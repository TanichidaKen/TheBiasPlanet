
class UnoSpreadSheetPropertyNamesSet:
	c_whetherIsVisible_boolean: str = "IsVisible"
	c_pageStyleName_string: str = "PageStyle"

