from theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup import BaseEnumerableConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.UnoPropertyNamesSet import UnoPropertyNamesSet

class Uno_uno_BasicIDEAppearEnumerablePropertyNamesSet (BaseEnumerableConstantsGroup [str], UnoPropertyNamesSet):
	c_documentName_string: str = "Document";
	c_libraryName_string: str = "LibName";
	c_itemName_string: str = "Name";
	c_itemTypeName_string: str = "Type";
	c_lineNumber_long: str = "Line";
	c_column1Number_short: str = "Column1";
	c_column2Number_short: str = "Column2";
	c_instance: "Uno_uno_BasicIDEAppearEnumerablePropertyNamesSet"
	
	def __init__ (a_this: "Uno_uno_BasicIDEAppearEnumerablePropertyNamesSet") -> None:
		BaseEnumerableConstantsGroup.__init__ (a_this, str)
	
Uno_uno_BasicIDEAppearEnumerablePropertyNamesSet.c_instance = Uno_uno_BasicIDEAppearEnumerablePropertyNamesSet ()

