from theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup import BaseEnumerableConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.UnoPropertyNamesSet import UnoPropertyNamesSet

class Uno_uno_GoToCellEnumerablePropertyNamesSet (BaseEnumerableConstantsGroup [str], UnoPropertyNamesSet):
	c_destinationPoint_string: str = "ToPoint"
	c_instance: "Uno_uno_GoToCellEnumerablePropertyNamesSet"
	
	def __init__ (a_this: "Uno_uno_GoToCellEnumerablePropertyNamesSet") -> None:
		BaseEnumerableConstantsGroup.__init__ (a_this, str)
	
Uno_uno_GoToCellEnumerablePropertyNamesSet.c_instance = Uno_uno_GoToCellEnumerablePropertyNamesSet ()

