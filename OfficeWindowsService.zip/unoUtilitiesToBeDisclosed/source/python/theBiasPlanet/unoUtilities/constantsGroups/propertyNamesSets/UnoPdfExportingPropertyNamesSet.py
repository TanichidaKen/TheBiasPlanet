
class UnoPdfExportingPropertyNamesSet:
	# General
	c_pagesRangeSpecification_string: str = "PageRange" # '' -> all the pages, '1-2,4', etc.
	c_exportedSections_any: str = "Selection" # the selection gotten by 'XSelectionSupplier.getSelection ()' of the controller of the document, or an arbitrary object (for example, a cells range)
	c_losslessCompressionIsUsed_boolean: str = "UseLosslessCompression" # 'false' -> a JPEG compression is used
	c_jpegQuality_short: str = "Quality" # in %
	c_imageResolutionsAreReduced_boolean: str = "ReduceImageResolution"
	c_maximumImageResolution_short: str = "MaxImageResolution" # in DPI: 75, 150, 300, 600, or 1200
	c_watermarkString_string: str = "Watermark"
	c_originalDocumentIsEmbedded_boolean: str = "IsAddStream"
	c_pdfVersionCode_short: str = "SelectPdfVersion" # '0' -> PDF 1.4, '1' -> PDF/A-1
	c_taggedPdfIsUsed_boolean: str = "UseTaggedPDF"
	c_formFieldsAreExported_boolean: str = "ExportFormFields"
	c_formsTypeCode_short: str = "FormsType" # '0' -> FDF, '1' -> PDF, '2' -> HTML, '3' -> XML
	c_someDuplicateFieldNamesAreAllowed_boolean: str = "AllowDuplicateFieldNames"
	c_bookmarksAreExported_boolean: str = "ExportBookmarks"
	c_placeholdersAreExported_boolean: str = "ExportPlaceholders"
	c_commentsAreExported_boolean: str = "ExportNotes"
	c_automaticallyInsertedEmptyPagesAreSkipped_boolean: str = "IsSkipEmptyPages"
	c_formXobjectsAreUsed_boolean: str = "UseReferenceXObject"
	c_targetFileIsShownAfterExportingHasBeenCompleted_boolean: str = "ViewPDFAfterExport"
	# Initial View
	c_forAfterExportingShowingOfTargetFileInitialViewStyleCode_short: str = "InitialView" # '0' -> pages only, '1' -> bookmarks and pages, '2' -> thumbnails and pages
	c_forAfterExportingShowingOfTargetFileInitialPageNumber_short: str = "InitialPage"
	c_forAfterExportingShowingOfTargetFileInitialMagnificationTypeCode_short: str = "Magnification" # '0' -> default, '1' -> the whole page is fitted into the window, '2' -> the page width is fitted into the window, '3' -> the page contents are supposed to be fitted into the window, but not necessarily are so
	c_forAfterExportingShowingOfTargetFileInitialZoomFactor_short: str = "Zoom" # in %
	c_forAfterExportingShowingOfTargetFileInitialPageLayoutStyleCode_short: str = "PageLayout" # '0' -> default, '1' -> single page, '2' -> continuous, '3' -> each 2 facing pages are shown abreast and those pairs are shown continuously connected vertically
	c_forAfterExportingShowingOfTargetFileFirstPageIsOnLeft_boolean: str = "FirstPageOnLeft" # valid only when 'PageLayout' is '3'
	# User Interface
	c_forAfterExportingShowingOfTargetFileWindowIsResizedToInitialPage_boolean: str = "ResizeWindowToInitialPage"
	c_forAfterExportingShowingOfTargetFileWindowIsCenteredOnScreen_boolean: str = "CenterWindow"
	c_forAfterExportingShowingOfTargetFileWindowIsOpenedInFullScreenMode_boolean: str = "OpenInFullScreenMode"
	c_forAfterExportingShowingOfTargetFileDocumentTitleIsShown_boolean: str = "DisplayPDFDocumentTitle"
	c_forAfterExportingShowingOfTargetFileTransitionEffectsAreUsed_boolean: str = "UseTransitionEffects"
	c_forAfterExportingShowingOfTargetFileMenubarIsHidden_boolean: str = "HideViewerMenubar"
	c_forAfterExportingShowingOfTargetFileToolbarIsHidden_boolean: str = "HideViewerToolbar"
	c_forAfterExportingShowingOfTargetFileWindowControlsAreHidden_boolean: str = "HideViewerWindowControls"
	c_forAfterExportingShowingOfTargetFileOpenedBookmarkLevels_short: str = "OpenBookmarkLevels" # '-1' -> all
	# Links
	c_bookmarksAreExportedAsNamedDestinations_boolean: str = " ExportBookmarksToPDFDestination"
	c_documentLinksAreConvertedToPdfTargets_boolean: str = "ConvertOOoTargetToPDFTarget"
	c_relativeFileLinksAreExported_boolean: str = "ExportLinksRelativeFsys"
	c_crossDocumentsLinksViewerCode_short: str = "PDFViewSelection" # '0' -> the default viewer, '1' -> a PDF reader application, '2' -> an internet browser
	# Security
	c_fileIsEncrypted_boolean: str = "EncryptFile"
	c_openingPassword_string: str = "DocumentOpenPassword"
	c_someActionsAreRestricted_boolean: str = "RestrictPermissions"
	c_restrictedActionsPassword_string: str = "PermissionPassword"
	c_printingRestrictionCode_short: str = "Printing" # '0' -> not permitted, '1' -> only in a low resolution (150 DPI), '2' -> also in high resolutions
	c_changingRestrictionCode_short: str = "Changes" # '0' -> not permitted, '1' -> inserting, deleting, and rotating pages, '2' -> filling in form fields, '3' -> commenting and filling in form fields, '4' -> any except extracting pages
	c_copyingOfContentsIsAllowed_boolean: str = "EnableCopyingOfContent"
	c_textAccessForAccessibilityToolsIsAllowed_boolean: str = "EnableTextAccessForAccessibilityTools"
	# Digital Signature
	c_fileIsSigned_boolean: str = "SignPDF"
	c_signatureCertificate_com_sun_star_security_XCertificate: str = "SignatureCertificate"
	c_signatureCertificatePassword_string: str = "SignaturePassword"
	c_signatureLocation_string: str = "SignatureLocation"
	c_signatureReason_string: str = "SignatureReason"
	c_signatureContactInformation_string: str = "SignatureContactInfo"
	c_signatureTimeStampAuthorityUrl_string: str = "SignatureTSA"

