from theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup import BaseEnumerableConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.UnoPropertyNamesSet import UnoPropertyNamesSet

class Uno_uno_PasteSpecialEnumerablePropertyNamesSet (BaseEnumerableConstantsGroup [str], UnoPropertyNamesSet):
	c_formatKey_int: str = "Format"
	c_instance: "Uno_uno_PasteSpecialEnumerablePropertyNamesSet"
	
	def __init__ (a_this: "Uno_uno_PasteSpecialEnumerablePropertyNamesSet") -> None:
		BaseEnumerableConstantsGroup.__init__ (a_this, str)

Uno_uno_PasteSpecialEnumerablePropertyNamesSet.c_instance = Uno_uno_PasteSpecialEnumerablePropertyNamesSet ()

