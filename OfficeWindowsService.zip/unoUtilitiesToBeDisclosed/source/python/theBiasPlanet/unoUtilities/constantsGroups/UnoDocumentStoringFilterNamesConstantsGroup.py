
class UnoDocumentStoringFilterNamesConstantsGroup:
	c_toOpenDocumentTextFileFilterName: str = "writer8"
	c_toOpenDocumentSpreadsheetFileFilterName: str = "calc8"
	c_toOpenDocumentPresentationFileFilterName: str = "impress8"
	c_toMicrosoftWord97FileFilterName: str = "MS Word 97"
	c_toMicrosoftWord2007XmlFileFilterName: str = "MS Word 2007 XML"
	c_toMicrosoftExcel97FileFilterName: str = "MS Excel 97"
	c_toMicrosoftExcel2007XmlFileFilterName: str = "Calc MS Excel 2007 XML"
	c_toMicrosoftPowerPoint97FileFilterName: str = "MS PowerPoint 97"
	c_toMicrosoftPowerPoint2007XmlFileFilterName: str = "Impress MS PowerPoint 2007 XML"
	c_toCsvFileFilterName: str = "Text - txt - csv (StarCalc)"
	c_toPdfFileFilterNameForTextDocuments: str = "writer_pdf_Export"
	c_toPdfFileFilterNameForSpreadSheetsDocuments: str = "calc_pdf_Export"
	c_toPdfFileFilterNameForPresentationDocuments: str = "impress_pdf_Export"

