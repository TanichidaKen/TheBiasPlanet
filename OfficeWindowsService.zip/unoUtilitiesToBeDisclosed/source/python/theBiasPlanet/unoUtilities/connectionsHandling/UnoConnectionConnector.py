from datetime import datetime
from typing import cast
from typing import List
from typing import Optional
from com.sun.star.connection import XConnection
from com.sun.star.connection import XConnector
from theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup import GeneralConstantsConstantsGroup
from theBiasPlanet.coreUtilities.stringsHandling.StringTokenizer import StringTokenizer
from theBiasPlanet.unoUtilities.connectionsHandling.UnoConnection import UnoConnection
from theBiasPlanet.unoUtilities.connectionsHandling.UnoConnectionEventsListener import UnoConnectionEventsListener
from theBiasPlanet.unoUtilities.connectionsHandling.UnoConnectionsFactory import UnoConnectionsFactory
from theBiasPlanet.unoUtilities.connectionsHandling.UnoObjectsContext import UnoObjectsContext
from theBiasPlanet.unoUtilities.constantsGroups.UnoGeneralConstantsConstantsGroup import UnoGeneralConstantsConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.UnoServiceNamesConstantsGroup import UnoServiceNamesConstantsGroup

class UnoConnectionConnector (UnoConnectionsFactory):
	def __init__ (a_this: "UnoConnectionConnector", a_localObjectsContext: UnoObjectsContext) -> None:
		
		UnoConnectionsFactory.__init__ (a_this, a_localObjectsContext)
		a_this.initialize ()
	
	def connect (a_this: "UnoConnectionConnector", a_url: str, a_eventListeners: Optional [List [UnoConnectionEventsListener]]) -> UnoConnection:
		l_urlTokenizer:StringTokenizer = StringTokenizer (a_url, UnoGeneralConstantsConstantsGroup.c_connectionUrlDelimiter)
		l_unoConnectionConnectorInXConnector:XConnector = cast (XConnector, a_this.i_localObjectsContext.getServiceInstance (UnoServiceNamesConstantsGroup.c_com_sun_star_connection_Connector, None))
		l_connectionInXConnection:XConnection = l_unoConnectionConnectorInXConnector.connect (l_urlTokenizer.nextToken ())
		l_unoConnection:UnoConnection = a_this.setupConnection (l_connectionInXConnection, l_urlTokenizer, str (datetime.now ()), a_eventListeners)
		return l_unoConnection

