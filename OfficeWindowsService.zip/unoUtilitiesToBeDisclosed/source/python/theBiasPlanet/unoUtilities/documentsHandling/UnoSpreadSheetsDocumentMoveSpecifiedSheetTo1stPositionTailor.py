from typing import cast
from com.sun.star.container import XIndexAccess
from com.sun.star.container import XNamed
from com.sun.star.frame import XModel
from com.sun.star.lang import XComponent
from com.sun.star.sheet import XSpreadsheet
from com.sun.star.sheet import XSpreadsheetDocument
from com.sun.star.sheet import XSpreadsheets
from  theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup import GeneralConstantsConstantsGroup
from theBiasPlanet.coreUtilities.messagingHandling.Publisher import Publisher
from theBiasPlanet.unoUtilities.documentsHandling.UnoDocumentTailor import UnoDocumentTailor 
from theBiasPlanet.unoUtilities.pointers.UnoObjectPointer import UnoObjectPointer 
from theBiasPlanet.unoUtilities.unoObjectsContexts.RemoteUnoObjectsContextInterface import RemoteUnoObjectsContextInterface

class UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor (UnoDocumentTailor):
	def __init__ (a_this: "UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor", a_remoteUnoObjectsContext: "RemoteUnoObjectsContextInterface", a_targetSpreadSheetIndex: int) -> None:
		a_this.i_targetSpreadSheetIndex: int
		
		UnoDocumentTailor.__init__ (a_this, a_remoteUnoObjectsContext)
		a_this.i_targetSpreadSheetIndex = a_targetSpreadSheetIndex
	
	def tailor (a_this: "UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor", a_unoDocument: "UnoObjectPointer [XModel]") -> bool:
		l_spreadSheets: "UnoObjectPointer [XIndexAccess]" = UnoObjectPointer (XIndexAccess, a_unoDocument.getAddress ().getSheets ())
		try:
			l_spreadSheet: "UnoObjectPointer [XSpreadsheet]" = UnoObjectPointer (XSpreadsheet, l_spreadSheets.getAddress ().getByIndex (a_this.i_targetSpreadSheetIndex).getObject ())
			l_spreadSheets.getAddress ().moveByName (l_spreadSheet.getAddress ().getName (), GeneralConstantsConstantsGroup.c_iterationStartNumber)
			return True
		except (Exception) as l_exception:
			Publisher.logErrorInformation (l_exception)
			return False

