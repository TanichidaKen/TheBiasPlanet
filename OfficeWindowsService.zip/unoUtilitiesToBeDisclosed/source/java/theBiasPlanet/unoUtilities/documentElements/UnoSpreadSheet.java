package theBiasPlanet.unoUtilities.documentElements;

import java.util.ArrayList;
import com.sun.star.awt.EnhancedMouseEvent;
import com.sun.star.awt.Key;
import com.sun.star.awt.KeyEvent;
import com.sun.star.awt.KeyModifier;
import com.sun.star.awt.XEnhancedMouseClickHandler;
import com.sun.star.awt.XKeyHandler;
import com.sun.star.beans.XPropertySet;
import com.sun.star.beans.UnknownPropertyException;
import com.sun.star.container.NoSuchElementException;
import com.sun.star.container.XNamed;
import com.sun.star.container.XIndexAccess;
import com.sun.star.frame.XModel;
import com.sun.star.lang.EventObject;
import com.sun.star.lang.WrappedTargetException;
import com.sun.star.sheet.XSheetCellCursor;
import com.sun.star.sheet.XSheetCellRange;
import com.sun.star.sheet.XSheetCellRangeContainer;
import com.sun.star.sheet.XSpreadsheet;
import com.sun.star.style.XStyle;
import com.sun.star.table.XCell2;
import com.sun.star.uno.AnyConverter;
import com.sun.star.uno.XInterface;
import com.sun.star.util.XModifyListener;
import com.sun.star.view.XSelectionChangeListener;
import theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup;
import theBiasPlanet.unoUtilities.constantsGroups.UnoMessagesConstantsGroup;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.*;
import theBiasPlanet.unoUtilities.displayElements.UnoDesktop;
import theBiasPlanet.unoUtilities.documents.UnoSpreadSheetsDocument;
import theBiasPlanet.unoUtilities.documentsHandling.UnoSpreadSheetCellPosition;
import theBiasPlanet.unoUtilities.documentsHandling.UnoSpreadSheetCellsRectangle;
import theBiasPlanet.unoUtilities.documentsHandling.UnoSpreadSheetCellsRectangles;
import theBiasPlanet.unoUtilities.inspectionsHandling.UnoInterfaceNotImplementedException;
import theBiasPlanet.unoUtilities.pointers.UnoObjectPointer;
import theBiasPlanet.unoUtilities.unoComponentBases.UnoComponentBase;

public class UnoSpreadSheet extends UnoComponentBase implements XSelectionChangeListener, XModifyListener, XEnhancedMouseClickHandler, XKeyHandler {
	private UnoSpreadSheetsDocument i_document = null;
	private UnoObjectPointer <XSpreadsheet> i_underlyingUnoObject = null;
	private UnoSpreadSheetCellPosition i_selectedCellPosition = null;
	private UnoSpreadSheetCellsRectangle i_selectedCellsRectangle = null;
	private UnoSpreadSheetCellsRectangles i_selectedCellsRectangles = null;
	private UnoSpreadSheetCellPosition i_currentCellPosition = null;
	private boolean i_isInMouseClickHandling = false;
	
	public UnoSpreadSheet (UnoSpreadSheetsDocument a_spreadSheetsDocument, UnoObjectPointer <XSpreadsheet> a_underlyingUnoObject) throws Exception {
		if (a_spreadSheetsDocument == null) {
			throw new Exception (UnoMessagesConstantsGroup.c_spreadSheetsDocumentNotSpecified);
		}
		i_document = a_spreadSheetsDocument;
		if (a_underlyingUnoObject == null) {
			throw new Exception (UnoMessagesConstantsGroup.c_spreadSheetNotSpecified);
		}
		i_underlyingUnoObject = a_underlyingUnoObject;
		/*
		retrieveSelection ();
		// Unless this is called when the current cell is the selected cell, this isn't correct.
		setCurrentCellPosition (i_selectedCellPosition);
		// i_document.addSelectionChangeListener (this);
		// i_document.addEnhancedMouseClicksListener (this);
		// i_document.addKeyPressesListener (this);
		*/
	}
	
	public static UnoSpreadSheet getCurrentSheet (UnoDesktop a_unoDesktop) throws Exception {
		UnoSpreadSheetsDocument l_currentSpreadSheetsDocument = UnoSpreadSheetsDocument.getCurrentDocument (a_unoDesktop);
		return l_currentSpreadSheetsDocument.getActiveSheet ();
	}
	
	public static UnoSpreadSheet getSheet (UnoDesktop a_unoDesktop, String a_fileName) throws Exception {
		UnoSpreadSheetsDocument l_spreadSheetsDocument = UnoSpreadSheetsDocument.getDocument (a_unoDesktop, a_fileName);
		return l_spreadSheetsDocument.getActiveSheet ();
	}
	
	// return: true -> the selection is changed, false -> the selection isn't changed
	private boolean retrieveSelection () {
		boolean l_selectionIsChanged = false;
		if (!isActive ()) {
		}
		else {
			UnoObjectPointer <XInterface> l_selection = new UnoObjectPointer <XInterface> ( (XInterface) i_document.getUnderlyingUnoObject ().getAddress (XModel.class).getCurrentSelection ());
			UnoSpreadSheetCellPosition l_selectedCellPosition = UnoSpreadSheetCellPosition.getCellPosition (this, l_selection);
			if (l_selectedCellPosition != null) {
				if (i_selectedCellPosition == null) {
					l_selectionIsChanged = true;
				}
				else {
					if (l_selectedCellPosition.equals (i_selectedCellPosition)) {
					}
					else {
//theBiasPlanet.coreUtilities.messagingHandling.Publisher.appendToFile (System.getProperty("user.home") + "/UnoSelectionChangedEvents.txt", "True1: " + l_selectedCellPosition + ", " + i_selectedCellPosition);
						l_selectionIsChanged = true;
					}
				}
				if (l_selectionIsChanged) {
					i_selectedCellsRectangles = null;
					i_selectedCellsRectangle = null;
					i_selectedCellPosition = l_selectedCellPosition;
					if (!i_isInMouseClickHandling) {
						setCurrentCellPosition (i_selectedCellPosition);
//theBiasPlanet.coreUtilities.messagingHandling.Publisher.appendToFile (System.getProperty("user.home") + "/UnoSelectionChangedEvents.txt", "Current cell set: " + i_selectedCellPosition);
					}
				}
			}
			else {
				UnoSpreadSheetCellsRectangle l_selectedCellsRectangle = UnoSpreadSheetCellsRectangle.getCellsRectangle (this, l_selection);
				if (l_selectedCellsRectangle != null) {
					if (i_selectedCellsRectangle == null) {
						l_selectionIsChanged = true;
					}
					else {
						if (l_selectedCellsRectangle.equals (i_selectedCellsRectangle)) {
						}
						else {
							l_selectionIsChanged = true;
						}
					}
					if (l_selectionIsChanged) {
						i_selectedCellsRectangles = null;
						i_selectedCellsRectangle = l_selectedCellsRectangle;
						i_selectedCellPosition = null;
					}
				}
				else {
					UnoSpreadSheetCellsRectangles l_selectedCellsRectangles = UnoSpreadSheetCellsRectangles.getCellsRectangles (this, l_selection);
					if (l_selectedCellsRectangles != null) {
						if (i_selectedCellsRectangles == null) {
							l_selectionIsChanged = true;
						}
						else {
							if (l_selectedCellsRectangles.equals (i_selectedCellsRectangles)) {
							}
							else {
								l_selectionIsChanged = true;
							}
						}
						if (l_selectionIsChanged) {
							i_selectedCellsRectangles = l_selectedCellsRectangles;
							i_selectedCellsRectangle = null;
							i_selectedCellPosition = null;
						}
					}
					else {
						if (i_selectedCellsRectangles == null && i_selectedCellsRectangle == null && i_selectedCellPosition == null) {
						}
						else {
							l_selectionIsChanged = true;
						}
						if (l_selectionIsChanged) {
							i_selectedCellsRectangles = null;
							i_selectedCellsRectangle = null;
							i_selectedCellPosition = null;
						}
					}
				}
			}
		}
if (l_selectionIsChanged) {
try {
if (i_selectedCellPosition != null) {
UnoSpreadSheetCell l_selectedCell = getCell (i_selectedCellPosition);
//theBiasPlanet.coreUtilities.messagingHandling.Publisher.appendToFile (System.getProperty("user.home") + "/UnoNeighboringCells.txt", String.format ("selected: %d, %d", l_selectedCell.getRepresentativeRowIndex (), l_selectedCell.getRepresentativeColumnIndex ()));
UnoSpreadSheetCell l_upperCell = l_selectedCell.getUpperCell ();
//theBiasPlanet.coreUtilities.messagingHandling.Publisher.appendToFile (System.getProperty("user.home") + "/UnoNeighboringCells.txt", String.format ("Upper: %d, %d", l_upperCell.getRepresentativeRowIndex (), l_upperCell.getRepresentativeColumnIndex ()));
UnoSpreadSheetCell l_downCell = l_selectedCell.getDownCell ();
//theBiasPlanet.coreUtilities.messagingHandling.Publisher.appendToFile (System.getProperty("user.home") + "/UnoNeighboringCells.txt", String.format ("Down: %d, %d", l_downCell.getRepresentativeRowIndex (), l_downCell.getRepresentativeColumnIndex ()));
UnoSpreadSheetCell l_leftCell = l_selectedCell.getLeftCell ();
//theBiasPlanet.coreUtilities.messagingHandling.Publisher.appendToFile (System.getProperty("user.home") + "/UnoNeighboringCells.txt", String.format ("Left: %d, %d", l_leftCell.getRepresentativeRowIndex (), l_leftCell.getRepresentativeColumnIndex ()));
UnoSpreadSheetCell l_rightCell = l_selectedCell.getRightCell ();
//theBiasPlanet.coreUtilities.messagingHandling.Publisher.appendToFile (System.getProperty("user.home") + "/UnoNeighboringCells.txt", String.format ("Right: %d, %d", l_rightCell.getRepresentativeRowIndex (), l_rightCell.getRepresentativeColumnIndex ()));


}
}
catch (Exception l_exception) {
//theBiasPlanet.coreUtilities.messagingHandling.Publisher.appendToFile (System.getProperty("user.home") + "/UnoNeighboringCells.txt", l_exception.toString ());
}

// try {
// UnoSpreadSheetCell l_currentCell = getCell (i_currentCellPosition);
// theBiasPlanet.coreUtilities.messagingHandling.Publisher.appendToFile (System.getProperty("user.home") + "/UnoSelectionChangedEvents.txt", "Current cell moved: " + i_currentCellPosition);
// l_currentCell.setAsCurrentCell ();
// }
// catch (Exception l_exception) {
// }

//theBiasPlanet.coreUtilities.messagingHandling.Publisher.appendToFile (System.getProperty("user.home") + "/UnoSelectionChangedEvents.txt", i_selectedCellPosition + "@" + i_selectedCellsRectangle + "@" + i_selectedCellsRectangles);
}
		if (l_selectionIsChanged && i_isInMouseClickHandling) {
//theBiasPlanet.coreUtilities.messagingHandling.Publisher.appendToFile (System.getProperty("user.home") + "/UnoSelectionChangedEvents.txt", "i_isInMouseClickHandling is set false");

			i_isInMouseClickHandling = false;
		}
		return l_selectionIsChanged;
	}
	
	private void setCurrentCellPosition (UnoSpreadSheetCellPosition a_cellPosition) {
		i_currentCellPosition = a_cellPosition;
//theBiasPlanet.coreUtilities.messagingHandling.Publisher.appendToFile (System.getProperty("user.home") + "/UnoCurrentCellPositionChangedEvents.txt", "" + i_currentCellPosition);
	}
	
	public boolean isActive () {
	try {
			UnoSpreadSheet l_activeSpreadSheet = i_document.getActiveSheet ();
			if (getName ().equals (l_activeSpreadSheet.getName ())) {
				return true;
			}
			else {
				return false;
			}
		}
		catch (Exception l_exception) {
			return false;
		}
	}
	
	/*
	@Override
	public boolean equals (Object a_spreadSheetToBeComparedWith) {
    	if (a_spreadSheetToBeComparedWith != null) {
			UnoSpreadSheet l_spreadSheetToBeComparedWith = null;
			if (a_spreadSheetToBeComparedWith instanceof UnoSpreadSheet) {
				l_spreadSheetToBeComparedWith = (UnoSpreadSheet) a_spreadSheetToBeComparedWith;
			}
			else {
				return false;
			}
			if (i_document.equals (l_spreadSheetToBeComparedWith.getDocument ())) {
				if (getName ().equals (l_spreadSheetToBeComparedWith.getName ())) {
					return true;
				}
				else {
					return false;
				}
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}
	*/
	
	public UnoSpreadSheetsDocument getDocument () {
		return i_document;
	}
	
	public UnoObjectPointer <XSpreadsheet> getUnderlyingUnoObject () {
		return i_underlyingUnoObject;
	}
	
	public UnoObjectPointer <XStyle> getPageStyle () {
		try {
			return new UnoObjectPointer <XStyle> ( (XStyle) AnyConverter.toObject (XStyle.class, i_document.getPageStyles ().getAddress ().getByName (getPageStyleName ())));
		}
		catch (NoSuchElementException | WrappedTargetException l_exception) {
			// Impossible
			return null;
		}
	}
	
	public String getPageStyleName () {
		try {
			return (String) i_underlyingUnoObject.getAddress (XPropertySet.class).getPropertyValue (UnoSpreadSheetPropertyNamesSet.c_pageStyleName_string);
		}
		catch (UnknownPropertyException | WrappedTargetException l_exception) {
			// Impossible
			return null;
		}
	}
	
	public UnoSpreadSheetCell getCell (int a_rowIndex, int a_columnIndex) throws com.sun.star.lang.IndexOutOfBoundsException {
		return new UnoSpreadSheetCell (this, new UnoObjectPointer <XCell2> (i_underlyingUnoObject.getAddress ().getCellByPosition (a_columnIndex, a_rowIndex), XCell2.class));
	}
	
	public UnoSpreadSheetCell getCell (UnoSpreadSheetCellPosition a_cellPosition) throws com.sun.star.lang.IndexOutOfBoundsException {
		return getCell (a_cellPosition.getRowIndex (), a_cellPosition.getColumnIndex ());
	}
	
	public UnoSpreadSheetCell getFirstSelectedCell () {
		if (!isActive ()) {
			return null;
		}
		UnoObjectPointer <XInterface> l_selectedCells = new UnoObjectPointer <XInterface> ( (XInterface) getDocument ().getUnderlyingUnoObject ().getAddress (XModel.class).getCurrentSelection ());
		if (l_selectedCells.getAddress (XSheetCellRange.class) == null) {
			if (l_selectedCells.getAddress (XSheetCellRangeContainer.class) != null) {
				try {
					l_selectedCells = new UnoObjectPointer <XInterface> ( (XInterface) AnyConverter.toObject (XInterface.class, l_selectedCells.getAddress (XSheetCellRangeContainer.class).getByIndex (GeneralConstantsConstantsGroup.c_iterationStartNumber)));
				}
				catch (com.sun.star.lang.IndexOutOfBoundsException | WrappedTargetException l_exception) {
					return null;
				}
			}
			else {
				return null;
			}
		}
		if (l_selectedCells.getAddress (XSheetCellRange.class) != null) {
			try {
				return new UnoSpreadSheetCell (this, new UnoObjectPointer <XCell2> (l_selectedCells.getAddress (XSheetCellRange.class).getCellByPosition (GeneralConstantsConstantsGroup.c_iterationStartNumber, GeneralConstantsConstantsGroup.c_iterationStartNumber), XCell2.class));
			}
			catch (com.sun.star.lang.IndexOutOfBoundsException l_exception) {
				return null;
			}
		}
		else {
			return null;
		}
	}
	
	public ArrayList <UnoSpreadSheetCell> getSelectedCells () {
		if (!isActive ()) {
			return null;
		}
		UnoObjectPointer <XInterface> l_selectedCellsRootIterator = new UnoObjectPointer <XInterface> ( (XInterface) getDocument ().getUnderlyingUnoObject ().getAddress (XModel.class).getCurrentSelection ());
// try {
// theBiasPlanet.coreUtilities.messagingHandling.Publisher.appendToFile (System.getProperty("user.home") + "/UnoCurrentSelectionInterfaces.txt", "###\n" + String.join ("\n", theBiasPlanet.unoUtilities.inspecting.UnoComponentInspector.getTypeNames (l_selectedCellsInXInterface)));
// 
// theBiasPlanet.coreUtilities.messagingHandling.Publisher.appendToFile (System.getProperty("user.home") + "/UnoCurrentSelectionProperties.txt", "###\n" + String.join ("\n", theBiasPlanet.unoUtilities.inspecting.UnoComponentInspector.getPropertyNamesAndValues (l_selectedCellsInXInterface)));
// 
// 
// }
// catch (Exception l_exception) {
// theBiasPlanet.coreUtilities.messagingHandling.Publisher.appendToFile (System.getProperty("user.home") + "/UnoCurrentSelectionTest.txt", "### error\n" + l_exception.toString ());
// }
		ArrayList <UnoSpreadSheetCell> l_selectedCells = new ArrayList <UnoSpreadSheetCell> ();
		UnoObjectPointer <XSheetCellRange> l_selectedCellsRangeCellsIterator = null;
		for (int l_cellsRangeIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber; ; l_cellsRangeIndex ++) {
			if (l_selectedCellsRootIterator.getAddress (XSheetCellRangeContainer.class) == null) {
				try {
					l_selectedCellsRangeCellsIterator = new UnoObjectPointer <XSheetCellRange> (l_selectedCellsRootIterator, XSheetCellRange.class);
				}
				catch (UnoInterfaceNotImplementedException l_exception) {
				}
			}
			else {
				try {
					l_selectedCellsRangeCellsIterator = new UnoObjectPointer <XSheetCellRange> ( (XSheetCellRange) AnyConverter.toObject (XSheetCellRange.class , l_selectedCellsRootIterator.getAddress (XSheetCellRangeContainer.class).getByIndex (l_cellsRangeIndex)));
				}
				catch (com.sun.star.lang.IndexOutOfBoundsException | WrappedTargetException l_exception) {
					break;
				}
			}
			if (! (l_selectedCellsRangeCellsIterator.isEmpty ())) {
				m_rowsLoop:
				for (int l_cellRowInCellsRangeIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber; ; l_cellRowInCellsRangeIndex ++) {
					for (int l_cellColumnInCellsRangeIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber; ; l_cellColumnInCellsRangeIndex ++) {
						try {
							l_selectedCells.add (new UnoSpreadSheetCell (this, new UnoObjectPointer <XCell2> (l_selectedCellsRangeCellsIterator.getAddress ().getCellByPosition (l_cellColumnInCellsRangeIndex, l_cellRowInCellsRangeIndex), XCell2.class)));
						}
						catch (com.sun.star.lang.IndexOutOfBoundsException l_exception) {
							if (l_cellColumnInCellsRangeIndex == GeneralConstantsConstantsGroup.c_iterationStartNumber) {
								break m_rowsLoop;
							}
							else {
								break;
							}
						}
					}
				}
			}
			else {
				break;
			}
			if (l_selectedCellsRootIterator.getAddress (XSheetCellRangeContainer.class) == null) {
				break;
			}
		}
		return l_selectedCells;
	}
	
	public UnoObjectPointer <XSheetCellRange> getCellsRange (int a_cellTopRowIndex, int a_cellLeftColumnIndex, int a_cellBottomRowIndex, int a_cellRightColumnIndex) throws com.sun.star.lang.IndexOutOfBoundsException {
		return new UnoObjectPointer <XSheetCellRange> (i_underlyingUnoObject.getAddress ().getCellRangeByPosition (a_cellLeftColumnIndex, a_cellTopRowIndex, a_cellRightColumnIndex, a_cellBottomRowIndex), XSheetCellRange.class);
	}
	
	public UnoObjectPointer <XSheetCellCursor> getCellsRangeCursor (int a_cellTopRowIndex, int a_cellLeftColumnIndex, int a_cellBottomRowIndex, int a_cellRightColumnIndex) throws com.sun.star.lang.IndexOutOfBoundsException {
		return getCellsRangeCursor (getCellsRange (a_cellTopRowIndex, a_cellLeftColumnIndex, a_cellBottomRowIndex, a_cellRightColumnIndex));
	}
	
	public UnoObjectPointer <XSheetCellCursor> getCellsRangeCursor (UnoObjectPointer <? extends XInterface> a_cellsRange) {
		return new UnoObjectPointer <XSheetCellCursor> (i_underlyingUnoObject.getAddress ().createCursorByRange (a_cellsRange. <XSheetCellRange>getAddress (XSheetCellRange.class)));
	}
	
	public String getName () {
		return i_underlyingUnoObject.getAddress (XNamed.class).getName ();
	}
	
	public int getIndex () throws com.sun.star.lang.IndexOutOfBoundsException, WrappedTargetException {
		UnoObjectPointer <XIndexAccess> l_spreadSheets = null;
		try {
			l_spreadSheets = new UnoObjectPointer <XIndexAccess> (i_document.getSheets (), XIndexAccess.class);
		}
		catch (UnoInterfaceNotImplementedException l_exception) {
			// should never happen
			return GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		}
		int l_spreadSheetsCount = l_spreadSheets.getAddress ().getCount ();
		String l_spreadSheetName = getName ();
		UnoObjectPointer <XNamed> l_spreadSheet = null;
		int l_spreadSheetIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
		for (; l_spreadSheetIndex < l_spreadSheetsCount; l_spreadSheetIndex ++) {
			l_spreadSheet = new UnoObjectPointer <XNamed> ( (XInterface) l_spreadSheets.getAddress ().getByIndex (l_spreadSheetIndex), XNamed.class);
			if (l_spreadSheetName.equals (l_spreadSheet.getAddress ().getName ())) {
				break;
			}
		}
		if (l_spreadSheetIndex < l_spreadSheetsCount) {
			return l_spreadSheetIndex;
		}
		else {
			return GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		}
	}
	
	/*
	public void insertUnoRows (int a_startRowIndex, int a_endRowIndex) throws com.sun.star.lang.IndexOutOfBoundsException, WrappedTargetException {
		CellRangeAddress l_cellsRangeAddress = new CellRangeAddress ();
		l_cellsRangeAddress.Sheet = (short) getIndex ();
		l_cellsRangeAddress.StartRow = a_startRowIndex;
		l_cellsRangeAddress.EndRow = a_endRowIndex;
		i_selfInXCellRangeMovement.insertCells (l_cellsRangeAddress, CellInsertMode.ROWS);
	}
	
	public void insertUnoColumns (int a_startColumnIndex, int a_endColumnIndex) throws com.sun.star.lang.IndexOutOfBoundsException, WrappedTargetException {
		CellRangeAddress l_cellsRangeAddress = new CellRangeAddress ();
		l_cellsRangeAddress.Sheet = (short) getIndex ();
		l_cellsRangeAddress.StartColumn = a_startColumnIndex;
		l_cellsRangeAddress.EndColumn = a_endColumnIndex;
		i_selfInXCellRangeMovement.insertCells (l_cellsRangeAddress, CellInsertMode.COLUMNS);
	}
	
	public void removeUnoRows (int a_startRowIndex, int a_endRowIndex) throws com.sun.star.lang.IndexOutOfBoundsException, WrappedTargetException {
		CellRangeAddress l_cellsRangeAddress = new CellRangeAddress ();
		l_cellsRangeAddress.Sheet = (short) getIndex ();
		l_cellsRangeAddress.StartRow = a_startRowIndex;
		l_cellsRangeAddress.EndRow = a_endRowIndex;
		i_selfInXCellRangeMovement.removeRange (l_cellsRangeAddress, CellDeleteMode.ROWS);
	}
	
	public void removeUnoColumns (int a_startColumnIndex, int a_endColumnIndex) throws com.sun.star.lang.IndexOutOfBoundsException, WrappedTargetException {
		CellRangeAddress l_cellsRangeAddress = new CellRangeAddress ();
		l_cellsRangeAddress.Sheet = (short) getIndex ();
		l_cellsRangeAddress.StartColumn = a_startColumnIndex;
		l_cellsRangeAddress.EndColumn = a_endColumnIndex;
		i_selfInXCellRangeMovement.removeRange (l_cellsRangeAddress, CellDeleteMode.COLUMNS);
	}
	
	public void addModificationEventsListener (XModifyListener a_eventListener) {
		i_selfInXModifyBroadcaster.addModifyListener (a_eventListener);
	}
	
	public void removeModificationEventsListener (XModifyListener a_eventListener) {
		i_selfInXModifyBroadcaster.removeModifyListener (a_eventListener);
	}
	*/
	
	@Override
	public void disposing (EventObject a_event) {
	}
	
	@Override
	public void selectionChanged (EventObject a_event) {
		boolean l_selectionIsChanged = retrieveSelection ();
	}
	
	@Override
	public void modified (EventObject a_event) {
	}
	
	@Override
	public boolean mousePressed (EnhancedMouseEvent a_enhancedMouseEvent) {
//theBiasPlanet.coreUtilities.messagingHandling.Publisher.appendToFile (System.getProperty("user.home") + "/UnoSelectionChangedEvents.txt", "i_isInMouseClickHandling is set true");
		i_isInMouseClickHandling = true;
// try {
// theBiasPlanet.coreUtilities.messagingHandling.Publisher.appendToFile (System.getProperty("user.home") + "/UnoMousePressedEvents.txt", "###\n" + String.join ("\n", theBiasPlanet.unoUtilities.inspecting.UnoComponentInspector.getTypeNames ( (XInterface) a_enhancedMouseEvent.Target)));
// }
// catch (Exception l_exception) {
// 	
// }
		// 0 -> Nothing, KeyModifier.MOD1 -> Ctrl, KeyModifier.MOD2 -> Alt, KeyModifier.SHIFT -> Shift
		if (a_enhancedMouseEvent.Modifiers == 0 || a_enhancedMouseEvent.Modifiers == KeyModifier.MOD1) {
			UnoObjectPointer <XCell2> l_clickedCell = new UnoObjectPointer <XCell2> ( (XInterface) a_enhancedMouseEvent.Target, XCell2.class);
			if (! (l_clickedCell.isEmpty ())) {
				setCurrentCellPosition (UnoSpreadSheetCellPosition.getCellPosition (this, l_clickedCell));
			}
		}
		return true;
	}
	
	@Override
	public boolean  mouseReleased (EnhancedMouseEvent a_enhancedMouseEvent) {
		return true;
	}
	
	@Override
	public boolean keyPressed (KeyEvent a_keyEvent) {
//theBiasPlanet.coreUtilities.messagingHandling.Publisher.appendToFile (System.getProperty("user.home") + "/UnoSelectionChangedEvents.txt", "i_isInMouseClickHandling is set false");
		i_isInMouseClickHandling = false;
		if (a_keyEvent.KeyCode == Key.RETURN) {
			if (a_keyEvent.Modifiers == 0) {
				UnoSpreadSheetCellPosition l_nextCellPosition = null;
				if (i_selectedCellsRectangles != null) {
					l_nextCellPosition = i_selectedCellsRectangles.getVerticallyNextMemberCellPosition (i_currentCellPosition);
				}
				else if (i_selectedCellsRectangle != null) {
					l_nextCellPosition = i_selectedCellsRectangle.getVerticallyNextMemberCellPosition (i_currentCellPosition, true);
				}
				else if (i_selectedCellPosition != null) {
					l_nextCellPosition = i_selectedCellPosition.getVerticallyNextMemberCellPosition (i_currentCellPosition, true);
				}
				if (l_nextCellPosition != null) {
					setCurrentCellPosition (l_nextCellPosition);
				}
			}
			else if (a_keyEvent.Modifiers == KeyModifier.SHIFT) {
				UnoSpreadSheetCellPosition l_previousCellPosition = null;
				if (i_selectedCellsRectangles != null) {
					l_previousCellPosition = i_selectedCellsRectangles.getVerticallyPreviousMemberCellPosition (i_currentCellPosition);
				}
				else if (i_selectedCellsRectangle != null) {
					l_previousCellPosition = i_selectedCellsRectangle.getVerticallyPreviousMemberCellPosition (i_currentCellPosition, true);
				}
				else if (i_selectedCellPosition != null) {
					l_previousCellPosition = i_selectedCellPosition.getVerticallyPreviousMemberCellPosition (i_currentCellPosition, true);
				}
				if (l_previousCellPosition != null) {
					setCurrentCellPosition (l_previousCellPosition);
				}
			}
		}
		//else if (a_keyEvent.KeyCode == Key.UP) {
	//		if (a_keyEvent.Modifiers != KeyModifier.SHIFT) {
	//			i_isInControlArrowHandling = true;
	//		}
	//	}
	//	else if (a_keyEvent.KeyCode == Key.DOWN) {
	//		if (a_keyEvent.Modifiers == 0) {
	//			setCurrentCellPosition (i_currentCellPosition.getDownCellPosition ());
	//		}
	//		else if (a_keyEvent.Modifiers == KeyModifier.MOD1) {
	//			i_isInControlArrowHandling = true;
	//		}
	//	}
	//	else if (a_keyEvent.KeyCode == Key.LEFT) {
	//		if (a_keyEvent.Modifiers == 0) {
	//			setCurrentCellPosition (i_currentCellPosition.getLeftCellPosition ());
	//		}
	//		else if (a_keyEvent.Modifiers == KeyModifier.MOD1) {
	//			i_isInControlArrowHandling = true;
	//		}
	//	}
	//	else if (a_keyEvent.KeyCode == Key.RIGHT) {
	//		if (a_keyEvent.Modifiers == 0) {
	//			setCurrentCellPosition (i_currentCellPosition.getRightCellPosition ());
	//		}
	//		else if (a_keyEvent.Modifiers == KeyModifier.MOD1) {
	//			i_isInControlArrowHandling = true;
	//		}
	//	}
//theBiasPlanet.coreUtilities.messagingHandling.Publisher.appendToFile (String.format (GeneralConstantsConstantsGroup.c_linuxFilePathFormat, System.getProperty (JavaPropertyNamesConstantsGroup.c_userHomeDirectoryPath), "UnoKeyPressed.txt"), i_currentCellPosition.toString ());
		return false;
	}
	
	@Override
	public boolean keyReleased (KeyEvent a_keyEvent) {
		return false;
	}
	
	/*
	// a_numberOfRemainingColumns: the number of remaining columns. If it's unspecified, it is determined by the number of caption columns of the above row.
	// a_leafIsList: true if the leaf is a list; false if the leaf is a String
	// return: the cell for the next key. Null if there is no next key.
	@SuppressWarnings (WarningNamesConstantsGroup.c_notChecked)
	public <T, U> UnoSpreadSheetCell buildCascadeMap (UnoSpreadSheetCell a_startSpreadSheetCell, LinkedHashMap <T, U> a_mapToBeBuilt, int a_numberOfRemainingColumns, boolean a_leafIsList) throws IOException {
		UnoSpreadSheetCell l_nextCell = a_startSpreadSheetCell;
		if (a_numberOfRemainingColumns == GeneralConstantsConstantsGroup.c_unspecifiedInteger) {
			UnoSpreadSheetCell l_captionCell = null;
			try {
				l_captionCell = a_startSpreadSheetCell.getUpperCell ();
			}
			catch (com.sun.star.lang.IndexOutOfBoundsException l_exception) {
				return null;
			}
			a_numberOfRemainingColumns = 0;
			while (true) {
				if (l_captionCell.getBackgroundColor () == UnoPixelValuesConstantsGroup.c_parameterCaptionBackgroundPixelValue) {
					a_numberOfRemainingColumns ++;
				}
				else {
					break;
				}
				try {
					l_captionCell = l_captionCell.getRightCell ();
				}
				catch (com.sun.star.lang.IndexOutOfBoundsException l_exception) {
					break;
				}
			}
		}
		boolean l_isFirstRow = true;
		while (true) {
			if (l_nextCell == null) {
				return null;
			}
			if (!l_isFirstRow) {
				UnoSpreadSheetCell l_leftCell = null;
				try {
					 l_leftCell = l_nextCell.getLeftCell ();
					 if (l_leftCell.getValue () != null) {
						 // The row doesn't belong to this map
						 return l_leftCell;
					 }
				}
				catch (com.sun.star.lang.IndexOutOfBoundsException l_exception) {
				}
			}
			T l_key = (T) l_nextCell.getValue ();
			if (l_key == null) {
				return null;
			}
			UnoSpreadSheetCell l_rightCell = null;
			try {
				l_rightCell = l_nextCell.getRightCell ();
			}
			catch (com.sun.star.lang.IndexOutOfBoundsException l_exception) {
				// This won't happen unless a_numberOfRemainingColumns is erroneously specified.
				break;
			}
			if (a_numberOfRemainingColumns > 2) {
				LinkedHashMap <T, Object> l_childMap = new LinkedHashMap <T, Object> ();
				l_nextCell = buildCascadeMap (l_rightCell, l_childMap, a_numberOfRemainingColumns - 1, a_leafIsList);
				a_mapToBeBuilt.put (l_key, (U) l_childMap);
			}
			else {
				ArrayList <T> l_childList = new ArrayList <T> ();
				l_nextCell  =  buildList (l_rightCell, l_childList, false, GeneralConstantsConstantsGroup.c_unspecifiedInteger);
				if (a_leafIsList) {
					a_mapToBeBuilt.put (l_key, (U) l_childList);
				}
				else {
					// There should be only one element in the list; if not, only the first element will be used.
					a_mapToBeBuilt.put (l_key, (U) l_childList.get (GeneralConstantsConstantsGroup.c_iterationStartNumber));
				}
			}
			l_isFirstRow = false;
		}
		return null;
	}
	
	// a_numberOfColumns: the number of columns (the key column and the list columns). If it's unspecified, it is determined by the number of caption columns of the above row.
	@SuppressWarnings (WarningNamesConstantsGroup.c_notChecked)
	public <T> void buildObjectToListsMap (UnoSpreadSheetCell a_startSpreadSheetCell, LinkedHashMap <T, List <List <T>>> a_mapToBeBuilt, int a_numberOfColumns) throws IOException {
		UnoSpreadSheetCell l_nextCell = a_startSpreadSheetCell;
		if (a_numberOfColumns == GeneralConstantsConstantsGroup.c_unspecifiedInteger) {
			UnoSpreadSheetCell l_captionCell = null;
			try {
				l_captionCell = a_startSpreadSheetCell.getUpperCell ();
			}
			catch (com.sun.star.lang.IndexOutOfBoundsException l_exception) {
				return;
			}
			a_numberOfColumns = 0;
			while (true) {
				if (l_captionCell.getBackgroundColor () == UnoPixelValuesConstantsGroup.c_parameterCaptionBackgroundPixelValue) {
					a_numberOfColumns ++;
				}
				else {
					break;
				}
				try {
					l_captionCell = l_captionCell.getRightCell ();
				}
				catch (com.sun.star.lang.IndexOutOfBoundsException l_exception) {
					break;
				}
			}
		}
		int l_keyColumnIndex = l_nextCell.getRepresentativeColumnIndex ();
		while (true) {
			if (l_nextCell == null) {
				return;
			}
			T l_key = (T) l_nextCell.getValue ();
			if (l_key == null) {
				return;
			}
			// Actually, l_listColumnCell isn't a list column cell at this point, but will be moved to the left most list column cell soon.
			UnoSpreadSheetCell l_listColumnCell = l_nextCell;
			UnoSpreadSheetCell l_nextCellCandidate = null;
			ArrayList <List <T>> l_value = new ArrayList <List <T>> ();
			l_nextCell = null;
			for (int l_numberOfRemainingColumns = a_numberOfColumns - 1; l_numberOfRemainingColumns > 0; l_numberOfRemainingColumns --) {
				try {
					l_listColumnCell = l_listColumnCell.getRightCell ();
				}
				catch (com.sun.star.lang.IndexOutOfBoundsException l_exception) {
					// This won't happen unless a_numberOfColumns is erroneously specified.
					break;
				}
				ArrayList <T> l_childList = new ArrayList <T> ();
				l_nextCellCandidate = buildList (l_listColumnCell, l_childList, false, l_keyColumnIndex);
				if (l_nextCellCandidate != null) {
					l_nextCell = l_nextCellCandidate;
				}
				l_value.add (l_childList);
			}
			a_mapToBeBuilt.put (l_key, l_value);
		}
	}
	
	// a_standAlone: true if this list isn't a part of a map, but a standalone list; false otherwise
	// a_keysColumnIndex: the column of keys of the map to which this list belongs. This is valid only when a_standAlone is false.
	// return: the cell for the next key. Null if there is no next key.
	@SuppressWarnings (WarningNamesConstantsGroup.c_notChecked)
	public <T> UnoSpreadSheetCell buildList (UnoSpreadSheetCell a_startSpreadSheetCell, List <T> a_listToBeBuilt, boolean a_standAlone, int a_keysColumnIndex) throws IOException {
		UnoSpreadSheetCell l_nextCell = a_startSpreadSheetCell;
		boolean l_isFirstRow = true;
		while (true) {
			if (l_nextCell == null || l_nextCell.getValue () == null || l_nextCell.getBackgroundColor () == UnoPixelValuesConstantsGroup.c_parameterCaptionBackgroundPixelValue) {
				return null;
			}
			if (!a_standAlone && !l_isFirstRow) {
				UnoSpreadSheetCell l_keysColumnCell = null;
				try {
					if (a_keysColumnIndex != GeneralConstantsConstantsGroup.c_unspecifiedInteger) {
						l_keysColumnCell = l_nextCell.getSheet ().getCell (l_nextCell.getRepresentativeRowIndex (), a_keysColumnIndex);
					}
					// If a_keysColumnIndex isn't specified, the left cell is the keys column.
					else {
						l_keysColumnCell = l_nextCell.getLeftCell ();
					}
					if (l_keysColumnCell.getValue () != null) {
						// the row doesn't belong to this map
						return l_keysColumnCell;
					}
				}
				catch (com.sun.star.lang.IndexOutOfBoundsException l_exception) {
					// There is no keys column.
				}
			}
			T l_value = (T) l_nextCell.getValue ();
			a_listToBeBuilt.add (l_value);
			try {
				 l_nextCell = l_nextCell.getDownCell ();
			}
			catch (com.sun.star.lang.IndexOutOfBoundsException l_exception) {
				l_nextCell = null;
			}
			l_isFirstRow = false;
		}
	}
*/
}

