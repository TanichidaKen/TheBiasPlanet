package theBiasPlanet.unoUtilities.unoObjectsContexts;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;
import com.sun.star.container.ElementExistException;
import com.sun.star.container.NoSuchElementException;
import com.sun.star.container.XNameContainer;
import com.sun.star.container.XSet;
import com.sun.star.lang.IllegalArgumentException;
import com.sun.star.lang.WrappedTargetException;
import com.sun.star.lang.XMultiServiceFactory;
import com.sun.star.lang.XMultiComponentFactory;
import com.sun.star.lang.XSingleComponentFactory;
import com.sun.star.registry.XRegistryKey;
import com.sun.star.uno.XComponentContext;
import com.sun.star.uno.XInterface;
import theBiasPlanet.coreUtilities.collectionsHandling.ArraysFactory;
import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.coreUtilities.xmlDataHandling.XmlDatumHandler;
import theBiasPlanet.unoUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.*;

public class LocalUnoObjectsContext extends UnoObjectsContext {
	private XComponentContext i_underlyingUnoObject = null;
	private XMultiComponentFactory i_unoGlobalServicesManager = null;
	
	public LocalUnoObjectsContext (XComponentContext a_underlyingUnoObject, String a_unoConnectionIdentification) throws com.sun.star.uno.Exception {
		super (a_unoConnectionIdentification);
		i_underlyingUnoObject = a_underlyingUnoObject;
		i_unoGlobalServicesManager = i_underlyingUnoObject.getServiceManager ();
	}
	
	@Override
	protected void finalize () {
	}
	
	@Override
	public final Object getValueByName (String a_propertyName) {
		return i_underlyingUnoObject.getValueByName (a_propertyName);
	}
	
	@Override
	public void addExtraGlobalProperty (String a_propertyName, Object a_propertyValue) throws IllegalArgumentException, ElementExistException, WrappedTargetException {
		( (XNameContainer) i_underlyingUnoObject).insertByName (a_propertyName, a_propertyValue);
	}
	
	@Override
	public void removeExtraGlobalProperty (String a_propertyName) throws IllegalArgumentException, NoSuchElementException, WrappedTargetException {
		( (XNameContainer) i_underlyingUnoObject).removeByName (a_propertyName);
	}
	
	@Override
	public final XMultiComponentFactory getServiceManager () {
		return i_unoGlobalServicesManager;
	}
	
	@SuppressWarnings (WarningNamesConstantsGroup.c_notChecked)
	public <T extends XInterface> T getUnoServiceInstance (String a_unoServiceName, List <Object> a_unoServiceInstantiationArguments) throws com.sun.star.uno.Exception {
		if (a_unoServiceInstantiationArguments == null) {
			return (T) (getServiceManager ().createInstanceWithContext (a_unoServiceName, this));
		}
		else {
			return (T) (getServiceManager ().createInstanceWithArgumentsAndContext (a_unoServiceName, ArraysFactory. <Object>createArray (Object.class, a_unoServiceInstantiationArguments), this));
		}
	}
	
	private boolean addGlobalUnoService (XSingleComponentFactory a_globalUnoServiceInstancesFactory) throws ElementExistException {
		( (XSet) i_unoGlobalServicesManager).insert (a_globalUnoServiceInstancesFactory);
		return true;
	}
	
	public boolean addGlobalUnoServices (String a_globalUnoServiceInstancesFactoriesConfigurationFileUrl) throws IOException, ParserConfigurationException, SAXException, ClassNotFoundException, NoSuchMethodException, IllegalAccessException, InvocationTargetException, ElementExistException {
		ArrayList <XSingleComponentFactory> l_globalUnoServiceInstancesFactories = new ArrayList <XSingleComponentFactory> ();
		Map <String, List <String>> l_globalUnoServicesProviderNameToUnoComponentNamesMap = XmlDatumHandler.get2TierAttributeValues (a_globalUnoServiceInstancesFactoriesConfigurationFileUrl);
		if (l_globalUnoServicesProviderNameToUnoComponentNamesMap != null) {
			for (Map.Entry <String, List <String>> l_globalUnoServicesProviderNameToUnoComponentNamesMapEntry: l_globalUnoServicesProviderNameToUnoComponentNamesMap.entrySet ()) {
				Class <?> l_globalUnoServicesProvider = null;
				Method l___getComponentFactoryMethod = null;
				Method l___getServiceFactoryMethod = null;
				XSingleComponentFactory l_globalUnoServiceInstancesFactory = null;
				l_globalUnoServicesProvider = Class.forName (l_globalUnoServicesProviderNameToUnoComponentNamesMapEntry.getKey ());
				if (l_globalUnoServicesProvider == null) {
					continue;
				}
				try {
					l___getComponentFactoryMethod = l_globalUnoServicesProvider.getMethod ("__getComponentFactory", String.class);
				}
				catch (NoSuchMethodException l_exception) {
				}
				if (l___getComponentFactoryMethod == null) {
					l___getServiceFactoryMethod = l_globalUnoServicesProvider.getMethod ("__getServiceFactory", String.class, XMultiServiceFactory.class, XRegistryKey.class);
				}
				for (String l_unoComponentName: l_globalUnoServicesProviderNameToUnoComponentNamesMapEntry.getValue ()) {
					if (l___getComponentFactoryMethod != null) {
						l_globalUnoServiceInstancesFactory = (XSingleComponentFactory) l___getComponentFactoryMethod.invoke (null, new Object [] {l_unoComponentName});
					}
					else if (l___getServiceFactoryMethod != null) {
						//l_globalUnoServiceInstancesFactory = UnoRuntime.queryInterface (XSingleComponentFactory.class, (XSingleServiceFactory) l___getServiceFactoryMethod.invoke (null, new Object [] {l_unoComponentName, null, null}));
						l_globalUnoServiceInstancesFactory = (XSingleComponentFactory) l___getServiceFactoryMethod.invoke (null, new Object [] {l_unoComponentName, null, null});
					}
					if (l_globalUnoServiceInstancesFactory != null) {
						addGlobalUnoService (l_globalUnoServiceInstancesFactory);
					}
				}
			}
		}
		return true;
	}
}

