package theBiasPlanet.unoUtilities.connection;

import java.util.List;
import java.util.Map;
import com.sun.star.bridge.XBridge;
import com.sun.star.bridge.XInstanceProvider;
import com.sun.star.container.ElementExistException;
import com.sun.star.frame.TerminationVetoException;
import com.sun.star.frame.XDesktop;
import com.sun.star.frame.XTerminateListener;
import com.sun.star.lang.EventObject;
import com.sun.star.lang.XComponent;
import com.sun.star.lang.XEventListener;
import com.sun.star.uno.XComponentContext;
import com.sun.star.uno.XInterface;
import theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup;
import theBiasPlanet.coreUtilities.messagingHandling.Publisher;
import theBiasPlanet.unoDatumTypes.unoUtilities.officeInstance.XOfficeInstance;
import theBiasPlanet.unoUtilities.constantsGroups.UnoDefaultValuesConstantsGroup;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.UnoObjectsContextPropertyNamesSet;
import theBiasPlanet.unoUtilities.displayElements.UnoDesktop;
import theBiasPlanet.unoUtilities.officeInstance.OfficeInstance;
import theBiasPlanet.unoUtilities.pointers.UnoObjectPointer;
import theBiasPlanet.unoUtilities.unoComponentBases.UnoComponentBase;
import theBiasPlanet.unoUtilities.unoDataHandling.UnoDatumConverter;
import theBiasPlanet.unoUtilities.unoObjectsContexts.LocalUnoObjectsContext;
import theBiasPlanet.unoUtilities.unoObjectsContexts.RemoteUnoObjectsContext;

public class UnoConnection extends UnoComponentBase implements XEventListener {
	public static class InitialUnoObjectsProvider extends UnoComponentBase implements XInstanceProvider {
		private LocalUnoObjectsContext i_localUnoObjectsContext = null;
		
		public InitialUnoObjectsProvider (LocalUnoObjectsContext a_localUnoObjectsContext) {
			i_localUnoObjectsContext = a_localUnoObjectsContext;
		}
		
		@Override
		protected void finalize () {
		}
		
		@Override
		public XInterface getInstance (String a_initialUnoObjectName) {
			if (UnoDefaultValuesConstantsGroup.c_initiallyOfferedUnoObjectName.equals (a_initialUnoObjectName)) {
				return i_localUnoObjectsContext;
			}
			else {
				return null;
			}
		}
	}
	public interface UnoConnectionEventsListener {
		public void connected (UnoConnection a_unoConnection);
		
		public void disconnected (UnoConnection a_unoConnection);
	}
	public class OfficeTerminationQueryListener extends UnoComponentBase implements XTerminateListener {
		public OfficeTerminationQueryListener () {
		}
		
		@Override
		public void queryTermination (com.sun.star.lang.EventObject a_event) throws TerminationVetoException {
			Publisher.logNormalInformation ("### The termination of the office instance is queried.");
			RemoteUnoObjectsContext l_remoteUnoObjectsContext = getRemoteUnoObjectsContext ();
			if (l_remoteUnoObjectsContext.officeInstanceSingletonIsSet ()) {
				if (! (l_remoteUnoObjectsContext.serverIsPlannedToBeTerminated ()) || l_remoteUnoObjectsContext.getCriticalSessionCount () > 0) {
					Publisher.logNormalInformation ("### And vetoed.");
					throw new TerminationVetoException ();
				}
				else {
					Publisher.logNormalInformation ("### And accepted.");
				}
			}
		}
		
		@Override
		public void notifyTermination (com.sun.star.lang.EventObject a_event) {
			Publisher.logNormalInformation ("### The termination of the office instance is notified.");
			//disconnect ();
		}
		
		@Override
		public void disposing (com.sun.star.lang.EventObject a_event) {
		}
	}
	private RemoteUnoObjectsContext i_remoteUnoObjectsContext;
	private XComponent i_unoBridge;
	private	InitialUnoObjectsProvider i_initialUnoObjectsProvider;
	private List <UnoConnectionEventsListener> i_eventsListeners;
	private OfficeTerminationQueryListener i_officeTerminationQueryListener;
	
	public UnoConnection (UnoObjectPointer <XComponentContext> a_originalRemoteUnoObjectsContext, String a_unoConnectionIdentification, XBridge a_unoBridge, InitialUnoObjectsProvider a_initialUnoObjectsProvider, List <UnoConnectionEventsListener> a_eventsListeners) throws Exception {
		i_remoteUnoObjectsContext = new RemoteUnoObjectsContext (a_originalRemoteUnoObjectsContext, a_unoConnectionIdentification);
		i_remoteUnoObjectsContext.setUpForOfficeInstance ();
		i_unoBridge = (XComponent) a_unoBridge;
		i_initialUnoObjectsProvider = a_initialUnoObjectsProvider;
		i_eventsListeners = a_eventsListeners;
		i_unoBridge.addEventListener (this);
		if (i_eventsListeners != null) {
			for (UnoConnectionEventsListener l_eventsListener: i_eventsListeners){
				l_eventsListener.connected (this);
			}
		}
		// add local singletons Start
		i_remoteUnoObjectsContext.addLocalProperty (UnoObjectsContextPropertyNamesSet.c_unoConnectionSingleton_string, this);
		// add local singletons End
		UnoDesktop l_unoDesktop = (UnoDesktop) (i_remoteUnoObjectsContext.getLocalPropertyValue (UnoObjectsContextPropertyNamesSet.c_unoDesktopSingleton_string));
		if (l_unoDesktop != null) {
			i_officeTerminationQueryListener = new OfficeTerminationQueryListener ();
			l_unoDesktop.getUnderlyingUnoObject (). <XDesktop>getAddress (XDesktop.class).addTerminateListener (i_officeTerminationQueryListener);
		}
		else {
			i_officeTerminationQueryListener = null;
		}
	}
	
	@Override
	protected void finalize () {
	}
	
	public final RemoteUnoObjectsContext getRemoteUnoObjectsContext () {
		return i_remoteUnoObjectsContext;
	}
	
	public final void disconnect () {
		if (i_unoBridge != null) {
			try {
				if (i_officeTerminationQueryListener != null) {
					UnoDesktop l_unoDesktop = (UnoDesktop) (i_remoteUnoObjectsContext.getLocalPropertyValue (UnoObjectsContextPropertyNamesSet.c_unoDesktopSingleton_string));
					l_unoDesktop.getUnderlyingUnoObject (). <XDesktop>getAddress (XDesktop.class).removeTerminateListener (i_officeTerminationQueryListener);
				}
				i_unoBridge.dispose ();
			}
			catch (Exception l_exception) {
				Publisher.logErrorInformation (String.format ("### UnoConnection.disconnect error: %s.", l_exception.toString ()));
			}
		}
	}
	
	@Override
	public final void disposing (EventObject a_event) {
		if (i_eventsListeners != null) {
			for (UnoConnectionEventsListener l_eventsListener: i_eventsListeners) {
				l_eventsListener.disconnected (this);
			}
		}
		i_remoteUnoObjectsContext = null;
		i_unoBridge = null;
		i_initialUnoObjectsProvider = null;
		i_eventsListeners = null;
		i_officeTerminationQueryListener = null;
	}
}

