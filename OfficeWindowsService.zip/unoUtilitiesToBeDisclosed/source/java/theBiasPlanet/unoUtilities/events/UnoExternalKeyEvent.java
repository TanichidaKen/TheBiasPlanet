package theBiasPlanet.unoUtilities.events;

import theBiasPlanet.unoDatumTypes.unoExternalEventsHandling.events.XExternalKeyEvent;

public class UnoExternalKeyEvent extends UnoExternalEvent implements XExternalKeyEvent {
	protected int i_keyCode;
	protected int i_modificationCode;
	
	public UnoExternalKeyEvent (String a_eventTypeString, String a_eventSourceIdentification, String a_propertiesString, int a_keyCode, int a_modificationCode) {
		super (a_eventTypeString, a_eventSourceIdentification, a_propertiesString);
		i_keyCode = a_keyCode;
		i_modificationCode = a_modificationCode;
	}
	
	@Override
	public int getKeyCode () {
		return i_keyCode;
	}
	
	@Override
	public int getModificationCode () {
		return i_modificationCode;
	}
}

