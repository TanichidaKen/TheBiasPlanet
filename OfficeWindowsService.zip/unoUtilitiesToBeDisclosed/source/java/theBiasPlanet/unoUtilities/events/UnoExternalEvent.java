package theBiasPlanet.unoUtilities.events;

import theBiasPlanet.unoDatumTypes.unoExternalEventsHandling.events.XExternalEvent;
import theBiasPlanet.unoUtilities.unoComponentBases.UnoComponentBase;

public class UnoExternalEvent extends UnoComponentBase implements XExternalEvent {
	protected String i_eventTypeString;
	protected String i_eventSourceIdentification;
	protected String i_propertiesString;
	
	public UnoExternalEvent (String a_eventTypeString, String a_eventSourceIdentification, String a_propertiesString) {
		i_eventTypeString = a_eventTypeString;
		i_eventSourceIdentification = a_eventSourceIdentification;
		i_propertiesString = a_propertiesString;
	}
	
	@Override
	public String getEventTypeString () {
		return i_eventTypeString;
	}
	
	@Override
	public String getEventSourceIdentification () {
		return i_eventSourceIdentification;
	}
	
	@Override
	public String getPropertiesString () {
		return i_propertiesString;
	}
}

