package theBiasPlanet.unoUtilities.documents;

import com.sun.star.container.NoSuchElementException;
import com.sun.star.container.XNameAccess;
import com.sun.star.container.XNameContainer;
import com.sun.star.frame.XModel;
import com.sun.star.lang.WrappedTargetException;
import com.sun.star.style.XStyleFamiliesSupplier;
import com.sun.star.text.XPageCursor;
import com.sun.star.text.XText;
import com.sun.star.text.XTextCursor;
import com.sun.star.text.XTextDocument;
import com.sun.star.text.XTextFramesSupplier;
import com.sun.star.text.XTextSectionsSupplier;
import com.sun.star.text.XTextTablesSupplier;
import com.sun.star.text.XTextViewCursor;
import com.sun.star.text.XTextViewCursorSupplier;
import com.sun.star.uno.AnyConverter;
import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.*;
import theBiasPlanet.unoUtilities.displayElements.UnoDesktop;
import theBiasPlanet.unoUtilities.documents.UnoDocument;
import theBiasPlanet.unoUtilities.documentElements.UnoTextPage;
import theBiasPlanet.unoUtilities.pointers.UnoObjectPointer;
import theBiasPlanet.unoUtilities.unoObjectsContexts.RemoteUnoObjectsContext;

public class UnoTextDocument extends UnoDocument {
	private UnoObjectPointer <XTextViewCursor> i_unoTextViewCursor= null;
	private UnoObjectPointer <XText> i_unoText = null;
	
	public static UnoTextDocument createDocument (UnoDesktop a_unoDesktop, boolean a_unoDocumentIsHidden) throws Exception, com.sun.star.io.IOException {
		return new UnoTextDocument (a_unoDesktop.getRemoteUnoObjectsContext (), a_unoDesktop.loadUnoDocument (UnoSpecialFileUrlsConstantsGroup.c_writerNewDocument, null, a_unoDocumentIsHidden));
	}
	
	public static UnoTextDocument openFile (UnoDesktop a_unoDesktop, String a_fileUrl, String a_password, boolean a_unoDocumentIsHidden) throws Exception, com.sun.star.io.IOException {
		return new UnoTextDocument (a_unoDesktop.getRemoteUnoObjectsContext (), a_unoDesktop.loadUnoDocument (a_fileUrl, a_password, a_unoDocumentIsHidden));
	}
	
	public static UnoTextDocument getCurrentDocument (UnoDesktop a_unoDesktop) throws Exception {
		return new UnoTextDocument (a_unoDesktop.getRemoteUnoObjectsContext (), a_unoDesktop.getCurrentDocument ());
	}
	
	public UnoTextDocument (RemoteUnoObjectsContext a_remoteUnoObjectsContext, UnoObjectPointer <XModel> a_underlyingUnoObject) throws Exception {
		super (a_remoteUnoObjectsContext, a_underlyingUnoObject);
		if (i_underlyingUnoObject. <XTextDocument>getAddress (XTextDocument.class) == null) {
			throw new Exception (UnoMessagesConstantsGroup.c_isNotTextDocument);
		}
		i_unoTextViewCursor = new UnoObjectPointer <XTextViewCursor> (i_unoController. <XTextViewCursorSupplier>getAddress (XTextViewCursorSupplier.class).getViewCursor ());
		i_unoText = new UnoObjectPointer <XText> (i_underlyingUnoObject. <XTextDocument>getAddress (XTextDocument.class).getText ());
	}
	
	public UnoObjectPointer <XTextViewCursor> getUnoTextViewCursor () {
		return i_unoTextViewCursor;
	}
	
	public UnoObjectPointer <XTextCursor> getUnoTextCursor () {
		return new UnoObjectPointer <XTextCursor> (i_unoText.getAddress ().createTextCursor ());
	}
	
	public UnoObjectPointer <XNameContainer> getUnoPageStyles () {
		try {
			return new UnoObjectPointer <XNameContainer> ( (XNameContainer) AnyConverter.toObject (XNameContainer.class, i_underlyingUnoObject. <XStyleFamiliesSupplier>getAddress (XStyleFamiliesSupplier.class).getStyleFamilies ().getByName (UnoStylesFamiliesConstantsGroup.c_unoPageStylesFamily.c_name)));
		}
		catch (NoSuchElementException | WrappedTargetException l_exception) {
			// Impossible
			return null;
		}
	}
	
	// a_unoPageIndex: -1 -> the last page
	public UnoTextPage getUnoPage (int a_unoPageIndex) {
		boolean l_whetherUnoPageIsFound = false;
		if (a_unoPageIndex == GeneralConstantsConstantsGroup.c_unspecifiedInteger) {
			l_whetherUnoPageIsFound = i_unoTextViewCursor. <XPageCursor>getAddress (XPageCursor.class).jumpToLastPage ();
		}
		else {
			l_whetherUnoPageIsFound = i_unoTextViewCursor. <XPageCursor>getAddress (XPageCursor.class).jumpToPage ((short) (a_unoPageIndex + 1));
		}
		if (l_whetherUnoPageIsFound) {
			return new UnoTextPage (this, i_unoTextViewCursor);
		}
		else {
			return null;
		}
	}
	
	public UnoObjectPointer <XNameAccess> getUnoSections () {
		return new UnoObjectPointer <XNameAccess> (i_underlyingUnoObject. <XTextSectionsSupplier>getAddress (XTextSectionsSupplier.class).getTextSections ());
	}
	
	public UnoObjectPointer <XNameAccess> getUnoFrames () {
		return new UnoObjectPointer <XNameAccess> (i_underlyingUnoObject. <XTextFramesSupplier>getAddress (XTextFramesSupplier.class).getTextFrames ());
	}
	
	public UnoObjectPointer <XNameAccess> getUnoTables () {
		return new UnoObjectPointer <XNameAccess> (i_underlyingUnoObject. <XTextTablesSupplier>getAddress (XTextTablesSupplier.class).getTextTables ());
	}
	
	public boolean insertText (String a_text) {
		getUnoTextViewCursor ().getAddress ().gotoEnd (false);
		i_unoText.getAddress ().insertString (i_unoTextViewCursor.getAddress (), a_text, false);
		return true;
	}
}

