package theBiasPlanet.unoUtilities.fileConversionsHandling;

import java.util.ArrayList;
import com.sun.star.beans.PropertyValue;
import com.sun.star.beans.XPropertySet;
import com.sun.star.container.XIndexAccess;
import com.sun.star.container.XNamed;
import com.sun.star.frame.XModel;
import com.sun.star.frame.XStorable2;
import com.sun.star.frame.XSynchronousDispatch;
import com.sun.star.lang.XComponent;
import com.sun.star.sheet.XSpreadsheetDocument;
import com.sun.star.sheet.XSpreadsheets;
import com.sun.star.sheet.XSpreadsheets2;
import com.sun.star.uno.Any;
import com.sun.star.uno.AnyConverter;
import com.sun.star.uno.XInterface;
import com.sun.star.util.XCloseable;
import theBiasPlanet.coreUtilities.collectionsHandling.ListsFactory;
import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.coreUtilities.messagingHandling.Publisher;
import theBiasPlanet.unoUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.*;
import theBiasPlanet.unoUtilities.displayElements.UnoDesktop;
import theBiasPlanet.unoUtilities.documentsHandling.UnoDocumentTailor;
import theBiasPlanet.unoUtilities.pointers.UnoObjectPointer;
import theBiasPlanet.unoUtilities.propertiesHandling.UnoPropertiesHandler;
import theBiasPlanet.unoUtilities.unoDataHandling.UnoDatumConverter;
import theBiasPlanet.unoUtilities.unoObjectsContexts.RemoteUnoObjectsContext;

public class FilesConverter {
	private static final String c_csvFormatStringFormat = "%d,%d,%d,1,,0,%b,false,%b,%b,false"; // the CSV items delimiter character code (can be specified like 'Character.codePointAt ("\t", 0)'), the CSV text items quotation character code (can be specified like 'Character.codePointAt ("\"", 0)'), the encoding code (76 -> UTF-8, 65535 -> UCS-2, 65534 -> UCS-4, 11 -> US-ASCII, 69 -> EUC_JP, 64 -> SHIFT_JIS), whether all the text items are quoted, whether the contents are exported as shown, whether the formula themselves are exported
	private RemoteUnoObjectsContext i_remoteUnoObjectsContext = null;
	private UnoObjectPointer <XSynchronousDispatch> i_fileOpeningUnoDispatcher = null;
	
	public FilesConverter (UnoDesktop a_unoDesktop) throws Exception {
		i_remoteUnoObjectsContext = a_unoDesktop.getRemoteUnoObjectsContext ();
		i_fileOpeningUnoDispatcher = a_unoDesktop.getFileOpeningDispatcher ();
	}
	
	public RemoteUnoObjectsContext getRemoteUnoObjectsContext () {
		return i_remoteUnoObjectsContext;
	}
	
	public boolean convertFile (String a_originalFileUrl, String a_originalFilePassword, String a_targetFileUrl, PropertyValue [] a_unoDocumentStoringPropertiesArray, ArrayList <UnoDocumentTailor> a_unoDocumentTailors) throws Exception {
		com.sun.star.util.URL l_originalFileUrlInURL = UnoDatumConverter.getUrlInURL (a_originalFileUrl);
		PropertyValue [] l_unoDocumentOpeningPropertiesArray = UnoPropertiesHandler.buildPropertiesArray (UnoDocumentOpeningEnumerablePropertyNamesSet.c_instance.getValues (), ListsFactory. <Object>createArrayList (Boolean.valueOf (true), Boolean.valueOf (true), Boolean.valueOf (true), Boolean.valueOf (true), a_originalFilePassword != null ? a_originalFilePassword: ""));
		Any l_originalUnoDocumentInAny = (Any) i_fileOpeningUnoDispatcher.getAddress ().dispatchWithReturnValue (l_originalFileUrlInURL, l_unoDocumentOpeningPropertiesArray);
		boolean l_hasSucceeded = false;
		if (! (AnyConverter.isVoid (l_originalUnoDocumentInAny))) {
			UnoObjectPointer <XModel> l_originalUnoDocument = new UnoObjectPointer <XModel> ( (XComponent) l_originalUnoDocumentInAny.getObject (), XModel.class);
			try {
				if (a_unoDocumentTailors != null) {
					for (UnoDocumentTailor l_unoDocumentTailor: a_unoDocumentTailors) {
						l_unoDocumentTailor.tailor (l_originalUnoDocument);
					}
				}
				l_originalUnoDocument. <XStorable2>getAddress (XStorable2.class).storeToURL (a_targetFileUrl, a_unoDocumentStoringPropertiesArray);
				l_hasSucceeded = true;
			}
			catch (Exception l_exception) {
				throw l_exception;
			}
			l_originalUnoDocument. <XCloseable>getAddress (XCloseable.class).close (false); 
		}
		else {
			Publisher.logErrorInformation (String.format ("### The original file: '%s' cannot be opened.", a_originalFileUrl));
		}
		return l_hasSucceeded;
	}
	
	public static PropertyValue [] createToCsvFileDocumentStoringPropertiesArray (int a_itemsDelimiterCharacterCode, int a_textItemQuotationCharacterCode, int a_charactersEncodingCode, boolean a_whetherAllTextItemsAreQuoted, boolean a_whetherContentsAreExportedAsShown, boolean a_whetherFormulaThemselvesAreExported) {
		ArrayList <String> l_unoDocumentStoringPropertyNames = ListsFactory.<String>createArrayList (
			UnoDocumentStoringEnumerablePropertyNamesSet.c_filterName_string,
			UnoDocumentStoringEnumerablePropertyNamesSet.c_filterData_string,
			UnoDocumentStoringEnumerablePropertyNamesSet.c_overwrites_boolean
		);
		ArrayList <Object> l_unoDocumentStoringPropertyValues = ListsFactory.<Object>createArrayList (
			UnoDocumentStoringFilterNamesConstantsGroup.c_toCsvFileFilterName,
			String.format (c_csvFormatStringFormat, a_itemsDelimiterCharacterCode, a_textItemQuotationCharacterCode, a_charactersEncodingCode, a_whetherAllTextItemsAreQuoted, a_whetherContentsAreExportedAsShown, a_whetherFormulaThemselvesAreExported),
			Boolean.valueOf (true)
		);
		return UnoPropertiesHandler.buildPropertiesArray (l_unoDocumentStoringPropertyNames, l_unoDocumentStoringPropertyValues);
	}
	
	// a_targetFileNamingRule: 0 -> augmented by the sheet index, 1 -> augmented by the sheet name
	public boolean convertSpreadSheetsDocumentFileToCsvFiles (String a_originalFileUrl, String a_originalFilePassword, String a_targetFileUrlBase, PropertyValue [] a_unoDocumentStoringPropertiesArray, ArrayList <UnoDocumentTailor> a_unoDocumentTailors, int a_targetFileNamingRule, boolean a_hiddenSpreadSheetsAreWritten) throws Exception {
		com.sun.star.util.URL l_originalFileUrlInURL = UnoDatumConverter.getUrlInURL (a_originalFileUrl);
		PropertyValue [] l_unoDocumentOpeningPropertiesArray = UnoPropertiesHandler.buildPropertiesArray (UnoDocumentOpeningEnumerablePropertyNamesSet.c_instance.getValues (), ListsFactory. <Object>createArrayList (Boolean.valueOf (true), Boolean.valueOf (true), Boolean.valueOf (true), Boolean.valueOf (true), a_originalFilePassword != null ? a_originalFilePassword: ""));
		Any l_originalUnoDocumentInAny = (Any) i_fileOpeningUnoDispatcher.getAddress ().dispatchWithReturnValue (l_originalFileUrlInURL, l_unoDocumentOpeningPropertiesArray);
		boolean l_hasSucceeded = false;
		if (! (AnyConverter.isVoid (l_originalUnoDocumentInAny))) {
			UnoObjectPointer <XModel> l_originalUnoDocument = new UnoObjectPointer <XModel> ( (XComponent) l_originalUnoDocumentInAny.getObject (), XModel.class);
			try {
				if (a_unoDocumentTailors != null) {
					for (UnoDocumentTailor l_unoDocumentTailor: a_unoDocumentTailors) {
						l_unoDocumentTailor.tailor (l_originalUnoDocument);
					}
				}
				if (l_originalUnoDocument. <XSpreadsheetDocument>getAddress (XSpreadsheetDocument.class) == null) {
					Publisher.logErrorInformation ("The document is not any spread sheet.");
					return false;
				}
				else {
					UnoObjectPointer <XSpreadsheets2> l_spreadSheets = new UnoObjectPointer <XSpreadsheets2> ( (XSpreadsheets) l_originalUnoDocument. <XSpreadsheetDocument>getAddress (XSpreadsheetDocument.class).getSheets (), XSpreadsheets2.class);
					int l_numberOfSheets = l_spreadSheets. <XIndexAccess>getAddress (XIndexAccess.class).getCount ();
					UnoObjectPointer <XNamed> l_spreadSheet = null;
					String l_targetFileNameAugmentation = null;
					int l_lastPeriodPositionInTargetFileUrlBase = a_targetFileUrlBase.lastIndexOf (".");
					String l_augmentedTargetFileUrl = null;
					boolean l_whetherSheetIsVisible = false;
					for (int l_sheetIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber; l_sheetIndex < l_numberOfSheets; l_sheetIndex ++) {
						l_spreadSheet = new UnoObjectPointer <XNamed> ( (XInterface) ( ( (Any) l_spreadSheets. <XIndexAccess>getAddress (XIndexAccess.class).getByIndex (l_sheetIndex)).getObject ()), XNamed.class);
						if (a_hiddenSpreadSheetsAreWritten) {
						}
						else {
							l_whetherSheetIsVisible = ( (Boolean) l_spreadSheet. <XPropertySet>getAddress (XPropertySet.class).getPropertyValue (UnoSpreadSheetPropertyNamesSet.c_whetherIsVisible_boolean)).booleanValue (); 
							if (!l_whetherSheetIsVisible) {
								continue;
							}
						}
						if (a_targetFileNamingRule == 0) {
							l_targetFileNameAugmentation = String.format ("%d", l_sheetIndex);
						}
						else {
							l_targetFileNameAugmentation = l_spreadSheet.getAddress ().getName (); 
						}
						if (l_lastPeriodPositionInTargetFileUrlBase >= GeneralConstantsConstantsGroup.c_iterationStartNumber) {
							l_augmentedTargetFileUrl = String.format ("%s_%s%s", a_targetFileUrlBase.substring (GeneralConstantsConstantsGroup.c_iterationStartNumber, l_lastPeriodPositionInTargetFileUrlBase), l_targetFileNameAugmentation, a_targetFileUrlBase.substring (l_lastPeriodPositionInTargetFileUrlBase));
						}
						else {
							l_augmentedTargetFileUrl = String.format ("%s_%s", a_targetFileUrlBase, l_targetFileNameAugmentation);
						}
						if (l_sheetIndex != GeneralConstantsConstantsGroup.c_iterationStartNumber) {
							l_spreadSheets.getAddress ().moveByName (l_spreadSheet.getAddress ().getName (), (short) GeneralConstantsConstantsGroup.c_iterationStartNumber);
						}
						l_originalUnoDocument. <XStorable2>getAddress (XStorable2.class).storeToURL (l_augmentedTargetFileUrl, a_unoDocumentStoringPropertiesArray);
					}
					l_hasSucceeded = true;
				}
			}
			catch (Exception l_exception) {
				throw l_exception;
			}
			l_originalUnoDocument. <XCloseable>getAddress (XCloseable.class).close (false); 
		}
		else {
			Publisher.logErrorInformation (String.format ("### The original file: '%s' cannot be opened.", a_originalFileUrl));
		}
		return l_hasSucceeded;
	}
}

