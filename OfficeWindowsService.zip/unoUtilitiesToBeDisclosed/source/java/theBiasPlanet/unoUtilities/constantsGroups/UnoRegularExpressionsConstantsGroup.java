package theBiasPlanet.unoUtilities.constantsGroups;

import java.util.regex.Pattern;

public interface UnoRegularExpressionsConstantsGroup {
	Pattern c_urlRegularExpression = Pattern.compile ("(.*:)(.*)");
	Pattern c_cellPositionExpressionRegularExpression = Pattern.compile ("(\\$.+\\.)?\\$([A-Z]+)\\$([0-9]+)");
	Pattern c_cellsRectangleExpressionRegularExpression = Pattern.compile ("(\\$.+\\.)?\\$([A-Z]+)\\$([0-9]+)(:\\$([A-Z]+)\\$([0-9]+))?");
}

