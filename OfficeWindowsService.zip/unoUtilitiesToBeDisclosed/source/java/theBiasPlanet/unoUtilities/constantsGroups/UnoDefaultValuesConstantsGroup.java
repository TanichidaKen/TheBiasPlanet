package theBiasPlanet.unoUtilities.constantsGroups;

public interface UnoDefaultValuesConstantsGroup {
	String c_customDefaultStyleName = "CustomDefault";
	String c_initiallyOfferedUnoObjectName = "theBiasPlanet.UnoObjectsContext";
}

