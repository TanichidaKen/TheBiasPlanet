package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

public interface UnoSpreadSheetCellPropertyNamesSet extends UnoPropertyNamesSet {
	String c_numberFormat = "NumberFormat";
	String c_backgroundColor = "CellBackColor";
	String c_backgroundIsTransparent = "IsCellBackgroundTransparent";
	String c_foregroundColor = "CharColor";
	String c_fontName = "CharFontName";
	String c_fontSize = "CharHeight";
	String c_fontPosture = "CharPosture";
	String c_fontWeight = "CharWeight";
	String c_underLineStyle = "CharUnderline";
	String c_underLineColor = "CharUnderlineColor";
	String c_underLineHasColor = "CharUnderlineHasColor";
	String c_overLineStyle = "CharOverline";
	String c_overLineColor = "CharOverlineColor";
	String c_overLineHasColor = "CharOverlineHasColor";
	String c_strikeOutStyle = "CharStrikeout";
	String c_wrappedFlag = "IsTextWrapped";
	String c_horizontalAlignmentStyle = "HoriJustify";
	String c_verticalAlignmentStyle = "VertJustify";
	String c_leftBorderStyle = "LeftBorder2";
	String c_rightBorderStyle = "RightBorder2";
	String c_topBorderStyle = "TopBorder2";
	String c_bottomBorderStyle = "BottomBorder2";
	String c_absoluteName = "AbsoluteName";
}

