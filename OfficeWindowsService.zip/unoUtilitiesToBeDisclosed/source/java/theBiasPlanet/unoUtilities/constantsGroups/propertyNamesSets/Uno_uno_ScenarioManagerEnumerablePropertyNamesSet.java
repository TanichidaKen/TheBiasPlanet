package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_ScenarioManagerEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_scenarioName_string = "Name";
	public static final String c_scenarioComment_string = "Comment";
	public static final Uno_uno_ScenarioManagerEnumerablePropertyNamesSet c_instance = new Uno_uno_ScenarioManagerEnumerablePropertyNamesSet ();
	
	private Uno_uno_ScenarioManagerEnumerablePropertyNamesSet () {
	}
}

