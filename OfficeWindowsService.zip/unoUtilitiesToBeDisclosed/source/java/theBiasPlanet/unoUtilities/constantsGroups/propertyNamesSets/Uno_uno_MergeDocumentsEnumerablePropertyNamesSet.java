package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_MergeDocumentsEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_url_string = "URL";
	public static final String c_version_short = "Version";
	public static final Uno_uno_MergeDocumentsEnumerablePropertyNamesSet c_instance = new Uno_uno_MergeDocumentsEnumerablePropertyNamesSet ();
	
	private Uno_uno_MergeDocumentsEnumerablePropertyNamesSet () {
	}
}

