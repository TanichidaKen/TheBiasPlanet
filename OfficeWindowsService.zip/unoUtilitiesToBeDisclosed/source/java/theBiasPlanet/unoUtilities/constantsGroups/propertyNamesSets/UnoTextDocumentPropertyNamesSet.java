package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

public interface UnoTextDocumentPropertyNamesSet extends UnoPropertyNamesSet {
	String c_pageStyle = "PageStyle";
}

