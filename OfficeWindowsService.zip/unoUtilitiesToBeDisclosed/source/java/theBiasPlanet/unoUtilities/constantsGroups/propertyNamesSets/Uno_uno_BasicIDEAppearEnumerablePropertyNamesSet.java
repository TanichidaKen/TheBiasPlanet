package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_BasicIDEAppearEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_documentName_string = "Document";
	public static final String c_libraryName_string = "LibName";
	public static final String c_itemName_string = "Name";
	public static final String c_itemTypeName_string = "Type";
	public static final String c_lineNumber_long = "Line";
	public static final String c_column1Number_short = "Column1";
	public static final String c_column2Number_short = "Column2";
	public static final Uno_uno_BasicIDEAppearEnumerablePropertyNamesSet c_instance = new Uno_uno_BasicIDEAppearEnumerablePropertyNamesSet ();
	
	private Uno_uno_BasicIDEAppearEnumerablePropertyNamesSet () {
	}
}

