#ifndef __theBiasPlanet_unoUtilities_constantsGroups_propertyNamesSets_UnoDocumentStoringEnumerablePropertyNamesSet_hpp__
	#define __theBiasPlanet_unoUtilities_constantsGroups_propertyNamesSets_UnoDocumentStoringEnumerablePropertyNamesSet_hpp__
	
	#include "theBiasPlanet/coreUtilities/constantsGroups/BaseEnumerableConstantsGroup.hpp"
	#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/UnoPropertyNamesSet.hpp"
	#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::theBiasPlanet::coreUtilities::constantsGroups;
	
	namespace theBiasPlanet {
		namespace unoUtilities {
			namespace constantsGroups {
				namespace propertyNamesSets {
					class __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ UnoDocumentStoringEnumerablePropertyNamesSet : public BaseEnumerableConstantsGroup <string>, public UnoPropertyNamesSet {
						private:
							UnoDocumentStoringEnumerablePropertyNamesSet ();
						public:
							static string const c_filterName_String;
							static string const c_filterData_Object; // a sequence of parameter name-value sets
							static string const c_isTemplate_Boolean;
							static string const c_authorName_String;
							static string const c_title_String;
							static string const c_password_String;
							static string const c_charactersSet_String;
							static string const c_version_Short;
							static string const c_description_String;
							static string const c_overwrites_Boolen;
							static string const c_documentTypeSpecificData_Object;
							static UnoDocumentStoringEnumerablePropertyNamesSet const c_instance;
					};
				}
			}
		}
	}
#endif

