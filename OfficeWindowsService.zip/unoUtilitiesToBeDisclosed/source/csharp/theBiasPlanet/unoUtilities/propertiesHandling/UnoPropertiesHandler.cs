namespace theBiasPlanet {
	namespace unoUtilities {
		namespace propertiesHandling {
			using System;
			using System.Collections.Generic;
			using uno;
			using unoidl.com.sun.star.beans;
			using theBiasPlanet.coreUtilities.constantsGroups;
			using theBiasPlanet.unoUtilities.property;
			
			public class UnoPropertiesHandler {
				public static PropertyValue [] buildPropertiesArray (List <String> a_propertyNames, List <Object> a_propertyValues) {
					if (a_propertyNames == null || a_propertyValues == null) {
						return null;
					}
					else {
						PropertyValue [] l_propertiesArray = new PropertyValue [a_propertyNames.Count];
						int l_propertyIndex = GeneralConstantsConstantsGroup.c_iterationStartingNumber;
						Object l_propertyValue = null;
						foreach (String l_propertyName in a_propertyNames) {
							l_propertyValue = a_propertyValues [l_propertyIndex];
							l_propertiesArray [l_propertyIndex] = new UnoProperty (l_propertyName, new Any (l_propertyValue.GetType (), l_propertyValue));
							l_propertyIndex ++;
						}
						return l_propertiesArray;
					}
				}
			}
		}
	}
}

