namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			namespace propertyNamesSets {
				using System;
				using theBiasPlanet.coreUtilities.constantsGroups;
				
				public class UnoDispatchCommandsCommonArgumentEnumerablePropertyNamesSet : BaseEnumerableConstantsGroup <String>, UnoPropertyNamesSet  {
					public const String c_synchronousMode_Boolean = "SynchronMode";
					public static readonly UnoDispatchCommandsCommonArgumentEnumerablePropertyNamesSet c_instance = new UnoDispatchCommandsCommonArgumentEnumerablePropertyNamesSet ();
					
					private UnoDispatchCommandsCommonArgumentEnumerablePropertyNamesSet () {
					}
				}
			}
		}
	}
}

