namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			namespace propertyNamesSets {
				using System;
				using theBiasPlanet.coreUtilities.constantsGroups;
				
				public class Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet : BaseEnumerableConstantsGroup <String>, UnoPropertyNamesSet {
					public const String c_styleName_String = "Param";
					public const String c_styleFamilyKey_Short = "Family";
					public static readonly Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet c_instance = new Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet ();
					
					private Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet () {
					}
				}
			}
		}
	}
}

