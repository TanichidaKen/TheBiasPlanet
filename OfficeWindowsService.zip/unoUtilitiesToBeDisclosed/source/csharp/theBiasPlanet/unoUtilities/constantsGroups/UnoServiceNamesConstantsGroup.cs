namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			using System;
			
			public static class UnoServiceNamesConstantsGroup {
				public const String c_com_sun_star_frame_Desktop = "com.sun.star.frame.Desktop";
				public const String c_com_sun_star_frame_DispatchHelper = "com.sun.star.frame.DispatchHelper";
				public const String c_com_sun_star_xml_crypto_SecurityEnvironment = "com.sun.star.xml.crypto.SecurityEnvironment";
				public const String c_com_sun_star_bridge_BridgeFactory = "com.sun.star.bridge.BridgeFactory";
				public const String c_com_sun_star_connection_Connector = "com.sun.star.connection.Connector";
				public const String c_com_sun_star_connection_Acceptor = "com.sun.star.connection.Acceptor";
				public const String c_com_sun_star_util_URLTransformer = "com.sun.star.util.URLTransformer";
			}
		}
	}
}

