namespace theBiasPlanet {
	namespace unoUtilities {
		namespace dispatching {
			using System;
			using System.Collections.Generic;
			using System.Text;
			using unoidl.com.sun.star.frame;
			using theBiasPlanet.unoUtilities.unoDataHandling;
			
			public class UnoDispatchResult {
				private short i_finalStatus;
				private Object i_dispatchResult;
				private List <Object> i_relatedInformation;
				
				public UnoDispatchResult () {
					i_finalStatus = DispatchResultState.FAILURE;
					i_dispatchResult = null;
					i_relatedInformation = new List <Object> ();
				}
				
				public Object getDispatchResult () {
					return i_dispatchResult;
				}
				
				public void setDispatchResult (DispatchResultEvent a_dispatchResultEvent) {
					if (a_dispatchResultEvent != null) {
						i_finalStatus = a_dispatchResultEvent.State;
						i_dispatchResult = UnoDatumConverter.getObject (a_dispatchResultEvent.Result);
					}
					else {
						i_dispatchResult = null;
					}
				}
				
				public List <Object> getRelatedInformation () {
					return i_relatedInformation;
				}
				
				public void addRelatedInformationPiece (FeatureStateEvent a_featureStateEvent) {
					if (a_featureStateEvent != null) {
						if (a_featureStateEvent.State.hasValue ()) {
							i_relatedInformation.Add (UnoDatumConverter.getObject (a_featureStateEvent.State));
						}
						else {
							i_relatedInformation.Add (null);
						}
					}
					else {
						i_relatedInformation.Add (null);
					}
				}
				
				public String toString () {
					StringBuilder l_stringBuilder = new StringBuilder ();
					l_stringBuilder.Append ("State = ");
					l_stringBuilder.Append (String.Format ("{0}", i_finalStatus));
					l_stringBuilder.Append (", Result = ");
					if (i_dispatchResult != null) {
						l_stringBuilder.Append (i_dispatchResult.ToString ());
					}
					else {
						l_stringBuilder.Append ("null");
					}
					l_stringBuilder.Append (", Related information = ");
					bool l_isInFirstIterationOfRelatedInformationPieces = true;
					foreach (Object l_relatedInformationPiece in i_relatedInformation) {
						if (!l_isInFirstIterationOfRelatedInformationPieces) {
							l_stringBuilder.Append (", ");
						}
						else {
							l_isInFirstIterationOfRelatedInformationPieces = false;
						}
						if (l_relatedInformationPiece != null) {
							l_stringBuilder.Append (l_relatedInformationPiece.GetType ().ToString ());
							l_stringBuilder.Append (": ");
							if (l_relatedInformationPiece.GetType ().IsArray) {
								Array l_relatedInformationPieceInArray = (Array) l_relatedInformationPiece;
								l_stringBuilder.Append ("[");
								int l_numberOfRelatedInformationPieceElements = l_relatedInformationPieceInArray.Length;
								Object l_relatedInformationPieceElement = null;
								for (int l_relatedInformationPieceElementIndex = 0; l_relatedInformationPieceElementIndex < l_numberOfRelatedInformationPieceElements ; l_relatedInformationPieceElementIndex ++) {
									if (l_relatedInformationPieceElementIndex == 0) {
									}	
									else {
										l_stringBuilder.Append (", ");
									}
									l_relatedInformationPieceElement = l_relatedInformationPieceInArray.GetValue (l_relatedInformationPieceElementIndex); 
									l_stringBuilder.Append (l_relatedInformationPieceElement.ToString ());
								}
								l_stringBuilder.Append ("]");
							}
							else {
								l_stringBuilder.Append (l_relatedInformationPiece.ToString ());
							}
						}
						else {
							l_stringBuilder.Append ("null");
						}
					}
					return l_stringBuilder.ToString ();
				}
			}
		}
	}
}

