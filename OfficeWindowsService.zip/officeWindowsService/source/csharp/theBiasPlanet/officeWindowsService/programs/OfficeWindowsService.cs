namespace theBiasPlanet {
	namespace officeWindowsService {
		namespace programs {
			using System;
			using System.Collections.Generic;
			using System.Diagnostics;
			using System.ServiceProcess;
			using System.Threading;
			using theBiasPlanet.coreUtilities.collectionsHandling;
			using theBiasPlanet.coreUtilities.constantsGroups;
			using theBiasPlanet.coreUtilities.messaging;
			using theBiasPlanet.coreUtilities.processesHandling;
			using theBiasPlanet.coreUtilities.programsHandling;
			using theBiasPlanet.unoUtilities.connectionsHandling;
			using theBiasPlanet.unoUtilities.officeInstancesHandling;
			using theBiasPlanet.unoUtilities.programsHandling;
			
			// Register this Windows service by this command.
			// sc create OfficeWindowsService start={auto | demand} binpath="%path% %the office directory path% %the connection URL%" obj=%the computer name%\%the user name% password=%the user password%
			public sealed class OfficeWindowsService : ServiceBase {
				private List <String> c_officeProgramCommandAndArguments = ListsFactory.createList <String> ("soffice", "--headless", "--norestore");
				//List <String> c_officeProgramCommandAndArguments = ListsFactory.createList <String> ("soffice", "--display", ":0.0");
				private int c_connectTryingTimes = 20;
				private int c_connectTryingIntervalInMilliseconds = 5000;
				private UnoConnection i_unoConnection;
				private OfficeInstance i_officeInstance;
				private String i_officeProgramDirectoryPath;
				private String i_unoServerUrl;
				
				public static void Main (String [] a_argumentsArray) {
					OfficeWindowsService l_officeWindowsService = new OfficeWindowsService (a_argumentsArray);
					if (Environment.UserInteractive) {
						l_officeWindowsService.OnStart (new String [] {}); 
						Console.Out.WriteLine ("### Press any key to stop this Windows service.");
						Console.Read ();
						l_officeWindowsService.OnStop ();
						Environment.Exit (0);
					}
					else {
						Run (l_officeWindowsService);
					}
				}
			
				public OfficeWindowsService (String [] a_argumentsArray) {
					ServiceName = "OfficeWindowsService";
					if (a_argumentsArray.Length != 2) {
						throw new Exception ("The arguments have to be these.\nThe argument 1: the office program directory path\nThe argument 2: the server url like 'socket,host=localhost,port=2002,tcpNoDelay=1;urp;StarOffice.ComponentContext'");
					}
					i_officeProgramDirectoryPath = a_argumentsArray [0];
					i_unoServerUrl = a_argumentsArray [1];
				}
				
				~OfficeWindowsService () {
				}
				
				protected override void OnStart (String [] a_argumentsArray) {
					base.OnStart (a_argumentsArray);
					EventLog.WriteEntry ("The service is starting up.", EventLogEntryType.Information);
					try {
						Publisher.setLoggingLevel (3);
						int l_childProcessInvokingResult = ProcessHandler.execute (i_officeProgramDirectoryPath, c_officeProgramCommandAndArguments, false);
						if (l_childProcessInvokingResult == 0) {
							UnoProcessEnvironment l_localUnoProcessEnvironment = new UnoProcessEnvironment (DateTime.Now.ToString ("yyyy-MM-dd HH:mm:ss"), null);
							ProcessEnvironment.windowsSocketStartup ();
							UnoConnectionConnector l_unoConnectionConnector = new UnoConnectionConnector (l_localUnoProcessEnvironment.getLocalObjectsContext ());
							for (int l_connectTryingIndex = GeneralConstantsConstantsGroup.c_iterationStartingNumber; l_connectTryingIndex < c_connectTryingTimes; l_connectTryingIndex ++) {
								Thread.Sleep ( c_connectTryingIntervalInMilliseconds);
								try {
									i_unoConnection = l_unoConnectionConnector.connect (i_unoServerUrl, null);
									break;
								}
								catch (unoidl.com.sun.star.uno.Exception l_exception) {
									if ((l_connectTryingIndex + 1) >= c_connectTryingTimes) {
										throw l_exception;
									}
								}
							}
							i_officeInstance = new OfficeInstance (i_unoConnection.getRemoteObjectsContext ());
						}
						else {
							throw new Exception ("Any office instance cannot be created.");
						}
					}
					catch (unoidl.com.sun.star.uno.Exception l_exception) {
						Publisher.logErrorInformation (l_exception.Message);
						throw l_exception;
					}
					catch (Exception l_exception) {
						Publisher.logErrorInformation (l_exception);
						throw l_exception;
					}
					EventLog.WriteEntry ("The service has successfully started up.", EventLogEntryType.Information);
				}
				
				protected override void OnStop () {
					i_officeInstance.shutDown ();
					i_unoConnection.disconnect ();
					ProcessEnvironment.windowsSocketCleanup ();
					EventLog.WriteEntry ("The service has successfully shut down.", EventLogEntryType.Information);
					base.OnStop ();
				}
			}
		}
	}
}

