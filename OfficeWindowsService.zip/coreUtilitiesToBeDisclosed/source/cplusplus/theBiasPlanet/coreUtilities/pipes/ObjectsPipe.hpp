#ifndef __theBiasPlanet_coreUtilities_pipes_ObjectsPipe_hpp__
	#define __theBiasPlanet_coreUtilities_pipes_ObjectsPipe_hpp__
	
	#include <condition_variable>
	#include <list>
	#include <mutex>
	#include <optional>
	#include "theBiasPlanet/coreUtilities/constantsGroups/GeneralConstantsConstantsGroup.hpp"
	
	using namespace ::std;
	using namespace ::theBiasPlanet::coreUtilities::constantsGroups;
	
	namespace theBiasPlanet {
		namespace coreUtilities {
			namespace pipes {
				template <typename T> class ObjectsPipe {
					protected:
						recursive_mutex i_mutex;
						condition_variable_any i_threadCondition;
						T * i_objects;
						int i_bufferSize = 0;
						// No data: i_dataStartIndex == GeneralConstantsConstantsGroup.c_iterationStartNumber && i_dataUntilIndex == GeneralConstantsConstantsGroup.c_iterationStartNumber
						int i_dataStartIndex = GeneralConstantsConstantsGroup::c_iterationStartNumber;
						int i_dataUntilIndex = GeneralConstantsConstantsGroup::c_iterationStartNumber;
						bool i_isFinishedWriting = false;
						bool i_isFinishedReading = false;
						bool i_notificationIsDelayed = false;
						virtual bool isEmptyWithoutLocking ();
						virtual bool isFullWithoutLocking ();
						// a_timeOutPeriodInMilliseconds: -1 -> waits indefinitely, 0 -> not wait
						virtual void writeWithoutLocking (T const & a_object, unique_lock <recursive_mutex> * a_lock, long const & a_timeOutPeriodInMilliseconds = -1);
						// a_timeOutPeriodInMilliseconds: -1 -> waits indefinitely, 0 -> not wait
						virtual T readWithoutLocking (unique_lock <recursive_mutex> * a_lock, long const & a_timeOutPeriodInMilliseconds = -1);
					public:
						ObjectsPipe (int const & a_bufferSize, bool const & a_notificationIsDelayed);
						virtual ~ObjectsPipe ();
						virtual bool isEmpty ();
						virtual bool isFull ();
						// a_timeOutPeriodInMilliseconds: -1 -> waits indefinitely, 0 -> not wait
						virtual void write (T const & a_object, long const & a_timeOutPeriodInMilliseconds = -1);
						// a_timeOutPeriodInMilliseconds: -1 -> waits indefinitely, 0 -> not wait
						virtual int write (T const * const a_objects, int const & a_offset, int const & a_length, long const & a_timeOutPeriodInMilliseconds = 0);
						// a_timeOutPeriodInMilliseconds: -1 -> waits indefinitely, 0 -> not wait
						virtual T read (long const & a_timeOutPeriodInMilliseconds = -1);
						// a_timeOutPeriodInMilliseconds: -1 -> waits indefinitely, 0 -> not wait
						virtual int read (T * const a_objects, int const & a_offset, int const & a_length, long const & a_timeOutPeriodInMilliseconds = -1);
						virtual list <T> readWholeData ();
						virtual void finishWriting ();
						virtual void finishReading ();
						virtual void reset ();
				};
			}
		}
	}
#endif

