#ifndef __theBiasPlanet_coreUtilities_jsonDataHandling_UnsupportedValueException_hpp__
	#define __theBiasPlanet_coreUtilities_jsonDataHandling_UnsupportedValueException_hpp__
	
	#include <exception>
	#include <string>
	#include "theBiasPlanet/coreUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	
	namespace theBiasPlanet {
		namespace coreUtilities {
			namespace jsonDataHandling {
				class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ UnsupportedValueException : public exception {
					private:
						string i_message;
					public:
						UnsupportedValueException (string a_message);
						virtual ~UnsupportedValueException ();
						virtual char const * what () const throw () override;
				};
			}
		}
	}
#endif

