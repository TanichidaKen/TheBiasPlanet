#ifndef __theBiasPlanet_coreUtilities_jsonDataHandling_TerminatedException_hpp__
	#define __theBiasPlanet_coreUtilities_jsonDataHandling_TerminatedException_hpp__
	
	#include <exception>
	#include <string>
	#include "theBiasPlanet/coreUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	
	namespace theBiasPlanet {
		namespace coreUtilities {
			namespace jsonDataHandling {
				class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ TerminatedException : public exception {
					private:
						string i_message;
					public:
						TerminatedException (string a_message);
						virtual ~TerminatedException ();
						virtual char const * what () const throw () override;
				};
			}
		}
	}
#endif

