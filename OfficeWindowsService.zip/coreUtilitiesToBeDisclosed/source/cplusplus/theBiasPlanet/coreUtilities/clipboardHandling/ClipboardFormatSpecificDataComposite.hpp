#ifndef __theBiasPlanet_coreUtilities_clipboardHandling_ClipboardFormatSpecificDataComposite_hpp__
	#define __theBiasPlanet_coreUtilities_clipboardHandling_ClipboardFormatSpecificDataComposite_hpp__
	
	#include <list>
	#include <string>
	#include "theBiasPlanet/coreUtilities/clipboardHandling/ClipboardFormatSpecificDatum.hpp"
	#include "theBiasPlanet/coreUtilities/collections/NavigableLinkedMap.hpp"
	#include "theBiasPlanet/coreUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::theBiasPlanet::coreUtilities::collections;
	
	namespace theBiasPlanet {
		namespace coreUtilities {
			namespace clipboardHandling {
				class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ ClipboardFormatSpecificDataComposite {
					private:
						NavigableLinkedMap <::std::string const, ClipboardFormatSpecificDatum const *> i_formatNameToDatumMap;
					public:
						ClipboardFormatSpecificDataComposite ();
						virtual ~ClipboardFormatSpecificDataComposite ();
						ClipboardFormatSpecificDataComposite (ClipboardFormatSpecificDataComposite const & a_copiedObject) = delete; // because the data are not meant to be shared by multiple instances
						virtual ClipboardFormatSpecificDataComposite & operator = (ClipboardFormatSpecificDataComposite const & a_assignedFromObject) = delete; // because the data are not meant to be shared by multiple instances
						virtual bool addFormatSpecificDatum (ClipboardFormatSpecificDatum const * const a_formatSpecificDatum);
						virtual ::std::list <::std::string> getFormatNames () const;
						virtual ClipboardFormatSpecificDatum const * const getFormatSpecificDatum (::std::string const & a_formatName) const;
				};
			}
		}
	}
#endif

