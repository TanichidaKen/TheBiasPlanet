from datetime import datetime

class PerformanceMeasurer:
	s_startTime: datetime
	
	@staticmethod
	def setStartTime () -> None:
		PerformanceMeasurer.s_startTime = datetime.now ()
	
	@staticmethod
	def getElapseTimeInNanoSeconds () -> int:
		return int ((datetime.now () - PerformanceMeasurer.s_startTime).total_seconds () * 1000000000)
	
	@staticmethod
	def getElapseTimeInMicroSeconds () -> int:
		return int ((datetime.now () - PerformanceMeasurer.s_startTime).total_seconds () * 1000000)

