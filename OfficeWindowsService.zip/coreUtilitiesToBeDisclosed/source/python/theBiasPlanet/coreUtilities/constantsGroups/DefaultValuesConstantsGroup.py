
class DefaultValuesConstantsGroup:
	c_smallBufferSize: int = 1024
	c_largeBufferSize: int = 102400
	c_smallestBufferSize: int = 1
	c_saxParserModuleName: str = "xml.sax.expatreader"

