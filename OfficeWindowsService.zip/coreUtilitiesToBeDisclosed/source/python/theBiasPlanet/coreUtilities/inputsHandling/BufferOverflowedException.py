
class BufferOverflowedException (Exception):
	def __init__ (a_this: "BufferOverflowedException", a_message: str) -> None:
		
		super ().__init__ (a_message)

