
class JsonParsingTerminatedException (Exception):
	def __init__ (a_this: "JsonParsingTerminatedException", a_message: str) -> None:
		
		super ().__init__ (a_message)

