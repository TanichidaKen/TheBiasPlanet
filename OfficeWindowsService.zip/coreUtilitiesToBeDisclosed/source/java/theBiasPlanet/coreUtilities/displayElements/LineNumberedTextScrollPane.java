package theBiasPlanet.coreUtilities.displayElements;

import javax.swing.JScrollPane;
import javax.swing.text.JTextComponent;

public class LineNumberedTextScrollPane extends JScrollPane {
	public LineNumberedTextScrollPane (JTextComponent a_textComponent, int a_verticalScrollBarPolicy, int a_horizontalScrollBarPolicy) {
		super (a_textComponent, a_verticalScrollBarPolicy, a_horizontalScrollBarPolicy);
		initialize (a_textComponent);
	}
	
	public LineNumberedTextScrollPane (JTextComponent a_textComponent) {
		super (a_textComponent);
		initialize (a_textComponent);
	}
	
	@Override
	protected void finalize () {
	}
	
	private void initialize (JTextComponent a_textComponent) {
		setViewportView (a_textComponent);
		setVerticalScrollBarPolicy (JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		TextLineNumbersPanel l_textLineNumbersPanel = new TextLineNumbersPanel (a_textComponent);
		setRowHeaderView (l_textLineNumbersPanel);
	}
}

