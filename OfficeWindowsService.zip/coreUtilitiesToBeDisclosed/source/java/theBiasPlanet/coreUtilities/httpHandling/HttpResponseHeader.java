package theBiasPlanet.coreUtilities.httpHandling;

import theBiasPlanet.coreUtilities.constantsGroups.CharactersSetNamesConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.InputPropertiesConstantsGroup;

public class HttpResponseHeader {
	private static final String c_defaultCharactersSet = CharactersSetNamesConstantsGroup.c_utf8CharactersSetName;
	private String i_contentsType = null;
	private String i_charactersSet = c_defaultCharactersSet;
	private String i_transferEncoding = null;
	private int i_contentsLength = InputPropertiesConstantsGroup.c_lengthNotSet;
	private String i_contentsEncoding = null;
	
	public HttpResponseHeader () {
	}
	
	public String getContentsType () {
		return i_contentsType;
	}
	
	public void setContentsType (String a_contentsType) {
		i_contentsType = a_contentsType;
	}
	
	public String getCharactersSet () {
		return i_charactersSet;
	}
	
	public void setCharactersSet (String a_charactersSet) {
		i_charactersSet = a_charactersSet;
	}
	
	public String getTransferEncoding () {
		return i_transferEncoding;
	}
	
	public void setTransferEncoding (String a_transferEncoding) {
		i_transferEncoding = a_transferEncoding;
	}
	
	public int getContentsLength () {
		return i_contentsLength;
	}
	
	public void setContentsLength (int a_contentsLength) {
		i_contentsLength = a_contentsLength;
	}
	
	public String getContentsEncoding () {
		return i_contentsEncoding;
	}
	
	public void setContentsEncoding (String a_contentsEncoding) {
		i_contentsEncoding = a_contentsEncoding;
	}
	
	public String toString () {
		return String.format ("%s %s %s %d %s", i_contentsType, i_charactersSet, i_transferEncoding, i_contentsLength, i_contentsEncoding);
	}
}

