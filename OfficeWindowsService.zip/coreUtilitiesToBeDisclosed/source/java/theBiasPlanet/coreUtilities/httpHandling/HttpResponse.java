package theBiasPlanet.coreUtilities.httpHandling;

import java.io.Reader;

public class HttpResponse {
	private HttpResponseStatus i_status = null;
	private HttpResponseHeader i_header = null;
	private Reader i_bodyReader = null;
	
	public HttpResponse (HttpResponseStatus a_status, HttpResponseHeader a_header, Reader a_bodyReader) {
		i_status = a_status;
		i_header = a_header;
		i_bodyReader = a_bodyReader;
	}
	
	public HttpResponseStatus getStatus () {
		return i_status;
	}
	
	public void setStatus (HttpResponseStatus a_status) {
		i_status = a_status;
	}
	
	public HttpResponseHeader getHeader () {
		return i_header;
	}
	
	public void setHeader (HttpResponseHeader a_header) {
		i_header = a_header;
	}
	
	public Reader getBodyReader () {
		return i_bodyReader;
	}
	
	public void setBodyReader (Reader a_bodyReader) {
		i_bodyReader = a_bodyReader;
	}
}

