package theBiasPlanet.coreUtilities.jsonDataHandling;

public class JsonDatumItemUnsupportedValueException extends Exception {
	public JsonDatumItemUnsupportedValueException (String a_message) {
		super (a_message);
	}
}

