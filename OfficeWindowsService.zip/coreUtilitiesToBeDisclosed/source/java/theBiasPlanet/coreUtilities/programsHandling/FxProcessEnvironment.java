package theBiasPlanet.coreUtilities.programsHandling;

import java.io.FileNotFoundException;
import java.io.IOException;
import javafx.stage.Stage;

public class FxProcessEnvironment extends ProcessEnvironment{
	public static FxProcessEnvironment s_currentEnvironment;
	protected Stage i_mainStage;
	
	public FxProcessEnvironment (String a_identification, String a_propertyFileUrl) throws FileNotFoundException, IOException {
		super (a_identification, a_propertyFileUrl);
		i_mainStage = null;
		s_currentEnvironment = this;
	}
	
	public final Stage getMainStage () {
		return i_mainStage;
	}
	
	public final void setMainStage (Stage a_mainStage) {
		i_mainStage = a_mainStage;
	}
}

