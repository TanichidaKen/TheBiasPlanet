package theBiasPlanet.coreUtilities.constantsGroups;

public interface OperatingSystemEnvironmentVariableNamesConstantsGroup {
	String c_path = "PATH";
}

