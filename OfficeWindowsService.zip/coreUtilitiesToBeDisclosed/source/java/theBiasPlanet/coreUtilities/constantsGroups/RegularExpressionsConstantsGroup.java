package theBiasPlanet.coreUtilities.constantsGroups;

import java.util.regex.Pattern;

public interface RegularExpressionsConstantsGroup {
	Pattern c_cProgramTraceLineRegularExpression = Pattern.compile ("(#.*: )(.*)\\((.*)\\+0x(.*)\\) \\[(.*)\\] (.*)");
	// nm is the name of a command
	Pattern c_nmOutputLineRegularExpression = Pattern.compile ("(.*) (.*) (.*)");
	// addr2line is the name of a command
	Pattern c_addr2lineOutputSecondLineRegularExpression = Pattern.compile ("(.*):(.*)");
	Pattern c_numbersRegularExpression = Pattern.compile ("^(\\d*|\\d{1,3}(,\\d{3})*)(\\.\\d+)?([eE][-+]?\\d+)?$"); // This is used for JSON parsing: "(-?(?:0|[1-9]\\d*))(\\.\\d+)?([eE][-+]?\\d+)?"
	Pattern c_dateAndTimesRegularExpression = Pattern.compile ("(\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2})(.\\d*)?");
	Pattern c_datesRegularExpression = Pattern.compile ("(\\d{4}-\\d{2}-\\d{2})");
	Pattern c_timesRegularExpression = Pattern.compile ("(\\d{2}:\\d{2}:\\d{2})");
	Pattern c_javaPackageDelimiterRegularExpression = Pattern.compile ("\\.");
	Pattern c_windowsDirectoryDelimiterRegularExpression = Pattern.compile ("\\\\");
	Pattern c_wordRegularExpression = Pattern.compile ("(\\w+)");
	Pattern c_termRegularExpression = Pattern.compile ("(\\S+)");
	Pattern c_doubleQuotedTermRegularExpression = Pattern.compile ("\"(\\S+)\"");
	Pattern c_urlRegularExpression = Pattern.compile ("(\\b(https?|ftp|file)://)?[-A-Za-z0-9+&@#/%?=~_|!:,.;]+[-A-Za-z0-9+&@#/%=~_|]");
	Pattern c_xmlEntityReferenceOrBrElementRegularExpression = Pattern.compile ("(&.*?;|[ \t\r\n]+|<br.*?>)");
}

