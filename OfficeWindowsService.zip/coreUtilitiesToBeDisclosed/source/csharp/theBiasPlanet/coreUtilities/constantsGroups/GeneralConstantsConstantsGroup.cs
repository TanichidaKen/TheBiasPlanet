namespace theBiasPlanet {
	namespace coreUtilities {
		namespace constantsGroups {
			using System;
			using theBiasPlanet.coreUtilities.collections;
			using theBiasPlanet.coreUtilities.collectionsHandling;
			
			public static class GeneralConstantsConstantsGroup {
				public const int c_maximumBytesLengthPerUtf8Character = 4;
				public const int c_numberOfAlphabets = 26;
				public const int c_anyUnspecifiedInteger = -1;
				public const float c_anyUnspecifiedFloat = (float) -1.0;
				public const char c_anyUnspecifiedCharacter = (char) 0;
				public const int c_iterationStartingNumber = 0;
				public const int c_normalResult = 0;
				public const String c_emptySpace = "";
				public const char c_radixPointCharacter = '.';
				public const char c_thousandsDelimiter = ',';
				public const char c_escapingCharacter = '\\';
				public const char c_newLineCharacter = '\n';
				public const char c_carriageReturnCharacter = '\r';
				public const char c_semicolonCharacter = ';';
				public const char c_utfBomCharacter = '\uFEFF';
				public const char c_lessThanCharacter = '<';
				public const char c_greaterThanCharacter = '>';
				public const char c_ampersandCharacter = '&';
				public const char c_doubleQuotationMarkCharacter = '\"';
				public const char c_apostropheCharacter = '\'';
				public const char c_argumentsDelimiter = ' ';
				public const String c_colonDelimiter = ": ";
				public const String c_commaDelimiter = ", ";
				public const char c_linuxDirectoriesDelimiter = '/';
				public const char c_windowsDirectoriesDelimiter = '\\';
				public const char c_javaPackagesDelimiter = '.';
				public const char c_fileNameElementsDelimiter = '.';
				public const char c_nameElementsDelimiter = '_';
				public const char c_linuxPathsDelimiter = ':';
				public const char c_windowsPathsDelimiter = ';';
				public const String c_integerDefaultFormat = "%d";
				public const String c_doubleDefaultFormat = "%f";
				public const String c_booleanDefaultFormat = "%b";
				public const String c_globExpressionFormat = "glob:%s";
				public const String c_commandSwitchOrFlagStarter = "-";
				public static readonly String c_linuxDirectoryPathFormat = String.Format ("{{0}}{0}{{1}}", c_linuxDirectoriesDelimiter);
				public static readonly String c_windowsDirectoryPathFormat = String.Format ("{{0}}{0}{{1}}", c_windowsDirectoriesDelimiter);
				public static readonly String c_linuxFilePathFormat = String.Format ("{{0}}{0}{{1}}", c_linuxDirectoriesDelimiter);
				public static readonly String c_windowsFilePathFormat = String.Format ("{{0}}{0}{{1}}", c_windowsDirectoriesDelimiter);
				public static readonly String c_fileNameFormat = String.Format ("%%s%s%%s", c_fileNameElementsDelimiter);
				public static readonly String c_javaClassNameFormat = String.Format ("{{0}}{0}{{1}}", c_javaPackagesDelimiter);
				public static readonly String c_styleSheetFileNameFormat = String.Format ("{{0}}{0}{1}", c_fileNameElementsDelimiter, FileNameSuffixesConstantsGroup.c_styleSheetFileNameSuffix);
				public static readonly String c_javaFileNameFormat = String.Format ("{{0}}{0}{1}", c_fileNameElementsDelimiter, FileNameSuffixesConstantsGroup.c_javaFileNameSuffix);
				public const String c_quotedByDoubleQuotationsFormat = "\"{0}\"";
				public const String c_quotedByAngleBracketsFormat = "<{0}>";
				public static readonly String c_definitionNameFormat = String.Format ("{0}{0}{{0}}{0}{0}", c_nameElementsDelimiter);
				public const String c_plus = "+";
				public const String c_propertyValueFormat = "${{{0}}}";
				public static readonly NavigableLinkedHashMap <char, int> c_alphabetToAlphabetIndexMap = MapsFactory.createNavigableLinkedHashMap <char, int> ('A', 0, 'B', 1, 'C', 2, 'D', 3, 'E', 4, 'F', 5, 'G', 6, 'H', 7, 'I', 8, 'J', 9, 'K', 10, 'L', 11, 'M', 12, 'N', 13, 'O', 14, 'P', 15, 'Q', 16, 'R', 17, 'S', 18, 'T', 19, 'U', 20, 'V', 21, 'W', 22, 'X', 23, 'Y', 24, 'Z', 25);
				public static readonly NavigableLinkedHashMap  <int, char> c_alphabetIndexToAlphabetMap = MapsFactory.createNavigableLinkedHashMap <int, char> ( 0, 'A', 1, 'B', 2, 'C', 3, 'D', 4, 'E', 5, 'F', 6, 'G', 7, 'H', 8, 'I', 9, 'J', 10, 'K', 11, 'L', 12, 'M', 13, 'N', 14, 'O', 15, 'P', 16, 'Q', 17, 'R', 18, 'S', 19, 'T', 20, 'U', 21, 'V', 22, 'W', 23, 'X', 24, 'Y', 25, 'Z');
			}
		}
	}
}

