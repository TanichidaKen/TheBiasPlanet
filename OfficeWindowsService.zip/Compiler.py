import sys
import py_compile

if __name__ == "__main__":
	if len (sys.argv) < 3:
		sys.stderr.write ("The arguments have to be these.\nThe argument 1: the source file path\nThe argument 2: the binary code file path'\n")
	else:
		py_compile.compile (sys.argv [1], sys.argv [2])
