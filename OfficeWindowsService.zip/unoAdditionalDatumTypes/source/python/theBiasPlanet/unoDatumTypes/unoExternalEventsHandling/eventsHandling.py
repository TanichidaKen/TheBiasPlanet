from abc import ABCMeta
from com.sun.star.uno import XInterface
from theBiasPlanet.unoDatumTypes.unoExternalEventsHandling.events import XExternalEvent

class XExternalEventsBroadcaster (XInterface, metaclass=ABCMeta):
	def addEventsListener (a_this: "XExternalEventsBroadcaster", a_eventsListener: "XExternalEventsListener") -> None:
		None
		
	def removeEventsListener (a_this: "XExternalEventsBroadcaster", a_eventsListener: "XExternalEventsListener") -> None:
		None

#class XExternalEventsListener (XInterface, metaclass=ABCMeta):
class XExternalEventsListener (XInterface, metaclass=ABCMeta):
	def eventHappened (a_this: "XExternalEventsListener", a_event: "XExternalEvent") -> None:
		None

