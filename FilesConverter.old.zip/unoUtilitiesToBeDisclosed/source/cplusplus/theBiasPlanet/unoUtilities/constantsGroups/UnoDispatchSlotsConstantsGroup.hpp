#ifndef __theBiasPlanet_unoUtilities_constantsGroups_UnoDispatchSlotsConstantsGroup_hpp__
	#define __theBiasPlanet_unoUtilities_constantsGroups_UnoDispatchSlotsConstantsGroup_hpp__
	
	#include <optional>
	#include <string>
	#include "theBiasPlanet/coreUtilities/constantsGroups/BaseEnumerableConstantsGroup.hpp"
	#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	using namespace ::theBiasPlanet::coreUtilities::constantsGroups;
	
	namespace theBiasPlanet {
		namespace unoUtilities {
			namespace constantsGroups {
				class __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ UnoDispatchSlotsConstantsGroup {
					public:
						// Base class for all the constants in this group
						class BaseDispatchSlot {
							public:
								string const c_url;
								optional <BaseEnumerableConstantsGroup <string>> const c_argumentPropertyNamesSet;
								BaseDispatchSlot (string a_url, optional <BaseEnumerableConstantsGroup <string>> a_argumentPropertyNamesSet);
						};
						static BaseDispatchSlot const c__uno_StyleNewByExample;
						static BaseDispatchSlot const c__uno_GoToCell;
				};
			}
		}
	}
#endif

