package theBiasPlanet.coreUtilities.messaging;

import javafx.scene.control.Alert;
import javafx.scene.control.DialogPane;
import javafx.scene.control.Label;
import javafx.scene.control.ButtonType;
import javafx.scene.layout.Region;
import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.coreUtilities.programsHandling.FxProcessEnvironment;

public class CustomizedAlert extends Alert {
	public static int extraHeight = 10;
	
	public CustomizedAlert (Alert.AlertType a_alertType, String a_header, String a_content, ButtonType... a_buttonTypes) {
		super (a_alertType, a_content, a_buttonTypes);
		DialogPane l_dialogPane = getDialogPane ();
		l_dialogPane.getStylesheets ().add (FxProcessEnvironment.s_currentEnvironment.getProperties ().getProperty (ProcessPropertyNamesConstantsGroup.c_styleSheetUrl));
		l_dialogPane.getStyleClass ().add (FxStyleClassesConstantsGroup.c_dialogPane);
		setHeaderText (a_header);
		getDialogPane ().getChildren ().stream ().filter (l_node -> {
			return l_node instanceof Label;
		}).forEach (l_node -> {
			( (Label) l_node).setMinHeight (Region.USE_PREF_SIZE + extraHeight);
		});
	}
}

