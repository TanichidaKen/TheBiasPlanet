#ifndef __theBiasPlanet_coreUtilities_constantsGroups_DefaultValuesConstantsGroup_hpp__
	#define __theBiasPlanet_coreUtilities_constantsGroups_DefaultValuesConstantsGroup_hpp__

	#include "theBiasPlanet/coreUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	
	namespace theBiasPlanet {
		namespace coreUtilities {
			namespace constantsGroups {
				class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ DefaultValuesConstantsGroup {
					public:
						static int const c_smallBufferSize;
						static int const c_largeBufferSize;
						static int const c_smallestBufferSize;
				};
			}
		}
	}
#endif

