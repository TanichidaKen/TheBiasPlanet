namespace theBiasPlanet {
	namespace filesConverter {
		namespace programs {
			using System;
			using System.Collections.Generic;
			using uno;
			using unoidl.com.sun.star.beans;
			using unoidl.com.sun.star.container;
			using unoidl.com.sun.star.frame;
			using unoidl.com.sun.star.lang;
			using unoidl.com.sun.star.sheet;
			using theBiasPlanet.coreUtilities.collectionsHandling;
			using theBiasPlanet.coreUtilities.constantsGroups;
			using theBiasPlanet.coreUtilities.messaging;
			using theBiasPlanet.coreUtilities.programsHandling;
			using theBiasPlanet.coreUtilities.performanceMeasuring;
			using theBiasPlanet.unoUtilities.connectionsHandling;
			using theBiasPlanet.unoUtilities.constantsGroups;
			using theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;
			using theBiasPlanet.unoUtilities.documentsHandling;
			using theBiasPlanet.unoUtilities.filesConverting;
			using theBiasPlanet.unoUtilities.programsHandling;
			using theBiasPlanet.unoUtilities.propertiesHandling;
			using theBiasPlanet.unoUtilities.unoDataHandling;
			
			public class FilesConverterConsoleProgram {
				private class UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor : UnoDocumentTailor {
					private int i_targetSpreadSheetIndex;
					
					public UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor (UnoObjectsContext a_objectsContext, int a_targetSpreadSheetIndex) : base (a_objectsContext) {
						i_targetSpreadSheetIndex = a_targetSpreadSheetIndex;
					}
					
					public override bool tailor (XComponent a_unoDocumentInXComponent) {
						XSpreadsheetDocument l_spreadSheetsDocumentInXSpreadsheetDocument = (XSpreadsheetDocument) a_unoDocumentInXComponent;
						if (l_spreadSheetsDocumentInXSpreadsheetDocument == null) {
							Publisher.logErrorInformation ("The document is not any spread sheet.");
							return false;
						}
						else {
							XIndexAccess l_spreadSheetsInXIndexAccess = (XIndexAccess) l_spreadSheetsDocumentInXSpreadsheetDocument.getSheets ();
							try {
								XSpreadsheet l_spreadSheetInXSpreadsheet = (XSpreadsheet) (((Any) l_spreadSheetsInXIndexAccess.getByIndex (i_targetSpreadSheetIndex)).Value);
								XNamed l_spreadSheetInXNamed = (XNamed) l_spreadSheetInXSpreadsheet;
								((XSpreadsheets) l_spreadSheetsInXIndexAccess).moveByName (l_spreadSheetInXNamed.getName (), (short) GeneralConstantsConstantsGroup.c_iterationStartingNumber);
								return true;
							}
							catch (Exception l_exception) {
								Publisher.logErrorInformation (l_exception);
								return false;
							}
						}
					}
				}
				
				static void Main (String [] a_argumentsArray) {
					int l_resultStatus = -1;
					try {
						if (a_argumentsArray.Length < 4) {
							throw new Exception ("The arguments have to be these.\nThe argument 1: the server URL like 'socket,host=localhost,port=2002,tcpNoDelay=1;urp;StarOffice.ComponentContext'\nThe argument 2: the URL of the file to be converted like 'file://${HOME}/myData/development/filesConverter/execution/FilesConverterTest.ods'\nThe argument 3: the URL of the target file  like 'file://${HOME}/myData/development/filesConverter/execution/FilesConverterTest.csv'\nThe argument 4: the filter name like 'Text - txt - csv (StarCalc)'\nThe argument 5 (optional): the converted-from file password\nThe argument 6 (valid only for the CSV filter, and optional): whether all the spread sheets are written ('true' or else)\nThe argument 7 (valid only for the CSV filter, and optional): the CSV file naming rule ('0' -> augmented by the sheet index, '1' -> augmented by the sheet name)\nThe argument 8 (valid only for the CSV filter, and optional): the items delimiter character code\nThe argument 9 (valid only for the CSV filter, and optional): the text item quotation character code\nThe argument 10 (valid only for the CSV filter, and optional): the encoding code\nThe argument 11 (valid only for the CSV filter, and optional): whether all the text items are quoted\nThe argument 12 (valid only for the CSV filter, and optional): whether the contents are exported as shown\nThe argument 13 (valid only for the CSV filter, and optional): whether the formula themselves are exported\nThe argument 14 (valid only for the CSV filter, and optional): whether the hidden sheets are written\n");
						}
						String l_unoServerUrl = a_argumentsArray [0];
						String l_convertedFileUrl = a_argumentsArray [1];
						String l_targetFileUrl = a_argumentsArray [2];
						String l_filterName = a_argumentsArray [3];
						String l_openingPassword = null;
						if (a_argumentsArray.Length >= 5) {
							l_openingPassword = a_argumentsArray [4];
						}
						String l_title = "Test Title";
						String l_storingPassword = "TestPassword";
						bool l_overwrites = true;
						List <String> l_documentStoringFilterDataInPropertiesArrayPropertyNames = ListsFactory.createList <String> ();
						List <Any> l_documentStoringFilterDataInPropertiesArrayPropertyValues = ListsFactory.createList <Any> ();
						bool l_whetherAllSpreadSheetsAreWritten = false;
						int l_targetFileNamingRule = 0;
						int l_csvItemsDelimiterCharacterCode = (int) '\t';
						int l_csvTextItemQuotationCharacterCode = (int) '\"';
						int l_csvCharactersEncodingCode = UnoCharactersEncodingCodesConstantsGroup.c_utf8; // 76: UTF-8, 65535: UCS-2, 65534: UCS-4, 11: US-ASCII, 69: EUC_JP, 64: SHIFT_JIS
						bool l_csvWhetherAllTextItemsAreQuoted = true;
						bool l_csvWhetherContentsAreExportedAsShown = true;
						bool l_csvWhetherFormulaeThemselvesAreExported = false;
						bool l_whetherHiddenSpreadSheetsAreWritten = false;
						if (l_filterName == UnoFileStoringFilterNamesConstantsGroup.c_csvFileFilterName) {
							if (a_argumentsArray.Length >= 6) {
								if (a_argumentsArray [5] == "true") {
									l_whetherAllSpreadSheetsAreWritten = true;
								}
								if (a_argumentsArray.Length >= 7) {
									l_targetFileNamingRule = int.Parse (a_argumentsArray [6]);
									if (a_argumentsArray.Length >= 8) {
										l_csvItemsDelimiterCharacterCode = int.Parse (a_argumentsArray [7]);
										if (a_argumentsArray.Length >= 9) {
											l_csvTextItemQuotationCharacterCode = int.Parse (a_argumentsArray [8]);
											if (a_argumentsArray.Length >= 10) {
												l_csvCharactersEncodingCode = int.Parse (a_argumentsArray [9]);
												if (a_argumentsArray.Length >= 11) {
													if (a_argumentsArray [10] == "true") {
														l_csvWhetherAllTextItemsAreQuoted = true;
													}
													if (a_argumentsArray.Length >= 12) {
														if (a_argumentsArray [11] == "true") {
															l_csvWhetherContentsAreExportedAsShown = true;
														}
														if (a_argumentsArray.Length >= 13) {
															if (a_argumentsArray [12] == "true") {
																l_csvWhetherFormulaeThemselvesAreExported = true;
															}
															if (a_argumentsArray.Length >= 14) {
																if (a_argumentsArray [13] == "true") {
																	l_whetherHiddenSpreadSheetsAreWritten = true;
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
						String l_documentStoringFilterDataInStringValue = "";
						PropertyValue [] l_documentStoringPropertiesArray = null;
						if (!l_whetherAllSpreadSheetsAreWritten) {
							List <String> l_documentStoringPropertyNames = ListsFactory.createList <String> (
								UnoDocumentStoringEnumerablePropertyNamesSet.c_filterName_string,
								UnoDocumentStoringEnumerablePropertyNamesSet.c_filterData_any,
								UnoDocumentStoringEnumerablePropertyNamesSet.c_filterData_string,
								UnoDocumentStoringEnumerablePropertyNamesSet.c_title_string,
								UnoDocumentStoringEnumerablePropertyNamesSet.c_password_string,
								UnoDocumentStoringEnumerablePropertyNamesSet.c_overwrites_boolen
							);
							List <Any> l_documentStoringPropertyValues = ListsFactory.createList <Any> (
								UnoDatumConverter.getAny (l_filterName),
								UnoDatumConverter.getAny (UnoPropertiesHandler.buildPropertiesArray (l_documentStoringFilterDataInPropertiesArrayPropertyNames, l_documentStoringFilterDataInPropertiesArrayPropertyValues)),
								UnoDatumConverter.getAny (l_documentStoringFilterDataInStringValue),
								UnoDatumConverter.getAny (l_title),
								UnoDatumConverter.getAny (l_storingPassword),
								UnoDatumConverter.getAny (l_overwrites)
							);
							l_documentStoringPropertiesArray = UnoPropertiesHandler.buildPropertiesArray (l_documentStoringPropertyNames, l_documentStoringPropertyValues);
						}
						else {
							l_documentStoringPropertiesArray = FilesConverter.createCsvFileStoringPropertiesArray (l_csvItemsDelimiterCharacterCode, l_csvTextItemQuotationCharacterCode, l_csvCharactersEncodingCode, l_csvWhetherAllTextItemsAreQuoted, l_csvWhetherContentsAreExportedAsShown, l_csvWhetherFormulaeThemselvesAreExported);
						}
						UnoProcessEnvironment l_localUnoProcessEnvironment = new UnoProcessEnvironment (DateTime.Now.ToString (), null);
						ProcessEnvironment.windowsSocketStartup ();
						UnoConnectionConnector l_unoConnectionConnector = new UnoConnectionConnector (l_localUnoProcessEnvironment.getLocalObjectsContext ());
						UnoConnection l_unoConnection = l_unoConnectionConnector.connect (l_unoServerUrl, null);
						UnoObjectsContext l_remoteUnoObjectsContext = l_unoConnection.getRemoteObjectsContext ();
						FilesConverter l_filesConverter = new FilesConverter (l_remoteUnoObjectsContext);
						UnoDocumentTailor l_unoDocumentTailor = null;
						PerformanceMeasurer.setStartTime ();
						bool l_whetherConversionHasSucceeded = false;
						if (!l_whetherAllSpreadSheetsAreWritten) {
							if (l_filterName == UnoFileStoringFilterNamesConstantsGroup.c_csvFileFilterName) {
								l_unoDocumentTailor = new UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor (l_remoteUnoObjectsContext, 1);
							}
							l_whetherConversionHasSucceeded = l_filesConverter.convertFile (l_convertedFileUrl, l_openingPassword, l_targetFileUrl, l_documentStoringPropertiesArray, l_unoDocumentTailor);
						}
						else {
							l_whetherConversionHasSucceeded = l_filesConverter.convertSpreadSheetsDocumentFileToCsvFiles (l_convertedFileUrl, l_openingPassword, l_targetFileUrl, l_documentStoringPropertiesArray, l_unoDocumentTailor, l_targetFileNamingRule, l_whetherHiddenSpreadSheetsAreWritten);
						}
						if (l_whetherConversionHasSucceeded) {
							Console.Out.WriteLine (String.Format ("### The elapsed time is {0:n0} ns", PerformanceMeasurer.getElapseTimeInNanoSeconds ()));
							l_resultStatus = 0;
						}
						else {
						}
						l_unoConnection.disconnect ();
						ProcessEnvironment.windowsSocketCleanup ();
					}
					catch (Exception l_exception) {
						Publisher.logErrorInformation (l_exception);
						Environment.Exit (l_resultStatus);
					}
					Environment.Exit (l_resultStatus);
				}
			}
		}
	}
}

