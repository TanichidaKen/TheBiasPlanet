#ifndef __theBiasPlanet_filesConverter_programs_FilesConverterConsoleProgram_hpp__
#define __theBiasPlanet_filesConverter_programs_FilesConverterConsoleProgram_hpp__

#include "theBiasPlanet/unoUtilities/documentsHandling/UnoDocumentTailor.hpp"

using namespace ::theBiasPlanet::unoUtilities::documentsHandling;

namespace theBiasPlanet {
	namespace filesConverter {
		namespace programs {
			class FilesConverterConsoleProgram {
				private:
					class UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor : public UnoDocumentTailor {
						private:
							int i_targetSpreadSheetIndex;
						public:
							UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor (Reference <UnoObjectsContext> a_unoObjectsContext, int a_targetSpreadSheetIndex);
							UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor (UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor const & a_copiedObject);
							virtual ~UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor ();
							virtual bool tailor (Reference <XComponent> a_unoDocumentInXComponent) const override;
					};
				public:
					static int main (int const & a_argumentsNumber, char const * const a_arguments []);
			};
		}
	}
}

#endif

