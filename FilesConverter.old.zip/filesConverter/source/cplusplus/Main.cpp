#include "theBiasPlanet/filesConverter/programs/FilesConverterConsoleProgram.hpp"
#include <sal/main.h>

using namespace ::theBiasPlanet::filesConverter::programs;

// An environment variable has to be set like 'URE_MORE_TYPES=file:////usr/lib/libreoffice/program/types/offapi.rdb'; the environment variable can be set by passing an argument like '-env:URE_MORE_TYPES=file:////usr/lib/libreoffice/program/types/offapi.rdb'
int main (int a_argumentsNumber, char * a_arguments []) {
	sal_detail_initialize (a_argumentsNumber, a_arguments);
	int l_result = FilesConverterConsoleProgram::main (a_argumentsNumber, a_arguments);
	sal_detail_deinitialize ();
	return l_result;
}

