from typing import Optional
from datetime import datetime
import wx
from theBiasPlanet.coreUtilities.processesHandling.ProcessEnvironment import ProcessEnvironment

class WxProcessEnvironment (ProcessEnvironment):
	s_currentEnvironment: Optional ["WxProcessEnvironment"] = None
	
	def __init__ (a_this: "WxProcessEnvironment", a_identification: str):
		#a_this.i_wxApplication: Optional [wx.core.App] = None
		a_this.i_wxApplication: Optional [wx.App] = None
		
		super ().__init__ (a_identification)
		if WxProcessEnvironment.s_currentEnvironment is None:
			a_this.i_wxApplication = wx.App ()
			#a_this.i_wxApplication.MainLoop ()
			WxProcessEnvironment.s_currentEnvironment = a_this
		else:
			raise Exception ("wxPython has been already initialized.")
	
	def __del__ (a_this: "WxProcessEnvironment") -> None:
		None
	
#WxProcessEnvironment.s_currentEnvironment = WxProcessEnvironment (str (datetime.now ()))
WxProcessEnvironment (str (datetime.now ()))

