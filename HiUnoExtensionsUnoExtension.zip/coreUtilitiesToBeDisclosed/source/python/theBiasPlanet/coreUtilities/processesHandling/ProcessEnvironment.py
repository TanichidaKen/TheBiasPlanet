from typing import Optional

class ProcessEnvironment:
	s_currentEnvironment: Optional ["ProcessEnvironment"] = None
	
	def __init__ (a_this: "ProcessEnvironment", a_identification: str):
		a_this.i_dentification: str = a_identification
		
		s_currentEnvironment = a_this

