from typing import Dict
from typing import List
from typing import TextIO
from typing import cast
from io import StringIO
import os
import signal
import subprocess
from subprocess import Popen
import sys
import threading
from threading import Condition
from threading import Thread
from theBiasPlanet.coreUtilities.constantsGroups.CharactersSetNamesConstantsGroup import CharactersSetNamesConstantsGroup
from theBiasPlanet.coreUtilities.inputs.HaltableStandardInputReader import HaltableStandardInputReader
from theBiasPlanet.coreUtilities.inputsHandling.NoMoreDataException import NoMoreDataException
from theBiasPlanet.coreUtilities.messagingHandling.Publisher import Publisher
from theBiasPlanet.coreUtilities.timersHandling.TimeOutException import TimeOutException

class ProcessHandler ():
	s_haltableStandardInputReader: "HaltableStandardInputReader" = HaltableStandardInputReader.getInstance ()
	
	# the static initializer Start
	# the dispatch data thread is not started automatically.
	#s_haltableStandardInputReader.startDispatchDataThread ()
	# the static initializer End
	
	@staticmethod
	def interruptRelayStandardInputThread (a_thread: Thread) -> None:
		ProcessHandler.s_haltableStandardInputReader.removeSubscriber ("{0:d}".format (id (a_thread)))
	
	class StandardInputAndOutputs:
		def __init__ (a_this: "ProcessHandler.StandardInputAndOutputs", a_process: Popen) -> None:
			a_this.i_process: Popen
			a_this.i_standardInputOutputStream: TextIO
			a_this.i_standardOutputInputStream: TextIO
			a_this.i_standardErrorOutputInputStream: TextIO
			a_this.i_relayStandardInputThread: Thread
			a_this.i_printStandardOutputThread: Thread
			a_this.i_printStandardErrorOutputThread: Thread
			a_this.i_thereWereStandardInputContents: bool
			a_this.i_thereWereStandardOutputContents: bool
			a_this.i_thereWereStandardErrorOutputContents: bool
			
			a_this.i_process = a_process
			a_this.i_standardInputOutputStream = cast (TextIO, a_this.i_process.stdin)
			a_this.i_standardOutputInputStream = cast (TextIO, a_this.i_process.stdout)
			a_this.i_standardErrorOutputInputStream = cast (TextIO, a_this.i_process.stderr)
			a_this.i_relayStandardInputThread = None
			a_this.i_printStandardOutputThread = None
			a_this.i_printStandardErrorOutputThread = None
			a_this.i_thereWereStandardInputContents = False
			a_this.i_thereWereStandardOutputContents = False
			a_this.i_thereWereStandardErrorOutputContents = False
		
		def getStandardInputOutputStream (a_this: "ProcessHandler.StandardInputAndOutputs", ) -> TextIO:
			return a_this.i_standardInputOutputStream
		
		def getStandardOutputInputStream (a_this: "ProcessHandler.StandardInputAndOutputs", ) -> TextIO:
			return a_this.i_standardOutputInputStream
		
		def getStandardErrorOutputInputStream (a_this: "ProcessHandler.StandardInputAndOutputs", ) -> TextIO:
			return a_this.i_standardErrorOutputInputStream
		
		def relayStandardInputAsynchronously (a_this: "ProcessHandler.StandardInputAndOutputs") -> None:
			def l_relayStandardInputThreadFunction () -> None:
				l_threadIdentification: str = "{0:d}".format (id (threading.current_thread ()))
				try:
					l_processStandardInputWriter: TextIO = a_this.i_standardInputOutputStream
					l_standardInputDatum: str = None
					while True:
						try:
							l_standardInputDatum = ProcessHandler.s_haltableStandardInputReader.read (l_threadIdentification, 1)
							a_this.i_thereWereStandardInputContents = True
							l_processStandardInputWriter.write (l_standardInputDatum)
							l_processStandardInputWriter.flush ()
						except (NoMoreDataException) as l_exception:
							break
						except (TimeOutException) as l_exception:
							# impossible
							None
				except (Exception) as l_exception:
					Publisher.logErrorInformation ("### A standard input error: {0:s}.".format (str (l_exception)))
			a_this.i_relayStandardInputThread = Thread (target = l_relayStandardInputThreadFunction)
			ProcessHandler.s_haltableStandardInputReader.addSubscriber ("{0:d}".format (id (a_this.i_relayStandardInputThread)))
			a_this.i_relayStandardInputThread.start ()
		
		def printStandardOutputAsynchronously (a_this: "ProcessHandler.StandardInputAndOutputs") -> None:
			def l_printStandardOutputThreadFunction () -> None:
				try:
					l_standardOutputReader: TextIO = a_this.i_standardOutputInputStream
					l_standardOutputData: str
					while True:
						l_standardOutputData = l_standardOutputReader.read (1)
						if l_standardOutputData == "":
							break
						a_this.i_thereWereStandardOutputContents = True
						sys.stdout.write (l_standardOutputData)
						sys.stdout.flush ()
				except (Exception) as l_exception:
					Publisher.logErrorInformation (l_exception)
					sys.stderr.write ("### A standard output error: {0:s}.\n".format (str (l_exception)))
					sys.stderr.flush ()
			a_this.i_printStandardOutputThread  = Thread (target = l_printStandardOutputThreadFunction)
			a_this.i_printStandardOutputThread.start ()
		
		def printStandardErrorOutputAsynchronously (a_this: "ProcessHandler.StandardInputAndOutputs") -> None:
			def l_printStandardErrorOutputThreadFunction () -> None:
				try:
					l_standardErrorOutputReader: TextIO = a_this.i_standardErrorOutputInputStream
					l_standardErrorOutputData: str
					while True:
						l_standardErrorOutputData = l_standardErrorOutputReader.read (1)
						if l_standardErrorOutputData == "":
							break
						a_this.i_thereWereStandardErrorOutputContents = True
						sys.stderr.write (l_standardErrorOutputData)
						sys.stderr.flush ()
				except (Exception) as l_exception:
					Publisher.logErrorInformation (l_exception)
					sys.stderr.write ("### A standard error output error: {0:s}.\n".format (str (l_exception)))
					sys.stderr.flush ()
			a_this.i_printStandardErrorOutputThread  = Thread (target = l_printStandardErrorOutputThreadFunction)
			a_this.i_printStandardErrorOutputThread .start ()
		
		def setStandardInputNextLine (a_this: "ProcessHandler.StandardInputAndOutputs", a_line: str) -> None:
			try:
				a_this.i_standardInputOutputStream.write ("{0:s}\n".format (a_line))
				a_this.i_standardInputOutputStream.flush ()
				a_this.i_thereWereStandardInputContents = True
			except (Exception) as l_exception:
				sys.stderr.write ("The standard input couldn't be written into: {0:s}.\n".format (str (l_exception)))
				sys.stderr.flush ()
				a_this.i_standardInputOutputStream.close ()
		
		def getStandardOutputNextLine (a_this: "ProcessHandler.StandardInputAndOutputs") -> str:
			try:
				l_line: str = None
				l_line = a_this.i_standardOutputInputStream.readline ()
				if l_line != "":
					a_this.i_thereWereStandardOutputContents = True
					return l_line
				else:
					a_this.i_standardOutputInputStream.close ()
					return None
			except (Exception) as l_exception:
				sys.stderr.write ("The standard output couldn't be scanned: {0:s}.\n".format (str (l_exception)))
				sys.stderr.flush ()
				a_this.i_standardOutputInputStream.close ()
				return None
		
		def getStandardErrorOutputNextLine (a_this: "ProcessHandler.StandardInputAndOutputs") -> str:
			try:
				l_line: str = None
				l_line = a_this.i_standardErrorOutputInputStream.readline ()
				if l_line != "":
					a_this.i_thereWereStandardErrorOutputContents = True
					return l_line
				else:
					a_this.i_standardErrorOutputInputStream.close ()
					return None
			except (Exception) as l_exception:
				sys.stderr.write ("The standard error output couldn't be scanned: {0:s}.\n".format (str (l_exception)))
				sys.stderr.flush ()
				a_this.i_standardErrorOutputInputStream.close ()
				return None
		
		def thereWereStandardInputContents (a_this: "ProcessHandler.StandardInputAndOutputs") -> bool:
			return a_this.i_thereWereStandardInputContents
		
		def thereWereStandardOutputContents (a_this: "ProcessHandler.StandardInputAndOutputs") -> bool:
			return a_this.i_thereWereStandardOutputContents
		
		def thereWereStandardErrorOutputContents (a_this: "ProcessHandler.StandardInputAndOutputs") -> bool:
			return a_this.i_thereWereStandardErrorOutputContents
		
		def waitUntillFinish (a_this: "ProcessHandler.StandardInputAndOutputs") -> int:
			if a_this.i_printStandardErrorOutputThread is not None:
				a_this.i_printStandardErrorOutputThread.join ()
				a_this.i_printStandardErrorOutputThread = None
			if a_this.i_printStandardOutputThread is not None:
				a_this.i_printStandardOutputThread.join ()
				a_this.i_printStandardOutputThread = None
			l_processReturn: int = a_this.i_process.wait ()
			if a_this.i_relayStandardInputThread is not None:
				ProcessHandler.interruptRelayStandardInputThread (a_this.i_relayStandardInputThread)
				a_this.i_relayStandardInputThread.join ()
				a_this.i_relayStandardInputThread = None
			return l_processReturn
	
	# The environment variables of the current process are automatically passed into the sub process.
	@staticmethod
	def executeAndReturnStandardInputAndOutputs (a_workingDirectoryPath: str, a_environmentVariableNameToValueMap: "Dict [str, str]", a_commandAndArguments: List [str]) -> "ProcessHandler.StandardInputAndOutputs":
		l_process: Popen = Popen (args = a_commandAndArguments, stdin = subprocess.PIPE, stdout = subprocess.PIPE, stderr = subprocess.PIPE, cwd = a_workingDirectoryPath, env = a_environmentVariableNameToValueMap, encoding = CharactersSetNamesConstantsGroup.c_utf8CharactersSetName)
		return ProcessHandler.StandardInputAndOutputs (l_process)
	
	@staticmethod
	def execute (a_workingDirectory: str, a_environmentVariableNameToValueMap: "Dict [str, str]", a_commandAndArguments: List [str], a_waitsUntilFinish: bool) -> int:
		l_standardInputAndOutputs: "ProcessHandler.StandardInputAndOutputs" = ProcessHandler.executeAndReturnStandardInputAndOutputs (a_workingDirectory, a_environmentVariableNameToValueMap, a_commandAndArguments)
		l_childProcessReturn: int = 0
		if a_waitsUntilFinish:
			l_standardInputAndOutputs.printStandardOutputAsynchronously ()
			l_standardInputAndOutputs.printStandardErrorOutputAsynchronously ()
			l_standardInputAndOutputs.relayStandardInputAsynchronously ()
			l_childProcessReturn = l_standardInputAndOutputs.waitUntillFinish ()
		else:
			def l_waitForInvokedProcessToEndThreadFunction () -> None:
				try:
					l_standardInputAndOutputs.printStandardOutputAsynchronously ()
					l_standardInputAndOutputs.printStandardErrorOutputAsynchronously ()
					l_standardInputAndOutputs.relayStandardInputAsynchronously ()
					l_standardInputAndOutputs.waitUntillFinish ()
				except (Exception) as l_exception:
					None
			l_waitForInvokedProcessToEndThread = Thread (target = l_waitForInvokedProcessToEndThreadFunction)
			l_waitForInvokedProcessToEndThread.start ()
		return l_childProcessReturn

