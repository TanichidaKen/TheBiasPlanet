
class TimeOutException (Exception):
	def __init__ (a_this: "TimeOutException", a_message: str) -> None:
		
		super ().__init__ (a_message)

