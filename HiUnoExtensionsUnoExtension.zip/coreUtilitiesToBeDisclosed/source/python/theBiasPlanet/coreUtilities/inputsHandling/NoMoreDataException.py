
class NoMoreDataException (Exception):
	def __init__ (a_this: "NoMoreDataException", a_message: str) -> None:
		
		super ().__init__ (a_message)

