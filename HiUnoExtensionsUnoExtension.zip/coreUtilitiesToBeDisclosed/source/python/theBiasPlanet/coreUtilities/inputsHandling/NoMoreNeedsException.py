
class NoMoreNeedsException (Exception):
	def __init__ (a_this: "NoMoreNeedsException", a_message: str) -> None:
		
		super ().__init__ (a_message)

