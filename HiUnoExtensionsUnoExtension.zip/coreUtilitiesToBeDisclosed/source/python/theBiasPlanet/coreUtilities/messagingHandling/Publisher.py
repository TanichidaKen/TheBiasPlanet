import inspect
from inspect import FrameInfo
import os
import sys
import threading
import traceback
from typing import List
from typing import Optional
from typing import TextIO
from typing import Union
import wx
from wx import MessageDialog
from theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup import GeneralConstantsConstantsGroup

class Publisher:
	c_processIdentification: int = os.getpid ()
	# 0: error, 1: error and warning, 2: error, warning, and normal, 3: error, warning, normal, and debug
	s_loggingLevel: int = 0
	s_succinctness: bool = False
	
	@staticmethod
	def getLoggingLevel () -> int:
		return Publisher.s_loggingLevel
	
	@staticmethod
	def setLoggingLevel (a_loggingLevel: int) -> None:
		Publisher.s_loggingLevel = a_loggingLevel
	
	@staticmethod
	def getSuccinctness () -> bool:
		return Publisher.s_succinctness
	
	@staticmethod
	def setSuccinctness (a_succinctness: bool) -> None:
		Publisher.s_succinctness = a_succinctness;
	
	@staticmethod
	def getMessage (a_messageIngredient: str) -> str:
		l_messageBuilder: List [str] = []
		if not Publisher.s_succinctness:
			l_stackTraceElements: List [FrameInfo] = None
			try:
				l_stackTraceElements = inspect.stack ()
				l_previousMethodStackTraceElement: FrameInfo
				l_stackTraceElement: FrameInfo
				l_pointsThisClass:bool = False
				for l_stackTraceElement in l_stackTraceElements:
					if l_stackTraceElement.filename.endswith ("theBiasPlanet{0:s}coreUtilities{0:s}messagingHandling{0:s}Publisher.py".format (GeneralConstantsConstantsGroup.c_currentDirectoriesDelimiter)):
						l_pointsThisClass = True
					else:
						if l_pointsThisClass:
							l_previousMethodStackTraceElement = l_stackTraceElement
							break
			except (Exception) as l_exception:
				None
			l_messageBuilder.append ("virtual machine name: ")
			l_messageBuilder.append (str (Publisher.c_processIdentification))
			l_messageBuilder.append (", class name: ")
			l_messageBuilder.append (l_previousMethodStackTraceElement.filename)
			l_messageBuilder.append (", method name: ");
			l_messageBuilder.append (l_previousMethodStackTraceElement.function)
			l_messageBuilder.append (", thread id: ")
			l_messageBuilder.append (str (threading.current_thread ().ident))
			l_messageBuilder.append (", ")
		l_messageBuilder.append (a_messageIngredient)
		return "".join (l_messageBuilder)
	
	@staticmethod
	def show (a_messageIngredient: str) -> str:
		l_message: str
		l_message = Publisher.getMessage (a_messageIngredient)
		l_messageDialog: MessageDialog = MessageDialog (None, l_message, "Information", wx.OK | wx.ICON_INFORMATION)
		l_messageDialog.ShowModal ()
		return l_message
	
	@staticmethod
	def logDebugInformation (a_messageIngredient: str) -> Optional [str]:
		if Publisher.s_loggingLevel >= 3:
			l_message: str = Publisher.getMessage (a_messageIngredient)
			sys.stdout.write ("Debug  : " + l_message + "\n")
			sys.stdout.flush ()
			return l_message;
		else:
			return None
	
	@staticmethod
	def logNormalInformation (a_messageIngredient: str) -> Optional [str]:
		if Publisher.s_loggingLevel >= 2:
			l_message: str = Publisher.getMessage (a_messageIngredient)
			sys.stdout.write ("Normal : " + l_message + "\n")
			sys.stdout.flush ()
			return l_message
		else:
			return None
	
	@staticmethod
	def logWarningInformation (a_messageIngredientOrMessageException: Union [str, Exception]) -> Optional [str]:
		if Publisher.s_loggingLevel >= 1:
			l_messageIngredient: str
			if isinstance (a_messageIngredientOrMessageException, str):
				l_messageIngredient = a_messageIngredientOrMessageException
			else:
				l_messageIngredient = "{0:s}: {1:s}".format (str (a_messageIngredientOrMessageException), traceback.format_exc ())
			l_message:str = Publisher.getMessage (l_messageIngredient)
			sys.stdout.write ("Warning: " + l_message + "\n")
			sys.stdout.flush ()
			return l_message
		else:
			return None
	
	@staticmethod
	def logErrorInformation (a_messageIngredientOrMessageException: Union [str, Exception]) -> Optional [str]:
		if Publisher.s_loggingLevel >= 0:
			l_messageIngredient: str
			if isinstance (a_messageIngredientOrMessageException, str):
				l_messageIngredient = a_messageIngredientOrMessageException
			else:
				l_messageIngredient = "{0:s}: {1:s}".format (str (a_messageIngredientOrMessageException), traceback.format_exc ())
			l_message: str = Publisher.getMessage (l_messageIngredient)
			sys.stderr.write ("Error  : " + l_message + "\n")
			sys.stderr.flush ()
			return l_message
		else:
			return None
	
	@staticmethod
	def appendToFile (a_fileName: str, a_contents: str) -> None:
		try:
			l_file: TextIO = open (a_fileName, "a")
			l_file.write (a_contents + "\n")
			l_file.close ()
		except IOError as l_exception:
			Publisher.show (str (l_exception))

