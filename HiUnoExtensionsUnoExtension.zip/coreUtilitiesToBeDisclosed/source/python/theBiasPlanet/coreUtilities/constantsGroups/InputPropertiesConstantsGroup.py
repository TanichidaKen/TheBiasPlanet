
class InputPropertiesConstantsGroup:
	c_noMoreData: int = -1
	c_noDataRetrieved: int = 0
	c_lengthNotSet: int = -1
	c_lengthNotRead: int = 0

