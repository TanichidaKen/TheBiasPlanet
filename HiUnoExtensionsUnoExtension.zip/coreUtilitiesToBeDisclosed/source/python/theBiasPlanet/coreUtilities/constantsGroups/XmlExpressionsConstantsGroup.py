
class XmlExpressionsConstantsGroup:
	c_xml1_0Declaration: str = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
	c_xmlDeclarationOpener: str = "<?xml"
	c_xhtml1_0DocumentTypeDeclaration: str = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Frameset//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd\">"
	c_xhtmlNamespace: str = "xmlns=\"http://www.w3.org/1999/xhtml\""
	c_xhtmlNamespaceOpener: str = "xmlns="
	c_tagEndCharacter: str = '>'
	c_commentOpener: str = "<!--"
	c_commentCloser: str = "-->"
	c_lessThanXmlExpression: str = "&lt;"
	c_greaterThanXmlExpression: str = "&gt;"
	c_ampersandXmlExpression: str = "&amp;"
	c_doubleQuotationMarkXmlExpression: str = "&quot;"
	c_apostropheXmlExpression: str = "&apos;"

