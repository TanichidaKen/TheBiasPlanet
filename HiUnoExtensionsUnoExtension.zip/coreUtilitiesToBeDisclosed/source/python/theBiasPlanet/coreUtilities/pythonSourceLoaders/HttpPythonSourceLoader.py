from typing import Union
from typing import cast
from http.client import HTTPConnection
from http.client import HTTPResponse
from http.client import HTTPSConnection
from importlib.abc import SourceLoader
import urllib.parse
from urllib.parse import ParseResult
from theBiasPlanet.coreUtilities.constantsGroups.DefaultValuesConstantsGroup import DefaultValuesConstantsGroup
from theBiasPlanet.coreUtilities.constantsGroups.FileNameSuffixesConstantsGroup import FileNameSuffixesConstantsGroup 
from theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup import GeneralConstantsConstantsGroup
from theBiasPlanet.coreUtilities.constantsGroups.HttpMethodNamesConstantsGroup import HttpMethodNamesConstantsGroup
from theBiasPlanet.coreUtilities.constantsGroups.HttpStatusCodesConstantsGroup import HttpStatusCodesConstantsGroup

class HttpPythonSourceLoader (SourceLoader):
	c_readingBlockSize: int = DefaultValuesConstantsGroup.c_smallBufferSize
	
	def __init__ (a_this: "HttpPythonSourceLoader ", a_urlPrefix: str) -> None:
		a_this.i_urlPrefix: str = a_urlPrefix
		a_this.i_httpConnection: HTTPConnection = None
		
		l_parsedUrl: ParseResult = urllib.parse.urlparse (a_this.i_urlPrefix)
		if l_parsedUrl.scheme == GeneralConstantsConstantsGroup.c_httpsSchemeName:
			a_this.i_httpConnection = HTTPSConnection (l_parsedUrl.hostname, l_parsedUrl.port)
		else:
			a_this.i_httpConnection = HTTPConnection (l_parsedUrl.hostname, l_parsedUrl.port)
	
	def get_filename (a_this: "HttpPythonSourceLoader", a_pythonModuleName: str) -> str:
		return "{0:s}{1:s}.{2:s}".format (a_this.i_urlPrefix, a_pythonModuleName.replace (GeneralConstantsConstantsGroup.c_pythonPackagesDelimiter, GeneralConstantsConstantsGroup.c_urlDirectoriesDelimiter), FileNameSuffixesConstantsGroup.c_pythonModuleFileNameSuffix)
	
	def get_data (a_this: "HttpPythonSourceLoader", a_pythonModuleUrl: Union [bytes, str]) -> bytes:
		l_httpResponseBody: bytes = b""
		try:
			l_parsedUrl: ParseResult = urllib.parse.urlparse (cast (str, a_pythonModuleUrl))
			a_this.i_httpConnection.request (HttpMethodNamesConstantsGroup.c_get, l_parsedUrl.path)
			l_httpResponse: HTTPResponse = a_this.i_httpConnection.getresponse ()
			if l_httpResponse.status == HttpStatusCodesConstantsGroup.c_success:
				l_httpResponseBodyBuffer: bytes = None
				while True:
					l_httpResponseBodyBuffer = l_httpResponse.read (HttpPythonSourceLoader.c_readingBlockSize)
					if len (l_httpResponseBodyBuffer) == 0:
						break
					l_httpResponseBody = l_httpResponseBody + l_httpResponseBodyBuffer
			else:
				raise Exception ("The Python module source could not be accessed.")
		finally:
			a_this.i_httpConnection.close ()
			
		return l_httpResponseBody

