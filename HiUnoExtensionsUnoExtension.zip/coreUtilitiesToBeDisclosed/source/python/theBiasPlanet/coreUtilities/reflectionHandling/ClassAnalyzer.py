from typing import List
from typing import Tuple

class ClassAnalyzer:
	@staticmethod
	def getHierarchyExpression (a_class: type) -> str:
		l_hierarchyExpression: List [str] = []
		l_hierarchyExpression.append (str (a_class))
		if a_class != object:
			l_superClasses: Tuple [type, ...] = a_class.__bases__
			l_superClass: type = None
			for l_superClass in l_superClasses:
				l_hierarchyExpression.append ("-> (")
				l_hierarchyExpression.append (ClassAnalyzer.getHierarchyExpression (l_superClass))
				l_hierarchyExpression.append (")")
		return "".join (l_hierarchyExpression)

