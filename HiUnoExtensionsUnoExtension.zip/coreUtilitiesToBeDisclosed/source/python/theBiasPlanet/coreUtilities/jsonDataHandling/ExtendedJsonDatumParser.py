from typing import Iterator
from typing import List
from typing import Match
from typing import Optional
from typing import TextIO
from dateutil.parser import parse as parseDateAndTimeString
import math
import sys
from threading import Thread
from theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup import GeneralConstantsConstantsGroup
from theBiasPlanet.coreUtilities.constantsGroups.RegularExpressionsConstantsGroup import RegularExpressionsConstantsGroup
from theBiasPlanet.coreUtilities.inputs.PushableReader import PushableReader
from theBiasPlanet.coreUtilities.jsonDataHandling.ExtendedJsonDatumParseEventsHandler import ExtendedJsonDatumParseEventsHandler
from theBiasPlanet.coreUtilities.jsonDataHandling.JsonParsingTerminatedException import JsonParsingTerminatedException
from theBiasPlanet.coreUtilities.jsonDataHandling.JsonDatumItemUnsupportedClassException import JsonDatumItemUnsupportedClassException
from theBiasPlanet.coreUtilities.jsonDataHandling.JsonDatumItemUnsupportedValueException import JsonDatumItemUnsupportedValueException
from theBiasPlanet.coreUtilities.messagingHandling.Publisher import Publisher
from theBiasPlanet.coreUtilities.pipes.StringPipe import StringPipe
from theBiasPlanet.coreUtilities.stringsHandling.StringHandler import StringHandler

class ExtendedJsonDatumParser:
	c_bufferSize: int = 1024
	c_notANumberExpressionOpener: str = GeneralConstantsConstantsGroup.c_notANumberExpression [0]
	c_positiveInfinityExpressionOpener: str = GeneralConstantsConstantsGroup.c_positiveInfinityExpression [0]
	c_negativeInfinityExpressionOpener: str = GeneralConstantsConstantsGroup.c_negativeInfinityExpression [0]
	c_nullExpressionOpener: str = GeneralConstantsConstantsGroup.c_nullExpression [0]
	c_trueExpressionOpener: str = GeneralConstantsConstantsGroup.c_trueExpression [0]
	c_falseExpressionOpener: str = GeneralConstantsConstantsGroup.c_falseExpression [0]
	c_exceptionMessageFormattingExpression: str = "character position: {0:d}"
	
	def __init__ (a_this: "ExtendedJsonDatumParser") -> None:
		a_this.i_extendedJsonDatumReader: Optional ["PushableReader"] = None
		a_this.i_parseEventsHandler: Optional ["ExtendedJsonDatumParseEventsHandler"] = None
		a_this.i_characters: List [Optional [str]] = [None] * ExtendedJsonDatumParser.c_bufferSize
		a_this.i_characterPositionIndex: int = 0
	
	# return: 'True' -> an item has been found, 'False' -> no item has been found
	def parseNextItem (a_this: "ExtendedJsonDatumParser") -> bool:
		l_readFunctionReturn: int = GeneralConstantsConstantsGroup.c_unspecifiedInteger
		l_toReadLength: int = GeneralConstantsConstantsGroup.c_unspecifiedInteger
		l_readLength: int = 0
		l_toReadLength = 1
		if a_this.i_extendedJsonDatumReader is None or a_this.i_parseEventsHandler is None:
			return False
		else:
			l_readFunctionReturn = a_this.i_extendedJsonDatumReader.readFixedLengthData (a_this.i_characters, l_readLength, l_toReadLength)
			if l_readFunctionReturn < l_toReadLength:
				return False
			l_readLength = l_readLength + l_readFunctionReturn
			a_this.i_characterPositionIndex = a_this.i_characterPositionIndex + l_readFunctionReturn
			l_matchersIterator: Optional [Iterator] = None
			l_matcher: Optional [Match [str]] = None
			l_itemValue: Optional [str] = None
			l_readData: Optional [str] = None
			if a_this.i_characters[l_readLength - 1] == GeneralConstantsConstantsGroup.c_doubleQuotationMarkCharacter:
				a_this.parseString ()
				return True
			elif a_this.i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_jsonDictionaryOpener:
				a_this.parseDictionary ()
				return True
			elif a_this.i_characters[l_readLength - 1] == GeneralConstantsConstantsGroup.c_jsonArrayOpener:
				a_this.parseArray ()
				return True
			elif a_this.i_characters [l_readLength - 1] == ExtendedJsonDatumParser.c_nullExpressionOpener or a_this.i_characters [l_readLength - 1] == ExtendedJsonDatumParser.c_trueExpressionOpener or a_this.i_characters [l_readLength - 1] == ExtendedJsonDatumParser.c_falseExpressionOpener or a_this.i_characters [l_readLength - 1] == ExtendedJsonDatumParser.c_notANumberExpressionOpener or a_this.i_characters [l_readLength - 1] == ExtendedJsonDatumParser.c_positiveInfinityExpressionOpener:
				if a_this.i_characters [l_readLength - 1] == ExtendedJsonDatumParser.c_nullExpressionOpener:
					l_itemValue = GeneralConstantsConstantsGroup.c_nullExpression
				elif a_this.i_characters [l_readLength - 1] == ExtendedJsonDatumParser.c_trueExpressionOpener:
					l_itemValue = GeneralConstantsConstantsGroup.c_trueExpression
				elif a_this.i_characters[l_readLength - 1] == ExtendedJsonDatumParser.c_falseExpressionOpener:
					l_itemValue = GeneralConstantsConstantsGroup.c_falseExpression
				elif a_this.i_characters[l_readLength - 1] == ExtendedJsonDatumParser.c_notANumberExpressionOpener:
					l_itemValue = GeneralConstantsConstantsGroup.c_notANumberExpression
				elif a_this.i_characters[l_readLength - 1] == ExtendedJsonDatumParser.c_positiveInfinityExpressionOpener:
					l_itemValue = GeneralConstantsConstantsGroup.c_positiveInfinityExpression
				if l_itemValue is not None:
					l_toReadLength = len (l_itemValue) - 1
					l_readFunctionReturn = a_this.i_extendedJsonDatumReader.readFixedLengthData (a_this.i_characters, l_readLength, l_toReadLength)
					if l_readFunctionReturn < l_toReadLength:
						raise JsonDatumItemUnsupportedValueException (ExtendedJsonDatumParser.c_exceptionMessageFormattingExpression.format (a_this.i_characterPositionIndex))
					l_readLength = l_readLength + l_readFunctionReturn
					a_this.i_characterPositionIndex = a_this.i_characterPositionIndex + l_readFunctionReturn
					if l_itemValue == StringHandler.joinListElements (str, a_this.i_characters, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength):
						if a_this.i_characters [GeneralConstantsConstantsGroup.c_iterationStartNumber] == ExtendedJsonDatumParser.c_nullExpressionOpener:
							if not (a_this.i_parseEventsHandler.onNullFound ()):
								raise JsonParsingTerminatedException ("")
							return True
						elif a_this.i_characters[GeneralConstantsConstantsGroup.c_iterationStartNumber] == ExtendedJsonDatumParser.c_trueExpressionOpener or a_this.i_characters[GeneralConstantsConstantsGroup.c_iterationStartNumber] == ExtendedJsonDatumParser.c_falseExpressionOpener:
							if not (a_this.i_parseEventsHandler.onBooleanFound (bool (l_itemValue))):
								raise JsonParsingTerminatedException ("")
							return True
						elif a_this.i_characters[GeneralConstantsConstantsGroup.c_iterationStartNumber] == ExtendedJsonDatumParser.c_notANumberExpressionOpener:
							if not (a_this.i_parseEventsHandler.onDoubleFound (math.nan)):
								raise JsonParsingTerminatedException ("")
							return True
						elif a_this.i_characters[GeneralConstantsConstantsGroup.c_iterationStartNumber] == ExtendedJsonDatumParser.c_positiveInfinityExpressionOpener:
							if not (a_this.i_parseEventsHandler.onDoubleFound (math.inf)):
								raise JsonParsingTerminatedException ("")
							return True
					else:
						raise JsonDatumItemUnsupportedValueException (ExtendedJsonDatumParser.c_exceptionMessageFormattingExpression.format (a_this.i_characterPositionIndex))
			elif a_this.i_characters[l_readLength - 1] == GeneralConstantsConstantsGroup.c_jsonDateEtcOpener:
				l_readLength = 0
				l_toReadLength = 8
				l_readFunctionReturn = a_this.i_extendedJsonDatumReader.readFixedLengthData (a_this.i_characters, l_readLength, l_toReadLength)
				if l_readFunctionReturn < l_toReadLength:
					raise JsonDatumItemUnsupportedValueException (ExtendedJsonDatumParser.c_exceptionMessageFormattingExpression.format (a_this.i_characterPositionIndex))
				l_readLength = l_readLength + l_readFunctionReturn
				a_this.i_characterPositionIndex = a_this.i_characterPositionIndex + l_readFunctionReturn
				l_readData = StringHandler.joinListElements (str, a_this.i_characters, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength)
				l_matchersIterator = RegularExpressionsConstantsGroup.c_timesRegularExpression.finditer (l_readData)
				for l_matcher in l_matchersIterator:
					if not (a_this.i_parseEventsHandler.onLocalTimeFound (parseDateAndTimeString (l_readData).time ())):
						raise JsonParsingTerminatedException ("")
					return True
				l_toReadLength = 3
				l_readFunctionReturn = a_this.i_extendedJsonDatumReader.readFixedLengthData (a_this.i_characters, l_readLength, l_toReadLength)
				if l_readFunctionReturn < l_toReadLength - 1:
					raise JsonDatumItemUnsupportedValueException (ExtendedJsonDatumParser.c_exceptionMessageFormattingExpression.format (a_this.i_characterPositionIndex))
				if l_readFunctionReturn == l_toReadLength and a_this.i_characters [l_readLength + l_readFunctionReturn - 1] != GeneralConstantsConstantsGroup.c_jsonDateAndTimeTimePartOpener:
					a_this.i_extendedJsonDatumReader.pushData (a_this.i_characters, l_readLength + l_readFunctionReturn - 1, 1)
					l_readLength = l_readLength + (l_readFunctionReturn - 1)
					a_this.i_characterPositionIndex = a_this.i_characterPositionIndex + (l_readFunctionReturn - 1)
					l_readData = StringHandler.joinListElements (str, a_this.i_characters, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength)
					l_matchersIterator = RegularExpressionsConstantsGroup.c_datesRegularExpression.finditer (l_readData)
					for l_matcher in l_matchersIterator:
						if not (a_this.i_parseEventsHandler.onLocalDateFound (parseDateAndTimeString (l_readData).date ())):
							raise JsonParsingTerminatedException ("")
						return True
					else:
						raise JsonDatumItemUnsupportedValueException (ExtendedJsonDatumParser.c_exceptionMessageFormattingExpression.format (a_this.i_characterPositionIndex))
				else:
					l_readLength = l_readLength + l_readFunctionReturn
					a_this.i_characterPositionIndex = a_this.i_characterPositionIndex + l_readFunctionReturn
					l_toReadLength = 9
					l_readFunctionReturn = a_this.i_extendedJsonDatumReader.readFixedLengthData (a_this.i_characters, l_readLength, l_toReadLength)
					if l_readFunctionReturn < l_toReadLength - 1:
						raise JsonDatumItemUnsupportedValueException (ExtendedJsonDatumParser.c_exceptionMessageFormattingExpression.format (a_this.i_characterPositionIndex))
					if l_readFunctionReturn == l_toReadLength and a_this.i_characters [l_readLength + l_readFunctionReturn - 1] != GeneralConstantsConstantsGroup.c_radixPointCharacter:
						a_this.i_extendedJsonDatumReader.pushData (a_this.i_characters, l_readLength + l_readFunctionReturn - 1, 1)
						l_readLength = l_readLength + (l_readFunctionReturn - 1)
						a_this.i_characterPositionIndex = a_this.i_characterPositionIndex + (l_readFunctionReturn - 1)
					else:
						l_readLength = l_readLength + l_readFunctionReturn
						a_this.i_characterPositionIndex = a_this.i_characterPositionIndex + l_readFunctionReturn
						if l_readFunctionReturn == l_toReadLength:
							l_toReadLength = 1
							while True:
								l_readFunctionReturn = a_this.i_extendedJsonDatumReader.readFixedLengthData (a_this.i_characters, l_readLength, l_toReadLength)
								if l_readFunctionReturn == GeneralConstantsConstantsGroup.c_unspecifiedInteger:
									break
								if a_this.i_characters [l_readLength] >= GeneralConstantsConstantsGroup.c_minimumDigit and a_this.i_characters [l_readLength] <= GeneralConstantsConstantsGroup.c_maximumDigit:
									l_readLength = l_readLength + l_readFunctionReturn
									a_this.i_characterPositionIndex = a_this.i_characterPositionIndex + l_readFunctionReturn
								else:
									a_this.i_extendedJsonDatumReader.pushData (a_this.i_characters, l_readLength - 1, 1)
									break
					l_readData = StringHandler.joinListElements (str, a_this.i_characters, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength)
					l_matchersIterator = RegularExpressionsConstantsGroup.c_dateAndTimesRegularExpression.finditer (l_readData)
					for l_matcher in l_matchersIterator:
						break
						if not (a_this.i_parseEventsHandler.onLocalDateAndTimeFound (parseDateAndTimeString (l_readData).datetime ())):
							raise JsonParsingTerminatedException ("")
						return True
					else:
						raise JsonDatumItemUnsupportedValueException (ExtendedJsonDatumParser.c_exceptionMessageFormattingExpression.format (a_this.i_characterPositionIndex))
			elif a_this.i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_jsonBytesArrayOpener:
				l_readLength = 0
				l_toReadLength = 1
				l_readFunctionReturn = a_this.i_extendedJsonDatumReader.readFixedLengthData (a_this.i_characters, l_readLength, l_toReadLength)
				if l_readFunctionReturn < l_toReadLength:
					raise JsonDatumItemUnsupportedValueException (ExtendedJsonDatumParser.c_exceptionMessageFormattingExpression.format (a_this.i_characterPositionIndex))
				l_readLength = l_readLength + l_readFunctionReturn
				a_this.i_characterPositionIndex = a_this.i_characterPositionIndex + l_readFunctionReturn
				if a_this.i_characters [l_readLength - 1] != GeneralConstantsConstantsGroup.c_doubleQuotationMarkCharacter:
					raise JsonDatumItemUnsupportedValueException (ExtendedJsonDatumParser.c_exceptionMessageFormattingExpression.format (a_this.i_characterPositionIndex))
				l_stringPipe: "StringPipe" = StringPipe (ExtendedJsonDatumParser.c_bufferSize, True)
				try:
					def l_subThreadFunction () -> None:
						try:
							if not (a_this.i_parseEventsHandler.onBytesArrayFound (l_stringPipe)):
								raise JsonParsingTerminatedException ("")
						except (Exception) as l_exception:
							Publisher.logErrorInformation (l_exception)
					l_subThread: Thread = Thread (target = l_subThreadFunction)
					l_subThread.start ()
					l_readLength = 0
					l_toReadLength = 1
					while True:
						l_readFunctionReturn = a_this.i_extendedJsonDatumReader.readFixedLengthData (a_this.i_characters, l_readLength, l_toReadLength)
						if l_readFunctionReturn == GeneralConstantsConstantsGroup.c_unspecifiedInteger:
							break
						a_this.i_characterPositionIndex = a_this.i_characterPositionIndex + l_readFunctionReturn
						if a_this.i_characters [l_readLength] == GeneralConstantsConstantsGroup.c_doubleQuotationMarkCharacter:
							if l_readLength > 0:
								l_stringPipe.write_1 (a_this.i_characters, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength)
							l_stringPipe.finishWriting ()
							l_subThread.join ()
							return True
						else:
							l_readLength = l_readLength + l_readFunctionReturn
							if l_readLength == 4:
								l_stringPipe.write_1 (a_this.i_characters, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength)
								l_readLength = 0
					if l_readFunctionReturn == GeneralConstantsConstantsGroup.c_unspecifiedInteger:
						l_stringPipe.finishWriting ()
						raise JsonDatumItemUnsupportedValueException (ExtendedJsonDatumParser.c_exceptionMessageFormattingExpression.format (a_this.i_characterPositionIndex))
				finally:
					l_stringPipe.finishWriting ()
			elif (a_this.i_characters [l_readLength - 1] >= GeneralConstantsConstantsGroup.c_minimumDigit and a_this.i_characters [l_readLength - 1] <= GeneralConstantsConstantsGroup.c_maximumDigit) or a_this.i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_plusCharacter or a_this.i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_minusCharacter:
				l_readLength = 1
				l_toReadLength = 1
				if a_this.i_characters [l_readLength - 1] == ExtendedJsonDatumParser.c_negativeInfinityExpressionOpener:
					l_readFunctionReturn = a_this.i_extendedJsonDatumReader.readFixedLengthData (a_this.i_characters, l_readLength, l_toReadLength)
					if l_readFunctionReturn < l_toReadLength:
						raise JsonDatumItemUnsupportedValueException (ExtendedJsonDatumParser.c_exceptionMessageFormattingExpression.format (a_this.i_characterPositionIndex))
					l_readLength = l_readLength + l_readFunctionReturn
					a_this.i_characterPositionIndex = a_this.i_characterPositionIndex + l_readFunctionReturn
					if a_this.i_characters [l_readLength - 1] == ExtendedJsonDatumParser.c_positiveInfinityExpressionOpener:
						l_toReadLength = 7
						l_readFunctionReturn = a_this.i_extendedJsonDatumReader.readFixedLengthData (a_this.i_characters, l_readLength, l_toReadLength)
						if l_readFunctionReturn < l_toReadLength:
							raise JsonDatumItemUnsupportedValueException (ExtendedJsonDatumParser.c_exceptionMessageFormattingExpression.format (a_this.i_characterPositionIndex))
						l_readLength = l_readLength + l_readFunctionReturn
						a_this.i_characterPositionIndex = a_this.i_characterPositionIndex + l_readFunctionReturn
						l_readData = StringHandler.joinListElements (str, a_this.i_characters, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength)
						if GeneralConstantsConstantsGroup.c_negativeInfinityExpression == l_readData:
							if not (a_this.i_parseEventsHandler.onDoubleFound (-math.inf)):
								raise JsonParsingTerminatedException ("")
							return True
				while True:
					l_readFunctionReturn = a_this.i_extendedJsonDatumReader.readFixedLengthData (a_this.i_characters, l_readLength, l_toReadLength)
					if l_readFunctionReturn == GeneralConstantsConstantsGroup.c_unspecifiedInteger:
						break
					if (a_this.i_characters [l_readLength] >= GeneralConstantsConstantsGroup.c_minimumDigit and a_this.i_characters [l_readLength] <= GeneralConstantsConstantsGroup.c_maximumDigit) or a_this.i_characters [l_readLength] == GeneralConstantsConstantsGroup.c_radixPointCharacter or a_this.i_characters [l_readLength] == GeneralConstantsConstantsGroup.c_exponentOpener1 or a_this.i_characters [l_readLength] == GeneralConstantsConstantsGroup.c_exponentOpener2 or a_this.i_characters [l_readLength] == GeneralConstantsConstantsGroup.c_plusCharacter or a_this.i_characters [l_readLength] == GeneralConstantsConstantsGroup.c_minusCharacter:
						l_readLength = l_readLength + l_readFunctionReturn
						a_this.i_characterPositionIndex = a_this.i_characterPositionIndex + l_readFunctionReturn
					else:
						a_this.i_extendedJsonDatumReader.pushData (a_this.i_characters, l_readLength, 1)
						break
				l_readData = StringHandler.joinListElements (str, a_this.i_characters, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength)
				l_matchersIterator = RegularExpressionsConstantsGroup.c_numbersRegularExpression.finditer (l_readData)
				for l_matcher in l_matchersIterator:
					l_integerPart: str = l_matcher.group (1)
					l_fractionPart: str = l_matcher.group (2)
					l_exponentPart: str = l_matcher.group (3)
					if l_fractionPart is not None or l_exponentPart is not None:
						if not (a_this.i_parseEventsHandler.onDoubleFound (float (l_integerPart + (l_fractionPart if l_fractionPart is not None else "") + (l_exponentPart if l_exponentPart is not None else "")))):
							raise JsonParsingTerminatedException ("")
						return True
					else:
						if not (a_this.i_parseEventsHandler.onIntegerFound (int (l_integerPart))):
							raise JsonParsingTerminatedException ("")
						return True
				raise JsonDatumItemUnsupportedValueException (ExtendedJsonDatumParser.c_exceptionMessageFormattingExpression.format (a_this.i_characterPositionIndex))
			elif a_this.i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_jsonArrayCloser or a_this.i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_jsonDictionaryCloser:
				a_this.i_extendedJsonDatumReader.pushData (a_this.i_characters, l_readLength - 1, 1)
				return False
			else:
				raise JsonDatumItemUnsupportedValueException (ExtendedJsonDatumParser.c_exceptionMessageFormattingExpression.format (a_this.i_characterPositionIndex))
			return False
	
	def parseString (a_this: "ExtendedJsonDatumParser") -> bool:
		l_readFunctionReturn: int = GeneralConstantsConstantsGroup.c_unspecifiedInteger
		l_toReadLength: int = GeneralConstantsConstantsGroup.c_unspecifiedInteger
		l_readLength: int = 0
		l_stringChunkTerminator: Optional [str] = None
		l_originalCharacterOfEscapedCharacter: str
		l_stringPipe: "StringPipe" = StringPipe (ExtendedJsonDatumParser.c_bufferSize, True)
		try:
			l_onStringFoundReturn: List [bool] = [False]
			def l_subThreadFunction () -> None:
				try:
					l_onStringFoundReturn [GeneralConstantsConstantsGroup.c_iterationStartNumber] = a_this.i_parseEventsHandler.onStringFound (l_stringPipe)
				except (Exception) as l_exception:
					Publisher.logErrorInformation (l_exception)
			l_subThread: Thread = Thread (target = l_subThreadFunction)
			l_subThread.start ()
			while True:
				l_readLength = 0
				l_toReadLength = 1
				# reading a chunk of the string, not the whole string
				while True:
					l_readFunctionReturn = a_this.i_extendedJsonDatumReader.readFixedLengthData (a_this.i_characters, l_readLength, l_toReadLength)
					if l_readFunctionReturn == GeneralConstantsConstantsGroup.c_unspecifiedInteger:
						break
					if l_readFunctionReturn < l_toReadLength:
						raise JsonDatumItemUnsupportedValueException (ExtendedJsonDatumParser.c_exceptionMessageFormattingExpression.format (a_this.i_characterPositionIndex))
					l_readLength =  l_readLength + l_readFunctionReturn
					a_this.i_characterPositionIndex = a_this.i_characterPositionIndex + l_readFunctionReturn
					# '\x00' ~ '\x1f' are control characters that must have been escaped
					if a_this.i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_doubleQuotationMarkCharacter or a_this.i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_escapingCharacter or (a_this.i_characters [l_readLength - 1] >= GeneralConstantsConstantsGroup.c_controlCharactersStart and a_this.i_characters [l_readLength - 1] < GeneralConstantsConstantsGroup.c_controlCharactersUntil):
						l_stringChunkTerminator = a_this.i_characters [l_readLength - 1]
						break
					else:
						try:
							l_stringPipe.write_1 (a_this.i_characters, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength)
						except (Exception) as l_exception:
							Publisher.logWarningInformation (l_exception)
					l_readLength = 0
				if l_stringChunkTerminator == GeneralConstantsConstantsGroup.c_doubleQuotationMarkCharacter:
					l_stringPipe.finishWriting ()
					l_subThread.join ()
					if not l_onStringFoundReturn [GeneralConstantsConstantsGroup.c_iterationStartNumber]:
						raise JsonParsingTerminatedException ("")
					return True
				elif l_stringChunkTerminator != GeneralConstantsConstantsGroup.c_escapingCharacter:
					raise JsonDatumItemUnsupportedValueException (ExtendedJsonDatumParser.c_exceptionMessageFormattingExpression.format (a_this.i_characterPositionIndex))
				l_toReadLength = 1
				l_readFunctionReturn = a_this.i_extendedJsonDatumReader.readFixedLengthData (a_this.i_characters, l_readLength, l_toReadLength)
				if l_readFunctionReturn < l_toReadLength:
					raise JsonDatumItemUnsupportedValueException (ExtendedJsonDatumParser.c_exceptionMessageFormattingExpression.format (a_this.i_characterPositionIndex))
				l_readLength = l_readLength + l_readFunctionReturn
				a_this.i_characterPositionIndex = a_this.i_characterPositionIndex + l_readFunctionReturn
				if a_this.i_characters [l_readLength - 1] != GeneralConstantsConstantsGroup.c_unicodeEscapeIndicator:
					l_originalCharacterOfEscapedCharacter= GeneralConstantsConstantsGroup.c_escapedCharacterToCharacterMap.get (StringHandler.joinListElements (str, a_this.i_characters, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength))
					"""
					if (l_originalCharacterOfEscapedCharacter != null) {
					}
					"""
					if l_originalCharacterOfEscapedCharacter is None:
						raise JsonDatumItemUnsupportedValueException (ExtendedJsonDatumParser.c_exceptionMessageFormattingExpression.format (a_this.i_characterPositionIndex))
				else:
					l_originalCharacterOfEscapedCharacter = a_this.decodeUnicodeEscape ()
				try:
					l_stringPipe.write (l_originalCharacterOfEscapedCharacter)
				except (Exception) as l_exception:
					Publisher.logWarningInformation (l_exception)
		finally:
			l_stringPipe.finishWriting ()
	
	def decodeUnicodeEscape (a_this: "ExtendedJsonDatumParser") -> str:
		try:
			l_readFunctionReturn: int = GeneralConstantsConstantsGroup.c_unspecifiedInteger
			l_readLength: int = 0
			l_toReadLength: int = 4
			l_readFunctionReturn = a_this.i_extendedJsonDatumReader.readFixedLengthData (a_this.i_characters, l_readLength, l_toReadLength)
			if l_readFunctionReturn < l_toReadLength:
				raise JsonDatumItemUnsupportedValueException (ExtendedJsonDatumParser.c_exceptionMessageFormattingExpression.format (a_this.i_characterPositionIndex))
			l_readLength = l_readLength + l_readFunctionReturn
			a_this.i_characterPositionIndex = a_this.i_characterPositionIndex + l_readFunctionReturn
			return chr (int (StringHandler.joinListElements (str, a_this.i_characters, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength), 16))
		except (Exception) as l_exception:
			raise JsonDatumItemUnsupportedValueException (ExtendedJsonDatumParser.c_exceptionMessageFormattingExpression.format (a_this.i_characterPositionIndex))
	
	def skipWhiteSpaces (a_this: "ExtendedJsonDatumParser") -> None:
		l_readFunctionReturn: int = GeneralConstantsConstantsGroup.c_unspecifiedInteger
		l_readLength: int = 0
		l_toReadLength: int = 1
		while True:
			l_readFunctionReturn = a_this.i_extendedJsonDatumReader.readFixedLengthData (a_this.i_characters, l_readLength, l_toReadLength)
			if l_readFunctionReturn == GeneralConstantsConstantsGroup.c_unspecifiedInteger:
				break
			l_readLength = l_readLength + l_readFunctionReturn
			a_this.i_characterPositionIndex = a_this.i_characterPositionIndex + l_readFunctionReturn
			if a_this.i_characters [l_readLength - 1] != GeneralConstantsConstantsGroup.c_spaceCharacter and a_this.i_characters [l_readLength - 1] != GeneralConstantsConstantsGroup.c_tabCharacter and a_this.i_characters [l_readLength - 1] != GeneralConstantsConstantsGroup.c_newLineCharacter and a_this.i_characters [l_readLength - 1] != GeneralConstantsConstantsGroup.c_carriageReturnCharacter:
				a_this.i_extendedJsonDatumReader.pushData (a_this.i_characters, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength)
				break
			l_readLength = 0
		return
	
	def parseArray (a_this: "ExtendedJsonDatumParser") -> bool:
		l_readFunctionReturn: int = GeneralConstantsConstantsGroup.c_unspecifiedInteger
		l_toReadLength: int = GeneralConstantsConstantsGroup.c_unspecifiedInteger
		l_readLength: int = 0
		if not (a_this.i_parseEventsHandler.onArrayStarted ()):
			raise JsonParsingTerminatedException ("")
		l_itemFound: bool = False
		while True:
			a_this.skipWhiteSpaces ()
			l_itemFound = a_this.parseNextItem ()
			a_this.skipWhiteSpaces ()
			l_readLength = 0
			l_toReadLength = 1
			l_readFunctionReturn = a_this.i_extendedJsonDatumReader.readFixedLengthData (a_this.i_characters, l_readLength, l_toReadLength)
			if l_readFunctionReturn < l_toReadLength:
				raise JsonDatumItemUnsupportedValueException (ExtendedJsonDatumParser.c_exceptionMessageFormattingExpression.format (a_this.i_characterPositionIndex))
			l_readLength = l_readLength + l_readFunctionReturn
			a_this.i_characterPositionIndex = a_this.i_characterPositionIndex + l_readFunctionReturn
			if a_this.i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_jsonArrayCloser:
				if not (a_this.i_parseEventsHandler.onArrayEnded ()):
					raise JsonParsingTerminatedException ("")
				a_this.skipWhiteSpaces ()
				return True
			elif a_this.i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_jsonItemsSeparatorOpener:
				if not l_itemFound:
					raise JsonDatumItemUnsupportedValueException (ExtendedJsonDatumParser.c_exceptionMessageFormattingExpression.format (a_this.i_characterPositionIndex))
			else:
				raise JsonDatumItemUnsupportedValueException (ExtendedJsonDatumParser.c_exceptionMessageFormattingExpression.format (a_this.i_characterPositionIndex))
	
	def parseDictionary (a_this: "ExtendedJsonDatumParser") -> bool:
		if not (a_this.i_parseEventsHandler.onDictionaryStarted ()):
			raise JsonParsingTerminatedException ("")
		l_readFunctionReturn: int = GeneralConstantsConstantsGroup.c_unspecifiedInteger
		l_toReadLength: int = GeneralConstantsConstantsGroup.c_unspecifiedInteger
		l_readLength: int = 0
		l_itemFound: bool = False
		while True:
			a_this.skipWhiteSpaces ()
			l_itemFound = a_this.parseNextItem ()
			if l_itemFound:
				a_this.skipWhiteSpaces ()
				l_readLength = 0
				l_toReadLength = 1
				l_readFunctionReturn = a_this.i_extendedJsonDatumReader.readFixedLengthData (a_this.i_characters, l_readLength, l_toReadLength)
				if l_readFunctionReturn < l_toReadLength:
					raise JsonDatumItemUnsupportedValueException (ExtendedJsonDatumParser.c_exceptionMessageFormattingExpression.format (a_this.i_characterPositionIndex))
				l_readLength = l_readLength + l_readFunctionReturn
				a_this.i_characterPositionIndex = a_this.i_characterPositionIndex + l_readFunctionReturn
				if a_this.i_characters [l_readLength - 1] != ':':
					raise JsonDatumItemUnsupportedValueException (ExtendedJsonDatumParser.c_exceptionMessageFormattingExpression.format (a_this.i_characterPositionIndex))
				a_this.skipWhiteSpaces ()
				l_itemFound = a_this.parseNextItem ()
				if not l_itemFound:
					raise JsonDatumItemUnsupportedValueException (ExtendedJsonDatumParser.c_exceptionMessageFormattingExpression.format (a_this.i_characterPositionIndex))
				a_this.skipWhiteSpaces ()
			l_readLength = 0
			l_toReadLength = 1
			l_readFunctionReturn = a_this.i_extendedJsonDatumReader.readFixedLengthData (a_this.i_characters, l_readLength, l_toReadLength)
			if l_readFunctionReturn < l_toReadLength:
				raise JsonDatumItemUnsupportedValueException (ExtendedJsonDatumParser.c_exceptionMessageFormattingExpression.format (a_this.i_characterPositionIndex))
			l_readLength = l_readLength + l_readFunctionReturn
			a_this.i_characterPositionIndex = a_this.i_characterPositionIndex + l_readFunctionReturn
			if a_this.i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_jsonDictionaryCloser:
				if not (a_this.i_parseEventsHandler.onDictionaryEnded ()):
					raise JsonParsingTerminatedException ("")
				a_this.skipWhiteSpaces ()
				return True
			elif a_this.i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_jsonItemsSeparatorOpener:
				if not l_itemFound:
					raise JsonDatumItemUnsupportedValueException (ExtendedJsonDatumParser.c_exceptionMessageFormattingExpression.format (a_this.i_characterPositionIndex))
			else:
				raise JsonDatumItemUnsupportedValueException (ExtendedJsonDatumParser.c_exceptionMessageFormattingExpression.format (a_this.i_characterPositionIndex))
	
	# return: 'True' -> an item has been found, 'False' -> no item has been found
	def parse (a_this: "ExtendedJsonDatumParser", a_extendedJsonDatumReader: TextIO, a_parseEventsHandler: "ExtendedJsonDatumParseEventsHandler") -> bool:
		a_this.i_extendedJsonDatumReader = PushableReader (a_extendedJsonDatumReader, ExtendedJsonDatumParser.c_bufferSize)
		a_this.i_parseEventsHandler = a_parseEventsHandler
		a_this.i_parseEventsHandler.initialize ()
		a_this.i_characterPositionIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber
		try:
			return a_this.parseNextItem ()
		except (Exception) as l_exception:
			try:
				a_this.i_parseEventsHandler.onException (l_exception)
			except (Exception) as l_exceptionOfInnerTry:
				Publisher.logErrorInformation (l_exceptionOfInnerTry)
			raise l_exception

