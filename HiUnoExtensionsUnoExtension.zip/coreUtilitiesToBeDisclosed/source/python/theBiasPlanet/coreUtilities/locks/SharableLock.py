from typing import Optional
import threading
from threading import Condition
from threading import Thread

class SharableLock:
	def __init__ (a_this: "SharableLock") -> None:
		a_this.i_sharingLockingNumberOfTimes: int = 0
		a_this.i_exclusiveLockingThread: Optional [Thread] = None
		a_this.i_exclusiveLockingNumberOfTimes: int = 0
		a_this.i_threadCondition: Condition = Condition ()
	
	def lockSharedly (a_this: "SharableLock") -> None:
		a_this.i_threadCondition.acquire ()
		while a_this.i_exclusiveLockingNumberOfTimes > 0:
			a_this.i_threadCondition.wait ()
		a_this.i_sharingLockingNumberOfTimes = a_this.i_sharingLockingNumberOfTimes + 1
		a_this.i_threadCondition.release ()
	
	def lockExclusively (a_this: "SharableLock") -> None:
		a_this.i_threadCondition.acquire ()
		while a_this.i_sharingLockingNumberOfTimes > 0 or (a_this.i_exclusiveLockingThread is not None and threading.current_thread () != a_this.i_exclusiveLockingThread):
			a_this.i_threadCondition.wait ()
		if a_this.i_exclusiveLockingThread is None:
			a_this.i_exclusiveLockingThread = threading.current_thread ()
		a_this.i_exclusiveLockingNumberOfTimes = a_this.i_exclusiveLockingNumberOfTimes + 1
		a_this.i_threadCondition.release ()
	
	def unlockSharedly (a_this: "SharableLock") -> None:
		a_this.i_threadCondition.acquire ()
		if a_this.i_sharingLockingNumberOfTimes > 0:
			a_this.i_sharingLockingNumberOfTimes = a_this.i_sharingLockingNumberOfTimes - 1
			if a_this.i_sharingLockingNumberOfTimes == 0:
				a_this.i_threadCondition.notify_all ()
		a_this.i_threadCondition.release ()
	
	def unlockExclusively (a_this: "SharableLock") -> None:
		a_this.i_threadCondition.acquire ()
		if a_this.i_exclusiveLockingNumberOfTimes > 0:
			a_this.i_exclusiveLockingNumberOfTimes = a_this.i_exclusiveLockingNumberOfTimes - 1
			if a_this.i_exclusiveLockingNumberOfTimes == 0:
				a_this.i_exclusiveLockingThread = None
				a_this.i_threadCondition.notify_all ()
		a_this.i_threadCondition.release ()

