import sys
from theBiasPlanet.coreUtilities.constantsGroups.DefaultValuesConstantsGroup import DefaultValuesConstantsGroup
from theBiasPlanet.coreUtilities.inputs.HaltableReader import HaltableReader

class HaltableStandardInputReader (HaltableReader):
	s_singletonInstance: "HaltableStandardInputReader" = None
	
	def __init__ (a_this: "HaltableStandardInputReader", a_quittingCharacter: str = None) -> None:
		
		super ().__init__ (sys.stdin, DefaultValuesConstantsGroup.c_smallBufferSize, a_quittingCharacter)
	
	@staticmethod
	def getInstance (a_quittingCharacter: str = None) -> "HaltableStandardInputReader":
		if HaltableStandardInputReader.s_singletonInstance is None:
			HaltableStandardInputReader.s_singletonInstance = HaltableStandardInputReader (a_quittingCharacter)
		return HaltableStandardInputReader.s_singletonInstance

