from typing import List
from typing import Optional
from typing import Type
from typing import TypeVar
from theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup import GeneralConstantsConstantsGroup

T = TypeVar ("T")

class ListHandler:
	@staticmethod
	def copyElements (a_type0: Type [T], a_originalList: List [Optional [T]], a_originalElementsOffset: int, a_targetList: List [Optional [T]], a_targetElementsOffset: int, a_toBecopiedLength: int) -> int:
		l_elementIndex: int = GeneralConstantsConstantsGroup.c_iterationStartNumber
		l_copiedLength: int = min (a_toBecopiedLength, len (a_originalList) - a_originalElementsOffset, len (a_targetList) - a_targetElementsOffset)
		for l_elementIndex in range (GeneralConstantsConstantsGroup.c_iterationStartNumber, l_copiedLength):
			a_targetList [a_targetElementsOffset + l_elementIndex] = a_originalList [a_originalElementsOffset + l_elementIndex]
		return l_elementIndex

