from typing import List
from typing import Optional
import xml.sax.saxutils
from xml.sax.xmlreader import AttributesImpl
from theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup import GeneralConstantsConstantsGroup

class XmlDatumHandler:
	@staticmethod
	def getElementOpenString (a_elementName: str, a_attributes: AttributesImpl) -> str:
		l_attributeStrings: List [str] = []
		l_attributeName: Optional [str] = None
		for l_attributeName in a_attributes.getNames ():
			l_attributeStrings.append ("{0:s}={1:s}".format (l_attributeName, xml.sax.saxutils.quoteattr (a_attributes.getValue (l_attributeName))))
		l_attributesString = " ".join (l_attributeStrings)
		return GeneralConstantsConstantsGroup.c_quotedByAngleBracketsFormat.format ("{0:s} {1:s}".format (a_elementName, l_attributesString))
	
	@staticmethod
	def getElementCloseString (a_elementName: str) -> str:
		return GeneralConstantsConstantsGroup.c_quotedByAngleBracketsFormat.format ("/{0:s}".format (a_elementName))

