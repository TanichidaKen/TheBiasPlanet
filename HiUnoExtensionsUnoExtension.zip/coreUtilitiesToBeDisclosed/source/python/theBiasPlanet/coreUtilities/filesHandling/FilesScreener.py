
class FilesScreener:
	def screen (a_this: "FilesScreener", a_fileAbsolutePath: str) -> bool:
		return False

