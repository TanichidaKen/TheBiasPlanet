
class FileProcessor:
	def process (a_this: "FileProcessor", a_fileAbsolutePath: str) -> None:
		None

