from typing import List
from typing import Optional
import fnmatch
import os.path
from theBiasPlanet.coreUtilities.filesHandling.FilesScreener import FilesScreener

class FilesScreenerForGlobExpressionsFileName (FilesScreener):
	def __init__ (a_this: "FilesScreenerForGlobExpressionsFileName", a_baseDirectoryAbsolutePath: str, a_globExpressions: List [str]) -> None:
		a_this.i_normalizedBaseDirectoryAbsolutePath: str = os.path.normpath (a_baseDirectoryAbsolutePath)
		a_this.i_normalizedGlobExpressions: Optional [List [str]] = None
		if a_globExpressions is not None:
			a_this.i_normalizedGlobExpressions = []
			l_globExpression: Optional [str] = None
			for l_globExpression in a_globExpressions:
				a_this.i_normalizedGlobExpressions.append (os.path.normpath (l_globExpression))
	
	def __del__ (a_this: "FilesScreenerForGlobExpressionsFileName") -> None:
		None
	
	def screen (a_this: "FilesScreenerForGlobExpressionsFileName", a_fileAbsolutePath: str) -> bool:
		l_normalizedFileRelativePath: str = os.path.normpath (os.path.relpath (a_fileAbsolutePath, a_this.i_normalizedBaseDirectoryAbsolutePath))
		if os.path.isfile (a_fileAbsolutePath):
			l_normalizedGlobExpression: str = None
			for l_normalizedGlobExpression in a_this.i_normalizedGlobExpressions:
				if fnmatch.fnmatch (l_normalizedFileRelativePath, l_normalizedGlobExpression):
					return True
			return False
		else:
			return False

