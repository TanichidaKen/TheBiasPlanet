from typing import List
from typing import Optional
import os
from theBiasPlanet.coreUtilities.filesHandling.FileProcessor import FileProcessor
from theBiasPlanet.coreUtilities.filesHandling.FilesScreener import FilesScreener

class FilesVisitor:
	def __init__ (a_this: "FilesVisitor", a_filesScreeners: Optional [List ["FilesScreener"]], a_fileProcessors: Optional [List ["FileProcessor"]]) -> None:
		a_this.i_filesScreeners: Optional [List ["FilesScreener"]] = a_filesScreeners
		a_this.i_fileProcessors: Optional [List ["FileProcessor"]] = a_fileProcessors
		a_this.i_numberOfSuccessfullyProcessedFiles: int = 0
	
	def walkFilesTree (a_this: "FilesVisitor", a_baseDirectoryPath: str) -> None:
		l_directoryPath: Optional [str] = None
		l_containedDirectoryPaths: Optional [List [str]] = None
		l_containedFileNames: Optional [List [str]] = None
		for l_directoryPath, l_containedDirectoryPaths, l_containedFileNames in os.walk (a_baseDirectoryPath):
			l_containedFileName: Optional [str] = None
			for l_containedFileName in l_containedFileNames:
				l_filePath: str = l_directoryPath + os.sep + l_containedFileName
				l_fileIsSelected: bool = True
				if a_this.i_filesScreeners is not None:
					l_filesScreener: Optional ["FilesScreener"] = None
					for l_filesScreener in a_this.i_filesScreeners:
						if not (l_filesScreener.screen (l_filePath)):
							l_fileIsSelected = False
				if l_fileIsSelected:
					if a_this.i_fileProcessors is not None:
						l_fileProcessor: Optional ["FileProcessor"] = None
						for l_fileProcessor in a_this.i_fileProcessors:
							l_fileProcessor.process (l_filePath)
						a_this.i_numberOfSuccessfullyProcessedFiles = a_this.i_numberOfSuccessfullyProcessedFiles + 1
	
	def getNumberOfSuccessfullyProcessedFiles (a_this: "FilesVisitor") -> int:
		return a_this.i_numberOfSuccessfullyProcessedFiles

