from typing import List
import os.path
from theBiasPlanet.coreUtilities.filesHandling.FileProcessor import FileProcessor

class FileProcessorForRememberingFilePaths (FileProcessor):
	def __init__ (a_this: "FileProcessorForRememberingFilePaths", a_relativePathsAreRemembered: bool, a_baseDirectoryAbsolutePath: str) -> None:
		a_this.i_filePaths: List [str] = []
		a_this.i_relativePathsAreRemembered: bool = a_relativePathsAreRemembered
		a_this.i_baseDirectoryAbsolutePath: str = a_baseDirectoryAbsolutePath
	
	def __del__ (a_this: "FileProcessorForRememberingFilePaths") -> None:
		None
	
	def process (a_this: "FileProcessorForRememberingFilePaths", a_fileAbsolutePath: str) -> None:
		if a_this.i_relativePathsAreRemembered:
			a_this.i_filePaths.append (os.path.relpath (a_fileAbsolutePath, a_this.i_baseDirectoryAbsolutePath))
		else:
			a_this.i_filePaths.append (a_fileAbsolutePath)
	
	def getFilePaths (a_this: "FileProcessorForRememberingFilePaths") -> List [str]:
		return a_this.i_filePaths

