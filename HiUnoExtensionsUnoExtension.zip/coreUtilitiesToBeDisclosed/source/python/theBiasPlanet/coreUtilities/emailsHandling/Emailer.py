from typing import List
from typing import Optional
from typing import BinaryIO
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import email.encoders
import os
from smtplib import SMTP
from smtplib import SMTP_SSL
from ssl import SSLContext
import ssl
from theBiasPlanet.coreUtilities.messagingHandling.Publisher import Publisher

class Emailer:
	def __init__ (a_this: "Emailer", a_userName: str, a_userEmailAddress: str, a_smtpServerName: str, a_smtpServerPortNumber: int, a_smtpServerPassword: str, a_popServerName: str, a_popServerPortNumber: int, a_popServerPassword: str, a_usesTsl: bool = True) -> None:
		a_this.i_userName: str
		a_this.i_userEmailAddress: str
		a_this.i_smtpServerName: str
		a_this.i_smtpServerPortNumber: int
		a_this.i_smtpServerPassword: str
		a_this.i_popServerName: str
		a_this.i_popServerPortNumber: int
		a_this.i_popServerPassword: str
		a_this.i_sslContext: Optional [SSLContext] = None
		a_this.i_smtpServer: SMTP
		a_this.i_usesTsl: bool
		
		a_this.i_userName = a_userName
		a_this.i_userEmailAddress = a_userEmailAddress
		a_this.i_smtpServerName = a_smtpServerName
		a_this.i_smtpServerPortNumber = a_smtpServerPortNumber
		a_this.i_smtpServerPassword = a_smtpServerPassword
		a_this.i_popServerName = a_popServerName
		a_this.i_popServerPortNumber = a_popServerPortNumber
		a_this.i_popServerPassword = a_popServerPassword
		a_this.i_usesTsl = a_usesTsl
		if a_this.i_usesTsl:
			a_this.i_sslContext = ssl.create_default_context ()
			a_this.i_smtpServer = SMTP_SSL (a_this.i_smtpServerName, a_this.i_smtpServerPortNumber, context = a_this.i_sslContext)
		else:
			a_this.i_smtpServer = SMTP (a_this.i_smtpServerName, a_this.i_smtpServerPortNumber)
	
	def connectToSmtpServer (a_this: "Emailer") -> bool:
		try:
			a_this.i_smtpServer.login (a_this.i_userName, a_this.i_smtpServerPassword)
			return True
		except (Exception) as l_exception:
			return False
	
	def disconnectFromSmtpServer (a_this: "Emailer") -> bool:
		try:
			a_this.i_smtpServer.quit ()
			return True
		except (Exception) as l_exception:
			return False
	
	def sendEmail (a_this: "Emailer", a_destinationEmailAddresses: List [str], a_carbonCopyEmailAddresses: List [str], a_subject: str, a_message: str, a_attachedFilePaths: List [str]) -> bool:
		l_destinationEmailAddressesString: str = ", ".join (a_destinationEmailAddresses)
		l_email: MIMEMultipart = MIMEMultipart ()
		l_email ["From"] = a_this.i_userEmailAddress
		l_email ["To"] = l_destinationEmailAddressesString
		l_email ["Subject"] = a_subject
		if a_carbonCopyEmailAddresses is not None:
			l_email ["Bcc"] = ", ".join (a_carbonCopyEmailAddresses)
		l_email.attach (MIMEText (a_message, "plain"))
		if a_attachedFilePaths is not None:
			l_attachedFilePath: str
			for l_attachedFilePath in a_attachedFilePaths:
				l_fileReader: Optional [BinaryIO] = None
				try:
					l_fileReader = open (l_attachedFilePath, "rb")
					l_mimeBase: MIMEBase = MIMEBase ("application", "octet-stream")
					l_mimeBase.set_payload (l_fileReader.read ())
					email.encoders.encode_base64 (l_mimeBase)
					l_mimeBase.add_header ("Content-Disposition", "attachment; filename= {0:s}".format (os.path.basename (l_attachedFilePath)))
					l_email.attach (l_mimeBase)
				except (Exception) as l_exception:
					Publisher.logErrorInformation (l_exception)
					return False
				finally:
					if l_fileReader is not None:
						l_fileReader.close ()
		try:
			a_this.i_smtpServer.sendmail (a_this.i_userEmailAddress, l_destinationEmailAddressesString, l_email.as_string())
		except (Exception) as l_exception:
			Publisher.logErrorInformation (l_exception)
			return False
		return True

