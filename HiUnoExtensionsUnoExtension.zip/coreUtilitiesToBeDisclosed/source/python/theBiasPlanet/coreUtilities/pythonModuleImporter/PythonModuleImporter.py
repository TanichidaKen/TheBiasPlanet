from typing import Optional
from collections import OrderedDict
from importlib.abc import SourceLoader
import sys
from types import ModuleType

class PythonModuleImporter:
	s_pythonModuleNameToPythonModuleMap: "OrderedDict [str, ModuleType]" = OrderedDict ()
	
	@staticmethod
	def importModule (a_pythonSourceLoader: SourceLoader, a_pythonModuleName: str, a_setModuleProperties: "Optional [OrderedDict [str, object]]") -> ModuleType:
		l_pythonModule: ModuleType = None
		try:
			l_pythonModule = PythonModuleImporter.s_pythonModuleNameToPythonModuleMap [a_pythonModuleName]
		except (KeyError) as l_exception:
			l_pythonModule = ModuleType (a_pythonModuleName)
			l_propertyName: str
			l_propertyValue: object
			for l_propertyName, l_propertyValue in a_setModuleProperties.items ():
				l_pythonModule.__dict__ [l_propertyName] = l_propertyValue
			a_pythonSourceLoader.exec_module (l_pythonModule)
			sys.modules [a_pythonModuleName] = l_pythonModule
			PythonModuleImporter.s_pythonModuleNameToPythonModuleMap [a_pythonModuleName] = l_pythonModule
		return l_pythonModule

