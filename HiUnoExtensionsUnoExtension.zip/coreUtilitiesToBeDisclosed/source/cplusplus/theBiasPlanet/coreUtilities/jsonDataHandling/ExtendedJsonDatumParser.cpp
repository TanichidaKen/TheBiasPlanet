#include "theBiasPlanet/coreUtilities/jsonDataHandling/ExtendedJsonDatumParser.hpp"
#include <iomanip>
#include <limits>
#include <regex>
#include <stdexcept>
#include <thread>
#include "theBiasPlanet/coreUtilities/collections/NavigableLinkedMap.hpp"
#include "theBiasPlanet/coreUtilities/constantsGroups/RegularExpressionsConstantsGroup.hpp"
#include "theBiasPlanet/coreUtilities/jsonDataHandling/TerminatedException.hpp"
#include "theBiasPlanet/coreUtilities/jsonDataHandling/UnsupportedClassException.hpp"
#include "theBiasPlanet/coreUtilities/jsonDataHandling/UnsupportedValueException.hpp"
#include "theBiasPlanet/coreUtilities/messagingHandling/Publisher.hpp"
#include "theBiasPlanet/coreUtilities/stringsHandling/StringHandler.hpp"

using namespace ::theBiasPlanet::coreUtilities::messagingHandling;
using namespace ::theBiasPlanet::coreUtilities::stringsHandling;

namespace theBiasPlanet {
	namespace coreUtilities {
		namespace jsonDataHandling {
			ExtendedJsonDatumParser::ExtendedJsonDatumParser (): i_characters (new char [c_bufferSize]) {
			}
			
			ExtendedJsonDatumParser::~ExtendedJsonDatumParser () {
				delete [] i_characters;
			}
			
			bool ExtendedJsonDatumParser::parseNextItem () {
				int l_readFunctionReturn = GeneralConstantsConstantsGroup::c_unspecifiedInteger;
				int l_toReadLength = GeneralConstantsConstantsGroup::c_unspecifiedInteger;
				int l_readLength = 0;
				l_toReadLength = 1;
				l_readFunctionReturn = i_extendedJsonDatumReader->readFixedLengthData (i_characters, l_readLength, l_toReadLength);
				if (l_readFunctionReturn < l_toReadLength) {
					return false;
				}
				l_readLength += l_readFunctionReturn;
				i_characterPositionIndex += l_readFunctionReturn;
				smatch l_matcher;
				string l_itemValue;
				string l_readData;
				if (i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup::c_doubleQuotationMarkCharacter) {
					parseString ();
					return true;
				}
				else if (i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup::c_jsonDictionaryOpener) {
					parseDictionary ();
					return true;
				}
				else if (i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup::c_jsonArrayOpener) {
					parseArray ();
					return true;
				}
				else if (i_characters [l_readLength - 1] == c_nullExpressionOpener || i_characters [l_readLength - 1] == c_trueExpressionOpener || i_characters [l_readLength - 1] == c_falseExpressionOpener || i_characters [l_readLength - 1] == c_notANumberExpressionOpener || i_characters [l_readLength - 1] == c_positiveInfinityExpressionOpener) {
					if (i_characters [l_readLength - 1] == c_nullExpressionOpener) {
						l_itemValue = GeneralConstantsConstantsGroup::c_nullExpression;
					}
					else if (i_characters [l_readLength - 1] == c_trueExpressionOpener) {
						l_itemValue = GeneralConstantsConstantsGroup::c_trueExpression;
					}
					else if (i_characters [l_readLength - 1] == c_falseExpressionOpener) {
						l_itemValue = GeneralConstantsConstantsGroup::c_falseExpression;
					}
					else if (i_characters [l_readLength - 1] == c_notANumberExpressionOpener) {
						l_itemValue = GeneralConstantsConstantsGroup::c_notANumberExpression;
					}
					else if (i_characters [l_readLength - 1] == c_positiveInfinityExpressionOpener) {
						l_itemValue = GeneralConstantsConstantsGroup::c_positiveInfinityExpression;
					}
					l_toReadLength = l_itemValue.length () - 1;
					l_readFunctionReturn = i_extendedJsonDatumReader->readFixedLengthData (i_characters, l_readLength, l_toReadLength);
					if (l_readFunctionReturn < l_toReadLength) {
						throw UnsupportedValueException (StringHandler::format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
					}
					l_readLength += l_readFunctionReturn;
					i_characterPositionIndex += l_readFunctionReturn;
					if (l_itemValue == string (i_characters, GeneralConstantsConstantsGroup::c_iterationStartNumber, l_readLength)) {
						if (i_characters [GeneralConstantsConstantsGroup::c_iterationStartNumber] == c_nullExpressionOpener) {
							if (! (i_parseEventsHandler->onNullFound ())) {
								throw TerminatedException ("");
							}
							return true;
						}
						else if (i_characters [GeneralConstantsConstantsGroup::c_iterationStartNumber] == c_trueExpressionOpener || i_characters [GeneralConstantsConstantsGroup::c_iterationStartNumber] == c_falseExpressionOpener) {
							if (! (i_parseEventsHandler->onBooleanFound (l_itemValue == GeneralConstantsConstantsGroup::c_trueExpression))) {
								throw TerminatedException ("");
							}
							return true;
						}
						else if (i_characters [GeneralConstantsConstantsGroup::c_iterationStartNumber] == c_notANumberExpressionOpener) {
							if (! (i_parseEventsHandler->onDoubleFound (numeric_limits <double>::quiet_NaN()))) {
								throw TerminatedException ("");
							}
							return true;
						}
						else if (i_characters [GeneralConstantsConstantsGroup::c_iterationStartNumber] == c_positiveInfinityExpressionOpener) {
							if (! (i_parseEventsHandler->onDoubleFound (numeric_limits <double>::infinity ()))) {
								throw TerminatedException ("");
							}
							return true;
						}
					}
					else {
						throw UnsupportedValueException (StringHandler::format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
					}
				}
				else if (i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup::c_jsonDateEtcOpener) {
					l_readLength = 0;
					l_toReadLength = 8;
					l_readFunctionReturn = i_extendedJsonDatumReader->readFixedLengthData (i_characters, l_readLength, l_toReadLength);
					if (l_readFunctionReturn < l_toReadLength) {
						throw UnsupportedValueException (StringHandler::format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
					}
					l_readLength += l_readFunctionReturn;
					i_characterPositionIndex += l_readFunctionReturn;
					l_readData = string (i_characters, GeneralConstantsConstantsGroup::c_iterationStartNumber, l_readLength);
					string::const_iterator l_readDataIteratorAtStart (l_readData.cbegin ());
					string::const_iterator l_readDataIteratorAtEnd (l_readData.cend ());
					tm l_time;
					if (regex_search (l_readDataIteratorAtStart, l_readDataIteratorAtEnd, l_matcher, RegularExpressionsConstantsGroup::c_timesRegularExpression)) {
						stringstream l_stringStream (l_readData);
						l_stringStream >> get_time (&l_time, GeneralConstantsConstantsGroup::c_isoTimeExpression.c_str ());
						if (! (i_parseEventsHandler->onLocalTimeFound (system_clock::from_time_t (mktime (&l_time))))) {
							throw TerminatedException ("");
						}
						return true;
					}
					l_toReadLength = 3;
					l_readFunctionReturn = i_extendedJsonDatumReader->readFixedLengthData (i_characters, l_readLength, l_toReadLength);
					if (l_readFunctionReturn < l_toReadLength - 1) {
						throw UnsupportedValueException (StringHandler::format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
					}
					if (l_readFunctionReturn == l_toReadLength && i_characters [l_readLength + l_readFunctionReturn - 1] != GeneralConstantsConstantsGroup::c_jsonDateAndTimeTimePartOpener) {
						i_extendedJsonDatumReader->pushData (i_characters, l_readLength + l_readFunctionReturn - 1, 1);
						l_readLength += (l_readFunctionReturn - 1);
						i_characterPositionIndex += (l_readFunctionReturn - 1);
						l_readData = string (i_characters, GeneralConstantsConstantsGroup::c_iterationStartNumber, l_readLength);
						string::const_iterator l_readDataIteratorAtStart (l_readData.cbegin ());
						string::const_iterator l_readDataIteratorAtEnd (l_readData.cend ());
						tm l_time;
						if (regex_search (l_readDataIteratorAtStart, l_readDataIteratorAtEnd, l_matcher, RegularExpressionsConstantsGroup::c_datesRegularExpression)) {
							stringstream l_stringStream (l_readData);
							l_stringStream >> get_time (&l_time, GeneralConstantsConstantsGroup::c_isoDateExpression.c_str ());
							if (! (i_parseEventsHandler->onLocalDateFound (system_clock::from_time_t (mktime (&l_time))))) {
								throw TerminatedException ("");
							}
							return true;
						}
						else {
							throw UnsupportedValueException (StringHandler::format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
						}
					}
					else {
						l_readLength += l_readFunctionReturn;
						i_characterPositionIndex += l_readFunctionReturn;
						l_toReadLength = 9;
						l_readFunctionReturn = i_extendedJsonDatumReader->readFixedLengthData (i_characters, l_readLength, l_toReadLength);
						if (l_readFunctionReturn < l_toReadLength - 1) {
							throw UnsupportedValueException (StringHandler::format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
						}
						if (l_readFunctionReturn == l_toReadLength && i_characters [l_readLength + l_readFunctionReturn - 1] != GeneralConstantsConstantsGroup::c_radixPointCharacter) {
							i_extendedJsonDatumReader->pushData (i_characters, l_readLength + l_readFunctionReturn - 1, 1);
							l_readLength += (l_readFunctionReturn - 1);
							i_characterPositionIndex += (l_readFunctionReturn - 1);
						}
						else {
							l_readLength += l_readFunctionReturn;
							i_characterPositionIndex += l_readFunctionReturn;
							if (l_readFunctionReturn == l_toReadLength) {
								l_toReadLength = 1;
								while ((l_readFunctionReturn = i_extendedJsonDatumReader->readFixedLengthData (i_characters, l_readLength, l_toReadLength)) != GeneralConstantsConstantsGroup::c_unspecifiedInteger) {
									if (i_characters [l_readLength] >= GeneralConstantsConstantsGroup::c_minimumDigit && i_characters [l_readLength] <= GeneralConstantsConstantsGroup::c_maximumDigit) {
										l_readLength += l_readFunctionReturn;
										i_characterPositionIndex += l_readFunctionReturn;
									}
									else {
										i_extendedJsonDatumReader->pushData (i_characters, l_readLength - 1, 1);
										break;
									}
								}
							}
						}
						l_readData = string (i_characters, GeneralConstantsConstantsGroup::c_iterationStartNumber, l_readLength);
						string::const_iterator l_readDataIteratorAtStart (l_readData.cbegin ());
						string::const_iterator l_readDataIteratorAtEnd (l_readData.cend ());
						tm l_time;
						if (regex_search (l_readDataIteratorAtStart, l_readDataIteratorAtEnd, l_matcher, RegularExpressionsConstantsGroup::c_dateAndTimesRegularExpression)) {
							stringstream l_stringStream (l_readData);
							l_stringStream >> get_time (&l_time, GeneralConstantsConstantsGroup::c_isoDateAndTimeExpression.c_str ());
							if (! (i_parseEventsHandler->onLocalDateAndTimeFound  (system_clock::from_time_t (mktime (&l_time))))) {
								throw TerminatedException ("");
							}
							return true;
						}
						else {
							throw UnsupportedValueException (StringHandler::format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
						}
					}
				}
				else if (i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup::c_jsonBytesArrayOpener) {
					l_readLength = 0;
					l_toReadLength = 1;
					l_readFunctionReturn = i_extendedJsonDatumReader->readFixedLengthData (i_characters, l_readLength, l_toReadLength);
					if (l_readFunctionReturn < l_toReadLength) {
						throw UnsupportedValueException (StringHandler::format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
					}
					l_readLength += l_readFunctionReturn;
					i_characterPositionIndex += l_readFunctionReturn;
					if (i_characters [l_readLength - 1] != GeneralConstantsConstantsGroup::c_doubleQuotationMarkCharacter) {
						throw UnsupportedValueException (StringHandler::format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
					}
					StringPipe l_stringPipe (c_bufferSize, true);
					try {
						thread l_subThread = thread ( [this, &l_stringPipe] () -> void {
							try {
								if (! (i_parseEventsHandler->onBytesArrayFound (&l_stringPipe))) {
									throw TerminatedException ("");
								}
							}
							catch (exception & l_exception) {
								Publisher::logErrorInformation (l_exception);
							}
						});
						l_readLength = 0;
						l_toReadLength = 1;
						while ((l_readFunctionReturn = i_extendedJsonDatumReader->readFixedLengthData (i_characters, l_readLength, l_toReadLength)) != GeneralConstantsConstantsGroup::c_unspecifiedInteger) {
							i_characterPositionIndex += l_readFunctionReturn;
							if (i_characters [l_readLength] == GeneralConstantsConstantsGroup::c_doubleQuotationMarkCharacter) {
								if (l_readLength > 0) {
									l_stringPipe.write (i_characters, GeneralConstantsConstantsGroup::c_iterationStartNumber, l_readLength);
								}
								l_stringPipe.finishWriting ();
								l_subThread.join ();
								return true;
							}
							else {
								l_readLength += l_readFunctionReturn;
								if (l_readLength == 4) {
									l_stringPipe.write (i_characters, GeneralConstantsConstantsGroup::c_iterationStartNumber, l_readLength);
									l_readLength = 0;
								}
							}
						}
						if (l_readFunctionReturn == GeneralConstantsConstantsGroup::c_unspecifiedInteger) {
							l_stringPipe.finishWriting ();
							throw UnsupportedValueException (StringHandler::format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
						}
					}
					catch (exception & l_exception) {
					}
					l_stringPipe.finishWriting ();
				}
				else if ((i_characters [l_readLength - 1] >= GeneralConstantsConstantsGroup::c_minimumDigit && i_characters [l_readLength - 1] <= GeneralConstantsConstantsGroup::c_maximumDigit) || i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup::c_plusCharacter || i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup::c_minusCharacter) {
					l_readLength = 1;
					l_toReadLength = 1;
					if (i_characters [l_readLength - 1] == c_negativeInfinityExpressionOpener) {
						l_readFunctionReturn = i_extendedJsonDatumReader->readFixedLengthData (i_characters, l_readLength, l_toReadLength);
						if (l_readFunctionReturn < l_toReadLength) {
							throw UnsupportedValueException (StringHandler::format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
						}
						l_readLength += l_readFunctionReturn;
						i_characterPositionIndex += l_readFunctionReturn;
						if (i_characters [l_readLength - 1] == c_positiveInfinityExpressionOpener) {
							l_toReadLength = 7;
							l_readFunctionReturn = i_extendedJsonDatumReader->readFixedLengthData (i_characters, l_readLength, l_toReadLength);
							if (l_readFunctionReturn < l_toReadLength) {
								throw UnsupportedValueException (StringHandler::format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
							}
							l_readLength += l_readFunctionReturn;
							i_characterPositionIndex += l_readFunctionReturn;
							l_readData = string (i_characters, GeneralConstantsConstantsGroup::c_iterationStartNumber, l_readLength);
							if (GeneralConstantsConstantsGroup::c_negativeInfinityExpression == l_readData) {
								if (! (i_parseEventsHandler->onDoubleFound (-1 * numeric_limits <double>::infinity ()))) {
									throw TerminatedException ("");
								}
								return true;
							}
						}
					}
					while ((l_readFunctionReturn = i_extendedJsonDatumReader->readFixedLengthData (i_characters, l_readLength, l_toReadLength)) != GeneralConstantsConstantsGroup::c_unspecifiedInteger) {
						if ((i_characters [l_readLength] >= GeneralConstantsConstantsGroup::c_minimumDigit && i_characters [l_readLength] <= GeneralConstantsConstantsGroup::c_maximumDigit) || i_characters [l_readLength] == GeneralConstantsConstantsGroup::c_radixPointCharacter || i_characters [l_readLength] == GeneralConstantsConstantsGroup::c_exponentOpener1 || i_characters [l_readLength] == GeneralConstantsConstantsGroup::c_exponentOpener2 || i_characters [l_readLength] == GeneralConstantsConstantsGroup::c_plusCharacter || i_characters [l_readLength] == GeneralConstantsConstantsGroup::c_minusCharacter) {
							l_readLength += l_readFunctionReturn;
							i_characterPositionIndex += l_readFunctionReturn;
						}
						else {
							i_extendedJsonDatumReader->pushData (i_characters, l_readLength, 1);
							break;
						}
					}
					l_readData = string (i_characters, GeneralConstantsConstantsGroup::c_iterationStartNumber, l_readLength);
					string::const_iterator l_readDataIteratorAtStart (l_readData.cbegin ());
					string::const_iterator l_readDataIteratorAtEnd (l_readData.cend ());
					if (regex_search (l_readDataIteratorAtStart, l_readDataIteratorAtEnd, l_matcher, RegularExpressionsConstantsGroup::c_numbersRegularExpression)) {
						string l_integerPart (l_matcher [1]);
						string l_fractionPart (l_matcher [2]);
						string l_exponentPart (l_matcher [3]);
						if (l_fractionPart != GeneralConstantsConstantsGroup::c_emptyString || l_exponentPart != GeneralConstantsConstantsGroup::c_emptyString) {
							if (! (i_parseEventsHandler->onDoubleFound (stod (l_integerPart + l_fractionPart + l_exponentPart)))) {
								throw TerminatedException ("");
							}
							return true;
						}
						else {
							if (! (i_parseEventsHandler->onIntegerFound (stoi (l_integerPart)))) {
								throw TerminatedException ("");
							}
							return true;
						}
					}
					else {
						throw UnsupportedValueException (StringHandler::format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
					}
				}
				else if (i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup::c_jsonArrayCloser || i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup::c_jsonDictionaryCloser) {
					i_extendedJsonDatumReader->pushData (i_characters, l_readLength - 1, 1);
					return false;
				}
				else {
					throw UnsupportedValueException (StringHandler::format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
				}
				return false;
			}
			
			bool ExtendedJsonDatumParser::parseString () {
				int l_readFunctionReturn = GeneralConstantsConstantsGroup::c_unspecifiedInteger;
				int l_toReadLength = GeneralConstantsConstantsGroup::c_unspecifiedInteger;
				int l_readLength = 0;
				int l_stringChunkTerminator= GeneralConstantsConstantsGroup::c_unspecifiedInteger;
				string l_originalCharacterOfEscapedCharacter;
				StringPipe l_stringPipe (c_bufferSize, true);
				try {
					bool l_onStringFoundReturn [] = {false};
					thread l_subThread = thread ( [this, &l_stringPipe, &l_onStringFoundReturn] () -> void {
						try {
							l_onStringFoundReturn [GeneralConstantsConstantsGroup::c_iterationStartNumber] = i_parseEventsHandler->onStringFound (&l_stringPipe);
						}
						catch (exception & l_exception) {
							Publisher::logErrorInformation (l_exception);
						}
					});
					while (true) {
						l_readLength = 0;
						l_toReadLength = 1;
						// reading a chunk of the string, not the whole string
						while ((l_readFunctionReturn = i_extendedJsonDatumReader->readFixedLengthData (i_characters, l_readLength, l_toReadLength)) != GeneralConstantsConstantsGroup::c_unspecifiedInteger) {
							if (l_readFunctionReturn < l_toReadLength) {
								throw UnsupportedValueException (StringHandler::format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
							}
							l_readLength += l_readFunctionReturn;
							i_characterPositionIndex += l_readFunctionReturn;
							// '\x00' ~ '\x1f' are control characters that must have been escaped
							if (i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup::c_doubleQuotationMarkCharacter || i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup::c_escapingCharacter || (i_characters [l_readLength - 1] >= GeneralConstantsConstantsGroup::c_controlCharactersStart && i_characters [l_readLength - 1] < GeneralConstantsConstantsGroup::c_controlCharactersUntil)) {
								l_stringChunkTerminator = i_characters [l_readLength - 1];
								break;
							}
							else {
								try {
									l_stringPipe.write (i_characters, GeneralConstantsConstantsGroup::c_iterationStartNumber, l_readLength);
								}
								catch (exception & l_exception) {
									Publisher::logWarningInformation (l_exception);
								}
							}
							l_readLength = 0;
						}
						if (l_stringChunkTerminator == GeneralConstantsConstantsGroup::c_doubleQuotationMarkCharacter) {
							l_stringPipe.finishWriting ();
							l_subThread.join ();
							if (!l_onStringFoundReturn [GeneralConstantsConstantsGroup::c_iterationStartNumber]) {
								throw TerminatedException ("");
							}
							return true;
						}
						else if (l_stringChunkTerminator != GeneralConstantsConstantsGroup::c_escapingCharacter) {
							throw UnsupportedValueException (StringHandler::format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
						}
						l_toReadLength = 1;
						l_readFunctionReturn = i_extendedJsonDatumReader->readFixedLengthData (i_characters, l_readLength, l_toReadLength);
						if (l_readFunctionReturn < l_toReadLength) {
							throw UnsupportedValueException (StringHandler::format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
						}
						l_readLength += l_readFunctionReturn;
						i_characterPositionIndex += l_readFunctionReturn;
						if (i_characters [l_readLength - 1] != GeneralConstantsConstantsGroup::c_unicodeEscapeIndicator) {
							NavigableLinkedMap <string, string>::const_iterator l_escapedCharacterToCharacterMapIterator = GeneralConstantsConstantsGroup::c_escapedCharacterToCharacterMap.find (string (i_characters, GeneralConstantsConstantsGroup::c_iterationStartNumber, l_readLength));
							if (l_escapedCharacterToCharacterMapIterator == GeneralConstantsConstantsGroup::c_escapedCharacterToCharacterMap.end ()) {
								throw UnsupportedValueException (StringHandler::format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
							}
							else {
								l_originalCharacterOfEscapedCharacter = l_escapedCharacterToCharacterMapIterator->second;
							}
						}
						else {
							l_originalCharacterOfEscapedCharacter = decodeUnicodeEscape ();
						}
						try {
							l_stringPipe.write (l_originalCharacterOfEscapedCharacter.c_str (), GeneralConstantsConstantsGroup::c_iterationStartNumber, strlen (l_originalCharacterOfEscapedCharacter.c_str ()));
						}
						catch (exception & l_exception) {
							Publisher::logWarningInformation (l_exception);
						}
					}
				}
				catch (exception & l_exception) {
				}
				l_stringPipe.finishWriting ();
				return false;
			}
			
			string ExtendedJsonDatumParser::decodeUnicodeEscape () {
				try {
					int l_readFunctionReturn = GeneralConstantsConstantsGroup::c_unspecifiedInteger;
					int l_readLength = 0;
					int l_toReadLength = 4;
					l_readFunctionReturn = i_extendedJsonDatumReader->readFixedLengthData (i_characters, l_readLength, l_toReadLength);
					if (l_readFunctionReturn < l_toReadLength) {
						throw UnsupportedValueException (StringHandler::format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
					}
					l_readLength += l_readFunctionReturn;
					i_characterPositionIndex += l_readFunctionReturn;
					wstring_convert <std::codecvt_utf8 <char32_t>, char32_t> l_integerToUtf8StringConverter;
					return l_integerToUtf8StringConverter.to_bytes ( (char32_t) stoi (string (i_characters, GeneralConstantsConstantsGroup::c_iterationStartNumber, l_readLength), nullptr, 16));
				}
				catch (invalid_argument & l_exception) {
					throw UnsupportedValueException (StringHandler::format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
				}
				catch (out_of_range & l_exception) {
					throw UnsupportedValueException (StringHandler::format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
				}
			}
			
			void ExtendedJsonDatumParser::skipWhiteSpaces () {
				int l_readFunctionReturn = GeneralConstantsConstantsGroup::c_unspecifiedInteger;
				int l_readLength = 0;
				int l_toReadLength = 1;
				while ((l_readFunctionReturn = i_extendedJsonDatumReader->readFixedLengthData (i_characters, l_readLength, l_toReadLength)) != GeneralConstantsConstantsGroup::c_unspecifiedInteger) {
					l_readLength += l_readFunctionReturn;
					i_characterPositionIndex += l_readFunctionReturn;
					if (i_characters [l_readLength - 1] != GeneralConstantsConstantsGroup::c_spaceCharacter && i_characters [l_readLength - 1] != GeneralConstantsConstantsGroup::c_tabCharacter && i_characters [l_readLength - 1] != GeneralConstantsConstantsGroup::c_newLineCharacter && i_characters [l_readLength - 1] != GeneralConstantsConstantsGroup::c_carriageReturnCharacter) {
						i_extendedJsonDatumReader->pushData (i_characters, GeneralConstantsConstantsGroup::c_iterationStartNumber, l_readLength);
						break;
					}
					l_readLength = 0;
				}
				return;
			}
			
			bool ExtendedJsonDatumParser::parseArray () {
				int l_readFunctionReturn = GeneralConstantsConstantsGroup::c_unspecifiedInteger;
				int l_toReadLength = GeneralConstantsConstantsGroup::c_unspecifiedInteger;
				int l_readLength = 0;
				if (! (i_parseEventsHandler->onArrayStarted ())) {
					throw TerminatedException ("");
				}
				bool l_itemFound = false;
				while (true) {
					skipWhiteSpaces ();
					l_itemFound = parseNextItem ();
					skipWhiteSpaces ();
					l_readLength = 0;
					l_toReadLength = 1;
					l_readFunctionReturn = i_extendedJsonDatumReader->readFixedLengthData (i_characters, l_readLength, l_toReadLength);
					if (l_readFunctionReturn < l_toReadLength) {
						throw UnsupportedValueException (StringHandler::format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
					}
					l_readLength += l_readFunctionReturn;
					i_characterPositionIndex += l_readFunctionReturn;
					if (i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup::c_jsonArrayCloser) {
						if (! (i_parseEventsHandler->onArrayEnded ())) {
							throw TerminatedException ("");
						}
						skipWhiteSpaces ();
						return true;
					}
					else if (i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup::c_jsonItemsSeparatorOpener) {
						if (!l_itemFound) {
							throw UnsupportedValueException (StringHandler::format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
						}
					}
					else {
						throw UnsupportedValueException (StringHandler::format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
					}
				}
			}
			
			bool ExtendedJsonDatumParser::parseDictionary () {
				if (! (i_parseEventsHandler->onDictionaryStarted ())) {
					throw TerminatedException ("");
				}
				int l_readFunctionReturn = GeneralConstantsConstantsGroup::c_unspecifiedInteger;
				int l_toReadLength = GeneralConstantsConstantsGroup::c_unspecifiedInteger;
				int l_readLength = 0;
				bool l_itemFound = false;
				while (true) {
					skipWhiteSpaces ();
					l_itemFound = parseNextItem ();
					if (l_itemFound) {
						skipWhiteSpaces ();
						l_readLength = 0;
						l_toReadLength = 1;
						l_readFunctionReturn = i_extendedJsonDatumReader->readFixedLengthData (i_characters, l_readLength, l_toReadLength);
						if (l_readFunctionReturn < l_toReadLength) {
							throw UnsupportedValueException (StringHandler::format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
						}
						l_readLength += l_readFunctionReturn;
						i_characterPositionIndex += l_readFunctionReturn;
						if (i_characters [l_readLength - 1] != ':') {
							throw UnsupportedValueException (StringHandler::format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
						}
						skipWhiteSpaces ();
						l_itemFound = parseNextItem ();
						if (!l_itemFound) {
							throw UnsupportedValueException (StringHandler::format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
						}
						skipWhiteSpaces ();
					}
					l_readLength = 0;
					l_toReadLength = 1;
					l_readFunctionReturn = i_extendedJsonDatumReader->readFixedLengthData (i_characters, l_readLength, l_toReadLength);
					if (l_readFunctionReturn < l_toReadLength) {
						throw UnsupportedValueException (StringHandler::format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
					}
					l_readLength += l_readFunctionReturn;
					i_characterPositionIndex += l_readFunctionReturn;
					if (i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup::c_jsonDictionaryCloser) {
						if (! (i_parseEventsHandler->onDictionaryEnded ())) {
							throw TerminatedException ("");
						}
						skipWhiteSpaces ();
						return true;
					}
					else if (i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup::c_jsonItemsSeparatorOpener) {
						if (!l_itemFound) {
							throw UnsupportedValueException (StringHandler::format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
						}
					}
					else {
						throw UnsupportedValueException (StringHandler::format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
					}
				}
			}
			
			bool ExtendedJsonDatumParser::parse (istream * a_extendedJsonDatumReader, ExtendedJsonDatumParseEventsHandler * a_parseEventsHandler) {
				i_extendedJsonDatumReader = new PushableReader (a_extendedJsonDatumReader, c_bufferSize);
				i_parseEventsHandler = a_parseEventsHandler;
				i_parseEventsHandler->initialize ();
				i_characterPositionIndex = GeneralConstantsConstantsGroup::c_iterationStartNumber;
				try {
					return parseNextItem ();
				}
				catch (exception & l_exception) {
					try {
						i_parseEventsHandler->onException (l_exception);
					}
					catch (exception & l_exceptionOfInnerTry) {
						Publisher::logErrorInformation (l_exceptionOfInnerTry);
					}
					delete i_extendedJsonDatumReader;
					throw l_exception;
				}
				delete i_extendedJsonDatumReader;
			}
		}
	}
}

