#include <chrono>
#include <iostream>
#include <regex>
#include <string>
#include <thread>
#include "theBiasPlanet/coreUtilities/clipboardHandling/ClipboardFormatSpecificDatum.hpp"
#include "theBiasPlanet/coreUtilities/clipboardHandling/ClipboardFormatSpecificDataComposite.hpp"
#include "theBiasPlanet/coreUtilities/pipes/StringPipe.hpp"
#ifdef __theBiasPlanet_coreUtilities__
	#include "theBiasPlanet/coreUtilities/collections/NavigableLinkedMap.tpp"
	#include "theBiasPlanet/coreUtilities/collectionsHandling/ArraysFactory.tpp"
	#include "theBiasPlanet/coreUtilities/collectionsHandling/ListsFactory.tpp"
	#include "theBiasPlanet/coreUtilities/constantsGroups/BaseEnumerableConstantsGroup.tpp"
	#include "theBiasPlanet/coreUtilities/pipes/ObjectsPipe.tpp"
	#include "theBiasPlanet/coreUtilities/stringsHandling/StringHandler.tpp"
#else
	#include "theBiasPlanet/coreUtilities/collections/NavigableLinkedMap.hpp"
	#include "theBiasPlanet/coreUtilities/collectionsHandling/ArraysFactory.hpp"
	#include "theBiasPlanet/coreUtilities/collectionsHandling/ListsFactory.hpp"
	#include "theBiasPlanet/coreUtilities/constantsGroups/BaseEnumerableConstantsGroup.hpp"
	#include "theBiasPlanet/coreUtilities/pipes/ObjectsPipe.hpp"
	#include "theBiasPlanet/coreUtilities/stringsHandling/StringHandler.hpp"
#endif
#include "theBiasPlanet/coreUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"

using namespace ::std;
using namespace ::std::chrono;
using namespace ::theBiasPlanet::coreUtilities::clipboardHandling;
using namespace ::theBiasPlanet::coreUtilities::collections;
using namespace ::theBiasPlanet::coreUtilities::collectionsHandling;
using namespace ::theBiasPlanet::coreUtilities::constantsGroups;
using namespace ::theBiasPlanet::coreUtilities::pipes;
using namespace ::theBiasPlanet::coreUtilities::stringsHandling;

template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ string * ArraysFactory::createArray <string> (string * a_targetArray, list <string> const & a_list);
template class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ BaseEnumerableConstantsGroup <string>;
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ list <string> ListsFactory::createList <string> ();
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ list <string> ListsFactory::createList <string> (string const & a_currentElement);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ list <string> ListsFactory::createList <string, string> (string const & a_currentElement, string const & a_remainingElement0);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ list <string> ListsFactory::createList <string, string, string> (string const & a_currentElement, string const & a_remainingElement0, string const & a_remainingElement1);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ list <string> ListsFactory::createList <string, string, string, string> (string const & a_currentElement, string const & a_remainingElement0, string const & a_remainingElement1, string const & a_remainingElement3);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ list <string> ListsFactory::createList <string, string, string, string, string> (string const & a_currentElement, string const & a_remainingElement0, string const & a_remainingElement1, string const & a_remainingElement2, string const & a_remainingElement3);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ list <string> ListsFactory::createList <string, string, string, string, string, string> (string const & a_currentElement, string const & a_remainingElement0, string const & a_remainingElement1, string const & a_remainingElement2, string const & a_remainingElement3, string const & a_remainingElement4);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ list <string> ListsFactory::createList <string, string, string, string, string, string, string> (string const & a_currentElement, string const & a_remainingElement0, string const & a_remainingElement1, string const & a_remainingElement2, string const & a_remainingElement3, string const & a_remainingElement4, string const & a_remainingElement5);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ list <string> ListsFactory::createList <string, string, string, string, string, string, string, string> (string const & a_currentElement, string const & a_remainingElement0, string const & a_remainingElement1, string const & a_remainingElement2, string const & a_remainingElement3, string const & a_remainingElement4, string const & a_remainingElement5, string const & a_remainingElement6);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ list <string> ListsFactory::createListExpandingItems <string> (string const & a_currentElement);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ list <string> ListsFactory::createListExpandingItems <string, list <string>> (string const & a_currentElement, list <string> const & a_remainingElement0);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ list <string> ListsFactory::createListExpandingItems <string> (list <string> const & a_currentElement);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ list <string> ListsFactory::createListExpandingItems <string, string> (list <string> const & a_currentElement, string const & a_remainingElement0);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ list <string> ListsFactory::createListExpandingItems <string, list <string>> (list <string> const & a_currentElement, list <string> const & a_remainingElement0);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ list <unsigned char> ListsFactory::createListExpandingArray <unsigned char> (unsigned char const * a_array, int const & a_arrayLength);
//template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ ostringstream * StringHandler::format <int, double, string> (ostringstream * const a_resultStream, istringstream * const a_formatStream, int const & a_currentItem, double const & a_remainderItem0, string const & a_remainderItem1);
//template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ ostringstream * StringHandler::format <string> (ostringstream * const a_resultStream, istringstream * const a_formatStream, string const & a_currentItem);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ string StringHandler::format <string> (string const & a_formatString, string const & a_currentItem);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ string StringHandler::format <char> (string const & a_formatString, char const & a_currentItem);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ string StringHandler::format <int> (string const & a_formatString, int const & a_currentItem);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ string StringHandler::format <short> (string const & a_formatString, short const & a_currentItem);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ string StringHandler::format <long> (string const & a_formatString, long const & a_currentItem);
// This cannot be set because 'high_resolution_clock' is an alias of 'system_clock' in GCC or 'steady_clock' in Visual C++ and causes a duplicate
//template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ string StringHandler::format <high_resolution_clock> (string const & a_formatString, time_point <high_resolution_clock> const & a_currentItem);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ string StringHandler::format <steady_clock> (string const & a_formatString, time_point <steady_clock> const & a_currentItem);
// This should work, but enigmatically doesn't ("<>" is not recognized as an emptiness, but an omission).
//template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ string StringHandler::format <> (string const & a_formatString, time_point <system_clock> const & a_currentItem);
// An end run that uses the next argument as a dummy in order to avoid "<>" above.
//template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ string StringHandler::format <string> (string const & a_formatString, time_point <system_clock> const & a_currentItem, string const & a_remainderItem0);
// This is really odd because this has to instantiate the no-T overload, but enigmatically works.
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ string StringHandler::format <system_clock> (string const & a_formatString, time_point <system_clock> const & a_currentItem);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ string StringHandler::format <void *> (string const & a_formatString, void * const & a_currentItem);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ string StringHandler::format <string, string> (string const & a_formatString, string const & a_currentItem, string const & a_remainderItem0);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ string StringHandler::format <char, char> (string const & a_formatString, char const & a_currentItem, char const & a_remainderItem0);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ string StringHandler::format <char, string> (string const & a_formatString, char const & a_currentItem, string const & a_remainderItem0);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ string StringHandler::format <int, string> (string const & a_formatString, int const & a_currentItem, string const & a_remainderItem0);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ string StringHandler::format <string, string, string> (string const & a_formatString, string const & a_currentItem, string const & a_remainderItem0, string const & a_remainderItem1);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ string StringHandler::format <string, int, string> (string const & a_formatString, string const & a_currentItem, int const & a_remainderItem0, string const & a_remainderItem1);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ string StringHandler::format <int, double, string> (string const & a_formatString, int const & a_currentItem, double const & a_remainderItem0, string const & a_remainderItem1);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ string StringHandler::format <int, string, int> (string const & a_formatString, int const & a_currentItem, string const & a_remainderItem0, int const & a_remainderItem1);
#ifndef GCC
	template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ ostringstream * StringHandler::format <int, double, string> (ostringstream * const a_resultStream, istringstream * const a_formatStream, int const & a_currentItem, double const & a_remainderItem0, string const & a_remainderItem1);
#endif
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ string StringHandler::format <int, int, int, bool, bool, bool> (string const & a_formatString, int const & a_currentItem, int const & a_remainderItem0, int const & a_remainderItem1, bool const & a_remainderItem2, bool const & a_remainderItem3, bool const & a_remainderItem4);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ string StringHandler::format <string, string, string, string, string, string, string> (string const & a_formatString, string const & a_currentItem, string const & a_remainderItem0, string const & a_remainderItem1, string const & a_remainderItem2, string const & a_remainderItem3, string const & a_remainderItem4, string const & a_remainderItem5);
template class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ NavigableLinkedMap <string, int>;
template class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ NavigableLinkedMap <string, string>;
template class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ NavigableLinkedMap <string, StringPipe *>;
template class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ NavigableLinkedMap <string, void *>;
template class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ NavigableLinkedMap <char, int>;
template class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ NavigableLinkedMap <int, char>;
template class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ NavigableLinkedMap <thread *, StringPipe *>;
template class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ NavigableLinkedMap <unsigned int, void *>;
#ifndef GCC
	template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ NavigableLinkedMap <string, void *>::NonConstantIterator::NonConstantIterator (NavigableLinkedMap <string, void *> const & a_navigableLinkedMap, string const * const a_currentKey);
	template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ NavigableLinkedMap <unsigned int, void *>::NonConstantIterator::NonConstantIterator (NavigableLinkedMap <unsigned int, void *> const & a_navigableLinkedMap, unsigned int const * const a_currentKey);
	template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ NavigableLinkedMap <string, void *>::NonConstantIterator::~NonConstantIterator ();
	template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ NavigableLinkedMap <unsigned int, void *>::NonConstantIterator::~NonConstantIterator ();
#endif
template class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ NavigableLinkedMap <string const, ClipboardFormatSpecificDatum const *>;
template class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ NavigableLinkedMap <string const, ClipboardFormatSpecificDataComposite const *>;
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ pair <NavigableLinkedMap <string, int>::iterator, bool> NavigableLinkedMap <string, int>::emplace <string, int> (string && a_argument0, int && a_argument1);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ NavigableLinkedMap <string, int>::iterator NavigableLinkedMap <string, int>::emplace_hint <string, int> (NavigableLinkedMap <string, int>::const_iterator a_position, string && a_argument0, int && a_argument1);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ NavigableLinkedMap <string, int>::NavigableLinkedMap (NavigableLinkedMap <string, int>::iterator const & a_iteratorPointedAtFirstElement, NavigableLinkedMap <string, int>::iterator const & a_iteratorPointedAtLastElementNotIncluded, NavigableLinkedMap <string, int>::key_compare const & a_keysComparer);
template class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ ObjectsPipe <char>;
template class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ ObjectsPipe <int>;

