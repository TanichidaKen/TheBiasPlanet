#ifndef __theBiasPlanet_coreUtilities_collections_NavigableLinkedMap_hpp__
	#define __theBiasPlanet_coreUtilities_collections_NavigableLinkedMap_hpp__
	
	#include <initializer_list>
	#include <map>
	#include <mutex>
	#include <optional>
	
	using namespace ::std;
	
	namespace theBiasPlanet {
		namespace coreUtilities {
			namespace collections {
				template <typename T, typename U, typename W = less <T>> class NavigableLinkedMap {
					public:
						typedef T key_type;
						typedef U mapped_type;
						typedef W key_compare;
					private:
						class Links {
							private:
								key_type const * i_previousKey; // has to be a pointer, because the address has to be changed
								key_type const * i_nextKey; // has to be a pointer, because the address has to be changed
							public:
								Links ();
								Links (key_type const * const a_previousKey, key_type const * const a_nextKey); // have to be pointers, because each can be 'nullptr' ('optional' cannot take any reference)
								Links (Links const & a_copiedObject);
								virtual Links & operator = (Links const & a_assignedFromObject);
								virtual ~Links ();
								key_type const * const getPreviousKey () const; // has to be a pointer, because it can be 'nullptr' ('optional' cannot take any reference) 
								void setPreviousKey (key_type const * const a_previousKey); // has to be a pointer, because it can be 'nullptr' ('optional' cannot take any reference)
								key_type const * const getNextKey () const; // has to be a pointer, because it can be 'nullptr' ('optional' cannot take any reference)
								void setNextKey (key_type const * const a_nextKey); // has to be a pointer, because it can be 'nullptr' ('optional' cannot take any reference)
						};
					public:
						typedef pair <key_type const, mapped_type> value_type; // This definition follows the standard map
						class KeyValuePairComparer {
							private:
								key_compare i_keyComparer;
							public:
								KeyValuePairComparer (key_compare const & a_keyComparer);
								KeyValuePairComparer (KeyValuePairComparer const & a_copiedObject);
								virtual KeyValuePairComparer & operator = (KeyValuePairComparer const & a_assignedFromObject);
								virtual ~KeyValuePairComparer ();
								virtual bool operator () (value_type const & a_keyValuePair1, value_type const & a_keyValuePair2) const;
						};
						typedef KeyValuePairComparer value_compare;
						typedef allocator <value_type> allocator_type;
						typedef value_type & reference;
						typedef value_type const & const_reference;
						typedef value_type * pointer;
						typedef value_type const * const_pointer;
						class BaseIterator {
							protected:
								map <key_type, mapped_type, key_compare> const * i_keyToValueMap; // has to be a pointer, because assignment may change this
								map <key_type const * const, Links> const * i_keyToLinksMap; // has to be a pointer, because assignment may change this
								key_type const * i_firstKey; // has to be a pointer, because it can be 'nullptr'
								key_type const * i_lastKey; // has to be a pointer, because it can be 'nullptr'
								key_type const * i_currentKey; // has to be a pointer, because the address can be changed
								virtual void goToPreviousElement ();
								virtual void goToNextElement ();
							public:
								typedef ptrdiff_t difference_type;
								typedef bidirectional_iterator_tag iterator_category;
								BaseIterator (NavigableLinkedMap <key_type, mapped_type, key_compare> const & a_navigableLinkedMap, key_type const * const a_currentKey); // has to be a pointer, because it can be 'nullptr'
								BaseIterator (BaseIterator const & a_copiedObject);
								virtual BaseIterator & operator = (BaseIterator const & a_assignedFromObject);
								virtual ~BaseIterator ();
								virtual bool operator == (BaseIterator const & a_iteratorToBeCompared) const;
								virtual bool operator != (BaseIterator const & a_iteratorToBeCompared) const;
						};
						class NonConstantIterator: public BaseIterator {
							public:
								typedef pair <key_type const, mapped_type> value_type;
								typedef value_type * pointer;
								typedef value_type & reference;
								NonConstantIterator (NavigableLinkedMap <key_type, mapped_type, key_compare> const & a_navigableLinkedMap, key_type const * const a_currentKey); // has to be a pointer, because it can be 'nullptr'
								NonConstantIterator (NonConstantIterator const & a_copiedObject);
								virtual NonConstantIterator & operator = (NonConstantIterator const & a_assignedFromObject);
								virtual ~NonConstantIterator ();
								virtual NonConstantIterator & operator ++ ();
								virtual NonConstantIterator operator ++ (int const);
								virtual NonConstantIterator & operator -- ();
								virtual NonConstantIterator operator -- (int const);
								virtual value_type & operator * () const;
								virtual value_type * const operator -> () const;
						};
						class ConstantIterator : public BaseIterator {
							public:
								typedef pair <key_type const, mapped_type> const value_type;
								typedef pair <key_type const, mapped_type> NonConstantvalue_type;
								typedef value_type * pointer;
								typedef value_type & reference;
								ConstantIterator (NavigableLinkedMap <key_type, mapped_type, key_compare> const & a_navigableLinkedMap, key_type const * const a_currentKey); // has to be a pointer, because it can be 'nullptr'
								ConstantIterator (ConstantIterator const & a_copiedObject);
								virtual ConstantIterator & operator = (ConstantIterator const & a_assignedFromObject);
								virtual ~ConstantIterator ();
								virtual ConstantIterator & operator ++ ();
								virtual ConstantIterator operator ++ (int const);
								virtual ConstantIterator & operator -- ();
								virtual ConstantIterator operator -- (int const);
								virtual value_type & operator * () const;
#ifdef GCC
								virtual value_type * const operator -> () const;
#else
								virtual NonConstantvalue_type const * const operator -> () const;
#endif
						};
						typedef NonConstantIterator iterator;
						typedef ConstantIterator const_iterator;
						typedef ::std::reverse_iterator <iterator> reverse_iterator;
						typedef ::std::reverse_iterator <const_iterator> const_reverse_iterator;
						typedef ptrdiff_t difference_type;
						typedef size_t size_type;
					private:
						map <key_type, mapped_type, key_compare> * i_keyToValueMap; // has to be a pointer, because the address can be changed by being swapped
						map <key_type const * const, Links> * i_keyToLinksMap; // has to be a pointer, because the address can be changed by being swapped
						key_type const * i_firstKey; // has to be a pointer, because the address can be changed
						key_type const * i_lastKey; // has to be a pointer, because the address can be changed
						recursive_mutex i_mutex;
						pair <key_type const &, mapped_type const &> getKeyValuePair (key_type const & a_key, mapped_type const & a_value) const;
						virtual void insertNewElementAtEnd (key_type const & a_key, optional <mapped_type> const & a_value); // optional, because when '[]' is used, the value will be a default value ('optional' means the default value)
						virtual void insertNewElementAtMiddle (key_type const & a_positionKey, key_type const & a_key, optional <mapped_type> const & a_value); // optional, because when '[]' is used, the value will be a default value ('optional' means the default value)
						virtual void updateElement (key_type const & a_key, mapped_type const & a_value);
					public:
						explicit NavigableLinkedMap (key_compare const & a_keysComparer = key_compare ());
						template <typename V> NavigableLinkedMap (V const & a_iteratorPointedAtFirstElement, V const & a_iteratorPointedAtLastElementNotIncluded, key_compare const & a_keysComparer = key_compare ());
						NavigableLinkedMap (initializer_list <value_type> const & a_initializer, key_compare const & a_keysComparer = key_compare ());
						NavigableLinkedMap (NavigableLinkedMap const & a_copiedObject);
						virtual NavigableLinkedMap & operator = (NavigableLinkedMap const & a_assignedFromObject);
						virtual ~NavigableLinkedMap ();
						virtual iterator begin ();
						virtual const_iterator begin () const;
						virtual iterator end ();
						virtual const_iterator end () const;
						virtual reverse_iterator rbegin ();
						virtual const_reverse_iterator rbegin () const;
						virtual reverse_iterator rend ();
						virtual const_reverse_iterator rend () const;
						virtual const_iterator cbegin () const noexcept;
						virtual const_iterator cend () const noexcept;
						virtual const_reverse_iterator crbegin () const noexcept;
						virtual const_reverse_iterator crend () const noexcept;
						virtual bool empty () const;
						virtual size_type size () const;
						virtual size_type max_size () const;
						virtual mapped_type & operator [] (key_type const & a_key);
						// When the key isn't found, a '::std::out_of_range' exception is thrown.
						virtual mapped_type & at (key_type const & a_key);
						virtual mapped_type const & at (key_type const & a_key) const;
						virtual pair <iterator, bool> insert (value_type const & a_keyValuePair);
						virtual iterator insert (iterator a_position, value_type const & a_keyValuePair); // This definition follows the standard map
						// Any template method cannot be virtual only because it is decided so by the specification.
						template <typename V> void insert (V const & a_iteratorPointedAtFirstElement, V const & a_iteratorPointedAtLastElementNotIncluded);
						virtual void erase (iterator a_position); // This definition follows the standard map
						virtual size_type erase (key_type const & a_key);
   		  				virtual void erase (iterator a_iteratorPointedAtFirstElement, iterator a_iteratorPointedAtLastElementNotIncluded); // This definition follows the standard map
						virtual void swap (NavigableLinkedMap <T, U, W> & a_navigableLinkedMap);
						virtual void clear ();
						template <typename ... V> pair <iterator, bool> emplace (V && ... a_arguments); // the definition follows the standard map
						template <typename ... V> iterator emplace_hint (const_iterator a_position, V && ... a_arguments); // the definition follows the standard map
						virtual key_compare key_comp () const;
						virtual value_compare value_comp () const;
						virtual iterator find (key_type const & a_key);
						virtual const_iterator find (key_type const & a_key) const;
						virtual size_type count (key_type const & a_key) const;
						virtual iterator lower_bound (key_type const & a_key);
						virtual const_iterator lower_bound (key_type const & a_key) const;
						virtual iterator upper_bound (key_type const & a_key);
						virtual const_iterator upper_bound (key_type const & a_key) const;
						virtual pair <const_iterator, const_iterator> equal_range (key_type const & a_key) const;
						virtual pair <iterator, iterator> equal_range (key_type const & a_key);
						virtual allocator_type get_allocator () const; // the definition follows the standard map
						virtual key_type * getFirstKey () const; // the definition follows the standard map
						virtual key_type * getLastKey () const; // the definition follows the standard map
						virtual key_type * getPreviousKey (key_type const & a_key) const; // has to be a pointer, because it can be 'nullptr'
						virtual key_type * getNextKey (key_type const & a_key) const; // the definition follows the standard map
				};
			}
		}
	}
#endif

