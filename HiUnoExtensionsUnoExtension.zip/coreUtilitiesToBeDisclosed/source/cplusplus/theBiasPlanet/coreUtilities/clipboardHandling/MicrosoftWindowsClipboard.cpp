#ifndef GCC
	#include <windows.h> // This has to be before the primary header file in order to avoid the conflict of the '::std::' namespace and the Win32 API namespace.
	#include "theBiasPlanet/coreUtilities/clipboardHandling/MicrosoftWindowsClipboard.hpp"
	#include "theBiasPlanet/coreUtilities/messagingHandling/Publisher.hpp"
	#include "theBiasPlanet/coreUtilities/stringsHandling/StringHandler.hpp"
	
	using namespace ::theBiasPlanet::coreUtilities::messagingHandling;
	using namespace ::theBiasPlanet::coreUtilities::stringsHandling;
	
	namespace theBiasPlanet {
		namespace coreUtilities {
			namespace clipboardHandling {
				bool MicrosoftWindowsClipboard::openClipboard () {
					return OpenClipboard (nullptr);
				}
				
				bool MicrosoftWindowsClipboard::closeClipboard () {
					return CloseClipboard ();
				}
				
				bool MicrosoftWindowsClipboard::clearClipboard () {
					return EmptyClipboard ();
				}
				
				ClipboardFormatSpecificDataComposite * const MicrosoftWindowsClipboard::getFormatSpecificDataComposite () {
					UINT l_datumFormatNumber = 0;
					int l_datumFormatNameMaximumSize = 100;
					HGLOBAL l_datumFormatNameGlobalMemoryArea = GlobalAlloc (GMEM_MOVEABLE, l_datumFormatNameMaximumSize);
					LPSTR l_datumFormatName = (LPSTR) GlobalLock (l_datumFormatNameGlobalMemoryArea);
					ClipboardFormatSpecificDataComposite * const l_formatSpecificDataComposite = new ClipboardFormatSpecificDataComposite ();
					while (true) {
						l_datumFormatNumber = EnumClipboardFormats (l_datumFormatNumber);
						if (l_datumFormatNumber == 0) {
							break;
						}
						if (l_datumFormatNumber == 1) {
							strcpy (l_datumFormatName, "Text");
						}
						else if (l_datumFormatNumber == 2) {
							strcpy (l_datumFormatName, "Bitmap");
						}
						else if (l_datumFormatNumber == 3) {
							strcpy (l_datumFormatName, "MetaFilePict");
						}
						else if (l_datumFormatNumber == 4) {
							strcpy (l_datumFormatName, "SymbolicLink");
						}
						else if (l_datumFormatNumber == 5) {
							strcpy (l_datumFormatName, "DataInterchangeFormat");
						}
						else if (l_datumFormatNumber == 7) {
							strcpy (l_datumFormatName, "OEMText");
						}
						else if (l_datumFormatNumber == 8) {
							strcpy (l_datumFormatName, "DeviceIndependentBitmap");
						}
						else if (l_datumFormatNumber == 13) {
							strcpy (l_datumFormatName, "UnicodeText");
						}
						else if (l_datumFormatNumber == 14) {
							strcpy (l_datumFormatName, "EnhancedMetafile");
						}
						else if (l_datumFormatNumber == 16) {
							strcpy (l_datumFormatName, "Locale");
						}
						else if (l_datumFormatNumber == 17) {
							strcpy (l_datumFormatName, "Format17");
						}
						else {
							strcpy (l_datumFormatName, "???");
							GetClipboardFormatNameA (l_datumFormatNumber, l_datumFormatName, l_datumFormatNameMaximumSize);
						}
						HANDLE l_formatSpecificDatumHandle = GetClipboardData (l_datumFormatNumber);
						if (l_formatSpecificDatumHandle != nullptr) {
							if (l_datumFormatNumber == 2) {
								HBITMAP l_formatSpecificDatumHandleForBitmap = (HBITMAP) l_formatSpecificDatumHandle;
								BITMAP * const l_copiedFormatSpecificDatumForBitmap = new BITMAP ();
								GetObject (l_formatSpecificDatumHandleForBitmap, sizeof (BITMAP), l_copiedFormatSpecificDatumForBitmap);
								l_formatSpecificDataComposite->addFormatSpecificDatum (new ClipboardFormatSpecificDatum (l_datumFormatName, l_datumFormatNumber, false, sizeof (BITMAP), l_copiedFormatSpecificDatumForBitmap));
							}
							else if (l_datumFormatNumber == 14) {
								HENHMETAFILE l_formatSpecificDatumHandleForEnhancedMetafile = (HENHMETAFILE) l_formatSpecificDatumHandle;
								int const l_formatSpecificDatumForEnhancedMetafileMaximumSize = 10000;
								::std::byte * const l_copiedFormatSpecificDatumForEnhancedMetafile = new ::std::byte [l_formatSpecificDatumForEnhancedMetafileMaximumSize];
								int const l_formatSpecificDatumForEnhancedMetafileSize (GetEnhMetaFileBits (l_formatSpecificDatumHandleForEnhancedMetafile, l_formatSpecificDatumForEnhancedMetafileMaximumSize, (LPBYTE) l_copiedFormatSpecificDatumForEnhancedMetafile));
								l_formatSpecificDataComposite->addFormatSpecificDatum (new ClipboardFormatSpecificDatum (l_datumFormatName, l_datumFormatNumber, true, l_formatSpecificDatumForEnhancedMetafileSize, l_copiedFormatSpecificDatumForEnhancedMetafile));
							}
							else {
								LPVOID l_formatSpecificDatumForUsualFormats = GlobalLock (l_formatSpecificDatumHandle);
								if (l_formatSpecificDatumForUsualFormats != nullptr) {
									SIZE_T l_formatSpecificDatumSizeForUsualFormats = GlobalSize (l_formatSpecificDatumHandle);
									::std::byte * const l_copiedFormatSpecificDatumForUsualFormats = new ::std::byte [l_formatSpecificDatumSizeForUsualFormats];
									::std::memcpy (l_copiedFormatSpecificDatumForUsualFormats, l_formatSpecificDatumForUsualFormats, l_formatSpecificDatumSizeForUsualFormats);
									l_formatSpecificDataComposite->addFormatSpecificDatum (new ClipboardFormatSpecificDatum (l_datumFormatName, l_datumFormatNumber, true, l_formatSpecificDatumSizeForUsualFormats, l_copiedFormatSpecificDatumForUsualFormats));
									GlobalUnlock (l_formatSpecificDatumHandle);
								}
								else {
									Publisher::logWarningInformation (StringHandler::format (::std::string ("The clipboard datum for the '%d' format could not be gotten."), (int) l_datumFormatNumber));
								}
							}
						}
						else {
							return false;
						}
					}
					GlobalUnlock (l_datumFormatNameGlobalMemoryArea);
					GlobalFree (l_datumFormatNameGlobalMemoryArea);
					return l_formatSpecificDataComposite;
				}
				
				bool MicrosoftWindowsClipboard::setFormatSpecificDataComposite (ClipboardFormatSpecificDataComposite const * const a_formatSpecificDataComposite) {
					for (::std::string const & l_datumFormatName: a_formatSpecificDataComposite->getFormatNames ()) {
						ClipboardFormatSpecificDatum const * const l_formatSpecificDatum (a_formatSpecificDataComposite->getFormatSpecificDatum (l_datumFormatName));
						if (l_datumFormatName == "Bitmap") {
							BITMAP const * const l_copiedFormatSpecificDatumForBitmap = (BITMAP const * const) (l_formatSpecificDatum->getDatum ());
							HBITMAP l_formatSpecificDatumHandleForBitmap = CreateBitmapIndirect (l_copiedFormatSpecificDatumForBitmap);
							HANDLE l_formatSpecificDatumHandle = SetClipboardData (l_formatSpecificDatum->getFormatNumber (), l_formatSpecificDatumHandleForBitmap);
						}
						else if (l_datumFormatName == "EnhancedMetafile") {
							LPBYTE const l_copiedFormatSpecificDatumForEnhancedMetafile = (LPBYTE const) (l_formatSpecificDatum->getDatum ());
							HENHMETAFILE l_formatSpecificDatumHandleForEnhancedMetafile = SetEnhMetaFileBits (l_formatSpecificDatum->getDatumSize (), l_copiedFormatSpecificDatumForEnhancedMetafile);
							HANDLE l_formatSpecificDatumHandle = SetClipboardData (l_formatSpecificDatum->getFormatNumber (), l_formatSpecificDatumHandleForEnhancedMetafile);
						}
						else {
							::std::byte const * const l_copiedFormatSpecificDatumForUsualFormats = (::std::byte const * const) (l_formatSpecificDatum->getDatum ());
							HGLOBAL l_formatSpecificDatumForUsualFormatsGlobalMemoryArea = GlobalAlloc (GMEM_MOVEABLE, l_formatSpecificDatum->getDatumSize ());
							LPBYTE l_formatSpecificDatumForUsualFormats = (LPBYTE) GlobalLock (l_formatSpecificDatumForUsualFormatsGlobalMemoryArea);
							::std::memcpy (l_formatSpecificDatumForUsualFormats, l_copiedFormatSpecificDatumForUsualFormats, l_formatSpecificDatum->getDatumSize ());
							GlobalUnlock (l_formatSpecificDatumForUsualFormatsGlobalMemoryArea);
							HANDLE l_formatSpecificDatumHandle = SetClipboardData (l_formatSpecificDatum->getFormatNumber (), l_formatSpecificDatumForUsualFormatsGlobalMemoryArea);
						}
					}
					return true;
				}
			}
		}
	}
#endif

