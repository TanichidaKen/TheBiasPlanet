#ifndef __theBiasPlanet_coreUtilities_processesHandling_ProcessHandler_hpp__
	#define __theBiasPlanet_coreUtilities_processesHandling_ProcessHandler_hpp__
#ifdef GCC
	#include <iostream>
	#include <list>
	#include <mutex>
	#include <optional>
	#include <string>
	#include <thread>
	#include <ext/stdio_filebuf.h>
	#include "theBiasPlanet/coreUtilities/collections/NavigableLinkedMap.hpp"
	#include "theBiasPlanet/coreUtilities/inputs/HaltableStandardInputReader.hpp"
	#include "theBiasPlanet/coreUtilities/pipes/StringPipe.hpp"
	#include "theBiasPlanet/coreUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	using namespace ::__gnu_cxx;
	using namespace ::theBiasPlanet::coreUtilities::collections;
	using namespace ::theBiasPlanet::coreUtilities::inputs;
	using namespace ::theBiasPlanet::coreUtilities::pipes;
	
	namespace theBiasPlanet {
		namespace coreUtilities {
			namespace processesHandling {
				class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ ProcessHandler {
					private:
						static HaltableStandardInputReader & s_haltableStandardInputReader;
						static void interruptRelayStandardInputThread (thread & a_thread);
					public:
						class StandardInputAndOutputs {
							private:
								pid_t i_processIdentification;
								stdio_filebuf <char> i_standardInputBuffer;
								ostream i_standardInputOutputStream;
								stdio_filebuf <char> i_standardOutputBuffer;
								istream i_standardOutputInputStream;
								stdio_filebuf <char> i_standardErrorOutputBuffer;
								istream i_standardErrorOutputInputStream;
								thread i_relayStandardInputThread;
								thread i_printStandardOutputThread;
								thread i_printStandardErrorOutputThread;
								bool i_thereWereStandardInputContents;
								bool i_thereWereStandardOutputContents;
								bool i_thereWereStandardErrorOutputContents;
							public:
								StandardInputAndOutputs (pid_t a_processIdentification, int const & a_standardInputOutputFileDescription, int const & a_standardOutputInputFileDescription, int const & a_standardErrorOutputInputFileDescription);
								ostream * getStandardInputOutputStream ();
								istream * getStandardOutputInputStream ();
								istream * getStandardErrorOutputInputStream ();
								void relayStandardInputAsynchronously ();
								void printStandardOutputAsynchronously ();
								void printStandardErrorOutputAsynchronously ();
								optional <string> getStandardOutputNextLine ();
								optional <string> getStandardErrorOutputNextLine ();
								bool thereWereStandardInputContents ();
								bool thereWereStandardOutputContents ();
								bool thereWereStandardErrorOutputContents ();
								int waitUntillFinish ();
						};
						static StandardInputAndOutputs * executeAndReturnStandardInputAndOutputs (string const & a_workingDirectoryPath, list <string> const & a_commandAndArguments);
						static int execute (string const & a_workingDirectoryPath, list <string> const & a_commandAndArguments, bool const & a_waitsUntilFinish);
				};
			}
		}
	}
#else
#endif
#endif

