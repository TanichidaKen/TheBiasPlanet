#include "theBiasPlanet/coreUtilities/processesHandling/ProcessHandler.hpp"
#ifdef GCC
#include <array>
#include <chrono>
#include <exception>
#include <unistd.h>
#include <sys/wait.h>
#include "theBiasPlanet/coreUtilities/collectionsHandling/ArraysFactory.hpp"
#include "theBiasPlanet/coreUtilities/constantsGroups/DefaultValuesConstantsGroup.hpp"
#include "theBiasPlanet/coreUtilities/constantsGroups/GeneralConstantsConstantsGroup.hpp"
#include "theBiasPlanet/coreUtilities/inputsHandling/NoMoreDataException.hpp"
#include "theBiasPlanet/coreUtilities/inputsHandling/NoMoreNeedsException.hpp"
#include "theBiasPlanet/coreUtilities/messagingHandling/Publisher.hpp"
#include "theBiasPlanet/coreUtilities/stringsHandling/StringHandler.hpp"
#include "theBiasPlanet/coreUtilities/timersHandling/TimeOutException.hpp"

using namespace ::std::chrono;
using namespace ::theBiasPlanet::coreUtilities::collectionsHandling;
using namespace ::theBiasPlanet::coreUtilities::constantsGroups;
using namespace ::theBiasPlanet::coreUtilities::inputsHandling;
using namespace ::theBiasPlanet::coreUtilities::messagingHandling;
using namespace ::theBiasPlanet::coreUtilities::stringsHandling;
using namespace ::theBiasPlanet::coreUtilities::timersHandling;

namespace theBiasPlanet {
	namespace coreUtilities {
		namespace processesHandling {
			void ProcessHandler::interruptRelayStandardInputThread (thread & a_thread) {
				s_haltableStandardInputReader.removeSubscriber (StringHandler::format <void *> (string ("%d"), (void *) &a_thread));
			}
			
			ProcessHandler::StandardInputAndOutputs::StandardInputAndOutputs (int a_processIdentification, int const & a_standardInputOutputFileDescription, int const & a_standardOutputInputFileDescription, int const & a_standardErrorOutputInputFileDescription) : i_processIdentification (a_processIdentification), i_standardInputBuffer (a_standardInputOutputFileDescription, std::ios::out), i_standardInputOutputStream (&i_standardInputBuffer), i_standardOutputBuffer (a_standardOutputInputFileDescription, std::ios::in), i_standardOutputInputStream (&i_standardOutputBuffer), i_standardErrorOutputBuffer (a_standardErrorOutputInputFileDescription, std::ios::in), i_standardErrorOutputInputStream (&i_standardErrorOutputBuffer) {
			}
			
			ostream * ProcessHandler::StandardInputAndOutputs::getStandardInputOutputStream () {
				return &i_standardInputOutputStream;
			}
			
			istream * ProcessHandler::StandardInputAndOutputs::getStandardOutputInputStream () {
				return &i_standardOutputInputStream;
			}
			
			istream * ProcessHandler::StandardInputAndOutputs::getStandardErrorOutputInputStream () {
				return &i_standardErrorOutputInputStream;;
			}
			
			void ProcessHandler::StandardInputAndOutputs::relayStandardInputAsynchronously () {
				s_haltableStandardInputReader.addSubscriber (StringHandler::format <void *> (string ("%d"), (void *) &i_relayStandardInputThread));
				i_relayStandardInputThread = thread ( [this] () -> void {
					string l_threadIdentification (StringHandler::format <void *> (string ("%d"), (void *) &i_relayStandardInputThread));
					try {
						string l_standardInputDatum;
						while (true) {
							try {
								l_standardInputDatum = s_haltableStandardInputReader.read (l_threadIdentification, 1);
								i_thereWereStandardInputContents = true;
								i_standardInputOutputStream << l_standardInputDatum;
								i_standardInputOutputStream.flush ();
							}
							catch (NoMoreDataException & l_exception) {
								break;
							}
							catch (TimeOutException & l_exception) {
								// impossible
							}
						}
					}
					catch (exception & l_exception) {
						Publisher::logErrorInformation (StringHandler::format (string ("### A standard input error: %s."), string (l_exception.what ())));
					}
				});
				i_relayStandardInputThread.detach ();
			}
			
			void ProcessHandler::StandardInputAndOutputs::printStandardOutputAsynchronously () {
				i_printStandardOutputThread = thread ([this] () -> void {
					try {
						char l_standardOutputData [DefaultValuesConstantsGroup::c_smallBufferSize];
						int l_standardOutputDataLength = -1;
						while (true) {
							i_standardOutputInputStream.read (l_standardOutputData, DefaultValuesConstantsGroup::c_smallBufferSize);
							l_standardOutputDataLength = i_standardOutputInputStream.gcount ();
							for (int l_characterIndex = 0; l_characterIndex < l_standardOutputDataLength; l_characterIndex ++) {
								i_thereWereStandardOutputContents = true;
								cout.put (l_standardOutputData [l_characterIndex]);
								cout.flush ();
							}
							if (!(i_standardOutputInputStream.good ())) {
								break;
							}
						}
					}
					catch (exception & l_exception) {
						Publisher::logErrorInformation (StringHandler::format (string ("### A standard output error: %s."), string (l_exception.what ())));
					}
				});
				i_printStandardOutputThread.detach ();
			}
			
			void ProcessHandler::StandardInputAndOutputs::printStandardErrorOutputAsynchronously () {
				i_printStandardErrorOutputThread = thread ( [this] () -> void {
					try {
						char l_standardErrorOutputData [DefaultValuesConstantsGroup::c_smallBufferSize];
						int l_standardErrorOutputDataLength = -1;
						while (true) {
							i_standardErrorOutputInputStream.read (l_standardErrorOutputData, DefaultValuesConstantsGroup::c_smallBufferSize);
							l_standardErrorOutputDataLength = i_standardErrorOutputInputStream.gcount ();
							for (int l_characterIndex = 0; l_characterIndex < l_standardErrorOutputDataLength; l_characterIndex ++) {
								i_thereWereStandardErrorOutputContents = true;
								cerr.put (l_standardErrorOutputData [l_characterIndex]);
								cerr.flush ();
							}
							if (!(i_standardErrorOutputInputStream.good ())) {
								break;
							}
						}
					}
					catch (exception & l_exception) {
						Publisher::logErrorInformation (StringHandler::format (string ("### A standard error output error: %s."), string (l_exception.what ())));
					}
				});
				i_printStandardErrorOutputThread.detach ();
			}
			
			optional <string> ProcessHandler::StandardInputAndOutputs::getStandardOutputNextLine () {
				try {
					if (!(i_standardOutputInputStream.eof ())) {
						i_thereWereStandardOutputContents = true;
						string l_line;
						getline (i_standardOutputInputStream, l_line);
						return optional <string> (l_line);
					}
					else {
						//i_standardOutputInputStream.close ();
						return nullopt;
					}
				}
				catch (exception & l_exception) {
					Publisher::logErrorInformation (StringHandler::format (string ("### The standard output couldn't be scanned: %s."), string (l_exception.what ())));
					//i_standardOutputInputStream.close ();
					return nullopt;
				}
			}
			
			optional <string> ProcessHandler::StandardInputAndOutputs::getStandardErrorOutputNextLine () {
				try {
					if (!(i_standardErrorOutputInputStream.eof ())) {
						i_thereWereStandardErrorOutputContents = true;
						string l_line;
						getline (i_standardErrorOutputInputStream, l_line);
						return optional <string> (l_line);
					}
					else {
						//i_standardErrorOutputInputStream.close ();
						return nullopt;
					}
				}
				catch (exception & l_exception) {
					Publisher::logErrorInformation (StringHandler::format (string ("### The standard error output couldn't be scanned: %s."), string (l_exception.what ())));
					//i_standardOutputInputStream.close ();
					return nullopt;
				}
			}
			
			bool ProcessHandler::StandardInputAndOutputs::thereWereStandardInputContents () {
				return i_thereWereStandardInputContents;
			}
			
			bool ProcessHandler::StandardInputAndOutputs::thereWereStandardOutputContents () {
				return i_thereWereStandardOutputContents;
			}
			
			bool ProcessHandler::StandardInputAndOutputs::thereWereStandardErrorOutputContents () {
				return i_thereWereStandardErrorOutputContents;
			}
			
			int ProcessHandler::StandardInputAndOutputs::waitUntillFinish () {
				if (i_printStandardErrorOutputThread.joinable ()) {
					i_printStandardErrorOutputThread.join ();
				}
				if (i_printStandardOutputThread.joinable ()) {
					i_printStandardOutputThread.join ();
				}
				int l_processReturn;
			   	waitpid (i_processIdentification, &l_processReturn, 0);
				if (i_relayStandardInputThread.joinable ()) {
					interruptRelayStandardInputThread (i_relayStandardInputThread);
					i_relayStandardInputThread.join ();
				}
				return l_processReturn;
			}
			
			// the return has to be the address of a heap datum in order for it to be able to be used after the control is out of the block in which this method is called.
			ProcessHandler::StandardInputAndOutputs * ProcessHandler::executeAndReturnStandardInputAndOutputs (string const & a_workingDirectoryPath, list <string> const & a_commandAndArguments) {
				// For each of the file descriptions arrays, the element 0 and the element 1 are the exit and the entrance of the pipe, respectively.
				int l_childProcessStandardInputPipeFileDescriptionsArray [2];
				int l_childProcessStandardOutputPipeFileDescriptionsArray [2];
				int l_childProcessStandardErrorOutputPipeFileDescriptionsArray [2];
				if ( (pipe (l_childProcessStandardInputPipeFileDescriptionsArray ) < 0) || (pipe (l_childProcessStandardOutputPipeFileDescriptionsArray) < 0) || (pipe (l_childProcessStandardErrorOutputPipeFileDescriptionsArray) < 0)) {
					throw runtime_error (string ("### A pipe error has occurred."));
				}
				pid_t l_processIdentification = fork ();
				if (l_processIdentification  == -1) {
					throw runtime_error (string ("### A fork error has occurred."));
				} else if (l_processIdentification == 0) {
					while ( (dup2 (l_childProcessStandardInputPipeFileDescriptionsArray [0], STDIN_FILENO) == -1) && (errno == EINTR)) {
					}
					close (l_childProcessStandardInputPipeFileDescriptionsArray [0]);
					close (l_childProcessStandardInputPipeFileDescriptionsArray [1]);
					while ( (dup2 (l_childProcessStandardOutputPipeFileDescriptionsArray [1], STDOUT_FILENO) == -1) && (errno == EINTR)) {
					}
					close (l_childProcessStandardOutputPipeFileDescriptionsArray [1]);
					close (l_childProcessStandardOutputPipeFileDescriptionsArray [0]);
					while ( (dup2 (l_childProcessStandardErrorOutputPipeFileDescriptionsArray [1], STDERR_FILENO) == -1) && (errno == EINTR)) {
					}
					close (l_childProcessStandardErrorOutputPipeFileDescriptionsArray [1]);
					close (l_childProcessStandardErrorOutputPipeFileDescriptionsArray [0]);
					if (a_workingDirectoryPath != GeneralConstantsConstantsGroup::c_emptyString) {
						chdir (a_workingDirectoryPath.c_str ());
					}
					int const l_lengthOfCommandAndArgumentsArray = a_commandAndArguments.size () + 1;
					char const * l_nonConstantCommandAndArgumentsArray [l_lengthOfCommandAndArgumentsArray];
					int l_commandOrArgumentIndex = 0;
					for (string const & l_commandOrArgument : a_commandAndArguments) {
						l_nonConstantCommandAndArgumentsArray  [l_commandOrArgumentIndex] = l_commandOrArgument.c_str ();
						l_commandOrArgumentIndex ++;
					}
					l_nonConstantCommandAndArgumentsArray  [l_commandOrArgumentIndex] = (char*) nullptr;
					// const_cast has to be used because the function, execvpe, is sloppy in that the first argument isn't 'char const * const' and the second and third arguments aren't 'char const * const *' as they really should be!
					char * const * l_commandAndArgumentsArray = const_cast <char * const *> (l_nonConstantCommandAndArgumentsArray);
					//char * const l_environmentVariablesArray [1] = {(char*) nullptr};
					char * const * l_environmentVariablesArray = environ; // 'environ' is the global variable defined in 'unistd.h'.
					int l_childProcessExitStatus = execvpe (l_commandAndArgumentsArray [0], l_commandAndArgumentsArray, l_environmentVariablesArray);
					exit (l_childProcessExitStatus);
				}
				close (l_childProcessStandardInputPipeFileDescriptionsArray [0]);
				close (l_childProcessStandardOutputPipeFileDescriptionsArray [1]);
				close (l_childProcessStandardErrorOutputPipeFileDescriptionsArray [1]);
				return new StandardInputAndOutputs (l_processIdentification, l_childProcessStandardInputPipeFileDescriptionsArray [1], l_childProcessStandardOutputPipeFileDescriptionsArray [0], l_childProcessStandardErrorOutputPipeFileDescriptionsArray [0]);
			}
			
			int ProcessHandler::execute (string const & a_workingDirectoryPath, list <string> const & a_commandAndArguments, bool const & a_waitsUntilFinish) {
				StandardInputAndOutputs * l_childProcessStandardInputAndOutputs = executeAndReturnStandardInputAndOutputs (a_workingDirectoryPath, a_commandAndArguments);
				int l_childProcessReturn = 0;
				if (a_waitsUntilFinish) {
					l_childProcessStandardInputAndOutputs->printStandardOutputAsynchronously ();
					l_childProcessStandardInputAndOutputs->printStandardErrorOutputAsynchronously ();
					l_childProcessStandardInputAndOutputs->relayStandardInputAsynchronously ();
					l_childProcessReturn = l_childProcessStandardInputAndOutputs->waitUntillFinish ();
					delete l_childProcessStandardInputAndOutputs;
				}
				else {
					thread l_waitForInvokedProcessToEndThread = thread ([l_childProcessStandardInputAndOutputs] () -> void {
						l_childProcessStandardInputAndOutputs->printStandardOutputAsynchronously ();
						l_childProcessStandardInputAndOutputs->printStandardErrorOutputAsynchronously ();
						l_childProcessStandardInputAndOutputs->relayStandardInputAsynchronously ();
						l_childProcessStandardInputAndOutputs->waitUntillFinish ();
						delete l_childProcessStandardInputAndOutputs;
					});
					l_waitForInvokedProcessToEndThread.detach ();
				}
				return l_childProcessReturn;
			}
		}
	}
}
#else
#endif

