#ifndef __theBiasPlanet_coreUtilities_inputsHandling_NoMoreDataException_hpp__
	#define __theBiasPlanet_coreUtilities_inputsHandling_NoMoreDataException_hpp__
	
	#include <exception>
	#include <string>
	#include "theBiasPlanet/coreUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	
	namespace theBiasPlanet {
		namespace coreUtilities {
			namespace inputsHandling {
				class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ NoMoreDataException : public exception {
					private:
						string i_message;
					public:
						NoMoreDataException (string a_message);
						virtual ~NoMoreDataException ();
						virtual char const * what () const throw () override;
				};
			}
		}
	}
#endif

