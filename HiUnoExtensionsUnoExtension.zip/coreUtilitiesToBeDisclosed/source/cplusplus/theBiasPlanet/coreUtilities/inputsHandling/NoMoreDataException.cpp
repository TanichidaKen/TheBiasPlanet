#include "theBiasPlanet/coreUtilities/inputsHandling/NoMoreDataException.hpp"

namespace theBiasPlanet {
	namespace coreUtilities {
		namespace inputsHandling {
			NoMoreDataException::NoMoreDataException (string a_message) : exception (), i_message (a_message) {
			}
			
			NoMoreDataException::~NoMoreDataException () {
			}
			
			char const * NoMoreDataException::what () const throw () {
    			return i_message.c_str ();
    		}
		}
	}
}

