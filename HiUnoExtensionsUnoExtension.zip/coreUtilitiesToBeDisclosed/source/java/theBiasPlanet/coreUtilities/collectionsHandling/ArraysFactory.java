package theBiasPlanet.coreUtilities.collectionsHandling;

import java.util.Collection;
import java.lang.reflect.Array;
import theBiasPlanet.coreUtilities.constantsGroups.WarningNamesConstantsGroup;

public class ArraysFactory {
	@SuppressWarnings (WarningNamesConstantsGroup.c_notChecked)
	public static <T> T [] createArray (Class <?> a_class, Collection <?> a_collection) {
		int l_size = 0;
		if (a_collection != null) {
			l_size = a_collection.size ();
		}
		T [] l_array = (T []) Array.newInstance (a_class, l_size);
		if (l_size != 0) {
			return (T []) a_collection.toArray (l_array);
		}
		else {
			return l_array;
		}
	}
}

