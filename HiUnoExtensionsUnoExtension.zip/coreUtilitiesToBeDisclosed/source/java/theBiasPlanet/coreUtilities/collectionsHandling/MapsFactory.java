package theBiasPlanet.coreUtilities.collectionsHandling;

import java.util.Map;
import java.util.LinkedHashMap;
import theBiasPlanet.coreUtilities.collections.NavigableLinkedHashMap;
import theBiasPlanet.coreUtilities.constantsGroups.WarningNamesConstantsGroup;

public class MapsFactory {
	@SafeVarargs
	@SuppressWarnings (WarningNamesConstantsGroup.c_notChecked)
	public static <T, U> LinkedHashMap <T, U> createLinkedHashMap (Object ... a_alternatelyKeyAndValue) {
		LinkedHashMap <T, U> l_linkedHashMap = new LinkedHashMap <T, U> ();
		if (a_alternatelyKeyAndValue != null) {
			T l_key = null;
			for (Object l_keyOrValue: a_alternatelyKeyAndValue) {
				if (l_key == null) {
					l_key = (T) l_keyOrValue;
				}
				else {
					l_linkedHashMap.put (l_key, (U) l_keyOrValue);
					l_key = null;
				}
			}
		}
		return l_linkedHashMap;
	}
	
	@SafeVarargs
	@SuppressWarnings (WarningNamesConstantsGroup.c_notChecked)
	public static <T, U> LinkedHashMap <T, U> createLinkedHashMapExpandingItems (Object ... a_alternatelyKeyAndValueOrMaps) {
		LinkedHashMap <T, U> l_linkedHashMap = new LinkedHashMap <T, U> ();
		if (a_alternatelyKeyAndValueOrMaps != null) {
			T l_key = null;
			for (Object l_keyOrValueOrMap: a_alternatelyKeyAndValueOrMaps) {
				if (l_keyOrValueOrMap instanceof Map) {
					for (Map.Entry <?, ?> l_mapEntry: ((Map <?, ?>) l_keyOrValueOrMap).entrySet ()) {
						l_linkedHashMap.put ((T) l_mapEntry.getKey (), (U) l_mapEntry.getValue ());
					}
					l_key = null;
				}
				else {
					if (l_key == null) {
						l_key = (T) l_keyOrValueOrMap;
					}
					else {
						l_linkedHashMap.put (l_key, (U) l_keyOrValueOrMap);
						l_key = null;
					}
				}
			}
		}
		return l_linkedHashMap;
	}
	
	@SafeVarargs
	@SuppressWarnings (WarningNamesConstantsGroup.c_notChecked)
	public static <T, U> NavigableLinkedHashMap <T, U> createNavigableLinkedHashMap (Object ... a_alternatelyKeyAndValue) {
		NavigableLinkedHashMap <T, U> l_navigableLinkedHashMap = new NavigableLinkedHashMap <T, U> ();
		if (a_alternatelyKeyAndValue != null) {
			T l_key = null;
			for (Object l_keyOrValue: a_alternatelyKeyAndValue) {
				if (l_key == null) {
					l_key = (T) l_keyOrValue;
				}
				else {
					l_navigableLinkedHashMap.put (l_key, (U) l_keyOrValue);
					l_key = null;
				}
			}
		}
		return l_navigableLinkedHashMap;
	}
	
	@SafeVarargs
	@SuppressWarnings (WarningNamesConstantsGroup.c_notChecked)
	public static <T, U> NavigableLinkedHashMap <T, U> createNavigableLinkedHashMapExpandingItems (Object ... a_alternatelyKeyAndValueOrMaps) {
		NavigableLinkedHashMap <T, U> l_navigableLinkedHashMap = new NavigableLinkedHashMap <T, U> ();
		if (a_alternatelyKeyAndValueOrMaps != null) {
			T l_key = null;
			for (Object l_keyOrValueOrMap: a_alternatelyKeyAndValueOrMaps) {
				if (l_keyOrValueOrMap instanceof Map) {
					for (Map.Entry <?, ?> l_mapEntry: ((Map <?, ?>) l_keyOrValueOrMap).entrySet ()) {
						l_navigableLinkedHashMap.put ((T) l_mapEntry.getKey (), (U) l_mapEntry.getValue ());
					}
					l_key = null;
				}
				else {
					if (l_key == null) {
						l_key = (T) l_keyOrValueOrMap;
					}
					else {
						l_navigableLinkedHashMap.put (l_key, (U) l_keyOrValueOrMap);
						l_key = null;
					}
				}
			}
		}
		return l_navigableLinkedHashMap;
	}
}

