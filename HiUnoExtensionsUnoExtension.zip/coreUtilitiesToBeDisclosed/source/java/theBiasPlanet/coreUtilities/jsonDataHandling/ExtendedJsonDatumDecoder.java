package theBiasPlanet.coreUtilities.jsonDataHandling;

import java.io.IOException;
import java.io.Reader;
import theBiasPlanet.coreUtilities.inputsHandling.BufferOverflowedException;
import theBiasPlanet.coreUtilities.jsonDataHandling.ExtendedJsonDatumParseEventsHandlerForRememberingWholeStructure;
import theBiasPlanet.coreUtilities.jsonDataHandling.ExtendedJsonDatumParser;

public final class ExtendedJsonDatumDecoder {
	private ExtendedJsonDatumDecoder () {
	}
	
	public static Object decode (Reader a_jsonDatumReader) throws IOException, InterruptedException, BufferOverflowedException, JsonDatumItemUnsupportedValueException {
		try {
			ExtendedJsonDatumParseEventsHandlerForRememberingWholeStructure l_extendedJsonDatumParseEventsHandlerForRememberingWholeStructure = new ExtendedJsonDatumParseEventsHandlerForRememberingWholeStructure ();
			ExtendedJsonDatumParser l_extendedJsonDatumParser = new ExtendedJsonDatumParser ();
			l_extendedJsonDatumParser.parse (a_jsonDatumReader, l_extendedJsonDatumParseEventsHandlerForRememberingWholeStructure);
			return l_extendedJsonDatumParseEventsHandlerForRememberingWholeStructure.getRootItem ();
		}
		catch (IOException | InterruptedException |  BufferOverflowedException | JsonDatumItemUnsupportedValueException l_exception) {
			throw l_exception;
		}
		catch (JsonParsingTerminatedException l_exception) {
			// impossible
			return null;
		}
		catch (Exception  l_exception) {
			// impossible
			return null;
		}
	}
}

