package theBiasPlanet.coreUtilities.jsonDataHandling;

public class JsonDatumItemUnsupportedClassException extends Exception {
	public JsonDatumItemUnsupportedClassException (String a_message) {
		super (a_message);
	}
}

