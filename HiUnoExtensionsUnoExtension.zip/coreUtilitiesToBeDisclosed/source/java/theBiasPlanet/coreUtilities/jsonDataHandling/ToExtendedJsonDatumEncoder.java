package theBiasPlanet.coreUtilities.jsonDataHandling;

import java.nio.file.Path;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import theBiasPlanet.coreUtilities.constantsGroups.CharactersSetNamesConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.DefaultValuesConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.InputPropertiesConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.MessagesConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.WarningNamesConstantsGroup;
import theBiasPlanet.coreUtilities.messagingHandling.Publisher;
import theBiasPlanet.coreUtilities.inputs.PushableReader;

public final class ToExtendedJsonDatumEncoder {
	private static final int c_bufferSize = DefaultValuesConstantsGroup.c_smallBufferSize;
	private char [] i_buffer = new char [c_bufferSize];
	private Writer i_extendedJsonDatumWriter = null;
	
	public ToExtendedJsonDatumEncoder (Writer a_extendedJsonDatumWriter) {
		i_extendedJsonDatumWriter = a_extendedJsonDatumWriter;
	}
	
	public void encode (Object a_object) throws IOException, JsonDatumItemUnsupportedClassException {
		try {
			encodeObject (a_object);
		}
		catch (IOException l_exception) {
			try {
				i_extendedJsonDatumWriter.write (String.format (MessagesConstantsGroup.c_errorHasOccurred, l_exception.toString ()));
			}
			catch (Exception l_exceptionOfInnerTry) {
				Publisher.logErrorInformation (l_exceptionOfInnerTry);
			}
			throw l_exception;
		}
	}
	
	private void encodeString (Reader a_stringReader) throws IOException {
		i_extendedJsonDatumWriter.write (GeneralConstantsConstantsGroup.c_doubleQuotationMarkCharacter);
		PushableReader l_pushableStringReader = new PushableReader (a_stringReader, c_bufferSize);
		int l_readLength = InputPropertiesConstantsGroup.c_noDataRetrieved;
		int l_toReadLength = InputPropertiesConstantsGroup.c_lengthNotSet;
		int l_readFunctionReturn = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		l_toReadLength = 1;
		while ((l_readFunctionReturn = l_pushableStringReader.readFixedLengthData (i_buffer, l_readLength, l_toReadLength)) != InputPropertiesConstantsGroup.c_noMoreData) {
			l_readLength += l_readFunctionReturn;
			if (GeneralConstantsConstantsGroup.c_characterToEscapedCharacterMap.containsKey (i_buffer [l_readLength - 1])) {
				i_extendedJsonDatumWriter.write (GeneralConstantsConstantsGroup.c_characterToEscapedCharacterMap.get (Character.valueOf (i_buffer [l_readLength - 1])));
			}
			else {
				i_extendedJsonDatumWriter.write (i_buffer, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength);
			}
			l_readLength = InputPropertiesConstantsGroup.c_noDataRetrieved;
		}
		i_extendedJsonDatumWriter.write (GeneralConstantsConstantsGroup.c_doubleQuotationMarkCharacter);
		return;
	}
	
	private void encodeDouble (Double a_double) throws IOException {
		if (a_double == null || a_double.isNaN ()) {
			i_extendedJsonDatumWriter.write (GeneralConstantsConstantsGroup.c_notANumberExpression);
		}
		else if (a_double.doubleValue() == a_double.POSITIVE_INFINITY) {
			i_extendedJsonDatumWriter.write (GeneralConstantsConstantsGroup.c_positiveInfinityExpression);
		}
		else if (a_double.doubleValue() == a_double.NEGATIVE_INFINITY) {
			i_extendedJsonDatumWriter.write (GeneralConstantsConstantsGroup.c_negativeInfinityExpression);
		}
		else {
			i_extendedJsonDatumWriter.write (a_double.toString ());
		}
		return;
	}
	
	private void encodeFloat (Float a_float) throws IOException {
		if (a_float == null || a_float.isNaN ()) {
			i_extendedJsonDatumWriter.write (GeneralConstantsConstantsGroup.c_notANumberExpression);
		}
		else if (a_float.floatValue() == a_float.POSITIVE_INFINITY) {
			i_extendedJsonDatumWriter.write (GeneralConstantsConstantsGroup.c_positiveInfinityExpression);
		}
		else if (a_float.doubleValue() == a_float.NEGATIVE_INFINITY) {
			i_extendedJsonDatumWriter.write (GeneralConstantsConstantsGroup.c_negativeInfinityExpression);
		}
		else {
			i_extendedJsonDatumWriter.write (a_float.toString ());
		}
		return;
	}
	
	private void encodeObject (Object a_object) throws IOException, JsonDatumItemUnsupportedClassException {
		if (a_object == null) {
			i_extendedJsonDatumWriter.write (GeneralConstantsConstantsGroup.c_nullExpression);
			return;
		}
		else if (a_object instanceof Reader) {
			encodeString ( (Reader) a_object);
			return;
		}
		else if (a_object instanceof String) {
			encodeString (new StringReader ( (String) a_object));
			return;
		}
		else if (a_object instanceof Boolean) {
			if ( ( (Boolean) a_object).booleanValue ()) {
				i_extendedJsonDatumWriter.write (GeneralConstantsConstantsGroup.c_trueExpression);
			}
			else {
				i_extendedJsonDatumWriter.write (GeneralConstantsConstantsGroup.c_falseExpression);
			}
			return;
		}
		else if (a_object instanceof Integer) {
			i_extendedJsonDatumWriter.write (a_object.toString ());
			return;
		}
		else if (a_object instanceof Double) {
			encodeDouble ( (Double) a_object);
			return;
		}
		else if (a_object instanceof Float) {
			encodeFloat ( (Float) a_object);
			return;
		}
		else if (a_object instanceof LocalDate) {
			i_extendedJsonDatumWriter.write (GeneralConstantsConstantsGroup.c_jsonDateEtcOpener + ( (LocalDate) a_object).format (DateTimeFormatter.ISO_LOCAL_DATE));
			return;
		}
		else if (a_object instanceof LocalTime) {
			i_extendedJsonDatumWriter.write (GeneralConstantsConstantsGroup.c_jsonDateEtcOpener + ( (LocalTime) a_object).format (DateTimeFormatter.ISO_LOCAL_TIME));
			return;
		}
		else if (a_object instanceof LocalDateTime) {
			i_extendedJsonDatumWriter.write (GeneralConstantsConstantsGroup.c_jsonDateEtcOpener + ( (LocalDateTime) a_object).format (DateTimeFormatter.ISO_LOCAL_DATE_TIME));
			return;
		}
		else if (a_object instanceof byte []) {
			byte [] l_base64ByteArray = Base64.getEncoder ().encode ( (byte []) a_object);
			try {
				i_extendedJsonDatumWriter.write (GeneralConstantsConstantsGroup.c_jsonBytesArrayOpener);
				encodeString (new StringReader (new String (l_base64ByteArray, CharactersSetNamesConstantsGroup.c_utf8CharactersSetName)));
				return;
			}
			catch (UnsupportedEncodingException l_exception) {
				// won't come here
				return;
			}
		}
		else if (a_object instanceof Path) {
			i_extendedJsonDatumWriter.write (GeneralConstantsConstantsGroup.c_jsonPathOpener);
			encodeString (new StringReader (a_object.toString ()));
			return;
		}
		else if (a_object instanceof List) {
			@SuppressWarnings (WarningNamesConstantsGroup.c_notChecked)
			List <Object> l_list = (List <Object>) a_object;
			encodeList (l_list);
			return;
		}
		else if (a_object instanceof Map) {
			@SuppressWarnings (WarningNamesConstantsGroup.c_notChecked)
			Map <Object, Object> l_map = (Map <Object, Object>) a_object;
			encodeMap (l_map);
			return;
		}
		else {
			dealWithJavaObjectWithoutBuiltinSupport (a_object);
			return;
		}
	}
	
	private void encodeList (List a_list) throws IOException, JsonDatumItemUnsupportedClassException {
		i_extendedJsonDatumWriter.write (GeneralConstantsConstantsGroup.c_jsonArrayOpener);
		boolean l_isFirstItem = true;
		for (Object l_item: a_list) {
			if (!l_isFirstItem) {
				i_extendedJsonDatumWriter.write (GeneralConstantsConstantsGroup.c_jsonItemsSeparator);
			}
			else {
				l_isFirstItem = false;
			}
			encodeObject (l_item);
		}
		i_extendedJsonDatumWriter.write (GeneralConstantsConstantsGroup.c_jsonArrayCloser);
	}
	
	private void encodeMap (Map a_map) throws IOException, JsonDatumItemUnsupportedClassException {
		i_extendedJsonDatumWriter.write (GeneralConstantsConstantsGroup.c_jsonDictionaryOpener);
		boolean l_isFirstItem = true;
		@SuppressWarnings (WarningNamesConstantsGroup.c_notChecked)
		Set <Map.Entry <Object, Object>> l_mapEntrySet = a_map.entrySet ();
		for (Map.Entry <Object, Object> l_mapEntry: l_mapEntrySet) {
			if (!l_isFirstItem) {
				i_extendedJsonDatumWriter.write (GeneralConstantsConstantsGroup.c_jsonItemsSeparator);
			}
			else {
				l_isFirstItem = false;
			}
			encodeObject (l_mapEntry.getKey ());
			i_extendedJsonDatumWriter.write (GeneralConstantsConstantsGroup.c_jsonKeyValueSeparator);
			encodeObject (l_mapEntry.getValue ());
		}
		i_extendedJsonDatumWriter.write (GeneralConstantsConstantsGroup.c_jsonDictionaryCloser);
	}
	
	private void dealWithJavaObjectWithoutBuiltinSupport (Object a_object) throws IOException, JsonDatumItemUnsupportedClassException {
		throw new JsonDatumItemUnsupportedClassException (a_object.toString ());
	}
}

