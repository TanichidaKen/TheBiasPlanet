package theBiasPlanet.coreUtilities.jsonDataHandling;

import java.io.Reader;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.EmptyStackException;
import java.util.Stack;
import theBiasPlanet.coreUtilities.collections.NavigableLinkedHashMap;
import theBiasPlanet.coreUtilities.constantsGroups.WarningNamesConstantsGroup;
import theBiasPlanet.coreUtilities.inputsHandling.ReaderHandler;
import theBiasPlanet.coreUtilities.messagingHandling.Publisher;
import theBiasPlanet.coreUtilities.stringsHandling.StringHandler;

public class ExtendedJsonDatumParseEventsHandlerForRememberingWholeStructure extends ExtendedJsonDatumParseEventsHandler {
	private Object i_rootItem = null;
	private Stack <Object> i_listAndMapStack = null; // The current list or map is not included.
	private ArrayList <Object> i_currentList = null;
	private NavigableLinkedHashMap <Object, Object> i_currentMap = null;
	private Object i_currentMapKey = null;
	
	private void regiterItem (Object a_item) {
		if (i_currentList != null) {
			i_currentList.add (a_item);
		}
		else if (i_currentMap != null) {
			if (i_currentMapKey == null) {
				i_currentMapKey = a_item;
			}
			else {
				i_currentMap.put (i_currentMapKey, a_item);
				i_currentMapKey = null;
			}
		}
		else if (i_rootItem == null) {
			i_rootItem = a_item;
		}
	}
	
	private void stackCurrentListOrMap () {
		if (i_currentList != null) {
			i_listAndMapStack.push (i_currentList);
			i_currentList = null;
		}
		else if (i_currentMap != null) {
			i_listAndMapStack.push (i_currentMap);
			i_currentMap = null;
		}
	}
	
	@SuppressWarnings (WarningNamesConstantsGroup.c_notChecked)
	private void popPreviousListOrMap () {
		try {
			Object l_currentListOrMap = i_listAndMapStack.pop ();
			if (l_currentListOrMap instanceof ArrayList) {
				i_currentList = (ArrayList <Object>) l_currentListOrMap;
				i_currentMap = null;
			}
			else {
				i_currentList = null;
				i_currentMap = (NavigableLinkedHashMap <Object, Object>) l_currentListOrMap;
			}
		}
		catch (EmptyStackException l_exception) {
			i_currentList = null;
			i_currentMap = null;
		}
	}
	
	public void initialize () {
		i_rootItem = null;
		i_listAndMapStack = new Stack <Object> ();
		i_currentList = null;
		i_currentMap = null;
	}
	
	public boolean onNullFound () throws Exception {
		regiterItem (null);
		return true;
	}
	
	public boolean onBooleanFound (Boolean a_value) throws Exception {
		regiterItem (a_value);
		return true;
	}
	
	public boolean onIntegerFound (Integer a_value) throws Exception {
		regiterItem (a_value);
		return true;
	}
	
	public boolean onDoubleFound (Double a_value) throws Exception {
		regiterItem (a_value);
		return true;
	}
	
	public boolean onLocalDateAndTimeFound (LocalDateTime a_value) throws Exception {
		regiterItem (a_value);
		return true;
	}
	
	public boolean onLocalDateFound (LocalDate a_value) throws Exception {
		regiterItem (a_value);
		return true;
	}
	
	public boolean onLocalTimeFound (LocalTime a_value) throws Exception {
		regiterItem (a_value);
		return true;
	}
	
	public boolean onBytesArrayFound (Reader a_reader) throws Exception {
		regiterItem (StringHandler.decodeBase64String (ReaderHandler.getWholeString (a_reader)));
		return true;
	}
	
	public boolean onPathFound (Path a_value) throws Exception {
		regiterItem (a_value);
		return true;
	}
	
	public boolean onStringFound (Reader a_reader) throws Exception {
		regiterItem (ReaderHandler.getWholeString (a_reader));
		return true;
	}
	
	public boolean onArrayStarted () throws Exception {
		ArrayList <Object> l_newList = new ArrayList <Object> ();
		regiterItem (l_newList);
		stackCurrentListOrMap ();
		i_currentList = l_newList;
		i_currentMap = null;
		return true;
	}
	
	public boolean onArrayEnded () throws Exception {
		popPreviousListOrMap ();
		return true;
	}
	
	public boolean onDictionaryStarted () throws Exception {
		NavigableLinkedHashMap <Object, Object> l_newMap = new NavigableLinkedHashMap <Object, Object> ();
		regiterItem (l_newMap);
		stackCurrentListOrMap ();
		i_currentList = null;
		i_currentMap = l_newMap;
		return true;
	}
	
	public boolean onDictionaryEnded () throws Exception {
		popPreviousListOrMap ();
		return true;
	}
	
	public void onException (Exception a_exception) throws Exception {
		Publisher.logErrorInformation (a_exception);
	}
	
	public Object getRootItem () {
		return i_rootItem;
	}
}

