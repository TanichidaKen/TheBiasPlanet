package theBiasPlanet.coreUtilities.inputs;

import java.io.FilterReader;
import java.io.IOException;
import java.io.InputStreamReader;
import theBiasPlanet.coreUtilities.constantsGroups.CharactersSetNamesConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.DefaultValuesConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.InputPropertiesConstantsGroup;

public class Utf8BomIgnoringInputStreamReader extends FilterReader {
	private boolean i_isInUtf8 = false;
	private boolean i_isAtTheStart = true;
	private char [] i_inMethodBuffer = new char [DefaultValuesConstantsGroup.c_smallestBufferSize];
	
	public Utf8BomIgnoringInputStreamReader (InputStreamReader a_underlyingInputStreamReader) {
		super (a_underlyingInputStreamReader);
		if (CharactersSetNamesConstantsGroup.c_utf8InputStreamReaderReturningCharactersSetName.equals (a_underlyingInputStreamReader.getEncoding())) {
			i_isInUtf8 = true;
		}
	}
	
	@Override
	public int read (char [] a_charactersArray, int a_offset, int a_length) throws IOException {
		int l_readLength = InputPropertiesConstantsGroup.c_lengthNotRead;
		if (i_isInUtf8 && i_isAtTheStart) {
			char [] l_charactersArray = new char [a_length];
			l_readLength = in.read (l_charactersArray, a_offset, a_length);
			if (l_readLength > InputPropertiesConstantsGroup.c_noDataRetrieved) {
				int l_charactersOffset = GeneralConstantsConstantsGroup.c_iterationStartNumber;
				if (l_charactersArray [GeneralConstantsConstantsGroup.c_iterationStartNumber] == GeneralConstantsConstantsGroup.c_utfBomCharacter) {
					l_charactersOffset ++;
				}
				for (int l_characterIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber; l_characterIndex + l_charactersOffset < l_readLength; l_characterIndex ++) {
					a_charactersArray [l_characterIndex] = l_charactersArray [l_characterIndex + l_charactersOffset];
				}
				l_readLength -= l_charactersOffset;
				if (l_charactersOffset > GeneralConstantsConstantsGroup.c_iterationStartNumber) {
					if (in.read (a_charactersArray, l_readLength, l_charactersOffset) == l_charactersOffset) {
						l_readLength += l_charactersOffset;
					}
				}
			}
			i_isAtTheStart = false;
		}
		else {
			l_readLength = in.read (a_charactersArray, a_offset, a_length);
		}
		return l_readLength;
	}
	
	@Override
	public int read () throws IOException {
		int l_readFunctionReturn = read (i_inMethodBuffer, GeneralConstantsConstantsGroup.c_iterationStartNumber, DefaultValuesConstantsGroup.c_smallestBufferSize);
		if (l_readFunctionReturn == InputPropertiesConstantsGroup.c_noMoreData) {
			return InputPropertiesConstantsGroup.c_noMoreData;
		}
		else {
			return i_inMethodBuffer [GeneralConstantsConstantsGroup.c_iterationStartNumber];
		}
	}
}

