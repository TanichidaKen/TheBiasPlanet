package theBiasPlanet.coreUtilities.inputs;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.Map;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import theBiasPlanet.coreUtilities.collections.NavigableLinkedHashMap;
import theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup;
import theBiasPlanet.coreUtilities.inputsHandling.NoMoreDataException;
import theBiasPlanet.coreUtilities.messagingHandling.Publisher;
import theBiasPlanet.coreUtilities.pipes.StringPipe;
import theBiasPlanet.coreUtilities.timersHandling.TimeOutException;

public class HaltableReader {
	private Reader i_underlyingReader;
	private int i_bufferSize;
	private Thread i_dispatchDataThread = null;
	private NavigableLinkedHashMap <String, StringPipe> i_subscriberIdentificationToStringPipeMap = new NavigableLinkedHashMap <String, StringPipe> ();
	private ReentrantReadWriteLock i_sharableLock = new ReentrantReadWriteLock (true);
	
	public HaltableReader (Reader a_underlyingReader, int a_bufferSize) {
		i_underlyingReader = a_underlyingReader;
		i_bufferSize = a_bufferSize;
	}
	
	// Any subscriber has to read consistently, or the other subscribers may be stuck because the dispatching thread will be stuck waiting to write to the string pipe for the neglecting subscriber.
	public void addSubscriber (String a_subscriberIdentification) {
		try {
			i_sharableLock.writeLock ().lock ();
			i_subscriberIdentificationToStringPipeMap.put (a_subscriberIdentification, new StringPipe (i_bufferSize, false));
		}
		finally {
			i_sharableLock.writeLock ().unlock ();
		}
	}
	
	public void removeSubscriber (String a_subscriberIdentification) {
		try {
			i_sharableLock.readLock ().lock ();
			StringPipe l_stringPipe = i_subscriberIdentificationToStringPipeMap.get (a_subscriberIdentification);
			if (l_stringPipe != null) {
				l_stringPipe.finishWriting ();
			}
		}
		finally {
			i_sharableLock.readLock ().unlock ();
		}
		try {
			i_sharableLock.writeLock ().lock ();
			i_subscriberIdentificationToStringPipeMap.remove (a_subscriberIdentification);
		}
		finally {
			i_sharableLock.writeLock ().unlock ();
		}
	}
	
	public void startDispatchDataThread () {
		if (i_dispatchDataThread == null) {
			i_dispatchDataThread = new Thread (() -> {
				try {
					int l_readFunctionReturn;
					while (true) {
						l_readFunctionReturn = i_underlyingReader.read ();
						if (l_readFunctionReturn == GeneralConstantsConstantsGroup.c_unspecifiedInteger) {
							break;
						}
						String l_inputDatum = String.valueOf ( (char) l_readFunctionReturn);
						try {
							i_sharableLock.readLock ().lock ();
							for (Map.Entry <String, StringPipe> l_subscriberIdentificationToStringPipeMapEntry: i_subscriberIdentificationToStringPipeMap.entrySet ()) {
								l_subscriberIdentificationToStringPipeMapEntry.getValue ().writeWholeString (new StringReader (l_inputDatum));
							}
						}
						finally {
							i_sharableLock.readLock().unlock();
						}
					}
				}
				catch (Exception l_exception) {
					Publisher.logErrorInformation (l_exception);
				}
				finally {
					try {
						i_sharableLock.readLock().lock();
						for (Map.Entry <String, StringPipe> l_subscriberIdentificationToStringPipeMapEntry: i_subscriberIdentificationToStringPipeMap.entrySet ()) {
							l_subscriberIdentificationToStringPipeMapEntry.getValue ().finishWriting ();
						}
					}
					finally {
						i_sharableLock.readLock().unlock();
					}
				}
			});
			i_dispatchDataThread.setDaemon (true);
			i_dispatchDataThread.start ();
		}
	}
	
	public void close () throws IOException {
		i_underlyingReader.close ();
	}
	
	public String read (String a_subscriberIdentification, int a_maximumLength, int a_timeOutPeriodInMilliseconds) throws NoMoreDataException, TimeOutException {
		StringPipe l_stringPipe = null;
		try {
			i_sharableLock.readLock ().lock ();
			l_stringPipe = i_subscriberIdentificationToStringPipeMap.get (a_subscriberIdentification);
		}
		finally {
			i_sharableLock.readLock ().unlock ();
		}
		if (l_stringPipe != null) {
			return l_stringPipe.readString (a_maximumLength, a_timeOutPeriodInMilliseconds);
		}
		else {
			throw new NoMoreDataException ("");
		}
	}
	
	public String read (String a_subscriberIdentification, int a_maximumLength) throws NoMoreDataException, TimeOutException {
		return read (a_subscriberIdentification, a_maximumLength, -1);
	}
	
	public String readLine (String a_subscriberIdentification, int a_maximumLength, int a_timeOutPeriodInMilliseconds) throws NoMoreDataException, TimeOutException {
		StringPipe l_stringPipe = null;
		try {
			i_sharableLock.readLock ().lock ();
			l_stringPipe = i_subscriberIdentificationToStringPipeMap.get (a_subscriberIdentification);
		}
		finally {
			i_sharableLock.readLock ().unlock ();
		}
		if (l_stringPipe != null) {
			return l_stringPipe.readStringLine (a_maximumLength, a_timeOutPeriodInMilliseconds);
		}
		else {
			throw new NoMoreDataException ("");
		}
	}
	
	public String readLine (String a_subscriberIdentification, int a_maximumLength) throws NoMoreDataException, TimeOutException {
		return readLine (a_subscriberIdentification, a_maximumLength, -1);
	}
	
	public boolean isReady (String a_subscriberIdentification) {
		StringPipe l_stringPipe = null;
		try {
			i_sharableLock.readLock ().lock ();
			l_stringPipe = i_subscriberIdentificationToStringPipeMap.get (a_subscriberIdentification);
		}
		finally {
			i_sharableLock.readLock ().unlock ();
		}
		if (l_stringPipe != null) {
			return ! (l_stringPipe.isEmpty ());
		}
		else {
			return false;
		}
	}
}

