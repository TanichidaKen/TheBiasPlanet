package theBiasPlanet.coreUtilities.inputs;

import java.io.Reader;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import theBiasPlanet.coreUtilities.bytesArraysHandling.BytesBufferToCharactersBufferDecoder;
import theBiasPlanet.coreUtilities.bytesArraysHandling.BytesBufferToCharactersBufferDecodingResult;
import theBiasPlanet.coreUtilities.constantsGroups.DefaultValuesConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.InputPropertiesConstantsGroup;

public class BytesLengthSpecifiedReader extends Reader {
	private BytesLengthSpecifiedInputStream i_underlyingBytesLengthSpecifiedInputStream = null;
	private	ByteBuffer i_inputBytesBuffer = ByteBuffer.wrap (new byte [DefaultValuesConstantsGroup.c_smallBufferSize]);
	private	CharBuffer i_temporaryOutputCharactersBuffer = CharBuffer.wrap (new char [DefaultValuesConstantsGroup.c_smallestBufferSize]);
	private BytesBufferToCharactersBufferDecoder i_bytesBufferToCharactersBufferDecoder = null; 
	
	public BytesLengthSpecifiedReader (BytesLengthSpecifiedInputStream a_underlyingBytesLengthSpecifiedInputStream, String a_charactersSet) {
		i_underlyingBytesLengthSpecifiedInputStream = a_underlyingBytesLengthSpecifiedInputStream;
		i_bytesBufferToCharactersBufferDecoder = new BytesBufferToCharactersBufferDecoder (a_charactersSet);
	}
	
	@Override
	public boolean ready () throws IOException {
		return (i_underlyingBytesLengthSpecifiedInputStream.available () > 0) ? true : false;
	}
	
	@Override
	public void close () throws IOException {
		i_underlyingBytesLengthSpecifiedInputStream.close ();
	}
	
	@Override
	public int read () throws IOException {
		int l_readingResult = read (i_temporaryOutputCharactersBuffer.array (), GeneralConstantsConstantsGroup.c_iterationStartNumber, i_temporaryOutputCharactersBuffer.capacity ());
		if (l_readingResult == InputPropertiesConstantsGroup.c_noMoreData) {
			return InputPropertiesConstantsGroup.c_noMoreData;
		}
		else {
			return i_temporaryOutputCharactersBuffer.get (GeneralConstantsConstantsGroup.c_iterationStartNumber);
		}
	}
	
	@Override
	public int read (char [] a_charactersArray) throws IOException {
		return read (a_charactersArray, 0, a_charactersArray.length);
	}
	
	@Override
	public int read (char [] a_charactersArray, int a_offset, int a_length) throws IOException {
		int l_maximumLengthOfBytesToReadThisTime = a_length; // Although a characters length can correspond to a longer bytes length, as 'a_length' is just a maximum, we are going to read only 'a_length' bytes unless it doesn't constitute even a single character: at least one character has to be read unless there is no character is left.
		CharBuffer l_outputCharactersBuffer = CharBuffer.wrap (a_charactersArray, a_offset, a_length);
		BytesBufferToCharactersBufferDecodingResult l_bytesBufferToCharactersBufferDecodingResult = null;
		int l_readingResult = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		int l_processedBytesLengthSoFar = 0;
		while (true) {
			int l_processedBytesLengthPerIteration = Math.min (l_maximumLengthOfBytesToReadThisTime - l_processedBytesLengthSoFar, i_inputBytesBuffer.capacity ());
			l_readingResult = i_underlyingBytesLengthSpecifiedInputStream.read (i_inputBytesBuffer.array (), GeneralConstantsConstantsGroup.c_iterationStartNumber, l_processedBytesLengthPerIteration);
			if (l_readingResult == InputPropertiesConstantsGroup.c_noMoreData) {
				i_inputBytesBuffer.limit (GeneralConstantsConstantsGroup.c_iterationStartNumber);
				l_bytesBufferToCharactersBufferDecodingResult = i_bytesBufferToCharactersBufferDecoder.decode (i_inputBytesBuffer, l_outputCharactersBuffer, true);
				i_bytesBufferToCharactersBufferDecoder.reset ();
				if (!l_bytesBufferToCharactersBufferDecodingResult.isJustFit () ) {
					throw new IOException ();
				}
				if (l_outputCharactersBuffer.position () == a_offset) {
					return InputPropertiesConstantsGroup.c_noMoreData;
				}
				else {
					return l_outputCharactersBuffer.position () - a_offset;
				}
			}
			else {
				i_inputBytesBuffer.limit (l_readingResult);
				i_inputBytesBuffer.position (GeneralConstantsConstantsGroup.c_iterationStartNumber);
				l_bytesBufferToCharactersBufferDecodingResult = i_bytesBufferToCharactersBufferDecoder.decode (i_inputBytesBuffer, l_outputCharactersBuffer, false);
				if (l_bytesBufferToCharactersBufferDecodingResult.isMalformed ()) {
					throw new IOException ("The data is malformed.");
				}
				else if (l_bytesBufferToCharactersBufferDecodingResult.isUnmappable ()) {
					throw new IOException ("The data is unmappable.");
				}
			}
			l_processedBytesLengthSoFar += l_processedBytesLengthPerIteration;
			if (l_processedBytesLengthSoFar == l_maximumLengthOfBytesToReadThisTime ) {
				break;
			}
		}
		if (l_outputCharactersBuffer.position () == a_offset) {
			// reading at least 1 character
			for (int l_iterationIndex = l_processedBytesLengthSoFar; l_iterationIndex < GeneralConstantsConstantsGroup.c_maximumBytesLengthPerUtf8Character; l_iterationIndex ++) {
				l_readingResult = i_underlyingBytesLengthSpecifiedInputStream.read ();
				if (l_readingResult == InputPropertiesConstantsGroup.c_noMoreData) {
					return InputPropertiesConstantsGroup.c_noMoreData;
				}
				else {
					i_inputBytesBuffer.clear ();
					i_inputBytesBuffer.put ( (byte) l_readingResult);
					i_inputBytesBuffer.flip ();
					l_bytesBufferToCharactersBufferDecodingResult = i_bytesBufferToCharactersBufferDecoder.decode (i_inputBytesBuffer, l_outputCharactersBuffer, false);
					if (l_bytesBufferToCharactersBufferDecodingResult.isMalformed ()) {
						throw new IOException ("The data is malformed.");
					}
					else if (l_bytesBufferToCharactersBufferDecodingResult.isUnmappable ()) {
						throw new IOException ("The data is unmappable");
					}
					else if (l_bytesBufferToCharactersBufferDecodingResult.isJustFit ()) {
						break;
					}
				}
			}
		}
		if (l_outputCharactersBuffer.position () > a_offset) {
			return l_outputCharactersBuffer.position () - a_offset;
		}
		else {
			return InputPropertiesConstantsGroup.c_noMoreData;
		}
	}
	
	@Override
	public long skip (long a_charactersLengthToBeSkipped) throws IOException {
		long l_characterIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
		for (; l_characterIndex < a_charactersLengthToBeSkipped; l_characterIndex ++) {
			if (read () == InputPropertiesConstantsGroup.c_noMoreData) {
				break;
			}
		}
		return l_characterIndex;
	}
	
	@Override
	public void mark (int a_readLimit) {
		throw new UnsupportedOperationException ();
	}
	
	@Override
	public void reset () throws IOException {
		throw new IOException ();
	}
	
	@Override
	public boolean markSupported () {
		return false;
	}
	
	public void prepareForNextPart () {
		i_underlyingBytesLengthSpecifiedInputStream.prepareForNextPart (); 
		i_inputBytesBuffer.clear ();
		i_bytesBufferToCharactersBufferDecoder.reset ();
	}
	
	public int getBytesLength () {
		return i_underlyingBytesLengthSpecifiedInputStream.getBytesLength ();
	}
}

