package theBiasPlanet.coreUtilities.inputs;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import theBiasPlanet.coreUtilities.constantsGroups.DefaultValuesConstantsGroup;

public class HaltableStandardInputReader extends HaltableReader {
	private static HaltableStandardInputReader s_singletonInstance = null;
	
	private HaltableStandardInputReader () {
		super (new BufferedReader (new InputStreamReader (System.in)), DefaultValuesConstantsGroup.c_smallBufferSize);
	}
	
	public static HaltableStandardInputReader getInstance () {
		if (s_singletonInstance == null) {
			s_singletonInstance = new HaltableStandardInputReader ();
		}
		return s_singletonInstance;
	}
}

