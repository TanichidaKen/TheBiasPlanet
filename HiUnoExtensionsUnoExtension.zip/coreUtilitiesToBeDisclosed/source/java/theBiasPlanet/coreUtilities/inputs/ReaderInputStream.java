package theBiasPlanet.coreUtilities.inputs;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.io.Reader;
import theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.InputPropertiesConstantsGroup;

public class ReaderInputStream extends InputStream {
	private Reader i_reader;
	private PipedInputStream i_pipedInputStream;	
	private PipedOutputStream i_pipedOutputStream;
	private OutputStreamWriter i_pipedOutputStreamWriter;
	
	public ReaderInputStream (Reader a_reader, String a_charactersSet) throws IOException {
		i_reader = a_reader;
		i_pipedOutputStream = new PipedOutputStream ();
		i_pipedInputStream = new PipedInputStream (i_pipedOutputStream);
		i_pipedOutputStreamWriter = new OutputStreamWriter (i_pipedOutputStream, a_charactersSet);
	}
	
	@Override
	public int available () throws IOException {
		int l_available = i_pipedInputStream.available ();
		if (l_available > InputPropertiesConstantsGroup.c_lengthNotRead) {
			return l_available;
		}
		if (i_reader.ready ()) {
			return 1;
		} else {
			return InputPropertiesConstantsGroup.c_lengthNotRead;
		}
	}
	
	@Override
	public void close () throws IOException {
		i_pipedOutputStreamWriter.close ();
		i_pipedInputStream.close ();
		i_pipedOutputStream.close ();
		i_reader.close ();
	}
	
	@Override
	public int read () throws IOException {
		if (i_pipedInputStream.available () > InputPropertiesConstantsGroup.c_lengthNotRead) {
			return i_pipedInputStream.read ();
		}
		else {
			while (i_pipedInputStream.available () <= InputPropertiesConstantsGroup.c_lengthNotRead) {
				int l_character = i_reader.read ();
				if (l_character == InputPropertiesConstantsGroup.c_noMoreData) {
					return InputPropertiesConstantsGroup.c_noMoreData;
				}
				i_pipedOutputStreamWriter.write (l_character);
				i_pipedOutputStreamWriter.flush ();
				i_pipedOutputStream.flush ();
			}
			return i_pipedInputStream.read ();
		}
	}
	
	@Override
	public int read (byte [] a_bytesArray) throws IOException {
		return read (a_bytesArray, GeneralConstantsConstantsGroup.c_iterationStartNumber, a_bytesArray.length);
	}
	
	@Override
	public int read (byte [] a_bytesArray, int a_offset, int a_length) throws IOException {
        if (a_length == InputPropertiesConstantsGroup.c_lengthNotRead) {
            return InputPropertiesConstantsGroup.c_lengthNotRead;
        }
        if (a_offset < GeneralConstantsConstantsGroup.c_iterationStartNumber || a_length < InputPropertiesConstantsGroup.c_lengthNotRead || a_offset + a_length > a_bytesArray.length) {
			throw new IndexOutOfBoundsException ();
		}
        int l_byte;
        int l_byteIndex;
        for (l_byteIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber; l_byteIndex < a_length; l_byteIndex ++) {
			if (l_byteIndex == GeneralConstantsConstantsGroup.c_iterationStartNumber || available () > InputPropertiesConstantsGroup.c_lengthNotRead) {
				l_byte = read ();
				if (l_byte == InputPropertiesConstantsGroup.c_noMoreData) {
					break;
				}
				else {
					a_bytesArray [a_offset + l_byteIndex] = (byte) l_byte;
				}
			}
			else {
				break;
			}
		}
		return l_byteIndex > InputPropertiesConstantsGroup.c_lengthNotRead ? l_byteIndex: InputPropertiesConstantsGroup.c_noMoreData;
	}
	
	@Override
	public long skip (long a_bytesNumberToBeSkipped) throws IOException {
		long l_byteIndex;
		for (l_byteIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber; l_byteIndex < a_bytesNumberToBeSkipped; l_byteIndex ++) {
			if (read () == InputPropertiesConstantsGroup.c_noMoreData) {
				break;
			}
		}
		return l_byteIndex;
	}
	
	@Override
	public void mark (int a_readLimit) {
		throw new UnsupportedOperationException ();
	}
	
	@Override
	public void reset () throws IOException {
		throw new IOException ();
	}
	
	@Override
	public boolean markSupported () {
		return false;
	}
}

