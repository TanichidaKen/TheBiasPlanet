package theBiasPlanet.coreUtilities.inputs;

import java.io.InputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import theBiasPlanet.coreUtilities.constantsGroups.DefaultValuesConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.InputPropertiesConstantsGroup;
import theBiasPlanet.coreUtilities.inputsHandling.LengthSegmentInterpreter;

public class BytesLengthSpecifiedInputStream extends InputStream {
	private InputStream i_underlyingInputStream = null;
	private LengthSegmentInterpreter i_lengthSegmentInterpreter = null;
	private int i_bytesLength = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
	private int i_readBytesLength = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
	private	ByteBuffer i_temporaryOutputBytesBuffer = ByteBuffer.wrap (new byte [DefaultValuesConstantsGroup.c_smallestBufferSize]);
	
	public BytesLengthSpecifiedInputStream (InputStream a_underlyingInputStream, LengthSegmentInterpreter a_lengthSegmentInterpreter) {
		i_underlyingInputStream = a_underlyingInputStream;
		i_lengthSegmentInterpreter = a_lengthSegmentInterpreter;
	}
	
	@Override
	public int available () throws IOException {
		return i_underlyingInputStream.available ();
	}
	
	@Override
	public void close() throws IOException {
		i_underlyingInputStream.close ();
	}
	
	@Override
	public int read () throws IOException {
		int l_readingResult = read (i_temporaryOutputBytesBuffer.array (), GeneralConstantsConstantsGroup.c_iterationStartNumber, i_temporaryOutputBytesBuffer.capacity ());
		if (l_readingResult == InputPropertiesConstantsGroup.c_noMoreData) {
			return InputPropertiesConstantsGroup.c_noMoreData;
		}
		else {
			return i_temporaryOutputBytesBuffer.get (GeneralConstantsConstantsGroup.c_iterationStartNumber);
		}
	}
	
	@Override
	public int read (byte [] a_byteArray) throws IOException {
		return read (a_byteArray, 0, a_byteArray.length);
	}
	
	@Override
	public int read (byte [] a_bytesArray, int a_offset, int a_length) throws IOException {
		if (i_bytesLength == GeneralConstantsConstantsGroup.c_unspecifiedInteger) {
			i_bytesLength = i_lengthSegmentInterpreter.interpret (i_underlyingInputStream);
			if (i_bytesLength == InputPropertiesConstantsGroup.c_noMoreData) {
				i_bytesLength = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
				return InputPropertiesConstantsGroup.c_noMoreData;
			}
			i_readBytesLength = 0;
		}
		if (i_readBytesLength < i_bytesLength) {
			int l_lengthToRead = Math.min (i_bytesLength - i_readBytesLength, a_length);
			int l_result = i_underlyingInputStream.read (a_bytesArray, a_offset, l_lengthToRead);
			if (l_result != InputPropertiesConstantsGroup.c_noMoreData) {
				i_readBytesLength += l_result;
			}
			return l_result;
		}
		else {
			return InputPropertiesConstantsGroup.c_noMoreData;
		}
	}
	
	@Override
	public long skip (long a_bytesLengthToBeSkipped) throws IOException {
		long l_byteIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
		for (; l_byteIndex < a_bytesLengthToBeSkipped; l_byteIndex ++) {
			if (read () == InputPropertiesConstantsGroup.c_noMoreData) {
				break;
			}
		}
		return l_byteIndex;
	}
	
	@Override
	public void mark (int a_readLimit) {
		throw new UnsupportedOperationException ();
	}
	
	@Override
	public void reset () throws IOException {
		throw new IOException ();
	}
	
	@Override
	public boolean markSupported () {
		return false;
	}
	
	public void prepareForNextPart () {
		i_bytesLength = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		i_readBytesLength = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
	}
	
	public int getBytesLength () {
		return i_bytesLength;
	}
}

