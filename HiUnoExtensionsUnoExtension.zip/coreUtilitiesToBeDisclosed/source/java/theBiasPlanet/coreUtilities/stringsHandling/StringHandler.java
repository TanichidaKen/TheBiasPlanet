package theBiasPlanet.coreUtilities.stringsHandling;

import java.io.Reader;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.lang.reflect.Array;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.InflaterInputStream;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.math.BigDecimal;
import theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.RegularExpressionsConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.UserInterfaceComponentCaptionsConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.WarningNamesConstantsGroup;
import theBiasPlanet.coreUtilities.inputsHandling.ReaderHandler;
import theBiasPlanet.coreUtilities.inputs.ReaderInputStream;
import theBiasPlanet.coreUtilities.messagingHandling.Publisher;
import theBiasPlanet.coreUtilities.pipes.ObjectsPipe;
import theBiasPlanet.coreUtilities.reflectionHandling.ReflectionHandler;

public class StringHandler {
	static private final int c_unicodePackMaximumChunkLength;
	static private final int c_minimumCaptionLength;
	static private final Pattern c_environmentVariableRegularExpression;
	static private final Base64.Encoder c_base64Encoder;
	static private final Base64.Decoder c_base64Decoder;
	
	static {
		c_unicodePackMaximumChunkLength = 8192;
		c_minimumCaptionLength = 4;
		c_environmentVariableRegularExpression = Pattern.compile ("\\$\\{(.*?)\\}");
		c_base64Encoder = Base64.getEncoder ();
		c_base64Decoder = Base64.getDecoder ();
	}
	
	static public StringBuilder append (StringBuilder a_target, List <String> a_stringsListToAppend, String a_delimiter) {
		boolean [] l_isFirstIteration = {true};
		a_stringsListToAppend.stream ().forEach (a_string -> {
			if (l_isFirstIteration [GeneralConstantsConstantsGroup.c_iterationStartNumber]) {
				l_isFirstIteration [GeneralConstantsConstantsGroup.c_iterationStartNumber] = false;
			}
			else {
				a_target.append (a_delimiter);
			}
			a_target.append (a_string);
		});
		return a_target;
	}
	
	static public StringBuilder append (StringBuilder a_target, List <String> a_stringsListToAppend, String a_delimiter, String a_replacement) {
		boolean [] l_isFirstIteration = {true};
		a_stringsListToAppend.stream ().forEach (a_string -> {
			if (l_isFirstIteration [GeneralConstantsConstantsGroup.c_iterationStartNumber]) {
				l_isFirstIteration [GeneralConstantsConstantsGroup.c_iterationStartNumber] = false;
			}
			else {
				a_target.append (a_delimiter);
			}
			a_target.append (a_replacement);
		});
		return a_target;
	}
	
	static public void extractMainBodyAndParameters (Reader a_expressionReader, char a_parameterStartSymbol, char a_parameterEndSymbol, ObjectsPipe  <String> a_mainBodyAndParametersPipe) {
		Thread l_subThread = new Thread (() -> {
			try {
				int l_readResult;
				char l_character;
				int l_isInParameterDepth = GeneralConstantsConstantsGroup.c_iterationStartNumber;
				boolean l_isInEscape = false;
				char l_escapeCharacter = '\\';
				boolean l_isInMainBody = true;
				StringBuilder l_mainBodyOrParameterStringBuilder = new StringBuilder ();
				
				while (true) {
					l_readResult = a_expressionReader.read ();
					if (l_readResult == -1) {
						break;
					}
					l_character = (char) l_readResult;
					if (l_isInParameterDepth == GeneralConstantsConstantsGroup.c_iterationStartNumber) {
						if (l_character == a_parameterStartSymbol) {
							if (l_isInMainBody) {
								a_mainBodyAndParametersPipe.write (l_mainBodyOrParameterStringBuilder.toString ());
								l_mainBodyOrParameterStringBuilder.delete (0, l_mainBodyOrParameterStringBuilder.length ());
								l_isInMainBody = false;
							}
							l_isInParameterDepth ++;
						}
						else {
							if (l_isInMainBody) {
								l_mainBodyOrParameterStringBuilder.append (l_character);
							}
						}
					}
					else {
						if (!l_isInEscape) {
							if (l_character == a_parameterStartSymbol) {
								l_isInParameterDepth ++;
								l_mainBodyOrParameterStringBuilder.append (l_character);
							}
							else {
								if (l_character == a_parameterEndSymbol) {
									l_isInParameterDepth --;
									if (l_isInParameterDepth == GeneralConstantsConstantsGroup.c_iterationStartNumber) {
										a_mainBodyAndParametersPipe.write (l_mainBodyOrParameterStringBuilder.toString ());
										l_mainBodyOrParameterStringBuilder.delete (GeneralConstantsConstantsGroup.c_iterationStartNumber, l_mainBodyOrParameterStringBuilder.length ());
									}
									else {
										l_mainBodyOrParameterStringBuilder.append (l_character);
									}
								}
								else {
									if (l_character == l_escapeCharacter) {
										l_isInEscape = true;
										if (l_isInParameterDepth > 1) {
											l_mainBodyOrParameterStringBuilder.append (l_character);
										}
									}
									else {
										l_mainBodyOrParameterStringBuilder.append (l_character);
									}
								}
							}
						}
						else {
							l_mainBodyOrParameterStringBuilder.append (l_character);
							l_isInEscape = false;
						}
					}
				}
				a_mainBodyAndParametersPipe.finishWriting ();
			}
			catch (Exception l_exception) {
				Publisher.logErrorInformation (l_exception.toString ());
				throw new RuntimeException (l_exception);
			}
		});
		l_subThread.start ();
	}
	
	@SuppressWarnings (WarningNamesConstantsGroup.c_notChecked)
	static public <T> void extractDelimitedObjects (Reader a_expressionReader, char a_delimiter, ObjectsPipe  <T> a_objectsPipe, Class a_objectsClass) {
		Thread l_subThread = new Thread (() -> {
			try {
				int l_readResult;
				char l_character;
				boolean l_isInDelimitedObject = true;
				boolean l_isInEscape = false;
				char l_escapeCharacter = '\\';
				StringBuilder l_delimitedObjectStringBuilder = new StringBuilder ();
				while (true) {
					l_readResult = a_expressionReader.read ();
					if (l_readResult == -1) {
						break;
					}
					l_character = (char) l_readResult;
					if (l_isInDelimitedObject) {
						if (l_isInEscape) {
							l_delimitedObjectStringBuilder.append (l_character);
						}
						else {
							if (l_character == a_delimiter) {
								if (l_delimitedObjectStringBuilder.length () > 0) {
									a_objectsPipe.write ( (T) getObject (l_delimitedObjectStringBuilder.toString (), a_objectsClass));
								}
								else {
									a_objectsPipe.write (null);
								}
								l_delimitedObjectStringBuilder.delete (GeneralConstantsConstantsGroup.c_iterationStartNumber, l_delimitedObjectStringBuilder.length ());
								l_isInDelimitedObject = false;
							}
							else if (l_character == l_escapeCharacter) {
								l_isInEscape = true;
							}
							else {
								l_delimitedObjectStringBuilder.append (l_character);
							}
						}
					}
					else {
						l_isInDelimitedObject = true;
					}
				}
				if (l_delimitedObjectStringBuilder.length () > 0) {
					a_objectsPipe.write ( (T) getObject (l_delimitedObjectStringBuilder.toString (), a_objectsClass));
				}
				else {
					a_objectsPipe.write (null);
				}
				l_delimitedObjectStringBuilder.delete (GeneralConstantsConstantsGroup.c_iterationStartNumber, l_delimitedObjectStringBuilder.length ());
				a_objectsPipe.finishWriting ();
			}
			catch (Exception l_exception) {
				Publisher.logErrorInformation (l_exception.toString ());
				throw new RuntimeException (l_exception);
			}
		});
		l_subThread.start ();
	}
	
	static public void extractStepStrings (Reader a_expressionReader, char a_stepStartSymbol, char a_parameterStartSymbol, char a_parameterEndSymbol, ObjectsPipe  <String> a_stringsPipe) {
		Thread l_subThread = new Thread (() -> {
			try {
				int l_readResult;
				char l_character;
				int l_isInParameterDepth = GeneralConstantsConstantsGroup.c_iterationStartNumber;
				boolean l_isInEscape = false;
				char l_escapeCharacter = '\\';
				boolean l_isInStartSymbolSequence = false;
				StringBuilder l_stepStringBuilder = new StringBuilder ();
				
				while (true) {
					l_readResult = a_expressionReader.read ();
					if (l_readResult == -1) {
						break;
					}
					l_character = (char) l_readResult;
					if (l_isInParameterDepth == GeneralConstantsConstantsGroup.c_iterationStartNumber) {
						if (l_character == a_stepStartSymbol) {
							if (!l_isInStartSymbolSequence) {
								if (l_stepStringBuilder.length () > 0) {
									a_stringsPipe.write (l_stepStringBuilder.toString ());
									l_stepStringBuilder.delete (GeneralConstantsConstantsGroup.c_iterationStartNumber, l_stepStringBuilder.length ());
								}
								l_isInStartSymbolSequence = true;
							}
						}
						else {
							l_isInStartSymbolSequence = false;
						}
						if (l_character == a_parameterStartSymbol) {
							l_isInParameterDepth ++;
						}
					}
					else {
						if (!l_isInEscape) {
							if (l_character == a_parameterStartSymbol) {
								l_isInParameterDepth ++;
							}
							if (l_character == a_parameterEndSymbol) {
								l_isInParameterDepth --;
							}
							if (l_character == l_escapeCharacter) {
								l_isInEscape = true;
							}
						}
						else {
							l_isInEscape = false;
						}
					}
					l_stepStringBuilder.append (l_character);
				}
				if (l_stepStringBuilder.length () > 0) {
					a_stringsPipe.write (l_stepStringBuilder.toString ());
					l_stepStringBuilder.delete (GeneralConstantsConstantsGroup.c_iterationStartNumber, l_stepStringBuilder.length ());
				}
				a_stringsPipe.finishWriting ();
			}
			catch (Exception l_exception) {
				Publisher.logErrorInformation (l_exception.toString ());
				throw new RuntimeException (l_exception);
			}
		});
		l_subThread.start ();
	}
	
	public static Object getObject (String a_string, Class a_objectClass) /*throws UnsupportedOperationException*/ {
		try {
			if (a_objectClass == LocalDate.class) {
				LocalDate l_date = LocalDate.parse (a_string, DateTimeFormatter.ISO_LOCAL_DATE);
				return l_date;
			}
			else if (a_objectClass == LocalTime.class) {
				LocalTime l_time = LocalTime.parse (a_string, DateTimeFormatter.ISO_LOCAL_TIME);
				return l_time;
			}
			else if (a_objectClass == LocalDateTime.class) {
				LocalDateTime l_dateAndTime = LocalDateTime.parse (a_string, DateTimeFormatter.ISO_LOCAL_DATE_TIME);
				return l_dateAndTime;
			}
			else if (a_objectClass == Boolean.class) {
				Boolean l_boolean = Boolean.valueOf (a_string);
				return l_boolean;
			}
			else if (a_objectClass == Integer.class) {
				return Integer.valueOf (a_string);
			}
			else if (a_objectClass == BigDecimal.class) {
				return new BigDecimal (a_string);
			}
			else if (a_objectClass == Double.class) {
				return Double.valueOf (a_string);
			}
			else if (a_objectClass == String.class) {
				return a_string;
			}
			else {
				return a_string;
			}
		}
		catch (Exception l_exception) {
			return a_string;
		}
		//throw new UnsupportedOperationException ();
	}
	
	public static String getString (Object a_object) {
		if (a_object == null) {
			return "null";
		}
		else {
			Class l_class = a_object.getClass ();
			StringBuilder l_stringBuilder = new StringBuilder ();
			l_stringBuilder.append (l_class.toString ());
			l_stringBuilder.append (": ");
			if (l_class.isArray ()) {
				int l_numberOfElements = Array.getLength (a_object);
				for (int l_elementIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber; l_elementIndex < l_numberOfElements; l_elementIndex ++) {
					if (l_elementIndex != GeneralConstantsConstantsGroup.c_iterationStartNumber) {
						l_stringBuilder.append (", ");
					}
					l_stringBuilder.append (String.format ("%d-", l_elementIndex));
					l_stringBuilder.append (getString (Array.get (a_object, l_elementIndex)));
				}
			}
			else if (a_object instanceof Map) {
				int l_elementIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
				for (Map.Entry <?, ?> l_mapEntry: ((Map <?, ?>) a_object).entrySet ()) {
					if (l_elementIndex != GeneralConstantsConstantsGroup.c_iterationStartNumber) {
						l_stringBuilder.append (", ");
					}
					l_stringBuilder.append (getString (l_mapEntry.getKey ()));
					l_stringBuilder.append ("-> ");
					l_stringBuilder.append (getString (l_mapEntry.getValue ()));
					l_elementIndex ++;
				}
			}
			else if (a_object instanceof List) {
				int l_elementIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
				for (Object l_element: (List <?>) a_object) {
					
					if (l_elementIndex != GeneralConstantsConstantsGroup.c_iterationStartNumber) {
						l_stringBuilder.append (", ");
					}
					l_stringBuilder.append (getString (l_element));
					l_elementIndex ++;
				}
			}
			else {
				if (a_object instanceof String) {
					l_stringBuilder.append ((String) a_object);
				}
				else if (a_object instanceof Integer) {
					l_stringBuilder.append (String.format (GeneralConstantsConstantsGroup.c_integerDefaultFormat, a_object));
				}
				else if (a_object instanceof Short) {
					l_stringBuilder.append (String.format (GeneralConstantsConstantsGroup.c_integerDefaultFormat, a_object));
				}
				else if (a_object instanceof BigDecimal) {
					l_stringBuilder.append (((BigDecimal) a_object).toPlainString ());
				}
				else if (a_object instanceof Double) {
					l_stringBuilder.append (String.format (GeneralConstantsConstantsGroup.c_doubleDefaultFormat, a_object));
				}
				else if (a_object instanceof Float) {
					l_stringBuilder.append (String.format (GeneralConstantsConstantsGroup.c_doubleDefaultFormat, a_object));
				}
				else if (a_object instanceof Boolean) {
					l_stringBuilder.append (String.format (GeneralConstantsConstantsGroup.c_booleanDefaultFormat, a_object));
				}
				else if (a_object instanceof LocalDate) {
					LocalDate l_date = (LocalDate) a_object;
					l_stringBuilder.append (l_date.format (DateTimeFormatter.ISO_LOCAL_DATE));
				}
				else if (a_object instanceof LocalTime) {
					LocalTime l_time = (LocalTime) a_object;
					l_stringBuilder.append (l_time.format (DateTimeFormatter.ISO_LOCAL_TIME));
				}
				else if (a_object instanceof LocalDateTime) {
					LocalDateTime l_dateAndTime = (LocalDateTime) a_object;
					l_stringBuilder.append (l_dateAndTime.format (DateTimeFormatter.ISO_LOCAL_DATE_TIME));
				}
				else if (a_object instanceof Byte) {
					// showing the unsigned value
					int l_byteValue = ((Byte) a_object).byteValue ();
					l_stringBuilder.append (String.format ("%02X", (l_byteValue >= 0) ? l_byteValue: l_byteValue + 256));
				}
				else if (a_object instanceof Class) {
					l_stringBuilder.append (a_object.toString ());
				}
				else if (l_class.toString ().startsWith ("class java") || l_class.toString ().startsWith ("class com.sun.star.lib") || l_class.toString ().startsWith ("class com.sun.star.comp")) {
					l_stringBuilder.append (a_object.toString ());
				}
				else {
					LinkedHashMap <String, Object> l_fieldNamesAndValuesMap = null;
					try {
						l_fieldNamesAndValuesMap = ReflectionHandler.getFieldNameToValueMap (l_class, a_object, false, true, null, null, true);
					}
					catch (Exception l_exception) {
					}
					if (l_fieldNamesAndValuesMap != null) {
						int l_elementIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
						for (Map.Entry <String, Object> l_fieldNamesAndValuesMapEntry : l_fieldNamesAndValuesMap.entrySet ()) {
							if (l_elementIndex != GeneralConstantsConstantsGroup.c_iterationStartNumber) {
								l_stringBuilder.append (", ");
							}
							l_stringBuilder.append (String.format ("%s-> %s", l_fieldNamesAndValuesMapEntry.getKey (), StringHandler.getString (l_fieldNamesAndValuesMapEntry.getValue ())));
							l_elementIndex ++;
						}
					}
					else {
						l_stringBuilder.append (a_object.toString ());
					}
				}
			}
		 	return l_stringBuilder.toString ();
		}
	}
	
	public static String getBase64String (byte [] a_bytesArray) {
		return c_base64Encoder.encodeToString (a_bytesArray);
	}
	
	public static byte [] decodeBase64String (String a_base64String) {
		return c_base64Decoder.decode (a_base64String);
	}
	
	//// a_toMakeItLowerCase: 0 -> no, 1 -> yes for the start, 2 -> yes for all
	public static String getIdentificationString (String a_originalString, boolean a_isLowerCaseStart, boolean a_isAllLowerCase) {
		StringTokenizer l_stringTokenizer = new StringTokenizer (a_originalString, " ");
		String l_token;
		int l_tokenIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
		StringBuilder l_targetStringBuilder = new StringBuilder ();
		boolean l_passTheseTokens = false;
		int l_tagSearchMode = 0; // 0: search '<', 1: search '>'
		Pattern l_tagStartOrEndRegularExpression = Pattern.compile("(<|>)");
		StringBuilder l_preservedChunk = new StringBuilder ();
		StringBuilder l_disposedChunk = new StringBuilder ();
		while (l_stringTokenizer.hasMoreTokens ()) {
			l_token = l_stringTokenizer.nextToken ();
			l_token = l_token.replaceAll (",|'|\"|“|”|\\?|\\.|:|;|/|-|~|_|!|\\^", "");
			if (l_token.startsWith ("+")) {
				l_token = String.format ("Plus%s", l_token.substring (1));
			}
			l_token = l_token.replaceAll ("\\+", "plus");
			l_token = l_token.replaceAll ("\\#", "sharp");
			if (l_token.startsWith ("(")) {
				l_passTheseTokens = true;
			}
			if (!l_passTheseTokens) {
				Matcher l_tagStartOrEndMatcher = l_tagStartOrEndRegularExpression.matcher (l_token);
				l_tagSearchMode = 0;
				while (l_tagStartOrEndMatcher.find ()) {
					if (l_tagSearchMode == 0) {
						l_tagStartOrEndMatcher.appendReplacement (l_preservedChunk, "");
						if (l_tagStartOrEndMatcher.group (GeneralConstantsConstantsGroup.c_iterationStartNumber).equals ("<")) {
							l_tagSearchMode = 1;
						}
						else {
							// an unpaired '>'
						}
					}
					else if (l_tagSearchMode == 1) {
						if (l_tagStartOrEndMatcher.group (GeneralConstantsConstantsGroup.c_iterationStartNumber).equals (">")) {
							l_tagStartOrEndMatcher.appendReplacement (l_disposedChunk, "");
							l_disposedChunk.delete (GeneralConstantsConstantsGroup.c_iterationStartNumber, l_disposedChunk.length ());
							l_tagSearchMode = 0;
						}
						else {
							// an unpaired '<'
							l_tagStartOrEndMatcher.appendReplacement (l_preservedChunk, "");
						}
					}
				}
				//if (l_tagSearchMode == 0) {
				l_tagStartOrEndMatcher.appendTail (l_preservedChunk);
				//}
				/*
				if ((a_toMakeItLowerCase == 1 && l_tokenIndex == GeneralConstantsConstantsGroup.c_iterationStartNumber) || a_toMakeItLowerCase == 2) {
					if (a_toMakeItLowerCase == 1) {
						l_targetStringBuilder.append (l_preservedChunk.substring (GeneralConstantsConstantsGroup.c_iterationStartNumber, 1).toLowerCase ());
						l_targetStringBuilder.append (l_preservedChunk.substring (1));
					}
					else {
						l_targetStringBuilder.append (l_preservedChunk.toString ().toLowerCase ());
					}
				}
				else {
					l_targetStringBuilder.append (l_preservedChunk);
				}
				*/
				if (l_tokenIndex == GeneralConstantsConstantsGroup.c_iterationStartNumber && a_isLowerCaseStart) {
					l_targetStringBuilder.append (l_preservedChunk.toString ().toLowerCase ());
				}
				else {
					if (l_preservedChunk.length () > 0) {
						if (!a_isAllLowerCase) {
							l_targetStringBuilder.append (l_preservedChunk.substring (GeneralConstantsConstantsGroup.c_iterationStartNumber, 1).toUpperCase ());
						}
						else {
							l_targetStringBuilder.append (l_preservedChunk.substring (GeneralConstantsConstantsGroup.c_iterationStartNumber, 1).toLowerCase ());
						}
						l_targetStringBuilder.append (l_preservedChunk.substring (1).toLowerCase ());
					}
				}
				l_preservedChunk.delete (GeneralConstantsConstantsGroup.c_iterationStartNumber, l_preservedChunk.length ());
				l_tokenIndex ++;
			}
			if (l_token.endsWith (")")) {
				l_passTheseTokens = false;
			}
		}
		return l_targetStringBuilder.toString ();
	}
	
	public static String getUpperCaseBeginnigString (String a_originalString) {
		if (a_originalString != null) {
			return String.format ("%s%s", a_originalString.substring (GeneralConstantsConstantsGroup.c_iterationStartNumber, 1).toUpperCase (), a_originalString.substring (1));
		}
		else {
			return null;
		}
	}
	
	// a_captionLength has to be larger than or equal to c_minimumCaptionLength
	public static String getCaptionString (String a_sourceString, int a_captionLength) {
		if (a_sourceString == null) {
			return null;
		}
		else {
			if (a_captionLength < c_minimumCaptionLength) {
				a_captionLength = c_minimumCaptionLength;
			}
			int l_lackingLength = a_captionLength - a_sourceString.length ();
			if (l_lackingLength == 0) {
				return a_sourceString;
			}
			else if (l_lackingLength > 0) {
				return String.format (String.format (UserInterfaceComponentCaptionsConstantsGroup.c_generalFullFormat, l_lackingLength), a_sourceString, " ");
			}
			else {
				return String.format (UserInterfaceComponentCaptionsConstantsGroup.c_generalAbrreviatedFormat, a_sourceString.substring (GeneralConstantsConstantsGroup.c_iterationStartNumber, a_captionLength - c_minimumCaptionLength + 1));
			}
		}
	}
	
	public static String getClassOrInterfaceRelativeName (String a_classOrInterfaceName) {
		int l_lastIndexOfJavaPackageDelimiter = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		if (a_classOrInterfaceName != null) {
			l_lastIndexOfJavaPackageDelimiter = a_classOrInterfaceName.lastIndexOf (GeneralConstantsConstantsGroup.c_javaPackagesDelimiter);
			if (l_lastIndexOfJavaPackageDelimiter != GeneralConstantsConstantsGroup.c_unspecifiedInteger) {
				if (l_lastIndexOfJavaPackageDelimiter + 1 < a_classOrInterfaceName.length ()) {
					return a_classOrInterfaceName.substring (l_lastIndexOfJavaPackageDelimiter + 1);
				}
				else {
					return null;
				}
			}
		}
		else {
			return null;
		}
		return null;
	}
	
	public static String getElementsReplacedString (String a_originalString, String a_elementDelimiter, String a_elementFormat) {
		StringBuilder l_targetStringBuilder = new StringBuilder ();
		StringTokenizer l_originalStringTokenizer = new StringTokenizer (a_originalString, a_elementDelimiter);
		while (l_originalStringTokenizer.hasMoreTokens ()) {
			l_targetStringBuilder.append (String.format (a_elementFormat,l_originalStringTokenizer.nextToken ()));
		}
		return l_targetStringBuilder.toString ();
	}
	
	public static ArrayList <String> getAddedTerms (String a_string) {
		Matcher l_matcher = RegularExpressionsConstantsGroup.c_termRegularExpression.matcher (a_string);
		ArrayList <String> l_terms = new ArrayList <String> ();
		while (l_matcher.find ()) {
			String l_termCandidate = l_matcher.group (1);
			if (!l_termCandidate.equals (String.valueOf (GeneralConstantsConstantsGroup.c_plusCharacter))) {
				l_terms.add (l_termCandidate);
			}
		}
		return l_terms;
	}
	
	public static InputStream compressInZip (Reader a_originalStringReader, int a_bufferSize) throws IOException {
		PipedOutputStream l_pipedOutputStream = new PipedOutputStream ();
		PipedInputStream l_pipedInputStream = new PipedInputStream (l_pipedOutputStream, a_bufferSize);
		OutputStream l_deflaterOutputStream = new DeflaterOutputStream (l_pipedOutputStream);
		Thread l_subThread = new Thread (() -> {
			try {
				ReaderHandler.writeWholeStringToOutputStream (a_originalStringReader, "UTF-8", l_deflaterOutputStream);
				l_deflaterOutputStream.close ();
			}
			catch (Exception l_exception) {
				l_exception.printStackTrace ();
			}
		});
		l_subThread.start ();
		return l_pipedInputStream;
	}
	
	public static Reader expandFromZip (InputStream a_compressedInputStream) throws IOException {
		InputStream l_inflaterInputStream = new InflaterInputStream (a_compressedInputStream);
		return new InputStreamReader (l_inflaterInputStream, "UTF-8");
	}
	
	public static Reader packToUnicode (InputStream a_originalDatainputStream, int a_bufferSize) throws IOException {
		PipedOutputStream l_pipedOutputStream = new PipedOutputStream ();
		PipedInputStream l_pipedInputStream = new PipedInputStream (l_pipedOutputStream, a_bufferSize);
		Thread l_subThread = new Thread (() -> {
			try {
				byte [] l_bytesArray = new byte [a_bufferSize];
				int l_returnOfRead = 0;
				int l_offset = 1;
				byte l_baseByte = 0b01111111;
				byte l_targetByte = 0;
				while (l_returnOfRead >= 0) {
					l_returnOfRead = a_originalDatainputStream.read (l_bytesArray, GeneralConstantsConstantsGroup.c_iterationStartNumber, a_bufferSize);
					for (int l_byteIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber; l_byteIndex < l_returnOfRead; l_byteIndex ++) {
						//System.out.println (String.format ("original:_%8s", Integer.toBinaryString (l_bytesArray [l_byteIndex] & 0xFF)).replace(' ', '0'));
						l_targetByte = (byte) (l_targetByte + ((l_bytesArray [l_byteIndex] & 0xFF) >>> l_offset));
						//System.out.println (String.format ("packed  :_%8s", Integer.toBinaryString (l_targetByte & 0xFF)).replace(' ', '0'));
						l_pipedOutputStream.write (l_targetByte);
						l_targetByte = (byte) (l_baseByte & ((l_bytesArray [l_byteIndex] & 0xFF) << (8 - l_offset - 1)));
						//System.out.println (String.format ("SHIFTED :_%8s", Integer.toBinaryString (l_targetByte & 0xFF)).replace(' ', '0'));
						l_offset ++;
						if (l_offset == 8) {
							
							//System.out.println (String.format ("packed  :_%8s", Integer.toBinaryString (l_targetByte & 0xFF)).replace(' ', '0'));
							l_pipedOutputStream.write (l_targetByte);
							l_targetByte = 0;
							l_offset = 1;
						}
					}
				}
				if (l_offset > 1) {
					//System.out.println (String.format ("packed  :_%8s", Integer.toBinaryString (l_targetByte & 0xFF)).replace(' ', '0'));
					l_pipedOutputStream.write (l_targetByte);
				}
				
				l_pipedOutputStream.close ();
			}
			catch (Exception l_exception) {
				l_exception.printStackTrace ();
			}
		});
		l_subThread.start ();
		return new InputStreamReader (l_pipedInputStream, "UTF-8");
	}
	
	public static Reader packToUnicode2 (InputStream a_originalDatainputStream, int a_bufferSize) throws IOException {
		PipedOutputStream l_pipedOutputStream = new PipedOutputStream ();
		PipedInputStream l_pipedInputStream = new PipedInputStream (l_pipedOutputStream, a_bufferSize);
		Thread l_subThread = new Thread (() -> {
			try {
				byte [] l_bytesArray = new byte [a_bufferSize];
				int l_returnOfRead = 0;
				int l_offset = 2;
				byte l_baseByte = 0b00111111;
				byte l_targetByte = 0b01000000;
				int l_chunkLength = 0;
				while (l_returnOfRead >= 0) {
					l_returnOfRead = a_originalDatainputStream.read (l_bytesArray, GeneralConstantsConstantsGroup.c_iterationStartNumber, a_bufferSize);
					for (int l_byteIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber; l_byteIndex < l_returnOfRead; l_byteIndex ++) {
						//System.out.println (String.format ("original:_%8s", Integer.toBinaryString (l_bytesArray [l_byteIndex] & 0xFF)).replace(' ', '0'));
						l_targetByte = (byte) (l_targetByte + ((l_bytesArray [l_byteIndex] & 0xFF) >>> l_offset));
						//System.out.println (String.format ("packed 1:_%8s", Integer.toBinaryString (l_targetByte & 0xFF)).replace(' ', '0'));
						if (l_chunkLength == c_unicodePackMaximumChunkLength) {
							l_pipedOutputStream.write ( (byte) 0x0A);
							l_chunkLength = 0;
						}
						l_pipedOutputStream.write (l_targetByte);
						l_chunkLength ++;
						l_targetByte = (byte) (0b01000000 + (l_baseByte & ((l_bytesArray [l_byteIndex] & 0xFF) << (8 - l_offset - 2))));
						//System.out.println (String.format ("SHIFTED :_%8s", Integer.toBinaryString (l_targetByte & 0xFF)).replace(' ', '0'));
						l_offset += 2;
						if (l_offset == 8) {
							//System.out.println (String.format ("packed 2:_%8s", Integer.toBinaryString (l_targetByte & 0xFF)).replace(' ', '0'));
							if (l_chunkLength == c_unicodePackMaximumChunkLength) {
								l_pipedOutputStream.write ( (byte) 0x0A);
								l_chunkLength = 0;
							}
							l_pipedOutputStream.write (l_targetByte);
							l_chunkLength ++;
							l_targetByte = 0b01000000;
							l_offset = 2;
						}
					}
				}
				if (l_offset > 2) {
					//System.out.println (String.format ("packed 3:_%8s", Integer.toBinaryString (l_targetByte & 0xFF)).replace(' ', '0'));
					if (l_chunkLength == c_unicodePackMaximumChunkLength) {
						l_pipedOutputStream.write ( (byte) 0x0A);
						l_chunkLength = 0;
					}
					l_pipedOutputStream.write (l_targetByte);
					l_chunkLength ++;
				}
				l_pipedOutputStream.close ();
			}
			catch (Exception l_exception) {
				l_exception.printStackTrace ();
				Publisher.show (l_exception.toString ());
			}
		});
		l_subThread.start ();
		return new InputStreamReader (l_pipedInputStream, "UTF-8");
	}
	
	public static InputStream unpackFromUnicode (Reader a_packedStringReader, int a_bufferSize) throws IOException {
		PipedOutputStream l_pipedOutputStream = new PipedOutputStream ();
		PipedInputStream l_pipedInputStream = new PipedInputStream (l_pipedOutputStream, a_bufferSize);
		Thread l_subThread = new Thread (() -> {
			try {
				ReaderInputStream l_packedStringInputStream = new ReaderInputStream (a_packedStringReader, "UTF-8");
				byte [] l_bytesArray = new byte [a_bufferSize];
				int l_returnOfRead = 0;
				int l_offset = 1;
				byte l_targetByte = 0;
				boolean l_firstByte = true;
				while (l_returnOfRead >= 0) {
					l_returnOfRead = l_packedStringInputStream.read (l_bytesArray, GeneralConstantsConstantsGroup.c_iterationStartNumber, a_bufferSize);
					for (int l_byteIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber; l_byteIndex < l_returnOfRead; l_byteIndex ++) {
						if (!l_firstByte) {
							l_targetByte = (byte) (l_targetByte +  ((l_bytesArray [l_byteIndex] & 0xFF) >>> (8 - (l_offset))));
							//System.out.println (String.format ("unpacked:_%8s", Integer.toBinaryString (l_targetByte & 0xFF)).replace(' ', '0'));
							l_pipedOutputStream.write (l_targetByte);
						}
						else {
							l_firstByte = false;
						}
						if (l_offset == 8) {
							l_firstByte = true;
							l_targetByte = 0;
							l_offset = 1;
						}
						else {
							l_targetByte = (byte) ((l_bytesArray [l_byteIndex] & 0xFF) << l_offset);
							l_offset ++;
						}
					}
				}
				l_pipedOutputStream.close ();
			}
			catch (Exception l_exception) {
				l_exception.printStackTrace ();
			}
		});
		l_subThread.start ();
		return l_pipedInputStream;
	}
	
	public static InputStream unpackFromUnicode2 (Reader a_packedStringReader, int a_bufferSize) throws IOException {
		PipedOutputStream l_pipedOutputStream = new PipedOutputStream ();
		PipedInputStream l_pipedInputStream = new PipedInputStream (l_pipedOutputStream, a_bufferSize);
		Thread l_subThread = new Thread (() -> {
			try {
				ReaderInputStream l_packedStringInputStream = new ReaderInputStream (a_packedStringReader, "UTF-8");
				byte [] l_bytesArray = new byte [a_bufferSize];
				int l_returnOfRead = 0;
				int l_offset = 2;
				byte l_targetByte = 0;
				boolean l_firstByte = true;
				int l_chunkLength = 0;
				while (l_returnOfRead >= 0) {
					l_returnOfRead = l_packedStringInputStream.read (l_bytesArray, GeneralConstantsConstantsGroup.c_iterationStartNumber, a_bufferSize);
					for (int l_byteIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber; l_byteIndex < l_returnOfRead; l_byteIndex ++) {
						if (l_chunkLength == c_unicodePackMaximumChunkLength) {
							l_chunkLength = 0;
							continue;
						}
						l_chunkLength ++;
						if (!l_firstByte) {
							l_targetByte = (byte) (l_targetByte +  ((l_bytesArray [l_byteIndex] & 0x3F) >>> (8 - (l_offset))));
							//System.out.println (String.format ("unpacked:_%8s", Integer.toBinaryString (l_targetByte & 0xFF)).replace(' ', '0'));
							l_pipedOutputStream.write (l_targetByte);
						}
						else {
							l_firstByte = false;
						}
						if (l_offset == 8) {
							l_firstByte = true;
							l_targetByte = 0;
							l_offset = 2;
						}
						else {
							l_targetByte = (byte) ((l_bytesArray [l_byteIndex] & 0x3F) << l_offset);
							l_offset += 2;
						}
					}
				}
				l_pipedOutputStream.close ();
			}
			catch (Exception l_exception) {
				l_exception.printStackTrace ();
			}
		});
		l_subThread.start ();
		return l_pipedInputStream;
	}
	
	public static ArrayList <String> splitArgumentsString (String a_argumentsString) throws Exception {
		if (a_argumentsString != null) {
			ArrayList <String> l_arguments = new ArrayList <String> ();
			int l_argumentsStringCharactersLength = a_argumentsString.length ();
			StringBuilder l_argumentBuffer = new StringBuilder ();
			char l_character = GeneralConstantsConstantsGroup.c_unspecifiedCharacter;
			boolean l_isInBlock = false;
			boolean l_isEscaped = false;
			boolean l_isAtArgumentStart = true;
			char l_blockingCharacter = GeneralConstantsConstantsGroup.c_unspecifiedCharacter;
			int l_characterIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
			for (; l_characterIndex < l_argumentsStringCharactersLength; l_characterIndex ++) {
				l_character = a_argumentsString.charAt (l_characterIndex);
				// Is in a block Start
				if (l_isInBlock) {
					// Is escaped Start
					if (l_isEscaped) {
						// Is or not at an argument start Start
						if (l_isAtArgumentStart || !l_isAtArgumentStart) {
							if (l_character == GeneralConstantsConstantsGroup.c_doubleQuotationMarkCharacter || l_character == GeneralConstantsConstantsGroup.c_apostropheCharacter) {
								l_argumentBuffer.append (l_character );
								l_isEscaped = false;
								l_isAtArgumentStart = false;
							}
							else if (l_character == GeneralConstantsConstantsGroup.c_escapingCharacter) {
								l_argumentBuffer.append (l_character );
								l_isEscaped = false;
								l_isAtArgumentStart = false;
							}
							else if (l_character == GeneralConstantsConstantsGroup.c_argumentsDelimiter) {
								// error
								throw new Exception (String.format ("There is an invalid expression at %d.", l_characterIndex));
							}
							else {
								// error
								throw new Exception (String.format ("There is an invalid expression at %d.", l_characterIndex));
							}
						}
						// Is or not at an argument start End
					}
					// Is escaped End
					// Is not escaped Start
					else {
						// Is or not at an argument start Start
						if (l_isAtArgumentStart || !l_isAtArgumentStart) {
							if (l_character == l_blockingCharacter) {
								l_blockingCharacter = GeneralConstantsConstantsGroup.c_unspecifiedCharacter;
								l_isInBlock = false;
							}
							else if (l_character == GeneralConstantsConstantsGroup.c_escapingCharacter) {
								l_isEscaped = true;
							}
							else if (l_character == GeneralConstantsConstantsGroup.c_argumentsDelimiter) {
								l_argumentBuffer.append (l_character);
								l_isAtArgumentStart = false;
							}
							else {
								l_argumentBuffer.append (l_character);
								l_isAtArgumentStart = false;
							}
						}
						// Is or not at an argument start End
					}
					// Is not escaped End
				}
				// Is in a block End
				// Is not in a block Start
				else {
					// Is escaped Start
					if (l_isEscaped) {
						// Is or not at an argument start Start
						if (l_isAtArgumentStart || !l_isAtArgumentStart) {
							if (l_character == GeneralConstantsConstantsGroup.c_doubleQuotationMarkCharacter || l_character == GeneralConstantsConstantsGroup.c_apostropheCharacter) {
								l_argumentBuffer.append (l_character);
								l_isEscaped = false;
								l_isAtArgumentStart = false;
							}
							else if (l_character == GeneralConstantsConstantsGroup.c_escapingCharacter) {
								l_argumentBuffer.append (l_character);
								l_isEscaped = false;
								l_isAtArgumentStart = false;
							}
							else if (l_character == GeneralConstantsConstantsGroup.c_argumentsDelimiter) {
								// error
								throw new Exception (String.format ("There is an invalid expression at %d.", l_characterIndex));
							}
							else {
								// error
								throw new Exception (String.format ("There is an invalid expression at %d.", l_characterIndex));
							}
						}
						// Is or not at an argument start End
					}
					// Is escaped End
					// Is not escaped Start
					else {
						// Is or not at an argument start Start
						if (l_isAtArgumentStart || !l_isAtArgumentStart) {
							if (l_character == GeneralConstantsConstantsGroup.c_doubleQuotationMarkCharacter || l_character == GeneralConstantsConstantsGroup.c_apostropheCharacter) {
								l_blockingCharacter = l_character;
								l_isInBlock = true;
							}
							else if (l_character == GeneralConstantsConstantsGroup.c_escapingCharacter) {
								l_isEscaped = true;
							}
							else if (l_character == GeneralConstantsConstantsGroup.c_argumentsDelimiter) {
								if (l_isAtArgumentStart ) {
								}
								else {
									l_arguments.add (l_argumentBuffer.toString ());
									l_argumentBuffer.setLength (0);
									l_isAtArgumentStart = true;
								}
							}
							else {
								l_argumentBuffer.append (l_character);
								l_isAtArgumentStart = false;
							}
						}
						// Is or not at an argument start End
					}
					// Is not escaped End
				}
				// Is not in a block End
			}
			if (l_isInBlock) {
				// error
				throw new Exception (String.format ("There is an invalid expression at %d.", l_characterIndex));
			}
			else {
				if (l_isEscaped) {
					// error
					throw new Exception (String.format ("There is an invalid expression at %d.", l_characterIndex));
				}
				else {
					if (l_isAtArgumentStart) {
					}
					else {
						l_arguments.add (l_argumentBuffer.toString ());
						l_argumentBuffer.setLength (0);
						l_isAtArgumentStart = true;
					}
				}
			}
			return l_arguments;
		}
		else {
			return null;
		}
	}
	
	public static String getUrl (String a_filePath) {
		return (Paths.get (a_filePath)).normalize ().toUri ().toString ();
	}
	
	public static Path getFilePath (String a_url) throws URISyntaxException {
		return Paths.get (new URI (a_url));
	}
	
	public static String getFileNameExtension (String a_fileName) {
		int l_indexOfLastPeriod = a_fileName.lastIndexOf (GeneralConstantsConstantsGroup.c_fileNameElementsDelimiter);
		if (l_indexOfLastPeriod >= GeneralConstantsConstantsGroup.c_iterationStartNumber) {
			return a_fileName.substring (l_indexOfLastPeriod + 1);
		}
		else {
			return null;
		}
	}
	
	public static String getFileContentType (String a_fileName) {
		String l_fileNameExtension = StringHandler.getFileNameExtension (a_fileName);
		String l_contentType = null;
		if (l_fileNameExtension != null) {
			l_contentType = GeneralConstantsConstantsGroup.c_fileExtensionToMimeTypeMap.get (l_fileNameExtension);
			if (l_contentType == null) {
				l_contentType = "application/octet-stream";
			}
		}
		else {
			l_contentType = "application/octet-stream";
		}
		return l_contentType;
	}
	
	public static String getStackStringLastItem (String a_stackString) {
		int l_indexOfLastDelimiter = a_stackString.lastIndexOf (GeneralConstantsConstantsGroup.c_commaDelimiter);
		if (l_indexOfLastDelimiter >= GeneralConstantsConstantsGroup.c_iterationStartNumber) {
			return a_stackString.substring (l_indexOfLastDelimiter + GeneralConstantsConstantsGroup.c_commaDelimiter.length (), a_stackString.length () - 1);
		}
		else {
			return a_stackString.substring (1, a_stackString.length () - 1);
		}
	}
	
	public static String unNullify (String a_originalString) {
		if (a_originalString != null) {
			return a_originalString;
		}
		else {
			return "";
		}
	}
	
	public static String effectuateEnvironmentVariables (String a_originalString) {
		StringBuilder l_targetStringBuilder = new StringBuilder ();
		Matcher l_environmentVariableMatcher = c_environmentVariableRegularExpression.matcher (a_originalString);
		while (l_environmentVariableMatcher.find ()) {
			l_environmentVariableMatcher.appendReplacement (l_targetStringBuilder, unNullify (System.getenv (l_environmentVariableMatcher.group (GeneralConstantsConstantsGroup.c_iterationStartNumber + 1))));
		}
		l_environmentVariableMatcher.appendTail (l_targetStringBuilder);
		return l_targetStringBuilder.toString ();
	}
	
	public static boolean validateAsUrl (String a_string) {
		Matcher l_urlMatcher = RegularExpressionsConstantsGroup.c_urlRegularExpression.matcher (a_string);
		return (l_urlMatcher.find ());
	}
}

