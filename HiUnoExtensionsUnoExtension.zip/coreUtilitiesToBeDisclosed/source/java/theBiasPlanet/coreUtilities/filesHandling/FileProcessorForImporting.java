package theBiasPlanet.coreUtilities.filesHandling;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.LocalDateTime;
import java.time.ZoneId;
import theBiasPlanet.coreUtilities.collectionsHandling.ListsFactory;
import theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup;
import theBiasPlanet.coreUtilities.inputs.HaltableStandardInputReader;
import theBiasPlanet.coreUtilities.inputsHandling.NoMoreDataException;
import theBiasPlanet.coreUtilities.processesHandling.ProcessHandler;
import theBiasPlanet.coreUtilities.timersHandling.TimeOutException;

public class FileProcessorForImporting implements FileProcessor {
	private static HaltableStandardInputReader s_haltableStandardInputReader = HaltableStandardInputReader.getInstance ();
	private Path i_sourceBaseDirectoryAbsolutePath = null;
	private Path i_destinationBaseDirectoryPath = null;
	private LocalDateTime i_exportingDateAndTime = null;
	
	static {
		s_haltableStandardInputReader.startDispatchDataThread ();
	}
	
	public FileProcessorForImporting (Path a_sourceBaseDirectoryAbsolutePath, Path a_destinationBaseDirectoryPath) {
		i_sourceBaseDirectoryAbsolutePath = a_sourceBaseDirectoryAbsolutePath;
		i_destinationBaseDirectoryPath = a_destinationBaseDirectoryPath;
		try {
			i_exportingDateAndTime = FilesHandler.getFileLastModifiedDateAndTime (i_destinationBaseDirectoryPath.resolve (FilesHandler.c_exportingTokenFileName));
		}
		catch (IOException l_exception) {
		}
	}
	
	@Override
	protected void finalize () {
	}
	
	@Override
	public void process (Path a_fileAbsolutePath, BasicFileAttributes a_fileAttributes) throws IOException {
		Path l_destinationFilePath = null;
		Path l_destinationSaveFilePath = null;
		LocalDateTime l_destinationFileLastModifiedDateAndTime = null;
		boolean l_fileIsMoved = false;
		boolean l_fileIsRemoved = false;
		try {
			l_destinationFilePath = i_destinationBaseDirectoryPath.resolve (i_sourceBaseDirectoryAbsolutePath.relativize (a_fileAbsolutePath));
			l_destinationFileLastModifiedDateAndTime = FilesHandler.getFileLastModifiedDateAndTime (l_destinationFilePath);
			l_destinationSaveFilePath = Paths.get (l_destinationFilePath.toString () + ".save");
		}
		catch (IOException l_exception) {
			// as the destination file may not exist
		}
		LocalDateTime l_sourceFileLastModifiedDateAndTime = LocalDateTime.ofInstant (a_fileAttributes.lastModifiedTime ().toInstant (), ZoneId.systemDefault ());
		if (l_destinationFileLastModifiedDateAndTime != null) {
			if (l_destinationFileLastModifiedDateAndTime.isBefore (i_exportingDateAndTime)) {
				if (l_destinationFileLastModifiedDateAndTime.isBefore (l_sourceFileLastModifiedDateAndTime)) {
					l_fileIsMoved = true;
				}
			}
			if (l_destinationFileLastModifiedDateAndTime.isEqual (l_sourceFileLastModifiedDateAndTime)) {
				l_fileIsRemoved = true;
			}
		}
		else {
			l_fileIsMoved = true;
		}
		if (!l_fileIsMoved && !l_fileIsRemoved) {
			try {
				ProcessHandler.execute (null, null, ListsFactory. <String>createArrayList ("diff", l_destinationFilePath.toString (), a_fileAbsolutePath.toString ()), true);
			}
			catch (InterruptedException l_exception) {
			}
			System.out.println (String.format ("What to with the source file: %s? ([move]/remove/leave): ", a_fileAbsolutePath.toString ()));
			System.out.flush ();
			String l_threadIdentification = String.format ("%d", Thread.currentThread ().getId ());
			s_haltableStandardInputReader.addSubscriber (l_threadIdentification);
			String l_userReply = null;
			try {
				l_userReply = s_haltableStandardInputReader.readLine (l_threadIdentification, 1000);
			}
			catch (NoMoreDataException | TimeOutException l_exception) {
			}
			s_haltableStandardInputReader.removeSubscriber (l_threadIdentification);
			if (l_userReply != null) {
				if (l_userReply.equals (String.format ("%s%c", "move", GeneralConstantsConstantsGroup.c_newLineCharacter)) || l_userReply.equals (String.format ("%c", GeneralConstantsConstantsGroup.c_newLineCharacter))) {
					l_fileIsMoved = true;
					System.out.println ("It has been moved.");
				}
				else if (l_userReply.equals (String.format ("%s%c", "remove", GeneralConstantsConstantsGroup.c_newLineCharacter))) {
					l_fileIsRemoved = true;
					System.out.println ("It has been removed.");
				}
			}
		}
		if (l_fileIsMoved) {
			FilesHandler.move (l_destinationFilePath, l_destinationSaveFilePath, true);
			FilesHandler.move (a_fileAbsolutePath, l_destinationFilePath, true);
		}
		if (l_fileIsRemoved) {
			FilesHandler.delete (a_fileAbsolutePath);
		}
	}
}

