package theBiasPlanet.coreUtilities.filesHandling;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;

public class FileProcessorForExporting implements FileProcessor {
	private Path i_sourceBaseDirectoryAbsolutePath = null;
	private Path i_destinationBaseDirectoryPath = null;
	
	public FileProcessorForExporting (Path a_sourceBaseDirectoryAbsolutePath, Path a_destinationBaseDirectoryPath) {
		i_sourceBaseDirectoryAbsolutePath = a_sourceBaseDirectoryAbsolutePath;
		i_destinationBaseDirectoryPath = a_destinationBaseDirectoryPath;
	}
	
	@Override
	protected void finalize () {
	}
	
	@Override
	public void process (Path a_fileAbsolutePath, BasicFileAttributes a_fileAttributes) throws IOException {
		Path l_destinationFileAbsolutePath = null;
		l_destinationFileAbsolutePath = i_destinationBaseDirectoryPath.resolve (i_sourceBaseDirectoryAbsolutePath.relativize (a_fileAbsolutePath));
		FilesHandler.copy (a_fileAbsolutePath, l_destinationFileAbsolutePath, true);
	}
}

