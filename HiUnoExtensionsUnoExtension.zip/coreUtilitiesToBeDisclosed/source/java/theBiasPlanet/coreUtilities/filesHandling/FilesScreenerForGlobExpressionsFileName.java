package theBiasPlanet.coreUtilities.filesHandling;

import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.PathMatcher;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.List;
import theBiasPlanet.coreUtilities.constantsGroups.*;

public class FilesScreenerForGlobExpressionsFileName implements FilesScreener {
	private Path i_normalizedBaseDirectoryAbsolutePath = null;
	private ArrayList <PathMatcher> i_pathMatchers = null;
	
	public FilesScreenerForGlobExpressionsFileName (Path a_baseDirectoryAbsolutePath, List <String> a_normalizedGlobExpressions) {
		i_normalizedBaseDirectoryAbsolutePath = a_baseDirectoryAbsolutePath.normalize ();
		if (a_normalizedGlobExpressions != null) {
			i_pathMatchers = new ArrayList <PathMatcher> ();
			FileSystem l_fileSystem = FileSystems.getDefault ();
			for (String l_normalizedGlobExpression: a_normalizedGlobExpressions) {
				i_pathMatchers.add (l_fileSystem.getPathMatcher (String.format (GeneralConstantsConstantsGroup.c_globExpressionFormat, l_normalizedGlobExpression)));
			}
		}
	}
	
	@Override
	protected void finalize () {
	}
	
	@Override
	public boolean screen (Path a_fileAbsolutePath, BasicFileAttributes a_fileAttributes) {
		Path l_normalizedFileRelativePath = i_normalizedBaseDirectoryAbsolutePath.relativize (a_fileAbsolutePath).normalize ();
		if (Files.isRegularFile (a_fileAbsolutePath)) {
			for (PathMatcher l_pathMatcher: i_pathMatchers) {
				if (l_pathMatcher.matches (l_normalizedFileRelativePath)) {
					return true;
				}
			}
			return false;
		}
		else {
			return false;
		}
	}
}

