package theBiasPlanet.coreUtilities.filesHandling;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.time.LocalDateTime;
import java.time.ZoneId;
import theBiasPlanet.coreUtilities.collectionsHandling.ListsFactory;

public class FilesHandler {
	public static String c_exportingTokenFileName = "Exporting.token";
	
	public static Path getAbsolutePath (Path a_baseAbsolutePath, Path ... a_relativePaths) {
		Path l_absolutePath = a_baseAbsolutePath;
		if (l_absolutePath != null && a_relativePaths != null) {
			for (Path l_relativePath: a_relativePaths) {
				if (l_relativePath != null) {
					l_absolutePath = l_absolutePath.resolve (l_relativePath);
				}
			}
		}
		return l_absolutePath;
	}
	
	// the return: 'true' -> the file had existed, 'false' -> the had not existed.
	public static boolean touch (Path a_filePath) throws IOException {
		if (Files.exists (a_filePath)) {
			Files.setLastModifiedTime (a_filePath, FileTime.fromMillis (System.currentTimeMillis ()));
			return true;
		}
		else {
			Files.createFile (a_filePath);
			return false;
		}
	}
	
	public static void copy (Path a_sourceBaseDirectoryAbsolutePath, List <String> a_filesGlobExpressions, Path a_destinationBaseDirectoryPath) throws IOException {
		FileProcessorForExporting l_fileProcessorForExporting = new FileProcessorForExporting (a_sourceBaseDirectoryAbsolutePath, a_destinationBaseDirectoryPath);
		FilesVisitor l_filesVisitor = new FilesVisitor (ListsFactory. <FilesScreener>createArrayList (new FilesScreenerForGlobExpressionsFileName (a_sourceBaseDirectoryAbsolutePath, a_filesGlobExpressions)), ListsFactory. <FileProcessor>createArrayList (l_fileProcessorForExporting));
		Files.walkFileTree (a_sourceBaseDirectoryAbsolutePath, l_filesVisitor);
	}
	
	public static boolean copy (Path a_sourceFilePath, Path a_destinationFilePath, boolean a_overwrite) throws IOException {
		if (!Files.exists (a_sourceFilePath)) {
			return false;
		}
		if (Files.exists (a_destinationFilePath) && !a_overwrite) {
			return false;
		}
		createDirectoryIfNecessary (a_destinationFilePath);
		Files.copy (a_sourceFilePath, a_destinationFilePath, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.COPY_ATTRIBUTES);
		return true;
	}
	
	public static boolean move (Path a_sourceFilePath, Path a_destinationFilePath, boolean a_overwrite) throws IOException {
		if (!Files.exists (a_sourceFilePath)) {
			return false;
		}
		if (Files.exists (a_destinationFilePath) && !a_overwrite) {
			return false;
		}
		createDirectoryIfNecessary (a_destinationFilePath);
		Files.move (a_sourceFilePath, a_destinationFilePath, StandardCopyOption.REPLACE_EXISTING);
		return true;
	}
	
	public static boolean delete (Path a_filePath) throws IOException {
		if (!Files.exists (a_filePath)) {
			return false;
		}
		Files.delete (a_filePath);
		return true;
	}
	
	// return: true -> created, false -> not created
	public static boolean createDirectoryIfNecessary (Path a_fileOrDirectoryPath) throws IOException {
		Path l_targetDirectoryPath = null;
		if (!Files.isDirectory (a_fileOrDirectoryPath)) {
			l_targetDirectoryPath = a_fileOrDirectoryPath.getParent ();
		}
		else {
			l_targetDirectoryPath = a_fileOrDirectoryPath;
		}
		if (l_targetDirectoryPath != null && !Files.exists (l_targetDirectoryPath)) {
			Files.createDirectories (l_targetDirectoryPath);
			return true;
		}
		return false;
	}
	
	public static ArrayList <Path> getRecentFileRelativePaths (Path a_baseDirectoryAbsolutePath, LocalDateTime a_borderFileDateAndTime) throws IOException {
		FileProcessorForRememberingFilePaths l_fileProcessorForRememberingFilePaths = new FileProcessorForRememberingFilePaths (true, a_baseDirectoryAbsolutePath);
		FilesVisitor l_filesVisitor = new FilesVisitor (ListsFactory. <FilesScreener>createArrayList (new FilesScreenerForRecentModification (a_borderFileDateAndTime)), ListsFactory. <FileProcessor>createArrayList (l_fileProcessorForRememberingFilePaths));
		Files.walkFileTree (a_baseDirectoryAbsolutePath, l_filesVisitor);
		return l_fileProcessorForRememberingFilePaths.getFilePaths ();
	}
	
	public static ArrayList <Path> getGlobMatchedFileRelativePaths (Path a_baseDirectoryAbsolutePath, List <String> a_globExpressions) throws IOException {
		FileProcessorForRememberingFilePaths l_fileProcessorForRememberingFilePaths = new FileProcessorForRememberingFilePaths (true, a_baseDirectoryAbsolutePath);
		FilesVisitor l_filesVisitor = new FilesVisitor (ListsFactory. <FilesScreener> createArrayList (new FilesScreenerForGlobExpressionsFileName (a_baseDirectoryAbsolutePath, a_globExpressions)), ListsFactory. <FileProcessor> createArrayList (l_fileProcessorForRememberingFilePaths));
		Files.walkFileTree (a_baseDirectoryAbsolutePath, l_filesVisitor);
		ArrayList <Path> l_gottenFileRelativePaths = l_fileProcessorForRememberingFilePaths.getFilePaths ();
		if (l_gottenFileRelativePaths.size () != 0) {
			return l_gottenFileRelativePaths;
		}
		else {
			return null;
		}
	}
	
	public static LocalDateTime getFileLastModifiedDateAndTime (Path a_filePath) throws NoSuchFileException, IOException {
		try {
			BasicFileAttributes l_fileAttribues = Files.readAttributes (a_filePath, BasicFileAttributes.class);
			return (LocalDateTime.ofInstant (l_fileAttribues.lastModifiedTime ().toInstant (), ZoneId.systemDefault ()));
		}
		catch (UnsupportedOperationException l_exception) {
			return null;
		}
	}
	
	public static void setFileLastModifiedDateAndTime (Path a_filePath, LocalDateTime a_lastModifiedDateAndTime) throws NoSuchFileException, IOException {
		ZonedDateTime l_zonedDateAndTime = a_lastModifiedDateAndTime.atZone (ZoneId.systemDefault ());
		 long l_epockMilliseconds = l_zonedDateAndTime.toInstant ().toEpochMilli ();
		Files.setLastModifiedTime (a_filePath, FileTime.fromMillis (l_epockMilliseconds));
	}
	
	public static int shiftFileLastModifiedDateAndTimes (Path a_directoryPath, boolean a_isFromUtcToLocal) throws IOException {
		FileProcessorForShiftingLastModifiedDateAndTime l_fileProcessorForShiftingLastModifiedDateAndTime = new FileProcessorForShiftingLastModifiedDateAndTime (a_isFromUtcToLocal);
		FilesVisitor l_filesVisitor = new FilesVisitor (null, ListsFactory. <FileProcessor>createArrayList (l_fileProcessorForShiftingLastModifiedDateAndTime));
		Files.walkFileTree (a_directoryPath, l_filesVisitor);
		return l_filesVisitor.getNumberOfSuccessfullyProcessedFiles ();
	}
	
	public static LocalDateTime getFileCreatedDateAndTime (Path a_filePath) throws NoSuchFileException, IOException {
		try {
			BasicFileAttributes l_fileAttribues = Files.readAttributes (a_filePath, BasicFileAttributes.class);
			return (LocalDateTime.ofInstant (l_fileAttribues.creationTime ().toInstant (), ZoneId.systemDefault ()));
		}
		catch (UnsupportedOperationException l_exception) {
			return null;
		}
	}
	
	public static void setFileCreatedDateAndTime (Path a_filePath, LocalDateTime a_createdDateAndTime) throws NoSuchFileException, IOException {
		try {
			ZonedDateTime l_zonedDateAndTime = a_createdDateAndTime.atZone (ZoneId.systemDefault ());
			long l_epockMilliseconds = l_zonedDateAndTime.toInstant ().toEpochMilli ();
			Files.setAttribute (a_filePath, "creationTime", FileTime.fromMillis (l_epockMilliseconds));
		}
		catch (UnsupportedOperationException l_exception) {
			return;
		}
	}
	
	public static int exportDirectory (Path a_sourceBaseDirectoryAbsolutePath, Path a_desitinationBaseDirectoryPath, boolean a_exportingIsFull) throws IOException {
		FileProcessorForExporting l_fileProcessorForExporting = new FileProcessorForExporting (a_sourceBaseDirectoryAbsolutePath, a_desitinationBaseDirectoryPath);
		LocalDateTime l_borderDateAndTime = null;
		Path l_exportingTokenFileAbsolutePath = a_sourceBaseDirectoryAbsolutePath.resolve (c_exportingTokenFileName);
		if (!a_exportingIsFull) {
			try {
				l_borderDateAndTime = FilesHandler.getFileLastModifiedDateAndTime (l_exportingTokenFileAbsolutePath);
			}
			catch (NoSuchFileException l_exception) {
			}
		}
		FilesVisitor l_filesVisitor = new FilesVisitor (ListsFactory. <FilesScreener>createArrayList (new FilesScreenerForRecentModification (l_borderDateAndTime), new FilesScreenerForGlobExpressionsFileName (a_sourceBaseDirectoryAbsolutePath, ListsFactory. <String>createArrayList ("**.gradle", "**.gradleForSubProjects", "**_Template", "**.xml", "**.sh", "**.ini", "**.txt", "**.java", "**.hpp", "**.cpp", "**.tpp", "**.cs", "**.py", "**.pyi", "**.xslt", "**.MF.addition", "**.idl", "**.recipe", "**.xba", "**.xlb", "**.odt", "**.fodt", "**.ods", "**.fods", "**.jpg", "**.png", "**.html"))), ListsFactory. <FileProcessor>createArrayList (l_fileProcessorForExporting));
		Files.walkFileTree (a_sourceBaseDirectoryAbsolutePath, l_filesVisitor);
		touch (l_exportingTokenFileAbsolutePath);
		return l_filesVisitor.getNumberOfSuccessfullyProcessedFiles ();
	}
	
	public static int importDirectory (Path a_sourceBaseDirectoryAbsolutePath, Path a_desitinationBaseDirectoryPath) throws IOException {
		FileProcessorForImporting l_fileProcessorForImporting = new FileProcessorForImporting (a_sourceBaseDirectoryAbsolutePath, a_desitinationBaseDirectoryPath);
		FilesVisitor l_filesVisitor = new FilesVisitor (null, ListsFactory. <FileProcessor>createArrayList (l_fileProcessorForImporting));
		Files.walkFileTree (a_sourceBaseDirectoryAbsolutePath, l_filesVisitor);
		return l_filesVisitor.getNumberOfSuccessfullyProcessedFiles ();
	}
}

