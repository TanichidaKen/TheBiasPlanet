package theBiasPlanet.coreUtilities.filesHandling;

import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;

public interface FilesScreener {
	public boolean screen (Path a_fileAbsolutePath, BasicFileAttributes a_fileAttributes);
}

