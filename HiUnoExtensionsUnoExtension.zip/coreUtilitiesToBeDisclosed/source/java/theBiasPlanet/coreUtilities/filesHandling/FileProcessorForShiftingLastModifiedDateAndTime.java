package theBiasPlanet.coreUtilities.filesHandling;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.TimeZone;

public class FileProcessorForShiftingLastModifiedDateAndTime implements FileProcessor {
	private boolean i_isFromUtcToLocal = true;
	private int i_timeZoneOffsetMilliseconds = TimeZone.getDefault ().getRawOffset ();
	
	public FileProcessorForShiftingLastModifiedDateAndTime (boolean a_isFromUtcToLocal) {
		i_isFromUtcToLocal = a_isFromUtcToLocal;
	}
	
	@Override
	protected void finalize () {
	}
	
	@Override
	public void process (Path a_fileAbsolutePath, BasicFileAttributes a_fileAttributes) throws IOException {
		LocalDateTime l_fileLastModifiedDateAndTime = LocalDateTime.ofInstant (a_fileAttributes.lastModifiedTime ().toInstant (), ZoneId.systemDefault ());
		int l_shiftedMilliseconds = 0;
		if (i_isFromUtcToLocal) {
			l_shiftedMilliseconds = i_timeZoneOffsetMilliseconds;
		}
		else {
			l_shiftedMilliseconds = -1 * i_timeZoneOffsetMilliseconds;
		}
		l_fileLastModifiedDateAndTime = l_fileLastModifiedDateAndTime.plus (l_shiftedMilliseconds, ChronoUnit.MILLIS);
		FilesHandler.setFileLastModifiedDateAndTime (a_fileAbsolutePath, l_fileLastModifiedDateAndTime);
	}
}

