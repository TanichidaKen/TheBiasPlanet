package theBiasPlanet.coreUtilities.filesHandling;

import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.List;
import theBiasPlanet.coreUtilities.messagingHandling.Publisher;

public class FilesVisitor extends SimpleFileVisitor <Path> {
	protected Path i_baseDirectoryAbsolutePath = null;
	protected List <FilesScreener> i_filesScreeners = null;
	protected List <FileProcessor> i_fileProcessors = null;
	protected int i_numberOfSuccessfullyProcessedFiles = 0;
	
	FilesVisitor (List <FilesScreener> a_filesScreeners, List <FileProcessor> a_fileProcessors) {
		i_filesScreeners = a_filesScreeners;
		i_fileProcessors = a_fileProcessors;
	}
	
	@Override
	protected void finalize () {
	}
	
	@Override
	public FileVisitResult visitFile (Path a_fileAbsolutePath, BasicFileAttributes a_fileAttributes) throws IOException {
		boolean l_fileIsSelected = true;
		if (i_filesScreeners != null) {
			for (FilesScreener l_filesScreener: i_filesScreeners) {
				if (! (l_filesScreener.screen (a_fileAbsolutePath, a_fileAttributes))) {
					l_fileIsSelected = false;
				}
			}
		}
		if (l_fileIsSelected) {
			if (i_fileProcessors != null) {
				for (FileProcessor l_fileProcessor: i_fileProcessors) {
					l_fileProcessor.process (a_fileAbsolutePath, a_fileAttributes);
				}
				i_numberOfSuccessfullyProcessedFiles ++;
			}
		}
		return FileVisitResult.CONTINUE;
	}
	
	@Override
	public FileVisitResult preVisitDirectory (Path a_directoryAbsolutePath, BasicFileAttributes a_fileAttributes) {
		if (i_baseDirectoryAbsolutePath == null) {
			i_baseDirectoryAbsolutePath = a_directoryAbsolutePath;
		}
		return FileVisitResult.CONTINUE;
	}
	
	@Override
	public FileVisitResult visitFileFailed (Path a_fileAbsolutePath, IOException a_exception) {
		Publisher.logErrorInformation (a_exception);
		return FileVisitResult.CONTINUE;
	}
	
	public int getNumberOfSuccessfullyProcessedFiles () {
		return i_numberOfSuccessfullyProcessedFiles;
	}
}

