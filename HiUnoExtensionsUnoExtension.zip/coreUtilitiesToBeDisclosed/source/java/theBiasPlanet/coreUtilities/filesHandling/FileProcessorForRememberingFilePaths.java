package theBiasPlanet.coreUtilities.filesHandling;

import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;

public class FileProcessorForRememberingFilePaths implements FileProcessor {
	private ArrayList <Path> i_filePaths = new ArrayList <Path> ();
	private boolean i_relativePathsAreRemembered = false;
	private Path i_baseDirectoryAbsolutePath = null;
	
	public FileProcessorForRememberingFilePaths (boolean a_relativePathsAreRemembered, Path a_baseDirectoryAbsolutePath) {
		i_relativePathsAreRemembered = a_relativePathsAreRemembered;
		i_baseDirectoryAbsolutePath = a_baseDirectoryAbsolutePath;
	}
	
	@Override
	protected void finalize () {
	}
	
	@Override
	public void process (Path a_fileAbsolutePath, BasicFileAttributes a_fileAttributes) {
		if (i_relativePathsAreRemembered) {
			i_filePaths.add (i_baseDirectoryAbsolutePath.relativize (a_fileAbsolutePath));
		}
		else {
			i_filePaths.add (a_fileAbsolutePath);
		}
	}
	
	public ArrayList <Path> getFilePaths () {
		return i_filePaths;
	}
}

