package theBiasPlanet.coreUtilities.filesHandling;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.LocalDateTime;
import java.time.ZoneId;

public class FilesScreenerForRecentModification implements FilesScreener {
	private LocalDateTime i_borderModificationDateAndTime = null;
	
	public FilesScreenerForRecentModification (LocalDateTime a_borderModificationDateAndTime) {
		i_borderModificationDateAndTime = a_borderModificationDateAndTime;
	}
	
	@Override
	protected void finalize () {
	}
	
	@Override
	public boolean screen (Path a_fileAbsolutePath, BasicFileAttributes a_fileAttributes) {
		if (Files.isRegularFile (a_fileAbsolutePath)) {
			if (i_borderModificationDateAndTime != null) {
				LocalDateTime l_fileLastModifiedTime = LocalDateTime.ofInstant (a_fileAttributes.lastModifiedTime ().toInstant (), ZoneId.systemDefault ());
				if (l_fileLastModifiedTime.isEqual (i_borderModificationDateAndTime) || l_fileLastModifiedTime.isAfter (i_borderModificationDateAndTime)) {
					return true;
				}
				else {
					return false;
				}
			}
			else {
				return true;
			}
		}
		else {
			return false;
		}
	}
}

