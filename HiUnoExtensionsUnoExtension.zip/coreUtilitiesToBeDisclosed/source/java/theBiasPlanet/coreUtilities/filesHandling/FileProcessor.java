package theBiasPlanet.coreUtilities.filesHandling;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;

public interface FileProcessor {
	public void process (Path a_fileAbsolutePath, BasicFileAttributes a_fileAttributes) throws IOException;
}

