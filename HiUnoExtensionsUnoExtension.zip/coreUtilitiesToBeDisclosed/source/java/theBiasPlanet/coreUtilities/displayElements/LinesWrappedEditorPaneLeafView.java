package theBiasPlanet.coreUtilities.displayElements;

import javax.swing.text.Element;
import javax.swing.text.LabelView;
import javax.swing.text.View;
import theBiasPlanet.coreUtilities.constantsGroups.*;

public class LinesWrappedEditorPaneLeafView extends LabelView {
	public LinesWrappedEditorPaneLeafView (Element a_element) {
		super (a_element);
	}
	
	@Override
	protected void finalize () {
	}
	
	@Override
	public float getMinimumSpan (int a_axis) {
		switch (a_axis) {
			case View.X_AXIS:
				return 0;
			case View.Y_AXIS:
				return super.getMinimumSpan (a_axis);
			default:
				throw new IllegalArgumentException (String.format (MessagesConstantsGroup.c_invalidAxis, a_axis));
		}
	}
}

