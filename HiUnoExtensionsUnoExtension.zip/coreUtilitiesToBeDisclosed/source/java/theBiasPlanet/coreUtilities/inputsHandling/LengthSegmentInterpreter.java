package theBiasPlanet.coreUtilities.inputsHandling;

import java.io.InputStream;
import java.io.IOException;

public interface LengthSegmentInterpreter {
	// the return -> the length of the corresponding datum
	public int interpret (InputStream a_inputStream) throws IOException;
}

