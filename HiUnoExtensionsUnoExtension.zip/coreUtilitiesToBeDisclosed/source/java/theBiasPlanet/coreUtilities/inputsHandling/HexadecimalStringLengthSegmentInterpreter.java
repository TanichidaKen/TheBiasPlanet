package theBiasPlanet.coreUtilities.inputsHandling;

import java.io.IOException;
import java.io.InputStream;
import theBiasPlanet.coreUtilities.constantsGroups.CharactersSetNamesConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.InputPropertiesConstantsGroup;

public class HexadecimalStringLengthSegmentInterpreter implements LengthSegmentInterpreter {
	int i_segmentLength = InputPropertiesConstantsGroup.c_lengthNotSet;
	
	public HexadecimalStringLengthSegmentInterpreter (int a_segmentLength) {
		i_segmentLength = a_segmentLength;
	}
	
	// the return -> the length of the corresponding datum
	public int interpret (InputStream a_inputStream) throws IOException {
		byte [] l_bytesArray = new byte [i_segmentLength];
		int l_readFunctionReturn = a_inputStream.read (l_bytesArray, GeneralConstantsConstantsGroup.c_iterationStartNumber, i_segmentLength);
		if (l_readFunctionReturn < i_segmentLength) {
			if (l_readFunctionReturn == InputPropertiesConstantsGroup.c_noMoreData) {
				return InputPropertiesConstantsGroup.c_noMoreData;
			}
			else {
				throw new IOException ("The input stream is invalid.");
			}
		}
		int l_setLength =  Integer.parseInt (new String (l_bytesArray, CharactersSetNamesConstantsGroup.c_utf8CharactersSetName), 16);
		if (l_setLength > 0) {
			return l_setLength - i_segmentLength;
		}
		else {
			return 0;
		}
	}
}

