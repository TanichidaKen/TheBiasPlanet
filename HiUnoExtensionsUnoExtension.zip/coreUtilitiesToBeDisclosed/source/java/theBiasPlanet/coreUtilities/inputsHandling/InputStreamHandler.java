package theBiasPlanet.coreUtilities.inputsHandling;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import theBiasPlanet.coreUtilities.constantsGroups.DefaultValuesConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.InputPropertiesConstantsGroup;

public class InputStreamHandler {
	private static final int c_bufferSize = DefaultValuesConstantsGroup.c_smallBufferSize;
	
	public static void writeWholeContentsToOutputStream (InputStream a_inputStream, OutputStream a_outputStream) throws IOException {
		byte [] l_bytesArray = new byte [c_bufferSize];
		int l_readFunctionReturn = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		while ( (l_readFunctionReturn = a_inputStream.read (l_bytesArray, GeneralConstantsConstantsGroup.c_iterationStartNumber, c_bufferSize)) != InputPropertiesConstantsGroup.c_noMoreData) {
			a_outputStream.write (l_bytesArray, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readFunctionReturn);
			a_outputStream.flush ();
		}
	}
}

