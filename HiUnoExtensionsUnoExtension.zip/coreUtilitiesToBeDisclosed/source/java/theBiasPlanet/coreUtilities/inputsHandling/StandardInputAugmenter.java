package theBiasPlanet.coreUtilities.inputsHandling;

import java.io.File;
import java.util.Scanner;
import theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup;

final public class StandardInputAugmenter {
	private StandardInputAugmenter () {
	}
	
	public static void main (String [] a_argumentsArray) throws Exception {
		Scanner l_inputScanner = null;
		String l_inputLine = null;
		for (int l_iterationIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber; l_iterationIndex < a_argumentsArray.length + 1; l_iterationIndex ++) {
			if (l_iterationIndex < a_argumentsArray.length) {
				l_inputScanner = new Scanner (new File (a_argumentsArray [l_iterationIndex]));
			}
			else {
				l_inputScanner = new Scanner (System.in);
			}
			while (l_inputScanner.hasNextLine ()) {
				l_inputLine = l_inputScanner.nextLine ();
				System.out.println (l_inputLine);
			}
			l_inputScanner.close ();
		}
	}
}

