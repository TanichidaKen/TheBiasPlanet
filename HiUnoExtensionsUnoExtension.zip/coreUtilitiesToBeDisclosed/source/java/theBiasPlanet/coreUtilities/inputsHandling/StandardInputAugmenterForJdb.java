package theBiasPlanet.coreUtilities.inputsHandling;

import java.io.File;
import java.util.Scanner;
import theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup;

final public class StandardInputAugmenterForJdb {
	private StandardInputAugmenterForJdb () {
	}
	
	public static void main (String [] a_argumentsArray) throws Exception {
		Scanner l_inputScanner = null;
		String l_inputLine = null;
		boolean l_isInStandardInput = false;
		for (int l_iterationIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber; l_iterationIndex < a_argumentsArray.length + 1; l_iterationIndex ++) {
			if (l_iterationIndex < a_argumentsArray.length) {
				l_inputScanner = new Scanner (new File (a_argumentsArray [l_iterationIndex]));
			}
			else {
				l_inputScanner = new Scanner (System.in);
				l_isInStandardInput = true;
			}
			while (l_inputScanner.hasNextLine ()) {
				l_inputLine = l_inputScanner.nextLine ();
				if (l_isInStandardInput) {
					if ("c".equals (l_inputLine)) {
						l_inputLine = "cont";
					}
					if ("n".equals (l_inputLine)) {
						l_inputLine = "next";
					}
					if ("s".equals (l_inputLine)) {
						l_inputLine = "step";
					}
					if (l_inputLine.startsWith ("p ")) {
						l_inputLine = String.format ("print %s", l_inputLine.substring (2));
					}
					if (l_inputLine.startsWith ("d ")) {
						l_inputLine = String.format ("dump %s", l_inputLine.substring (2));
					}
				}
				System.out.println (l_inputLine);
			}
			l_inputScanner.close ();
		}
	}
}

