package theBiasPlanet.coreUtilities.processesHandling;

import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.io.BufferedWriter;;
import java.io.File;
import java.io.Reader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.InterruptedIOException;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.coreUtilities.inputs.HaltableStandardInputReader;
import theBiasPlanet.coreUtilities.inputsHandling.NoMoreDataException;
import theBiasPlanet.coreUtilities.messagingHandling.Publisher;
import theBiasPlanet.coreUtilities.timersHandling.TimeOutException;

public class ProcessHandler {
	private static HaltableStandardInputReader s_haltableStandardInputReader = HaltableStandardInputReader.getInstance ();
	
	static {
		// the dispatch data thread is not started automatically.
		//s_haltableStandardInputReader.startDispatchDataThread ();
	}
	
	private static void interruptRelayStandardInputThread (Thread a_thread) {
		s_haltableStandardInputReader.removeSubscriber (String.format ("%d", a_thread.getId ()));
	}
	
	public static class StandardInputAndOutputs {
		private Process i_process = null;
		private OutputStream i_standardInputOutputStream = null;
		private InputStream i_standardOutputInputStream = null;
		private InputStream i_standardErrorOutputInputStream = null;
		private Thread i_relayStandardInputThread = null;
		private Thread i_printStandardOutputThread = null;
		private Thread i_printStandardErrorOutputThread = null;
		private boolean i_thereWereStandardInputContents = false;
		private boolean i_thereWereStandardOutputContents = false;
		private boolean i_thereWereStandardErrorOutputContents = false;
		private BufferedWriter i_standardInputWriter = null;
		private Scanner i_standardOutputScanner = null;
		private Scanner i_standardErrorOutputScanner = null;
		
		public StandardInputAndOutputs (Process a_process) {
			i_process = a_process;
			i_standardInputOutputStream = i_process.getOutputStream ();
			i_standardOutputInputStream = i_process.getInputStream ();
			i_standardErrorOutputInputStream = i_process.getErrorStream ();
		}
		
		public OutputStream getStandardInputOutputStream () {
			return i_standardInputOutputStream;
		}
		
		public InputStream getStandardOutputInputStream () {
			return i_standardOutputInputStream;
		}
		
		public InputStream getStandardErrorOutputInputStream () {
			return i_standardErrorOutputInputStream;
		}
		
		public void relayStandardInputAsynchronously () {
			i_relayStandardInputThread = new Thread (() -> {
				String l_threadIdentification = String.format ("%d", Thread.currentThread ().getId ());
				try {
					Writer l_processStandardInputWriter = new OutputStreamWriter (i_standardInputOutputStream);
					String l_standardInputDatum = null;
					while (true) {
						try {
							l_standardInputDatum = s_haltableStandardInputReader.read (l_threadIdentification, 1);
							i_thereWereStandardInputContents = true;
							l_processStandardInputWriter.write (l_standardInputDatum);
							l_processStandardInputWriter.flush ();
						}
						catch (NoMoreDataException l_exception) {
							break;
						}
						catch (TimeOutException l_exception) {
							// impossible
						}
					}
					l_processStandardInputWriter.close ();
					i_standardInputOutputStream.close ();
				}
				catch (InterruptedIOException l_exception) {
				}
				catch (IOException l_exception) {
					Publisher.logErrorInformation (String.format ("### A standard input error: %s.", l_exception));
				}
			});
			s_haltableStandardInputReader.addSubscriber (String.format ("%d", i_relayStandardInputThread.getId ()));
			i_relayStandardInputThread.start ();
		}
		
		public void printStandardOutputAsynchronously () {
			i_printStandardOutputThread = new Thread (() -> {
				try {
					Reader l_standardOutputReader = new InputStreamReader (i_standardOutputInputStream);
					char [] l_standardOutputData = new char [DefaultValuesConstantsGroup.c_smallBufferSize];
					int l_standardOutputDataLength = -1;
					while ((l_standardOutputDataLength = l_standardOutputReader.read (l_standardOutputData)) != -1) {
						for (int l_characterIndex = 0; l_characterIndex < l_standardOutputDataLength; l_characterIndex ++) {
							i_thereWereStandardOutputContents = true;
							System.out.print (l_standardOutputData [l_characterIndex]);
						}
						System.out.flush ();
					}
				}
				catch (IOException l_exception) {
					System.err.println (String.format ("### A standard output error: %s.", l_exception));
				}
			});
			i_printStandardOutputThread.start ();
		}
		
		public void printStandardErrorOutputAsynchronously () {
			i_printStandardErrorOutputThread = new Thread (() -> {
				try {
					Reader l_standardErrorOutputReader = new InputStreamReader (i_standardErrorOutputInputStream);
					char [] l_standardErrorOutputData = new char [DefaultValuesConstantsGroup.c_smallBufferSize];
					int l_standardErrorOutputDataLength = -1;
					while ((l_standardErrorOutputDataLength = l_standardErrorOutputReader.read (l_standardErrorOutputData)) != -1) {
						for (int l_characterIndex = 0; l_characterIndex < l_standardErrorOutputDataLength; l_characterIndex ++) {
							i_thereWereStandardErrorOutputContents = true;
							System.err.print (l_standardErrorOutputData [l_characterIndex]);
						}
						System.err.flush ();
					}
				}
				catch (IOException l_exception) {
					System.err.println (String.format ("### A standard error output error: %s.", l_exception));
				}
			});
			i_printStandardErrorOutputThread.start ();
		}
		
		public void setStandardInputNextLine (String a_line) throws IOException {
			if (i_standardInputWriter == null) {
				i_standardInputWriter = new BufferedWriter (new OutputStreamWriter (i_standardInputOutputStream));
			}
			try {
				i_thereWereStandardInputContents = true;
				i_standardInputWriter.write (a_line);
				i_standardInputWriter.newLine ();
			}
			catch (Exception l_exception) {
				System.err.println (String.format ("The standard input couldn't be written: %s.", l_exception));
				i_standardInputWriter.close ();
			}
		}
		
		public void flushStandardInput () throws IOException {
			if (i_standardInputWriter == null) {
				i_standardInputWriter = new BufferedWriter (new OutputStreamWriter (i_standardInputOutputStream));
			}
			try {
				i_standardInputWriter.flush ();
			}
			catch (Exception l_exception) {
				System.err.println (String.format ("The standard input couldn't be written: %s.", l_exception));
				i_standardInputWriter.close ();
			}
		}
		
		public String getStandardOutputNextLine () throws IOException {
			if (i_standardOutputScanner == null) {
				i_standardOutputScanner = new Scanner (i_standardOutputInputStream);
			}
			try {
				if (i_standardOutputScanner.hasNextLine ()) {
					i_thereWereStandardOutputContents = true;
					return i_standardOutputScanner.nextLine ();
				}
				else {
					i_standardOutputScanner.close ();
					return null;
				}
			}
			catch (Exception l_exception) {
				System.err.println (String.format ("The standard output couldn't be scanned: %s.", l_exception));
				i_standardOutputScanner.close ();
				return null;
			}
		}
		
		public String getStandardErrorOutputNextLine () throws IOException {
			if (i_standardErrorOutputScanner == null) {
				i_standardErrorOutputScanner = new Scanner (i_standardErrorOutputInputStream);
			}
			try {
				if (i_standardErrorOutputScanner.hasNextLine ()) {
					i_thereWereStandardErrorOutputContents = true;
					return i_standardErrorOutputScanner.nextLine ();
				}
				else {
					i_standardErrorOutputScanner.close ();
					return null;
				}
			}
			catch (Exception l_exception) {
				System.err.println ("The standard error output couldn't be scanned.");
				i_standardErrorOutputScanner.close ();
				return null;
			}
		}
		
		public boolean thereWereStandardInputContents () {
			return i_thereWereStandardInputContents;
		}
		
		public boolean thereWereStandardOutputContents () {
			return i_thereWereStandardOutputContents;
		}
		
		public boolean thereWereStandardErrorOutputContents () {
			return i_thereWereStandardErrorOutputContents;
		}
		
		public int waitUntillFinish () throws InterruptedException {
			if (i_printStandardErrorOutputThread != null) {
				i_printStandardErrorOutputThread.join ();
				i_printStandardErrorOutputThread = null;
			}
			if (i_printStandardOutputThread != null) {
				i_printStandardOutputThread.join ();
				i_printStandardOutputThread = null;
			}
			int l_processReturn = i_process.waitFor ();
			if (i_relayStandardInputThread != null) {
				interruptRelayStandardInputThread (i_relayStandardInputThread);
				i_relayStandardInputThread.join ();
				i_relayStandardInputThread = null;
			}
			return l_processReturn;
		}
	}
	
	// The environment variables of the current process are automatically passed into the sub process.
	public static StandardInputAndOutputs executeAndReturnStandardInputAndOutputs (File a_workingDirectory, Map <String, String> a_addedEnvironmentVaribleNameToValueMap, List <String> a_commandAndArguments) throws IOException, InterruptedException {
		ProcessBuilder l_processBuilder = new ProcessBuilder (a_commandAndArguments);
		if (a_workingDirectory != null) {
			l_processBuilder.directory (a_workingDirectory);
		}
		if (a_addedEnvironmentVaribleNameToValueMap != null) {
			Map <String, String> l_processEnvironmentVaribleNameToValueMap = l_processBuilder.environment ();
			for (Map.Entry <String, String> l_addedEnvironmentVaribleNameToValueMapEntry: a_addedEnvironmentVaribleNameToValueMap.entrySet ()) {
				l_processEnvironmentVaribleNameToValueMap.put (l_addedEnvironmentVaribleNameToValueMapEntry.getKey (), l_addedEnvironmentVaribleNameToValueMapEntry.getValue ());
			}
		}
		Process l_childProcess = l_processBuilder.start ();
		return new StandardInputAndOutputs (l_childProcess);
	}
	
	public static int execute (File a_workingDirectory, Map <String, String> a_addedEnvironmentVaribleNameToValueMap, List <String> a_commandAndArguments, boolean a_waitsUntilFinish) throws IOException, InterruptedException {
		StandardInputAndOutputs l_childProcessStandardInputAndOutputs = executeAndReturnStandardInputAndOutputs (a_workingDirectory, a_addedEnvironmentVaribleNameToValueMap, a_commandAndArguments);
		int l_childProcessReturn = 0;
		if (a_waitsUntilFinish) {
			l_childProcessStandardInputAndOutputs.printStandardOutputAsynchronously ();
			l_childProcessStandardInputAndOutputs.printStandardErrorOutputAsynchronously ();
			l_childProcessStandardInputAndOutputs.relayStandardInputAsynchronously ();
			l_childProcessReturn = l_childProcessStandardInputAndOutputs.waitUntillFinish ();
		}
		else {
			Thread l_waitForInvokedProcessToEndThread = new Thread (() -> {
				try {
					l_childProcessStandardInputAndOutputs.printStandardOutputAsynchronously ();
					l_childProcessStandardInputAndOutputs.printStandardErrorOutputAsynchronously ();
					l_childProcessStandardInputAndOutputs.relayStandardInputAsynchronously ();
					l_childProcessStandardInputAndOutputs.waitUntillFinish ();
				}
				catch (InterruptedException l_exception) {
				}
			});
			l_waitForInvokedProcessToEndThread.start ();
		}
		return l_childProcessReturn;
	}
}

