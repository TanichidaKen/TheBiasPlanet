package theBiasPlanet.coreUtilities.displaysHandling;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.event.UndoableEditEvent;
import javax.swing.event.UndoableEditListener;
import javax.swing.text.DefaultEditorKit;
import javax.swing.text.JTextComponent;
import javax.swing.undo.CannotRedoException;
import javax.swing.undo.CannotUndoException;
import javax.swing.undo.UndoManager;
import theBiasPlanet.coreUtilities.constantsGroups.UserInterfaceComponentCaptionsConstantsGroup;
import theBiasPlanet.coreUtilities.messagingHandling.Publisher;

public class PopUpMenuInjector {
	public static void injectEditorPopUpMenu (JTextComponent a_editor) {
		UndoManager l_undoManager = new UndoManager ();
		a_editor.getDocument ().addUndoableEditListener (new UndoableEditListener () {
			@Override
			public void undoableEditHappened (UndoableEditEvent a_undoableEditEvent) {
				l_undoManager.addEdit (a_undoableEditEvent.getEdit ());
			}
		});
		Action l_undoAction = new AbstractAction (UserInterfaceComponentCaptionsConstantsGroup.c_undo) {
			@Override
			public void actionPerformed (ActionEvent a_actionEvent) {
				try {
					if (l_undoManager.canUndo ()) {
						l_undoManager.undo ();
					}
				} catch (CannotUndoException l_cannotUndoException) {
					Publisher.show (l_cannotUndoException.toString ());
				}
			}
		};
		Action l_redoAction = new AbstractAction (UserInterfaceComponentCaptionsConstantsGroup.c_redo) {
			@Override
			public void actionPerformed (ActionEvent a_actionEvent) {
				try {
					if (l_undoManager.canRedo ()) {
						l_undoManager.redo ();
					}
				} catch (CannotRedoException l_cannotRedoException) {
					Publisher.show (l_cannotRedoException.toString ());
				}
			}
		};
		JPopupMenu l_popUpMenu = new JPopupMenu ();
		JMenuItem l_popUpMenuCutItem = new JMenuItem (a_editor.getActionMap().get (DefaultEditorKit.cutAction));
		l_popUpMenuCutItem.setText (UserInterfaceComponentCaptionsConstantsGroup.c_cut);
		l_popUpMenu.add (l_popUpMenuCutItem);
		JMenuItem l_popUpMenuCopyItem = new JMenuItem (a_editor.getActionMap().get (DefaultEditorKit.copyAction));
		l_popUpMenuCopyItem.setText (UserInterfaceComponentCaptionsConstantsGroup.c_copy);
		l_popUpMenu.add (l_popUpMenuCopyItem);
		JMenuItem l_popUpMenuPasteItem = new JMenuItem (a_editor.getActionMap().get (DefaultEditorKit.pasteAction));
		l_popUpMenuPasteItem.setText (UserInterfaceComponentCaptionsConstantsGroup.c_paste);
		l_popUpMenu.add (l_popUpMenuPasteItem);
		JMenuItem l_selectAllItem = new JMenuItem (a_editor.getActionMap().get (DefaultEditorKit.selectAllAction));
		l_selectAllItem.setText (UserInterfaceComponentCaptionsConstantsGroup.c_selectAll);
		l_popUpMenu.add (l_selectAllItem);
		JMenuItem l_popUpMenuUndoItem = new JMenuItem(l_undoAction);
		l_popUpMenuUndoItem.setText (UserInterfaceComponentCaptionsConstantsGroup.c_undo);
		l_popUpMenu.add (l_popUpMenuUndoItem);
		JMenuItem l_popUpMenuRedoItem = new JMenuItem (l_redoAction);
		l_popUpMenuRedoItem.setText (UserInterfaceComponentCaptionsConstantsGroup.c_redo);
		l_popUpMenu.add (l_popUpMenuRedoItem);
		a_editor.addMouseListener (new MouseListener () {
			private void showPopupMenu (MouseEvent a_mouseEvent) {
				if (a_mouseEvent.isPopupTrigger ()) {
					boolean l_textIsSelected = (a_editor.getSelectionStart () != a_editor.getSelectionEnd ());
					l_popUpMenuCutItem.setEnabled (l_textIsSelected);
					l_popUpMenuCopyItem.setEnabled (l_textIsSelected);
					l_popUpMenuUndoItem.setEnabled (l_undoManager.canUndo ());
					l_popUpMenuRedoItem.setEnabled (l_undoManager.canRedo ());
					l_popUpMenu.show (a_mouseEvent.getComponent(), a_mouseEvent.getX (), a_mouseEvent.getY ());
				}
			}
			
			@Override
			public void mousePressed (MouseEvent a_mouseEvent) {
				showPopupMenu (a_mouseEvent);
			}
			
			@Override
			public void mouseReleased (MouseEvent a_mouseEvent) {
				showPopupMenu (a_mouseEvent);
			}
			
			@Override
			public void mouseClicked (MouseEvent a_mouseEvent) {
				showPopupMenu (a_mouseEvent);
			}
			
			@Override
			public void mouseEntered (MouseEvent a_mouseEvent) {
			}
			
			@Override
			public void mouseExited (MouseEvent a_mouseEvent) {
			}
		});
		a_editor.addKeyListener (new KeyListener () {
			@Override
			public void keyTyped (KeyEvent a_keyEvent) {
			}
			
			@Override
			public void keyPressed (KeyEvent a_keyEvent) {
				switch (a_keyEvent.getKeyCode ()) {
				case KeyEvent.VK_Z:
					if (a_keyEvent.isControlDown () && l_undoManager.canUndo ()) {
						l_undoManager.undo ();
					}
					break;
				case KeyEvent.VK_Y:
					if (a_keyEvent.isControlDown () && l_undoManager.canRedo ()) {
						l_undoManager.redo ();
					}
					break;
				}
			}
			
			@Override
			public void keyReleased (KeyEvent a_keyEvent) {
			}
		});
	}
}

