package theBiasPlanet.coreUtilities.constantsGroups;

public interface SwingStyleNamesConstantsGroup {
	String c_normal = "normal";
}

