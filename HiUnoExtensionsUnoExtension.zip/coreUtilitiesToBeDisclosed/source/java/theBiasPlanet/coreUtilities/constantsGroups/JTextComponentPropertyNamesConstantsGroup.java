package theBiasPlanet.coreUtilities.constantsGroups;

public interface JTextComponentPropertyNamesConstantsGroup {
	String c_font = "font";
}

