package theBiasPlanet.coreUtilities.constantsGroups;

import java.nio.file.Path;
import java.nio.file.Paths;

public interface GitEnvironmentConstantsGroup {
	Path c_fileMetaDataBundleFilePath = Paths.get (".FileMetaDataBundle");
}

