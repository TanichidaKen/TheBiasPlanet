package theBiasPlanet.coreUtilities.bytesArraysHandling;

import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import theBiasPlanet.coreUtilities.constantsGroups.*;

public class BytesBufferToCharactersBufferDecoder {
	private CharsetDecoder i_instanceOfCharsetDecoder = null;
	// Although the encoding may not be UTF-8, any character of any major encoding isn't supposed to be longer than the per-UTF-8-character maximum bytes length.
	private	ByteBuffer i_previousInputsResidueBuffer = ByteBuffer.wrap (new byte [GeneralConstantsConstantsGroup.c_maximumBytesLengthPerUtf8Character]);
	
	public BytesBufferToCharactersBufferDecoder (String a_encoding) {
		i_instanceOfCharsetDecoder = Charset.forName (a_encoding).newDecoder ();
	}
	
	@Override
	protected void finalize () {
	}
	
	public BytesBufferToCharactersBufferDecodingResult decode (ByteBuffer a_newInputBuffer, CharBuffer a_outputBuffer, boolean a_isLastInput) {
		BytesBufferToCharactersBufferDecodingResult l_decodingResult = null;
		int l_previousInputsResidueBufferStartPointOfTimeIndex = i_previousInputsResidueBuffer.position (); // the index after the previous inputs residue
		if (l_previousInputsResidueBufferStartPointOfTimeIndex != GeneralConstantsConstantsGroup.c_iterationStartNumber) {
			int l_supplementalInputCandidateLength = Math.min (a_newInputBuffer.limit () - a_newInputBuffer.position (), i_previousInputsResidueBuffer.capacity () - l_previousInputsResidueBufferStartPointOfTimeIndex);
			if (l_supplementalInputCandidateLength == 0) {
				// The previous inputs residue cannot be complemented, so an error.
				l_decodingResult = new BytesBufferToCharactersBufferDecodingResult (-1 * l_previousInputsResidueBufferStartPointOfTimeIndex);
				return l_decodingResult;
			}
			int l_newInputBufferLimit = a_newInputBuffer.limit ();
			a_newInputBuffer.limit (a_newInputBuffer.position () + l_supplementalInputCandidateLength);
			i_previousInputsResidueBuffer.put (a_newInputBuffer);
			a_newInputBuffer.limit (l_newInputBufferLimit);
			i_previousInputsResidueBuffer.flip ();
			l_decodingResult = new BytesBufferToCharactersBufferDecodingResult (i_instanceOfCharsetDecoder.decode (i_previousInputsResidueBuffer, a_outputBuffer, false), i_previousInputsResidueBuffer);
			if (l_decodingResult.isUnderflowed ()) {
				// 'l_decodingResult.getInputsResidueStartIndex()' is the start index of the new residue.
				if (l_decodingResult.getInputsResidueStartIndex() == GeneralConstantsConstantsGroup.c_iterationStartNumber) {
					// The previous residue has not been completed, with some new bytes added.
					// preparing the residue buffer for the next input
					i_previousInputsResidueBuffer.position (i_previousInputsResidueBuffer.limit ());
					i_previousInputsResidueBuffer.limit (i_previousInputsResidueBuffer.capacity ());
					l_decodingResult.setInputsResidueStartIndex (-1 * l_previousInputsResidueBufferStartPointOfTimeIndex);
					return l_decodingResult;
				}
				else {
					// The previous residue has been completed, but some new residue may remain.
					// the new input buffer is rewound for the new residue.
					a_newInputBuffer.position (a_newInputBuffer.position () - (i_previousInputsResidueBuffer.limit () -  l_decodingResult.getInputsResidueStartIndex ()));
					// The previous residue buffer is cleared because the new residue will be read from the new input.
					i_previousInputsResidueBuffer.clear ();
				}
			}
			else if (l_decodingResult.isJustFit ()) {
				i_previousInputsResidueBuffer.clear ();
			}
			else {
				// It is malformed.
				int l_inputsResidueStartIndex = l_decodingResult.getInputsResidueStartIndex () < l_previousInputsResidueBufferStartPointOfTimeIndex ? -1 * (l_previousInputsResidueBufferStartPointOfTimeIndex - l_decodingResult.getInputsResidueStartIndex ()):  a_newInputBuffer.position () - l_supplementalInputCandidateLength + (l_decodingResult.getInputsResidueStartIndex () - l_previousInputsResidueBufferStartPointOfTimeIndex); // The former condition is that the error bytes begin in the previous residue; the latter condition is that the error bytes begin in the new input.
				l_decodingResult.setInputsResidueStartIndex (l_inputsResidueStartIndex);
				return l_decodingResult;
			}
		}
		// Here, there cannot be any residue.
		l_decodingResult = new BytesBufferToCharactersBufferDecodingResult (i_instanceOfCharsetDecoder.decode (a_newInputBuffer, a_outputBuffer, a_isLastInput), a_newInputBuffer);
		if (a_isLastInput) {
			i_instanceOfCharsetDecoder.flush (a_outputBuffer);
		}
		if (l_decodingResult.isUnderflowed ()) {
			// The new residue is remembered for the next input.
			i_previousInputsResidueBuffer.put (a_newInputBuffer);
		}
		return l_decodingResult;
	}
	
	public void reset () {
		i_instanceOfCharsetDecoder.reset ();
		i_previousInputsResidueBuffer.clear ();
	}
}

