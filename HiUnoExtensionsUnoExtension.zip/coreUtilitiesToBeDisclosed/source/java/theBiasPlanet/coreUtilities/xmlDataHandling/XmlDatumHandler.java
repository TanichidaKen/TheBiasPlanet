package theBiasPlanet.coreUtilities.xmlDataHandling;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilterReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import theBiasPlanet.coreUtilities.constantsGroups.CharactersSetNamesConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.InputPropertiesConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.XmlExpressionsConstantsGroup;
import theBiasPlanet.coreUtilities.filesHandling.FilesHandler;
import theBiasPlanet.coreUtilities.inputs.Utf8BomIgnoringInputStreamReader;
import theBiasPlanet.coreUtilities.stringsHandling.StringRange;

public final class XmlDatumHandler {
	private XmlDatumHandler () {
	}
	
	// To get the map of a first tier node attribute (only the first attribute is ) value to second tier node attribute values.
	// The root node isn't counted as a tier.
	public static HashMap <String, List <String>> get2TierAttributeValues (String a_xmlFileUrl) throws IOException, ParserConfigurationException, SAXException {
		HashMap <String, List <String>> l_attributesMap = new HashMap <String, List <String>> ();
		DocumentBuilderFactory l_documentBuildersFactory = DocumentBuilderFactory.newInstance ();
		DocumentBuilder l_documentBuilder = l_documentBuildersFactory.newDocumentBuilder ();
		Document l_document = l_documentBuilder.parse (a_xmlFileUrl);
		Element l_rootElement = l_document.getDocumentElement ();
		NodeList l_rootChildNodes = l_rootElement.getChildNodes ();
		if (l_rootChildNodes == null) {
			return l_attributesMap;
		}
		for (int l_i = 0; l_i < l_rootChildNodes.getLength (); l_i++) {
			Node l_rootChildNode = l_rootChildNodes.item (l_i);
			if (l_rootChildNode.getNodeType () == Node.ELEMENT_NODE) {
				String l_key = null;
				List <String> l_value = new ArrayList <String> ();
				NamedNodeMap l_rootChildNodeAttributes =  l_rootChildNode.getAttributes ();
				if (l_rootChildNodeAttributes == null) {
					continue;
				}
				Node l_rootChildNodeAttribute = l_rootChildNodeAttributes.item (0);
				l_key = l_rootChildNodeAttribute.getTextContent ();
				NodeList l_rootGrandChildNodes = l_rootChildNode.getChildNodes ();
				if (l_rootGrandChildNodes != null) {
					for (int l_j = 0; l_j < l_rootGrandChildNodes.getLength (); l_j++) {
						Node l_rootGrandChildNode = l_rootGrandChildNodes.item (l_j);
						if (l_rootGrandChildNode.getNodeType () == Node.ELEMENT_NODE) {
							String l_rootGrandChildNodeAttributeText = null;
							NamedNodeMap l_rootGrandChildNodeAttributes =  l_rootGrandChildNode.getAttributes ();
							if (l_rootGrandChildNodeAttributes == null) {
								continue;
							}
							Node l_rootGrandChildNodeAttribute = l_rootGrandChildNodeAttributes.item (0);
							l_rootGrandChildNodeAttributeText = l_rootGrandChildNodeAttribute.getTextContent ();
							l_value.add (l_rootGrandChildNodeAttributeText);
						}
					}
				}
				l_attributesMap.put (l_key, l_value);
			}
		}
		return l_attributesMap;	
	}
	
	public static void removeNode (Node a_nodeToRemove) {
		a_nodeToRemove.getParentNode ().removeChild (a_nodeToRemove);
	}
	
	public static void removeNodes (NodeList a_nodesToRemove) {
		IntStream.range (0, a_nodesToRemove.getLength ())
                                   .mapToObj (a_nodesToRemove::item).forEach (l_nodeToRemove -> {
						removeNode (l_nodeToRemove);
					});
	}
	
	public static void writeNodeToWriter (Node a_node, Writer a_writer, boolean a_fromHtml) throws TransformerException, IOException {
		Transformer l_transformer = TransformerFactory.newInstance ().newTransformer ();
		l_transformer.setOutputProperty (OutputKeys.OMIT_XML_DECLARATION, "no");
		l_transformer.setOutputProperty (OutputKeys.INDENT, "yes");
		if (a_fromHtml) {
			l_transformer.setOutputProperty (OutputKeys.CDATA_SECTION_ELEMENTS, "{http://www.w3.org/1999/xhtml}script {http://www.w3.org/1999/xhtml}style");
		}
		l_transformer.transform(new DOMSource (a_node), new StreamResult (a_writer));
		a_writer.close ();
	}
	
	public static class HtmlFilterReader extends FilterReader {
		int readInitialSequenceCharacters = 0;
		String initialSequence = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Frameset//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd\">\n<html xmlns=\"http://www.w3.org/1999/xhtml\"";
		boolean skippedOriginalInitialSequence = false;
		
		public HtmlFilterReader (Reader a_originalReader) {
			super (a_originalReader);
		}
		
		public int read (char[] a_bufferToSet, int a_toSetFrom, int a_maximumLengthToRead) throws IOException {
			if (skippedOriginalInitialSequence) {
				return in.read (a_bufferToSet, a_toSetFrom, a_maximumLengthToRead);
			}
			if (readInitialSequenceCharacters < initialSequence.length()) {
				int l_readLength = -1;
				int l_endToReadCharacterIndex = -1;
				if (readInitialSequenceCharacters + a_maximumLengthToRead <= initialSequence.length()) {
					l_endToReadCharacterIndex = readInitialSequenceCharacters + a_maximumLengthToRead;
				}
				else {
					l_endToReadCharacterIndex = initialSequence.length();
				}
				System.arraycopy (initialSequence.substring (readInitialSequenceCharacters, l_endToReadCharacterIndex).toCharArray(), 0, a_bufferToSet, a_toSetFrom, l_endToReadCharacterIndex - readInitialSequenceCharacters);
				l_readLength = l_endToReadCharacterIndex - readInitialSequenceCharacters;
				readInitialSequenceCharacters = l_endToReadCharacterIndex;
				return l_readLength;
			}
			else {
				char [] l_buffer = new char [a_maximumLengthToRead];
				char [] l_sequenceToCatch = {'<', 'h', 't', 'm', 'l'};
				int l_toMatchIndex = 0;
				int l_readLengthThisTime = -1;
				int l_characterIndex = -1;
				outerLoop:
				while (true) {
					l_readLengthThisTime = in.read (l_buffer, 0, a_maximumLengthToRead);
					if (l_readLengthThisTime == -1) {
						return -1;
					}
					for (l_characterIndex = 0; l_characterIndex < l_readLengthThisTime; l_characterIndex++) {
						if (l_sequenceToCatch [l_toMatchIndex] == l_buffer [l_characterIndex]) {
							l_toMatchIndex ++;
							if (l_toMatchIndex >= l_sequenceToCatch.length) {
								break outerLoop;
							}
						}
						else {
							l_toMatchIndex = 0;
							if (l_sequenceToCatch [l_toMatchIndex] == l_buffer [l_characterIndex]) {
								l_toMatchIndex ++;
								if (l_toMatchIndex >= l_sequenceToCatch.length) {
									break outerLoop;
								}
							}
						}
					}
				}
				
				skippedOriginalInitialSequence = true;
				if (l_characterIndex + 1 < l_readLengthThisTime) {
					System.arraycopy (l_buffer, l_characterIndex + 1, a_bufferToSet, a_toSetFrom, l_readLengthThisTime - (l_characterIndex + 1));
					return l_readLengthThisTime - (l_characterIndex + 1);
				}
				else {
					return 0;
				}
			}
		}
		
		public int read() throws IOException {
			char [] l_buffer = new char [1];
			read (l_buffer, 0, 1);
			return (int) l_buffer [0];
		}
	}
	
	public static String getEscapedXmlText (String a_originalText) {
		Map <Character, String> l_toEscapeCharacterEscapedStringMap = new HashMap <Character, String> ();
		l_toEscapeCharacterEscapedStringMap.put (GeneralConstantsConstantsGroup.c_lessThanCharacter, XmlExpressionsConstantsGroup.c_lessThanXmlExpression);
		l_toEscapeCharacterEscapedStringMap.put (GeneralConstantsConstantsGroup.c_greaterThanCharacter, XmlExpressionsConstantsGroup.c_greaterThanXmlExpression);
		l_toEscapeCharacterEscapedStringMap.put (GeneralConstantsConstantsGroup.c_ampersandCharacter, XmlExpressionsConstantsGroup.c_ampersandXmlExpression);
		l_toEscapeCharacterEscapedStringMap.put (GeneralConstantsConstantsGroup.c_doubleQuotationMarkCharacter, XmlExpressionsConstantsGroup.c_doubleQuotationMarkXmlExpression);
		l_toEscapeCharacterEscapedStringMap.put (GeneralConstantsConstantsGroup.c_apostropheCharacter, XmlExpressionsConstantsGroup.c_apostropheXmlExpression);
		StringReader l_stringReader = new StringReader (a_originalText);
		int l_processingData = InputPropertiesConstantsGroup.c_noMoreData;
		char l_processingCharacter;
		StringBuilder l_escapedText = new StringBuilder ();
		String l_characterEscapedString = null;
		while (true) {
			try {
				l_processingData = l_stringReader.read ();
			}
			catch (IOException l_exception) {
				throw new RuntimeException (l_exception);
			}
			if (l_processingData == InputPropertiesConstantsGroup.c_noMoreData) {
				break;
			}
			l_processingCharacter = (char) l_processingData;
			l_characterEscapedString = l_toEscapeCharacterEscapedStringMap.get (l_processingCharacter);
			if (l_characterEscapedString == null) {
				l_escapedText.append (l_processingCharacter);
			}
			else {
				l_escapedText.append (l_characterEscapedString);
			}
		}
		l_stringReader.close ();
		return l_escapedText.toString ();
	}
	
	public static String getElementOpenString (Element a_element, Map <String, String> a_prefixNamespaceUriMap) {
		StringBuilder l_bufferString = new StringBuilder ();
		String l_namespaceUriString;
		String l_prefix;
		int l_numberOfAttributes;
		NamedNodeMap l_attributes;
		Attr l_attribute;
		l_bufferString.append ("<");
		l_bufferString.append (a_element.getTagName());
		if (a_prefixNamespaceUriMap != null) {
			for (Map.Entry <String, String> l_prefixNamespaceUriEntry: a_prefixNamespaceUriMap.entrySet ()) {
				l_bufferString.append (" xmlns");
				l_prefix = l_prefixNamespaceUriEntry.getKey ();
				if (l_prefix != null) {
					l_bufferString.append (":");
					l_bufferString.append (l_prefix);
				}
				l_bufferString.append ("=\"");
				l_bufferString.append (l_prefixNamespaceUriEntry.getValue ());
				l_bufferString.append ("\"");
			}
		}
		l_attributes = a_element.getAttributes ();
		if (l_attributes != null) {
			for (int l_index = 0; l_index < l_attributes.getLength (); l_index ++) {
				l_attribute = (Attr) l_attributes.item (l_index);
				l_bufferString.append (" ");
				l_bufferString.append (l_attribute.getName ());
				l_bufferString.append ("=\"");
				l_bufferString.append (XmlDatumHandler.getEscapedXmlText (l_attribute.getValue ()));
				l_bufferString.append ("\"");
			}
		}
		l_bufferString.append (">");
		return l_bufferString.toString ();
	}
	
	public static String getElementCloseString (Element a_element) {
		StringBuilder l_bufferString = new StringBuilder ();
		l_bufferString.append ("</");
		l_bufferString.append (a_element.getTagName());
		l_bufferString.append (">");
		return l_bufferString.toString ();
	}
	
	public static void transform (Reader a_originalDataReader, Reader a_styleSheetReader, Writer a_transformedDataWriter, Map <String, Object> a_parametersMap) throws IOException, TransformerException {
		TransformerFactory l_transformersFactory = TransformerFactory.newInstance ();
		Transformer l_transformer = l_transformersFactory.newTransformer (new StreamSource (a_styleSheetReader));
		if (a_parametersMap != null) {
			for (Map.Entry <String, Object> l_parametersMapEntry: a_parametersMap.entrySet ()) {
				l_transformer.setParameter (l_parametersMapEntry.getKey (), l_parametersMapEntry.getValue ());
			}
		}
		l_transformer.transform (new StreamSource (a_originalDataReader), new StreamResult (a_transformedDataWriter));
	}
	
	public static void transform (String a_sourceFileName, String a_styleSheetFileName, String a_outputFileName, Map <String, Object> a_xsltParametersMap, boolean a_replace) throws FileNotFoundException, IOException, UnsupportedEncodingException, TransformerException, FileAlreadyExistsException {
		BufferedReader l_originalDataReader = new BufferedReader (new Utf8BomIgnoringInputStreamReader (new InputStreamReader (new FileInputStream (new File (a_sourceFileName)), CharactersSetNamesConstantsGroup.c_utf8CharactersSetName)));
		transform (l_originalDataReader, a_styleSheetFileName, a_outputFileName, a_xsltParametersMap, a_replace);
		l_originalDataReader.close ();
	}
	
	public static void transform (Reader a_originalDataReader, String a_styleSheetFileName, String a_outputFileName, Map <String, Object> a_xsltParametersMap, boolean a_replace) throws FileNotFoundException, IOException, UnsupportedEncodingException, TransformerException {
		BufferedReader l_styleSheetReader = new BufferedReader (new InputStreamReader (new FileInputStream (new File (a_styleSheetFileName)), CharactersSetNamesConstantsGroup.c_utf8CharactersSetName));
		Path l_outputFile = Paths.get (a_outputFileName);
		if (!a_replace && Files.exists (l_outputFile)) {
			throw new FileAlreadyExistsException (a_outputFileName);
		}
		FilesHandler.createDirectoryIfNecessary (l_outputFile);
		OutputStreamWriter l_outputStreamWriter = new OutputStreamWriter (new FileOutputStream (l_outputFile.toFile ()), CharactersSetNamesConstantsGroup.c_utf8CharactersSetName);
		XmlDatumHandler.transform (a_originalDataReader, l_styleSheetReader, l_outputStreamWriter, a_xsltParametersMap);
		l_outputStreamWriter.close ();
		l_styleSheetReader.close ();
	}
	
	public static StringRange getXmlChunk (String a_xmlString, int a_offset) {
		String l_anyTagStart1 = "<";
		String l_anyTagStart2 = ">";
		String l_pTagStart1 = "<p";
		String l_pTagStart2 = ">";
		String l_pTagEnd = "</p>";
		String l_titleTagStart1 = "<title";
		String l_titleTagStart2 = ">";
		String l_titleTagEnd = "</title>";
		String l_liTagStart1 = "<li";
		String l_liTagStart2 = ">";
		String l_liTagEnd = "</li>";
		String l_foundTagStart1 = null;
		String l_foundTagStart2 = null;
		String l_foundTagEnd = null;
		String l_doubleQuotation = "\"";
		int l_foundAnyTagStart1Index = -1;
		int l_foundAnyTagStart2Index = -1;
		int l_foundPTagStart1Index = -1;
		int l_foundTitleTagStart1Index = -1;
		int l_foundLiTagStart1Index = -1;
		int l_foundTagStart1Index = -1;
		int l_foundTagStart2Index = -1;
		int l_foundTagEndIndex = -1;
		int l_foundDoubleQuotationStartIndex = -1;
		int l_foundDoubleQuotationEndIndex = -1;
		int l_searchMode = -1; // 1 -> normally inside a tag contents, 2 -> inside an attribute, 3 -> inside a tag contents, but there in no complete tag start, 4 -> in a plain text
		StringRange l_foundStringRange = null;
		
		l_foundAnyTagStart2Index = a_xmlString.lastIndexOf (l_anyTagStart2, a_offset);
		l_foundAnyTagStart1Index = a_xmlString.lastIndexOf (l_anyTagStart1, a_offset);
		if (l_foundAnyTagStart2Index >= 0) {
			if (l_foundAnyTagStart1Index >= 0) {
				if (l_foundAnyTagStart1Index > l_foundAnyTagStart2Index) {
					// inside an attribute
					l_searchMode = 2;
				}
				else {
					// normally inside a tag contents
					l_searchMode = 1;
				}
			}
			else {
				// inside a tag contents, but there in no complete tag start
				l_searchMode = 3;
			}
		}
		else {
			if (l_foundAnyTagStart1Index >= 0) {
				// inside an attribute
				l_searchMode = 2;
			}
			else {
				// in a plain text
				l_searchMode = 4;
			}
		}
		switch (l_searchMode) {
			case 1:
				l_foundPTagStart1Index = a_xmlString.lastIndexOf (l_pTagStart1, a_offset);
				l_foundTitleTagStart1Index = a_xmlString.lastIndexOf (l_titleTagStart1, a_offset);
				l_foundLiTagStart1Index = a_xmlString.lastIndexOf (l_liTagStart1, a_offset);
				l_foundTagStart1Index = Math.max (l_foundPTagStart1Index, Math.max (l_foundTitleTagStart1Index, l_foundLiTagStart1Index));
				if (l_foundTagStart1Index >= 0) {
					if (l_foundTagStart1Index == l_foundPTagStart1Index) {
						l_foundTagStart1 = l_pTagStart1;
						l_foundTagStart2 = l_pTagStart2;
						l_foundTagEnd = l_pTagEnd;
					}
					if (l_foundTagStart1Index == l_foundTitleTagStart1Index) {
						l_foundTagStart1 = l_titleTagStart1;
						l_foundTagStart2 = l_titleTagStart2;
						l_foundTagEnd = l_titleTagEnd;
					}
					if (l_foundTagStart1Index == l_foundLiTagStart1Index) {
						l_foundTagStart1 = l_liTagStart1;
						l_foundTagStart2 = l_liTagStart2;
						l_foundTagEnd = l_liTagEnd;
					}
					l_foundTagStart2Index = a_xmlString.indexOf (l_foundTagStart2, l_foundTagStart1Index + l_foundTagStart1.length ());
					if (l_foundTagStart2Index >= 0 && l_foundTagStart2Index < a_offset) {
						// tag  start found
						l_foundTagEndIndex = a_xmlString.indexOf (l_foundTagEnd, a_offset);
						if (l_foundTagEndIndex >= 0) {
							// found
							l_foundStringRange = new StringRange (l_foundTagStart2Index + l_foundTagStart2.length (), l_foundTagEndIndex - 1);
						}
						else {
							// tag end not found
						}
					}
					else {
						// tag start not found
					}
				}
				else {
					// tag not found
				}
				break;
			case 2:
				l_foundDoubleQuotationStartIndex = a_xmlString.lastIndexOf (l_doubleQuotation, a_offset);
				if (l_foundDoubleQuotationStartIndex >= 0 && l_foundDoubleQuotationStartIndex > l_foundAnyTagStart2Index) {
					// the attribute start found
					l_foundDoubleQuotationEndIndex = a_xmlString.indexOf (l_doubleQuotation, a_offset);
					if (l_foundDoubleQuotationEndIndex > 0) {
						// found
						l_foundStringRange = new StringRange (l_foundDoubleQuotationStartIndex + l_doubleQuotation.length (), l_foundDoubleQuotationEndIndex - 1);
					}
					else {
						// the attribute end not found
					}
				}
				else {
					// the attribute start not found
				}
				break;
			case 3:
				break;
			case 4:
				break;
		}
		return l_foundStringRange;
	}
	
	// return: >= 0xd800 && <= 0xdbff -> the first part of a surrogate code
	public static int decodeNumericCharacterReference (String a_numericCharacterReferenceString) throws NumberFormatException {
		int l_digitBase = 10;
		int l_digitOffset = 0;
		if (a_numericCharacterReferenceString.substring (2, 3).equals ("x")) {
			l_digitBase = 16;
			l_digitOffset = 1;
		}
		int l_characterCode1 = Integer.parseInt (a_numericCharacterReferenceString.substring (2 + l_digitOffset, a_numericCharacterReferenceString.length () - 1), l_digitBase);
		return l_characterCode1;
	}
	
	public static String decodeNumericCharacterReference (int a_characterCode1, String a_numericCharacterReferenceString) throws NumberFormatException {
		int l_characterCode = -1;
		if (a_characterCode1 >= 0xd800 && a_characterCode1 <= 0xdbff) {
			int l_digitBase = 10;
			int l_digitOffset = 0;
			if (a_numericCharacterReferenceString.substring (2, 3).equals ("x")) {
				l_digitBase = 16;
				l_digitOffset = 1;
			}
			int l_characterCode2 = Integer.parseInt (a_numericCharacterReferenceString.substring (2 + l_digitOffset, a_numericCharacterReferenceString.length () - 1), l_digitBase);
			if (l_characterCode2 >= 0xdc00 && l_characterCode2 <= 0xdfff) {
				l_characterCode = 0x10000 + ( ( (a_characterCode1 - 0xd800) << 10) | (l_characterCode2 - 0xdc00));
			}
			else {
				l_characterCode = a_characterCode1;
			}
		}
		else {
			l_characterCode = a_characterCode1;
		}
		return String.valueOf (Character.toChars (l_characterCode));
	}
}

