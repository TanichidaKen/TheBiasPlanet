namespace theBiasPlanet {
	namespace coreUtilities {
		namespace jsonDataHandling {
			using System;
			using System.IO;
			using System.Text;
			using System.Text.RegularExpressions;
			using System.Threading;
			using theBiasPlanet.coreUtilities.constantsGroups;
			using theBiasPlanet.coreUtilities.inputs;
			using theBiasPlanet.coreUtilities.inputsHandling;
			using theBiasPlanet.coreUtilities.messagingHandling;
			using theBiasPlanet.coreUtilities.pipes;
			
			public sealed class ExtendedJsonDatumParser {
				private const Int32 c_bufferSize = 1024;
				private static readonly Char c_notANumberExpressionOpener = GeneralConstantsConstantsGroup.c_notANumberExpression [GeneralConstantsConstantsGroup.c_iterationStartNumber];
				private static readonly Char c_positiveInfinityExpressionOpener = GeneralConstantsConstantsGroup.c_positiveInfinityExpression [GeneralConstantsConstantsGroup.c_iterationStartNumber];
				private static readonly Char c_negativeInfinityExpressionOpener = GeneralConstantsConstantsGroup.c_negativeInfinityExpression [GeneralConstantsConstantsGroup.c_iterationStartNumber];
				private static readonly Char c_nullExpressionOpener = GeneralConstantsConstantsGroup.c_nullExpression [GeneralConstantsConstantsGroup.c_iterationStartNumber];
				private static readonly Char c_trueExpressionOpener = GeneralConstantsConstantsGroup.c_trueExpression [GeneralConstantsConstantsGroup.c_iterationStartNumber];
				private static readonly Char c_falseExpressionOpener = GeneralConstantsConstantsGroup.c_falseExpression [GeneralConstantsConstantsGroup.c_iterationStartNumber];
				private const String c_exceptionMessageFormattingExpression = "character position: %d";
				private PushableReader i_extendedJsonDatumReader = null;
				private ExtendedJsonDatumParseEventsHandler i_parseEventsHandler = null;
				private Char [] i_characters = new Char [c_bufferSize];
				private long i_characterPositionIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
				
				public ExtendedJsonDatumParser () {
				}
				
				// return: true: An item has been found, false: No item has been found
				private Boolean parseNextItem () {
					Int32 l_readFunctionReturn = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
					Int32 l_toReadLength = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
					Int32 l_readLength = 0;
					l_toReadLength = 1;
					l_readFunctionReturn = i_extendedJsonDatumReader.ReadBlock (i_characters, l_readLength, l_toReadLength);
					if (l_readFunctionReturn < l_toReadLength) {
						return false;
					}
					l_readLength += l_readFunctionReturn;
					i_characterPositionIndex += l_readFunctionReturn;
					MatchCollection l_matches = null;
					String l_itemValue = null;
					String l_readData = null;
					if (i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_doubleQuotationMarkCharacter) {
						parseString ();
						return true;
					}
					else if (i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_jsonDictionaryOpener) {
						parseDictionary ();
						return true;
					}
					else if (i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_jsonArrayOpener) {
						parseArray ();
						return true;
					}
					else if (i_characters [l_readLength - 1] == c_nullExpressionOpener || i_characters [l_readLength - 1] == c_trueExpressionOpener || i_characters [l_readLength - 1] == c_falseExpressionOpener || i_characters [l_readLength - 1] == c_notANumberExpressionOpener || i_characters [l_readLength - 1] == c_positiveInfinityExpressionOpener) {
						if (i_characters [l_readLength - 1] == c_nullExpressionOpener) {
							l_itemValue = GeneralConstantsConstantsGroup.c_nullExpression;
						}
						else if (i_characters [l_readLength - 1] == c_trueExpressionOpener) {
							l_itemValue = GeneralConstantsConstantsGroup.c_trueExpression;
						}
						else if (i_characters [l_readLength - 1] == c_falseExpressionOpener) {
							l_itemValue = GeneralConstantsConstantsGroup.c_falseExpression;
						}
						else if (i_characters [l_readLength - 1] == c_notANumberExpressionOpener) {
							l_itemValue = GeneralConstantsConstantsGroup.c_notANumberExpression;
						}
						else if (i_characters [l_readLength - 1] == c_positiveInfinityExpressionOpener) {
							l_itemValue = GeneralConstantsConstantsGroup.c_positiveInfinityExpression;
						}
						l_toReadLength = l_itemValue.Length - 1;
						l_readFunctionReturn = i_extendedJsonDatumReader.ReadBlock (i_characters, l_readLength, l_toReadLength);
						if (l_readFunctionReturn < l_toReadLength) {
							throw new UnsupportedValueException (String.Format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
						}
						l_readLength += l_readFunctionReturn;
						i_characterPositionIndex += l_readFunctionReturn;
						if (l_itemValue == new String (i_characters, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength)) {
							if (i_characters [GeneralConstantsConstantsGroup.c_iterationStartNumber] == c_nullExpressionOpener) {
								if (! (i_parseEventsHandler.onNullFound ())) {
									throw new TerminatedException ("");
								}
								return true;
							}
							else if (i_characters [GeneralConstantsConstantsGroup.c_iterationStartNumber] == c_trueExpressionOpener || i_characters [GeneralConstantsConstantsGroup.c_iterationStartNumber] == c_falseExpressionOpener) {
								if (! (i_parseEventsHandler.onBooleanFound (Boolean.Parse (l_itemValue)))) {
									throw new TerminatedException ("");
								}
								return true;
							}
							else if (i_characters [GeneralConstantsConstantsGroup.c_iterationStartNumber] == c_notANumberExpressionOpener) {
								if (! (i_parseEventsHandler.onDoubleFound (Double.NaN))) {
									throw new TerminatedException ("");
								}
								return true;
							}
							else if (i_characters [GeneralConstantsConstantsGroup.c_iterationStartNumber] == c_positiveInfinityExpressionOpener) {
								if (! (i_parseEventsHandler.onDoubleFound (Double.PositiveInfinity))) {
									throw new TerminatedException ("");
								}
								return true;
							}
						}
						else {
							throw new UnsupportedValueException (String.Format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
						}
					}
					else if (i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_jsonDateEtcOpener) {
						l_readLength = 0;
						l_toReadLength = 8;
						l_readFunctionReturn = i_extendedJsonDatumReader.ReadBlock (i_characters, l_readLength, l_toReadLength);
						if (l_readFunctionReturn < l_toReadLength) {
							throw new UnsupportedValueException (String.Format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
						}
						l_readLength += l_readFunctionReturn;
						i_characterPositionIndex += l_readFunctionReturn;
						l_readData = new String (i_characters, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength);
						l_matches = RegularExpressionsConstantsGroup.c_timesRegularExpression.Matches (l_readData);
						foreach (Match l_match in l_matches) {
							if (! (i_parseEventsHandler.onLocalTimeFound (DateTime.Parse (l_readData, System.Globalization.CultureInfo.InvariantCulture)))) {
								throw new TerminatedException ("");
							}
							return true;
						}
						l_toReadLength = 3;
						l_readFunctionReturn = i_extendedJsonDatumReader.ReadBlock (i_characters, l_readLength, l_toReadLength);
						if (l_readFunctionReturn < l_toReadLength - 1) {
							throw new UnsupportedValueException (String.Format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
						}
						if (l_readFunctionReturn == l_toReadLength && i_characters [l_readLength + l_readFunctionReturn - 1] != GeneralConstantsConstantsGroup.c_jsonDateAndTimeTimePartOpener) {
							i_extendedJsonDatumReader.pushData (i_characters, l_readLength + l_readFunctionReturn - 1, 1);
							l_readLength += (l_readFunctionReturn - 1);
							i_characterPositionIndex += (l_readFunctionReturn - 1);
							l_readData = new String (i_characters, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength);
							l_matches = RegularExpressionsConstantsGroup.c_datesRegularExpression.Matches (l_readData);
							foreach (Match l_match in l_matches) {
								if (! (i_parseEventsHandler.onLocalDateFound (DateTime.Parse (l_readData, System.Globalization.CultureInfo.InvariantCulture)))) {
									throw new TerminatedException ("");
								}
								return true;
							}
							throw new UnsupportedValueException (String.Format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
						}
						else {
							l_readLength += l_readFunctionReturn;
							i_characterPositionIndex += l_readFunctionReturn;
							l_toReadLength = 9;
							l_readFunctionReturn = i_extendedJsonDatumReader.ReadBlock (i_characters, l_readLength, l_toReadLength);
							if (l_readFunctionReturn < l_toReadLength - 1) {
								throw new UnsupportedValueException (String.Format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
							}
							if (l_readFunctionReturn == l_toReadLength && i_characters [l_readLength + l_readFunctionReturn - 1] != GeneralConstantsConstantsGroup.c_radixPointCharacter) {
								i_extendedJsonDatumReader.pushData (i_characters, l_readLength + l_readFunctionReturn - 1, 1);
								l_readLength += (l_readFunctionReturn - 1);
								i_characterPositionIndex += (l_readFunctionReturn - 1);
							}
							else {
								l_readLength += l_readFunctionReturn;
								i_characterPositionIndex += l_readFunctionReturn;
								if (l_readFunctionReturn == l_toReadLength) {
									l_toReadLength = 1;
									while ((l_readFunctionReturn = i_extendedJsonDatumReader.ReadBlock (i_characters, l_readLength, l_toReadLength)) != 0) {
										if (i_characters [l_readLength] >= GeneralConstantsConstantsGroup.c_minimumDigit && i_characters [l_readLength] <= GeneralConstantsConstantsGroup.c_maximumDigit) {
											l_readLength += l_readFunctionReturn;
											i_characterPositionIndex += l_readFunctionReturn;
										}
										else {
											i_extendedJsonDatumReader.pushData (i_characters, l_readLength - 1, 1);
											break;
										}
									}
								}
							}
							l_readData = new String (i_characters, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength);
							l_matches = RegularExpressionsConstantsGroup.c_dateAndTimesRegularExpression.Matches (l_readData);
							foreach (Match l_match in l_matches) {
								if (! (i_parseEventsHandler.onLocalDateAndTimeFound (DateTime.Parse (l_readData, System.Globalization.CultureInfo.InvariantCulture)))) {
									throw new TerminatedException ("");
								}
								return true;
							}
							throw new UnsupportedValueException (String.Format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
						}
					}
					else if (i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_jsonBytesArrayOpener) {
						l_readLength = 0;
						l_toReadLength = 1;
						l_readFunctionReturn = i_extendedJsonDatumReader.ReadBlock (i_characters, l_readLength, l_toReadLength);
						if (l_readFunctionReturn < l_toReadLength) {
							throw new UnsupportedValueException (String.Format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
						}
						l_readLength += l_readFunctionReturn;
						i_characterPositionIndex += l_readFunctionReturn;
						if (i_characters [l_readLength - 1] != GeneralConstantsConstantsGroup.c_doubleQuotationMarkCharacter) {
							throw new UnsupportedValueException (String.Format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
						}
						StringPipe l_stringPipe = new StringPipe (ExtendedJsonDatumParser.c_bufferSize, true);
						
						try {
							Thread l_subThread = new Thread (() => {
								try {
									if (! (i_parseEventsHandler.onBytesArrayFound (l_stringPipe))) {
										throw new TerminatedException ("");
									}
								}
								catch (Exception l_exception) {
									Console.Out.WriteLine (l_exception.StackTrace);
								}
							});
							l_subThread.Start ();
							l_readLength = 0;
							l_toReadLength = 1;
							while ((l_readFunctionReturn = i_extendedJsonDatumReader.ReadBlock (i_characters, l_readLength, l_toReadLength)) != 0) {
								i_characterPositionIndex += l_readFunctionReturn;
								if (i_characters [l_readLength] == GeneralConstantsConstantsGroup.c_doubleQuotationMarkCharacter) {
									if (l_readLength > 0) {
										l_stringPipe.write (i_characters, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength);
									}
									l_stringPipe.finishWriting ();
									l_subThread.Join ();
									return true;
								}
								else {
									l_readLength += l_readFunctionReturn;
									if (l_readLength == 4) {
										l_stringPipe.write (i_characters, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength);
										l_readLength = 0;
									}
								}
							}
							if (l_readFunctionReturn == GeneralConstantsConstantsGroup.c_unspecifiedInteger) {
								l_stringPipe.finishWriting ();
								throw new UnsupportedValueException (String.Format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
							}
						}
						finally {
							l_stringPipe.finishWriting ();
						}
					}
					else if ((i_characters [l_readLength - 1] >= GeneralConstantsConstantsGroup.c_minimumDigit && i_characters [l_readLength - 1] <= GeneralConstantsConstantsGroup.c_maximumDigit) || i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_plusCharacter || i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_minusCharacter) {
						l_readLength = 1;
						l_toReadLength = 1;
						if (i_characters [l_readLength - 1] == c_negativeInfinityExpressionOpener) {
							l_readFunctionReturn = i_extendedJsonDatumReader.ReadBlock (i_characters, l_readLength, l_toReadLength);
							if (l_readFunctionReturn < l_toReadLength) {
								throw new UnsupportedValueException (String.Format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
							}
							l_readLength += l_readFunctionReturn;
							i_characterPositionIndex += l_readFunctionReturn;
							if (i_characters [l_readLength - 1] == c_positiveInfinityExpressionOpener) {
								l_toReadLength = 7;
								l_readFunctionReturn = i_extendedJsonDatumReader.ReadBlock (i_characters, l_readLength, l_toReadLength);
								if (l_readFunctionReturn < l_toReadLength) {
									throw new UnsupportedValueException (String.Format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
								}
								l_readLength += l_readFunctionReturn;
								i_characterPositionIndex += l_readFunctionReturn;
								l_readData = new String (i_characters, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength);
								if (GeneralConstantsConstantsGroup.c_negativeInfinityExpression == l_readData) {
									if (! (i_parseEventsHandler.onDoubleFound (Double.NegativeInfinity))) {
										throw new TerminatedException ("");
									}
									return true;
								}
							}
						}
						while ((l_readFunctionReturn = i_extendedJsonDatumReader.ReadBlock (i_characters, l_readLength, l_toReadLength)) != 0) {
							if ((i_characters [l_readLength] >= GeneralConstantsConstantsGroup.c_minimumDigit && i_characters [l_readLength] <= GeneralConstantsConstantsGroup.c_maximumDigit) || i_characters [l_readLength] == GeneralConstantsConstantsGroup.c_radixPointCharacter || i_characters [l_readLength] == GeneralConstantsConstantsGroup.c_exponentOpener1 || i_characters [l_readLength] == GeneralConstantsConstantsGroup.c_exponentOpener2 || i_characters [l_readLength] == GeneralConstantsConstantsGroup.c_plusCharacter || i_characters [l_readLength] == GeneralConstantsConstantsGroup.c_minusCharacter) {
								l_readLength += l_readFunctionReturn;
								i_characterPositionIndex += l_readFunctionReturn;
							}
							else {
								i_extendedJsonDatumReader.pushData (i_characters, l_readLength, 1);
								break;
							}
						}
						l_readData = new String (i_characters, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength);
						l_matches = RegularExpressionsConstantsGroup.c_numbersRegularExpression.Matches (l_readData);
						foreach (Match l_match in l_matches) {
							String l_integerPart = l_match.Groups [1].Value;
							String l_fractionPart = l_match.Groups [2].Value;
							String l_exponentPart = l_match.Groups [3].Value;
							if (l_fractionPart != "" || l_exponentPart != "") {
								if (! (i_parseEventsHandler.onDoubleFound (Double.Parse (l_integerPart + l_fractionPart + l_exponentPart, System.Globalization.CultureInfo.InvariantCulture)))) {
									throw new TerminatedException ("");
								}
								return true;
							}
							else {
								if (! (i_parseEventsHandler.onIntegerFound (Int32.Parse (l_integerPart, System.Globalization.CultureInfo.InvariantCulture)))) {
									throw new TerminatedException ("");
								}
								return true;
							}
						}
						throw new UnsupportedValueException (String.Format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
					}
					else if (i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_jsonArrayCloser || i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_jsonDictionaryCloser) {
						i_extendedJsonDatumReader.pushData (i_characters, l_readLength - 1, 1);
						return false;
					}
					else {
						throw new UnsupportedValueException (String.Format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
					}
					return false;
				}
				
				private Boolean parseString () {
					Int32 l_readFunctionReturn = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
					Int32 l_toReadLength = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
					Int32 l_readLength = 0;
					Int32 l_stringChunkTerminator= GeneralConstantsConstantsGroup.c_unspecifiedInteger;
					Char l_originalCharacterOfEscapedCharacter;
					StringPipe l_stringPipe = new StringPipe (ExtendedJsonDatumParser.c_bufferSize, true);
					try {
						Boolean [] l_onStringFoundReturn = {false};
						Thread l_subThread = new Thread (() => {
							try {
								l_onStringFoundReturn [GeneralConstantsConstantsGroup.c_iterationStartNumber] = i_parseEventsHandler.onStringFound (l_stringPipe);
							}
							catch (Exception l_exception) {
								Console.Out.WriteLine (l_exception.StackTrace);
							}
						});
						l_subThread.Start ();
						while (true) {
							l_readLength = 0;
							l_toReadLength = 1;
							// reading a chunk of the string, not the whole string
							while ((l_readFunctionReturn = i_extendedJsonDatumReader.ReadBlock (i_characters, l_readLength, l_toReadLength)) != 0) {
								if (l_readFunctionReturn < l_toReadLength) {
									throw new UnsupportedValueException (String.Format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
								}
								l_readLength += l_readFunctionReturn;
								i_characterPositionIndex += l_readFunctionReturn;
								// '\x00' ~ '\x1f' are control characters that must have been escaped
								if (i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_doubleQuotationMarkCharacter || i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_escapingCharacter || (i_characters [l_readLength - 1] >= GeneralConstantsConstantsGroup.c_controlCharactersStart && i_characters [l_readLength - 1] < GeneralConstantsConstantsGroup.c_controlCharactersUntil)) {
									l_stringChunkTerminator = i_characters [l_readLength - 1];
									break;
								}
								else {
									try {
										//System.out.print (new String (i_characters, 0, l_readLength));
										l_stringPipe.write (i_characters, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength);
									}
									catch (Exception l_exception) {
										Publisher.logWarningInformation (l_exception);
									}
								}
								l_readLength = 0;
							}
							if (l_stringChunkTerminator == GeneralConstantsConstantsGroup.c_doubleQuotationMarkCharacter) {
								l_stringPipe.finishWriting ();
								l_subThread.Join ();
								if (!l_onStringFoundReturn [GeneralConstantsConstantsGroup.c_iterationStartNumber]) {
									throw new TerminatedException ("");
								}
								return true;
							}
							else if (l_stringChunkTerminator != GeneralConstantsConstantsGroup.c_escapingCharacter) {
								throw new UnsupportedValueException (String.Format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
							}
							l_toReadLength = 1;
							l_readFunctionReturn = i_extendedJsonDatumReader.ReadBlock (i_characters, l_readLength, l_toReadLength);
							if (l_readFunctionReturn < l_toReadLength) {
								throw new UnsupportedValueException (String.Format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
							}
							l_readLength += l_readFunctionReturn;
							i_characterPositionIndex += l_readFunctionReturn;
							if (i_characters [l_readLength - 1] != GeneralConstantsConstantsGroup.c_unicodeEscapeIndicator) {
								try {
									l_originalCharacterOfEscapedCharacter = GeneralConstantsConstantsGroup.c_escapedCharacterToCharacterMap [new String (i_characters, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength)];
								}
								catch (Exception){
									throw new UnsupportedValueException (String.Format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
								}
							}
							else {
								l_originalCharacterOfEscapedCharacter = decodeUnicodeEscape ();
							}
							try {
								l_stringPipe.write (l_originalCharacterOfEscapedCharacter);
							}
							catch (Exception l_exception) {
								Publisher.logWarningInformation (l_exception);
							}
						}
					}
					finally {
						l_stringPipe.finishWriting ();
					}
				}
				
				private Char decodeUnicodeEscape () {
					try {
						Int32 l_readFunctionReturn = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
						Int32 l_readLength = 0;
						Int32 l_toReadLength = 4;
						l_readFunctionReturn = i_extendedJsonDatumReader.ReadBlock (i_characters, l_readLength, l_toReadLength);
						if (l_readFunctionReturn < l_toReadLength) {
							throw new UnsupportedValueException (String.Format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
						}
						l_readLength += l_readFunctionReturn;
						i_characterPositionIndex += l_readFunctionReturn;
						return (Char) Int32.Parse (new String (i_characters, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength), System.Globalization.NumberStyles.HexNumber);
					}
					catch (Exception) {
						throw new UnsupportedValueException (String.Format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
					}
				}
				
				private void skipWhiteSpaces () {
					Int32 l_readFunctionReturn = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
					Int32 l_readLength = 0;
					Int32 l_toReadLength = 1;
					while ((l_readFunctionReturn = i_extendedJsonDatumReader.ReadBlock (i_characters, l_readLength, l_toReadLength)) != 0) {
						l_readLength += l_readFunctionReturn;
						i_characterPositionIndex += l_readFunctionReturn;
						if (i_characters [l_readLength - 1] != GeneralConstantsConstantsGroup.c_spaceCharacter && i_characters [l_readLength - 1] != GeneralConstantsConstantsGroup.c_tabCharacter && i_characters [l_readLength - 1] != GeneralConstantsConstantsGroup.c_newLineCharacter && i_characters [l_readLength - 1] != GeneralConstantsConstantsGroup.c_carriageReturnCharacter) {
							i_extendedJsonDatumReader.pushData (i_characters, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength);
							break;
						}
						l_readLength = 0;
					}
					return;
				}
				
				private Boolean parseArray () {
					Int32 l_readFunctionReturn = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
					Int32 l_toReadLength = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
					Int32 l_readLength = 0;
					if (! (i_parseEventsHandler.onArrayStarted ())) {
						throw new TerminatedException ("");
					}
					Boolean l_itemFound = false;
					while (true) {
						skipWhiteSpaces ();
						l_itemFound = parseNextItem ();
						skipWhiteSpaces ();
						l_readLength = 0;
						l_toReadLength = 1;
						l_readFunctionReturn = i_extendedJsonDatumReader.ReadBlock (i_characters, l_readLength, l_toReadLength);
						if (l_readFunctionReturn < l_toReadLength) {
							throw new UnsupportedValueException (String.Format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
						}
						l_readLength += l_readFunctionReturn;
						i_characterPositionIndex += l_readFunctionReturn;
						if (i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_jsonArrayCloser) {
							if (! (i_parseEventsHandler.onArrayEnded ())) {
								throw new TerminatedException ("");
							}
							skipWhiteSpaces ();
							return true;
						}
						else if (i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_jsonItemsSeparatorOpener) {
							if (!l_itemFound) {
								throw new UnsupportedValueException (String.Format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
							}
						}
						else {
							throw new UnsupportedValueException (String.Format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
						}
					}
				}
				
				private Boolean parseDictionary () {
					if (! (i_parseEventsHandler.onDictionaryStarted ())) {
						throw new TerminatedException ("");
					}
					Int32 l_readFunctionReturn = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
					Int32 l_toReadLength = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
					Int32 l_readLength = 0;
					Boolean l_itemFound = false;
					while (true) {
						skipWhiteSpaces ();
						l_itemFound = parseNextItem ();
						if (l_itemFound) {
							skipWhiteSpaces ();
							l_readLength = 0;
							l_toReadLength = 1;
							l_readFunctionReturn = i_extendedJsonDatumReader.ReadBlock (i_characters, l_readLength, l_toReadLength);
							if (l_readFunctionReturn < l_toReadLength) {
								throw new UnsupportedValueException (String.Format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
							}
							l_readLength += l_readFunctionReturn;
							i_characterPositionIndex += l_readFunctionReturn;
							if (i_characters [l_readLength - 1] != ':') {
								throw new UnsupportedValueException (String.Format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
							}
							skipWhiteSpaces ();
							l_itemFound = parseNextItem ();
							if (!l_itemFound) {
								throw new UnsupportedValueException (String.Format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
							}
							skipWhiteSpaces ();
						}
						l_readLength = 0;
						l_toReadLength = 1;
						l_readFunctionReturn = i_extendedJsonDatumReader.ReadBlock (i_characters, l_readLength, l_toReadLength);
						if (l_readFunctionReturn < l_toReadLength) {
							throw new UnsupportedValueException (String.Format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
						}
						l_readLength += l_readFunctionReturn;
						i_characterPositionIndex += l_readFunctionReturn;
						if (i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_jsonDictionaryCloser) {
							if (! (i_parseEventsHandler.onDictionaryEnded ())) {
								throw new TerminatedException ("");
							}
							skipWhiteSpaces ();
							return true;
						}
						else if (i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_jsonItemsSeparatorOpener) {
							if (!l_itemFound) {
								throw new UnsupportedValueException (String.Format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
							}
						}
						else {
							throw new UnsupportedValueException (String.Format (c_exceptionMessageFormattingExpression, i_characterPositionIndex));
						}
					}
				}
				
				// return: true: An item has been found, false: No item has been found
				public Boolean parse (TextReader a_extendedJsonDatumReader, ExtendedJsonDatumParseEventsHandler a_parseEventsHandler) {
					i_extendedJsonDatumReader = new PushableReader (a_extendedJsonDatumReader, c_bufferSize);
					i_parseEventsHandler = a_parseEventsHandler;
					i_parseEventsHandler.initialize ();
					i_characterPositionIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
					try {
						return parseNextItem ();
					}
					catch (Exception l_exception) {
						try {
							i_parseEventsHandler.onException (l_exception);
						}
						catch (Exception l_exceptionOfInnerTry) {
							Publisher.logErrorInformation (l_exceptionOfInnerTry);
						}
						throw l_exception;
					}
				}
			}
		}
	}
}

