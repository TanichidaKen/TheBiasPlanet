namespace theBiasPlanet {
	namespace coreUtilities {
		namespace jsonDataHandling {
			using System;
			
			public class UnsupportedClassException : Exception {
				public UnsupportedClassException (String a_message) : base (a_message) {
				}
			}
		}
	}
}


