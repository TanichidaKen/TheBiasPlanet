namespace theBiasPlanet {
	namespace coreUtilities {
		namespace reflectionHandling {
			using System;
			using System.Text;
			
			public class ClassAnalyzer {
				private ClassAnalyzer () {
				}
				
				public static String getHierarchyExpression (Type a_class) {
					StringBuilder l_hierarchyExpression = new StringBuilder ("");
					l_hierarchyExpression.Append (a_class);
					l_hierarchyExpression.Append (getInterfacesExpression (a_class));
					Type l_baseClass = null;
					Type l_superClass = null;
					l_baseClass = a_class;
					for (;;) {
						l_superClass = l_baseClass.BaseType;
						l_hierarchyExpression.Append ("-> ");
						l_hierarchyExpression.Append (l_superClass);
						l_hierarchyExpression.Append (getInterfacesExpression (l_superClass));
						if (l_superClass == typeof (Object)) {
							break;
						}
						l_baseClass = l_superClass;
					}
					return l_hierarchyExpression.ToString ();
				}
				
				public static String getSuperClassesExpression (Type a_class) {
					Type l_baseClass = null;
					Type l_superClass = null;
					StringBuilder l_superClassesExpression = new StringBuilder ("");
					l_baseClass = a_class;
					for (;;) {
						l_superClass = l_baseClass.BaseType;
						l_superClassesExpression.Append ("-> ");
						l_superClassesExpression.Append (l_superClass);
						if (l_superClass == typeof (Object)) {
							break;
						}
						l_baseClass = l_superClass;
					}
					return l_superClassesExpression.ToString ();
				}
				
				public static String getInterfacesExpression (Type a_class) {
					Type [] l_interfaces = null;
					StringBuilder l_interfacesExpression = new StringBuilder ("");
					l_interfaces = a_class.GetInterfaces ();
					foreach (Type l_interface in l_interfaces) {
						l_interfacesExpression.Append (": ");
						l_interfacesExpression.Append (l_interface);
					}
					return l_interfacesExpression.ToString ();
				}
			}
		}
	}
}

