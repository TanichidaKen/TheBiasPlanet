namespace theBiasPlanet {
	namespace coreUtilities {
		namespace inputs {
			using System;
			using System.Collections.Generic;
			using System.IO;
			using System.Threading;
			using theBiasPlanet.coreUtilities.constantsGroups;
			using theBiasPlanet.coreUtilities.collections;
			using theBiasPlanet.coreUtilities.inputsHandling;
			using theBiasPlanet.coreUtilities.messagingHandling;
			using theBiasPlanet.coreUtilities.pipes;
			using theBiasPlanet.coreUtilities.timersHandling;
			
			public class HaltableReader {
				TextReader i_underlyingReader;
				private Int32 i_bufferSize;
				private Thread i_dispatchDataThread = null;
				private NavigableLinkedHashMap <String, StringPipe> i_subscriberIdentificationToStringPipeMap = new NavigableLinkedHashMap <String, StringPipe> ();
				private ReaderWriterLockSlim i_sharableLock = new ReaderWriterLockSlim (LockRecursionPolicy.SupportsRecursion);
				
				public HaltableReader (TextReader a_underlyingReader, Int32 a_bufferSize) {
					i_underlyingReader = a_underlyingReader;
					i_bufferSize = a_bufferSize;
				}
				
				// Any subscriber has to read consistently, or the other subscribers may be stuck because the dispatching thread will be stuck waiting to write to the string pipe for the neglecting subscriber.
				public void addSubscriber (String a_subscriberIdentification) {
					try {
						i_sharableLock.EnterWriteLock ();
						i_subscriberIdentificationToStringPipeMap.put (a_subscriberIdentification, new StringPipe (i_bufferSize, false));
					}
					finally {
						i_sharableLock.ExitWriteLock ();
					}
				}
				
				public void removeSubscriber (String a_subscriberIdentification) {
					try {
						i_sharableLock.EnterReadLock ();
						StringPipe l_stringPipe = null;
						try {
							l_stringPipe = i_subscriberIdentificationToStringPipeMap [a_subscriberIdentification];
						}
						catch (KeyNotFoundException) {
						}
						if (l_stringPipe != null) {
							l_stringPipe.finishWriting ();
						}
					}
					finally {
						i_sharableLock.ExitReadLock ();
					}
					try {
						i_sharableLock.EnterWriteLock ();
						i_subscriberIdentificationToStringPipeMap.Remove (a_subscriberIdentification);
					}
					finally {
						i_sharableLock.ExitWriteLock ();
					}
				}
				
				public void startDispatchDataThread () {
					if (i_dispatchDataThread == null) {
						i_dispatchDataThread = new Thread (() => {
							try {
								Int32 l_readFunctionReturn;
								while (true) {
									l_readFunctionReturn = i_underlyingReader.Read ();
									if (l_readFunctionReturn == GeneralConstantsConstantsGroup.c_unspecifiedInteger) {
										break;
									}
									String l_inputDatum = ( (Char) l_readFunctionReturn).ToString ();
									try {
										i_sharableLock.EnterReadLock ();
										foreach (KeyValuePair <String, StringPipe> l_subscriberIdentificationToStringPipeMapEntry in i_subscriberIdentificationToStringPipeMap) {
											l_subscriberIdentificationToStringPipeMapEntry.Value.writeWholeString (new StringReader (l_inputDatum));
										}
									}
									finally {
										i_sharableLock.ExitReadLock ();
									}
								}
							}
							catch (ThreadAbortException) {
							}
							catch (Exception l_exception) {
								Publisher.logErrorInformation (l_exception);
							}
							finally {
								try {
									i_sharableLock.EnterReadLock ();
									foreach (KeyValuePair <String, StringPipe> l_subscriberIdentificationToStringPipeMapEntry in i_subscriberIdentificationToStringPipeMap) {
										l_subscriberIdentificationToStringPipeMapEntry.Value.finishWriting ();
									}
								}
								finally {
									i_sharableLock.ExitReadLock ();
								}
							}
						});
						i_dispatchDataThread.IsBackground = true;
						i_dispatchDataThread.Start ();
					}
				}
				
				public void close () {
					i_underlyingReader.Close ();
				}
				
				public String read (String a_subscriberIdentification, Int32 a_maximumLength, Int32 a_timeOutPeriodInMilliseconds = -1) {
					StringPipe l_stringPipe = null;
					try {
						i_sharableLock.EnterReadLock ();
						try {
							l_stringPipe = i_subscriberIdentificationToStringPipeMap [a_subscriberIdentification];
						}
						catch (KeyNotFoundException) {
						}
					}
					finally {
						i_sharableLock.ExitReadLock ();
					}
					if (l_stringPipe != null) {
						return l_stringPipe.readString (a_maximumLength, a_timeOutPeriodInMilliseconds);
					}
					else {
						throw new NoMoreDataException ("");
					}
				}
				
				public String readLine (String a_subscriberIdentification, Int32 a_maximumLength, Int32 a_timeOutPeriodInMilliseconds = -1) {
					StringPipe l_stringPipe = null;
					try {
						i_sharableLock.EnterReadLock ();
						try {
							l_stringPipe = i_subscriberIdentificationToStringPipeMap [a_subscriberIdentification];
						}
						catch (KeyNotFoundException) {
						}
					}
					finally {
						i_sharableLock.ExitReadLock ();
					}
					if (l_stringPipe != null) {
						return l_stringPipe.readStringLine (a_maximumLength, a_timeOutPeriodInMilliseconds);
					}
					else {
						throw new NoMoreDataException ("");
					}
				}
				
				public Boolean isReady (String a_subscriberIdentification) {
					StringPipe l_stringPipe = null;
					try {
						i_sharableLock.EnterReadLock ();
						try {
							l_stringPipe = i_subscriberIdentificationToStringPipeMap [a_subscriberIdentification];
						}
						catch (KeyNotFoundException) {
						}
					}
					finally {
						i_sharableLock.ExitReadLock ();
					}
					if (l_stringPipe != null) {
						return ! (l_stringPipe.isEmpty ());
					}
					else {
						return false;
					}
				}
			}
		}
	}
}


