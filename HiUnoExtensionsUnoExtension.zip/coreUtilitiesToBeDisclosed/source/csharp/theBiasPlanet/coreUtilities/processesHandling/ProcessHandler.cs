namespace theBiasPlanet {
	namespace coreUtilities {
		namespace processesHandling {
			using System;
			using System.Collections.Generic;
			using System.Diagnostics;
			using System.IO;
			using System.Text;
			using System.Threading;
			using theBiasPlanet.coreUtilities.collections;
			using theBiasPlanet.coreUtilities.constantsGroups;
			using theBiasPlanet.coreUtilities.inputs;
			using theBiasPlanet.coreUtilities.inputsHandling;
			using theBiasPlanet.coreUtilities.messagingHandling;
			using theBiasPlanet.coreUtilities.pipes;
			using theBiasPlanet.coreUtilities.stringsHandling;
			using theBiasPlanet.coreUtilities.timersHandling;
			
			public class ProcessHandler {
				private static HaltableStandardInputReader s_haltableStandardInputReader = HaltableStandardInputReader.getInstance ();
				
				static ProcessHandler () {
					// the dispatch data thread is not started automatically.
					//s_haltableStandardInputReader.startDispatchDataThread ();
				}
				
				private static void interruptRelayStandardInputThread (Thread a_thread) {
					s_haltableStandardInputReader.removeSubscriber (String.Format ("{0:d}", a_thread.ManagedThreadId));
				}
				
				public class StandardInputAndOutputs {
					private Process i_process = null;
					private StreamWriter i_standardInputOutputStream = null;
					private StreamReader i_standardOutputInputStream = null;
					private StreamReader i_standardErrorOutputInputStream = null;
					private Thread i_relayStandardInputThread = null;
					private Thread i_printStandardOutputThread = null;
					private Thread i_printStandardErrorOutputThread = null;
					private Boolean i_thereWereStandardInputContents = false;
					private Boolean i_thereWereStandardOutputContents = false;
					private Boolean i_thereWereStandardErrorOutputContents = false;
					
					public StandardInputAndOutputs (Process a_process) {
						i_process = a_process;
						i_standardInputOutputStream = i_process.StandardInput;
						i_standardOutputInputStream = i_process.StandardOutput;
						i_standardErrorOutputInputStream = i_process.StandardError;
					}
					
					public StreamWriter getStandardInputOutputStream () {
						return i_standardInputOutputStream;
					}
					
					public StreamReader getStandardOutputInputStream () {
						return i_standardOutputInputStream;
					}
					
					public StreamReader getStandardErrorOutputInputStream () {
						return i_standardErrorOutputInputStream;
					}
					
					public void relayStandardInputAsynchronously () {
						i_relayStandardInputThread = new Thread ( () => {
							String l_threadIdentification = String.Format ("{0:d}", Thread.CurrentThread.ManagedThreadId);
							try {
								StreamWriter l_processStandardInputWriter = i_standardInputOutputStream;
								String l_standardInputDatum = null;
								while (true) {
									try {
										l_standardInputDatum = s_haltableStandardInputReader.read (l_threadIdentification, 1);
										i_thereWereStandardInputContents = true;
										l_processStandardInputWriter.Write (l_standardInputDatum);
										l_processStandardInputWriter.Flush ();
									}
									catch (NoMoreDataException) {
										break;
									}
									catch (TimeOutException) {
										// impossible
									}
								}
							}
							catch (ThreadAbortException) {
							}
							catch (IOException l_exception) {
								Publisher.logErrorInformation (String.Format ("### A standard input error: {0}.", l_exception));
							}
						});
						s_haltableStandardInputReader.addSubscriber (String.Format ("{0:d}", i_relayStandardInputThread.ManagedThreadId));
						i_relayStandardInputThread.Start ();
					}
					
					public void printStandardOutputAsynchronously () {
						i_printStandardOutputThread = new Thread ( () => {
							try {
								StreamReader l_standardOutputReader = i_standardOutputInputStream;
								Char [] l_standardOutputData = new Char [DefaultValuesConstantsGroup.c_smallBufferSize];
								Int32 l_standardOutputDataLength = 0;
								while ( (l_standardOutputDataLength = l_standardOutputReader.Read (l_standardOutputData, GeneralConstantsConstantsGroup.c_iterationStartNumber, DefaultValuesConstantsGroup.c_smallBufferSize)) != 0) {
									for (Int32 l_characterIndex = 0; l_characterIndex < l_standardOutputDataLength; l_characterIndex ++) {
										i_thereWereStandardOutputContents = true;
										Console.Out.Write (l_standardOutputData [l_characterIndex]);
										Console.Out.Flush ();
									}
								}
							}
							catch (IOException l_exception) {
								Console.Error.WriteLine (String.Format ("### A child process standard output error: {0}.", l_exception));
							}
							Console.Out.Flush ();
						});
						i_printStandardOutputThread.Start ();
					}
					
					public void printStandardErrorOutputAsynchronously () {
						i_printStandardErrorOutputThread = new Thread ( () => {
							try {
								StreamReader l_standardErrorOutputReader = i_standardErrorOutputInputStream;
								Char [] l_standardErrorOutputData = new Char [DefaultValuesConstantsGroup.c_smallBufferSize];
								Int32 l_standardErrorOutputDataLength = 0;
								while ( (l_standardErrorOutputDataLength = l_standardErrorOutputReader.Read (l_standardErrorOutputData, GeneralConstantsConstantsGroup.c_iterationStartNumber, DefaultValuesConstantsGroup.c_smallBufferSize)) != 0) {
									for (Int32 l_characterIndex = 0; l_characterIndex < l_standardErrorOutputDataLength; l_characterIndex ++) {
										i_thereWereStandardErrorOutputContents = true;
										Console.Out.Write (l_standardErrorOutputData [l_characterIndex]);
										Console.Out.Flush ();
									}
								}
							}
							catch (IOException l_exception) {
								Console.Error.WriteLine (String.Format ("### A child process standard error output error: {0}.", l_exception));
							}
							Console.Out.Flush ();
						});
						i_printStandardErrorOutputThread.Start ();
					}
					
					public String getStandardOutputNextLine () {
						try {
							if (!(i_standardOutputInputStream.EndOfStream)) {
								i_thereWereStandardOutputContents = true;
								return i_standardOutputInputStream.ReadLine ();
							}
							else {
								i_standardOutputInputStream.Close ();
								return null;
							}
						}
						catch (Exception l_exception) {
							Console.Error.WriteLine (String.Format ("The standard output couldn't be scanned: {0}.", l_exception.ToString ()));
							i_standardOutputInputStream.Close ();
							return null;
						}
					}
					
					public String getStandardErrorOutputNextLine () {
						try {
							if (!(i_standardErrorOutputInputStream.EndOfStream)) {
								i_thereWereStandardErrorOutputContents = true;
								return i_standardErrorOutputInputStream.ReadLine ();
							}
							else {
								i_standardErrorOutputInputStream.Close ();
								return null;
							}
						}
						catch (Exception l_exception) {
							Console.Error.WriteLine (String.Format ("The standard error output couldn't be scanned: {0}.", l_exception.ToString ()));
							i_standardErrorOutputInputStream.Close ();
							return null;
						}
					}
					
					public Boolean thereWereStandardInputContents () {
						return i_thereWereStandardInputContents;
					}
					
					public Boolean thereWereStandardOutputContents () {
						return i_thereWereStandardOutputContents;
					}
					
					public Boolean thereWereStandardErrorOutputContents () {
						return i_thereWereStandardErrorOutputContents;
					}
					
					public Int32 waitUntillFinish () {
						if (i_printStandardErrorOutputThread != null) {
							i_printStandardErrorOutputThread.Join ();
							i_printStandardErrorOutputThread = null;
						}
						if (i_printStandardOutputThread != null) {
							i_printStandardOutputThread.Join ();
							i_printStandardOutputThread = null;
						}
						i_process.WaitForExit ();
						Int32 l_processReturn = i_process.ExitCode;
						if (i_relayStandardInputThread != null) {
							interruptRelayStandardInputThread (i_relayStandardInputThread);
							i_relayStandardInputThread.Join ();
							i_relayStandardInputThread = null;
						}
						return l_processReturn;
					}
				}
				
				// The environment variables of the current process are automatically passed into the sub process.
				public static StandardInputAndOutputs executeAndReturnStandardInputAndOutputs (String a_workingDirectoryPath, List <String> a_commandAndArguments) {
					Process l_process = new Process ();
					l_process.StartInfo.UseShellExecute = false;
					l_process.StartInfo.FileName = a_commandAndArguments [GeneralConstantsConstantsGroup.c_iterationStartNumber];
					l_process.StartInfo.CreateNoWindow = true;
					Boolean l_elementIsCommand = true;
					Boolean l_elementIsFirstArgument = false;
					StringBuilder l_argumentsStringBuilder = new StringBuilder ();
					foreach (String l_commandOrArgument in a_commandAndArguments) {
						if (l_elementIsCommand) {
							l_elementIsCommand = false;
							l_elementIsFirstArgument = true;
						}
						else {
							if (l_elementIsFirstArgument) {
								l_elementIsFirstArgument = false;
							}
							else {
								l_argumentsStringBuilder.Append (" ");
							}
							l_argumentsStringBuilder.Append (StringHandler.getEscapedArgument (l_commandOrArgument));
						}
					}
					l_process.StartInfo.Arguments = l_argumentsStringBuilder.ToString ();
					l_process.StartInfo.RedirectStandardInput = true;
					l_process.StartInfo.RedirectStandardOutput = true;
					l_process.StartInfo.RedirectStandardError = true;
					/*
					l_process.OutputDataReceived += (sender, args) => Console.Out.WriteLine("received output: {0}", args.Data);
					l_process.ErrorDataReceived += (sender, args) => Console.Out.WriteLine("received output: {0}", args.Data);
					*/
					if (a_workingDirectoryPath != null) {
						l_process.StartInfo.WorkingDirectory = a_workingDirectoryPath;
					}
					l_process.Start ();
					/*
					l_process.BeginOutputReadLine ();
					l_process.BeginErrorReadLine ();
					*/
					/*
					l_process.WaitForExit ();
					l_process.CancelOutputRead ();
					*/
					return new StandardInputAndOutputs (l_process);
				}
				
				public static Int32 execute (String a_workingDirectoryPath, List <String> a_commandAndArguments, Boolean a_waitsUntilFinish) {
					StandardInputAndOutputs l_standardInputAndOutputs = executeAndReturnStandardInputAndOutputs (a_workingDirectoryPath, a_commandAndArguments);
					Int32 l_childProcessReturn = 0;
					if (a_waitsUntilFinish) {
						l_standardInputAndOutputs.printStandardOutputAsynchronously ();
						l_standardInputAndOutputs.printStandardErrorOutputAsynchronously ();
						l_standardInputAndOutputs.relayStandardInputAsynchronously ();
						l_childProcessReturn = l_standardInputAndOutputs.waitUntillFinish ();
					}
					else {
						Thread l_waitForInvokedProcessToEndThread = new Thread ( () => {
							try {
								l_standardInputAndOutputs.printStandardOutputAsynchronously ();
								l_standardInputAndOutputs.printStandardErrorOutputAsynchronously ();
								l_standardInputAndOutputs.relayStandardInputAsynchronously ();
								l_standardInputAndOutputs.waitUntillFinish ();
							}
							catch (Exception) {
							}
						});
						l_waitForInvokedProcessToEndThread.Start ();
					}
					return l_childProcessReturn;
				}
			}
		}
	}
}

