namespace theBiasPlanet {
	namespace coreUtilities {
		namespace performanceMeasuringHandling {
			using System;
			
			public sealed class PerformanceMeasurer {
				private static DateTime s_startTime;
				
				public static void setStartTime () {
					s_startTime = DateTime.Now;
				}
				
				public static Int64 getElapseTimeInNanoSeconds () {
					return (Int64) ((DateTime.Now - s_startTime).TotalMilliseconds * 1000000);
				}
				
				public static Int64 getElapseTimeInMicroSeconds () {
					return (Int64) ((DateTime.Now - s_startTime).TotalMilliseconds * 1000);
				}
			}
		}
	}
}

