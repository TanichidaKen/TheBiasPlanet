package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_GoToObjectEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_objectName_string = "ToObject";
	public static final Uno_uno_GoToObjectEnumerablePropertyNamesSet c_instance = new Uno_uno_GoToObjectEnumerablePropertyNamesSet ();
	
	private Uno_uno_GoToObjectEnumerablePropertyNamesSet () {
	}
}

