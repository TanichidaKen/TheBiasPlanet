package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_JumpToTableEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_spreadSheetNumber_short = "Nr";
	public static final Uno_uno_JumpToTableEnumerablePropertyNamesSet c_instance = new Uno_uno_JumpToTableEnumerablePropertyNamesSet ();
	
	private Uno_uno_JumpToTableEnumerablePropertyNamesSet () {
	}
}

