package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_LibLoadedEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_containerNameOrContainer_any = "Document";
	public static final String c_libraryName_string = "LibName";
	public static final Uno_uno_LibLoadedEnumerablePropertyNamesSet c_instance = new Uno_uno_LibLoadedEnumerablePropertyNamesSet ();
	
	private Uno_uno_LibLoadedEnumerablePropertyNamesSet () {
	}
}

