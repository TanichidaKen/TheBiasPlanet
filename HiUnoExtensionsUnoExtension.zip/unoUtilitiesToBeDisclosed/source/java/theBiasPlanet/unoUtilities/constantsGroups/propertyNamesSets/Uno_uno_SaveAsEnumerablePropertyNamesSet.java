package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_SaveAsEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_url_string = "URL";
	public static final String c_filterName_string = "FilterName";
	public static final String c_password_string = "Password";
	public static final String c_showsPasswordDialog_boolean = "PasswordInteraction";
	public static final String c_filterData_string = "FilterOptions";
	public static final String c_versionCommment_string = "VersionComment";
	public static final String c_versionAuthor_string = "VersionAuthor";
	public static final String c_overwrites_boolean = "Overwrite";
	//public static final String c_unpacked_boolean = "Unpacked";
	public static final String c_notOpenedAs_boolean = "SaveTo";
	public static final String c_noFileSynchronization_boolean = "NoFileSync"; // the meaning unknown
	public static final String c_noThumbnail_boolean = "NoThumbnail";
	public static final Uno_uno_SaveAsEnumerablePropertyNamesSet c_instance = new Uno_uno_SaveAsEnumerablePropertyNamesSet ();
	
	private Uno_uno_SaveAsEnumerablePropertyNamesSet () {
	}
}

