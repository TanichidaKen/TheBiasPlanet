package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_GoRightBlockSelEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_numberOfPagesToGoRightBy_short = "By";
	public static final Uno_uno_GoRightBlockSelEnumerablePropertyNamesSet c_instance = new Uno_uno_GoRightBlockSelEnumerablePropertyNamesSet ();
	
	private Uno_uno_GoRightBlockSelEnumerablePropertyNamesSet () {
	}
}

