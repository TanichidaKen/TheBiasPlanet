package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_EnterStringEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_value_string = "StringName";
	public static final String c_valueIsNotCommited_boolean = "DontCommit";
	public static final Uno_uno_EnterStringEnumerablePropertyNamesSet c_instance = new Uno_uno_EnterStringEnumerablePropertyNamesSet ();
	
	private Uno_uno_EnterStringEnumerablePropertyNamesSet () {
	}
}

