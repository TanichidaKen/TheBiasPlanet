package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_ChangePrintAreaEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_printedAreasSpecification_string = "PrintArea";
	public static final String c_repeatedlyPrintedRowsAreaSpecification_string = "PrintRepeatRow";
	public static final String c_repeatedlyPrintedColumnsAreaSpecification_string = "PrintRepeatCol";
	public static final Uno_uno_ChangePrintAreaEnumerablePropertyNamesSet c_instance = new Uno_uno_ChangePrintAreaEnumerablePropertyNamesSet ();
	
	private Uno_uno_ChangePrintAreaEnumerablePropertyNamesSet () {
	}
}

