package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_SetDocumentPropertiesEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_usesUserData_boolean = "Properties.UseUserData";
	public static final String c_deletesUserData_boolean = "Properties.DeleteUserData";
	public static final String c_title_string = "Properties.Title";
	public static final String c_subject_string = "Properties.Subject";
	public static final String c_keywords_string = "Properties.KeyWords";
	public static final String c_description_string = "Properties.Description";
	public static final String c_reloadsAutomatically_boolean = "Properties.AutoReload";
	public static final String c_automaticReloadingInterval_long = "Properties.AutoReloadTime";
	public static final String c_automaticReloadingUrl_string = "Properties.AutoReloadURL";
	public static final String c_automaticReloadingFrameName_string = "Properties.AutoReloadFrame";
	public static final Uno_uno_SetDocumentPropertiesEnumerablePropertyNamesSet c_instance = new Uno_uno_SetDocumentPropertiesEnumerablePropertyNamesSet ();
	
	private Uno_uno_SetDocumentPropertiesEnumerablePropertyNamesSet () {
	}
}

