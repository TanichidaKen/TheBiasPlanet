package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_JumpToMarkEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_bookmarkName_string = "Bookmark";
	public static final Uno_uno_JumpToMarkEnumerablePropertyNamesSet c_instance = new Uno_uno_JumpToMarkEnumerablePropertyNamesSet ();
	
	private Uno_uno_JumpToMarkEnumerablePropertyNamesSet () {
	}
}

