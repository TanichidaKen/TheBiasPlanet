package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_CloseDocEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_saveChanges_boolean = "saveChanges";
	public static final String c_fileName_string = "fileName";
	public static final Uno_uno_CloseDocEnumerablePropertyNamesSet c_instance = new Uno_uno_CloseDocEnumerablePropertyNamesSet ();
	
	private Uno_uno_CloseDocEnumerablePropertyNamesSet () {
	}
}

