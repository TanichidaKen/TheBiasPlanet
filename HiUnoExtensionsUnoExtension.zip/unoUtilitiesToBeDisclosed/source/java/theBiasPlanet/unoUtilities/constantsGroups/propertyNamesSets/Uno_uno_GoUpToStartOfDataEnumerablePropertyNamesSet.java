package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_GoUpToStartOfDataEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_numberOfTimesToGoUpBy_short = "By";
	public static final String c_whetherTheCellsAreSelected_boolean = "Sel"; // Whether the command is in the changing-the-sells-selection mode
	public static final Uno_uno_GoUpToStartOfDataEnumerablePropertyNamesSet c_instance = new Uno_uno_GoUpToStartOfDataEnumerablePropertyNamesSet ();
	
	private Uno_uno_GoUpToStartOfDataEnumerablePropertyNamesSet () {
	}
}

