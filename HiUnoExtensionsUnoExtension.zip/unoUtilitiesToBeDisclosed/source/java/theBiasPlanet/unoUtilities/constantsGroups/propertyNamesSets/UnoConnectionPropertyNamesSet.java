package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

public interface UnoConnectionPropertyNamesSet extends UnoPropertyNamesSet {
	String c_url_string = "unoUrl";
}

