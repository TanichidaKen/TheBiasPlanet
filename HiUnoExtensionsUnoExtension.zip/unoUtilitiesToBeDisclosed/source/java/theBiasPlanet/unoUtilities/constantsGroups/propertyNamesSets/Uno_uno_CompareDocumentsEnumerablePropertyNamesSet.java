package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_CompareDocumentsEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_url_string = "URL";
	public static final String c_filterName_string = "FilterName";
	public static final String c_password_string = "Password";
	public static final String c_filterOptions_string = "FilterOptions";
	public static final String c_version_short = "Version";
	public static final String c_notShowAcceptDialog_boolean = "NoAcceptDialog";
	public static final Uno_uno_CompareDocumentsEnumerablePropertyNamesSet c_instance = new Uno_uno_CompareDocumentsEnumerablePropertyNamesSet ();
	
	private Uno_uno_CompareDocumentsEnumerablePropertyNamesSet () {
	}
}

