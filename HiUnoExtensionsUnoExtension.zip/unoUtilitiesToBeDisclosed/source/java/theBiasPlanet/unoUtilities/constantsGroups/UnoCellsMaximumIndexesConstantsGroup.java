package theBiasPlanet.unoUtilities.constantsGroups;

public interface UnoCellsMaximumIndexesConstantsGroup {
	int c_maximumRowIndex = 1048575;
	int c_maximumColumnIndex = 1023;
}

