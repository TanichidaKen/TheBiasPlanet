package theBiasPlanet.unoUtilities.constantsGroups;

public interface UnoOpenXmlFileEncryptionAlgorithmClassesConstantsGroup {
	String c_hash = "hash";
}

