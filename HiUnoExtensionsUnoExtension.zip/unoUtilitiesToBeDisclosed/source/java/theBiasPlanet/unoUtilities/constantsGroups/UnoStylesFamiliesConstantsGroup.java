package theBiasPlanet.unoUtilities.constantsGroups;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.*;

// Interface because this is not enumerable
public interface UnoStylesFamiliesConstantsGroup {
	BaseUnoStylesFamily c_unoPageStylesFamily = new BaseUnoStylesFamily ("PageStyles", (short) 0x08);
	BaseUnoStylesFamily c_unoSpreadSheetCellStylesFamily = new BaseUnoStylesFamily ("CellStyles", (short) 0x40);
	BaseUnoStylesFamily c_unoParagraphStylesFamily = new BaseUnoStylesFamily ("ParaStyles", (short) 0x02);
	BaseUnoStylesFamily c_unoCharacterStylesFamily = new BaseUnoStylesFamily ("CharStyles", (short) 0x01);
	BaseUnoStylesFamily c_unoFrameStylesFamily = new BaseUnoStylesFamily ("FrameStyles", (short) 0x04);
	BaseUnoStylesFamily c_unoListStylesFamily = new BaseUnoStylesFamily ("PseudoStyles", (short) 0x10);
	
	// Base class for all the constants in this group
	static class BaseUnoStylesFamily {
		public final String c_name;
		public final short c_key;
		
		BaseUnoStylesFamily (String a_name, short a_key) {
			c_name = a_name;
			c_key = a_key;
		}
	}
}

