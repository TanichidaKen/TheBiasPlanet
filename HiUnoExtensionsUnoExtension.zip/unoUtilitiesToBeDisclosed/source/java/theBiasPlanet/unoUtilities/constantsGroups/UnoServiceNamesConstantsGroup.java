package theBiasPlanet.unoUtilities.constantsGroups;

// Interface because this is not enumerable
public interface UnoServiceNamesConstantsGroup {
	String c_com_sun_star_awt_DialogProvider = "com.sun.star.awt.DialogProvider";
    String c_com_sun_star_awt_tree_MutableTreeDataModel = "com.sun.star.awt.tree.MutableTreeDataModel";
	String c_com_sun_star_bridge_BridgeFactory = "com.sun.star.bridge.BridgeFactory";
	String c_com_sun_star_connection_Acceptor = "com.sun.star.connection.Acceptor";
	String c_com_sun_star_connection_Connector = "com.sun.star.connection.Connector";
	String c_com_sun_star_frame_Desktop = "com.sun.star.frame.Desktop";
	String c_com_sun_star_frame_DispatchHelper = "com.sun.star.frame.DispatchHelper";
	String c_com_sun_star_graphic_GraphicProvider = "com.sun.star.graphic.GraphicProvider";
	String c_com_sun_star_script_BasicIDE = "com.sun.star.script.BasicIDE";
	String c_com_sun_star_script_provider_MasterScriptProvider = "com.sun.star.script.provider.MasterScriptProvider";
	String c_com_sun_star_script_provider_ScriptProviderForBasic = "com.sun.star.script.provider.ScriptProviderForBasic";
	String c_com_sun_star_util_URLTransformer = "com.sun.star.util.URLTransformer";
	String c_com_sun_star_xml_crypto_GPGSEInitializer = "com.sun.star.xml.crypto.GPGSEInitializer";
	String c_com_sun_star_xml_crypto_NSSInitializer = "com.sun.star.xml.crypto.NSSInitializer";
	String c_com_sun_star_xml_crypto_SEInitializer = "com.sun.star.xml.crypto.SEInitializer";
	String c_com_sun_star_xml_crypto_SecurityEnvironment = "com.sun.star.xml.crypto.SecurityEnvironment";
}

