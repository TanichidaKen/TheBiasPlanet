package theBiasPlanet.unoUtilities.unoComponentBases;

import com.sun.star.lang.XServiceInfo;
import com.sun.star.lib.uno.helper.WeakBase;
import theBiasPlanet.coreUtilities.messagingHandling.Publisher;

public class UnoComponentBase extends WeakBase implements XServiceInfo {
	public UnoComponentBase () {
		Publisher.logDebugInformation (String.format ("### An instance of a local UNO component, '%s', is being created.", this.getClass ().getName ()));
	}
	
	@Override
	protected void finalize () {
		Publisher.logDebugInformation (String.format ("### An instance of a local UNO component, '%s', is being destructed.", this.getClass ().getName ()));
	}
	
	@Override
	public String getImplementationName () {
		return "not specified";
	}
	
	@Override
	public boolean supportsService (String a_serviceName) {
		return false;
	}
	
	@Override
	public String [] getSupportedServiceNames () {
		return new String [0];
	}
}

