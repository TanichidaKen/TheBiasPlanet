package theBiasPlanet.unoUtilities.nameValuePair;

import com.sun.star.beans.NamedValue;

public class UnoNameValuePair extends NamedValue {
	public UnoNameValuePair (String a_name, Object a_value) {
		Name = a_name;
		Value = a_value;
	}
}

