package theBiasPlanet.unoUtilities.documents;

import java.util.List;
import com.sun.star.beans.PropertyValue;
import com.sun.star.container.NoSuchElementException;
import com.sun.star.container.XEnumeration;
import com.sun.star.document.XDocumentEventBroadcaster;
import com.sun.star.document.XDocumentEventListener;
import com.sun.star.document.XEventBroadcaster;
import com.sun.star.document.XEventListener;
import com.sun.star.frame.DispatchResultEvent;
import com.sun.star.frame.FeatureStateEvent;
import com.sun.star.frame.FrameSearchFlag;
import com.sun.star.frame.XController;
//import com.sun.star.frame.XDispatchHelper;
import com.sun.star.frame.XDispatchProvider;
import com.sun.star.frame.XDispatchResultListener;
import com.sun.star.frame.XFrame;
import com.sun.star.frame.XModel;
import com.sun.star.frame.XStatusListener;
import com.sun.star.frame.XStorable2;
import com.sun.star.lang.EventObject;
import com.sun.star.lang.WrappedTargetException;
import com.sun.star.lang.XComponent;
import com.sun.star.script.provider.XScript;
import com.sun.star.script.provider.XScriptProvider;
import com.sun.star.script.provider.XScriptProviderSupplier;
import com.sun.star.uno.UnoRuntime;
import com.sun.star.util.CloseVetoException;
import com.sun.star.util.XCloseable;
import theBiasPlanet.coreUtilities.collectionsHandling.ListsFactory;
import theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.RegularExpressionsConstantsGroup;
import theBiasPlanet.unoUtilities.constantsGroups.UnoGeneralConstantsConstantsGroup;
import theBiasPlanet.unoUtilities.constantsGroups.UnoMacroLocationNamesConstantsGroup;
import theBiasPlanet.unoUtilities.constantsGroups.UnoMessagesConstantsGroup;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.UnoDocumentStoringEnumerablePropertyNamesSet;
import theBiasPlanet.unoUtilities.displayElements.UnoDesktop;
import theBiasPlanet.unoUtilities.displayElements.UnoFrame;
import theBiasPlanet.unoUtilities.pointers.UnoObjectPointer;
import theBiasPlanet.unoUtilities.propertiesHandling.UnoPropertiesHandler;
import theBiasPlanet.unoUtilities.unoComponentBases.UnoComponentBase;
import theBiasPlanet.unoUtilities.unoObjectsContexts.RemoteUnoObjectsContext;

public class UnoDocument {
	protected RemoteUnoObjectsContext i_remoteUnoObjectsContext = null;
	protected UnoObjectPointer <XModel> i_underlyingUnoObject = null;
	protected UnoObjectPointer <XController> i_unoController = null;
	protected UnoFrame i_unoFrame = null;
	protected UnoObjectPointer <XScriptProvider> i_macrosProvider = null;
	
	public UnoDocument (RemoteUnoObjectsContext a_remoteUnoObjectsContext, UnoObjectPointer <XModel> a_underlyingUnoObject) throws Exception {
		if (a_remoteUnoObjectsContext == null) {
			throw new Exception (UnoMessagesConstantsGroup.c_unoObjectsContextNotSpecified);
		}
		i_remoteUnoObjectsContext = a_remoteUnoObjectsContext;
		if (a_underlyingUnoObject == null) {
			throw new Exception (UnoMessagesConstantsGroup.c_unoDocumentNotSpecified);
		}
		i_underlyingUnoObject = a_underlyingUnoObject;
		i_unoController = new UnoObjectPointer <XController> (i_underlyingUnoObject.getAddress ().getCurrentController (), XController.class);
		i_unoFrame = new UnoFrame (i_remoteUnoObjectsContext, new UnoObjectPointer <XFrame> (i_unoController.getAddress ().getFrame ()));
		i_macrosProvider = new UnoObjectPointer <XScriptProvider> (i_underlyingUnoObject. <XScriptProviderSupplier>getAddress (XScriptProviderSupplier.class).getScriptProvider ());
	}
	
	@Override
	protected void finalize () {
	}
	
	public static UnoDocument openDocumentFile (UnoDesktop a_unoDesktop, String a_fileUrl, String a_password, boolean a_unoDocumentIsHidden) throws Exception, com.sun.star.io.IOException {
		return new UnoDocument (a_unoDesktop.getRemoteUnoObjectsContext (), a_unoDesktop.loadUnoDocument (a_fileUrl, a_password, a_unoDocumentIsHidden));
	}
	
	public static UnoDocument getCurrentDocument (UnoDesktop a_unoDesktop) throws Exception {
		return new UnoDocument (a_unoDesktop.getRemoteUnoObjectsContext (), a_unoDesktop.getCurrentDocument ());
	}
	
	public RemoteUnoObjectsContext getRemoteUnoObjectsContext () {
		return i_remoteUnoObjectsContext;
	}
	
	public UnoObjectPointer <XModel> getUnderlyingUnoObject () {
		return i_underlyingUnoObject;
	}
	
	public UnoFrame getUnoFrame () {
		return i_unoFrame;
	}
	
	public void store () throws com.sun.star.io.IOException {
		//i_selfInXStorable2.storeSelf (new PropertyValue [0]);
		storeAtUrl (getUrl ());
	}
	
	public void storeAtUrl (String a_fileUrl) throws com.sun.star.io.IOException {
		i_underlyingUnoObject. <XStorable2>getAddress (XStorable2.class).storeToURL (a_fileUrl.replaceAll (RegularExpressionsConstantsGroup.c_windowsDirectoryDelimiterRegularExpression.pattern (), String.valueOf (GeneralConstantsConstantsGroup.c_linuxDirectoriesDelimiter)), new PropertyValue [0]);
	}
	
	// Use UnoDocumentStoringFilterNamesConstantsGroup for a_filterName.
	public void storeAtUrl (String a_fileUrl, String a_filterName, Object a_filterData) throws com.sun.star.io.IOException {
		i_underlyingUnoObject. <XStorable2>getAddress (XStorable2.class).storeToURL (a_fileUrl.replaceAll (RegularExpressionsConstantsGroup.c_windowsDirectoryDelimiterRegularExpression.toString (), String.valueOf (GeneralConstantsConstantsGroup.c_linuxDirectoriesDelimiter)), UnoPropertiesHandler.buildPropertiesArray (UnoDocumentStoringEnumerablePropertyNamesSet.c_instance.getValues (), ListsFactory. <Object>createArrayList (a_filterName, a_filterData)));
	}
	
	public String getUrl () {
		return i_underlyingUnoObject. <XStorable2>getAddress (XStorable2.class).getLocation ();
	}
	
	//public boolean addEventsListener (UnoObjectPointer <XDocumentEventListener> a_eventsListener) {
	public boolean addEventsListener (XDocumentEventListener a_eventsListener) {
		//i_underlyingUnoObject. <XDocumentEventBroadcaster>getAddress (XDocumentEventBroadcaster.class).addDocumentEventListener (a_eventsListener.getAddress ());
		i_underlyingUnoObject. <XDocumentEventBroadcaster>getAddress (XDocumentEventBroadcaster.class).addDocumentEventListener (a_eventsListener);
		return true;
	}
	
	//public boolean removeEventsListener (UnoObjectPointer <XDocumentEventListener> a_eventsListener) {
	public boolean removeEventsListener (XDocumentEventListener a_eventsListener) {
		//i_underlyingUnoObject. <XDocumentEventBroadcaster>getAddress (XDocumentEventBroadcaster.class).removeDocumentEventListener (a_eventsListener.getAddress ());
		i_underlyingUnoObject. <XDocumentEventBroadcaster>getAddress (XDocumentEventBroadcaster.class).removeDocumentEventListener (a_eventsListener);
		return true;
	}
	
	/*
	public void addEventsListener (UnoObjectPointer <XEventListener> a_eventsListener) {
		i_underlyingUnoObject. <XDocumentEventBroadcaster>getAddress (XDocumentEventBroadcaster.class).addEventListener (a_eventsListener.getAddress ());
	}
	
	public void removeEventsListener (UnoObjectPointer <XEventListener> a_eventsListener) {
		i_underlyingUnoObject. <XDocumentEventBroadcaster>getAddress (XDocumentEventBroadcaster.class).removeEventListener (a_eventsListener.getAddress ());
	}
	*/
	
	public void close () throws CloseVetoException {
		i_underlyingUnoObject. <XCloseable>getAddress (XCloseable.class).close (false);
	}
	
	public Object invokeMacro (String a_macroProgrammingLanguageName, String a_macroPathString, Object [] a_macroArgumentsArray, short [] [] a_macroOutputArgumentIndexesArray, Object [] [] a_macroOutputArgumentsArray) throws Exception {
		String l_macroUrl = String.format (UnoGeneralConstantsConstantsGroup.c_macroUrlFormat, a_macroPathString, a_macroProgrammingLanguageName, UnoMacroLocationNamesConstantsGroup.c_document);
		UnoObjectPointer <XScript> l_macroHandler = new UnoObjectPointer <XScript> (i_macrosProvider.getAddress ().getScript (l_macroUrl));
		return l_macroHandler.getAddress ().invoke (a_macroArgumentsArray, a_macroOutputArgumentIndexesArray, a_macroOutputArgumentsArray);
	}
}

