package theBiasPlanet.unoUtilities.unoDataHandling;

import java.util.ArrayList;
import java.util.regex.Matcher;
import com.sun.star.uno.XInterface;
import theBiasPlanet.unoUtilities.constantsGroups.UnoRegularExpressionsConstantsGroup;
import theBiasPlanet.unoUtilities.pointers.UnoObjectPointer;
import theBiasPlanet.unoUtilities.stringsHandling.UnoExtendedStringHandler;

public class UnoDatumConverter {
	public static Object getObject (Object a_originalObject) {
		if (a_originalObject == null) {
			return null;
		}
		else {
			if (a_originalObject instanceof com.sun.star.uno.Any) {
				return ( (com.sun.star.uno.Any) a_originalObject).getObject ();
			}
			else {
				return a_originalObject;
			}
		}
	}
	
	public static com.sun.star.uno.Any getAny (Object a_originalObject) {
		if (a_originalObject == null) {
			return null;
		}
		else {
			if (a_originalObject instanceof String) {
				return new com.sun.star.uno.Any (com.sun.star.uno.Type.STRING, a_originalObject);
			}
			else if (a_originalObject instanceof Character) {
				return new com.sun.star.uno.Any (com.sun.star.uno.Type.CHAR, a_originalObject);
			}
			else if (a_originalObject instanceof Boolean) {
				return new com.sun.star.uno.Any (com.sun.star.uno.Type.BOOLEAN, a_originalObject);
			}
			else if (a_originalObject instanceof Byte) {
				return new com.sun.star.uno.Any (com.sun.star.uno.Type.BYTE, a_originalObject);
			}
			else if (a_originalObject instanceof Short) {
				return new com.sun.star.uno.Any (com.sun.star.uno.Type.SHORT, a_originalObject);
			}
			else if (a_originalObject instanceof Integer) {
				return new com.sun.star.uno.Any (com.sun.star.uno.Type.LONG, a_originalObject);
			}
			else if (a_originalObject instanceof Long) {
				return new com.sun.star.uno.Any (com.sun.star.uno.Type.HYPER, a_originalObject);
			}
			else if (a_originalObject instanceof Float) {
				return new com.sun.star.uno.Any (com.sun.star.uno.Type.FLOAT , a_originalObject);
			}
			else if (a_originalObject instanceof Double) {
				return new com.sun.star.uno.Any (com.sun.star.uno.Type.DOUBLE, a_originalObject);
			}
			else if (a_originalObject instanceof com.sun.star.uno.Type) {
				return new com.sun.star.uno.Any (com.sun.star.uno.Type.TYPE, a_originalObject);
			}
			else {
				return new com.sun.star.uno.Any (com.sun.star.uno.Type.VOID, a_originalObject);
			}
		}
	}
	
	public static String toString (Object a_originalObject) {
		if (a_originalObject == null) {
			return null;
		}
		else {
			Class l_class = a_originalObject.getClass ();
			StringBuilder l_stringBuffer = new StringBuilder ();
			l_stringBuffer.append (UnoExtendedStringHandler.getString (a_originalObject));
			
			/*
			String l_className = l_class.toString ();
			l_stringBuffer.append (l_className);
			l_stringBuffer.append (": ");
			if (l_class.isArray ()) {
				l_stringBuffer.append ("[");
				int l_numberOfElements = Array.getLength (a_originalObject);
				Object l_element = null;
				for (int l_elementIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber; l_elementIndex < l_numberOfElements ; l_elementIndex ++) {
					if (l_elementIndex == GeneralConstantsConstantsGroup.c_iterationStartNumber) {
					}	
					else {
						l_stringBuffer.append (", ");
					}
					l_element = Array.get (a_originalObject, l_elementIndex);
					l_stringBuffer.append (toString (l_element));
				}
				l_stringBuffer.append ("]");
			}
			else {
				if (l_className.equals ("class com.sun.star.frame.status.ClipboardFormats")) {
					long [] l_formatIdentifications = ((ClipboardFormats) a_originalObject).Identifiers;
					String [] l_formatNames = ((ClipboardFormats) a_originalObject).Names;
					int l_formatIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
					for (long l_formatIdentification: l_formatIdentifications) {
						if (l_formatIndex == GeneralConstantsConstantsGroup.c_iterationStartNumber) {
						}	
						else {
							l_stringBuffer.append (", ");
						}
						l_stringBuffer.append (String.format ("%d, \"%s\"", l_formatIdentification, l_formatNames [l_formatIndex]));
						l_formatIndex ++;
					}
				}
				if (l_className.equals ("class com.sun.star.beans.PropertyValue")) {
					PropertyValue l_propertyValue = (PropertyValue) a_originalObject;
					l_stringBuffer.append ("Name -> ");
					l_stringBuffer.append (l_propertyValue.Name);
					l_stringBuffer.append (", Value -> ");
					l_stringBuffer.append (UnoDatumConverter.toString (l_propertyValue.Value));
				}
				else {
					l_stringBuffer.append (a_originalObject.toString ());
				}
			}
			*/
			return l_stringBuffer.toString ();
		}
	}
	
	/*
	public static com.sun.star.uno.Type getUnoType (String a_unoTypeName) {
		if ("char".equals (a_unoTypeName)) {
			return com.sun.star.uno.Type (null, TypeClass.CHAR);
		}
		else if ("boolean".equals (a_unoTypeName)) {
			return com.sun.star.uno.Type (null, TypeClass.BOOLEAN);
		}
		else if (a_unoType == TypeClass.BYTE) {
			return ReflectionHandler.getClass (null, GeneralConstantsConstantsGroup.c_byteClassName, false);
		}
		else if (a_unoType == TypeClass.SHORT || a_unoType == TypeClass.UNSIGNED_SHORT) {
			return ReflectionHandler.getClass (null, GeneralConstantsConstantsGroup.c_shortClassName, false);
		}
		else if (a_unoType == TypeClass.LONG || a_unoType == TypeClass.UNSIGNED_LONG) {
			return ReflectionHandler.getClass (null, GeneralConstantsConstantsGroup.c_intClassName, false);
		}
		else if (a_unoType == TypeClass.HYPER || a_unoType == TypeClass.UNSIGNED_HYPER) {
			return ReflectionHandler.getClass (null, GeneralConstantsConstantsGroup.c_longClassName, false);
		}
		else if (a_unoType == TypeClass.FLOAT) {
			return ReflectionHandler.getClass (null, GeneralConstantsConstantsGroup.c_floatClassName, false);
		}
		else if (a_unoType == TypeClass.DOUBLE) {
			return ReflectionHandler.getClass (null, GeneralConstantsConstantsGroup.c_doubleClassName, false);
		}
		else if (a_unoType == TypeClass.STRING) {
			return ReflectionHandler.getClass (null, GeneralConstantsConstantsGroup.c_stringClassName, false);
		}
		else if (a_unoType == TypeClass.TYPE) {
			return ReflectionHandler.getClass (null, "com.sun.star.uno.Type", false);
		}
		else if (a_unoType == TypeClass.ANY) {
			return ReflectionHandler.getClass (null, GeneralConstantsConstantsGroup.c_objectClassName, false);
		}
		else if (a_unoType == TypeClass.ENUM || a_unoType == TypeClass.STRUCT || a_unoType == TypeClass.EXCEPTION || TypeClass.INTERFACE) {
			return ReflectionHandler.getClass (null, a_unoType.getTypeName (), false);
		}
		else if (a_unoType == TypeClass.SEQUENCE) {
			// ???
			return ReflectionHandler.getClass (null, a_unoType.getTypeName (), false);
		}
		else {
			return null;
		}
	}
	*/
	
	public static <T extends XInterface> ArrayList <UnoObjectPointer <T>> getUnoObjects (T [] a_unoProxiesArray) {
		if (a_unoProxiesArray == null) {
			return null;
		}
		ArrayList <UnoObjectPointer <T>> l_unoObjects = new ArrayList <UnoObjectPointer <T>> ();
		for (T l_unoProxy: a_unoProxiesArray) {
			l_unoObjects.add (new UnoObjectPointer <T> (l_unoProxy));
		}
		return l_unoObjects;
	}
	
	public static com.sun.star.util.URL getUrlInURL (String a_url) {
		com.sun.star.util.URL l_urlInURL = new com.sun.star.util.URL ();
		l_urlInURL.Complete = a_url;
		l_urlInURL.Main = l_urlInURL.Complete;
		Matcher l_regularExpressionMatcher = UnoRegularExpressionsConstantsGroup.c_urlRegularExpression.matcher (l_urlInURL.Complete);
		if (l_regularExpressionMatcher != null && l_regularExpressionMatcher.lookingAt ()) {
			l_urlInURL.Protocol = l_regularExpressionMatcher.group (1);
			l_urlInURL.User = "";
			l_urlInURL.Password = "";
			l_urlInURL.Server = "";
			l_urlInURL.Port = 0;
			l_urlInURL.Path = l_regularExpressionMatcher.group (2);
			l_urlInURL.Name = "";
			l_urlInURL.Arguments = "";
			l_urlInURL.Mark = "";
		}
		return l_urlInURL;
	}
}

