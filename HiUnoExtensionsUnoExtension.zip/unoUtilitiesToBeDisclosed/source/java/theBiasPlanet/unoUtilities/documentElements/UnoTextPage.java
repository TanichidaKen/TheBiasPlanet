package theBiasPlanet.unoUtilities.documentElements;

import com.sun.star.beans.UnknownPropertyException;
import com.sun.star.beans.XPropertySet;
import com.sun.star.container.NoSuchElementException;
import com.sun.star.lang.WrappedTargetException;
import com.sun.star.style.XStyle;
import com.sun.star.text.XPageCursor;
import com.sun.star.text.XTextViewCursor;
import com.sun.star.uno.AnyConverter;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.*;
import theBiasPlanet.unoUtilities.documents.UnoTextDocument;
import theBiasPlanet.unoUtilities.pointers.UnoObjectPointer;

public class UnoTextPage {
	private UnoTextDocument i_unoTextDocument = null;
	private UnoObjectPointer <XTextViewCursor> i_unoPageCursor = null;
	
	public UnoTextPage (UnoTextDocument a_unoTextDocument, UnoObjectPointer <XTextViewCursor> a_unoPageCursor) {
		i_unoTextDocument = a_unoTextDocument;
		i_unoPageCursor = a_unoPageCursor;
	}
	
	public int getUnoPageIndex () {
		return (int) i_unoPageCursor. <XPageCursor>getAddress (XPageCursor.class).getPage ();
	}
	
	public boolean moveToStartOfUnoPage () {
		return i_unoPageCursor. <XPageCursor>getAddress (XPageCursor.class).jumpToStartOfPage ();
	}
	
	public boolean moveToEndOfUnoPage () {
		return i_unoPageCursor. <XPageCursor>getAddress (XPageCursor.class).jumpToEndOfPage ();
	}
	
	public boolean moveToUnoPage (int a_unoPageIndex) {
		return i_unoPageCursor. <XPageCursor>getAddress (XPageCursor.class).jumpToPage ( (short) (a_unoPageIndex + 1));
	}
	
	public boolean moveToPreviousUnoPage () {
		return i_unoPageCursor. <XPageCursor>getAddress (XPageCursor.class).jumpToPreviousPage ();
	}
	
	public boolean moveToNextUnoPage () {
		return i_unoPageCursor. <XPageCursor>getAddress (XPageCursor.class).jumpToNextPage ();
	}
	
	public String getUnoPageStyleName () {
		try {
			return (String) i_unoPageCursor. <XPropertySet>getAddress (XPropertySet.class).getPropertyValue (UnoTextPageCursorPropertyNamesSet.c_pageStyleName_string);
		}
		catch (UnknownPropertyException | WrappedTargetException l_exception) {
			// Impossible
			return null;
		}
	}
	
	public UnoObjectPointer <XStyle> getUnoPageStyle () {
		try {
			return new UnoObjectPointer <XStyle> ( (XStyle) AnyConverter.toObject (XStyle.class, i_unoTextDocument.getUnoPageStyles ().getAddress ().getByName (getUnoPageStyleName ())));
		}
		catch (NoSuchElementException | WrappedTargetException l_exception) {
			// Impossible
			return null;
		}
	}
}

