package theBiasPlanet.unoUtilities.documentsHandling;

import com.sun.star.frame.XModel;
import theBiasPlanet.unoUtilities.pointers.UnoObjectPointer;
import theBiasPlanet.unoUtilities.unoObjectsContexts.RemoteUnoObjectsContext;

public class UnoDocumentTailor {
	protected RemoteUnoObjectsContext i_remoteUnoObjectsContext;
	
	public UnoDocumentTailor (RemoteUnoObjectsContext a_remoteUnoObjectsContext) {
		i_remoteUnoObjectsContext = a_remoteUnoObjectsContext;
	}
	
	public boolean tailor (UnoObjectPointer <XModel> a_unoDocument) throws Exception {
		return true;
	}
}

