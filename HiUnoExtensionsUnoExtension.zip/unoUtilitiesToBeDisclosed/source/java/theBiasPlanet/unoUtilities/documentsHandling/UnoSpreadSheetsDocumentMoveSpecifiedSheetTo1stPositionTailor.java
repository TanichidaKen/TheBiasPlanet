package theBiasPlanet.unoUtilities.documentsHandling;

import com.sun.star.container.XIndexAccess;
import com.sun.star.container.XNamed;
import com.sun.star.frame.XModel;
import com.sun.star.sheet.XSpreadsheet;
import com.sun.star.sheet.XSpreadsheetDocument;
import com.sun.star.sheet.XSpreadsheets;
import com.sun.star.uno.Any;
import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.coreUtilities.messagingHandling.Publisher;
import theBiasPlanet.unoUtilities.documentsHandling.UnoDocumentTailor;
import theBiasPlanet.unoUtilities.pointers.UnoObjectPointer;
import theBiasPlanet.unoUtilities.unoObjectsContexts.RemoteUnoObjectsContext;

public class UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor extends UnoDocumentTailor {
	private int i_targetSpreadSheetIndex;
	
	public UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor (RemoteUnoObjectsContext a_remoteUnoObjectsContext, int a_targetSpreadSheetIndex) {
		super (a_remoteUnoObjectsContext);
		i_targetSpreadSheetIndex = a_targetSpreadSheetIndex;
	}
	
	@Override
	public boolean tailor (UnoObjectPointer <XModel> a_unoDocument) {
		if (a_unoDocument. <XSpreadsheetDocument>getAddress (XSpreadsheetDocument.class) == null) {
			Publisher.logErrorInformation ("The document is not any spread sheets document.");
			return false;
		}
		else {
			UnoObjectPointer <XIndexAccess> l_spreadSheets = new UnoObjectPointer <XIndexAccess> (a_unoDocument. <XSpreadsheetDocument>getAddress (XSpreadsheetDocument.class).getSheets (), XIndexAccess.class);
			try {
				UnoObjectPointer <XSpreadsheet> l_spreadSheet = new UnoObjectPointer <XSpreadsheet> ( (XSpreadsheet) (((Any) l_spreadSheets.getAddress ().getByIndex (i_targetSpreadSheetIndex)).getObject ()));
				l_spreadSheets. <XSpreadsheets>getAddress (XSpreadsheets.class).moveByName (l_spreadSheet. <XNamed>getAddress (XNamed.class).getName (), (short) GeneralConstantsConstantsGroup.c_iterationStartNumber);
				return true;
			}
			catch (Exception l_exception) {
				Publisher.logErrorInformation (l_exception);
				return false;
			}
		}
	}
}

