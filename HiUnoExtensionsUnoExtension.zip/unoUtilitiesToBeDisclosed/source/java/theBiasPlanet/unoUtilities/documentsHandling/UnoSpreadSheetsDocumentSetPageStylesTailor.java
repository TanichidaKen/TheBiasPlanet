package theBiasPlanet.unoUtilities.documentsHandling;

import java.util.HashMap;
import java.util.HashSet;
import com.sun.star.beans.PropertyVetoException;
import com.sun.star.beans.UnknownPropertyException;
import com.sun.star.beans.XPropertySet;
import com.sun.star.container.NoSuchElementException;
import com.sun.star.container.XIndexAccess;
import com.sun.star.container.XNameContainer;
import com.sun.star.frame.XModel;
import com.sun.star.lang.IndexOutOfBoundsException;
import com.sun.star.lang.WrappedTargetException;
import com.sun.star.style.XStyle;
import com.sun.star.style.XStyleFamiliesSupplier;
import com.sun.star.sheet.XSpreadsheetDocument;
import com.sun.star.sheet.XSpreadsheets2;
import com.sun.star.uno.AnyConverter;
import com.sun.star.uno.XInterface;
import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.coreUtilities.messagingHandling.Publisher;
import theBiasPlanet.unoUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.*;
import theBiasPlanet.unoUtilities.documentsHandling.UnoDocumentTailor;
import theBiasPlanet.unoUtilities.pointers.UnoObjectPointer;
import theBiasPlanet.unoUtilities.unoDataHandling.UnoDatumConverter;
import theBiasPlanet.unoUtilities.unoObjectsContexts.RemoteUnoObjectsContext;

public class UnoSpreadSheetsDocumentSetPageStylesTailor extends UnoDocumentTailor {
	private HashMap <String, Object> i_pageStylePropertyNameToPropertyValueMap = null;
	public UnoSpreadSheetsDocumentSetPageStylesTailor (RemoteUnoObjectsContext a_objectsContext, HashMap <String, Object> a_pageStylePropertyNameToPropertyValueMap) {
		super (a_objectsContext);
		i_pageStylePropertyNameToPropertyValueMap = a_pageStylePropertyNameToPropertyValueMap;
	}
	
	@Override
	public boolean tailor (UnoObjectPointer <XModel> a_unoDocument) {
		if (a_unoDocument. <XSpreadsheetDocument>getAddress (XSpreadsheetDocument.class) == null) {
			Publisher.logErrorInformation ("The document is not any spread sheets document.");
			return false;
		}
		else {
			try {
				UnoObjectPointer <XNameContainer> l_pageStyles = new UnoObjectPointer <XNameContainer> ( (XNameContainer) AnyConverter.toObject (XNameContainer.class , a_unoDocument. <XStyleFamiliesSupplier>getAddress (XStyleFamiliesSupplier.class).getStyleFamilies ().getByName (UnoStylesFamiliesConstantsGroup.c_unoPageStylesFamily.c_name)));
				String l_pageStyleName = null;
				HashSet <String> l_processedPageStyleNamesSet = new HashSet <String> ();
				UnoObjectPointer <XPropertySet> l_pageStyle = null;
				UnoObjectPointer <XSpreadsheets2> l_unoSpreadSheets = new UnoObjectPointer <XSpreadsheets2> (a_unoDocument. <XSpreadsheetDocument>getAddress (XSpreadsheetDocument.class).getSheets (), XSpreadsheets2.class);
				int l_numberOfSheets = l_unoSpreadSheets. <XIndexAccess>getAddress (XIndexAccess.class).getCount ();
				UnoObjectPointer <XPropertySet> l_unoSpreadSheet = null;
				for (int l_sheetIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber; l_sheetIndex < l_numberOfSheets; l_sheetIndex ++) {
					l_unoSpreadSheet = new UnoObjectPointer <XPropertySet> ( (XInterface) UnoDatumConverter.getObject (l_unoSpreadSheets. <XIndexAccess>getAddress (XIndexAccess.class).getByIndex (l_sheetIndex)), XPropertySet.class);
					l_pageStyleName = (String) l_unoSpreadSheet.getAddress ().getPropertyValue (UnoSpreadSheetPropertyNamesSet.c_pageStyleName_string);
					if (l_processedPageStyleNamesSet.contains (l_pageStyleName)) {
						continue;
					}
					else {
						l_pageStyle = new UnoObjectPointer <XPropertySet> ( (XStyle) (AnyConverter.toObject (XStyle.class, l_pageStyles.getAddress ().getByName (l_pageStyleName))), XPropertySet.class);
						for (HashMap.Entry <String, Object> l_pageStylePropertyNameToPropertyValueMapEntry: i_pageStylePropertyNameToPropertyValueMap.entrySet ()) {
							l_pageStyle.getAddress ().setPropertyValue (l_pageStylePropertyNameToPropertyValueMapEntry.getKey (), l_pageStylePropertyNameToPropertyValueMapEntry.getValue ());
						}
						l_processedPageStyleNamesSet.add (l_pageStyleName);
					}
				}
			}
			catch (NoSuchElementException | UnknownPropertyException | WrappedTargetException | PropertyVetoException | IndexOutOfBoundsException l_exception) {
				// Supposed not to happen.
			}
			return true;
		}
	}
}

