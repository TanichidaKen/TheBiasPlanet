package theBiasPlanet.hiConsoleJavaUnoClients.programs;

import java.time.LocalDateTime;
import theBiasPlanet.coreUtilities.messaging.Publisher;
import theBiasPlanet.unoUtilities.connectionsHandling.UnoConnection;
import theBiasPlanet.unoUtilities.connectionsHandling.UnoConnectionConnector;
import theBiasPlanet.unoUtilities.programsHandling.UnoProcessEnvironment;
import theBiasPlanet.unoUtilities.documentsHandling.textDocumentsHandling.UnoTextDocument;

public class HiConsoleJavaUnoClients {
	public static void main (String [] a_arguments) {
		try {
			if (a_arguments.length != 2) {
				throw new Exception ("The arguments have to be these.\nThe argument 1: the server url like 'socket,host=localhost,port=2002,tcpNoDelay=1;urp;StarOffice.ComponentContext'\nThe argument 2: the url of the file to be opened like ('file://${HOME}/myData/development/hiConsoleJavaUnoClients/execution/HiConsoleJavaUnoClientsTests.odt')");
			}
			String l_serverUrl = a_arguments [0];
			String l_openedFileUrl = a_arguments [1];
			UnoProcessEnvironment l_localUnoProcessEnvironment = new UnoProcessEnvironment (LocalDateTime.now ().toString (), null);
			UnoConnectionConnector l_unoConnectionConnector = new UnoConnectionConnector (l_localUnoProcessEnvironment.getLocalObjectsContext ());
			UnoConnection l_unoConnection = l_unoConnectionConnector.connect (l_serverUrl, null);
			UnoTextDocument l_unoTextDocument = UnoTextDocument.openTextDocumentFile (l_unoConnection.getRemoteObjectsContext (), l_openedFileUrl, false);
			l_unoTextDocument.close ();
			l_unoConnection.disconnect ();
		}
		catch (Exception l_exception) {
			Publisher.logErrorInformation (l_exception);
			System.exit (1);
		}
	}
}
