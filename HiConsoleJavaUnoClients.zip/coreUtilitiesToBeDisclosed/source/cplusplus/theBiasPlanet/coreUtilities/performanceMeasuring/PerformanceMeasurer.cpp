#include "theBiasPlanet/coreUtilities/performanceMeasuring/PerformanceMeasurer.hpp"

namespace theBiasPlanet {
	namespace coreUtilities {
		namespace performanceMeasuring {
			void PerformanceMeasurer::setStartTime () {
				s_startTime = steady_clock::now ();
			}
			
			steady_clock::rep PerformanceMeasurer::getElapseTimeInNanoSeconds () {
				return duration_cast <nanoseconds> (steady_clock::now () - s_startTime).count ();
			}
						
			steady_clock::rep PerformanceMeasurer::getElapseTimeInMicroSeconds () {
				return duration_cast <microseconds> (steady_clock::now () - s_startTime).count ();
			}
		}
	}
}

