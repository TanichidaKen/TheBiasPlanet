#include "theBiasPlanet/coreUtilities/constantsGroups/RegularExpressionsConstantsGroup.hpp"

namespace theBiasPlanet {
	namespace coreUtilities {
		namespace constantsGroups {
			regex const RegularExpressionsConstantsGroup::c_cProgramTraceOutputLineRegularExpression ("(#.*: )(.*)\\((.*)\\+0x(.*)\\) \\[(.*)\\] (.*)");
			regex const RegularExpressionsConstantsGroup::c_nmOutputLineRegularExpression ("(.*) (.*) (.*)");
			regex const RegularExpressionsConstantsGroup::c_addr2lineOutputSecondLineRegularExpression ("(.*):(.*)");
			regex const RegularExpressionsConstantsGroup::c_numbersRegularExpression ("^(\\d*|\\d{1,3}(,\\d{3})*)(\\.\\d+)?([eE][-+]?\\d+)?$");
			regex const RegularExpressionsConstantsGroup::c_javaPackageDelimiterRegularExpression ("\\.");
			regex const RegularExpressionsConstantsGroup::c_windowsDirectoryDelimiterRegularExpression ("\\\\");
			regex const RegularExpressionsConstantsGroup::c_wordRegularExpression ("(\\w+)");
			regex const RegularExpressionsConstantsGroup::c_termRegularExpression ("(\\S+)");
			regex const RegularExpressionsConstantsGroup::c_doubleQuotedTermRegularExpression ("\"(\\S+)\"");
		}
	}
}


