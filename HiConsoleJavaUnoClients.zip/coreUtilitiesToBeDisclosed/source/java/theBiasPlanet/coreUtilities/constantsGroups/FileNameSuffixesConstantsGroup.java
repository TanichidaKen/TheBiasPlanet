package theBiasPlanet.coreUtilities.constantsGroups;

public interface FileNameSuffixesConstantsGroup {
	String c_xmlFileNameSuffix = "xml";
	String c_styleSheetFileNameSuffix = "xslt";
	String c_jarFileNameSuffix = "jar";
	String c_javaFileNameSuffix = "java";
}

