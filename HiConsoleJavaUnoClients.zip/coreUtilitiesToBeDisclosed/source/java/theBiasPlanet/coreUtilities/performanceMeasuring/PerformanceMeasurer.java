package theBiasPlanet.coreUtilities.performanceMeasuring;

public final class PerformanceMeasurer {
	private static long s_startTime;
	
	public static void setStartTime () {
		s_startTime = System.nanoTime ();
	}
	
	public static long getElapseTimeInNanoSeconds () {
		return System.nanoTime () - s_startTime;
	}
	
	public static long getElapseTimeInMicroSeconds () {
		return (System.nanoTime () - s_startTime) / 1000;
	}
}

