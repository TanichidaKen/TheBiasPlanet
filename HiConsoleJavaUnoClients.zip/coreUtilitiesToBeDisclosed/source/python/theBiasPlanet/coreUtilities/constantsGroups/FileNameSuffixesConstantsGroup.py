
class FileNameSuffixesConstantsGroup:
	c_xmlFileNameSuffix: str = "xml"
	c_styleSheetFileNameSuffix: str = "xslt"
	c_jarFileNameSuffix: str = "jar"
	c_javaFileNameSuffix: str = "java"
	c_saveFileNameSuffix: str = "save"

