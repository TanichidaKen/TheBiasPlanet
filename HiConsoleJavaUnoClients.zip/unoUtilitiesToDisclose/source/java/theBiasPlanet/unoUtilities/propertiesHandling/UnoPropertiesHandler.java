package theBiasPlanet.unoUtilities.propertiesHandling;

import java.util.List;
import java.util.ArrayList;
import com.sun.star.beans.PropertyValue;
import theBiasPlanet.coreUtilities.constantsGroups.*;

public class UnoPropertiesHandler {
	public static ArrayList <PropertyValue> buildPropertyNameValuePairs (List <String> p_propertyNames, List <Object> p_propertyValues) {
		ArrayList <PropertyValue> l_propertyNameValuePairs = new ArrayList <PropertyValue> ();
		int l_propertyIndex = GeneralConstantsConstantsGroup.c_iterationStartingNumber;
		for (String l_propertyName: p_propertyNames) {
			PropertyValue l_propertyNameValuePair = new PropertyValue ();
			l_propertyNameValuePair.Name = l_propertyName;
			l_propertyNameValuePair.Value = p_propertyValues.get (l_propertyIndex);
			l_propertyNameValuePairs.add (l_propertyNameValuePair);
			l_propertyIndex ++;
		}
		return l_propertyNameValuePairs;
	}
}

