package theBiasPlanet.unoUtilities.connectionsHandling;

import java.util.List;
import com.sun.star.bridge.XBridge;
import com.sun.star.lang.XEventListener;
import com.sun.star.lang.XComponent;
import com.sun.star.lang.EventObject;
import com.sun.star.uno.UnoRuntime;
import theBiasPlanet.coreUtilities.messaging.Publisher;
import theBiasPlanet.unoUtilities.connectionsHandling.UnoObjectsContext;

public class UnoConnection implements XEventListener {
	private UnoObjectsContext i_remoteObjectsContext;
	private XComponent i_bridgeInXComponent;
	private List <UnoConnectionEventsListener> i_eventListeners;
	
	UnoConnection (UnoObjectsContext a_remoteObjectsContext, XBridge a_bridgeInXBridge, List <UnoConnectionEventsListener> a_eventListeners) {
		i_remoteObjectsContext = a_remoteObjectsContext;
		i_bridgeInXComponent = (XComponent) UnoRuntime.queryInterface (XComponent.class, a_bridgeInXBridge);
		i_eventListeners = a_eventListeners;
		i_bridgeInXComponent.addEventListener (this);
		EventObject l_event = new EventObject (this);
		if (i_eventListeners != null) {
			for (UnoConnectionEventsListener l_eventListener: i_eventListeners){
				l_eventListener.connected (l_event);
			}
		}
	}
	
	public final UnoObjectsContext getRemoteObjectsContext () {
		return i_remoteObjectsContext;
	}
	
	public final void disconnect () {
		if (i_bridgeInXComponent != null) {
			i_bridgeInXComponent.dispose ();
		}
	}
	
	@Override
	public final void disposing (EventObject a_event) {
		Publisher.logNormalInformation (a_event.Source.toString ());
		a_event.Source = this;
		if (i_eventListeners != null) {
			for (UnoConnectionEventsListener l_listener: i_eventListeners) {
				l_listener.disconnected (a_event);
			}
		}
		i_remoteObjectsContext = null;
		i_bridgeInXComponent = null;
		i_eventListeners = null;
	}
}

