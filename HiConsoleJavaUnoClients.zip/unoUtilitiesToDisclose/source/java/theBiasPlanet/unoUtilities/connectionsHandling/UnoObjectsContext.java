package theBiasPlanet.unoUtilities.connectionsHandling;

import java.util.Map;
import com.sun.star.uno.XComponentContext;
import com.sun.star.lang.XMultiComponentFactory;
import theBiasPlanet.unoUtilities.constantsGroups.*;

public class UnoObjectsContext implements XComponentContext {
	private XComponentContext i_originalObjectsContextInXComponentContext;
	private Map <String, Object> i_extraNameToValueMap;
	
	public UnoObjectsContext (XComponentContext a_originalObjectsContextInXComponentContext, Map <String, Object> a_extraNameToValueMap) throws com.sun.star.uno.Exception {
		if (a_originalObjectsContextInXComponentContext == null) {
			throw new com.sun.star.uno.Exception (UnoMessagesConstantsGroup.c_objectsContextNotSpecified);
		}
		i_originalObjectsContextInXComponentContext = a_originalObjectsContextInXComponentContext;
		i_extraNameToValueMap = a_extraNameToValueMap;
	}
	
	@Override
	public final Object getValueByName (String a_name) {
		if (i_extraNameToValueMap != null && i_extraNameToValueMap.containsKey (a_name)) {
			return i_extraNameToValueMap.get (a_name);
		}
		return i_originalObjectsContextInXComponentContext.getValueByName (a_name);
	}
	
	@Override
	public final XMultiComponentFactory getServiceManager () {
		return i_originalObjectsContextInXComponentContext.getServiceManager ();
	}
	
	public final boolean isFromSameOrigin (UnoObjectsContext a_unoObjectsContext) {
		if ((a_unoObjectsContext ==  null) || (i_extraNameToValueMap.get (UnoObjectsContextPropertyNamesConstantsGroup.c_identification) == null)) {
			return false;
		}
		if (i_extraNameToValueMap.get (UnoObjectsContextPropertyNamesConstantsGroup.c_identification).equals (a_unoObjectsContext.getValueByName (UnoObjectsContextPropertyNamesConstantsGroup.c_identification))) {
			return true;
		}
		else {
			return false;
		}
	}
}

