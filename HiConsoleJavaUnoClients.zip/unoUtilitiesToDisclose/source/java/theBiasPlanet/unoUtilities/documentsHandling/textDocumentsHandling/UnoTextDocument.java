package theBiasPlanet.unoUtilities.documentsHandling.textDocumentsHandling;

import com.sun.star.lang.XComponent;
import com.sun.star.uno.UnoRuntime;
import com.sun.star.text.XTextDocument;
import theBiasPlanet.unoUtilities.connectionsHandling.UnoObjectsContext;
import theBiasPlanet.unoUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.documentsHandling.UnoDocument;

public class UnoTextDocument extends UnoDocument {
	private XTextDocument i_textDocumentInXTextDocument;
	
	public UnoTextDocument (UnoObjectsContext a_objectsContext, XComponent a_textDocumentInXComponent) throws Exception {
		super (a_objectsContext, a_textDocumentInXComponent);
		i_textDocumentInXTextDocument = (XTextDocument) UnoRuntime.queryInterface (XTextDocument.class, a_textDocumentInXComponent);
		if (i_textDocumentInXTextDocument == null) {
			throw new Exception (UnoMessagesConstantsGroup.c_isNotTextDocument);
		}
	}
	
	public static UnoTextDocument createTextDocument (UnoObjectsContext a_objectsContext, boolean a_hiddenly) throws Exception, com.sun.star.io.IOException {
		return new UnoTextDocument (a_objectsContext, UnoDocument.createUnoDocumentOrOpenUnoDocumentFile (a_objectsContext, UnoSpecialFileUrlsConstantsGroup.c_writerNewDocument, a_hiddenly));
	}
	
	public static UnoTextDocument openTextDocumentFile (UnoObjectsContext a_objectsContext, String a_fileUrl, boolean a_hiddenly) throws Exception, com.sun.star.io.IOException {
		return new UnoTextDocument (a_objectsContext, UnoDocument.createUnoDocumentOrOpenUnoDocumentFile (a_objectsContext, a_fileUrl, a_hiddenly));
	}
}

