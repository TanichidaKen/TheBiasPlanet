namespace theBiasPlanet {
	namespace unoUtilities {
		namespace unoDataHandling {
			using System;
			using uno;
			
			public class UnoDatumConverter {
				public static Object getObject (Object a_originalObject) {
					if (a_originalObject == null) {
						return null;
					}
					else {
						if (a_originalObject is Any) {
							return ( (Any) a_originalObject).Value;
						}
						else {
							return a_originalObject;
						}
					}
				}
				
				public static Any getAny (Object a_originalObject) {
					return a_originalObject != null ? new Any (a_originalObject.GetType (), a_originalObject): new Any ();
				}
			}
		}
	}
}

