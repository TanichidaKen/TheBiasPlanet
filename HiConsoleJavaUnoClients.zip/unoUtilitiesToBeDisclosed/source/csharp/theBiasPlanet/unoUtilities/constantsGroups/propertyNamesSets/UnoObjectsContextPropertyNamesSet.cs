namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			namespace propertyNamesSets {
				using System;
				
				public static class UnoObjectsContextPropertyNamesSet {
					public const String c_identification_string = "identification";
				}
			}
		}
	}
}

