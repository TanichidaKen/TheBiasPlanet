namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			using System;
			
			public static class UnoSingletonNamesConstantsGroup {
				public const String c_com_sun_star_frame_theGlobalEventBroadcaster = "/singletons/com.sun.star.frame.theGlobalEventBroadcaster";
			}
		}
	}
}

