#ifndef __theBiasPlanet_unoUtilities_constantsGroups_UnoDocumentEventNamesConstantsGroup_hpp__
	#define __theBiasPlanet_unoUtilities_constantsGroups_UnoDocumentEventNamesConstantsGroup_hpp__
	
	#include <string>
	#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	
	namespace theBiasPlanet {
		namespace unoUtilities {
			namespace constantsGroups {
				class __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ UnoDocumentEventNamesConstantsGroup {
					public:
						static string const c_documentDatumLoaded;
						static string const c_titleChanged;
						static string const c_focused;
						static string const c_viewCreated;
						static string const c_pagesCountChanged;
						static string const c_frameDatumLoaded;
						static string const c_layouted;
						static string const c_preparingViewClosing;
						static string const c_preparingFrameUnloading;
						static string const c_viewClosed;
						static string const c_frameUnloaded;
						static string const c_unfocused;
				};
			}
		}
	}
#endif


