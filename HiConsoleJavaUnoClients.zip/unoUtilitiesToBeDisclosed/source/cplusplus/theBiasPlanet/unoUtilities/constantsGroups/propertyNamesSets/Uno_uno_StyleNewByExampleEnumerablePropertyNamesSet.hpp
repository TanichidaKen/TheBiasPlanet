#ifndef __theBiasPlanet_unoUtilities_constantsGroups_propertyNamesSets_Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet_hpp__
	#define __theBiasPlanet_unoUtilities_constantsGroups_propertyNamesSets_Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet_hpp__
	
	#include "theBiasPlanet/coreUtilities/constantsGroups/BaseEnumerableConstantsGroup.hpp"
	#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/UnoPropertyNamesSet.hpp"
	#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::theBiasPlanet::coreUtilities::constantsGroups;
	
	namespace theBiasPlanet {
		namespace unoUtilities {
			namespace constantsGroups {
				namespace propertyNamesSets {
					class __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet : public BaseEnumerableConstantsGroup <string>, public UnoPropertyNamesSet {
						private:
							Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet ();
						public:
							static string const c_styleName_string;
							static string const c_styleFamilyKey_short;
							static Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet c_instance;
					};
				}
			}
		}
	}
#endif

