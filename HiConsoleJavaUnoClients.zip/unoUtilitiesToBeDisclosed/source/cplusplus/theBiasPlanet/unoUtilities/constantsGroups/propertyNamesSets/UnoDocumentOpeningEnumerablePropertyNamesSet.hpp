#ifndef __theBiasPlanet_unoUtilities_constantsGroups_propertyNamesSets_UnoDocumentOpeningEnumerablePropertyNamesSet_hpp__
	#define __theBiasPlanet_unoUtilities_constantsGroups_propertyNamesSets_UnoDocumentOpeningEnumerablePropertyNamesSet_hpp__
	
	#include "theBiasPlanet/coreUtilities/constantsGroups/BaseEnumerableConstantsGroup.hpp"
	#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/UnoPropertyNamesSet.hpp"
	#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::theBiasPlanet::coreUtilities::constantsGroups;
	
	namespace theBiasPlanet {
		namespace unoUtilities {
			namespace constantsGroups {
				namespace propertyNamesSets {
					class __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ UnoDocumentOpeningEnumerablePropertyNamesSet : public BaseEnumerableConstantsGroup <string>, public UnoPropertyNamesSet {
						private:
							UnoDocumentOpeningEnumerablePropertyNamesSet ();
						public:
							static string const c_readOnly_Boolean;
							static string const c_hidden_Boolean;
							static string const c_openNewView_Boolean;
							static string const c_silent_Boolean;
							static UnoDocumentOpeningEnumerablePropertyNamesSet const c_instance;
					};
				}
			}
		}
	}
#endif

