#include "theBiasPlanet/unoUtilities/constantsGroups/UnoSpecialFileUrlsConstantsGroup.hpp"

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
					string const UnoSpecialFileUrlsConstantsGroup::c_calcNewDocument = "private:factory/scalc";
					string const UnoSpecialFileUrlsConstantsGroup::c_writerNewDocument = "private:factory/swriter";
		}
	}
}

