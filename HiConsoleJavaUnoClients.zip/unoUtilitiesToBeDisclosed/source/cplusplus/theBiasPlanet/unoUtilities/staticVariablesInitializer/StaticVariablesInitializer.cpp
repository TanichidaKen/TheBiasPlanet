/*
#include "theBiasPlanet/unoUtilities/constantsGroups/UnoDispatchSlotsConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/Uno_uno_GoToCellEnumerablePropertyNamesSet.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet.hpp"
*/

/*
using namespace ::theBiasPlanet::unoUtilities::constantsGroups::propertyNamesSets;

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			namespace propertyNamesSets {
*/
				/*
				string const Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet::c_styleName_String = "Param";
				string const Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet::c_styleFamilyKey_Short = "Family";
				Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet::c_instance;
				*/
/*
			}
*/
			//UnoDispatchSlotsConstantsGroup::BaseDispatchSlot const UnoDispatchSlotsConstantsGroup::c__uno_StyleNewByExample (string (".uno:StyleNewByExample"), optional <BaseEnumerableConstantsGroup <string>> (Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet::c_instance));
			//UnoDispatchSlotsConstantsGroup::BaseDispatchSlot const UnoDispatchSlotsConstantsGroup::c__uno_GoToCell (string (".uno:GoToCell"), optional <BaseEnumerableConstantsGroup <string>> (Uno_uno_GoToCellEnumerablePropertyNamesSet::c_instance));
			/*
					// This slot is removed.
					static BaseDispatchSlot const c__uno_Cells = new BaseDispatchSlot (".uno:Cells", Uno_uno_CellsEnumerablePropertyNamesSet.c_instance);
					// This slot is removed.
					static BaseDispatchSlot const c__uno_Range = new BaseDispatchSlot (".uno:Range", Uno_uno_RangeEnumerablePropertyNamesSet.c_instance);
					// This slot is removed.
					static BaseDispatchSlot const c__uno_CellText = new BaseDispatchSlot (".uno:CellText", Uno_uno_CellTextEnumerablePropertyNamesSet.c_instance);
					// This slot is removed.
					static BaseDispatchSlot const c__uno_Selection = new BaseDispatchSlot (".uno:Selection", null);
					// This slot is removed.
					static BaseDispatchSlot const c__uno_ActiveCell = new BaseDispatchSlot (".uno:ActiveCell", null);
					// This slot is removed.
					static BaseDispatchSlot const c__uno_ActiveTable = new BaseDispatchSlot (".uno:ActiveTable", null);
					// This slot is removed.
					static BaseDispatchSlot const c__uno_Tables = new BaseDispatchSlot (".uno:Tables", null);
					// This slot is removed.
					static BaseDispatchSlot const c__uno_DataPilotTables = new BaseDispatchSlot (".uno:DataPilotTables", null);
					static BaseDispatchSlot const c__uno_Position = new BaseDispatchSlot (".uno:Position", null);
					static BaseDispatchSlot const c__uno_GoToCurrentCell = new BaseDispatchSlot (".uno:GoToCurrentCell", null);
					static BaseDispatchSlot const c__uno_StatusDocPos = new BaseDispatchSlot (".uno:StatusDocPos", null);
					static BaseDispatchSlot const c__uno_StatusSelectionMode = new BaseDispatchSlot (".uno:StatusSelectionMode", null);
					static BaseDispatchSlot const c__uno_StatusSelectionModeExp = new BaseDispatchSlot (".uno:StatusSelectionModeExp", null);
					static BaseDispatchSlot const c__uno_StatusSelectionModeExt = new BaseDispatchSlot (".uno:StatusSelectionModeExt", null);
					static BaseDispatchSlot const c__uno_StatusSelectionModeNorm = new BaseDispatchSlot (".uno:StatusSelectionModeNorm", null);
					static BaseDispatchSlot const c__uno_SelectData = new BaseDispatchSlot (".uno:SelectData", null);
					static BaseDispatchSlot const c__uno_SetInputMode = new BaseDispatchSlot (".uno:SetInputMode", null);
					static BaseDispatchSlot const c__uno_JumpToPreviousCell = new BaseDispatchSlot (".uno:JumpToPreviousCell", null);
					static BaseDispatchSlot const c__uno_DataSelect = new BaseDispatchSlot (".uno:DataSelect", null);
					static BaseDispatchSlot const c__uno_ExternalEdit = new BaseDispatchSlot (".uno:ExternalEdit", null);
					static BaseDispatchSlot const c__uno_PasteSpecial = new BaseDispatchSlot (".uno:PasteSpecial", Uno_uno_PasteSpecialEnumerablePropertyNamesSet.c_instance);
					*/

/*
		}
	}
}
*/

