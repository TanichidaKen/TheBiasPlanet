package theBiasPlanet.unoUtilities.constantsGroups;

public interface UnoObjectsContextPropertyNamesConstantsGroup {
	String c_identification = "identification";
}

