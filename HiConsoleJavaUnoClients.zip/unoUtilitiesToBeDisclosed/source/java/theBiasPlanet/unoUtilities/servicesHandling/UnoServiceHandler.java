package theBiasPlanet.unoUtilities.servicesHandling;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;
import com.sun.star.uno.Type;
import com.sun.star.uno.TypeClass;
import com.sun.star.uno.UnoRuntime;
import com.sun.star.uno.XInterface;
import com.sun.star.lang.XMultiServiceFactory;
import com.sun.star.lang.XSingleComponentFactory;
import com.sun.star.lang.XSingleServiceFactory;
import com.sun.star.registry.XRegistryKey;
import theBiasPlanet.coreUtilities.collectionsHandling.ArraysFactory;
import theBiasPlanet.coreUtilities.xmlDataHandling.XmlDatumHandler;
import theBiasPlanet.unoUtilities.connectionsHandling.UnoObjectsContext;

public final class UnoServiceHandler {
	private UnoServiceHandler () {
	}
	
	public static Object getServiceInstance (UnoObjectsContext a_objectsContext, String a_serviceName, Class a_targetClass, List <Object> a_arguments) throws com.sun.star.uno.Exception {
		Object l_serviceInstance = null;
		Object l_targetProxy = null;
		if (a_arguments == null) {
			l_serviceInstance = a_objectsContext.getServiceManager ().createInstanceWithContext (a_serviceName, a_objectsContext);
		}
		else {
			l_serviceInstance = a_objectsContext.getServiceManager ().createInstanceWithArgumentsAndContext (a_serviceName, ArraysFactory. <Object>createArray (Object.class, a_arguments), a_objectsContext);
		}
		if (l_serviceInstance != null && a_targetClass != null && XInterface.class.isAssignableFrom (a_targetClass)) {
			l_targetProxy =  UnoRuntime.queryInterface (new Type (a_targetClass.getName (), TypeClass.INTERFACE), l_serviceInstance);
		}
		return l_targetProxy;
	}
	
	public static Object getServiceInstance (UnoObjectsContext a_objectsContext, String a_serviceName, Class a_targetClass) throws com.sun.star.uno.Exception {
		return getServiceInstance (a_objectsContext, a_serviceName, a_targetClass, null);
	}
	
	public static List <XSingleComponentFactory>  getSingleServiceFactories (String a_settingFileUrl) throws IOException, ParserConfigurationException, SAXException, ClassNotFoundException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {
		List <XSingleComponentFactory> l_singleServiceFactories = new ArrayList <XSingleComponentFactory> ();
		Map <String, List <String>> l_servicesProviderNameToComponentNamesMap = XmlDatumHandler.get2TierAttributeValues (a_settingFileUrl);
		if (l_servicesProviderNameToComponentNamesMap == null) {
			return l_singleServiceFactories;
		}
		for (Map.Entry <String, List <String>> l_servicesProviderNameToComponentNamesMapEntry: l_servicesProviderNameToComponentNamesMap.entrySet ()) {
			Class <?> l_servicesProvider = null;
			Method l___getComponentFactoryMethod = null;
			Method l___getServiceFactoryMethod = null;
			XSingleComponentFactory l_singleServicesFactoryInXSingleComponentFactory = null;
			l_servicesProvider = Class.forName (l_servicesProviderNameToComponentNamesMapEntry.getKey ());
			if (l_servicesProvider == null) {
				continue;
			}
			try {
				l___getComponentFactoryMethod = l_servicesProvider.getMethod ("__getComponentFactory", String.class);
			}
			catch (NoSuchMethodException l_exception) {
			}
			if (l___getComponentFactoryMethod == null) {
				l___getServiceFactoryMethod = l_servicesProvider.getMethod ("__getServiceFactory", String.class, XMultiServiceFactory.class, XRegistryKey.class);
			}
			for (String l_componentName: l_servicesProviderNameToComponentNamesMapEntry.getValue ()) {
				if (l___getComponentFactoryMethod != null) {
					l_singleServicesFactoryInXSingleComponentFactory = (XSingleComponentFactory) l___getComponentFactoryMethod.invoke (null, new Object [] {l_componentName});
				}
				else if (l___getServiceFactoryMethod != null) {
					l_singleServicesFactoryInXSingleComponentFactory = UnoRuntime.queryInterface(XSingleComponentFactory.class, (XSingleServiceFactory) l___getServiceFactoryMethod.invoke (null, new Object [] {l_componentName, null, null}));
				}
				
				if (l_singleServicesFactoryInXSingleComponentFactory == null) {
					continue;
				}
				l_singleServiceFactories.add (l_singleServicesFactoryInXSingleComponentFactory);
			}
		}
		return l_singleServiceFactories;
	}
}

