
class UnoFileStoringFilterNamesConstantsGroup:
	c_openDocumentWordProcessingFilterName: str = "writer8"
	c_openDocumentSpreadsheetsFilterName: str = "calc8"
	c_openDocumentPresentationsFilterName: str = "impress8"
	c_microsoftWord97FileFilterName: str = "MS Word 97"
	c_microsoftWord2007XmlFilterName: str = "MS Word 2007 XML"
	c_microsoftExcel97FilterName: str = "MS Excel 97"
	c_microsoftExcel2007XmlFilterName: str = "Calc MS Excel 2007 XML"
	c_microsoftPowerPoint97FilterName: str = "MS PowerPoint 97"
	c_microsoftPowerPoint2007XmlFilterName: str = "Impress MS PowerPoint 2007 XML"
	c_csvFileFilterName: str = "Text - txt - csv (StarCalc)"

