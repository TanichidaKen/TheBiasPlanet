
class UnoMessagesConstantsGroup:
	c_remoteInstanceNotProvided: str = "The server didn't provide the remote instance."
	c_cellNotString: str = "The cell isn't a string value cell."
	c_unoDocumentNotSpecified: str = "The UNO document isn't specified."
	c_isNotSpreadSheetsDocument: str = "The specified UNO component is not a spread sheets document."
	c_isNotTextDocument: str = "The specified UNO component is not a text document."
	c_spreadSheetsDocumentNotSpecified:str = "The spread sheets document isn't specified."
	c_spreadSheetNotSpecified: str = "The spread sheet isn't specified."
	c_unoObjectsContextNotCreated: str = "Couldn't create the component context."
	c_unoObjectsContextNotSpecified: str = "The component context isn't specified."
	c_noCurrentSpreadSheetCell: str = "there is no current spread sheet cell."

