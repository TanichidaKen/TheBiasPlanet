
class UnoObjectsContextPropertyNamesConstantsGroup:
	c_identification: str = "identification"

