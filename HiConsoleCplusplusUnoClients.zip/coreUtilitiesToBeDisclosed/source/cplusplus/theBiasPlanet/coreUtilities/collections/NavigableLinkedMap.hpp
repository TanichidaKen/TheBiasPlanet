#ifndef __theBiasPlanet_coreUtilities_collections_NavigableLinkedMap_hpp__
#define __theBiasPlanet_coreUtilities_collections_NavigableLinkedMap_hpp__

#include <initializer_list>
#include <map>
#include <mutex>
#include <optional>

using namespace ::std;

namespace theBiasPlanet {
	namespace coreUtilities {
		namespace collections {
			template <typename T, typename U, typename W = less <T>> class NavigableLinkedMap {
				public:
					typedef T key_type;
					typedef U mapped_type;
					typedef W key_compare;
				private:
					class Links {
						private:
							optional <key_type> i_previousKey;
							optional <key_type> i_nextKey;
						public:
							Links ();
							Links (optional <key_type> a_previousKey, optional <key_type> a_nextKey);
							optional <key_type> getPreviousKey ();
							void setPreviousKey (optional <key_type> a_previousKey);
							optional <key_type> getNextKey ();
							void setNextKey (optional <key_type> a_nextKey);
					};
				public:
					typedef pair <key_type const, mapped_type> value_type;
					class ValueComparer {
						private:
							key_compare i_keyComparer;
						public:
							ValueComparer (key_compare a_keyComparer);
							bool operator () (value_type const & a_keyValuePair1, value_type const & a_keyValuePair2) const;
					};
					typedef ValueComparer value_compare;
					typedef allocator <value_type> allocator_type;
					typedef value_type & reference;
					typedef value_type const & const_reference;
					typedef value_type * pointer;
					typedef value_type const * const_pointer;
					class BaseIterator {
						protected:
							map <key_type, mapped_type, key_compare> * i_keyToValueMap;
							map <key_type, Links, key_compare> * i_keyToLinksMap;
							optional <key_type> * i_firstKey;
							optional <key_type> * i_lastKey;
							optional <key_type> i_currentKey;
							virtual void goToNextElement ();
							virtual void goToPreviousElement ();
						public:
							typedef ptrdiff_t difference_type;
							typedef bidirectional_iterator_tag iterator_category;
							BaseIterator (NavigableLinkedMap <key_type, mapped_type, key_compare> const & a_navigableLinkedMap, optional <key_type> a_currentKey);
							BaseIterator (BaseIterator const & a_originalIterator);
							virtual bool operator == (BaseIterator const & a_iteratorToBeCompared) const;
							virtual bool operator != (BaseIterator const & a_iteratorToBeCompared) const;
					};
					class NonConstantIterator : public BaseIterator {
						public:
							typedef pair <key_type const, mapped_type> value_type;
							typedef value_type * pointer;
							typedef value_type & reference;
							NonConstantIterator (NavigableLinkedMap <key_type, mapped_type, key_compare> const & a_navigableLinkedMap, optional <key_type> a_currentKey);
							NonConstantIterator (BaseIterator const & a_originalIterator);
							virtual NonConstantIterator & operator ++ ();
							virtual NonConstantIterator operator ++ (int);
							virtual NonConstantIterator & operator -- ();
							virtual NonConstantIterator operator -- (int);
							virtual value_type & operator * ();
							virtual value_type * operator -> ();
					};
					class ConstantIterator : public BaseIterator {
						public:
							typedef pair <key_type const, mapped_type> const value_type;
							typedef pair <key_type const, mapped_type> NonConstantvalue_type;
							typedef value_type * pointer;
							typedef value_type & reference;
							ConstantIterator (NavigableLinkedMap <key_type, mapped_type, key_compare> const & a_navigableLinkedMap, optional <key_type> a_currentKey);
							ConstantIterator (BaseIterator const & a_originalIterator);
							virtual ConstantIterator & operator ++ ();
							virtual ConstantIterator operator ++ (int);
							virtual ConstantIterator & operator -- ();
							virtual ConstantIterator operator -- (int);
							virtual value_type & operator * ();
							virtual value_type * operator -> ();
					};
					typedef NonConstantIterator iterator;
					typedef ConstantIterator const_iterator;
					typedef ::std::reverse_iterator <iterator> reverse_iterator;
					typedef ::std::reverse_iterator <const_iterator> const_reverse_iterator;
					typedef ptrdiff_t difference_type;
					typedef size_t size_type;
				private:
					map <key_type, mapped_type, key_compare> * i_keyToValueMap;
					map <key_type, Links, key_compare> * i_keyToLinksMap;
					optional <key_type> * i_firstKey;
					optional <key_type> * i_lastKey;
					mutex i_mutex;
					pair <key_type &, mapped_type &> getKeyValuePair (key_type & a_key, mapped_type & a_value);
					virtual void insertNewElementAtEnd (key_type const a_key, optional <mapped_type> a_value);
					virtual void insertNewElementAtMiddle (key_type const a_positionKey, key_type const a_key, optional <mapped_type> a_value);
					virtual void updateElement (key_type const a_key, mapped_type a_value);
				public:
					explicit NavigableLinkedMap (key_compare const & a_keysComparer = key_compare ());
					template <typename V> NavigableLinkedMap (V a_iteratorPointedAtFirstElement, V a_iteratorPointedAtLastElementNotIncluded, key_compare const & a_keysComparer = key_compare ());
					NavigableLinkedMap (initializer_list <value_type> a_initializer, key_compare const & a_keysComparer = key_compare ());
					NavigableLinkedMap (NavigableLinkedMap const & a_navigableLinkedMap);
					virtual ~NavigableLinkedMap ();
					virtual NavigableLinkedMap <T, U, W> & operator = (NavigableLinkedMap <T, U, W> const & a_navigableLinkedMap);
					virtual iterator begin ();
					virtual const_iterator begin () const;
					virtual iterator end ();
					virtual const_iterator end () const;
					virtual reverse_iterator rbegin ();
					virtual const_reverse_iterator rbegin () const;
					virtual reverse_iterator rend ();
					virtual const_reverse_iterator rend () const;
					virtual const_iterator cbegin () const noexcept;
					virtual const_iterator cend () const noexcept;
					virtual const_reverse_iterator crbegin () const noexcept;
					virtual const_reverse_iterator crend () const noexcept;
					virtual bool empty () const;
					virtual size_type size () const;
					virtual size_type max_size () const;
					virtual mapped_type & operator [] (key_type const & a_key);
					virtual mapped_type & at (key_type const & a_key);
					virtual mapped_type const & at (key_type const & a_key) const;
					virtual pair <iterator, bool> insert (value_type const & a_keyValuePair);
					virtual iterator insert (iterator a_position, value_type const & a_keyValuePair);
					// Any template method cannot be virtual only because it is decided so by the specification.
					template <typename V> void insert (V a_iteratorPointedAtFirstElement, V a_iteratorPointedAtLastElementNotIncluded);
					virtual void erase (iterator a_position);
					virtual size_type erase (key_type const & a_key);
     				virtual void erase (iterator a_iteratorPointedAtFirstElement, iterator a_iteratorPointedAtLastElementNotIncluded);
					virtual void swap (NavigableLinkedMap <T, U, W> & a_navigableLinkedMap);
					virtual void clear();
					template <typename ... V> pair <iterator, bool> emplace (V && ... a_arguments);
					template <typename ... V> iterator emplace_hint (const_iterator a_position, V && ... a_arguments);
					virtual key_compare key_comp () const;
					virtual value_compare value_comp () const;
					virtual iterator find (key_type const & a_key);
					virtual const_iterator find (key_type const & a_key) const;
					virtual size_type count (key_type const & a_key) const;
					virtual iterator lower_bound (key_type const & a_key);
					virtual const_iterator lower_bound (key_type const & a_key) const;
					virtual iterator upper_bound (key_type const & a_key);
					virtual const_iterator upper_bound (key_type const & a_key) const;
					virtual pair <const_iterator, const_iterator> equal_range (key_type const & a_key) const;
					virtual pair <iterator, iterator> equal_range (key_type const & a_key);
					virtual allocator_type get_allocator () const;
			};
		}
	}
}

#endif

