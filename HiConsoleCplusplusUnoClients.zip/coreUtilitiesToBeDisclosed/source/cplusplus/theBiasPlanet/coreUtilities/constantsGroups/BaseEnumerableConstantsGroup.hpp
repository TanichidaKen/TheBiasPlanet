#ifndef __theBiasPlanet_coreUtilities_constantsGroups_BaseEnumerableConstantsGroup_hpp__
#define __theBiasPlanet_coreUtilities_constantsGroups_BaseEnumerableConstantsGroup_hpp__

#include <list>
#include <set>
#include "theBiasPlanet/coreUtilities/collections/NavigableLinkedMap.hpp"

using namespace ::std;
using namespace ::theBiasPlanet::coreUtilities::collections;

namespace theBiasPlanet {
	namespace coreUtilities {
		namespace constantsGroups {
			template <typename T> class BaseEnumerableConstantsGroup {
				private:
					NavigableLinkedMap <string, T> i_nameToValueMap;
				protected:
				public:
					BaseEnumerableConstantsGroup (NavigableLinkedMap <string, T> a_nameToValueMap);
					set <string> getNames () const;
					list <T> getValues () const;
			};
		}
	}
}

#endif

