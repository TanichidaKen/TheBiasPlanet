#include "theBiasPlanet/coreUtilities/messaging/Publisher.hpp"
#ifdef GCC
#include <cxxabi.h>
#include <execinfo.h>
#else
#include <windows.h>
#include <process.h>
#include <dbghelp.h>
#endif
#include <signal.h>
#include <fstream>
#include <iostream>
#include <sstream>
#include <thread>
#include <wx/wx.h>

using namespace ::std;

namespace theBiasPlanet {
	namespace coreUtilities {
		namespace messaging  {
#ifdef GCC
			int const Publisher::c_processIdentification = getpid ();
#else
			int const Publisher::c_processIdentification = _getpid ();
#endif
			
			int Publisher::s_loggingLevel = 0;
					
			Publisher::Publisher () {
			}
			
			int const & Publisher::getLoggingLevel () {
				return s_loggingLevel;
			}
			
			void Publisher::setLoggingLevel (int a_loggingLevel) {
				s_loggingLevel = a_loggingLevel;
			}
			
			string Publisher::getMessage (string const & a_messageIngredient) {
				ostringstream l_messageStream;
				l_messageStream << "process id: ";
				l_messageStream << c_processIdentification;
				l_messageStream << ", method name: ";
    			int const l_numberOfStepsOfBacktrace = 5;
				size_t l_functionNameLength = 512;
				void * l_backtraceArray [l_numberOfStepsOfBacktrace];
#ifdef GCC
				size_t const l_backtraceSize = backtrace (l_backtraceArray, l_numberOfStepsOfBacktrace);
				char * * const l_symbolsList = backtrace_symbols (l_backtraceArray, l_backtraceSize);
				char * l_beginningOfName = nullptr;
				char * l_beginningOfOffset = nullptr;
				char * l_endOfOffset = nullptr;
				char * l_characterInSymbol = nullptr;
				char l_functionName [l_functionNameLength];
				int l_demanglingResultStatus = -1;
				for (int l_symbolIndex = 1; l_symbolIndex < l_backtraceSize; l_symbolIndex ++) {
					l_beginningOfName = nullptr;
					l_beginningOfOffset = nullptr;
					l_endOfOffset = nullptr;
					for (l_characterInSymbol = l_symbolsList [l_symbolIndex]; l_characterInSymbol != 0; l_characterInSymbol ++) {
						if (*l_characterInSymbol == '(') {
							l_beginningOfName = l_characterInSymbol;
						}
						else if (*l_characterInSymbol == '+') {
							l_beginningOfOffset = l_characterInSymbol;
						}
						else if (*l_characterInSymbol == ')' && (l_beginningOfOffset != 0)) {
							l_endOfOffset = l_characterInSymbol;
							break;
						}
					}
					if ( (l_beginningOfName != nullptr) && (l_beginningOfOffset != nullptr) && (l_endOfOffset != nullptr) && (l_beginningOfName < l_beginningOfOffset)) {
						*(l_beginningOfName ++) = '\0';
						*(l_beginningOfOffset ++) = '\0';
						*(l_endOfOffset ++) = '\0';
						l_functionNameLength = 512;
						abi::__cxa_demangle (l_beginningOfName, l_functionName, &l_functionNameLength, &l_demanglingResultStatus);
						if (l_demanglingResultStatus == 0) {
							if ((string (l_functionName).find ("theBiasPlanet::coreUtilities::messaging::Publisher")) == 0) {
								continue;
							}
							else {
								l_messageStream << l_symbolsList [l_symbolIndex] << " + " << l_functionName << " + " << l_beginningOfOffset;
								break;
							}
						}
						else {
							l_messageStream << l_symbolsList [l_symbolIndex] << ": " << l_beginningOfName << " () + " << l_beginningOfOffset;
							break;
						}
					}
					else {
						l_messageStream << l_symbolsList [l_symbolIndex];
						break;
					}
				}
				free (l_symbolsList);
#else
				HANDLE l_currentProcess = GetCurrentProcess ();
				SymInitialize (l_currentProcess, nullptr, TRUE);
				WORD l_backtraceSize = CaptureStackBackTrace (0, l_numberOfStepsOfBacktrace, l_backtraceArray, nullptr);
				SYMBOL_INFO * l_symbolInformation = (SYMBOL_INFO *) malloc (sizeof (SYMBOL_INFO) + (l_functionNameLength - 1) * sizeof (TCHAR));
				l_symbolInformation->MaxNameLen = l_functionNameLength;
				l_symbolInformation->SizeOfStruct = sizeof (SYMBOL_INFO);
				DWORD l_offsetFromBeginningOfLine;
				IMAGEHLP_LINE64 * l_sourceLineInformation = (IMAGEHLP_LINE64 *) malloc (sizeof (IMAGEHLP_LINE64));
				l_sourceLineInformation->SizeOfStruct = sizeof (IMAGEHLP_LINE64);
				char * l_functionName = nullptr;
				for (int l_symbolIndex = 1; l_symbolIndex < l_backtraceSize; l_symbolIndex ++) {
					DWORD64 l_address = (DWORD64) (l_backtraceArray [l_symbolIndex]);
					if (SymFromAddr (l_currentProcess, l_address, nullptr, l_symbolInformation)) {
						l_functionName = l_symbolInformation->Name;
						if ((string (l_functionName).find ("theBiasPlanet::coreUtilities::messaging::Publisher")) == 0) {
							continue;
						}
						if (SymGetLineFromAddr64 (l_currentProcess, l_address, &l_offsetFromBeginningOfLine, l_sourceLineInformation)) {
							l_messageStream << l_functionName << " (" << l_sourceLineInformation->FileName << ": " << l_sourceLineInformation->LineNumber << ")";
							break;
						}
						else {
							l_messageStream << l_functionName << " (" << ")";
							break;
						}
					}
					else {
						l_messageStream << "No symbol";
						break;
					}
				}
#endif
				l_messageStream << ", thread id: ";
				l_messageStream << this_thread::get_id ();
				l_messageStream << ", ";
				l_messageStream << a_messageIngredient;
				return l_messageStream.str ();
			}
			
			string Publisher::show (string const & a_messageIngredient) {
				string const l_message = getMessage (a_messageIngredient);
				wxMessageDialog l_messageDialog (nullptr, l_message, "Information", wxOK | wxICON_INFORMATION);
				l_messageDialog.ShowModal ();
				return l_message;
			}
			
			optional <string> Publisher::logDebugInformation (string const & a_messageIngredient) {
				if (s_loggingLevel >= 3) {
					string const l_message = getMessage (a_messageIngredient);
					cout << "Debug  : " << l_message << endl << flush;
					return l_message;
				}
				else {
					return nullopt;
				}
			}
			
			optional <string> Publisher::logNormalInformation (string const & a_messageIngredient) {
				if (s_loggingLevel >= 2) {
					string const l_message = getMessage (a_messageIngredient);
					cout << "Normal : " << l_message << endl << flush;
					return l_message;
				}
				else {
					return nullopt;
				}
			}
			
			optional <string> Publisher::logWarningInformation (string const & a_messageIngredient) {
				if (s_loggingLevel >= 1) {
					string const l_message = getMessage (a_messageIngredient);
					cout << "Warning: " << l_message << endl << flush;
					return l_message;
				}
				else {
					return nullopt;
				}
			}
			
			optional <string> Publisher::logWarningInformation (exception const & a_messageException) {
				if (s_loggingLevel >= 1) {
					string const l_message = a_messageException.what ();
					return logWarningInformation (l_message);
				}
				else {
					return nullopt;
				}
			}
			
			optional <string> Publisher::logErrorInformation (string const & a_messageIngredient) {
				if (s_loggingLevel >= 0) {
					string const l_message = getMessage (a_messageIngredient);
					cout << "Error  : " << l_message << endl << flush;
					return l_message;
				}
				else {
					return nullopt;
				}
			}
			
			optional <string> Publisher::logErrorInformation (exception const & a_messageException) {
				if (s_loggingLevel >= 0) {
					string const l_message = a_messageException.what ();
					return logErrorInformation (l_message);
				}
				else {
					return nullopt;
				}
			}
			
			void Publisher::appendToFile (string const & a_fileName, string const & a_contents) {
				try {
					ofstream l_targetFile;
					l_targetFile.open (a_fileName, ios::app);
					l_targetFile << a_contents << endl;
					l_targetFile.close ();
				}
				catch (...) {
				}
			}
		}
	}
}

