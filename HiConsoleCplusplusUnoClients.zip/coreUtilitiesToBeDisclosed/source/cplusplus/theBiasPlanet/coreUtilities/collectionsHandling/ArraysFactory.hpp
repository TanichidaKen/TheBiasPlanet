#ifndef __theBiasPlanet_coreUtilities_collectionsHandling_ArraysFactory_hpp__
#define __theBiasPlanet_coreUtilities_collectionsHandling_ArraysFactory_hpp__

#include <list>
#include "theBiasPlanet/coreUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"

using namespace ::std;

namespace theBiasPlanet {
	namespace coreUtilities {
		namespace collectionsHandling {
			class __theBiasPlanet_coreUtilities_symbolExportingOrImportingDeclarationForVisualCplusplus__ ArraysFactory {
				public:
					template <typename T> static T * createArray (T * a_targetArray, list <T> const & a_list);
			};
		}
	}
}

#endif

