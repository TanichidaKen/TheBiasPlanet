package theBiasPlanet.coreUtilities.messaging;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.management.ManagementFactory;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import javax.swing.JOptionPane;
import theBiasPlanet.coreUtilities.constantsGroups.*;

public final class Publisher {
	private static final String c_virtualMachineName = ManagementFactory.getRuntimeMXBean ().getName ();
	// 0: error, 1: error and warning, 2: error, warning, and normal, 3: error, warning, normal, and debug
	private static int s_loggingLevel = 0;
	
	private Publisher () {
	}
	
	public static int getLoggingLevel () {
		return s_loggingLevel;
	}
	
	public static void setLoggingLevel (int a_loggingLevel) {
		s_loggingLevel = a_loggingLevel;
	}
	
	public static String getMessage (String a_messageIngredient) {
		StringBuilder l_messageBuilder = new StringBuilder ("");
		StackTraceElement [] l_stackTrace = Thread.currentThread ().getStackTrace ();
		StackTraceElement l_previousMethodStackTraceElement = null;
		boolean l_pointsThisClass = false;
		for (StackTraceElement l_stackTraceElement: l_stackTrace) {
			if (l_stackTraceElement.getClassName ().equals (Publisher.class.getName ())) {
				l_pointsThisClass = true;
			}
			else {
				if (l_pointsThisClass) {
					l_previousMethodStackTraceElement = l_stackTraceElement;
					break;
				}
			}
		}
		l_messageBuilder.append ("virtual machine name: ");
		l_messageBuilder.append (c_virtualMachineName);
		l_messageBuilder.append (", class name: ");
		l_messageBuilder.append (l_previousMethodStackTraceElement.getClassName ());
		l_messageBuilder.append (", method name: ");
		l_messageBuilder.append (l_previousMethodStackTraceElement.getMethodName ());
		l_messageBuilder.append (", thread id: ");
		l_messageBuilder.append (String.format ("%d", Thread.currentThread().getId()));
		l_messageBuilder.append (", ");
		l_messageBuilder.append (a_messageIngredient);
		return l_messageBuilder.toString ();
	}
	
	public static String show (String a_messageIngredient) {
		String l_message = null;
		l_message = getMessage (a_messageIngredient);
		JOptionPane.showMessageDialog (null, l_message, "Information", JOptionPane.INFORMATION_MESSAGE);
		return l_message;
	}
	
	public static String logDebugInformation (String a_messageIngredient) {
		if (s_loggingLevel >= 3) {
			String l_message = getMessage (a_messageIngredient);
			System.out.println ("Debug  : " + l_message);
			return l_message;
		}
		else {
			return null;
		}
	}
	
	public static String logNormalInformation (String a_messageIngredient) {
		if (s_loggingLevel >= 2) {
			String l_message = getMessage (a_messageIngredient);
			System.out.println ("Normal : " + l_message);
			return l_message;
		}
		else {
			return null;
		}
	}
	
	public static String logWarningInformation (String a_messageIngredient) {
		if (s_loggingLevel >= 1) {
			String l_message = getMessage (a_messageIngredient);
			System.out.println ("Warning: " + l_message);
			return l_message;
		}
		else {
			return null;
		}
	}
	
	public static String logWarningInformation (Exception a_messageException) {
		if (s_loggingLevel >= 1) {
			StringWriter l_stringWriter = new StringWriter ();
			a_messageException.printStackTrace (new PrintWriter (l_stringWriter));
			return logWarningInformation (l_stringWriter.toString ());
		}
		else {
			return null;
		}
	}
	
	public static String logErrorInformation (String a_messageIngredient) {
		if (s_loggingLevel >= 0) {
			String l_message = getMessage (a_messageIngredient);
			System.err.println ("Error  : " + l_message);
			return l_message;
		}
		else {
			return null;
		}
	}
	
	public static String logErrorInformation (Exception a_messageException) {
		if (s_loggingLevel >= 0) {
			StringWriter l_stringWriter = new StringWriter ();
			a_messageException.printStackTrace (new PrintWriter (l_stringWriter));
			return logErrorInformation (l_stringWriter.toString ());
		}
		else {
			return null;
		}
	}
	
	public static void appendToFile (String a_fileName, String a_contents) {
		try {
			Path l_filePath = Paths.get (a_fileName);
			if (!Files.exists(l_filePath)) {
				Files.createFile (l_filePath);
			}
			Files.write (l_filePath, String.format ("%s%c", a_contents, GeneralConstantsConstantsGroup.c_newLineCharacter).getBytes (), StandardOpenOption.APPEND);
		}
		catch (IOException l_exception) {
			show (l_exception.toString ());
		}
	}
}

