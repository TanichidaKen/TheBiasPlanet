package theBiasPlanet.coreUtilities.reflectionHandling;

import java.util.List;
import java.util.LinkedHashMap;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Constructor;
import java.lang.reflect.Modifier;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Array;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import theBiasPlanet.coreUtilities.collectionsHandling.ArraysFactory;

public class ReflectionHandler {
	private static final String c_booleanClassName = "boolean";
	private static final String c_byteClassName = "byte";
	private static final String c_charClassName = "char";
	private static final String c_doubleClassName = "double";
	private static final String c_floatClassName = "float";
	private static final String c_intClassName = "int";
	private static final String c_longClassName = "long";
	private static final String c_shortClassName = "short";
	
	// Fields are stored in the order of from the super class to the sub class and from the implemented interfaces to the implementing class.
	// Duplicate named fields are replaced by the sub class's.
	// If all the gotten fields are static, set a_instance to be null.
	public static LinkedHashMap <String, Object> getFieldNamesAndValues (Class <?> a_class, Object a_instance, boolean a_publicOnly, boolean a_setAccessible, List <Class <?>> a_assignableClassesOfFields, List <Class <?>> a_notAssignableClassesOfFields, boolean a_recursive) throws IllegalAccessException {
		LinkedHashMap <String, Object> l_fieldNameToValueMap = new LinkedHashMap <String, Object> ();
		if (a_recursive) {
			LinkedHashMap <String, Object> l_superClassOrImplementedInterfaceFieldNameToValueMap = null;
			Class<?> l_superClass = a_class.getSuperclass();
			if (l_superClass != null) {
				l_superClassOrImplementedInterfaceFieldNameToValueMap = getFieldNamesAndValues (l_superClass, a_instance, a_publicOnly, a_setAccessible, a_assignableClassesOfFields, a_notAssignableClassesOfFields, true);
				l_fieldNameToValueMap.putAll (l_superClassOrImplementedInterfaceFieldNameToValueMap);
			}
			Class<?>[] l_implementedInterfaces = null;
			l_implementedInterfaces = a_class.getInterfaces();
			for (Class<?> l_implementedInterface: l_implementedInterfaces) {
				l_superClassOrImplementedInterfaceFieldNameToValueMap = getFieldNamesAndValues (l_implementedInterface, null, a_publicOnly, a_setAccessible, a_assignableClassesOfFields, a_notAssignableClassesOfFields, true);
				l_fieldNameToValueMap.putAll (l_superClassOrImplementedInterfaceFieldNameToValueMap);
			}
		}
		Field [] l_fields = l_fields = a_class.getDeclaredFields ();
		FieldsLoop: for (Field l_field: l_fields) {
			int l_fieldModifiers = l_field.getModifiers ();
			if (a_publicOnly && !Modifier.isPublic (l_fieldModifiers)) {
				continue;
			}
			if (a_instance == null && !Modifier.isStatic (l_fieldModifiers)) {
				continue;
			}
			if (a_assignableClassesOfFields != null) {
				boolean l_assignable = false;
				for (Class <?> l_assignableClassOfFields: a_assignableClassesOfFields) {
					if (!l_assignableClassOfFields.isAssignableFrom (l_field.getType ())) {
						l_assignable = true;
						break;
					}
				}
				if (!l_assignable) {
					continue;
				}
			}
			if (a_notAssignableClassesOfFields != null) {
				for (Class <?> l_notAssignableClassOfFields: a_notAssignableClassesOfFields) {
					if (l_notAssignableClassOfFields.isAssignableFrom (l_field.getType ())) {
						continue FieldsLoop;
					}
				}
			}
			//boolean l_isAccessible = l_field.isAccessible ();
			boolean l_isAccessible = l_field.canAccess (a_instance);
			if (a_setAccessible && !l_isAccessible) {
				l_field.setAccessible (true);
			}
			l_fieldNameToValueMap.put (l_field.getName (), l_field.get (a_instance));
			if (a_setAccessible && !l_isAccessible) {
				l_field.setAccessible (l_isAccessible);
			}
		}
		return l_fieldNameToValueMap;
	}
	
	/*
	// The first element and the second element of the return are ArrayList <String> field names and ArrayList <Object> field values, respectively.
	// If all the gotten fields are static, a_instance can be null.
	// If a_declaredOnly is false, a_publicOnly will be set true and a_setAccessible will be set false automatically.
	public static ArrayList <ArrayList <?>> getFieldNamesAndValues (Class <?> a_class, Object a_instance, boolean a_declaredOnly, boolean a_publicOnly, boolean a_staticOnly, boolean a_setAccessible, List <Class <?>> a_assignableClassesOfFields, List <Class <?>> a_notAssignableClassesOfFields) throws IllegalAccessException {
		Field [] l_fields = null;
		if (a_declaredOnly) {
			l_fields = a_class.getDeclaredFields ();
		}
		else {
			l_fields = a_class.getFields ();
		}
		ArrayList <String> l_fieldNames = new ArrayList <String> ();
		ArrayList <Object> l_fieldValues = new ArrayList <Object> ();
		FieldsLoop: for (Field l_field: l_fields) {
			boolean l_isAccessible = l_field.isAccessible ();
			if (a_declaredOnly && a_setAccessible && !l_isAccessible) {
				l_field.setAccessible (true);
			}
			int l_fieldModifiers = l_field.getModifiers ();
			if (a_declaredOnly && a_publicOnly && !Modifier.isPublic (l_fieldModifiers)) {
				continue;
			}
			if (a_staticOnly && !Modifier.isStatic (l_fieldModifiers)) {
				continue;
			}
			if (a_assignableClassesOfFields != null) {
				boolean l_assignable = false;
				for (Class <?> l_assignableClassOfFields: a_assignableClassesOfFields) {
					if (!l_assignableClassOfFields.isAssignableFrom (l_field.getType ())) {
						l_assignable = true;
						break;
					}
				}
				if (!l_assignable) {
					continue;
				}
			}
			if (a_notAssignableClassesOfFields != null) {
				for (Class <?> l_notAssignableClassOfFields: a_notAssignableClassesOfFields) {
					if (l_notAssignableClassOfFields.isAssignableFrom (l_field.getType ())) {
						continue FieldsLoop;
					}
				}
			}
			l_fieldNames.add (l_field.getName ());
			l_fieldValues.add (l_field.get (a_instance));
			if (a_declaredOnly && a_setAccessible && !l_isAccessible) {
				l_field.setAccessible (l_isAccessible);
			}
		}
		ArrayList <ArrayList <?>> l_result = new ArrayList <ArrayList <?>> ();
		l_result.add (l_fieldNames);
		l_result.add (l_fieldValues);
		return l_result;
	}
	*/
	
	// For static fields, a_instance can be null
	// If a_declaredOnly is false, only public field can be accessed and a_setAccessible will be set false automatically.
	public static Object getFieldValue (Class <?> a_class, Object a_instance, String a_fieldName, boolean a_declaredOnly, boolean a_setAccessible) throws NoSuchFieldException, IllegalAccessException {
		Field l_field = null;
		if (a_declaredOnly) {
			l_field = a_class.getDeclaredField (a_fieldName);
		}
		else {
			l_field = a_class.getField (a_fieldName);
		}
		//boolean l_isAccessible = l_field.isAccessible ();
		boolean l_isAccessible = l_field.canAccess (a_instance);
		if (a_declaredOnly && a_setAccessible && !l_isAccessible) {
			l_field.setAccessible (true);
		}
		if (a_declaredOnly && a_setAccessible) {
			l_field.setAccessible (true);
		}
		Object l_value = l_field.get (a_instance);
		if (a_declaredOnly && a_setAccessible && !l_isAccessible) {
			l_field.setAccessible (l_isAccessible);
		}
		return l_value;
	}
	
	// For static methods, a_instance can be null
	// If a_declaredOnly is false, only public method can be accessed and a_setAccessible will be set false automatically.
	public static MethodHandle getMethodHandle (Class <?> a_class, Object a_instance, String a_methodName, List <Class <?>> a_argumentClasses, boolean a_declaredOnly, boolean a_setAccessible) throws NoSuchMethodException, IllegalAccessException {
		Method l_method = null;
		if (a_declaredOnly) {
			l_method = a_class.getDeclaredMethod (a_methodName, ArraysFactory. <Class <?>>createArray (Class.class, a_argumentClasses));
		}
		else {
			l_method = a_class.getMethod (a_methodName, ArraysFactory. <Class <?>>createArray (Class.class, a_argumentClasses));
		}
		//boolean l_isAccessible = l_method.isAccessible ();
		boolean l_isAccessible = l_method.canAccess (a_instance);
		if (a_declaredOnly && a_setAccessible && !l_isAccessible) {
			l_method.setAccessible (true);
		}
		MethodHandle l_methodHandle = MethodHandles.lookup ().unreflect (l_method).bindTo (a_instance);
		if (a_declaredOnly && a_setAccessible && !l_isAccessible) {
			l_method.setAccessible (l_isAccessible);
		}
		return l_methodHandle;
	}
	
	public static Class <?> getClass (ClassLoader a_classLoader, String a_className, boolean a_getWrapperClass) throws ClassNotFoundException {
		if (a_className.equals (c_booleanClassName)) {
			if (a_getWrapperClass) {
				return Boolean.class;
			}
			else {
				return Boolean.TYPE;
			}
		}
		else if (a_className.equals (c_byteClassName)) {
			if (a_getWrapperClass) {
				return Byte.class;
			}
			else {
				return Byte.TYPE;
			}
		}
		else if (a_className.equals (c_charClassName)) {
			if (a_getWrapperClass) {
				return Character.class;
			}
			else {
				return Character.TYPE;
			}
		}
		else if (a_className.equals (c_doubleClassName)) {
			if (a_getWrapperClass) {
				return Double.class;
			}
			else {
				return Double.TYPE;
			}
		}
		else if (a_className.equals (c_floatClassName)) {
			if (a_getWrapperClass) {
				return Float.class;
			}
			else {
				return Float.TYPE;
			}
		}
		else if (a_className.equals (c_intClassName)) {
			if (a_getWrapperClass) {
				return Integer.class;
			}
			else {
				return Integer.TYPE;
			}
		}
		else if (a_className.equals (c_longClassName)) {
			if (a_getWrapperClass) {
				return Long.class;
			}
			else {
				return Long.TYPE;
			}
		}
		else if (a_className.equals (c_shortClassName)) {
			if (a_getWrapperClass) {
				return Short.class;
			}
			else {
				return Short.TYPE;
			}
		}
		else {
			if (a_classLoader == null) {
				return Class.forName (a_className);
			}
			else {
				return a_classLoader.loadClass (a_className);
			}
		}
	}
	
	// use Integer.TYPE, etc for primitive type classes
	public static Object createInstance (ClassLoader a_classLoader, String a_className, List <Class <?>> a_argumentClasses, List <Object> a_arguments) throws ClassNotFoundException, NoSuchMethodException, InstantiationException, IllegalAccessException, InvocationTargetException {
		Class <?> l_class = getClass (a_classLoader, a_className, true);
		Constructor <?> l_constructor = l_class.getConstructor (ArraysFactory. <Class <?>>createArray (Class.class,  a_argumentClasses));
		Object l_object = l_constructor.newInstance (ArraysFactory. <Object>createArray (Object.class, a_arguments));
		return l_object;
	}
	
	// use Integer.TYPE, etc for primitive type classes
	public static Object createArrayInstance (ClassLoader a_classLoader, String a_className, List <Object> a_arguments) throws ClassNotFoundException, NoSuchMethodException, InstantiationException, IllegalAccessException, InvocationTargetException {
		Object l_object = Array.newInstance (getClass (a_classLoader, a_className, true), a_arguments.size ());
		int l_argumentIndex = 0;
		for (Object l_argument: a_arguments) {
			// Primitives are automatically unwrapped
			Array.set (l_object, l_argumentIndex, l_argument);
			l_argumentIndex ++;
		}
		return l_object;
	}
}

