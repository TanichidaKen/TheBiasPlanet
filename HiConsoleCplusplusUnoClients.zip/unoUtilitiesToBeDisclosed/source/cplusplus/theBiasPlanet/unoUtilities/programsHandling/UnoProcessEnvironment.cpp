#include "theBiasPlanet/unoUtilities/programsHandling/UnoProcessEnvironment.hpp"
#include <map>
#include <com/sun/star/uno/Any.h>
#include <com/sun/star/uno/XComponentContext.hpp>
#include <cppuhelper/bootstrap.hxx>
#include "theBiasPlanet/unoUtilities/constantsGroups/UnoMessagesConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/UnoObjectsContextPropertyNamesSet.hpp"
#include "theBiasPlanet/unoUtilities/stringsHandling/UnoExtendedStringHandler.hpp"

using namespace ::std;
using namespace ::com::sun::star::uno;
using namespace ::cppu;
using namespace ::theBiasPlanet::unoUtilities::connectionsHandling;
using namespace ::theBiasPlanet::unoUtilities::constantsGroups;
using namespace ::theBiasPlanet::unoUtilities::constantsGroups::propertyNamesSets;
using namespace ::theBiasPlanet::unoUtilities::stringsHandling;

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace programsHandling {
			UnoProcessEnvironment::UnoProcessEnvironment (string const &  a_identification) {
				try {
					map <string, Any> l_unoObjectsContextExtraNameToValueMap;
					l_unoObjectsContextExtraNameToValueMap [UnoObjectsContextPropertyNamesSet::c_identification_string] = Any (UnoExtendedStringHandler::getOustring (a_identification));
					Reference <XComponentContext> l_originalLocalObjectsContext = defaultBootstrap_InitialComponentContext ();
					i_localObjectsContext.set (new UnoObjectsContext (l_originalLocalObjectsContext, l_unoObjectsContextExtraNameToValueMap));
				}
				catch (Exception & l_exception) {
					throw l_exception;
				}
				catch (...) {
					exception_ptr l_currentException = current_exception ();
					throw runtime_error (UnoMessagesConstantsGroup::c_unoObjectsContextNotCreated);
				}
			}
			
			UnoProcessEnvironment::~UnoProcessEnvironment () {
			}
			
			Reference <UnoObjectsContext> & UnoProcessEnvironment::getLocalObjectsContext () const {
				return const_cast <Reference <UnoObjectsContext> &> (i_localObjectsContext);
			}
		}
	}
}

