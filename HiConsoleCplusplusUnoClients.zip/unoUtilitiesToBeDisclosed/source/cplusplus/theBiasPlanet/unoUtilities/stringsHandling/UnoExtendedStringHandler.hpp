#ifndef __theBiasPlanet_unoUtilities_stringsHandling_UnoExtendedStringHandler_hpp__
#define __theBiasPlanet_unoUtilities_stringsHandling_UnoExtendedStringHandler_hpp__

#include <string>
#include <rtl/ustring.hxx>
#include "theBiasPlanet/coreUtilities/stringsHandling/StringHandler.hpp"
#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"

using namespace ::rtl;
using namespace ::std;
using namespace ::theBiasPlanet::coreUtilities::stringsHandling;

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace stringsHandling {
			class __theBiasPlanet_unoUtilities_symbolExportingOrImportingDeclarationForVisualCplusplus__ UnoExtendedStringHandler : public StringHandler {
				public:
					static OUString getOustring (string const & a_utf8String);
					static string getString (OUString const & a_oustring);
			};
		}
	}
}

#endif

