#ifndef __theBiasPlanet_unoUtilities_connectionsHandling_UnoConnectionsFactory_hpp__
#define __theBiasPlanet_unoUtilities_connectionsHandling_UnoConnectionsFactory_hpp__

#include <list>
#include <string>
#include <com/sun/star/bridge/XBridgeFactory.hpp>
#include <com/sun/star/connection/XConnection.hpp>
#include <com/sun/star/uno/Reference.hxx>
#include "theBiasPlanet/coreUtilities/stringsHandling/StringTokenizer.hpp"
#include "theBiasPlanet/unoUtilities/connectionsHandling/UnoConnection.hpp"
#include "theBiasPlanet/unoUtilities/connectionsHandling/UnoConnectionEventsListener.hpp"
#include "theBiasPlanet/unoUtilities/connectionsHandling/UnoObjectsContext.hpp"
#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"

using namespace ::std;
using namespace ::com::sun::star::bridge;
using namespace ::com::sun::star::connection;
using namespace ::com::sun::star::uno;
using namespace ::theBiasPlanet::coreUtilities::stringsHandling;

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace connectionsHandling {
			class __theBiasPlanet_unoUtilities_symbolExportingOrImportingDeclarationForVisualCplusplus__ UnoConnectionsFactory {
				protected:
					Reference <UnoObjectsContext> i_localObjectsContext;
					Reference <XBridgeFactory> i_bridgesFactoryInXBridgeFactory;
					UnoConnectionsFactory (Reference <UnoObjectsContext> a_localObjectsContext);
					virtual void initialize () final;
					virtual Reference <UnoConnection> setupConnection (Reference <XConnection> a_connectionInXConnection, StringTokenizer * a_urlTokenizer, string const & a_connectionIdentification, optional <list <UnoConnectionEventsListener *> const> const a_eventListeners) final;
			};
		}
	}
}

#endif

