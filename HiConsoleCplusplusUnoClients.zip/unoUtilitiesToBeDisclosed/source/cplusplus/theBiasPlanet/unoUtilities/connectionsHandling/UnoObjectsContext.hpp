#ifndef __theBiasPlanet_unoUtilities_connectionsHandling_UnoObjectsContext_hpp__
#define __theBiasPlanet_unoUtilities_connectionsHandling_UnoObjectsContext_hpp__

#include <map>
#include <optional>
#include <string>
#include <com/sun/star/container/XNameContainer.hpp>
#include <com/sun/star/lang/XMultiComponentFactory.hpp>
#include <com/sun/star/uno/Any.h>
#include <com/sun/star/uno/Type.h>
#include <com/sun/star/uno/Reference.hxx>
#include <com/sun/star/uno/XComponentContext.hpp>
#include <cppuhelper/compbase1.hxx>
#include <osl/mutex.hxx>
#include <rtl/ustring.hxx>
#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"

using namespace ::std;
using namespace ::com::sun::star::container;
using namespace ::com::sun::star::lang;
using namespace ::com::sun::star::uno;
using namespace ::cppu;
using namespace ::osl;
using namespace ::rtl;

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace connectionsHandling {
			//class UnoObjectsContext : public WeakComponentImplHelper2 <XComponentContext, XNameContainer> {
			class __theBiasPlanet_unoUtilities_symbolExportingOrImportingDeclarationForVisualCplusplus__ UnoObjectsContext : public WeakComponentImplHelper1 <XComponentContext> {
				private:
					Mutex i_mutex;
					Reference <XComponentContext> i_originalObjectsContextInXComponentContext;
					Reference <XNameContainer> i_originalObjectsContextInXNameContainer;
					optional <map <string, Any>> i_extraNameToValueMap;
				public:
					UnoObjectsContext (Reference <XComponentContext> a_originalObjectsContextInXComponentContext, optional <map <string, Any>> a_extraNameToValueMap);
					~UnoObjectsContext ();
					virtual Any SAL_CALL getValueByName (const OUString & a_name) override;
					virtual Reference <XMultiComponentFactory> SAL_CALL getServiceManager () override;
					/*
					virtual Any SAL_CALL getByName (OUString const & a_name) override;
					virtual Sequence <OUString> SAL_CALL getElementNames () override;
					virtual sal_Bool SAL_CALL hasByName (OUString const & a_name) override;
					virtual Type SAL_CALL getElementType () override;
					virtual sal_Bool SAL_CALL hasElements () override;
					*/
					virtual bool SAL_CALL isFromSameOrigin (Reference <UnoObjectsContext> a_unoObjectsContext);
			};
		}
	}
}

#endif

