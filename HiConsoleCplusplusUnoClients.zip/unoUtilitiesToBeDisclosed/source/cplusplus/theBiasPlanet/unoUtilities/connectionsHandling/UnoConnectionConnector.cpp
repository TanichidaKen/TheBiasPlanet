#include <ctime>
#include <iomanip>
#include <sstream>
#include "theBiasPlanet/unoUtilities/connectionsHandling/UnoConnectionConnector.hpp"
#include <com/sun/star/connection/XConnection.hpp>
#include <com/sun/star/connection/XConnector.hpp>
#include <com/sun/star/uno/Reference.hxx>
#include "theBiasPlanet/coreUtilities/stringsHandling/StringTokenizer.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/UnoGeneralConstantsConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/UnoServiceNamesConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/servicesHandling/UnoServiceHandler.hpp"
#include "theBiasPlanet/unoUtilities/stringsHandling/UnoExtendedStringHandler.hpp"

using namespace ::theBiasPlanet::coreUtilities::stringsHandling;
using namespace ::theBiasPlanet::unoUtilities::constantsGroups;
using namespace ::theBiasPlanet::unoUtilities::servicesHandling;
using namespace ::theBiasPlanet::unoUtilities::stringsHandling;

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace connectionsHandling {
			UnoConnectionConnector::UnoConnectionConnector (Reference <UnoObjectsContext> a_localObjectsContext) : UnoConnectionsFactory (a_localObjectsContext) {
				initialize ();
			}
			
			Reference <UnoConnection> UnoConnectionConnector::connect (string const & a_url, optional <list <UnoConnectionEventsListener *> const> const a_eventListeners) {
				StringTokenizer l_urlTokenizer (a_url, UnoGeneralConstantsConstantsGroup::c_connectionUrlDelimiter);
				Reference <XConnector> l_unoConnectionConnectorInXConnector = UnoServiceHandler::getServiceInstance <XConnector> (i_localObjectsContext, UnoServiceNamesConstantsGroup::c_com_sun_star_connection_Connector);
				Reference <XConnection> l_connectionInXConnection = l_unoConnectionConnectorInXConnector->connect (UnoExtendedStringHandler::getOustring (l_urlTokenizer.nextToken ().value ()));
				time_t l_time = time (nullptr);
    			tm const l_localTime = *(localtime (&l_time));
    			ostringstream l_timeExpressionStream;
    			l_timeExpressionStream << put_time (&l_localTime, "%Y-%m-%dT%H:M:S");
				string const l_timeExpression = l_timeExpressionStream.str ();
				Reference <UnoConnection> l_unoConnection = setupConnection (l_connectionInXConnection, &l_urlTokenizer, l_timeExpression, a_eventListeners);
				return l_unoConnection;
			}
		}
	}
}

