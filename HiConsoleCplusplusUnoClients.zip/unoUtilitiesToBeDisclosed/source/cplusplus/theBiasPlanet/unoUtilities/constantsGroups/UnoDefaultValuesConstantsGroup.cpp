#include "theBiasPlanet/unoUtilities/constantsGroups/UnoDefaultValuesConstantsGroup.hpp"

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			string const UnoDefaultValuesConstantsGroup::c_customDefaultStyleName = "CustomDefault";
			string const UnoDefaultValuesConstantsGroup::c_initiallyOfferedUnoObjectName = "theBiasPlanet.UnoObjectsContext";
		}
	}
}

