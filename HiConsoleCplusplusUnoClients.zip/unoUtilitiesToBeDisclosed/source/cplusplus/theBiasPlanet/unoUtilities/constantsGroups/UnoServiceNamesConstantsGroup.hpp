#ifndef __theBiasPlanet_unoUtilities_constantsGroups_UnoServiceNamesConstantsGroup_hpp__
#define __theBiasPlanet_unoUtilities_constantsGroups_UnoServiceNamesConstantsGroup_hpp__

#include <string>
#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"

using namespace ::std;

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			class __theBiasPlanet_unoUtilities_symbolExportingOrImportingDeclarationForVisualCplusplus__ UnoServiceNamesConstantsGroup {
				public:
					static string const c_com_sun_star_frame_Desktop;
					static string const c_com_sun_star_frame_DispatchHelper;
					static string const c_com_sun_star_xml_crypto_SecurityEnvironment;
					static string const c_com_sun_star_bridge_BridgeFactory;
					static string const c_com_sun_star_connection_Connector;
					static string const c_com_sun_star_connection_Acceptor;
					static string const c_com_sun_star_util_URLTransformer;
			};
		}
	}
}

#endif

