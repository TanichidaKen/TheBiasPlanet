#ifndef __theBiasPlanet_unoUtilities_constantsGroups_propertyNamesSets_UnoDocumentOpeningPropertyNamesSet_hpp__
#define __theBiasPlanet_unoUtilities_constantsGroups_propertyNamesSets_UnoDocumentOpeningPropertyNamesSet_hpp__

#include <string>
#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/UnoPropertyNamesSet.hpp"
#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"

using namespace ::std;

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			namespace propertyNamesSets {
				class __theBiasPlanet_unoUtilities_symbolExportingOrImportingDeclarationForVisualCplusplus__ UnoDocumentOpeningPropertyNamesSet : public UnoPropertyNamesSet {
					public:
						static string const c_readOnly_Boolean;
						static string const c_hidden_Boolean;
				};
			}
		}
	}
}

#endif

