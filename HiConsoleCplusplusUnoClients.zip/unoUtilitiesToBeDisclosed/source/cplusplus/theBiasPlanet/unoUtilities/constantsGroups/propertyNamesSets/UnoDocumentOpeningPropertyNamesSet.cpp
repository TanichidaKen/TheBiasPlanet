#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/UnoDocumentOpeningPropertyNamesSet.hpp"

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			namespace propertyNamesSets {
				string const UnoDocumentOpeningPropertyNamesSet::c_readOnly_Boolean = "ReadOnly";
				string const UnoDocumentOpeningPropertyNamesSet::c_hidden_Boolean = "Hidden";
			}
		}
	}
}

