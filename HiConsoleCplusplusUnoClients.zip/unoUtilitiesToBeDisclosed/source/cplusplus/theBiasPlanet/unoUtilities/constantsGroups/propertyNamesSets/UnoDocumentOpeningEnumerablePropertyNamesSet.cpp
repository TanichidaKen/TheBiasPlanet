#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/UnoDocumentOpeningEnumerablePropertyNamesSet.hpp"

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			namespace propertyNamesSets {
				UnoDocumentOpeningEnumerablePropertyNamesSet::UnoDocumentOpeningEnumerablePropertyNamesSet () : BaseEnumerableConstantsGroup <string> ({ {"c_readOnly_Boolean", "ReadOnly"}, {"c_hidden_Boolean", "Hidden"}})  {
				}
				
				UnoDocumentOpeningEnumerablePropertyNamesSet const UnoDocumentOpeningEnumerablePropertyNamesSet::c_instance = UnoDocumentOpeningEnumerablePropertyNamesSet ();
			}
		}
	}
}

