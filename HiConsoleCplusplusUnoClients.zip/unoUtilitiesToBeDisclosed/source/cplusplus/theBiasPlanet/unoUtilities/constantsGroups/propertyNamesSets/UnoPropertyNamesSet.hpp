#ifndef __theBiasPlanet_unoUtilities_constantsGroups_propertyNamesSets_UnoPropertyNamesSet_hpp__
#define __theBiasPlanet_unoUtilities_constantsGroups_propertyNamesSets_UnoPropertyNamesSet_hpp__

#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			namespace propertyNamesSets {
				class __theBiasPlanet_unoUtilities_symbolExportingOrImportingDeclarationForVisualCplusplus__ UnoPropertyNamesSet {
				};
			}
		}
	}
}

#endif

