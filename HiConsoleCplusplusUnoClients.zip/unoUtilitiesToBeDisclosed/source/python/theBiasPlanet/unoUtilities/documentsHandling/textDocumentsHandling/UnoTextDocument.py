from typing import cast
from typing import Optional
from com.sun.star.lang import XComponent
from com.sun.star.text import XTextDocument
from com.sun.star.text import XTextViewCursor
from com.sun.star.text import XTextViewCursorSupplier
from theBiasPlanet.unoUtilities.constantsGroups.UnoMessagesConstantsGroup import UnoMessagesConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.UnoSpecialFileUrlsConstantsGroup import UnoSpecialFileUrlsConstantsGroup
from theBiasPlanet.unoUtilities.connectionsHandling.UnoObjectsContext import UnoObjectsContext
from theBiasPlanet.unoUtilities.documentsHandling.UnoDocument import UnoDocument

class UnoTextDocument (UnoDocument):
	def __init__ (a_this: "UnoTextDocument", a_unoObjectsContext: "UnoObjectsContext", a_textDocumentInXComponent: XComponent) -> None:
		a_this.i_textDocumentInXTextDocument: XTextDocument
		a_this.i_controllerInXTextViewCursorSupplier: XTextViewCursorSupplier
		
		UnoDocument.__init__ (a_this, a_unoObjectsContext, a_textDocumentInXComponent)
		a_this.i_textDocumentInXTextDocument = cast (XTextDocument, a_textDocumentInXComponent)
		if a_this.i_textDocumentInXTextDocument is None:
			raise Exception (UnoMessagesConstantsGroup.c_isNotTextDocument)
		a_this.i_controllerInXTextViewCursorSupplier = cast (XTextViewCursorSupplier, a_this.i_controllerInXController)
	
	@staticmethod
	def createTextDocument (a_unoObjectsContext: "UnoObjectsContext", a_hiddenly: bool) -> "UnoTextDocument":
		return UnoTextDocument (a_unoObjectsContext, UnoDocument.createUnoDocumentOrOpenUnoDocumentFile (a_unoObjectsContext, UnoSpecialFileUrlsConstantsGroup.c_writerNewDocument, None, a_hiddenly))
	
	@staticmethod
	def openTextDocumentFile (a_unoObjectsContext: "UnoObjectsContext", a_fileUrl: str, a_password: Optional [str], a_hiddenly: bool) -> "UnoTextDocument":
		return UnoTextDocument (a_unoObjectsContext, UnoDocument.createUnoDocumentOrOpenUnoDocumentFile (a_unoObjectsContext, a_fileUrl, a_password, a_hiddenly))
	
	@staticmethod
	def getCurrentTextDocument (a_unoObjectsContext: "UnoObjectsContext") -> "UnoTextDocument":
		return UnoTextDocument (a_unoObjectsContext, UnoDocument.getCurrentUnoDocument (a_unoObjectsContext))
	
	def getViewCursor (a_this: "UnoTextDocument") -> XTextViewCursor:
		return a_this.i_controllerInXTextViewCursorSupplier.getViewCursor ()

