namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			using System;
			
			public static class UnoCharactersEncodingCodesConstantsGroup {
				public const int c_utf8 = 76;
				public const int c_ucs2 = 65535;
				public const int c_ucs4 = 65534;
				public const int c_usAscii = 11;
				public const int c_eucJp = 69;
				public const int c_shiftJis = 64;
			}
		}
	}
}

