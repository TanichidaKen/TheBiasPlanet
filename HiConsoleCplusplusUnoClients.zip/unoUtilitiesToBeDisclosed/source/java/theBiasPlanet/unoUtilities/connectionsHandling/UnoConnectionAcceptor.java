package theBiasPlanet.unoUtilities.connectionsHandling;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import com.sun.star.connection.ConnectionSetupException;
import com.sun.star.connection.XAcceptor;
import com.sun.star.connection.XConnection;
import theBiasPlanet.unoUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.servicesHandling.UnoServiceHandler;

public class UnoConnectionAcceptor extends UnoConnectionsFactory {
	private Map <String, XAcceptor> i_portNameToConnectionAcceptorInXAcceptorMap;
	XAcceptor i_acceptingConnectionAcceptorInXAcceptor;
	
	public UnoConnectionAcceptor (UnoObjectsContext a_localObjectsContext) throws com.sun.star.uno.Exception {
		super (a_localObjectsContext);
		i_portNameToConnectionAcceptorInXAcceptorMap = new HashMap <String, XAcceptor> ();
		initialize ();
	}
	
	public final UnoConnection accept (String a_url, List <UnoConnectionEventsListener> a_eventListeners) throws com.sun.star.uno.Exception {
		StringTokenizer l_urlTokenizer = new StringTokenizer(a_url, UnoGeneralConstantsConstantsGroup.c_connectionUrlDlimiter);
		String l_portName = l_urlTokenizer.nextToken();
		XConnection l_connectionInXConnection = null;
		UnoConnection l_unoConnection = null;
		synchronized (this) {
			try {
				if (i_portNameToConnectionAcceptorInXAcceptorMap.containsKey (l_portName)) {
					i_acceptingConnectionAcceptorInXAcceptor = i_portNameToConnectionAcceptorInXAcceptorMap.get (l_portName);
				}
				else {
					i_acceptingConnectionAcceptorInXAcceptor = (XAcceptor) UnoServiceHandler.getServiceInstance (i_localObjectsContext, UnoServiceNamesConstantsGroup.c_com_sun_star_connection_Acceptor, XAcceptor.class);
				}
				l_connectionInXConnection = i_acceptingConnectionAcceptorInXAcceptor.accept (l_portName);
				i_portNameToConnectionAcceptorInXAcceptorMap.put (l_portName, i_acceptingConnectionAcceptorInXAcceptor);
				l_unoConnection = setupConnection (l_connectionInXConnection, l_urlTokenizer, LocalDateTime.now ().toString (), a_eventListeners);
			}
			catch (ConnectionSetupException l_exception) {
				i_portNameToConnectionAcceptorInXAcceptorMap.remove (l_portName);
				throw l_exception;
			}
			finally {
				i_acceptingConnectionAcceptorInXAcceptor = null;
			}
		}
		return l_unoConnection;
	}
	
	public final void stopAccepting () {
		XAcceptor l_acceptingConnectionAcceptorInXAcceptor = i_acceptingConnectionAcceptorInXAcceptor;
		if (l_acceptingConnectionAcceptorInXAcceptor != null) {
			l_acceptingConnectionAcceptorInXAcceptor.stopAccepting();
		}
	}
}

