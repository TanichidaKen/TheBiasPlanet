package theBiasPlanet.unoUtilities.propertiesHandling;

import java.util.ArrayList;
import java.util.List;
import com.sun.star.beans.PropertyValue;
import theBiasPlanet.coreUtilities.constantsGroups.*;

public class UnoPropertiesHandler {
	public static ArrayList <PropertyValue> buildPropertyNameValuePairs (List <String> a_propertyNames, List <Object> a_propertyValues) {
		ArrayList <PropertyValue> l_propertyNameValuePairs = new ArrayList <PropertyValue> ();
		int l_propertyIndex = GeneralConstantsConstantsGroup.c_iterationStartingNumber;
		for (String l_propertyName: a_propertyNames) {
			PropertyValue l_propertyNameValuePair = new PropertyValue ();
			l_propertyNameValuePair.Name = l_propertyName;
			l_propertyNameValuePair.Value = a_propertyValues.get (l_propertyIndex);
			l_propertyNameValuePairs.add (l_propertyNameValuePair);
			l_propertyIndex ++;
		}
		return l_propertyNameValuePairs;
	}
}

