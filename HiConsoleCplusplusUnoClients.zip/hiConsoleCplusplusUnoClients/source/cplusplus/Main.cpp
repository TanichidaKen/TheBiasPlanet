#include "theBiasPlanet/hiConsoleCplusplusUnoClients/programs/HiConsoleCplusplusUnoClients.hpp"
#include <sal/main.h>

using namespace ::theBiasPlanet::hiConsoleCplusplusUnoClients::programs;

// An environment variable has to be set like 'URE_MORE_TYPES=file:////usr/lib/libreoffice/program/types/offapi.rdb'; the environment variable can be set by passing an argument like '-env:URE_MORE_TYPES=file:////usr/lib/libreoffice/program/types/offapi.rdb'
//SAL_IMPLEMENT_MAIN_WITH_ARGS (a_argumentsNumber, a_arguments) {
int main (int a_argumentsNumber, char * a_arguments []) {
    sal_detail_initialize (a_argumentsNumber, a_arguments);
    int l_result = HiConsoleCplusplusUnoClients::main (a_argumentsNumber, a_arguments);
    sal_detail_deinitialize ();
	return l_result;
}

