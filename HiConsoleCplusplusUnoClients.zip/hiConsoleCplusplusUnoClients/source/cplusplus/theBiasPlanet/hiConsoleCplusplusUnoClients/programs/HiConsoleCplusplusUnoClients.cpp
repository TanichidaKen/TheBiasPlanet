#include "theBiasPlanet/hiConsoleCplusplusUnoClients/programs/HiConsoleCplusplusUnoClients.hpp"
#include <ctime>
#include <iostream>
#include <exception>
#include <optional>
#include "theBiasPlanet/coreUtilities/messaging/Publisher.hpp"
#include "theBiasPlanet/unoUtilities/connectionsHandling/UnoConnection.hpp"
#include "theBiasPlanet/unoUtilities/connectionsHandling/UnoConnectionConnector.hpp"
#include "theBiasPlanet/unoUtilities/documentsHandling/textDocumentsHandling/UnoTextDocument.hpp"
#include "theBiasPlanet/unoUtilities/programsHandling/UnoProcessEnvironment.hpp"
#include "theBiasPlanet/unoUtilities/stringsHandling/UnoExtendedStringHandler.hpp"

using namespace ::std;
using namespace ::theBiasPlanet::coreUtilities::messaging;
using namespace ::theBiasPlanet::unoUtilities::connectionsHandling;
using namespace ::theBiasPlanet::unoUtilities::documentsHandling::textDocumentsHandling;
using namespace ::theBiasPlanet::unoUtilities::programsHandling;
using namespace ::theBiasPlanet::unoUtilities::stringsHandling;

namespace theBiasPlanet {
	namespace hiConsoleCplusplusUnoClients {
		namespace programs {
				int HiConsoleCplusplusUnoClients::main (int const & a_argumentsNumber, char const * const a_arguments []) {
					try {
						if (a_argumentsNumber != 3) {
							throw runtime_error ("The arguments have to be these.\nThe argument 1: the server url like 'socket,host=localhost,port=2002,tcpNoDelay=1;urp;StarOffice.ComponentContext'\nThe argument 2: the url of the file to be opened like 'file://${HOME}/myData/development/hiConsoleJavaUnoClients/execution/HiConsoleJavaUnoClientsTests.odt'\n");
						}
						string l_serverUrl = string (a_arguments [1]);
						string l_openedFileUrl = string (a_arguments [2]);
						time_t l_time = time (nullptr);
    					tm const l_localTime = *(localtime (&l_time));
    					ostringstream l_timeExpressionStream;
    					l_timeExpressionStream << put_time (&l_localTime, "%Y-%m-%dT%H:M:S");
						string const l_timeExpression = l_timeExpressionStream.str ();
						UnoProcessEnvironment l_localUnoProcessEnvironment = UnoProcessEnvironment (l_timeExpression);
						UnoConnectionConnector l_unoConnectionConnector = UnoConnectionConnector (l_localUnoProcessEnvironment.getLocalObjectsContext ());
						Reference <UnoConnection> l_unoConnection = l_unoConnectionConnector.connect (l_serverUrl, nullopt);
						Reference <UnoTextDocument> l_unoTextDocument = UnoTextDocument::openTextDocumentFile (l_unoConnection->getRemoteObjectsContext (), l_openedFileUrl, nullopt, false);
						l_unoTextDocument->close ();
						l_unoConnection->disconnect ();
					}
					catch (Exception & l_exception) {
						Publisher::logErrorInformation (UnoExtendedStringHandler::getString (l_exception.Message));
						return (1);
					}
					catch (exception & l_exception) {
						Publisher::logErrorInformation (l_exception);
						return (1);
					}
					return (0);
				}
		}
	}
}

