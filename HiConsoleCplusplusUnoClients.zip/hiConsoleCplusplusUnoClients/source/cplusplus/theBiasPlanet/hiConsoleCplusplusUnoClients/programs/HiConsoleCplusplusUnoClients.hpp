#ifndef __theBiasPlanet_hiConsoleCplusplusUnoClients_programs_HiConsoleCplusplusUnoClients_hpp__
#define __theBiasPlanet_hiConsoleCplusplusUnoClients_programs_HiConsoleCplusplusUnoClients_hpp__

namespace theBiasPlanet {
	namespace hiConsoleCplusplusUnoClients {
		namespace programs {
			class HiConsoleCplusplusUnoClients {
				public:
					static int main (int const & a_argumentsNumber, char const * const a_arguments []);
			};
		}
	}
}

#endif

