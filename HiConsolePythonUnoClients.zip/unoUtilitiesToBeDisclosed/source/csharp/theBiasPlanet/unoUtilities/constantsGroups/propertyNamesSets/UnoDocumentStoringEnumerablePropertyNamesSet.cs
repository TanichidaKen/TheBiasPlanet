namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			namespace propertyNamesSets {
				using System;
				using theBiasPlanet.coreUtilities.constantsGroups;
				
				public class UnoDocumentStoringEnumerablePropertyNamesSet : BaseEnumerableConstantsGroup <String>, UnoPropertyNamesSet  {
					public const String c_filterName_string = "FilterName";
					public const String c_filterData_any = "FilterData"; // supposed to be, but not necessarily, a sequence of 'com.sun.star.beans.PropertyValue'
					public const String c_filterData_string = "FilterOptions"; // Some filters take this property while some other filters take the above property.
					public const String c_isTemplate_boolean = "AsTemplate";
					public const String c_authorName_string = "Author";
					public const String c_title_string = "DocumentTitle";
					public const String c_encryptionData_NamedValuesSequence = "EncryptionData";
					public const String c_password_string = "Password";
					public const String c_charactersSet_string = "CharacterSet";
					public const String c_version_short = "Version";
					public const String c_versionDescription_string = "Comment";
					public const String c_overwrites_boolen = "Overwrite";
					public const String c_documentTypeSpecificData_any = "ComponentData"; // supposed to be, but not necessarily, a sequence of com.sun.star.beans.NamedValue
					public readonly UnoDocumentStoringEnumerablePropertyNamesSet c_instance = new UnoDocumentStoringEnumerablePropertyNamesSet ();
					
					private UnoDocumentStoringEnumerablePropertyNamesSet () {
					}
				}
			}
		}
	}
}

