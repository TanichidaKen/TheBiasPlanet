namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			namespace propertyNamesSets {
				using System;
				using theBiasPlanet.coreUtilities.constantsGroups;
				
				public class UnoDocumentOpeningEnumerablePropertyNamesSet : BaseEnumerableConstantsGroup <String>, UnoPropertyNamesSet  {
					public const String c_readOnly_boolean = "ReadOnly";
					public const String c_hidden_boolean = "Hidden";
					public const String c_openNewView_boolean = "OpenNewView";
					public const String c_silent_boolean = "Silent";
					public const String c_password_string = "Password";
					
					public static readonly UnoDocumentOpeningEnumerablePropertyNamesSet c_instance = new UnoDocumentOpeningEnumerablePropertyNamesSet ();
					
					private UnoDocumentOpeningEnumerablePropertyNamesSet () {
					}
				}
			}
		}
	}
}

