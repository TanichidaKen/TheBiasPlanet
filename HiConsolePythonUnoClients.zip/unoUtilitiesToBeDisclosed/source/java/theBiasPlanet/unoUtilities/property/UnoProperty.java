package theBiasPlanet.unoUtilities.property;

import com.sun.star.beans.PropertyValue;

public class UnoProperty extends PropertyValue {
	public UnoProperty (String a_name, Object a_value) {
		Name = a_name;
		Value = a_value;
	}
}

