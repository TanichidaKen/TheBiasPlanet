package theBiasPlanet.unoUtilities.displaysHandling;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import com.sun.star.connection.ConnectionSetupException;
import com.sun.star.lang.EventObject;
import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.coreUtilities.messaging.CustomizedAlert;
import theBiasPlanet.unoUtilities.connectionsHandling.UnoConnection;
import theBiasPlanet.unoUtilities.connectionsHandling.UnoConnectionAcceptor;
import theBiasPlanet.unoUtilities.programsHandling.UnoFxProcessEnvironment;

public class UnoConnectionAcceptorScene extends UnoConnectionBaseScene {
	private static final String c_defaultTitle;
	private static final int c_defaultWidth;
	private static final int c_defaultHeight;
	private Button i_acceptButton;
	private Button i_suspendButton;
	private UnoConnectionAcceptor i_unoConnectionAcceptor;
	private List <UnoConnection> i_unoConnections;
	private boolean i_accepting;
	
	static {
		c_defaultTitle = "Uno Connection Acceptor Frame";
		c_defaultWidth = 700;
		c_defaultHeight = 100;
	}
	
	public UnoConnectionAcceptorScene (String a_title, int a_width, int a_height) throws com.sun.star.uno.Exception {
		super (a_title, a_width, a_height);
		i_accepting = false;
		i_unoConnectionAcceptor = new UnoConnectionAcceptor (UnoFxProcessEnvironment.s_currentEnvironment.getUnoEnvironment ().getLocalObjectsContext ());
		i_unoConnections = new ArrayList <UnoConnection> ();
		i_acceptButton = new Button (UserInterfaceComponentCaptionsConstantsGroup.c_accept);
		i_acceptButton.setOnAction (
			(a_event) -> {
				acceptActionPerformed(a_event);
			}
		);
		i_commandsPane.add (i_acceptButton, 0, 0);
		i_suspendButton = new Button (UserInterfaceComponentCaptionsConstantsGroup.c_suspend);
		i_suspendButton.setOnAction (
			(a_event) -> {
				suspendActionPerformed(a_event);
			}
		);
		i_commandsPane.add(i_suspendButton, 1, 0);
		i_disconnectButton.setOnAction (
			(a_event) -> {
				disconnectActionPerformed(a_event);
			}
		);
		i_commandsPane.add(i_disconnectButton, 2, 0);
		setStatusDisplay ();
	}
	
	public UnoConnectionAcceptorScene () throws com.sun.star.uno.Exception {
		this (c_defaultTitle, c_defaultWidth, c_defaultHeight);
	}
	
	private void acceptActionPerformed(ActionEvent a_event) {
		try {
			Thread l_subThread = new Thread (() -> {
				try {
					while (true) {
						i_unoConnectionAcceptor.accept (i_urlTextField.getText (), Arrays.asList (this));
					}
				}
				catch (ConnectionSetupException l_exception) {
					showAlert (CustomizedAlert.AlertType.INFORMATION,l_exception.toString ());
				}
				catch (com.sun.star.uno.Exception l_exception) {
					l_exception.printStackTrace ();
					showAlert (CustomizedAlert.AlertType.ERROR, l_exception.toString ());
				}
				finally {
					i_accepting = false;
					setStatusDisplay ();
				}
			});
			i_accepting = true;
			setStatusDisplay (MessagesConstantsGroup.c_accepting);
			l_subThread.start ();
		}
		catch (java.lang.Exception l_exception) {
			showAlert (CustomizedAlert.AlertType.ERROR, l_exception.toString ());
		}
	}
	
	private void disconnectActionPerformed (ActionEvent a_event) {
		List <UnoConnection> l_unoConnections = new ArrayList <UnoConnection> (i_unoConnections);
		for (UnoConnection l_unoConnection: l_unoConnections) {
			l_unoConnection.disconnect ();
		}
	}
	
	private void suspendActionPerformed (ActionEvent a_event) {
		i_unoConnectionAcceptor.stopAccepting ();
	}
	
	private void setStatusDisplay () {
		Platform.runLater(() -> {
			if (i_unoConnections.isEmpty ()) {
				i_statusLabel.setText (MessagesConstantsGroup.c_notConnected);
				i_disconnectButton.setDisable (true);
			}
			else {
				i_statusLabel.setText (MessagesConstantsGroup.c_connected);
				i_disconnectButton.setDisable (false);
			}
			i_acceptButton.setDisable (i_accepting);
			i_suspendButton.setDisable (!i_accepting);
		});
	}
	
	private void setStatusDisplay (String a_statusMessage) {
		setStatusDisplay ();
		Platform.runLater(() -> {
			i_statusLabel.setText (a_statusMessage);
		});
	}
	
	@Override
	public void connected (EventObject a_event) {
		i_unoConnections.add ( (UnoConnection) a_event.Source);
		setStatusDisplay ();
	}
	
	@Override
	public void disconnected (EventObject a_event) {
		i_unoConnections.remove (a_event.Source);
		setStatusDisplay ();
	}
	
	@Override
	protected void close () {
		disconnectActionPerformed (null);
		suspendActionPerformed (null);
		super.close ();
	}
}

