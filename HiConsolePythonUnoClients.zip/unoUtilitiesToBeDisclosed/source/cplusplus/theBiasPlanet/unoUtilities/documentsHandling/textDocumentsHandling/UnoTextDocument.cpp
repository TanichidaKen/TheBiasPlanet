#include "theBiasPlanet/unoUtilities/documentsHandling/textDocumentsHandling/UnoTextDocument.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/UnoMessagesConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/UnoSpecialFileUrlsConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/stringsHandling/UnoExtendedStringHandler.hpp"

using namespace ::theBiasPlanet::unoUtilities::constantsGroups;
using namespace ::theBiasPlanet::unoUtilities::stringsHandling;

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace documentsHandling {
			namespace textDocumentsHandling {
				Reference <UnoTextDocument> UnoTextDocument::createTextDocument (Reference <UnoObjectsContext> a_unoObjectsContext, bool a_hiddenly) {
					return Reference <UnoTextDocument> (new UnoTextDocument (a_unoObjectsContext, UnoDocument::createUnoDocumentOrOpenUnoDocumentFile (a_unoObjectsContext, UnoSpecialFileUrlsConstantsGroup::c_writerNewDocument, nullopt, a_hiddenly)));
				}
				
				Reference <UnoTextDocument> UnoTextDocument::openTextDocumentFile (Reference <UnoObjectsContext> a_unoObjectsContext, string const & a_fileUrl, optional <string> const & a_password, bool a_hiddenly) {
					return Reference <UnoTextDocument> (new UnoTextDocument (a_unoObjectsContext, UnoDocument::createUnoDocumentOrOpenUnoDocumentFile (a_unoObjectsContext, a_fileUrl, a_password, a_hiddenly)));
				}
				
				Reference <UnoTextDocument> UnoTextDocument::getCurrentTextDocument (Reference <UnoObjectsContext> a_unoObjectsContext) {
					return Reference <UnoTextDocument> (new UnoTextDocument (a_unoObjectsContext, getCurrentUnoDocument (a_unoObjectsContext)));
				}
				
				UnoTextDocument::UnoTextDocument (Reference <UnoObjectsContext> a_unoObjectsContext, Reference <XComponent> a_textDocumentInXComponent) : UnoDocument (a_unoObjectsContext, a_textDocumentInXComponent), i_textDocumentInXTextDocument (Reference <XTextDocument> (i_unoDocumentInXModel, UNO_QUERY)) {
					if (i_textDocumentInXTextDocument.get () == nullptr) {
						throw Exception (UnoExtendedStringHandler::getOustring (UnoMessagesConstantsGroup::c_isNotTextDocument), *this);
					}
					i_controllerInXTextViewCursorSupplier = Reference <XTextViewCursorSupplier> (i_controllerInXController, UNO_QUERY);
					i_viewCursorInXTextViewCursor = i_controllerInXTextViewCursorSupplier->getViewCursor ();
					i_textInXText = i_textDocumentInXTextDocument->getText ();
				}
				
				Reference <XTextViewCursor> UnoTextDocument::getViewCursor () {
					return i_viewCursorInXTextViewCursor;
				}
				
				bool UnoTextDocument::insertText (string a_text) {
					getViewCursor ()->gotoEnd (false);
					i_textInXText->insertString (i_viewCursorInXTextViewCursor, UnoExtendedStringHandler::getOustring (a_text), false);
					return true;
				}
			}
		}
	}
}

