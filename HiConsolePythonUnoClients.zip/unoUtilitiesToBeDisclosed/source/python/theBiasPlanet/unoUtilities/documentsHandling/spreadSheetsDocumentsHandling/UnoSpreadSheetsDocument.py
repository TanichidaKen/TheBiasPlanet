from typing import cast
from typing import Optional
from com.sun.star.lang import XComponent
from com.sun.star.sheet import XSpreadsheetDocument
from com.sun.star.sheet import XSpreadsheets
from com.sun.star.sheet import XSpreadsheetView;
from theBiasPlanet.unoUtilities.connectionsHandling.UnoObjectsContext import UnoObjectsContext
from theBiasPlanet.unoUtilities.constantsGroups.UnoMessagesConstantsGroup import UnoMessagesConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.UnoSpecialFileUrlsConstantsGroup import UnoSpecialFileUrlsConstantsGroup
from theBiasPlanet.unoUtilities.documentsHandling.UnoDocument import UnoDocument

class UnoSpreadSheetsDocument (UnoDocument):
	def __init__ (a_this: "UnoSpreadSheetsDocument", a_unoObjectsContext: "UnoObjectsContext", a_spreadSheetsDocumentInXComponent: XComponent) -> None:
		a_this.i_spreadSheetsDocumentInXSpreadsheetDocument: XSpreadsheetDocument
		a_this.i_controllerInXSpreadsheetView: XSpreadsheetView
		a_this.i_spreadSheetsInXSpreadsheets: XSpreadsheets
		
		UnoDocument.__init__ (a_this, a_unoObjectsContext, a_spreadSheetsDocumentInXComponent)
		a_this.i_spreadSheetsDocumentInXSpreadsheetDocument = cast (XSpreadsheetDocument, a_spreadSheetsDocumentInXComponent)
		if a_this.i_spreadSheetsDocumentInXSpreadsheetDocument is None:
			raise Exception (UnoMessagesConstantsGroup.c_isNotSpreadSheetsDocument)
		a_this.i_controllerInXSpreadsheetView = cast (XSpreadsheetView, a_this.i_controllerInXController)
		a_this.i_spreadSheetsInXSpreadsheets = a_this.i_spreadSheetsDocumentInXSpreadsheetDocument.getSheets ()
	
	@staticmethod
	def createSpreadSheetsDocument (a_unoObjectsContext: "UnoObjectsContext", a_hiddenly: bool) -> "UnoSpreadSheetsDocument":
		return UnoSpreadSheetsDocument (a_unoObjectsContext, UnoDocument.createUnoDocumentOrOpenUnoDocumentFile (a_unoObjectsContext, UnoSpecialFileUrlsConstantsGroup.c_calcNewDocument, None, a_hiddenly))
	
	@staticmethod
	def openSpreadSheetsDocumentFile (a_unoObjectsContext: "UnoObjectsContext", a_fileUrl: str, a_password: Optional [str], a_hiddenly: bool) -> "UnoSpreadSheetsDocument":
		return UnoSpreadSheetsDocument (a_unoObjectsContext, UnoDocument.createUnoDocumentOrOpenUnoDocumentFile (a_unoObjectsContext, a_fileUrl, a_password, a_hiddenly))
	
	@staticmethod
	def getCurrentSpreadSheetsDocument (a_unoObjectsContext: "UnoObjectsContext") -> "UnoSpreadSheetsDocument":
		return UnoSpreadSheetsDocument (a_unoObjectsContext, UnoDocument.getCurrentUnoDocument (a_unoObjectsContext))

