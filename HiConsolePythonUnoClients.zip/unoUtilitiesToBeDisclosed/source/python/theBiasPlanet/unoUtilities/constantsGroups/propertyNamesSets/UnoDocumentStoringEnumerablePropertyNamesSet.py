from theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup import BaseEnumerableConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.UnoPropertyNamesSet import UnoPropertyNamesSet

class UnoDocumentStoringEnumerablePropertyNamesSet (BaseEnumerableConstantsGroup [str], UnoPropertyNamesSet):
	c_filterName_string: str = "FilterName"
	c_filterData_any: str = "FilterData" # supposed to be, but not necessarily, a sequence of 'com.sun.star.beans.PropertyValue'
	c_filterData_string: str = "FilterOptions" # Some filters take this property while some other filters take the above property.
	c_isTemplate_boolean: str = "AsTemplate"
	c_authorName_string: str = "Author"
	c_title_string: str = "DocumentTitle"
	c_encryptionData_NamedValuesSequence: str = "EncryptionData"
	c_password_string: str = "Password"
	c_charactersSet_string: str = "CharacterSet"
	c_version_short: str = "Version"
	c_versionDescription_string: str = "Comment"
	c_overwrites_boolen: str = "Overwrite"
	c_documentTypeSpecificData_any: str = "ComponentData"; # supposed to be, but not necessarily, a sequence of com.sun.star.beans.NamedValue
	
	def __init__ (a_this: "UnoDocumentStoringEnumerablePropertyNamesSet") -> None:
		BaseEnumerableConstantsGroup.__init__ (a_this, str)
	
	c_instance: "UnoDocumentStoringEnumerablePropertyNamesSet"

UnoDocumentStoringEnumerablePropertyNamesSet.c_instance = UnoDocumentStoringEnumerablePropertyNamesSet ()

