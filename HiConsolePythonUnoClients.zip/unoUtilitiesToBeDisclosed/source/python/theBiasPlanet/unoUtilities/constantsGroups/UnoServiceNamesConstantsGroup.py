
class UnoServiceNamesConstantsGroup:
	c_com_sun_star_frame_Desktop: str = "com.sun.star.frame.Desktop"
	c_com_sun_star_frame_DispatchHelper: str = "com.sun.star.frame.DispatchHelper"
	c_com_sun_star_xml_crypto_SecurityEnvironment: str = "com.sun.star.xml.crypto.SecurityEnvironment"
	c_com_sun_star_bridge_BridgeFactory: str = "com.sun.star.bridge.BridgeFactory"
	c_com_sun_star_connection_Connector: str = "com.sun.star.connection.Connector"
	c_com_sun_star_connection_Acceptor: str = "com.sun.star.connection.Acceptor"
	c_com_sun_star_util_URLTransformer: str = "com.sun.star.util.URLTransformer"

