from datetime import datetime
import sys
from typing import List
from typing import Optional
import uno
from theBiasPlanet.coreUtilities.messaging.Publisher import Publisher
from theBiasPlanet.unoUtilities.connectionsHandling.UnoConnection import UnoConnection
from theBiasPlanet.unoUtilities.connectionsHandling.UnoConnectionConnector import UnoConnectionConnector
from theBiasPlanet.unoUtilities.connectionsHandling.UnoObjectsContext import UnoObjectsContext
from theBiasPlanet.unoUtilities.documentsHandling.textDocumentsHandling.UnoTextDocument import UnoTextDocument
from theBiasPlanet.unoUtilities.programsHandling.UnoProcessEnvironment import UnoProcessEnvironment

class HiConsolePythonUnoClients:
	@staticmethod
	def main (a_arguments: List [str]) -> None:
		try:
			if (len (a_arguments) != 3):
				raise Exception ("The arguments have to be these.\nThe argument 1: the server url like 'socket,host=localhost,port=2002,tcpNoDelay=1;urp;StarOffice.ComponentContext'\nThe argument 2: the url of the file to be opened like ('file://${HOME}/myData/development/hiConsolePythonUnoClients/execution/HiConsolePythonUnoClientsTests.odt')")
			l_serverUrl: str = a_arguments [1]
			l_openedFileUrl: str = a_arguments [2]
			l_localUnoProcessEnvironment: "UnoProcessEnvironment" = UnoProcessEnvironment (str (datetime.now ()), None)
			l_unoConnectionConnector: "UnoConnectionConnector" = UnoConnectionConnector (l_localUnoProcessEnvironment.getLocalObjectsContext ())
			l_unoConnection: "UnoConnection" = l_unoConnectionConnector.connect (l_serverUrl, None)
			l_remoteUnoObjectsContext: Optional ["UnoObjectsContext"] = l_unoConnection.getRemoteObjectsContext ()
			if not (l_remoteUnoObjectsContext is None):
				l_unoTextDocument: UnoTextDocument = UnoTextDocument.openTextDocumentFile (l_remoteUnoObjectsContext, l_openedFileUrl, None, False)
				l_unoTextDocument.close ()
			l_unoConnection.disconnect ()
		except (Exception) as l_exception:
			Publisher.logErrorInformation (l_exception)
			sys.exit (1)
		sys.exit (0)

if __name__ == "__main__":
	HiConsolePythonUnoClients.main (sys.argv)

