from typing import List
from typing import Optional
from typing import TYPE_CHECKING
from typing import Type
from typing import TypeVar
if TYPE_CHECKING:
	from theBiasPlanet.unoUtilities.connectionsHandling.UnoObjectsContext import UnoObjectsContext

class UnoServiceHandler:
	@staticmethod
	def getServiceInstance (a_unoObjectsContext: "UnoObjectsContext", a_serviceName: str, a_arguments: Optional [List [object]]) -> object:
		l_serviceInstance: object = None
		l_targetProxy: object = None
		if (a_arguments is None):
			l_serviceInstance = a_unoObjectsContext.getServiceManager ().createInstanceWithContext (a_serviceName, a_unoObjectsContext)
		else:
			l_serviceInstance = a_unoObjectsContext.getServiceManager ().createInstanceWithArgumentsAndContext (a_serviceName, a_arguments, a_unoObjectsContext)
		if not (l_serviceInstance is None):
			l_targetProxy =  l_serviceInstance
		return l_targetProxy;

