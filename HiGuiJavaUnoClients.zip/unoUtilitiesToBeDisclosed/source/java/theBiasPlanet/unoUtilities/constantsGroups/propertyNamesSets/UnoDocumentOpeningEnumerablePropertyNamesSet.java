package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class UnoDocumentOpeningEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoDocumentOpeningPropertyNamesSet {
	public static final UnoDocumentOpeningEnumerablePropertyNamesSet c_instance = new UnoDocumentOpeningEnumerablePropertyNamesSet ();
	
	private UnoDocumentOpeningEnumerablePropertyNamesSet () {
	}
}

