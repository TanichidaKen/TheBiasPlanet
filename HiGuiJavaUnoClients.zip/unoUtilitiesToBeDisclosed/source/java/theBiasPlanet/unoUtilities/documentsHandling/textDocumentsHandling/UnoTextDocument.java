package theBiasPlanet.unoUtilities.documentsHandling.textDocumentsHandling;

import com.sun.star.lang.XComponent;
import com.sun.star.uno.UnoRuntime;
import com.sun.star.text.XTextDocument;
import com.sun.star.text.XTextViewCursorSupplier;
import com.sun.star.text.XTextViewCursor;
import theBiasPlanet.unoUtilities.connectionsHandling.UnoObjectsContext;
import theBiasPlanet.unoUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.documentsHandling.UnoDocument;

public class UnoTextDocument extends UnoDocument {
	private XTextDocument i_textDocumentInXTextDocument;
	private XTextViewCursorSupplier i_controllerInXTextViewCursorSupplier;
	
	public UnoTextDocument (UnoObjectsContext a_unoObjectsContext, XComponent a_textDocumentInXComponent) throws Exception {
		super (a_unoObjectsContext, a_textDocumentInXComponent);
		i_textDocumentInXTextDocument = (XTextDocument) UnoRuntime.queryInterface (XTextDocument.class, a_textDocumentInXComponent);
		if (i_textDocumentInXTextDocument == null) {
			throw new Exception (UnoMessagesConstantsGroup.c_isNotTextDocument);
		}
		i_controllerInXTextViewCursorSupplier = (XTextViewCursorSupplier) UnoRuntime.queryInterface (XTextViewCursorSupplier.class, i_controllerInXController);
	}
	
	public static UnoTextDocument createTextDocument (UnoObjectsContext a_unoObjectsContext, boolean a_hiddenly) throws Exception, com.sun.star.io.IOException {
		return new UnoTextDocument (a_unoObjectsContext, UnoDocument.createUnoDocumentOrOpenUnoDocumentFile (a_unoObjectsContext, UnoSpecialFileUrlsConstantsGroup.c_writerNewDocument, a_hiddenly));
	}
	
	public static UnoTextDocument openTextDocumentFile (UnoObjectsContext a_unoObjectsContext, String a_fileUrl, boolean a_hiddenly) throws Exception, com.sun.star.io.IOException {
		return new UnoTextDocument (a_unoObjectsContext, UnoDocument.createUnoDocumentOrOpenUnoDocumentFile (a_unoObjectsContext, a_fileUrl, a_hiddenly));
	}
	
	public static UnoTextDocument getCurrentTextDocument (UnoObjectsContext a_unoObjectsContext) throws Exception {
		return new UnoTextDocument (a_unoObjectsContext, getCurrentUnoDocument (a_unoObjectsContext));
	}
	
	public XTextViewCursor getViewCursor () {
		return i_controllerInXTextViewCursorSupplier.getViewCursor ();
	}
}

