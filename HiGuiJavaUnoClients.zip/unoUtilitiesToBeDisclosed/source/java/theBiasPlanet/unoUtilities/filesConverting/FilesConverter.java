package theBiasPlanet.unoUtilities.filesConverting;

import com.sun.star.beans.PropertyValue;
import com.sun.star.frame.XStorable2;
import com.sun.star.frame.XSynchronousDispatch;
import com.sun.star.lang.XComponent;
import com.sun.star.uno.Any;
import com.sun.star.uno.AnyConverter;
import com.sun.star.uno.UnoRuntime;
import com.sun.star.util.XCloseable;
import theBiasPlanet.coreUtilities.collectionsHandling.ListsFactory;
import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.connectionsHandling.UnoObjectsContext;
import theBiasPlanet.unoUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.*;
import theBiasPlanet.unoUtilities.documentsHandling.UnoDocumentTailor;
import theBiasPlanet.unoUtilities.propertiesHandling.UnoPropertiesHandler;

public class FilesConverter {
	private UnoObjectsContext i_remoteUnoObjectsContext = null;
	private final PropertyValue [] i_unoDocumentOpeningPropertiesArray;
	private XSynchronousDispatch i_fileOpeningUnoDispatcherInXSynchronousDispatch;
	
	public FilesConverter (UnoObjectsContext a_remoteUnoObjectsContext) throws Exception {
		i_remoteUnoObjectsContext = a_remoteUnoObjectsContext;
		i_unoDocumentOpeningPropertiesArray = UnoPropertiesHandler.buildPropertiesArray (UnoDocumentOpeningEnumerablePropertyNamesSet.c_instance.getValues (), ListsFactory. <Object>createArrayList (Boolean.valueOf (true), Boolean.valueOf (true), Boolean.valueOf (true), Boolean.valueOf (true)));
		i_fileOpeningUnoDispatcherInXSynchronousDispatch = i_remoteUnoObjectsContext.getFileOpeningUnoDispatcherInXSynchronousDispatch ();
	}
	
	public boolean convertFile (String a_convertedFileUrl, String a_targetFileUrl, PropertyValue [] a_documentStoringPropertiesArray, UnoDocumentTailor a_unoDocumentTailor) throws Exception {
		com.sun.star.util.URL l_convertedFileUrlInURL = i_remoteUnoObjectsContext.createUrlInURL (a_convertedFileUrl);
		Any l_convertedUnoDocumentInAny = (Any) i_fileOpeningUnoDispatcherInXSynchronousDispatch.dispatchWithReturnValue (l_convertedFileUrlInURL, i_unoDocumentOpeningPropertiesArray);
		boolean l_hasSucceeded = false;
		if (! (AnyConverter.isVoid (l_convertedUnoDocumentInAny))) {
			XComponent l_convertedUnoDocumentInXComponent = (XComponent) l_convertedUnoDocumentInAny.getObject ();
			try {
				if (a_unoDocumentTailor != null) {
					a_unoDocumentTailor.tailor (l_convertedUnoDocumentInXComponent);
				}
				XStorable2 l_convertedUnoDocumentInXStorable2 = (XStorable2) UnoRuntime.queryInterface (XStorable2.class, l_convertedUnoDocumentInXComponent);
				l_convertedUnoDocumentInXStorable2.storeToURL (a_targetFileUrl, a_documentStoringPropertiesArray);
				l_hasSucceeded = true;
			}
			catch (Exception l_exception) {
				throw l_exception;
			}
			XCloseable l_convertedUnoDocumentInXCloseable = (XCloseable) UnoRuntime.queryInterface (XCloseable.class, l_convertedUnoDocumentInXComponent);
			l_convertedUnoDocumentInXCloseable.close (false); 
		}
		else {
		}
		return l_hasSucceeded;
	}
}

