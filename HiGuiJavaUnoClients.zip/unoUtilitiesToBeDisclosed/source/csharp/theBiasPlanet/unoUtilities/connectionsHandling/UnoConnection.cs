namespace theBiasPlanet {
	namespace unoUtilities {
		namespace connectionsHandling {
			using System;
			using System.Collections.Generic;
			using uno;
			using unoidl.com.sun.star.bridge;
			using unoidl.com.sun.star.lang;
			using unoidl.com.sun.star.uno;
			using theBiasPlanet.coreUtilities.messaging;
			
			public class UnoConnection : XEventListener {
				private UnoObjectsContext i_remoteObjectsContext;
				private XComponent i_bridgeInXComponent;
				private List <UnoConnectionEventsListener> i_eventListeners;
				
				public UnoConnection (XComponentContext a_originalObjectsContextInXComponentContext, Dictionary <String, Any> a_extraNameToValueMap, XBridge a_bridgeInXBridge, List <UnoConnectionEventsListener> a_eventListeners) {
					i_remoteObjectsContext = new UnoObjectsContext (a_originalObjectsContextInXComponentContext, a_extraNameToValueMap);
					i_bridgeInXComponent = (XComponent) a_bridgeInXBridge;
					i_eventListeners = a_eventListeners;
					i_bridgeInXComponent.addEventListener (this);
					EventObject l_event = new EventObject (this);
					if (i_eventListeners != null) {
						foreach (UnoConnectionEventsListener l_eventListener in i_eventListeners){
							l_eventListener.connected (l_event);
						}
					}
				}
				
				public UnoObjectsContext getRemoteObjectsContext () {
					return i_remoteObjectsContext;
				}
				
				public void disconnect () {
					if (i_bridgeInXComponent != null) {
						i_bridgeInXComponent.dispose ();
					}
				}
				
				public void disposing (EventObject a_event) {
					Publisher.logNormalInformation (a_event.Source.ToString ());
					a_event.Source = this;
					if (i_eventListeners != null) {
						foreach (UnoConnectionEventsListener l_listener in i_eventListeners) {
							l_listener.disconnected (a_event);
						}
					}
					i_remoteObjectsContext = null;
					i_bridgeInXComponent = null;
					i_eventListeners = null;
				}
			}
		}
	}
}

