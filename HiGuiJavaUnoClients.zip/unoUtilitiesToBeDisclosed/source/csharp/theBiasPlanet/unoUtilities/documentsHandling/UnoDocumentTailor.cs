namespace theBiasPlanet {
	namespace unoUtilities {
		namespace documentsHandling {
			using System;
			using unoidl.com.sun.star.lang;
			using theBiasPlanet.unoUtilities.connectionsHandling;
			
			public class UnoDocumentTailor {
				protected UnoObjectsContext i_unoObjectsContext;
				
				public UnoDocumentTailor (UnoObjectsContext a_unoObjectsContext) {
					i_unoObjectsContext = a_unoObjectsContext;
				}
				
				public virtual bool tailor (XComponent a_unoDocumentInXComponent) {
					return true;
				}
			}
		}
	}
}

