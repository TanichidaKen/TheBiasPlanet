#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/UnoDocumentOpeningEnumerablePropertyNamesSet.hpp"

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			namespace propertyNamesSets {
				UnoDocumentOpeningEnumerablePropertyNamesSet::UnoDocumentOpeningEnumerablePropertyNamesSet () : BaseEnumerableConstantsGroup <string> ({ {"c_readOnly_boolean", c_readOnly_boolean}, {"c_hidden_boolean", c_hidden_boolean}, {"c_openNewView_boolean", c_openNewView_boolean}, {"c_silent_boolean", c_silent_boolean}})  {
				}
			}
		}
	}
}

