#include "theBiasPlanet/unoUtilities/constantsGroups/UnoFileNameSuffixesConstantsGroup.hpp"

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			string const UnoFileNameSuffixesConstantsGroup::c_unoIdlFileNameSuffix = "idl";
			string const UnoFileNameSuffixesConstantsGroup::c_unoDataTypesMergedRegistryFileNameSuffix = "rdb";
		}
	}
}

