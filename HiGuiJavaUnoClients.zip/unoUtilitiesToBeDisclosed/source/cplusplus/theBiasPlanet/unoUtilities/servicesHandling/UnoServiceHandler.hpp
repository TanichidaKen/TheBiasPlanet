#ifndef __theBiasPlanet_unoUtilities_servicesHandling_UnoServiceHandler_hpp__
	#define __theBiasPlanet_unoUtilities_servicesHandling_UnoServiceHandler_hpp__
	
	#include <list>
	#include <optional>
	#include <com/sun/star/uno/Reference.hxx>
	#include "theBiasPlanet/unoUtilities/connectionsHandling/UnoObjectsContext.hpp"

	using namespace ::std;
	using namespace ::theBiasPlanet::unoUtilities::connectionsHandling;
	
	namespace theBiasPlanet {
		namespace unoUtilities {
			namespace servicesHandling {
				class UnoServiceHandler {
					private:
						UnoServiceHandler ();
					public:
						template <typename T> static Reference <T> getServiceInstance (Reference <UnoObjectsContext> a_unoObjectsContext, string const & a_serviceName, optional <list <Any>> const & a_arguments);
				};
			}
		}
	}
#endif

