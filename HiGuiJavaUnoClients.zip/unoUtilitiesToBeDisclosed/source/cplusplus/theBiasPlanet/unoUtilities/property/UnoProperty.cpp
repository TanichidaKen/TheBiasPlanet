#include "theBiasPlanet/unoUtilities/property/UnoProperty.hpp"
#include "theBiasPlanet/unoUtilities/stringsHandling/UnoExtendedStringHandler.hpp"

using namespace ::theBiasPlanet::unoUtilities::stringsHandling;

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace property {
			UnoProperty::UnoProperty (string a_name, Any a_value) {
				Name = UnoExtendedStringHandler::getOustring (a_name);
				Value = a_value;
			}
		}
	}
}

