#ifndef __theBiasPlanet_unoUtilities_documentsHandling_UnoDocument_hpp__
	#define __theBiasPlanet_unoUtilities_documentsHandling_UnoDocument_hpp__
	
	#include <list>
	#include <mutex>
	#include <optional>
	#include <string>
	#include <com/sun/star/beans/PropertyValue.hpp>
	#include <com/sun/star/document/XDocumentEventBroadcaster.hpp>
	#include <com/sun/star/document/XDocumentEventListener.hpp>
	#include <com/sun/star/document/XEventBroadcaster.hpp>
	#include <com/sun/star/document/XEventListener.hpp>
	#include <com/sun/star/frame/XController.hpp>
	#include <com/sun/star/frame/XDispatchProvider.hpp>
	#include <com/sun/star/frame/XDispatchResultListener.hpp>
	#include <com/sun/star/frame/FeatureStateEvent.hpp>
	#include <com/sun/star/frame/XFrame.hpp>
	#include <com/sun/star/frame/XModel.hpp>
	#include <com/sun/star/frame/XStorable2.hpp>
	#include <com/sun/star/lang/XComponent.hpp>
	#include <com/sun/star/lang/EventObject.hpp>
	#include <com/sun/star/uno/Any.h>
	#include <com/sun/star/uno/Reference.hxx>
	#include <cppuhelper/compbase2.hxx>
	#include "theBiasPlanet/unoUtilities/connectionsHandling/UnoObjectsContext.hpp"
	#include "theBiasPlanet/unoUtilities/constantsGroups/UnoDispatchSlotsConstantsGroup.hpp"
	#include "theBiasPlanet/unoUtilities/dispatching/UnoDispatchResult.hpp"
	#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	using namespace ::com::sun::star::beans;
	using namespace ::com::sun::star::document;
	using namespace ::com::sun::star::frame;
	using namespace ::com::sun::star::lang;
	using namespace ::com::sun::star::uno;
	using namespace ::com::sun::star::util;
	using namespace ::cppu;
	using namespace ::theBiasPlanet::unoUtilities::connectionsHandling;
	using namespace ::theBiasPlanet::unoUtilities::constantsGroups;
	using namespace ::theBiasPlanet::unoUtilities::dispatching;
	
	namespace theBiasPlanet {
		namespace unoUtilities {
			namespace documentsHandling {
				class __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ UnoDocument : public WeakComponentImplHelper2 <XDispatchResultListener, XStatusListener> {
					protected:
						Mutex i_mutex;
						mutex i_standardMutex;
						Reference <UnoObjectsContext> i_unoObjectsContext;
						Reference <XModel> i_unoDocumentInXModel;
						Reference <XStorable2> i_unoDocumentInXStorable2;
						/*
						Reference <XDocumentEventBroadcaster> i_unoDocumentInXDocumentEventBroadcaster;
						Reference <XEventBroadcaster> i_unoDocumentInXEventBroadcaster;
						*/
						Reference <XController> i_controllerInXController;
						Reference <XFrame> i_frameInXFrame;
						Reference <XDispatchProvider> i_frameInXDispatchProvider;
						UnoDispatchResult * i_dispatchResult;
						static Reference <XComponent> createUnoDocumentOrOpenUnoDocumentFile (Reference <UnoObjectsContext> a_unoObjectsContext, string const & a_fileUrl, optional <string> const & a_password, bool const & a_hiddenly);
						static Reference <XComponent> getCurrentUnoDocument (Reference <UnoObjectsContext> a_unoObjectsContext);
						/*
						static Reference <XComponent> getUnoDocument (Reference <UnoObjectsContext> a_unoObjectsContext, string const & a_fileName);
						*/
					public:
						UnoDocument (Reference <UnoObjectsContext> a_unoObjectsContext, Reference <XComponent> a_unoDocumentInXComponent);
						virtual ~UnoDocument ();
						virtual Reference <UnoObjectsContext> getObjectsContext ();
						/*
						virtual Reference <XModel> getUnoDocumentinXModel ();
						virtual Reference <XDispatchProvider> getFrameInXDispatchProvider ();
						virtual void store ();
						virtual void storeAtUrl (string const & a_fileUrl);
						virtual void storeAtUrl (string const & a_fileUrl, string const & a_filterName, Any const & a_filterData);
						virtual string getLocationUrl ();
						virtual void addDocumentEventsListener (Reference <XDocumentEventListener> a_eventListener);
						virtual void removeDocumentEventsListener (Reference <XDocumentEventListener> a_eventListener);
						virtual void addEventsListener (Reference <XEventListener> a_eventListener);
						virtual void removeEventsListener (Reference <XEventListener> a_eventListener);
						*/
						virtual void close ();
						virtual optional <UnoDispatchResult> dispatch (UnoDispatchSlotsConstantsGroup::BaseDispatchSlot const & a_dispatchSlot, optional <list <Any>> const & a_argumentValues);
						virtual void SAL_CALL dispatchFinished (DispatchResultEvent const & a_dispatchResultEvent) override;
						virtual void SAL_CALL statusChanged (FeatureStateEvent const & a_featureStateEvent) override;
						virtual void SAL_CALL disposing (::com::sun::star::lang::EventObject const & a_source) override;
				};
			}
		}
	}
#endif

