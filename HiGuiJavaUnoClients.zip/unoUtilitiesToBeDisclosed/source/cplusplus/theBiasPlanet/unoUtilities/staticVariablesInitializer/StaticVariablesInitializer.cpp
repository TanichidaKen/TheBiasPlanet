#include "theBiasPlanet/unoUtilities/constantsGroups/UnoCharactersEncodingCodesConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/UnoDefaultValuesConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/UnoDispatchSlotsConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/UnoDocumentEventNamesConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/UnoFileNameSuffixesConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/UnoFileStoringFilterNamesConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/UnoGeneralConstantsConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/UnoMessagesConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/UnoServiceNamesConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/UnoSpecialFileUrlsConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/UnoSpecialFrameNamesConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/UnoDispatchCommandsCommonArgumentEnumerablePropertyNamesSet.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/UnoDocumentOpeningEnumerablePropertyNamesSet.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/UnoDocumentStoringEnumerablePropertyNamesSet.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/UnoObjectsContextPropertyNamesSet.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/UnoSpreadSheetPropertyNamesSet.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/Uno_uno_GoToCellEnumerablePropertyNamesSet.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/Uno_uno_GoToCellEnumerablePropertyNamesSet.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet.hpp"
#include "theBiasPlanet/unoUtilities/filesConverting/FilesConverter.hpp"
#include "theBiasPlanet/coreUtilities/stringsHandling/StringHandler.hpp"

using namespace ::theBiasPlanet::coreUtilities::stringsHandling;
using namespace ::theBiasPlanet::unoUtilities::constantsGroups::propertyNamesSets;

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			int const UnoCharactersEncodingCodesConstantsGroup::c_utf8 = 76;
			int const UnoCharactersEncodingCodesConstantsGroup::c_ucs2 = 65535;
			int const UnoCharactersEncodingCodesConstantsGroup::c_ucs4 = 65534;
			int const UnoCharactersEncodingCodesConstantsGroup::c_usAscii = 11;
			int const UnoCharactersEncodingCodesConstantsGroup::c_eucJp = 69;
			int const UnoCharactersEncodingCodesConstantsGroup::c_shiftJis = 64;
			string const UnoDefaultValuesConstantsGroup::c_customDefaultStyleName = "CustomDefault";
			string const UnoDefaultValuesConstantsGroup::c_initiallyOfferedUnoObjectName = "theBiasPlanet.UnoObjectsContext";
			string const UnoDocumentEventNamesConstantsGroup::c_documentDatumLoaded = "OnLoadFinished";
			string const UnoDocumentEventNamesConstantsGroup::c_titleChanged = "OnTitleChanged";
			string const UnoDocumentEventNamesConstantsGroup::c_focused = "OnFocus";
			string const UnoDocumentEventNamesConstantsGroup::c_viewCreated = "OnViewCreated";
			string const UnoDocumentEventNamesConstantsGroup::c_pagesCountChanged = "OnPageCountChange";
			string const UnoDocumentEventNamesConstantsGroup::c_frameDatumLoaded = "OnLoad";
			string const UnoDocumentEventNamesConstantsGroup::c_layouted = "OnLayoutFinished";
			string const UnoDocumentEventNamesConstantsGroup::c_preparingViewClosing = "OnPrepareViewClosing";
			string const UnoDocumentEventNamesConstantsGroup::c_preparingFrameUnloading = "OnPrepareUnload";
			string const UnoDocumentEventNamesConstantsGroup::c_viewClosed = "OnViewClosed";
			string const UnoDocumentEventNamesConstantsGroup::c_frameUnloaded = "OnUnload";
			string const UnoDocumentEventNamesConstantsGroup::c_unfocused = "OnUnfocus";
			string const UnoFileNameSuffixesConstantsGroup::c_unoIdlFileNameSuffix = "idl";
			string const UnoFileNameSuffixesConstantsGroup::c_unoDataTypesMergedRegistryFileNameSuffix = "rdb";
			string const UnoFileStoringFilterNamesConstantsGroup::c_openDocumentWordProcessingFilterName = "writer8";
			string const UnoFileStoringFilterNamesConstantsGroup::c_openDocumentSpreadsheetsFilterName = "calc8";
			string const UnoFileStoringFilterNamesConstantsGroup::c_openDocumentPresentationsFilterName = "impress8";
			string const UnoFileStoringFilterNamesConstantsGroup::c_microsoftWord97FileFilterName = "MS Word 97";
			string const UnoFileStoringFilterNamesConstantsGroup::c_microsoftWord2007XmlFilterName = "MS Word 2007 XML";
			string const UnoFileStoringFilterNamesConstantsGroup::c_microsoftExcel97FilterName = "MS Excel 97";
			string const UnoFileStoringFilterNamesConstantsGroup::c_microsoftExcel2007XmlFilterName = "Calc MS Excel 2007 XML";
			string const UnoFileStoringFilterNamesConstantsGroup::c_microsoftPowerPoint97FilterName = "MS PowerPoint 97";
			string const UnoFileStoringFilterNamesConstantsGroup::c_microsoftPowerPoint2007XmlFilterName = "Impress MS PowerPoint 2007 XML";
			string const UnoFileStoringFilterNamesConstantsGroup::c_csvFileFilterName = "Text - txt - csv (StarCalc)";
			string const UnoGeneralConstantsConstantsGroup::c_anyUnspecifiedString = "";
			char const UnoGeneralConstantsConstantsGroup::c_digitPlaceCharacter = '0';
			double const UnoGeneralConstantsConstantsGroup::c_numberExpressionModelNumber = 0.0;
			string const UnoGeneralConstantsConstantsGroup::c_cellPositionExpressionFormat = "$%s$%s";
			int const UnoGeneralConstantsConstantsGroup::c_rowIndexToRowPositionExpressionDifference = -1;
			string const UnoGeneralConstantsConstantsGroup::c_connectionUrlDelimiter = ";";
			string const UnoGeneralConstantsConstantsGroup::c_moduleDlimiter = "::";
			string const UnoGeneralConstantsConstantsGroup::c_unoServiceNameFormat = "%s.%s";
			string const UnoGeneralConstantsConstantsGroup::c_unoIdlFileNameFormat = StringHandler::format ("%%s.%s", UnoFileNameSuffixesConstantsGroup::c_unoIdlFileNameSuffix);
			string const UnoGeneralConstantsConstantsGroup::c_unoModuleBeginningRelativeExpressionFormat = "module %s {";
			string const UnoGeneralConstantsConstantsGroup::c_unoModuleEndRelativeExpressionFormat = "};";
			string const UnoMessagesConstantsGroup::c_remoteInstanceNotProvided = "The server didn't provide the remote instance.";
			string const UnoMessagesConstantsGroup::c_cellNotString = "The cell isn't a string value cell.";
			string const UnoMessagesConstantsGroup::c_unoDocumentNotSpecified = "The UNO document isn't specified.";
			string const UnoMessagesConstantsGroup::c_isNotSpreadSheetsDocument = "The specified UNO component is not a spread sheets document.";
			string const UnoMessagesConstantsGroup::c_isNotTextDocument = "The specified UNO component is not a text document.";
			string const UnoMessagesConstantsGroup::c_spreadSheetsDocumentNotSpecified = "The spread sheets document isn't specified.";
			string const UnoMessagesConstantsGroup::c_spreadSheetNotSpecified = "The spread sheet isn't specified.";
			string const UnoMessagesConstantsGroup::c_unoObjectsContextNotCreated = "Couldn't create the component context.";
			string const UnoMessagesConstantsGroup::c_unoObjectsContextNotSpecified = "The component context isn't specified.";
			string const UnoMessagesConstantsGroup::c_noCurrentSpreadSheetCell = "there is no current spread sheet cell.";
			string const UnoServiceNamesConstantsGroup::c_com_sun_star_frame_Desktop = "com.sun.star.frame.Desktop";
			string const UnoServiceNamesConstantsGroup::c_com_sun_star_frame_DispatchHelper = "com.sun.star.frame.DispatchHelper";
			string const UnoServiceNamesConstantsGroup::c_com_sun_star_xml_crypto_SecurityEnvironment = "com.sun.star.xml.crypto.SecurityEnvironment";
			string const UnoServiceNamesConstantsGroup::c_com_sun_star_bridge_BridgeFactory = "com.sun.star.bridge.BridgeFactory";
			string const UnoServiceNamesConstantsGroup::c_com_sun_star_connection_Connector = "com.sun.star.connection.Connector";
			string const UnoServiceNamesConstantsGroup::c_com_sun_star_connection_Acceptor = "com.sun.star.connection.Acceptor";
			string const UnoServiceNamesConstantsGroup::c_com_sun_star_util_URLTransformer = "com.sun.star.util.URLTransformer";
			string const UnoSpecialFileUrlsConstantsGroup::c_calcNewDocument = "private:factory/scalc";
			string const UnoSpecialFileUrlsConstantsGroup::c_writerNewDocument = "private:factory/swriter";
			string const UnoSpecialFrameNamesConstantsGroup::c_new = "_blank";
			string const UnoSpecialFrameNamesConstantsGroup::c_default = "_default";
			string const UnoSpecialFrameNamesConstantsGroup::c_self = "_self";
			string const UnoSpecialFrameNamesConstantsGroup::c_parent = "_parent";
			string const UnoSpecialFrameNamesConstantsGroup::c_top = "_top";
			string const UnoSpecialFrameNamesConstantsGroup::c_specialSub = "_beamer";
			namespace propertyNamesSets {
				string const UnoDispatchCommandsCommonArgumentEnumerablePropertyNamesSet::c_synchronousMode_boolean = "SynchronMode";
				UnoDispatchCommandsCommonArgumentEnumerablePropertyNamesSet const UnoDispatchCommandsCommonArgumentEnumerablePropertyNamesSet::c_instance;
				string const UnoDocumentOpeningEnumerablePropertyNamesSet::c_readOnly_boolean = "ReadOnly";
				string const UnoDocumentOpeningEnumerablePropertyNamesSet::c_hidden_boolean = "Hidden";
				string const UnoDocumentOpeningEnumerablePropertyNamesSet::c_openNewView_boolean = "OpenNewView";
				string const UnoDocumentOpeningEnumerablePropertyNamesSet::c_silent_boolean = "Silent";
				string const UnoDocumentOpeningEnumerablePropertyNamesSet::c_password_string = "Password";
				UnoDocumentOpeningEnumerablePropertyNamesSet const UnoDocumentOpeningEnumerablePropertyNamesSet::c_instance;
				string const UnoDocumentStoringEnumerablePropertyNamesSet::c_filterName_string = "FilterName";
				string const UnoDocumentStoringEnumerablePropertyNamesSet::c_filterData_any = "FilterData";
				string const UnoDocumentStoringEnumerablePropertyNamesSet::c_filterData_string = "FilterOptions";
				string const UnoDocumentStoringEnumerablePropertyNamesSet::c_isTemplate_boolean = "AsTemplate";
				string const UnoDocumentStoringEnumerablePropertyNamesSet::c_authorName_string = "Author";
				string const UnoDocumentStoringEnumerablePropertyNamesSet::c_title_string = "DocumentTitle";
				string const UnoDocumentStoringEnumerablePropertyNamesSet::c_encryptionData_NamedValuesSequence = "EncryptionData";
				string const UnoDocumentStoringEnumerablePropertyNamesSet::c_password_string = "Password";
				string const UnoDocumentStoringEnumerablePropertyNamesSet::c_charactersSet_string = "CharacterSet";
				string const UnoDocumentStoringEnumerablePropertyNamesSet::c_version_short = "Version";
				string const UnoDocumentStoringEnumerablePropertyNamesSet::c_versionDescription_string = "Comment";
				string const UnoDocumentStoringEnumerablePropertyNamesSet::c_overwrites_boolen = "Overwrite";
				string const UnoDocumentStoringEnumerablePropertyNamesSet::c_documentTypeSpecificData_any = "ComponentData"; // supposed to be, but not necessarily, a sequence of com.sun.star.beans.NamedValue
				UnoDocumentStoringEnumerablePropertyNamesSet const UnoDocumentStoringEnumerablePropertyNamesSet::c_instance;
				string const UnoObjectsContextPropertyNamesSet::c_identification_string = "identification";
				string const UnoSpreadSheetPropertyNamesSet::c_whetherIsVisible_boolean = "IsVisible";
				string const UnoSpreadSheetPropertyNamesSet::c_pageStyle = "PageStyle";
				string const Uno_uno_GoToCellEnumerablePropertyNamesSet::c_destinationPoint_string = "ToPoint";
				Uno_uno_GoToCellEnumerablePropertyNamesSet const Uno_uno_GoToCellEnumerablePropertyNamesSet::c_instance;
				string const Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet::c_styleName_string = "Param";
				string const Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet::c_styleFamilyKey_short = "Family";
				Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet::c_instance;
			}
			UnoDispatchSlotsConstantsGroup::BaseDispatchSlot const UnoDispatchSlotsConstantsGroup::c__uno_GoToCell (string (".uno:GoToCell"), optional <BaseEnumerableConstantsGroup <string>> (Uno_uno_GoToCellEnumerablePropertyNamesSet::c_instance));
			UnoDispatchSlotsConstantsGroup::BaseDispatchSlot const UnoDispatchSlotsConstantsGroup::c__uno_StyleNewByExample (string (".uno:StyleNewByExample"), optional <BaseEnumerableConstantsGroup <string>> (Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet::c_instance));
			/*
					// This slot is removed.
					static BaseDispatchSlot const c__uno_Cells = new BaseDispatchSlot (".uno:Cells", Uno_uno_CellsEnumerablePropertyNamesSet.c_instance);
					// This slot is removed.
					static BaseDispatchSlot const c__uno_Range = new BaseDispatchSlot (".uno:Range", Uno_uno_RangeEnumerablePropertyNamesSet.c_instance);
					// This slot is removed.
					static BaseDispatchSlot const c__uno_CellText = new BaseDispatchSlot (".uno:CellText", Uno_uno_CellTextEnumerablePropertyNamesSet.c_instance);
					// This slot is removed.
					static BaseDispatchSlot const c__uno_Selection = new BaseDispatchSlot (".uno:Selection", null);
					// This slot is removed.
					static BaseDispatchSlot const c__uno_ActiveCell = new BaseDispatchSlot (".uno:ActiveCell", null);
					// This slot is removed.
					static BaseDispatchSlot const c__uno_ActiveTable = new BaseDispatchSlot (".uno:ActiveTable", null);
					// This slot is removed.
					static BaseDispatchSlot const c__uno_Tables = new BaseDispatchSlot (".uno:Tables", null);
					// This slot is removed.
					static BaseDispatchSlot const c__uno_DataPilotTables = new BaseDispatchSlot (".uno:DataPilotTables", null);
					static BaseDispatchSlot const c__uno_Position = new BaseDispatchSlot (".uno:Position", null);
					static BaseDispatchSlot const c__uno_GoToCurrentCell = new BaseDispatchSlot (".uno:GoToCurrentCell", null);
					static BaseDispatchSlot const c__uno_StatusDocPos = new BaseDispatchSlot (".uno:StatusDocPos", null);
					static BaseDispatchSlot const c__uno_StatusSelectionMode = new BaseDispatchSlot (".uno:StatusSelectionMode", null);
					static BaseDispatchSlot const c__uno_StatusSelectionModeExp = new BaseDispatchSlot (".uno:StatusSelectionModeExp", null);
					static BaseDispatchSlot const c__uno_StatusSelectionModeExt = new BaseDispatchSlot (".uno:StatusSelectionModeExt", null);
					static BaseDispatchSlot const c__uno_StatusSelectionModeNorm = new BaseDispatchSlot (".uno:StatusSelectionModeNorm", null);
					static BaseDispatchSlot const c__uno_SelectData = new BaseDispatchSlot (".uno:SelectData", null);
					static BaseDispatchSlot const c__uno_SetInputMode = new BaseDispatchSlot (".uno:SetInputMode", null);
					static BaseDispatchSlot const c__uno_JumpToPreviousCell = new BaseDispatchSlot (".uno:JumpToPreviousCell", null);
					static BaseDispatchSlot const c__uno_DataSelect = new BaseDispatchSlot (".uno:DataSelect", null);
					static BaseDispatchSlot const c__uno_ExternalEdit = new BaseDispatchSlot (".uno:ExternalEdit", null);
					static BaseDispatchSlot const c__uno_PasteSpecial = new BaseDispatchSlot (".uno:PasteSpecial", Uno_uno_PasteSpecialEnumerablePropertyNamesSet.c_instance);
					*/

		}
		namespace filesConverting {
			string const FilesConverter::c_csvFormatStringFormat = "%d,%d,%d,1,,0,%b,false,%b,%b,false"; // the CSV items delimiter character code (can be specified like 'Character.codePointAt ("\t", 0)'), the CSV text items quotation character code (can be specified like 'Character.codePointAt ("\"", 0)'), the encoding code (76 -> UTF-8, 65535 -> UCS-2, 65534 -> UCS-4, 11 -> US-ASCII, 69 -> EUC_JP, 64 -> SHIFT_JIS), whether all the text items are quoted, whether the contents are exported as shown, whether the formula themselves are exported
		}
	}
}

