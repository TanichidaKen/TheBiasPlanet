package theBiasPlanet.hiGuiJavaUnoClients.programs;

import java.time.LocalDateTime;
import theBiasPlanet.coreUtilities.messaging.Publisher;
import theBiasPlanet.unoUtilities.programs.UnoFxProgram;
import theBiasPlanet.unoUtilities.programsHandling.UnoFxProcessEnvironment;
import theBiasPlanet.hiGuiJavaUnoClients.displaysHandling.HiGuiJavaUnoClientsMainScene;

public class HiGuiJavaUnoClients extends UnoFxProgram {
	public static void main (String [] a_arguments) throws Exception {
		Publisher.setLoggingLevel (3);
		if (a_arguments.length != 1) {
			throw new Exception ("The argument 1 must be the property file url.");
		}
		new UnoFxProcessEnvironment (LocalDateTime.now ().toString (), a_arguments[0]);
		s_unoConnectionScene = new HiGuiJavaUnoClientsMainScene ();
		launch (a_arguments);
	}
}

