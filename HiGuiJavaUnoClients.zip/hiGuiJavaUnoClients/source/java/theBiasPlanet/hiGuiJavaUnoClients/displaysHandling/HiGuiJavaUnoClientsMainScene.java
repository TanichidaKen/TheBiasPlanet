package theBiasPlanet.hiGuiJavaUnoClients.displaysHandling;

import java.io.File;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.FileChooser;
import com.sun.star.lang.EventObject;
import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.coreUtilities.messaging.CustomizedAlert;
import theBiasPlanet.coreUtilities.programsHandling.FxProcessEnvironment;
import theBiasPlanet.coreUtilities.stringsHandling.StringHandler;
import theBiasPlanet.unoUtilities.displaysHandling.UnoConnectionConnectorScene;
import theBiasPlanet.unoUtilities.documentsHandling.textDocumentsHandling.UnoTextDocument;

public class HiGuiJavaUnoClientsMainScene extends UnoConnectionConnectorScene {
	private static final String c_title;
	private static final int c_width;
	private static final int c_height;
	private static final String c_defaultDocumentFilePathPropertyName;
	private static final String c_documentFilePathLabelCaption;
	private static final int c_documentFilePathLabelWidth;
	private static final int c_documentFilePathTextFieldWidth;
	private GridPane i_applicationSpecificBasePane = null;
	private GridPane i_applicationSpecificInputOutputPane = null;
	private GridPane i_applicationSpecificCommandsPane = null;
	private Label i_documentFilePathLabel;
	private TextField i_documentFilePathTextField = null;
	private Button i_chooseDocumentFileButton = null;
	private FileChooser i_fileChooser = null;
	private Button i_openDocumentFileButton = null;
	
	static {
		c_title = "Hi GUI Java Uno Clients";
		c_width = 700;
		c_height = 205;
		c_defaultDocumentFilePathPropertyName = "filePath";
		c_documentFilePathLabelCaption = "Document File Path";
		c_documentFilePathLabelWidth = 240;
		c_documentFilePathTextFieldWidth = 420;
	}
	
	public HiGuiJavaUnoClientsMainScene () throws com.sun.star.uno.Exception {
		super (c_title, c_width, c_height);
		i_applicationSpecificBasePane = new GridPane ();
		i_applicationSpecificBasePane.getStyleClass().add (FxStyleClassesConstantsGroup.c_pane);
		i_applicationSpecificBasePane.getStyleClass().add (FxStyleClassesConstantsGroup.c_invisibleBorderLinesPane);
		i_applicationSpecificInputOutputPane = new GridPane ();
		i_applicationSpecificInputOutputPane.getStyleClass().add (FxStyleClassesConstantsGroup.c_pane);
		i_applicationSpecificInputOutputPane.getStyleClass().add (FxStyleClassesConstantsGroup.c_invisibleBorderLinesPane);
		i_applicationSpecificCommandsPane = new GridPane ();
		i_applicationSpecificCommandsPane.getStyleClass().add (FxStyleClassesConstantsGroup.c_pane);
		i_applicationSpecificCommandsPane.getStyleClass().add (FxStyleClassesConstantsGroup.c_invisibleBorderLinesPane);
		i_documentFilePathLabel = new Label (c_documentFilePathLabelCaption);
		i_documentFilePathLabel.setPrefWidth (c_documentFilePathLabelWidth);
		i_applicationSpecificInputOutputPane.add (i_documentFilePathLabel, 0, 0);
		i_documentFilePathTextField = new TextField (FxProcessEnvironment.s_currentEnvironment.getProperties ().getProperty (c_defaultDocumentFilePathPropertyName));
		i_documentFilePathTextField.setPrefWidth (c_documentFilePathTextFieldWidth);
		i_documentFilePathTextField.setDisable (true);
		i_applicationSpecificInputOutputPane.add (i_documentFilePathTextField, 1, 0);
		i_chooseDocumentFileButton = new Button (UserInterfaceComponentCaptionsConstantsGroup.c_chooseFile);
		i_chooseDocumentFileButton.setOnAction (
			(a_event) -> {
				chooseDocumentFileActionPerformed (a_event);
			}
		);
		i_chooseDocumentFileButton.setDisable (true);
		i_applicationSpecificInputOutputPane.add (i_chooseDocumentFileButton, 2, 0);
		i_fileChooser = new FileChooser ();
		i_basePane.add (i_applicationSpecificInputOutputPane, 0, 2);
		i_openDocumentFileButton = new Button (UserInterfaceComponentCaptionsConstantsGroup.c_open);
		i_openDocumentFileButton.setOnAction (
			(a_event) -> {
				openDocumentFileActionPerformed (a_event);
			}
		);
		i_openDocumentFileButton.setDisable (true);
		i_applicationSpecificCommandsPane.add (i_openDocumentFileButton, 0, 0);
		i_basePane.add (i_applicationSpecificCommandsPane, 0, 3);
	}
	
	private void openDocumentFileActionPerformed (ActionEvent a_event) {
		try {
			Thread l_subThread = new Thread (() -> {
				try {
					UnoTextDocument l_unoTextDocument = UnoTextDocument.openTextDocumentFile (i_unoConnection.getRemoteObjectsContext (), StringHandler.getUrl (i_documentFilePathTextField.getText ()), false);
				}
				catch (Exception l_exception) {
					l_exception.printStackTrace ();
					showAlert (CustomizedAlert.AlertType.ERROR, l_exception.toString ());
				}
				finally {
				}
			});
			l_subThread.start ();
		}
		catch (java.lang.Exception l_exception) {
			showAlert (CustomizedAlert.AlertType.ERROR, l_exception.toString ());
		}
	}
	
	private void chooseDocumentFileActionPerformed (ActionEvent a_event) {
		File l_chosenFile = i_fileChooser.showOpenDialog (getWindow ());
		if (l_chosenFile != null) {
			i_documentFilePathTextField.setText (l_chosenFile.toString ());
		}
	}
	
	private void setStatusDisplay () {
		Platform.runLater(() -> {
			if (i_unoConnection == null) {
				i_documentFilePathTextField.setDisable (true);
				i_chooseDocumentFileButton.setDisable (true);
				i_openDocumentFileButton.setDisable (true);
			}
			else {
				i_documentFilePathTextField.setDisable (false);
				i_chooseDocumentFileButton.setDisable (false);
				i_openDocumentFileButton.setDisable (false);
			}
		});
	}
	
	@Override
	public void connected (EventObject a_event) {
		super.connected (a_event);
		setStatusDisplay ();
	}
	
	@Override
	public void disconnected(EventObject a_event) {
		super.disconnected (a_event);
		setStatusDisplay ();
	}
	
	@Override
	protected void close () {
		super.close ();
	}
}

