package theBiasPlanet.coreUtilities.constantsGroups;

import java.util.LinkedHashMap;
import theBiasPlanet.coreUtilities.collectionsHandling.MapsFactory;

public interface GeneralConstantsConstantsGroup {
	int c_maximumBytesLengthPerUtf8Character = 4;
	int c_numberOfAlphabets = 26;
	int c_anyUnspecifiedInteger = -1;
	float c_anyUnspecifiedFloat = (float) -1.0;
	char c_anyUnspecifiedCharacter = (char) -1;
	int c_iterationStartingNumber = 0;
	int c_normalResult = 0;
	String c_emptySpace = "";
	char c_radixPointCharacter = '.';
	char c_thousandsDelimiter = ',';
	char c_escapingCharacter = '\\';
	char c_newLineCharacter = '\n';
	char c_carriageReturnCharacter = '\r';
	char c_semicolonCharacter = ';';
	char c_utfBomCharacter = '\uFEFF';
	char c_lessThanCharacter = '<';
	char c_greaterThanCharacter = '>';
	char c_ampersandCharacter = '&';
	char c_doubleQuotationMarkCharacter = '\"';
	char c_apostropheCharacter = '\'';
	char c_argumentsDelimiter = ' ';
	String c_colonDelimiter = ": ";
	String c_commaDelimiter = ", ";
	char c_linuxDirectoriesDelimiter = '/';
	char c_windowsDirectoriesDelimiter = '\\';
	char c_javaPackagesDelimiter = '.';
	char c_fileNameElementsDelimiter = '.';
	char c_nameElementsDelimiter = '_';
	char c_linuxPathsDelimiter = ':';
	char c_windowsPathsDelimiter = ';';
	String c_integerDefaultFormat = "%d";
	String c_doubleDefaultFormat = "%f";
	String c_booleanDefaultFormat = "%b";
	String c_globExpressionFormat = "glob:%s";
	String c_commandSwitchOrFlagStarter = "-";
	String c_linuxDirectoryPathFormat = String.format ("%%s%s%%s", c_linuxDirectoriesDelimiter);
	String c_windowsDirectoryPathFormat = String.format ("%%s%s%%s", c_windowsDirectoriesDelimiter);
	String c_linuxFilePathFormat = String.format ("%%s%s%%s", c_linuxDirectoriesDelimiter);
	String c_windowsFilePathFormat = String.format ("%%s%s%%s", c_windowsDirectoriesDelimiter);
	String c_fileNameFormat = String.format ("%%s%s%%s", c_fileNameElementsDelimiter);
	String c_javaClassNameFormat = String.format ("%%s%s%%s", c_javaPackagesDelimiter);
	String c_styleSheetFileNameFormat = String.format ("%%s%s%s", c_fileNameElementsDelimiter, FileNameSuffixesConstantsGroup.c_styleSheetFileNameSuffix);
	String c_javaFileNameFormat = String.format ("%%s%s%s", c_fileNameElementsDelimiter, FileNameSuffixesConstantsGroup.c_javaFileNameSuffix);
	String c_quotedByDoubleQuotationsFormat = "\"%s\"";
	String c_quotedByAngleBracketsFormat = "<%s>";
	String c_definitionNameFormat = String.format ("%1$s%1$s%%s%1$s%1$s", c_nameElementsDelimiter);
	String c_plus = "+";
	String c_propertyValueFormat = "${%s}";
	LinkedHashMap <Character, Integer> c_alphabetToAlphabetIndexMap = MapsFactory. <Character, Integer>createLinkedHashMap ('A', 0, 'B', 1, 'C', 2, 'D', 3, 'E', 4, 'F', 5, 'G', 6, 'H', 7, 'I', 8, 'J', 9, 'K', 10, 'L', 11, 'M', 12, 'N', 13, 'O', 14, 'P', 15, 'Q', 16, 'R', 17, 'S', 18, 'T', 19, 'U', 20, 'V', 21, 'W', 22, 'X', 23, 'Y', 24, 'Z', 25);
	LinkedHashMap <Integer, Character> c_alphabetIndexToAlphabetMap = MapsFactory. <Integer, Character>createLinkedHashMap ( 0, 'A', 1, 'B', 2, 'C', 3, 'D', 4, 'E', 5, 'F', 6, 'G', 7, 'H', 8, 'I', 9, 'J', 10, 'K', 11, 'L', 12, 'M', 13, 'N', 14, 'O', 15, 'P', 16, 'Q', 17, 'R', 18, 'S', 19, 'T', 20, 'U', 21, 'V', 22, 'w', 23, 'x', 24, 'y', 25, 'z');
}

