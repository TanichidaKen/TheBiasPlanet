package theBiasPlanet.coreUtilities.collectionsHandling;

import java.util.LinkedHashSet;
import java.util.Arrays;

public class SetsFactory {
	@SafeVarargs
	@SuppressWarnings("unchecked")
	public static <T> LinkedHashSet <T> createLinkedHashSet (Object ... a_items) {
		LinkedHashSet <T> l_linkedHashSet = new LinkedHashSet <T> ();
		if (a_items != null) {
			Arrays.stream (a_items).forEach (a_item -> {
				l_linkedHashSet.add ( (T) a_item);
			});
		}
		return l_linkedHashSet;
	}
	
	// This doesn't accept any array as an expandable item; pass Iterables instead.
	@SafeVarargs
	@SuppressWarnings("unchecked")
	public static <T> LinkedHashSet <T> createLinkedHashSetExpandingItems (Object ... a_items) {
		LinkedHashSet <T> l_linkedHashSet = new LinkedHashSet <T> ();
		if (a_items != null) {
			Arrays.stream (a_items).forEach (a_item -> {
				if (a_item instanceof Iterable) {
					for (Object l_element: (Iterable) a_item) {
						l_linkedHashSet.add ( (T) l_element);
					}
				}
				else {
					l_linkedHashSet.add ( (T) a_item);
				}
			});
		}
		return l_linkedHashSet;
	}
}

