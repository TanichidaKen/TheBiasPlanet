#ifndef __theBiasPlanet_coreUtilities_stringsHandling_StringTokenizer_hpp__
	#define __theBiasPlanet_coreUtilities_stringsHandling_StringTokenizer_hpp__
	
	#include <optional>
	#include <sstream>
	#include <string>
	#include "theBiasPlanet/coreUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	
	namespace theBiasPlanet {
		namespace coreUtilities {
			namespace stringsHandling {
				class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ StringTokenizer {
					private:
						stringstream i_originalStringStream;
						string const i_delimiter;
					public:
						StringTokenizer (string const & a_originalString, string const a_delimiter);
						virtual optional <string> nextToken ();
				};
			}
		}
	}
#endif

