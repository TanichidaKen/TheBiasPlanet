#include "theBiasPlanet/coreUtilities/processesHandling/ProcessHandler.hpp"
#ifdef GCC
#include <array>
#include <chrono>
#include <exception>
#include <unistd.h>
#include <sys/wait.h>
#include "theBiasPlanet/coreUtilities/collectionsHandling/ArraysFactory.hpp"
#include "theBiasPlanet/coreUtilities/constantsGroups/DefaultValuesConstantsGroup.hpp"
#include "theBiasPlanet/coreUtilities/messaging/Publisher.hpp"
#include "theBiasPlanet/coreUtilities/stringsHandling/StringHandler.hpp"

using namespace ::std::chrono;
using namespace ::theBiasPlanet::coreUtilities::collectionsHandling;
using namespace ::theBiasPlanet::coreUtilities::constantsGroups;
using namespace ::theBiasPlanet::coreUtilities::messaging;
using namespace ::theBiasPlanet::coreUtilities::stringsHandling;

namespace theBiasPlanet {
	namespace coreUtilities {
		namespace processesHandling {
			int const ProcessHandler::StandardInputAndOutputs::c_standardInputPollingIntervalInMilliSeconds = 1000;
			
			ProcessHandler::StandardInputAndOutputs::StandardInputAndOutputs (int a_processIdentification, int const & a_standardInputOutputFileDescription, int const & a_standardOutputInputFileDescription, int const & a_standardErrorOutputInputFileDescription) : i_processIdentification (a_processIdentification), i_processIsInterrupted (false), i_childProcessStandardInputBuffer (a_standardInputOutputFileDescription, std::ios::out), i_standardInputOutputStream (&i_childProcessStandardInputBuffer), i_childProcessStandardOutputBuffer (a_standardOutputInputFileDescription, std::ios::in), i_standardOutputInputStream (&i_childProcessStandardOutputBuffer), i_childProcessStandardErrorOutputBuffer (a_standardErrorOutputInputFileDescription, std::ios::in), i_standardErrorOutputInputStream (&i_childProcessStandardErrorOutputBuffer) {
			}
			
			ostream * ProcessHandler::StandardInputAndOutputs::getStandardInputOutputStream () {
				return &i_standardInputOutputStream;
			}
			
			istream * ProcessHandler::StandardInputAndOutputs::getStandardOutputInputStream () {
				return &i_standardOutputInputStream;
			}
			
			istream * ProcessHandler::StandardInputAndOutputs::getStandardErrorOutputInputStream () {
				return &i_standardErrorOutputInputStream;;
			}
			
			void ProcessHandler::StandardInputAndOutputs::relayStandardInputAsynchronously () {
				i_relayStandardInputSubThread = thread ([this] () -> void {
					try {
						char l_standardInputData [DefaultValuesConstantsGroup::c_smallBufferSize];
						int l_standardInputDataLength = -1;
						while (cin.good () && !i_processIsInterrupted) {
							l_standardInputDataLength = cin.readsome (l_standardInputData, DefaultValuesConstantsGroup::c_smallBufferSize);
							for (int l_characterIndex = 0; l_characterIndex < l_standardInputDataLength; l_characterIndex ++) {
								i_thereWereStandardInputContents = true;
								i_standardInputOutputStream.put (l_standardInputData [l_characterIndex]);
								i_standardInputOutputStream.flush ();
							}
							this_thread::sleep_for (milliseconds (c_standardInputPollingIntervalInMilliSeconds));
						}
					}
					catch (exception l_exception) {
						Publisher::logErrorInformation (StringHandler::format (string ("### A standard input error: %s."), string (l_exception.what ())));
					}
				});
			}
			
			void ProcessHandler::StandardInputAndOutputs::printStandardOutputAsynchronously () {
				i_printStandardOutputSubThread = thread ([this] () -> void {
					try {
						char l_standardOutputData [DefaultValuesConstantsGroup::c_smallBufferSize];
						int l_standardOutputDataLength = -1;
						while (true) {
							i_standardOutputInputStream.read (l_standardOutputData, DefaultValuesConstantsGroup::c_smallBufferSize);
							l_standardOutputDataLength = i_standardOutputInputStream.gcount ();
							for (int l_characterIndex = 0; l_characterIndex < l_standardOutputDataLength; l_characterIndex ++) {
								i_thereWereStandardOutputContents = true;
								cout.put (l_standardOutputData [l_characterIndex]);
								cout.flush ();
							}
							if (!(i_standardOutputInputStream.good ())) {
								break;
							}
						}
					}
					catch (exception l_exception) {
						Publisher::logErrorInformation (StringHandler::format (string ("### A standard output error: %s."), string (l_exception.what ())));
					}
				});
			}
			
			void ProcessHandler::StandardInputAndOutputs::printStandardErrorOutputAsynchronously () {
				i_printStandardErrorOutputSubThread = thread ([this] () -> void {
					try {
						char l_standardErrorOutputData [DefaultValuesConstantsGroup::c_smallBufferSize];
						int l_standardErrorOutputDataLength = -1;
						while (true) {
							i_standardErrorOutputInputStream.read (l_standardErrorOutputData, DefaultValuesConstantsGroup::c_smallBufferSize);
							l_standardErrorOutputDataLength  = i_standardErrorOutputInputStream.gcount ();
							for (int l_characterIndex = 0; l_characterIndex < l_standardErrorOutputDataLength; l_characterIndex ++) {
								i_thereWereStandardErrorOutputContents = true;
								cerr.put (l_standardErrorOutputData [l_characterIndex]);
								cerr.flush ();
							}
							if (!(i_standardErrorOutputInputStream.good ())) {
								break;
							}
						}
					}
					catch (exception l_exception) {
						Publisher::logErrorInformation (StringHandler::format (string ("### A standard error output error: %s."), string (l_exception.what ())));
					}
				});
			}
			
			optional <string> ProcessHandler::StandardInputAndOutputs::getStandardOutputNextLine () {
				try {
					if (!(i_standardOutputInputStream.eof ())) {
						i_thereWereStandardOutputContents = true;
						string l_line;
						getline (i_standardOutputInputStream, l_line);
						return optional <string> (l_line);
					}
					else {
						//i_standardOutputInputStream.close ();
						return nullopt;
					}
				}
				catch (exception l_exception) {
					Publisher::logErrorInformation (StringHandler::format (string ("### The standard output couldn't be scanned: %s."), string (l_exception.what ())));
					//i_standardOutputInputStream.close ();
					return nullopt;
				}
			}
			
			optional <string> ProcessHandler::StandardInputAndOutputs::getStandardErrorOutputNextLine () {
				try {
					if (!(i_standardErrorOutputInputStream.eof ())) {
						i_thereWereStandardErrorOutputContents = true;
						string l_line;
						getline (i_standardErrorOutputInputStream, l_line);
						return optional <string> (l_line);
					}
					else {
						//i_standardErrorOutputInputStream.close ();
						return nullopt;
					}
				}
				catch (exception l_exception) {
					Publisher::logErrorInformation (StringHandler::format (string ("### The standard error output couldn't be scanned: %s."), string (l_exception.what ())));
					//i_standardOutputInputStream.close ();
					return nullopt;
				}
			}
			
			bool ProcessHandler::StandardInputAndOutputs::thereWereStandardInputContents () {
				return i_thereWereStandardInputContents;
			}
			
			bool ProcessHandler::StandardInputAndOutputs::thereWereStandardOutputContents () {
				return i_thereWereStandardOutputContents;
			}
			
			bool ProcessHandler::StandardInputAndOutputs::thereWereStandardErrorOutputContents () {
				return i_thereWereStandardErrorOutputContents;
			}
			
			int ProcessHandler::StandardInputAndOutputs::waitUntillFinish () {
				if (i_printStandardErrorOutputSubThread.joinable ()) {
					i_printStandardErrorOutputSubThread.join ();
				}
				if (i_printStandardOutputSubThread.joinable ()) {
					i_printStandardOutputSubThread.join ();
				}
				int l_processReturn;
			   	waitpid (i_processIdentification, &l_processReturn, 0);
				if (i_relayStandardInputSubThread.joinable ()) {
					i_processIsInterrupted = true;
					i_relayStandardInputSubThread.join ();
				}
				return l_processReturn;
			}
			
			int ProcessHandler::execute (string const & a_workingDirectoryPath, list <string> const & a_commandAndArguments, bool const & a_waitsUntilFinish) {
				int l_childProcessReturn = 0;
				StandardInputAndOutputs l_childProcessStandardInputAndOutputs = executeAndReturnStandardInputAndOutputs (a_workingDirectoryPath, a_commandAndArguments);
				if (a_waitsUntilFinish) {
					l_childProcessStandardInputAndOutputs.printStandardOutputAsynchronously ();
					l_childProcessStandardInputAndOutputs.printStandardErrorOutputAsynchronously ();
					l_childProcessStandardInputAndOutputs.relayStandardInputAsynchronously ();
					l_childProcessReturn = l_childProcessStandardInputAndOutputs.waitUntillFinish ();
				}
				else {
				}
				return l_childProcessReturn;
			}
			
			ProcessHandler::StandardInputAndOutputs ProcessHandler::executeAndReturnStandardInputAndOutputs (string const & a_workingDirectoryPath, list <string> const & a_commandAndArguments) {
				// For each of the file descriptions arrays, the element 0 and the element 1 are the exit and the entrance of the pipe, respectively.
				int l_childProcessStandardInputPipeFileDescriptionsArray [2];
				int l_childProcessStandardOutputPipeFileDescriptionsArray [2];
				int l_childProcessStandardErrorOutputPipeFileDescriptionsArray [2];
				if ( (pipe (l_childProcessStandardInputPipeFileDescriptionsArray ) < 0) || (pipe (l_childProcessStandardOutputPipeFileDescriptionsArray) < 0) || (pipe (l_childProcessStandardErrorOutputPipeFileDescriptionsArray) < 0)) {
					throw runtime_error (string ("### A pipe error has occurred."));
				}
				pid_t l_processIdentification = fork ();
				if (l_processIdentification  == -1) {
					throw runtime_error (string ("### A fork error has occurred."));
				} else if (l_processIdentification == 0) {
					while ( (dup2 (l_childProcessStandardInputPipeFileDescriptionsArray [0], STDIN_FILENO) == -1) && (errno == EINTR)) {
					}
					close (l_childProcessStandardInputPipeFileDescriptionsArray [0]);
					close (l_childProcessStandardInputPipeFileDescriptionsArray [1]);
					while ( (dup2 (l_childProcessStandardOutputPipeFileDescriptionsArray [1], STDOUT_FILENO) == -1) && (errno == EINTR)) {
					}
					close (l_childProcessStandardOutputPipeFileDescriptionsArray [1]);
					close (l_childProcessStandardOutputPipeFileDescriptionsArray [0]);
					while ( (dup2 (l_childProcessStandardErrorOutputPipeFileDescriptionsArray [1], STDERR_FILENO) == -1) && (errno == EINTR)) {
					}
					close (l_childProcessStandardErrorOutputPipeFileDescriptionsArray [1]);
					close (l_childProcessStandardErrorOutputPipeFileDescriptionsArray [0]);
					if (a_workingDirectoryPath != string ("")) {
						chdir (a_workingDirectoryPath.c_str ());
					}
					int const l_lengthOfCommandAndArgumentsArray = a_commandAndArguments.size () + 1;
					char const * l_nonConstantCommandAndArgumentsArray [l_lengthOfCommandAndArgumentsArray];
					int l_commandOrArgumentIndex = 0;
					for (string const & l_commandOrArgument : a_commandAndArguments) {
						l_nonConstantCommandAndArgumentsArray  [l_commandOrArgumentIndex] = l_commandOrArgument.c_str ();
						l_commandOrArgumentIndex ++;
					}
					l_nonConstantCommandAndArgumentsArray  [l_commandOrArgumentIndex] = (char*) nullptr;
					// const_cast has to be used because the function, execvpe, is sloppy in that the first argument isn't 'char const * const' and the second and third arguments aren't 'char const * const *' as they really should be!
					char * const * l_commandAndArgumentsArray = const_cast <char * const *> (l_nonConstantCommandAndArgumentsArray);
					char * const l_environmentVariablesArray [1] = {(char*) nullptr};
					int l_childProcessExitStatus = execvpe (l_commandAndArgumentsArray [0], l_commandAndArgumentsArray, l_environmentVariablesArray);
					exit (l_childProcessExitStatus);
				}
				close (l_childProcessStandardInputPipeFileDescriptionsArray [0]);
				close (l_childProcessStandardOutputPipeFileDescriptionsArray [1]);
				close (l_childProcessStandardErrorOutputPipeFileDescriptionsArray [1]);
				return StandardInputAndOutputs (l_processIdentification, l_childProcessStandardInputPipeFileDescriptionsArray [1], l_childProcessStandardOutputPipeFileDescriptionsArray [0], l_childProcessStandardErrorOutputPipeFileDescriptionsArray [0]);
			}
		}
	}
}
#else
#endif

