#ifndef __theBiasPlanet_coreUtilities_visualCplusplusSpecificHeaders_VisualCplusplusSpecificDefinitions_hpp__
	#define __theBiasPlanet_coreUtilities_visualCplusplusSpecificHeaders_VisualCplusplusSpecificDefinitions_hpp__

	#ifdef GCC
		#define __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__
	#else
		#ifdef __theBiasPlanet_coreUtilities__
			#define __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ __declspec (dllexport)
		#else
			#define __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ __declspec (dllimport)
		#endif
	#endif
#endif

