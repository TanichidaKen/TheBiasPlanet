namespace theBiasPlanet {
	namespace unoUtilities {
		namespace programsHandling {
			using System;
			using System.Collections.Generic;
			using uno;
			using uno.util;
			using unoidl.com.sun.star.lang;
			using unoidl.com.sun.star.uno;
			using theBiasPlanet.unoUtilities.connectionsHandling;
			using theBiasPlanet.unoUtilities.constantsGroups;
			
			public class UnoProcessEnvironment {
				private UnoObjectsContext i_localObjectsContext;
				
				public UnoProcessEnvironment (String a_identification, String a_servicesSettingFileUrl) {
					try {
						Dictionary <String, Any> l_objectsContextExtraNameToValueMap = new Dictionary <String, Any> ();
						l_objectsContextExtraNameToValueMap [UnoObjectsContextPropertyNamesConstantsGroup.c_identification] = new Any (a_identification);
						XComponentContext l_originalLocalObjectsContext = Bootstrap.defaultBootstrap_InitialComponentContext ();
						i_localObjectsContext = new UnoObjectsContext (l_originalLocalObjectsContext, l_objectsContextExtraNameToValueMap);
					}
					catch (System.Exception l_exception) {
						throw new unoidl.com.sun.star.uno.Exception (String.Format ("{0} {1}", UnoMessagesConstantsGroup.c_objectsContextNotCreated,  l_exception.ToString ()), null);
					}
				}
				
				public UnoObjectsContext getLocalObjectsContext () {
					return i_localObjectsContext;
				}
			}
		}
	}
}

