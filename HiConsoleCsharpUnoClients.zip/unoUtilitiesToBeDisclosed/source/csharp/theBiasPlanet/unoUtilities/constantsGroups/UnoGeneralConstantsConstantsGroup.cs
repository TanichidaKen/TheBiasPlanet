namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			using System;
			
			public static class UnoGeneralConstantsConstantsGroup {
				public const String c_anyUnspecifiedString = "";
				public const char c_digitPlaceCharacter = '0';
				public const double c_numberExpressionModelNumber = 0.0;
				public const String c_cellPositionExpressionFormat = "$%s$%s";
				public const int c_rowIndexToRowPositionExpressionDifference = -1;
				public const String c_connectionUrlDelimiter = ";";
				public const String c_moduleDlimiter = "::";
				public const String c_unoServiceNameFormat = "%s.%s";
				public static readonly String c_unoIdlFileNameFormat = String.Format ("%s.{0}", UnoFileNameSuffixesConstantsGroup.c_unoIdlFileNameSuffix);
				public const String c_unoModuleBeginningRelativeExpressionFormat = "module %s {";
				public const String c_unoModuleEndRelativeExpressionFormat = "};";
			}
		}
	}
}

