namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			using System;
			
			public static class UnoSpecialFileUrlsConstantsGroup {
				public const String c_calcNewDocument = "private:factory/scalc";
				public const String c_writerNewDocument = "private:factory/swriter";
			}
		}
	}
}

