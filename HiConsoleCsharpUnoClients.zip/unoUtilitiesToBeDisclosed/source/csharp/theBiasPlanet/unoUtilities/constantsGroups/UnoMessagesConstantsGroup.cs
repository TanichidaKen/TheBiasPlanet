namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			using System;
			
			public static class UnoMessagesConstantsGroup {
				public const String c_remoteInstanceNotProvided = "The server didn't provide the remote instance.";
				public const String c_cellNotString = "The cell isn't a string value cell.";
				public const String c_unoDocumentNotSpecified = "The UNO document isn't specified.";
				public const String c_isNotSpreadSheetsDocument = "The specified UNO component is not a spread sheets document.";
				public const String c_isNotTextDocument = "The specified UNO component is not a text document.";
				public const String c_spreadSheetsDocumentNotSpecified = "The spread sheets document isn't specified.";
				public const String c_spreadSheetNotSpecified = "The spread sheet isn't specified.";
				public const String c_objectsContextNotCreated = "Couldn't create the component context.";
				public const String c_objectsContextNotSpecified = "The component context isn't specified.";
				public const String c_noCurrentSpreadSheetCell = "there is no current spread sheet cell.";
			}
		}
	}
}

