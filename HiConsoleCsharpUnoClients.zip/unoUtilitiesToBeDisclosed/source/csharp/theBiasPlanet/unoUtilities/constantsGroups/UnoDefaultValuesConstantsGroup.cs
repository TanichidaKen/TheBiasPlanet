namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			using System;
			
			public static class UnoDefaultValuesConstantsGroup {
				public const String c_customDefaultStyleName = "CustomDefault";
				public const String c_initiallyOfferedUnoObjectName = "theBiasPlanet.UnoObjectsContext";
			}
		}
	}
}

