namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			namespace propertyNamesSets {
				using System;
				using theBiasPlanet.coreUtilities.constantsGroups;
				
				public class UnoDocumentOpeningEnumerablePropertyNamesSet : BaseEnumerableConstantsGroup <String>, UnoPropertyNamesSet  {
					public const String c_readOnly_Boolean = "ReadOnly";
					public const String c_hidden_Boolean = "Hidden";
					public const String c_openNewView_Boolean = "OpenNewView";
					public const String c_silent_Boolean = "Silent";
					
					public static readonly UnoDocumentOpeningEnumerablePropertyNamesSet c_instance = new UnoDocumentOpeningEnumerablePropertyNamesSet ();
					
					private UnoDocumentOpeningEnumerablePropertyNamesSet () {
					}
				}
			}
		}
	}
}

