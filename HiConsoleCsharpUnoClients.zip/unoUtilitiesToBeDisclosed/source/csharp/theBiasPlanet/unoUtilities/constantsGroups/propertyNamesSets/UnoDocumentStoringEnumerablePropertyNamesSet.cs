namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			namespace propertyNamesSets {
				using System;
				using theBiasPlanet.coreUtilities.constantsGroups;
				
				public class UnoDocumentStoringEnumerablePropertyNamesSet : BaseEnumerableConstantsGroup <String>, UnoPropertyNamesSet  {
					public const String c_filterName_String = "FilterName";
					public const String c_filterData_Object = "FilterData"; // a sequence of parameter name-value sets
					public const String c_authorName_String = "Author";
					public const String c_title_String = "DocumentTitle";
					public const String c_description_String = "Comment";
					public const String c_password_String = "Password";
					
					public readonly UnoDocumentStoringEnumerablePropertyNamesSet c_instance = new UnoDocumentStoringEnumerablePropertyNamesSet ();
					
					private UnoDocumentStoringEnumerablePropertyNamesSet () {
					}
				}
			}
		}
	}
}

