namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			namespace propertyNamesSets {
				using System;
				using theBiasPlanet.coreUtilities.constantsGroups;
				
				public class Uno_uno_GoToCellEnumerablePropertyNamesSet : BaseEnumerableConstantsGroup <String>, UnoPropertyNamesSet {
					public const String c_destinationPoint_string = "ToPoint";
					public static readonly Uno_uno_GoToCellEnumerablePropertyNamesSet c_instance = new Uno_uno_GoToCellEnumerablePropertyNamesSet ();
					
					private Uno_uno_GoToCellEnumerablePropertyNamesSet () {
					}
				}
			}
		}
	}
}

