namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			namespace propertyNamesSets {
				using System;
				
				interface UnoPropertyNamesSet {
				}
			}
		}
	}
}

