namespace theBiasPlanet {
	namespace unoUtilities {
		namespace documentsHandling {
			using System;
			using System.Collections.Generic;
			using System.Text.RegularExpressions;
			using unoidl.com.sun.star.beans;
			using unoidl.com.sun.star.container;
			using unoidl.com.sun.star.document;
			using unoidl.com.sun.star.frame;
			using unoidl.com.sun.star.lang;
			using unoidl.com.sun.star.uno;
			using unoidl.com.sun.star.util;
			using theBiasPlanet.coreUtilities.collectionsHandling;
			using theBiasPlanet.coreUtilities.constantsGroups;
			using theBiasPlanet.unoUtilities.connectionsHandling;
			using theBiasPlanet.unoUtilities.constantsGroups;
			using theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;
			using theBiasPlanet.unoUtilities.dispatching;
			using theBiasPlanet.unoUtilities.propertiesHandling;
			
			public class UnoDocument {
				protected UnoObjectsContext i_objectsContext;
				protected XModel i_unoDocumentInXModel;
				protected XStorable2 i_unoDocumentInXStorable2;
				protected XDocumentEventBroadcaster i_unoDocumentInXDocumentEventBroadcaster;
				protected XEventBroadcaster i_unoDocumentInXEventBroadcaster;
				protected XController i_controllerInXController;
				protected XFrame i_frameInXFrame;
				protected XDispatchProvider i_frameInXDispatchProvider;
				protected UnoDispatchResult i_dispatchResult;
				protected XURLTransformer i_urlTransformerInXURLTransformer;
				
				public UnoDocument (UnoObjectsContext a_objectsContext, XComponent a_unoDocumentInXComponent) {
					if (a_objectsContext == null) {
						throw new System.Exception (UnoMessagesConstantsGroup.c_objectsContextNotSpecified);
					}
					i_objectsContext = a_objectsContext;
					if (a_unoDocumentInXComponent == null) {
						throw new System.Exception (UnoMessagesConstantsGroup.c_unoDocumentNotSpecified);
					}
					i_unoDocumentInXModel = (XModel) a_unoDocumentInXComponent;
					i_unoDocumentInXStorable2 = (XStorable2) i_unoDocumentInXModel;
					i_unoDocumentInXDocumentEventBroadcaster = (XDocumentEventBroadcaster) i_unoDocumentInXModel;
					i_unoDocumentInXEventBroadcaster = (XEventBroadcaster) i_unoDocumentInXModel;
					i_controllerInXController = (XController) i_unoDocumentInXModel.getCurrentController ();
					i_frameInXFrame = i_controllerInXController.getFrame ();
					i_frameInXDispatchProvider = (XDispatchProvider) i_frameInXFrame;
					i_urlTransformerInXURLTransformer = (XURLTransformer) i_objectsContext.getServiceInstance (UnoServiceNamesConstantsGroup.c_com_sun_star_util_URLTransformer, null);
					i_dispatchResult = null;
				}
				
				protected static XComponent createUnoDocumentOrOpenUnoDocumentFile (UnoObjectsContext a_objectsContext, String a_fileUrl, bool a_hiddenly) {
					XComponentLoader l_desktopInXComponentLoader = (XComponentLoader) a_objectsContext.getServiceInstance (UnoServiceNamesConstantsGroup.c_com_sun_star_frame_Desktop, null);
					return l_desktopInXComponentLoader.loadComponentFromURL (Regex.Replace (a_fileUrl, RegularExpressionsConstantsGroup.c_windowsDirectoryDelimiterRegularExpression, GeneralConstantsConstantsGroup.c_linuxDirectoriesDelimiter.ToString ()), UnoSpecialFrameNamesConstantsGroup.c_new, FrameSearchFlag.CREATE, UnoPropertiesHandler.buildPropertiesArray (UnoDocumentOpeningEnumerablePropertyNamesSet.c_instance.getValues (), ListsFactory.createList <Object> (false, a_hiddenly, false, a_hiddenly)));
				}
				
				protected static XComponent getCurrentUnoDocument (UnoObjectsContext a_objectsContext) {
					XDesktop2 l_desktopInXDesktop2 = (XDesktop2) a_objectsContext.getServiceInstance (UnoServiceNamesConstantsGroup.c_com_sun_star_frame_Desktop, null);
					return l_desktopInXDesktop2.getCurrentComponent ();
				}
				
				/*
				protected static XComponent getUnoDocument (UnoObjectsContext a_objectsContext, String a_fileName) throws Exception {
					XDesktop2 l_desktopInXDesktop2 = (XDesktop2) a_objectsContext.getServiceInstance (UnoServiceNamesConstantsGroup.c_com_sun_star_frame_Desktop, XDesktop2.class, null);
					XEnumeration l_unoComponentsInXEnumeration = l_desktopInXDesktop2.getComponents ().createEnumeration ();
					while (l_unoComponentsInXEnumeration.hasMoreElements ()) {
						XStorable2 l_unoComponentInXStorable2 = null;
						try {
							l_unoComponentInXStorable2 = (XStorable2) UnoRuntime.queryInterface (XStorable2.class, l_unoComponentsInXEnumeration.nextElement ());
						}
						catch (NoSuchElementException | WrappedTargetException l_exception) {
							// Practically, never would happen
							break;
						}
						if (l_unoComponentInXStorable2 == null) {
							continue;
						}
						try {
							if (Paths.get (l_unoComponentInXStorable2.getLocation ()).getFileName ().toString ().equals (a_fileName)) {
								return (XComponent) UnoRuntime.queryInterface (XComponent.class, l_unoComponentInXStorable2);
							}
						}
						// The possibility is that 'getLocation' returned null.
						catch (IllegalArgumentException l_exception) {
							continue;
						}
					}
					return null;
				}
				*/
				
				public UnoObjectsContext getObjectsContext () {
					return i_objectsContext;
				}
				
				/*
				public XModel getUnoDocumentinXModel () {
					return i_unoDocumentInXModel;
				}
				
				public XDispatchProvider getFrameInXDispatchProvider () {
					return i_frameInXDispatchProvider;
				}
				
				public void store () throws com.sun.star.io.IOException {
					i_unoDocumentInXStorable2.storeSelf (new PropertyValue [0]);
				}
				
				public void storeAtUrl (String a_fileUrl) throws com.sun.star.io.IOException {
					i_unoDocumentInXStorable2.storeAsURL (a_fileUrl.replaceAll (RegularExpressionsConstantsGroup.c_windowsDirectoryDelimiterRegularExpression.pattern (), String.valueOf (GeneralConstantsConstantsGroup.c_linuxDirectoriesDelimiter)), new PropertyValue [0]);
				}
				
				// Use UnoSpreadSheetsDocumentStoringFilterNamesConstantsGroup for a_filterName.
				public void storeAtUrl (String a_fileUrl, String a_filterName, Object a_filterData) throws com.sun.star.io.IOException {
					//ArrayList <PropertyValue> l_storingProperties = UnoPropertiesHandler.buildPropertiesArray  (UnoDocumentStoringEnumerablePropertyNamesSet.c_instance.getValues (), ListsFactory. <Object>createArrayList (a_filterName, a_filterData));
					i_unoDocumentInXStorable2.storeAsURL (a_fileUrl.replaceAll ("\\\\", "/"), UnoPropertiesHandler.buildPropertiesArray  (UnoDocumentStoringEnumerablePropertyNamesSet.c_instance.getValues (), ListsFactory. <Object>createArrayList (a_filterName, a_filterData)));
				}
				
				public String getLocationUrl () {
					return i_unoDocumentInXStorable2.getLocation ();
				}
				
				public void addDocumentEventsListener (XDocumentEventListener a_eventListener) {
					i_unoDocumentInXDocumentEventBroadcaster.addDocumentEventListener (a_eventListener);
				}
				
				public void removeDocumentEventsListener (XDocumentEventListener a_eventListener) {
					i_unoDocumentInXDocumentEventBroadcaster.removeDocumentEventListener (a_eventListener);
				}
				
				public void addEventsListener (XEventListener a_eventListener) {
					i_unoDocumentInXEventBroadcaster.addEventListener (a_eventListener);
				}
				
				public void removeEventsListener (XEventListener a_eventListener) {
					i_unoDocumentInXEventBroadcaster.removeEventListener (a_eventListener);
				}
				*/
				
				public void close () {
					XCloseable l_unoDocumentInXCloseable = (XCloseable) i_unoDocumentInXStorable2;
					l_unoDocumentInXCloseable.close (false); 
				}
				
				/*
				public UnoDispatchResult dispatch (UnoDispatchSlotsConstantsGroup.BaseDispatchSlot a_dispatchSlot, List <Object> a_argumentValues) {
					//List <PropertyValue> l_dispatchArgumentProperties = UnoPropertiesHandler.buildPropertiesArray (UnoDispatchCommandsCommonArgumentEnumerablePropertyNamesSet.c_instance.getValues (), ListsFactory. <Object>createArrayList (Boolean.valueOf (true)));
					if (a_dispatchSlot.c_argumentPropertyNamesSet != null && a_argumentValues != null) {
						l_dispatchArgumentProperties.addAll (UnoPropertiesHandler.buildPropertiesArray (a_dispatchSlot.c_argumentPropertyNamesSet.getValues (), a_argumentValues));
					}
					else {
					}
					com.sun.star.util.URL [] l_urls = new com.sun.star.util.URL [1];
					l_urls [GeneralConstantsConstantsGroup.c_iterationStartingNumber] = new com.sun.star.util.URL ();
					l_urls [GeneralConstantsConstantsGroup.c_iterationStartingNumber].Complete = a_dispatchSlot.c_url;
					i_urlTransformerInXURLTransformer.parseStrict (l_urls);
					XNotifyingDispatch l_dispatchInXNotifyingDispatch = UnoRuntime.queryInterface (XNotifyingDispatch.class, i_frameInXDispatchProvider.queryDispatch (l_urls [GeneralConstantsConstantsGroup.c_iterationStartingNumber], UnoSpecialFrameNamesConstantsGroup.c_self, GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger));
					if (l_dispatchInXNotifyingDispatch != null) {
						synchronized (this) {
							i_dispatchResult = new UnoDispatchResult ();
							l_dispatchInXNotifyingDispatch.addStatusListener (this, l_urls [GeneralConstantsConstantsGroup.c_iterationStartingNumber]);
							l_dispatchInXNotifyingDispatch.dispatchWithNotification (l_urls [GeneralConstantsConstantsGroup.c_iterationStartingNumber], ArraysFactory. <PropertyValue>createArray (PropertyValue.class, l_dispatchArgumentProperties), this);
							l_dispatchInXNotifyingDispatch.removeStatusListener (this, l_urls [GeneralConstantsConstantsGroup.c_iterationStartingNumber]);
							return i_dispatchResult;
						}
					}
					else {
						theBiasPlanet.coreUtilities.messaging.Publisher.show (String.format ("### The dispatch isn't found: %s", l_urls [GeneralConstantsConstantsGroup.c_iterationStartingNumber]));
						return null;
					}
				}
				*/
				
				public void dispatchFinished (DispatchResultEvent a_dispatchResultEvent) {
					i_dispatchResult.setDispatchResult (a_dispatchResultEvent);
				}
				
				public void statusChanged (FeatureStateEvent a_featureStateEvent) {
					i_dispatchResult.addRelatedInformationPiece (a_featureStateEvent);
					//theBiasPlanet.coreUtilities.messaging.Publisher.show (String.Format ("The dispatch state is changed: the URL = {0}, the feature descriptor = {1}, Requery = {2}, the state = {3}", a_featureStateEvent.FeatureURL.Complete, a_featureStateEvent.FeatureDescriptor, a_featureStateEvent.Requery, a_featureStateEvent.State.ToString ()));
				}
				
				public void disposing (unoidl.com.sun.star.lang.EventObject a_source) {
				}
			}
		}
	}
}

