package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

public interface UnoObjectsContextPropertyNamesConstantsGroup {
	String c_identification = "identification";
}

