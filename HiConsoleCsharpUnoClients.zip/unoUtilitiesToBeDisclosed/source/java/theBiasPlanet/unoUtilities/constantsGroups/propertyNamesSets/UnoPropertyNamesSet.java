package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

public interface UnoPropertyNamesSet {
}

