package theBiasPlanet.unoUtilities.connectionsHandling;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import com.sun.star.bridge.BridgeExistsException;
import com.sun.star.bridge.XBridge;
import com.sun.star.bridge.XBridgeFactory;
import com.sun.star.connection.XConnection;
import com.sun.star.lang.XComponent;
import com.sun.star.uno.UnoRuntime;
import com.sun.star.uno.XComponentContext;
import theBiasPlanet.unoUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.servicesHandling.UnoServiceHandler;
;

abstract public class UnoConnectionsFactory {
	protected UnoObjectsContext i_localObjectsContext;
	protected XBridgeFactory i_bridgesFactoryInXBridgeFactory;
	
	protected UnoConnectionsFactory (UnoObjectsContext a_localObjectsContext) {
		i_localObjectsContext = a_localObjectsContext;
	}
	
	protected final void initialize () throws com.sun.star.uno.Exception {
		i_bridgesFactoryInXBridgeFactory = (XBridgeFactory) i_localObjectsContext.getServiceInstance (UnoServiceNamesConstantsGroup.c_com_sun_star_bridge_BridgeFactory, XBridgeFactory.class, null);
	}
	
	protected final UnoConnection setupConnection (XConnection a_connectionInXConnection, StringTokenizer a_urlTokenizer, String a_connectionIdentification, List <UnoConnectionEventsListener> a_eventListeners) throws com.sun.star.uno.Exception {
		XBridge l_bridgeInXBridge = null;
		try {
			l_bridgeInXBridge = i_bridgesFactoryInXBridgeFactory.createBridge ("", a_urlTokenizer.nextToken (), a_connectionInXConnection, (a_unoObjectName) -> {
				if (UnoDefaultValuesConstantsGroup.c_initiallyOfferedUnoObjectName.equals (a_unoObjectName)) {
					return i_localObjectsContext;
				}
				else {
					return null;
				}
			});
		}
		catch (BridgeExistsException l_exception) {
			// This can't happen
		}
		Object l_remoteObjectsContextInXInterface =  l_bridgeInXBridge.getInstance (a_urlTokenizer.nextToken ());
		if (l_remoteObjectsContextInXInterface == null) {
				throw new com.sun.star.uno.Exception (UnoMessagesConstantsGroup.c_remoteInstanceNotProvided, null);
		}
		Map <String, Object> l_objectsContextExtraNameToValueMap = new HashMap <String, Object> ();
		l_objectsContextExtraNameToValueMap.put (UnoObjectsContextPropertyNamesConstantsGroup.c_identification, String.format ("%s: %s", a_connectionInXConnection.getDescription (), a_connectionIdentification));
		UnoConnection l_unoConnection = new UnoConnection ((XComponentContext) UnoRuntime.queryInterface (XComponentContext.class, l_remoteObjectsContextInXInterface), l_objectsContextExtraNameToValueMap, l_bridgeInXBridge, a_eventListeners);
		return l_unoConnection;
	}
}

