package theBiasPlanet.unoUtilities.connectionsHandling;

import java.time.LocalDateTime;
import java.util.List;
import java.util.StringTokenizer;
import com.sun.star.connection.XConnection;
import com.sun.star.connection.XConnector;
import theBiasPlanet.unoUtilities.connectionsHandling.UnoObjectsContext;
import theBiasPlanet.unoUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.servicesHandling.UnoServiceHandler;

public class UnoConnectionConnector extends UnoConnectionsFactory {
	public UnoConnectionConnector (UnoObjectsContext a_localObjectsContext) throws com.sun.star.uno.Exception {
		super (a_localObjectsContext);
		initialize ();
	}
	
	public final UnoConnection connect (String a_url, List <UnoConnectionEventsListener> a_eventListeners) throws com.sun.star.uno.Exception {
		StringTokenizer l_urlTokenizer = new StringTokenizer (a_url, UnoGeneralConstantsConstantsGroup.c_connectionUrlDelimiter);
		XConnector l_unoConnectionConnectorInXConnector = (XConnector) i_localObjectsContext.getServiceInstance (UnoServiceNamesConstantsGroup.c_com_sun_star_connection_Connector, XConnector.class, null);
		XConnection l_connectionInXConnection = l_unoConnectionConnectorInXConnector.connect (l_urlTokenizer.nextToken ());
		UnoConnection l_unoConnection = setupConnection (l_connectionInXConnection, l_urlTokenizer, LocalDateTime.now ().toString (), a_eventListeners);
		return l_unoConnection;
	}
}

