package theBiasPlanet.unoUtilities.connectionsHandling;

import java.util.List;
import java.util.Map;
import com.sun.star.frame.XDesktop2;
import com.sun.star.frame.XDispatchProvider;
import com.sun.star.frame.XSynchronousDispatch;
import com.sun.star.lang.XMultiComponentFactory;
import com.sun.star.uno.UnoRuntime;
import com.sun.star.uno.XComponentContext;
import com.sun.star.util.XURLTransformer;
import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.servicesHandling.UnoServiceHandler;

public class UnoObjectsContext implements XComponentContext {
	private XComponentContext i_originalObjectsContextInXComponentContext;
	private Map <String, Object> i_extraNameToValueMap;
	private XDesktop2 i_unoDesktopInXDesktop2;
	private XDispatchProvider i_unoDesktopInXDispatchProvider;
	private XURLTransformer i_urlTransformerInXURLTransformer;
	private XSynchronousDispatch i_fileOpeningUnoDispatcherInXSynchronousDispatch;
	
	public UnoObjectsContext (XComponentContext a_originalObjectsContextInXComponentContext, Map <String, Object> a_extraNameToValueMap) throws com.sun.star.uno.Exception {
		if (a_originalObjectsContextInXComponentContext == null) {
			throw new com.sun.star.uno.Exception (UnoMessagesConstantsGroup.c_objectsContextNotSpecified);
		}
		i_originalObjectsContextInXComponentContext = a_originalObjectsContextInXComponentContext;
		i_extraNameToValueMap = a_extraNameToValueMap;
		i_unoDesktopInXDesktop2 = null;
		i_unoDesktopInXDispatchProvider = null;
		i_urlTransformerInXURLTransformer = null;
		i_fileOpeningUnoDispatcherInXSynchronousDispatch = null;
	}
	
	@Override
	public final Object getValueByName (String a_name) {
		if (i_extraNameToValueMap != null && i_extraNameToValueMap.containsKey (a_name)) {
			return i_extraNameToValueMap.get (a_name);
		}
		return i_originalObjectsContextInXComponentContext.getValueByName (a_name);
	}
	
	@Override
	public final XMultiComponentFactory getServiceManager () {
		return i_originalObjectsContextInXComponentContext.getServiceManager ();
	}
	
	public final boolean isFromSameOrigin (UnoObjectsContext a_unoObjectsContext) {
		if ((a_unoObjectsContext ==  null) || (i_extraNameToValueMap.get (UnoObjectsContextPropertyNamesConstantsGroup.c_identification) == null)) {
			return false;
		}
		if (i_extraNameToValueMap.get (UnoObjectsContextPropertyNamesConstantsGroup.c_identification).equals (a_unoObjectsContext.getValueByName (UnoObjectsContextPropertyNamesConstantsGroup.c_identification))) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public Object getServiceInstance (String a_serviceName, Class a_targetClass, List <Object> a_arguments) throws com.sun.star.uno.Exception {
		return UnoServiceHandler.getServiceInstance (this, a_serviceName, a_targetClass, a_arguments);
	}
	
	public XDesktop2 getUnoDesktopInXDesktop2 () throws Exception {
		if (i_unoDesktopInXDesktop2 == null) {
			i_unoDesktopInXDesktop2 = (XDesktop2) getServiceInstance (UnoServiceNamesConstantsGroup.c_com_sun_star_frame_Desktop, XDesktop2.class, null);
		}
		else {
		}
		return i_unoDesktopInXDesktop2;
	}
	
	public XDispatchProvider getUnoDesktopInXDispatchProvider () throws Exception {
		if (i_unoDesktopInXDispatchProvider == null) {
			if (i_unoDesktopInXDesktop2 == null) {
				getUnoDesktopInXDesktop2 ();
			}
			else {
			}
			i_unoDesktopInXDispatchProvider = (XDispatchProvider) UnoRuntime.queryInterface (XDispatchProvider.class, i_unoDesktopInXDesktop2);
		}
		else {
		}
		return i_unoDesktopInXDispatchProvider;
	}
	
	public XSynchronousDispatch getFileOpeningUnoDispatcherInXSynchronousDispatch () throws Exception {
		if (i_fileOpeningUnoDispatcherInXSynchronousDispatch == null) {
			i_fileOpeningUnoDispatcherInXSynchronousDispatch = UnoRuntime.queryInterface (XSynchronousDispatch.class, getUnoDesktopInXDispatchProvider ().queryDispatch (createUrlInURL ("file:///"), UnoSpecialFrameNamesConstantsGroup.c_new, GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger));
		}
		return i_fileOpeningUnoDispatcherInXSynchronousDispatch;
	}
	
	public com.sun.star.util.URL createUrlInURL (String a_url) throws Exception {
		if (i_urlTransformerInXURLTransformer == null) {
			i_urlTransformerInXURLTransformer = (XURLTransformer) getServiceInstance (UnoServiceNamesConstantsGroup.c_com_sun_star_util_URLTransformer, XURLTransformer.class, null);
		}
		com.sun.star.util.URL [] l_urlInURLArray = new com.sun.star.util.URL [1];
		l_urlInURLArray [GeneralConstantsConstantsGroup.c_iterationStartingNumber] = new com.sun.star.util.URL ();
		l_urlInURLArray [GeneralConstantsConstantsGroup.c_iterationStartingNumber].Complete = a_url;
		i_urlTransformerInXURLTransformer.parseStrict (l_urlInURLArray);
		return l_urlInURLArray [GeneralConstantsConstantsGroup.c_iterationStartingNumber];
	}
}

