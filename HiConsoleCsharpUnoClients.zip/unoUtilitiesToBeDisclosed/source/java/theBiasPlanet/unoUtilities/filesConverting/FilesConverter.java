package theBiasPlanet.unoUtilities.filesConverting;

import java.util.ArrayList;
import com.sun.star.beans.PropertyValue;
import com.sun.star.beans.XPropertySet;
import com.sun.star.container.XIndexAccess;
import com.sun.star.container.XNamed;
import com.sun.star.frame.XStorable2;
import com.sun.star.frame.XSynchronousDispatch;
import com.sun.star.lang.XComponent;
import com.sun.star.sheet.XSpreadsheetDocument;
import com.sun.star.sheet.XSpreadsheets2;
import com.sun.star.uno.Any;
import com.sun.star.uno.AnyConverter;
import com.sun.star.uno.UnoRuntime;
import com.sun.star.util.XCloseable;
import theBiasPlanet.coreUtilities.collectionsHandling.ListsFactory;
import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.coreUtilities.messaging.Publisher;
import theBiasPlanet.unoUtilities.connectionsHandling.UnoObjectsContext;
import theBiasPlanet.unoUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.*;
import theBiasPlanet.unoUtilities.documentsHandling.UnoDocumentTailor;
import theBiasPlanet.unoUtilities.propertiesHandling.UnoPropertiesHandler;

public class FilesConverter {
	private static final String c_csvFormatStringFormat = "%d,%d,%d,1,,0,%b,false,%b,%b,false"; // the CSV items delimiter character code (can be specified like 'Character.codePointAt ("\t", 0)'), the CSV text items quotation character code (can be specified like 'Character.codePointAt ("\"", 0)'), the encoding code (76 -> UTF-8, 65535 -> UCS-2, 65534 -> UCS-4, 11 -> US-ASCII, 69 -> EUC_JP, 64 -> SHIFT_JIS), whether all the text items are quoted, whether the contents are exported as shown, whether the formula themselves are exported
	private UnoObjectsContext i_remoteUnoObjectsContext = null;
	private XSynchronousDispatch i_fileOpeningUnoDispatcherInXSynchronousDispatch;
	
	public FilesConverter (UnoObjectsContext a_remoteUnoObjectsContext) throws Exception {
		i_remoteUnoObjectsContext = a_remoteUnoObjectsContext;
		i_fileOpeningUnoDispatcherInXSynchronousDispatch = i_remoteUnoObjectsContext.getFileOpeningUnoDispatcherInXSynchronousDispatch ();
	}
	
	public boolean convertFile (String a_convertedFileUrl, String a_convertedFilePassword, String a_targetFileUrl, PropertyValue [] a_documentStoringPropertiesArray, UnoDocumentTailor a_unoDocumentTailor) throws Exception {
		com.sun.star.util.URL l_convertedFileUrlInURL = i_remoteUnoObjectsContext.createUrlInURL (a_convertedFileUrl);
		PropertyValue [] l_unoDocumentOpeningPropertiesArray = UnoPropertiesHandler.buildPropertiesArray (UnoDocumentOpeningEnumerablePropertyNamesSet.c_instance.getValues (), ListsFactory. <Object>createArrayList (Boolean.valueOf (true), Boolean.valueOf (true), Boolean.valueOf (true), Boolean.valueOf (true), a_convertedFilePassword != null ? a_convertedFilePassword: ""));
		Any l_convertedUnoDocumentInAny = (Any) i_fileOpeningUnoDispatcherInXSynchronousDispatch.dispatchWithReturnValue (l_convertedFileUrlInURL, l_unoDocumentOpeningPropertiesArray);
		boolean l_hasSucceeded = false;
		if (! (AnyConverter.isVoid (l_convertedUnoDocumentInAny))) {
			XComponent l_convertedUnoDocumentInXComponent = (XComponent) l_convertedUnoDocumentInAny.getObject ();
			try {
				if (a_unoDocumentTailor != null) {
					a_unoDocumentTailor.tailor (l_convertedUnoDocumentInXComponent);
				}
				XStorable2 l_convertedUnoDocumentInXStorable2 = (XStorable2) UnoRuntime.queryInterface (XStorable2.class, l_convertedUnoDocumentInXComponent);
				l_convertedUnoDocumentInXStorable2.storeToURL (a_targetFileUrl, a_documentStoringPropertiesArray);
				l_hasSucceeded = true;
			}
			catch (Exception l_exception) {
				throw l_exception;
			}
			XCloseable l_convertedUnoDocumentInXCloseable = (XCloseable) UnoRuntime.queryInterface (XCloseable.class, l_convertedUnoDocumentInXComponent);
			l_convertedUnoDocumentInXCloseable.close (false); 
		}
		else {
		}
		return l_hasSucceeded;
	}
	
	public static PropertyValue [] createCsvFileStoringPropertiesArray (int a_itemsDelimiterCharacterCode, int a_textItemQuotationCharacterCode, int a_charactersEncodingCode, boolean a_whetherAllTextItemsAreQuoted, boolean a_whetherContentsAreExportedAsShown, boolean a_whetherFormulaThemselvesAreExported) {
		ArrayList <String> l_documentStoringPropertyNames = ListsFactory.<String>createArrayList (
			UnoDocumentStoringEnumerablePropertyNamesSet.c_filterName_string,
			UnoDocumentStoringEnumerablePropertyNamesSet.c_filterData_string,
			UnoDocumentStoringEnumerablePropertyNamesSet.c_overwrites_boolen
		);
		ArrayList <Object> l_documentStoringPropertyValues = ListsFactory.<Object>createArrayList (
			UnoFileStoringFilterNamesConstantsGroup.c_csvFileFilterName,
			String.format (c_csvFormatStringFormat, a_itemsDelimiterCharacterCode, a_textItemQuotationCharacterCode, a_charactersEncodingCode, a_whetherAllTextItemsAreQuoted, a_whetherContentsAreExportedAsShown, a_whetherFormulaThemselvesAreExported),
			Boolean.valueOf (true)
		);
		return UnoPropertiesHandler.buildPropertiesArray (l_documentStoringPropertyNames, l_documentStoringPropertyValues);
	}
	
	// a_targetFileNamingRule: 0 -> augmented by the sheet index, 1 -> augmented by the sheet name
	public boolean convertSpreadSheetsDocumentFileToCsvFiles (String a_convertedFileUrl, String a_convertedFilePassword, String a_targetFileUrlBase, PropertyValue [] a_documentStoringPropertiesArray, UnoDocumentTailor a_unoDocumentTailor, int a_targetFileNamingRule, boolean a_whetherWritesHiddenSheets) throws Exception {
		com.sun.star.util.URL l_convertedFileUrlInURL = i_remoteUnoObjectsContext.createUrlInURL (a_convertedFileUrl);
		PropertyValue [] l_unoDocumentOpeningPropertiesArray = UnoPropertiesHandler.buildPropertiesArray (UnoDocumentOpeningEnumerablePropertyNamesSet.c_instance.getValues (), ListsFactory. <Object>createArrayList (Boolean.valueOf (true), Boolean.valueOf (true), Boolean.valueOf (true), Boolean.valueOf (true), a_convertedFilePassword != null ? a_convertedFilePassword: ""));
		Any l_convertedUnoDocumentInAny = (Any) i_fileOpeningUnoDispatcherInXSynchronousDispatch.dispatchWithReturnValue (l_convertedFileUrlInURL, l_unoDocumentOpeningPropertiesArray);
		boolean l_hasSucceeded = false;
		if (! (AnyConverter.isVoid (l_convertedUnoDocumentInAny))) {
			XComponent l_convertedUnoDocumentInXComponent = (XComponent) l_convertedUnoDocumentInAny.getObject ();
			try {
				if (a_unoDocumentTailor != null) {
					a_unoDocumentTailor.tailor (l_convertedUnoDocumentInXComponent);
				}
				XSpreadsheetDocument l_spreadSheetsDocumentInXSpreadsheetDocument = (XSpreadsheetDocument) UnoRuntime.queryInterface (XSpreadsheetDocument.class, l_convertedUnoDocumentInXComponent);
				if (l_spreadSheetsDocumentInXSpreadsheetDocument == null) {
					Publisher.logErrorInformation ("The document is not any spread sheet.");
					return false;
				}
				else {
					XStorable2 l_convertedUnoDocumentInXStorable2 = (XStorable2) UnoRuntime.queryInterface (XStorable2.class, l_convertedUnoDocumentInXComponent);
					XSpreadsheets2 l_spreadSheetsInXSpreadsheets2 = (XSpreadsheets2) UnoRuntime.queryInterface (XSpreadsheets2.class, l_spreadSheetsDocumentInXSpreadsheetDocument.getSheets ());
					XIndexAccess l_spreadSheetsInXIndexAccess = (XIndexAccess) UnoRuntime.queryInterface (XIndexAccess.class, l_spreadSheetsInXSpreadsheets2);
					int l_numberOfSheets = l_spreadSheetsInXIndexAccess.getCount ();
					XNamed l_spreadSheetInXNamed = null;
					XPropertySet l_spreadSheetInXPropertySet = null;
					String l_targetFileNameAugmentation = null;
					int l_lastPeriodPositionInTargetFileUrlBase = a_targetFileUrlBase.lastIndexOf (".");
					String l_augmentedTargetFileUrl = null;
					boolean l_whetherSheetIsVisible = false;
					for (int l_sheetIndex = GeneralConstantsConstantsGroup.c_iterationStartingNumber; l_sheetIndex < l_numberOfSheets; l_sheetIndex ++) {
						l_spreadSheetInXNamed = (XNamed) UnoRuntime.queryInterface (XNamed.class, (((Any) l_spreadSheetsInXIndexAccess.getByIndex (l_sheetIndex)).getObject ()));
						if (a_whetherWritesHiddenSheets) {
						}
						else {
							l_spreadSheetInXPropertySet = (XPropertySet) UnoRuntime.queryInterface (XPropertySet.class, l_spreadSheetInXNamed);
							l_whetherSheetIsVisible = ((Boolean) l_spreadSheetInXPropertySet.getPropertyValue (UnoSpreadSheetPropertyNamesSet.c_whetherIsVisible_boolean)).booleanValue (); 
							if (!l_whetherSheetIsVisible) {
								continue;
							}
						}
						if (a_targetFileNamingRule == 0) {
							l_targetFileNameAugmentation = String.format ("%d", l_sheetIndex);
						}
						else {
							l_targetFileNameAugmentation = l_spreadSheetInXNamed.getName (); 
						}
						if (l_lastPeriodPositionInTargetFileUrlBase >= GeneralConstantsConstantsGroup.c_iterationStartingNumber) {
							l_augmentedTargetFileUrl = String.format ("%s_%s%s", a_targetFileUrlBase.substring (GeneralConstantsConstantsGroup.c_iterationStartingNumber, l_lastPeriodPositionInTargetFileUrlBase), l_targetFileNameAugmentation, a_targetFileUrlBase.substring (l_lastPeriodPositionInTargetFileUrlBase));
						}
						else {
							l_augmentedTargetFileUrl = String.format ("%s_%s", a_targetFileUrlBase, l_targetFileNameAugmentation);
						}
						if (l_sheetIndex != GeneralConstantsConstantsGroup.c_iterationStartingNumber) {
							l_spreadSheetsInXSpreadsheets2.moveByName (l_spreadSheetInXNamed.getName (), (short) GeneralConstantsConstantsGroup.c_iterationStartingNumber);
						}
						l_convertedUnoDocumentInXStorable2.storeToURL (l_augmentedTargetFileUrl, a_documentStoringPropertiesArray);
					}
					l_hasSucceeded = true;
				}
			}
			catch (Exception l_exception) {
				throw l_exception;
			}
			XCloseable l_convertedUnoDocumentInXCloseable = (XCloseable) UnoRuntime.queryInterface (XCloseable.class, l_convertedUnoDocumentInXComponent);
			l_convertedUnoDocumentInXCloseable.close (false); 
		}
		else {
		}
		return l_hasSucceeded;
	}
}

