from typing import cast
from typing import Dict
from typing import List
from typing import Optional
import uno
from unohelper import Base as UnoBase
from com.sun.star.bridge import XBridge;
from com.sun.star.lang import EventObject
from com.sun.star.lang import XComponent
from com.sun.star.lang import XEventListener
from com.sun.star.uno import XComponentContext
from theBiasPlanet.unoUtilities.connectionsHandling.UnoConnectionEventsListener import UnoConnectionEventsListener
from theBiasPlanet.unoUtilities.connectionsHandling.UnoObjectsContext import UnoObjectsContext

class UnoConnection (UnoBase, XEventListener):
	def __init__ (a_this: "UnoConnection", a_originalObjectsContextInXComponentContext: XComponentContext , a_extraNameToValueMap: Dict [str, object], a_bridgeInXBridge: XBridge, a_eventListeners: Optional [List [UnoConnectionEventsListener]]) -> None:
		a_this.i_remoteObjectsContext: Optional [UnoObjectsContext]
		a_this.i_bridgeInXComponent: XComponent
		a_this.i_eventListeners: Optional [List [UnoConnectionEventsListener]]
		
		a_this.i_remoteObjectsContext = UnoObjectsContext (a_originalObjectsContextInXComponentContext, a_extraNameToValueMap)
		a_this.i_bridgeInXComponent = cast (XComponent, a_bridgeInXBridge)
		a_this.i_eventListeners = a_eventListeners
		a_this.i_bridgeInXComponent.addEventListener (a_this)
		l_event: EventObject  = EventObject (a_this)
		if (not (a_this.i_eventListeners is None)):
			l_eventListener: UnoConnectionEventsListener
			for l_eventListener in a_this.i_eventListeners:
				l_eventListener.connected (l_event);
				
	def getRemoteObjectsContext (a_this: "UnoConnection") -> Optional [UnoObjectsContext]:
		return a_this.i_remoteObjectsContext
	
	def disconnect (a_this: "UnoConnection") -> None:
		if (not (a_this.i_bridgeInXComponent is None)):
			a_this.i_bridgeInXComponent.dispose ()
	
	def disposing (a_this: "UnoConnection", a_event: EventObject) -> None:
		#Publisher.logNormalInformation (a_event.Source.ToString ());
		a_event.Source = a_this
		if (not (a_this.i_eventListeners is None)):
			l_listener: UnoConnectionEventsListener
			for l_listener in a_this.i_eventListeners:
				l_listener.disconnected (a_event)
		a_this.i_remoteObjectsContext = None
		a_this.i_bridgeInXComponent = None
		a_this.i_eventListeners = None

