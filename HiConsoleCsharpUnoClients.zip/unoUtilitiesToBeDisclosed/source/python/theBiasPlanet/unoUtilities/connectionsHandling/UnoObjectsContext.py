import re
import sys
from typing import Dict
from typing import List
from typing import Match
from typing import cast
from typing import Optional
from typing import Pattern
import uno
from unohelper import Base as UnoBase
from com.sun.star.uno import XComponentContext
from com.sun.star.frame import XDesktop2
from com.sun.star.frame import XDispatchProvider
from com.sun.star.frame import XSynchronousDispatch
from com.sun.star.lang import XMultiComponentFactory
from com.sun.star.util import URL as com_sun_star_util_URL
#from com.sun.star.util import XURLTransformer
from theBiasPlanet.coreUtilities.constantsGroups.FileNameSuffixesConstantsGroup import FileNameSuffixesConstantsGroup
from theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup import GeneralConstantsConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.UnoMessagesConstantsGroup import UnoMessagesConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.UnoServiceNamesConstantsGroup import UnoServiceNamesConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.UnoSpecialFrameNamesConstantsGroup import UnoSpecialFrameNamesConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.UnoObjectsContextPropertyNamesSet import UnoObjectsContextPropertyNamesSet
from theBiasPlanet.unoUtilities.servicesHandling.UnoServiceHandler import UnoServiceHandler

class UnoObjectsContext (UnoBase, XComponentContext):
	def __init__ (a_this: "UnoObjectsContext", a_originalObjectsContextInXComponentContext: XComponentContext, a_extraNameToValueMap: Dict [str, object]) -> None:
		a_this.i_originalObjectsContextInXComponentContext: XComponentContext
		a_this.i_extraNameToValueMap: Dict [str, object]
		a_this.i_unoDesktopInXDesktop2: XDesktop2
		a_this.i_unoDesktopInXDispatchProvider: XDispatchProvider
		#a_this.i_urlTransformerInXURLTransformer: XURLTransformer
		a_this.i_fileOpeningUnoDispatcherInXSynchronousDispatch: XSynchronousDispatch
		
		if (a_originalObjectsContextInXComponentContext is None):
			raise Exception (UnoMessagesConstantsGroup.c_unoObjectsContextNotSpecified)
		a_this.i_originalObjectsContextInXComponentContext = a_originalObjectsContextInXComponentContext
		a_this.i_extraNameToValueMap = a_extraNameToValueMap
		a_this.i_unoDesktopInXDesktop2 = None
		a_this.i_unoDesktopInXDispatchProvider = None
		#a_this.i_urlTransformerInXURLTransformer = None
		a_this.i_fileOpeningUnoDispatcherInXSynchronousDispatch = None
	
	def getValueByName (a_this: "UnoObjectsContext", a_name: str) -> object:
		if (not (a_this.i_extraNameToValueMap is None) and a_name in a_this.i_extraNameToValueMap):
			return a_this.i_extraNameToValueMap [a_name]
		return a_this.i_originalObjectsContextInXComponentContext.getValueByName (a_name)
	
	def getServiceManager (a_this: "UnoObjectsContext") -> XMultiComponentFactory:
		return a_this.i_originalObjectsContextInXComponentContext.getServiceManager ()
	
	def isFromSameOrigin (a_this: "UnoObjectsContext", a_unoObjectsContext: "UnoObjectsContext") -> bool:
		if ((a_unoObjectsContext is None) or not (UnoObjectsContextPropertyNamesSet.c_identification_string in a_this.i_extraNameToValueMap)):
			return False
		if (a_this.i_extraNameToValueMap [UnoObjectsContextPropertyNamesSet.c_identification_string] == (a_unoObjectsContext.getValueByName (UnoObjectsContextPropertyNamesSet.c_identification_string))):
			return True
		else:
			return False
	
	def getServiceInstance (a_this: "UnoObjectsContext", a_serviceName: str, a_arguments: Optional [List [object]]) -> object:
		return UnoServiceHandler.getServiceInstance (a_this, a_serviceName, a_arguments)
	
	def getUnoDesktopInXDesktop2 (a_this: "UnoObjectsContext") -> XDesktop2:
		if (a_this.i_unoDesktopInXDesktop2 is None):
			a_this.i_unoDesktopInXDesktop2 = cast (XDesktop2, a_this.getServiceInstance (UnoServiceNamesConstantsGroup.c_com_sun_star_frame_Desktop, None))
		else:
			None
		return a_this.i_unoDesktopInXDesktop2
	
	def getUnoDesktopInXDispatchProvider (a_this: "UnoObjectsContext") -> XDispatchProvider:
		if (a_this.i_unoDesktopInXDispatchProvider is None):
			if (a_this.i_unoDesktopInXDesktop2 is None):
				a_this.getUnoDesktopInXDesktop2 ()
			else:
				None
			a_this.i_unoDesktopInXDispatchProvider = cast (XDispatchProvider, a_this.i_unoDesktopInXDesktop2)
		else:
			None
		return a_this.i_unoDesktopInXDispatchProvider
	
	def getFileOpeningUnoDispatcherInXSynchronousDispatch (a_this: "UnoObjectsContext") -> XSynchronousDispatch:
		if (a_this.i_fileOpeningUnoDispatcherInXSynchronousDispatch is None):
			a_this.i_fileOpeningUnoDispatcherInXSynchronousDispatch = cast (XSynchronousDispatch, a_this.getUnoDesktopInXDispatchProvider ().queryDispatch (a_this.createUrlInURL ("file:///"), UnoSpecialFrameNamesConstantsGroup.c_new, GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger))
		return a_this.i_fileOpeningUnoDispatcherInXSynchronousDispatch
	
	def createUrlInURL (a_this: "UnoObjectsContext", a_url: str) -> com_sun_star_util_URL:
		"""
		if (a_this.i_urlTransformerInXURLTransformer is None):
			a_this.i_urlTransformerInXURLTransformer = cast (XURLTransformer, a_this.getServiceInstance (UnoServiceNamesConstantsGroup.c_com_sun_star_util_URLTransformer, None))
		l_urlInURL: URL = URL ()
		l_urlInURL.Complete = a_url
		a_this.i_urlTransformerInXURLTransformer.parseStrict (l_urlInURL) # how about ref?
		"""
		l_urlInURL: com_sun_star_util_URL = com_sun_star_util_URL ()
		l_urlInURL.Complete = a_url
		l_urlInURL.Main = a_url
		l_regularExpressionPattern: Pattern = re.compile ("(.*:)(.*)")
		l_regularExpressionMatch: Optional [Match] = l_regularExpressionPattern.match (l_urlInURL.Complete, 0)
		if l_regularExpressionMatch is not None:
			l_urlInURL.Protocol = l_regularExpressionMatch.groups () [0]
			l_urlInURL.User = ""
			l_urlInURL.Password = ""
			l_urlInURL.Server = ""
			l_urlInURL.Port = 0
			l_urlInURL.Path = l_regularExpressionMatch.groups () [1]
			l_urlInURL.Name = ""
			l_urlInURL.Arguments = ""
			l_urlInURL.Mark = ""
		return l_urlInURL

