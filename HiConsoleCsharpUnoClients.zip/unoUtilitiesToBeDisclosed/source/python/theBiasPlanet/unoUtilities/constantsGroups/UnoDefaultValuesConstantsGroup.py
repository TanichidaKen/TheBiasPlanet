
class UnoDefaultValuesConstantsGroup:
	c_customDefaultStyleName: str = "CustomDefault"
	c_initiallyOfferedUnoObjectName: str = "theBiasPlanet.UnoObjectsContext"

