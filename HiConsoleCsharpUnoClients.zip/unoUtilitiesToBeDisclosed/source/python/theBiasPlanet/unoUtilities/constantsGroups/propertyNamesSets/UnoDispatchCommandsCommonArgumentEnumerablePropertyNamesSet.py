from theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup import BaseEnumerableConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.UnoPropertyNamesSet import UnoPropertyNamesSet

class UnoDispatchCommandsCommonArgumentEnumerablePropertyNamesSet (BaseEnumerableConstantsGroup [str], UnoPropertyNamesSet):
	c_synchronousMode_Boolean: str = "SynchronMode"
	c_instance: "UnoDispatchCommandsCommonArgumentEnumerablePropertyNamesSet"
	
	def __init__ (a_this: "UnoDispatchCommandsCommonArgumentEnumerablePropertyNamesSet") -> None:
		BaseEnumerableConstantsGroup.__init__ (a_this, str)

UnoDispatchCommandsCommonArgumentEnumerablePropertyNamesSet.c_instance = UnoDispatchCommandsCommonArgumentEnumerablePropertyNamesSet ()

