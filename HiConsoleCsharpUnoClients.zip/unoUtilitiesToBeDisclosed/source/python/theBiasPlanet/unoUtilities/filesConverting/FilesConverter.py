from typing import cast
from typing import List
from typing import Optional
from com.sun.star.beans import PropertyValue
from com.sun.star.beans import XPropertySet
from com.sun.star.container import XIndexAccess
from com.sun.star.container import XNamed
from com.sun.star.frame import XStorable2
from com.sun.star.frame import XSynchronousDispatch
from com.sun.star.lang import XComponent
from com.sun.star.sheet import XSpreadsheetDocument
from com.sun.star.sheet import XSpreadsheets2
from com.sun.star.util import URL as com_sun_star_util_URL
from com.sun.star.util import XCloseable
from uno import Any
from theBiasPlanet.coreUtilities.collectionsHandling.ListsFactory import ListsFactory
from theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup import GeneralConstantsConstantsGroup
from theBiasPlanet.coreUtilities.messaging.Publisher import Publisher
from theBiasPlanet.unoUtilities.connectionsHandling.UnoObjectsContext import UnoObjectsContext
from theBiasPlanet.unoUtilities.constantsGroups.UnoFileStoringFilterNamesConstantsGroup import UnoFileStoringFilterNamesConstantsGroup 
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.UnoDocumentOpeningEnumerablePropertyNamesSet import UnoDocumentOpeningEnumerablePropertyNamesSet
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.UnoDocumentStoringEnumerablePropertyNamesSet import UnoDocumentStoringEnumerablePropertyNamesSet
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.UnoSpreadSheetPropertyNamesSet import UnoSpreadSheetPropertyNamesSet
from theBiasPlanet.unoUtilities.documentsHandling.UnoDocumentTailor import UnoDocumentTailor
from theBiasPlanet.unoUtilities.propertiesHandling.UnoPropertiesHandler import UnoPropertiesHandler

class FilesConverter:
	c_csvFormatStringFormat: str = "{0:d},{1:d},{2:d},1,,0,{3:s},false,{4:s},{5:s},false" # the CSV items delimiter character code (can be specified like 'Character.codePointAt ("\t", 0)'), the CSV text items quotation character code (can be specified like 'Character.codePointAt ("\"", 0)'), the encoding code (76 -> UTF-8, 65535 -> UCS-2, 65534 -> UCS-4, 11 -> US-ASCII, 69 -> EUC_JP, 64 -> SHIFT_JIS), whether all the text items are quoted, whether the contents are exported as shown, whether the formula themselves are exported
	
	def __init__ (a_this: "FilesConverter", a_remoteUnoObjectsContext: UnoObjectsContext) -> None:
		a_this.i_remoteUnoObjectsContext: UnoObjectsContext
		a_this.i_fileOpeningUnoDispatcherInXSynchronousDispatch: XSynchronousDispatch
		
		a_this.i_remoteUnoObjectsContext = a_remoteUnoObjectsContext
		a_this.i_fileOpeningUnoDispatcherInXSynchronousDispatch = a_this.i_remoteUnoObjectsContext.getFileOpeningUnoDispatcherInXSynchronousDispatch ()
	
	def convertFile (a_this: "FilesConverter", a_convertedFileUrl: str, a_convertedFilePassword: Optional [str], a_targetFileUrl: str, a_documentStoringProperties: Optional [List [PropertyValue]], a_unoDocumentTailor: "Optional [UnoDocumentTailor]") -> bool:
		l_convertedFileUrlInURL: com_sun_star_util_URL = a_this.i_remoteUnoObjectsContext.createUrlInURL (a_convertedFileUrl)
		l_unoDocumentOpeningProperties: Optional [List [PropertyValue]] = UnoPropertiesHandler.buildProperties (UnoDocumentOpeningEnumerablePropertyNamesSet.c_instance.getValues (), ListsFactory.createList (object, True, True, True, True, a_convertedFilePassword if not (a_convertedFilePassword is None) else ""))
		l_convertedUnoDocumentInXComponent: XComponent = cast (XComponent, a_this.i_fileOpeningUnoDispatcherInXSynchronousDispatch.dispatchWithReturnValue (l_convertedFileUrlInURL, l_unoDocumentOpeningProperties))
		l_hasSucceeded: bool = False
		if not (l_convertedUnoDocumentInXComponent is None):
			try:
				if not (a_unoDocumentTailor is None):
					a_unoDocumentTailor.tailor (l_convertedUnoDocumentInXComponent)
				l_convertedUnoDocumentInXStorable2: XStorable2 = cast (XStorable2, l_convertedUnoDocumentInXComponent)
				l_convertedUnoDocumentInXStorable2.storeToURL (a_targetFileUrl, a_documentStoringProperties)
				l_hasSucceeded = True
			except (Exception) as l_exception:
				raise l_exception
			l_convertedUnoDocumentInXCloseable: XCloseable = cast (XCloseable, l_convertedUnoDocumentInXComponent)
			l_convertedUnoDocumentInXCloseable.close (False)
		else:
			None
		return l_hasSucceeded
	
	@staticmethod
	def createCsvFileStoringProperties (a_itemsDelimiterCharacterCode: int, a_textItemQuotationCharacterCode: int, a_charactersEncodingCode: int, a_whetherAllTextItemsAreQuoted: bool, a_whetherContentsAreExportedAsShown: bool, a_whetherFormulaThemselvesAreExported: bool) -> Optional [List [PropertyValue]]:
		l_documentStoringPropertyNames: List [str] = ListsFactory.createList (
			str,
			UnoDocumentStoringEnumerablePropertyNamesSet.c_filterName_string,
			UnoDocumentStoringEnumerablePropertyNamesSet.c_filterData_string,
			UnoDocumentStoringEnumerablePropertyNamesSet.c_overwrites_boolen
		)
		l_documentStoringPropertyValues: List [object] = ListsFactory.createList (
			object,
			UnoFileStoringFilterNamesConstantsGroup.c_csvFileFilterName,
			FilesConverter.c_csvFormatStringFormat.format (a_itemsDelimiterCharacterCode, a_textItemQuotationCharacterCode, a_charactersEncodingCode, str (a_whetherAllTextItemsAreQuoted).lower (), str (a_whetherContentsAreExportedAsShown).lower (), str (a_whetherFormulaThemselvesAreExported).lower ()),
			True
		)
		return UnoPropertiesHandler.buildProperties (l_documentStoringPropertyNames, l_documentStoringPropertyValues)
	
	# a_targetFileNamingRule: 0 -> augmented by the sheet index, 1 -> augmented by the sheet name
	def convertSpreadSheetsDocumentFileToCsvFiles (a_this: "FilesConverter", a_convertedFileUrl: str, a_convertedFilePassword: Optional [str], a_targetFileUrlBase: str, a_documentStoringProperties: Optional [List [PropertyValue]], a_unoDocumentTailor: "Optional [UnoDocumentTailor]", a_targetFileNamingRule: int, a_whetherWritesHiddenSheets: bool) -> bool:
		l_convertedFileUrlInURL: com_sun_star_util_URL = a_this.i_remoteUnoObjectsContext.createUrlInURL (a_convertedFileUrl)
		l_unoDocumentOpeningProperties: Optional [List [PropertyValue]] = UnoPropertiesHandler.buildProperties (UnoDocumentOpeningEnumerablePropertyNamesSet.c_instance.getValues (), ListsFactory.createList (object, True, True, True, True, a_convertedFilePassword if not (a_convertedFilePassword is None) else ""))
		l_convertedUnoDocumentInXComponent: XComponent = cast (XComponent, a_this.i_fileOpeningUnoDispatcherInXSynchronousDispatch.dispatchWithReturnValue (l_convertedFileUrlInURL, l_unoDocumentOpeningProperties))
		l_hasSucceeded: bool = False
		if not (l_convertedUnoDocumentInXComponent is None):
			try:
				if not (a_unoDocumentTailor is None):
					a_unoDocumentTailor.tailor (l_convertedUnoDocumentInXComponent)
				l_spreadSheetsDocumentInXSpreadsheetDocument: XSpreadsheetDocument = cast (XSpreadsheetDocument, l_convertedUnoDocumentInXComponent)
				if l_spreadSheetsDocumentInXSpreadsheetDocument is None:
					Publisher.logErrorInformation ("The document is not any spread sheet.")
					return False
				else:
					l_convertedUnoDocumentInXStorable2: XStorable2 = cast (XStorable2, l_convertedUnoDocumentInXComponent)
					l_spreadSheetsInXSpreadsheets2: XSpreadsheets2 = cast (XSpreadsheets2, l_spreadSheetsDocumentInXSpreadsheetDocument.getSheets ())
					l_spreadSheetsInXIndexAccess: XIndexAccess = cast (XIndexAccess, l_spreadSheetsInXSpreadsheets2)
					l_numberOfSheets: int = l_spreadSheetsInXIndexAccess.getCount ()
					l_spreadSheetInXNamed: XNamed = None
					l_spreadSheetInXPropertySet: XPropertySet = None
					l_targetFileNameAugmentation: Optional [str] = None
					l_lastPeriodPositionInTargetFileUrlBase: int = GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger
					try:
						l_lastPeriodPositionInTargetFileUrlBase = a_targetFileUrlBase.rindex (".")
					except (Exception) as l_exception:
						None
					l_augmentedTargetFileUrl: Optional [str] = None
					l_whetherSheetIsVisible: bool = False
					l_sheetIndex: int
					for l_sheetIndex in range (GeneralConstantsConstantsGroup.c_iterationStartingNumber, l_numberOfSheets, 1):
						l_spreadSheetInXNamed = cast (XNamed, cast (Any, l_spreadSheetsInXIndexAccess.getByIndex (l_sheetIndex)))
						if a_whetherWritesHiddenSheets:
							None
						else:
							l_spreadSheetInXPropertySet = cast (XPropertySet, l_spreadSheetInXNamed)
							l_whetherSheetIsVisible = l_spreadSheetInXPropertySet.getPropertyValue (UnoSpreadSheetPropertyNamesSet.c_whetherIsVisible_boolean) 
							if not l_whetherSheetIsVisible:
								continue
						if a_targetFileNamingRule == 0:
							l_targetFileNameAugmentation = "{0:d}".format (l_sheetIndex)
						else:
							l_targetFileNameAugmentation = l_spreadSheetInXNamed.getName ()
						if l_lastPeriodPositionInTargetFileUrlBase >= GeneralConstantsConstantsGroup.c_iterationStartingNumber:
							l_augmentedTargetFileUrl = "{0:s}_{1:s}{2:s}".format (a_targetFileUrlBase [GeneralConstantsConstantsGroup.c_iterationStartingNumber: l_lastPeriodPositionInTargetFileUrlBase], l_targetFileNameAugmentation, a_targetFileUrlBase [l_lastPeriodPositionInTargetFileUrlBase:])
						else:
							l_augmentedTargetFileUrl = "{0:s}_{1:s}".format (a_targetFileUrlBase, l_targetFileNameAugmentation)
						if l_sheetIndex != GeneralConstantsConstantsGroup.c_iterationStartingNumber:
							l_spreadSheetsInXSpreadsheets2.moveByName (l_spreadSheetInXNamed.getName (), GeneralConstantsConstantsGroup.c_iterationStartingNumber)
						l_convertedUnoDocumentInXStorable2.storeToURL (l_augmentedTargetFileUrl, a_documentStoringProperties)
					l_hasSucceeded = True
			except (Exception) as l_exception:
				raise l_exception
			l_convertedUnoDocumentInXCloseable: XCloseable = cast (XCloseable, l_convertedUnoDocumentInXComponent)
			l_convertedUnoDocumentInXCloseable.close (False)
		else:
			None
		return l_hasSucceeded

