#include "theBiasPlanet/unoUtilities/documentsHandling/UnoDocument.hpp"
#include <optional>
#include <com/sun/star/frame/FrameSearchFlag.hpp>
#include <com/sun/star/frame/XComponentLoader.hpp>
#include <com/sun/star/frame/XDesktop2.hpp>
#include <com/sun/star/util/XCloseable.hpp>
#include "theBiasPlanet/coreUtilities/collectionsHandling/ArraysFactory.hpp"
#include "theBiasPlanet/coreUtilities/collectionsHandling/ListsFactory.hpp"
#include "theBiasPlanet/coreUtilities/constantsGroups/GeneralConstantsConstantsGroup.hpp"
#include "theBiasPlanet/coreUtilities/constantsGroups/RegularExpressionsConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/collectionsHandling/UnoSequenceHandler.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/UnoMessagesConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/UnoServiceNamesConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/UnoSpecialFrameNamesConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/UnoDocumentOpeningEnumerablePropertyNamesSet.hpp"
#include "theBiasPlanet/unoUtilities/propertiesHandling/UnoPropertiesHandler.hpp"
#include "theBiasPlanet/unoUtilities/stringsHandling/UnoExtendedStringHandler.hpp"

using namespace ::com::sun::star::frame;
using namespace ::theBiasPlanet::coreUtilities::collectionsHandling;
using namespace ::theBiasPlanet::unoUtilities::collectionsHandling;
using namespace ::theBiasPlanet::unoUtilities::constantsGroups;
using namespace ::theBiasPlanet::unoUtilities::constantsGroups::propertyNamesSets;
using namespace ::theBiasPlanet::unoUtilities::propertiesHandling;
using namespace ::theBiasPlanet::unoUtilities::stringsHandling;

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace documentsHandling {
			/*
			Reference <XComponent> UnoDocument::createUnoDocumentOrOpenUnoDocumentFile (Reference <UnoObjectsContext> a_objectsContext, string const & a_fileUrl, bool const & a_hiddenly) {
			}
			*/
			
			Reference <XComponent> UnoDocument::getCurrentUnoDocument (Reference <UnoObjectsContext> a_objectsContext) {
				Reference <XDesktop2> l_desktopInXDesktop2 = a_objectsContext->getServiceInstance <XDesktop2> (UnoServiceNamesConstantsGroup::c_com_sun_star_frame_Desktop, nullopt);
				return l_desktopInXDesktop2->getCurrentComponent ();
			}
			/*
			
			Reference <XComponent> UnoDocument::getUnoDocument (Reference <UnoObjectsContext> a_objectsContext, string const & a_fileName) {
			}
			*/
			Reference <XComponent> UnoDocument::createUnoDocumentOrOpenUnoDocumentFile (Reference <UnoObjectsContext> a_objectsContext, string const & a_fileUrl, bool const & a_hiddenly) {
				Reference <XComponentLoader> l_desktopInXComponentLoader = a_objectsContext->getServiceInstance <XComponentLoader> (UnoServiceNamesConstantsGroup::c_com_sun_star_frame_Desktop, nullopt);
				string l_convertedFileUrl (a_fileUrl);
				return l_desktopInXComponentLoader->loadComponentFromURL (UnoExtendedStringHandler::getOustring (StringHandler::replaceAll (&l_convertedFileUrl, RegularExpressionsConstantsGroup::c_windowsDirectoryDelimiterRegularExpression, string (1, GeneralConstantsConstantsGroup::c_linuxDirectoriesDelimiter))), UnoExtendedStringHandler::getOustring (UnoSpecialFrameNamesConstantsGroup::c_new), FrameSearchFlag::CREATE, UnoPropertiesHandler::buildPropertiesArray (UnoDocumentOpeningEnumerablePropertyNamesSet::c_instance.getValues (), ListsFactory::createList <Any, Any, Any, Any> (Any (false), Any (a_hiddenly), Any (false), Any (a_hiddenly))));
			}
			
			UnoDocument::UnoDocument (Reference <UnoObjectsContext> a_objectsContext, Reference <XComponent> a_unoDocumentInXComponent) : WeakComponentImplHelper2 (i_mutex), i_objectsContext (a_objectsContext), i_unoDocumentInXModel (Reference <XModel> (a_unoDocumentInXComponent, UNO_QUERY)), i_unoDocumentInXStorable2 (Reference <XStorable2> (i_unoDocumentInXModel, UNO_QUERY)), i_controllerInXController (Reference <XController> (i_unoDocumentInXModel->getCurrentController (), UNO_QUERY)) {
				if (a_objectsContext.get () == nullptr) {
					throw Exception (UnoExtendedStringHandler::getOustring (UnoMessagesConstantsGroup::c_objectsContextNotSpecified), *this);
				}
				if (a_unoDocumentInXComponent.get () == nullptr) {
					throw Exception (UnoExtendedStringHandler::getOustring (UnoMessagesConstantsGroup::c_unoDocumentNotSpecified), *this);
				}
			}
			
			Reference <UnoObjectsContext> UnoDocument::getObjectsContext () {
				return i_objectsContext;
			}
			
			void UnoDocument::close () {
				Reference <XCloseable> l_unoDocumentInXCloseable = Reference <XCloseable> (i_unoDocumentInXStorable2, UNO_QUERY);
				l_unoDocumentInXCloseable->close (false); 
			}
			
			/*
			Reference <XModel> UnoDocument::getUnoDocumentinXModel () {
			}
			
			Reference <XDispatchProvider> UnoDocument::getFrameInXDispatchProvider () {
			}
			
			void UnoDocument::store () {
			}
			
			void UnoDocument::storeAtUrl (string const & a_fileUrl) {
			}
			
			void UnoDocument::storeAtUrl (string const & a_fileUrl, string const & a_filterName, Any const & a_filterData) {
			}
			
			string UnoDocument::getLocationUrl () {
			}
			
			void UnoDocument::addDocumentEventsListener (Reference <XDocumentEventListener> a_eventListener) {
			}
			
			void UnoDocument::removeDocumentEventsListener (Reference <XDocumentEventListener> a_eventListener) {
			}
			
			void UnoDocument::addEventsListener (Reference <XEventListener> a_eventListener) {
			}
			
			void UnoDocument::removeEventsListener (Reference <XEventListener> a_eventListener) {
			}
			*/
			
			/*
			UnoDispatchResult UnoDocument::dispatch (UnoDispatchSlotsConstantsGroup::BaseDispatchSlot const & a_dispatchSlot, list <Any> a_argumentValues) {
			}
			*/
			
			void UnoDocument::dispatchFinished (DispatchResultEvent const & a_dispatchResultEvent) {
			}
			
			void UnoDocument::statusChanged (FeatureStateEvent const & a_featureStateEvent) {
			}
			
			void UnoDocument::disposing (::com::sun::star::lang::EventObject const & a_source) {
			}
		}
	}
}

