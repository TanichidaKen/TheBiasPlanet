#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/UnoDocumentOpeningEnumerablePropertyNamesSet.hpp"

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			namespace propertyNamesSets {
				string const UnoDocumentOpeningEnumerablePropertyNamesSet::c_readOnly_Boolean = "ReadOnly";
				string const UnoDocumentOpeningEnumerablePropertyNamesSet::c_hidden_Boolean = "Hidden";
				string const UnoDocumentOpeningEnumerablePropertyNamesSet::c_openNewView_Boolean = "OpenNewView";
				string const UnoDocumentOpeningEnumerablePropertyNamesSet::c_silent_Boolean = "Silent";
				UnoDocumentOpeningEnumerablePropertyNamesSet::UnoDocumentOpeningEnumerablePropertyNamesSet () : BaseEnumerableConstantsGroup <string> ({ {"c_readOnly_Boolean", c_readOnly_Boolean}, {"c_hidden_Boolean", c_hidden_Boolean}, {"c_openNewView_Boolean", c_openNewView_Boolean}, {"c_silent_Boolean", c_silent_Boolean}})  {
				}
				
				UnoDocumentOpeningEnumerablePropertyNamesSet const UnoDocumentOpeningEnumerablePropertyNamesSet::c_instance = UnoDocumentOpeningEnumerablePropertyNamesSet ();
			}
		}
	}
}

