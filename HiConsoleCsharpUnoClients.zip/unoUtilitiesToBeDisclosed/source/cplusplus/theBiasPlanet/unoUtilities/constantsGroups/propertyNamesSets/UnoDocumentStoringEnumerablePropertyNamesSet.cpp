#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/UnoDocumentStoringEnumerablePropertyNamesSet.hpp"

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			namespace propertyNamesSets {
				string const UnoDocumentStoringEnumerablePropertyNamesSet::c_filterName_String = "FilterName";
				string const UnoDocumentStoringEnumerablePropertyNamesSet::c_filterData_Object = "FilterData";
				string const UnoDocumentStoringEnumerablePropertyNamesSet::c_authorName_String = "Author";
				string const UnoDocumentStoringEnumerablePropertyNamesSet::c_title_String = "DocumentTitle";
				string const UnoDocumentStoringEnumerablePropertyNamesSet::c_description_String = "Comment";
				string const UnoDocumentStoringEnumerablePropertyNamesSet::c_password_String = "Password";
				UnoDocumentStoringEnumerablePropertyNamesSet::UnoDocumentStoringEnumerablePropertyNamesSet () : BaseEnumerableConstantsGroup <string> ( { {"c_filterName_String", c_filterName_String}, {"c_filterData_Object", c_filterData_Object}, {"c_authorName_String", c_authorName_String}, {"c_title_String", c_title_String}, {"c_description_String", c_description_String}, {"c_password_String", c_password_String}})  {
				}
				
				UnoDocumentStoringEnumerablePropertyNamesSet const UnoDocumentStoringEnumerablePropertyNamesSet::c_instance = UnoDocumentStoringEnumerablePropertyNamesSet ();
			}
		}
	}
}

