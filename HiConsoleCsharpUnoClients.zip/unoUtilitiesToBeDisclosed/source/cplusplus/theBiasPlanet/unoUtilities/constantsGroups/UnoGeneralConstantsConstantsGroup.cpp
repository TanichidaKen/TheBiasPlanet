#include "theBiasPlanet/unoUtilities/constantsGroups/UnoGeneralConstantsConstantsGroup.hpp"
#include "theBiasPlanet/coreUtilities/stringsHandling/StringHandler.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/UnoFileNameSuffixesConstantsGroup.hpp"

using namespace ::theBiasPlanet::coreUtilities::stringsHandling;

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			string const UnoGeneralConstantsConstantsGroup::c_anyUnspecifiedString = "";
			char const UnoGeneralConstantsConstantsGroup::c_digitPlaceCharacter = '0';
			double const UnoGeneralConstantsConstantsGroup::c_numberExpressionModelNumber = 0.0;
			string const UnoGeneralConstantsConstantsGroup::c_cellPositionExpressionFormat = "$%s$%s";
			int const UnoGeneralConstantsConstantsGroup::c_rowIndexToRowPositionExpressionDifference = -1;
			string const UnoGeneralConstantsConstantsGroup::c_connectionUrlDelimiter = ";";
			string const UnoGeneralConstantsConstantsGroup::c_moduleDlimiter = "::";
			string const UnoGeneralConstantsConstantsGroup::c_unoServiceNameFormat = "%s.%s";
			string const UnoGeneralConstantsConstantsGroup::c_unoIdlFileNameFormat = StringHandler::format ("%%s.%s", UnoFileNameSuffixesConstantsGroup::c_unoIdlFileNameSuffix);
			string const UnoGeneralConstantsConstantsGroup::c_unoModuleBeginningRelativeExpressionFormat = "module %s {";
			string const UnoGeneralConstantsConstantsGroup::c_unoModuleEndRelativeExpressionFormat = "};";
		}
	}
}

