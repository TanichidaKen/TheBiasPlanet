#include "theBiasPlanet/unoUtilities/constantsGroups/UnoObjectsContextPropertyNamesConstantsGroup.hpp"

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			string const UnoObjectsContextPropertyNamesConstantsGroup::c_identification = "identification";
		}
	}
}

