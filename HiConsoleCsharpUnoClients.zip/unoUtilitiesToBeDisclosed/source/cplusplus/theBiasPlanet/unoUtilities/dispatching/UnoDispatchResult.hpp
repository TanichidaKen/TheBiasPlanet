#ifndef __theBiasPlanet_unoUtilities_dispatching_UnoDispatchResult_hpp__
	#define __theBiasPlanet_unoUtilities_dispatching_UnoDispatchResult_hpp__
	
	#include <list>
	#include <string>
	#include <com/sun/star/frame/DispatchResultEvent.hpp>
	#include <com/sun/star/frame/FeatureStateEvent.hpp>
	#include <com/sun/star/uno/Any.h>
	#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	using namespace ::com::sun::star::frame;
	using namespace ::com::sun::star::uno;
	
	namespace theBiasPlanet {
		namespace unoUtilities {
			namespace dispatching {
				class __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ UnoDispatchResult {
					private:
						short i_finalStatus;
						Any i_dispatchResult;
						list <Any> i_relatedInformation;
					public:
						UnoDispatchResult ();
						Any getDispatchResult ();
						void setDispatchResult (DispatchResultEvent const & a_dispatchResultEvent);
						list <Any> getRelatedInformation ();
						void addRelatedInformationPiece (FeatureStateEvent const & a_featureStateEvent);
						string toString ();
				};
			}
		}
	}
#endif

