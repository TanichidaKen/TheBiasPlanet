#include "theBiasPlanet/unoUtilities/filesConverting/FileConverter.hpp"
#include <com/sun/star/frame/XStorable2.hpp>
#include <com/sun/star/frame/XSynchronousDispatch.hpp>
#include <com/sun/star/util/XCloseable.hpp>
#include "theBiasPlanet/coreUtilities/collectionsHandling/ListsFactory.hpp"
#include "theBiasPlanet/unoUtilities/collectionsHandling/UnoSequenceHandler.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/UnoDocumentOpeningEnumerablePropertyNamesSet.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/UnoDocumentStoringEnumerablePropertyNamesSet.hpp"
#include "theBiasPlanet/unoUtilities/propertiesHandling/UnoPropertiesHandler.hpp"
#include "theBiasPlanet/unoUtilities/stringsHandling/UnoExtendedStringHandler.hpp"
#include "theBiasPlanet/unoUtilities/unoDataHandling/UnoDatumConverter.hpp"

using namespace ::theBiasPlanet::coreUtilities::collectionsHandling;
using namespace ::theBiasPlanet::unoUtilities::collectionsHandling;
using namespace ::theBiasPlanet::unoUtilities::constantsGroups;
using namespace ::theBiasPlanet::unoUtilities::constantsGroups::propertyNamesSets;
using namespace ::theBiasPlanet::unoUtilities::propertiesHandling;
using namespace ::theBiasPlanet::unoUtilities::stringsHandling;
using namespace ::theBiasPlanet::unoUtilities::unoDataHandling;

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace filesConverting {
			FileConverter::FileConverter (Reference <UnoObjectsContext> a_remoteUnoObjectsContext) : i_remoteUnoObjectsContext (a_remoteUnoObjectsContext), i_unoDocumentOpeningPropertiesSequence (UnoPropertiesHandler::buildPropertiesArray (UnoDocumentOpeningEnumerablePropertyNamesSet::c_instance.getValues (), ListsFactory::createList <Any, Any, Any, Any> (Any (true), Any (true), Any (true), Any (true)))), i_fileOpeningUnoDispatcherInXSynchronousDispatch (i_remoteUnoObjectsContext->getFileOpeningUnoDispatcherInXSynchronousDispatch ()) {
				//i_unoDocumentOpeningPropertiesSequence = UnoPropertiesHandler::buildPropertiesArray (UnoDocumentOpeningEnumerablePropertyNamesSet::c_instance.getValues (), ListsFactory::createList <Any, Any, Any, Any> (Any (true), Any (true), Any (true), Any (true)));
			}
			
			FileConverter::~FileConverter () {
			}
			
			bool FileConverter::convertFile (string const & a_convertedFileUrl, string const & a_targetFileUrl, string const & a_filterName, Any const & a_filterData, optional <string> const & a_authorName, optional <string> const & a_title, optional <string> const & a_description, optional <string> const & a_password) {
				::com::sun::star::util::URL l_convertedFileUrlInURL = i_remoteUnoObjectsContext->createUrlInURL (a_convertedFileUrl);
				Any l_convertedUnoDocumentInAny = i_fileOpeningUnoDispatcherInXSynchronousDispatch->dispatchWithReturnValue (l_convertedFileUrlInURL, i_unoDocumentOpeningPropertiesSequence);
				bool l_hasSucceeded = false;
				if (l_convertedUnoDocumentInAny.hasValue ()) {
					Reference <XComponent> l_convertedUnoDocumentInXComponent = * ((Reference <XComponent> *) (l_convertedUnoDocumentInAny.getValue ()));
					Sequence <PropertyValue> l_unoDocumentStoringPropertiesSequence = UnoPropertiesHandler::buildPropertiesArray (UnoDocumentStoringEnumerablePropertyNamesSet::c_instance.getValues (), ListsFactory::createList <Any, Any, Any, Any, Any, Any> (UnoDatumConverter::convertToUnoAnyDatum <string> (a_filterName), a_filterData, UnoDatumConverter::convertToUnoAnyDatum <string> (a_authorName), UnoDatumConverter::convertToUnoAnyDatum <string> (a_title), UnoDatumConverter::convertToUnoAnyDatum <string> (a_description), UnoDatumConverter::convertToUnoAnyDatum <string> (a_password)));
					Reference <XStorable2> l_convertedUnoDocumentInXStorable2 = Reference <XStorable2> (l_convertedUnoDocumentInXComponent, UNO_QUERY);
					try {
						l_convertedUnoDocumentInXStorable2->storeToURL (UnoExtendedStringHandler::getOustring (a_targetFileUrl), l_unoDocumentStoringPropertiesSequence);
						l_hasSucceeded = true;
					}
					catch (...) {
					}
					Reference <XCloseable> l_convertedUnoDocumentInXCloseable = Reference <XCloseable> (l_convertedUnoDocumentInXComponent, UNO_QUERY);
					l_convertedUnoDocumentInXCloseable->close (false); 
				}
				else {
				}
				return l_hasSucceeded;
			}
		}
	}
}

