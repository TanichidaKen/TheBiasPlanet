#include "theBiasPlanet/unoUtilities/stringsHandling/UnoExtendedStringHandler.hpp"

using namespace ::rtl;
using namespace ::std;

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace stringsHandling {
			OUString UnoExtendedStringHandler::getOustring (string const & a_utf8String) {
				return OUString ( (sal_Unicode *) (getUtf16String (a_utf8String).c_str ()));
			}
			
			string UnoExtendedStringHandler::getString (OUString const & a_oustring) {
				u16string l_utf16String = u16string ( (char16_t *) a_oustring.getStr ());
				return getUtf8String (l_utf16String );
			}
		}
	}
}

