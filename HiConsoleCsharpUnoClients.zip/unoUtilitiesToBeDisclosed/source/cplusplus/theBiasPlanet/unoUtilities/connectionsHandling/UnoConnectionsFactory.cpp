#include "theBiasPlanet/unoUtilities/connectionsHandling/UnoConnectionsFactory.hpp"
#include <optional>
#include <map>
#include <com/sun/star/bridge/BridgeExistsException.hpp>
#include <com/sun/star/bridge/XBridge.hpp>
#include <com/sun/star/bridge/XInstanceProvider.hpp>
#include <com/sun/star/uno/XComponentContext.hpp>
#include <osl/mutex.hxx>
#include "theBiasPlanet/unoUtilities/constantsGroups/UnoDefaultValuesConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/UnoMessagesConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/UnoServiceNamesConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/UnoObjectsContextPropertyNamesConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/stringsHandling/UnoExtendedStringHandler.hpp"

using namespace ::osl;
using namespace ::theBiasPlanet::unoUtilities::constantsGroups;
using namespace ::theBiasPlanet::unoUtilities::constantsGroups::propertyNamesSets;
using namespace ::theBiasPlanet::unoUtilities::stringsHandling;

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace connectionsHandling {
			UnoConnectionsFactory::UnoConnectionsFactory (Reference <UnoObjectsContext> a_localObjectsContext) : i_localObjectsContext (a_localObjectsContext) {
			}
			
			void UnoConnectionsFactory::initialize () {
				i_bridgesFactoryInXBridgeFactory = i_localObjectsContext->getServiceInstance <XBridgeFactory> (UnoServiceNamesConstantsGroup::c_com_sun_star_bridge_BridgeFactory, nullopt);
			}
			
			Reference <UnoConnection> UnoConnectionsFactory::setupConnection (Reference <XConnection> a_connectionInXConnection, StringTokenizer * a_urlTokenizer, string const & a_connectionIdentification, optional <list <UnoConnectionEventsListener *> const> const a_eventListeners) {
				class InitialUnoObjectsProvider : public WeakComponentImplHelper1 <XInstanceProvider> {
					private:
						Mutex i_mutex;
						Reference <UnoObjectsContext> i_localObjectsContext;
					public:
						InitialUnoObjectsProvider (Reference <UnoObjectsContext> a_localObjectsContext) : WeakComponentImplHelper1 (i_mutex), i_localObjectsContext (a_localObjectsContext) {
						}
						
						virtual Reference <XInterface> SAL_CALL getInstance (OUString const & a_initialUnoObjectName) override {
							if (UnoDefaultValuesConstantsGroup::c_initiallyOfferedUnoObjectName == UnoExtendedStringHandler::getString (a_initialUnoObjectName)) {
								return i_localObjectsContext;
							}
							else {
								return Reference <XInterface> ();
							}
						}
				};
			   	Reference <InitialUnoObjectsProvider> l_initialUnoObjectsProvider (new InitialUnoObjectsProvider (i_localObjectsContext));
				Reference <XBridge> l_bridgeInXBridge;
				try {
					OUString l_bridgeName;
					string l_protocolName = a_urlTokenizer->nextToken ().value ();
					l_bridgeInXBridge = i_bridgesFactoryInXBridgeFactory->createBridge (l_bridgeName, UnoExtendedStringHandler::getOustring (l_protocolName), a_connectionInXConnection, l_initialUnoObjectsProvider);
				}
				catch (BridgeExistsException l_exception) {
					// This can't happen
				}
				string l_remoteInitialUnoObjectName = a_urlTokenizer->nextToken ().value ();
				Reference <XInterface> l_remoteObjectsContextInXInterface = l_bridgeInXBridge->getInstance (UnoExtendedStringHandler::getOustring (l_remoteInitialUnoObjectName));
				if (l_remoteObjectsContextInXInterface.get () == nullptr) {
					throw ::com::sun::star::uno::Exception (UnoExtendedStringHandler::getOustring (UnoMessagesConstantsGroup::c_remoteInstanceNotProvided), 0);
				}
				map <string, Any> l_unoObjectsContextExtraNameToValueMap;
				ostringstream l_connectionIdentificationStream;
				OUString l_connectionDescription = a_connectionInXConnection->getDescription ();
				l_connectionIdentificationStream << UnoExtendedStringHandler::getString (l_connectionDescription) << ": " << a_connectionIdentification;
				string l_connectionIdentification = l_connectionIdentificationStream.str ();
				l_unoObjectsContextExtraNameToValueMap [UnoObjectsContextPropertyNamesConstantsGroup::c_identification] = Any (UnoExtendedStringHandler::getOustring (l_connectionIdentification));
				Reference <UnoConnection> l_unoConnection (new UnoConnection (Reference <XComponentContext> (l_remoteObjectsContextInXInterface, UNO_QUERY), l_unoObjectsContextExtraNameToValueMap, l_bridgeInXBridge, a_eventListeners));
				return l_unoConnection;
			}
		}
	}
}

