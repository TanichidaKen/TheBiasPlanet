#include "theBiasPlanet/unoUtilities/connectionsHandling/UnoObjectsContext.hpp"
#include <rtl/ustrbuf.hxx>
#include <com/sun/star/uno/Exception.hpp>
#include "theBiasPlanet/coreUtilities/constantsGroups/GeneralConstantsConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/UnoMessagesConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/UnoServiceNamesConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/UnoSpecialFrameNamesConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/UnoObjectsContextPropertyNamesSet.hpp"
#include "theBiasPlanet/unoUtilities/stringsHandling/UnoExtendedStringHandler.hpp"

using namespace ::theBiasPlanet::coreUtilities::constantsGroups;
using namespace ::theBiasPlanet::unoUtilities::constantsGroups;
using namespace ::theBiasPlanet::unoUtilities::constantsGroups::propertyNamesSets;
using namespace ::theBiasPlanet::unoUtilities::stringsHandling;

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace connectionsHandling {
			UnoObjectsContext::UnoObjectsContext (Reference <XComponentContext> a_originalObjectsContextInXComponentContext, optional <map <string, Any>> a_extraNameToValueMap) : WeakComponentImplHelper1 (i_mutex), i_originalObjectsContextInXComponentContext (a_originalObjectsContextInXComponentContext), i_extraNameToValueMap (a_extraNameToValueMap) {
			}
			
			UnoObjectsContext::~UnoObjectsContext () {
			}
			
			Any UnoObjectsContext::getValueByName (OUString const & a_name) {
				if (i_extraNameToValueMap.has_value ()) {
					map <string, Any>::iterator l_extraNameToValueMapIterator = i_extraNameToValueMap->find (UnoExtendedStringHandler::getString (a_name));
					if (l_extraNameToValueMapIterator != i_extraNameToValueMap->end ()) {
						return l_extraNameToValueMapIterator->second;
					}
					else {
						return i_originalObjectsContextInXComponentContext->getValueByName (a_name);
					}
				}
				else {
					return i_originalObjectsContextInXComponentContext->getValueByName (a_name);
				}
			}
			
			Reference <XMultiComponentFactory> UnoObjectsContext::getServiceManager () {
				return i_originalObjectsContextInXComponentContext->getServiceManager ();
			}
			
			bool UnoObjectsContext::isFromSameOrigin (Reference <UnoObjectsContext> a_unoObjectsContext) {
				if (i_extraNameToValueMap.has_value ()) {
					map <string, Any>::iterator l_extraNameToValueMapIterator = i_extraNameToValueMap->find (UnoObjectsContextPropertyNamesSet::c_identification_string);
					if (l_extraNameToValueMapIterator == i_extraNameToValueMap->end ()) {
						return false;
					}
					if (l_extraNameToValueMapIterator->second == a_unoObjectsContext->getValueByName (UnoExtendedStringHandler::getOustring (UnoObjectsContextPropertyNamesSet::c_identification_string))) {
						return true;
					}
					else {
						return false;
					}
				}
				else {
					return false;
				}
			}
			
			Reference <XDesktop2> UnoObjectsContext::getUnoDesktopInXDesktop2 () {
				if (!(i_unoDesktopInXDesktop2.is ())) {
					i_unoDesktopInXDesktop2 = getServiceInstance <XDesktop2> (UnoServiceNamesConstantsGroup::c_com_sun_star_frame_Desktop, nullopt);
				}
				else {
				}
				return i_unoDesktopInXDesktop2;
			}
			
			Reference <XDispatchProvider> UnoObjectsContext::getUnoDesktopInXDispatchProvider () {
				if (!(i_unoDesktopInXDispatchProvider.is ())) {
					if (!(i_unoDesktopInXDesktop2.is ())) {
						getUnoDesktopInXDesktop2 ();
					}
					else {
					}
					i_unoDesktopInXDispatchProvider = Reference <XDispatchProvider> (i_unoDesktopInXDesktop2, UNO_QUERY);
				}
				else {
				}
				return i_unoDesktopInXDispatchProvider;
			}
			
			Reference <XSynchronousDispatch> UnoObjectsContext::getFileOpeningUnoDispatcherInXSynchronousDispatch () {
				if (!(i_fileOpeningUnoDispatcherInXSynchronousDispatch.is ())) {
					i_fileOpeningUnoDispatcherInXSynchronousDispatch = Reference <XSynchronousDispatch> (getUnoDesktopInXDispatchProvider ()->queryDispatch (createUrlInURL ("file:///"), UnoExtendedStringHandler::getOustring (UnoSpecialFrameNamesConstantsGroup::c_new), GeneralConstantsConstantsGroup::c_anyUnspecifiedInteger), UNO_QUERY);
				}
				return i_fileOpeningUnoDispatcherInXSynchronousDispatch;
			}
			
			::com::sun::star::util::URL UnoObjectsContext::createUrlInURL (string a_url) {
				if (!(i_urlTransformerInXURLTransformer.is ())) {
					i_urlTransformerInXURLTransformer = getServiceInstance <XURLTransformer> (UnoServiceNamesConstantsGroup::c_com_sun_star_util_URLTransformer, nullopt);
				}
				::com::sun::star::util::URL l_urlInURL;
				l_urlInURL.Complete = UnoExtendedStringHandler::getOustring (a_url);
				i_urlTransformerInXURLTransformer->parseStrict (l_urlInURL);
				return l_urlInURL;
			}
		}
	}
}

