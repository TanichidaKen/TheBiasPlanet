namespace theBiasPlanet {
	namespace hiConsoleCsharpUnoClients {
		namespace programs {
			using System;
			using theBiasPlanet.coreUtilities.messaging;
			using theBiasPlanet.coreUtilities.programsHandling;
			using theBiasPlanet.unoUtilities.connectionsHandling;
			using theBiasPlanet.unoUtilities.documentsHandling.textDocumentsHandling;
			using theBiasPlanet.unoUtilities.programsHandling;
			
			public class HiConsoleCSharpUnoClients {
				static void Main (String [] a_argumentsArray) {
					try {
						if (a_argumentsArray.Length != 2) {
							throw new Exception ("The arguments have to be these.\nThe argument 1: the server url like 'socket,host=localhost,port=2002,tcpNoDelay=1;urp;StarOffice.ComponentContext'\nThe argument 2: the url of the file to be opened like ('file://!HOME!/myData/development/hiConsoleCsharpUnoClients/execution/HiConsoleCsharpUnoClientsTests.odt')");
						}
						String l_serverUrl = a_argumentsArray [0];
						String l_openedFileUrl = a_argumentsArray [1];
						UnoProcessEnvironment l_localUnoProcessEnvironment = new UnoProcessEnvironment (DateTime.Now.ToString (), null);
						ProcessEnvironment.windowsSocketStartup ();
						UnoConnectionConnector l_unoConnectionConnector = new UnoConnectionConnector (l_localUnoProcessEnvironment.getLocalObjectsContext ());
						UnoConnection l_unoConnection = l_unoConnectionConnector.connect (l_serverUrl, null);
						UnoTextDocument l_unoTextDocument = UnoTextDocument.openTextDocumentFile (l_unoConnection.getRemoteObjectsContext (), l_openedFileUrl, false);
						l_unoTextDocument.close ();
						l_unoConnection.disconnect ();
						ProcessEnvironment.windowsSocketCleanup ();
					}
					catch (Exception l_exception) {
						Publisher.logErrorInformation (l_exception);
						Environment.Exit (1);
					}
				}
			}
		}
	}
}

