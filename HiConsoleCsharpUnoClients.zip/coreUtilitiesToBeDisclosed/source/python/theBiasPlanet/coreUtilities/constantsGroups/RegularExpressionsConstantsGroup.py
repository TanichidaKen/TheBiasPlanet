
class RegularExpressionsConstantsGroup:
	c_numbersRegularExpression: str = "^(\\d*|\\d{1,3}(,\\d{3})*)(\\.\\d+)?([eE][-+]?\\d+)?$"
	c_csharpPackageDelimiterRegularExpression: str = "\\."
	c_windowsDirectoryDelimiterRegularExpression: str = "\\\\"
	c_wordRegularExpression: str = "(\\w+)"
	c_termRegularExpression: str = "(\\S+)"
	c_doubleQuotedTermRegularExpression: str = "\"(\\S+)\""

