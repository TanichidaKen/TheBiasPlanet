namespace theBiasPlanet {
	namespace coreUtilities {
		namespace reflectionHandling {
			using System;
			using System.Collections.Generic;
			using System.Reflection;
			using theBiasPlanet.coreUtilities.collections;
			
			public class ReflectionHandler {
				// Fields are stored in the order of from the super class to the sub class and from the implemented interfaces to the implementing class.
				// Duplicate named fields are replaced by the sub class's.
				// If all the gotten fields are static, set a_instance to be null.
				public static NavigableLinkedHashMap <String, Object> getFieldNamesAndValues (Type a_class, Object a_instance, bool a_publicOnly, bool a_setAccessible, List <Type> a_assignableClassesOfFields, List <Type> a_notAssignableClassesOfFields, bool a_recursive) {
					NavigableLinkedHashMap <String, Object> l_fieldNameToValueMap = new NavigableLinkedHashMap <String, Object> ();
					if (a_recursive) {
						NavigableLinkedHashMap <String, Object> l_superClassOrImplementedInterfaceFieldNameToValueMap = null;
						Type l_superClass = a_class.BaseType;
						if (l_superClass != null) {
							l_superClassOrImplementedInterfaceFieldNameToValueMap = getFieldNamesAndValues (l_superClass, a_instance, a_publicOnly, a_setAccessible, a_assignableClassesOfFields, a_notAssignableClassesOfFields, true);
							l_fieldNameToValueMap.putAll (l_superClassOrImplementedInterfaceFieldNameToValueMap);
						}
						Type [] l_implementedInterfaces = null;
						l_implementedInterfaces = a_class.GetInterfaces ();
						foreach (Type l_implementedInterface in l_implementedInterfaces) {
							l_superClassOrImplementedInterfaceFieldNameToValueMap = getFieldNamesAndValues (l_implementedInterface, null, a_publicOnly, a_setAccessible, a_assignableClassesOfFields, a_notAssignableClassesOfFields, true);
							l_fieldNameToValueMap.putAll (l_superClassOrImplementedInterfaceFieldNameToValueMap);
						}
					}
					FieldInfo [] l_fields = a_class.GetFields (BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static);
					foreach (FieldInfo l_field in l_fields) {
						if (a_publicOnly && !l_field.IsPublic) {
							continue;
						}
						if (a_instance == null && !l_field.IsStatic) {
							continue;
						}
						if (a_assignableClassesOfFields != null) {
							bool l_assignable = false;
							foreach (Type l_assignableClassOfFields in a_assignableClassesOfFields) {
								if (!l_assignableClassOfFields.IsAssignableFrom (l_field.FieldType)) {
									l_assignable = true;
									break;
								}
							}
							if (!l_assignable) {
								continue;
							}
						}
						if (a_notAssignableClassesOfFields != null) {
							bool l_assignable = false;
							foreach (Type l_notAssignableClassOfFields in a_notAssignableClassesOfFields) {
								if (l_notAssignableClassOfFields.IsAssignableFrom (l_field.FieldType)) {
									l_assignable = true;
									break;
								}
							}
							if (l_assignable) {
								continue;
							}
						}
						l_fieldNameToValueMap.put (l_field.Name, l_field.GetValue (a_instance));
					}
					return l_fieldNameToValueMap;
				}
			}
		}
	}
}

