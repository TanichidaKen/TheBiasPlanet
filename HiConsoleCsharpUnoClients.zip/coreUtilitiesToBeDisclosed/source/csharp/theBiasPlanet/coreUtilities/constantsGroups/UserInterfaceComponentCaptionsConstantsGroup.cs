namespace theBiasPlanet {
	namespace coreUtilities {
		namespace constantsGroups {
			using System;
			
			public static class  UserInterfaceComponentCaptionsConstantsGroup {
				public const String c_generalFullFormat = "%%s%%%ds";
				public const String c_generalAbrreviatedFormat = "%s...";
				public const String c_disconnect = "Disconnect";
				public const String c_connect = "Connect";
				public const String c_accept = "Accept";
				public const String c_suspend = "Suspend";
				public const String c_replace = "Replace";
				public const String c_cancel = "Cancel";
				public const String c_search = "Search";
				public const String c_replaceAndSearch = "Replace and Search";
				public const String c_undo = "Undo";
				public const String c_redo = "Redo";
				public const String c_cut = "Cut";
				public const String c_copy = "Copy";
				public const String c_paste = "Paste";
				public const String c_open = "Open";
				public const String c_chooseFile = "...";
				public const String c_selectAll = "Select All";
				public const String c_cellConnectedFormat = "Row index: %d, Column index: %d";
				public const String c_cellNotConnected = "No Cell Is Connected";
			}
		}
	}
}

