namespace theBiasPlanet {
	namespace coreUtilities {
		namespace constantsGroups {
			using System;
			
			public static class RegularExpressionsConstantsGroup {
				public const String c_numbersRegularExpression = "^(\\d*|\\d{1,3}(,\\d{3})*)(\\.\\d+)?([eE][-+]?\\d+)?$";
				public const String c_csharpPackageDelimiterRegularExpression = "\\.";
				public const String c_windowsDirectoryDelimiterRegularExpression = "\\\\";
				public const String c_wordRegularExpression = "(\\w+)";
				public const String c_termRegularExpression = "(\\S+)";
				public const String c_doubleQuotedTermRegularExpression = "\"(\\S+)\"";
			}
		}
	}
}

