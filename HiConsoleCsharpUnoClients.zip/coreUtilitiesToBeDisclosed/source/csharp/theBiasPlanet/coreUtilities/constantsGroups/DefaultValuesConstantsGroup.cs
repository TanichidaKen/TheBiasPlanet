namespace theBiasPlanet {
	namespace coreUtilities {
		namespace constantsGroups {
			using System;
			
			public static class DefaultValuesConstantsGroup {
					public const int c_smallBufferSize = 1024;
					public const int c_largeBufferSize = 102400;
					public const int c_smallestBufferSize = 1;
			}
		}
	}
}

