namespace theBiasPlanet {
	namespace coreUtilities {
		namespace optionalDatum {
			using System;
			using System.Collections.Generic;
			
			public class OptionalDatum <T> {
				private bool i_hasDatum = false;
				private T i_datum;
				
				public OptionalDatum () {
				}
				
				public OptionalDatum (T a_datum) {
					setDatum (a_datum);
				}
				
				public virtual bool hasDatum () {
					return i_hasDatum;
				}
				
				public virtual T getDatum () {
					return i_datum;
				}
				
				public virtual T setDatum (T a_datum) {
					i_datum = a_datum;
					if (a_datum == null) {
						i_hasDatum = false;
					}
					else {
						i_hasDatum = true;
					}
					return i_datum;
				}
				
				public virtual void removeDatum () {
					i_datum = default (T);
					i_hasDatum = false;
				}
				
				public override bool Equals (Object a_objectToBeCompared) {
					if (!hasDatum ()) {
						if (a_objectToBeCompared == null) {
							return true;
						}
						else {
							if (a_objectToBeCompared is OptionalDatum <T>) {
								OptionalDatum <T> l_optionalDatumToBeCompared = (OptionalDatum <T>) a_objectToBeCompared;
								if (!(l_optionalDatumToBeCompared.hasDatum ())) {
									return true;
								}
								else {
									return false;
								}
							}
							else {
								return false;
							}
						}
					}
					else {
						if (a_objectToBeCompared == null) {
							return false;
						}
						else {
							if (a_objectToBeCompared is OptionalDatum <T>) {
								OptionalDatum <T> l_optionalDatumToBeCompared = (OptionalDatum <T>) a_objectToBeCompared;
								if (!(l_optionalDatumToBeCompared.hasDatum ())) {
									return false;
								}
								else {
									return EqualityComparer <T>.Default.Equals (getDatum (), l_optionalDatumToBeCompared.getDatum ());
								}
							}
							else {
								if (a_objectToBeCompared is T) {
									return EqualityComparer <T>.Default.Equals (getDatum (), (T) a_objectToBeCompared);
								}
								else {
									return false;
								}
							}
						}
					}
				}
				
				public override int GetHashCode () {
					if (i_datum == null) {
						return 0;
					}
					else {
						return i_datum.GetHashCode ();
					}
				}
			}
		}
	}
}

