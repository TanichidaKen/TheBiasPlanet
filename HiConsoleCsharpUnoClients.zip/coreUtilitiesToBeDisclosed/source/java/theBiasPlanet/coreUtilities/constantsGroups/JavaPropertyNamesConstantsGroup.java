package theBiasPlanet.coreUtilities.constantsGroups;

public interface JavaPropertyNamesConstantsGroup {
	String c_userHomeDirectoryPath = "user.home";
	String c_currentDirectoryPath = "user.dir";
	String c_operatingSystemName = "os.name";
}

