package theBiasPlanet.coreUtilities.constantsGroups;

public interface OperatingSystemNamesConstantsGroup {
	String c_linux = "Linux";
	String c_windows = "Windows";
}

