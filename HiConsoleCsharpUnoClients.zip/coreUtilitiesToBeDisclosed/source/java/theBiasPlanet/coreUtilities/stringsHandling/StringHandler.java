package theBiasPlanet.coreUtilities.stringsHandling;

import java.io.Reader;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.InflaterInputStream;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.math.BigDecimal;
import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.coreUtilities.messaging.Publisher;

public class StringHandler {
	static private final int c_unicodePackMaximumChunkLength;
	static private final int c_minimumCaptionLength;
	
	static {
		c_unicodePackMaximumChunkLength = 8192;
		c_minimumCaptionLength = 4;
	}
	
	static public StringBuffer append (StringBuffer a_target, List <String> a_stringsListToAppend, String a_delimiter) {
		boolean [] l_isFirstIteration = {true};
		a_stringsListToAppend.stream ().forEach (a_string -> {
			if (l_isFirstIteration [GeneralConstantsConstantsGroup.c_iterationStartingNumber]) {
				l_isFirstIteration [GeneralConstantsConstantsGroup.c_iterationStartingNumber] = false;
			}
			else {
				a_target.append (a_delimiter);
			}
			a_target.append (a_string);
		});
		return a_target;
	}
	
	static public StringBuffer append (StringBuffer a_target, List <String> a_stringsListToAppend, String a_delimiter, String a_replacement) {
		boolean [] l_isFirstIteration = {true};
		a_stringsListToAppend.stream ().forEach (a_string -> {
			if (l_isFirstIteration [GeneralConstantsConstantsGroup.c_iterationStartingNumber]) {
				l_isFirstIteration [GeneralConstantsConstantsGroup.c_iterationStartingNumber] = false;
			}
			else {
				a_target.append (a_delimiter);
			}
			a_target.append (a_replacement);
		});
		return a_target;
	}
	
	public static Object getObject (String a_string, Class a_objectClass) /*throws UnsupportedOperationException*/ {
		try {
			if (a_objectClass == LocalDate.class) {
				LocalDate l_date = LocalDate.parse (a_string, DateTimeFormatter.ISO_LOCAL_DATE);
				return l_date;
			}
			else if (a_objectClass == LocalTime.class) {
				LocalTime l_time = LocalTime.parse (a_string, DateTimeFormatter.ISO_LOCAL_TIME);
				return l_time;
			}
			else if (a_objectClass == LocalDateTime.class) {
				LocalDateTime l_dateTime = LocalDateTime.parse (a_string, DateTimeFormatter.ISO_LOCAL_DATE_TIME);
				return l_dateTime;
			}
			else if (a_objectClass == Boolean.class) {
				Boolean l_boolean = Boolean.valueOf (a_string);
				return l_boolean;
			}
			else if (a_objectClass == Integer.class) {
				return Integer.valueOf (a_string);
			}
			else if (a_objectClass == BigDecimal.class) {
				return new BigDecimal (a_string);
			}
			else if (a_objectClass == Double.class) {
				return Double.valueOf (a_string);
			}
			else if (a_objectClass == String.class) {
				return a_string;
			}
			else {
				return a_string;
			}
		}
		catch (Exception l_exception) {
			return a_string;
		}
		//throw new UnsupportedOperationException ();
	}
	
	public static String getString (Object a_object) {
		String l_string = null;
		if (a_object == null || a_object instanceof String) {
			l_string = (String) a_object;
		}
		else if (a_object instanceof Integer) {
			l_string = String.format (GeneralConstantsConstantsGroup.c_integerDefaultFormat, a_object);
		}
		else if (a_object instanceof BigDecimal) {
			l_string = ((BigDecimal) a_object).toPlainString ();
		}
		else if (a_object instanceof Double) {
			l_string = String.format (GeneralConstantsConstantsGroup.c_doubleDefaultFormat, a_object);
		}
		else if (a_object instanceof Boolean) {
			l_string = String.format (GeneralConstantsConstantsGroup.c_booleanDefaultFormat, a_object);
		}
		else if (a_object instanceof LocalDate) {
			LocalDate l_date = (LocalDate) a_object;
			l_string = l_date.format (DateTimeFormatter.ISO_LOCAL_DATE);
		}
		else if (a_object instanceof LocalTime) {
			LocalTime l_time = (LocalTime) a_object;
			l_string = l_time.format (DateTimeFormatter.ISO_LOCAL_TIME);
		}
		else if (a_object instanceof LocalDateTime) {
			LocalDateTime l_dateTime = (LocalDateTime) a_object;
			l_string = l_dateTime.format (DateTimeFormatter.ISO_LOCAL_DATE_TIME);
		}
		else {
			l_string = a_object.toString ();
		}
		 return l_string;
	}
	
	//// a_toMakeItLowerCase: 0 -> no, 1 -> yes for the beginning, 2 -> yes for all
	public static String getIdString (String a_originalString, boolean a_isLowerCaseStarting, boolean a_isAllLowerCase) {
		StringTokenizer l_stringTokenizer = new StringTokenizer (a_originalString, " ");
		String l_token;
		int l_tokenIndex = GeneralConstantsConstantsGroup.c_iterationStartingNumber;
		StringBuffer l_targetStringBuffer = new StringBuffer ();
		boolean l_passTheseTokens = false;
		int l_tagSearchMode = GeneralConstantsConstantsGroup.c_iterationStartingNumber; // GeneralConstantsConstantsGroup.c_iterationStartingNumber: search '<', 1: search '>'
		Pattern l_tagStartOrEndRegularExpression = Pattern.compile("(<|>)");
		StringBuffer l_preservedChunk = new StringBuffer ();
		StringBuffer l_disposedChunk = new StringBuffer ();
		while (l_stringTokenizer.hasMoreTokens ()) {
			l_token = l_stringTokenizer.nextToken ();
			l_token = l_token.replaceAll (",|'|\"|\\?|\\.|:|;|/|-", "");
			if (l_token.startsWith ("+")) {
				l_token = String.format ("Plus%s", l_token.substring (1));
			}
			l_token = l_token.replaceAll ("\\+", "plus");
			if (l_token.startsWith ("(")) {
				l_passTheseTokens = true;
			}
			if (!l_passTheseTokens) {
				Matcher l_tagStartOrEndMatcher = l_tagStartOrEndRegularExpression.matcher (l_token);
				while (l_tagStartOrEndMatcher.find ()) {
					if (l_tagSearchMode == GeneralConstantsConstantsGroup.c_iterationStartingNumber) {
						if (l_tagStartOrEndMatcher.group (GeneralConstantsConstantsGroup.c_iterationStartingNumber).equals ("<")) {
							l_tagStartOrEndMatcher.appendReplacement (l_preservedChunk, "");
							l_tagSearchMode = 1;
						}
						else {
							// error
						}
					}
					if (l_tagSearchMode == 1) {
						if (l_tagStartOrEndMatcher.group (GeneralConstantsConstantsGroup.c_iterationStartingNumber).equals (">")) {
							l_tagStartOrEndMatcher.appendReplacement (l_disposedChunk, "");
							l_disposedChunk.delete (GeneralConstantsConstantsGroup.c_iterationStartingNumber, l_disposedChunk.length ());
							l_tagSearchMode = GeneralConstantsConstantsGroup.c_iterationStartingNumber;
						}
						else {
							// error
						}
					}
				}
				if (l_tagSearchMode == GeneralConstantsConstantsGroup.c_iterationStartingNumber) {
					l_tagStartOrEndMatcher.appendTail (l_preservedChunk);
				}
				/*
				if ((a_toMakeItLowerCase == 1 && l_tokenIndex == GeneralConstantsConstantsGroup.c_iterationStartingNumber) || a_toMakeItLowerCase == 2) {
					if (a_toMakeItLowerCase == 1) {
						l_targetStringBuffer.append (l_preservedChunk.substring (GeneralConstantsConstantsGroup.c_iterationStartingNumber, 1).toLowerCase ());
						l_targetStringBuffer.append (l_preservedChunk.substring (1));
					}
					else {
						l_targetStringBuffer.append (l_preservedChunk.toString ().toLowerCase ());
					}
				}
				else {
					l_targetStringBuffer.append (l_preservedChunk);
				}
				*/
				if (l_tokenIndex == GeneralConstantsConstantsGroup.c_iterationStartingNumber && a_isLowerCaseStarting) {
					l_targetStringBuffer.append (l_preservedChunk.toString ().toLowerCase ());
				}
				else {
					if (!a_isAllLowerCase) {
						l_targetStringBuffer.append (l_preservedChunk.substring (GeneralConstantsConstantsGroup.c_iterationStartingNumber, 1).toUpperCase ());
					}
					else {
						l_targetStringBuffer.append (l_preservedChunk.substring (GeneralConstantsConstantsGroup.c_iterationStartingNumber, 1).toLowerCase ());
					}
					l_targetStringBuffer.append (l_preservedChunk.substring (1).toLowerCase ());
				}
				l_preservedChunk.delete (GeneralConstantsConstantsGroup.c_iterationStartingNumber, l_preservedChunk.length ());
				l_tokenIndex ++;
			}
			if (l_token.endsWith (")")) {
				l_passTheseTokens = false;
			}
		}
		return l_targetStringBuffer.toString ();
	}
	
	public static String getUpperCaseBeginnigString (String a_originalString) {
		if (a_originalString != null) {
			return String.format ("%s%s", a_originalString.substring (GeneralConstantsConstantsGroup.c_iterationStartingNumber, 1).toUpperCase (), a_originalString.substring (1));
		}
		else {
			return null;
		}
	}
	
	// a_captionLength has to be larger than or equal to c_minimumCaptionLength
	public static String getCaptionString (String a_sourceString, int a_captionLength) {
		if (a_sourceString == null) {
			return null;
		}
		else {
			if (a_captionLength < c_minimumCaptionLength) {
				a_captionLength = c_minimumCaptionLength;
			}
			int l_lackingLength = a_captionLength - a_sourceString.length ();
			if (l_lackingLength == 0) {
				return a_sourceString;
			}
			else if (l_lackingLength > 0) {
				return String.format (String.format (UserInterfaceComponentCaptionsConstantsGroup.c_generalFullFormat, l_lackingLength), a_sourceString, " ");
			}
			else {
				return String.format (UserInterfaceComponentCaptionsConstantsGroup.c_generalAbrreviatedFormat, a_sourceString.substring (GeneralConstantsConstantsGroup.c_iterationStartingNumber, a_captionLength - c_minimumCaptionLength + 1));
			}
		}
	}
	
	public static String getClassOrInterfaceRelativeName (String a_classOrInterfaceName) {
		int l_lastIndexOfJavaPackageDelimiter = GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger;
		if (a_classOrInterfaceName != null) {
			l_lastIndexOfJavaPackageDelimiter = a_classOrInterfaceName.lastIndexOf (GeneralConstantsConstantsGroup.c_javaPackagesDelimiter);
			if (l_lastIndexOfJavaPackageDelimiter != GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger) {
				if (l_lastIndexOfJavaPackageDelimiter + 1 < a_classOrInterfaceName.length ()) {
					return a_classOrInterfaceName.substring (l_lastIndexOfJavaPackageDelimiter + 1);
				}
				else {
					return null;
				}
			}
		}
		else {
			return null;
		}
		return null;
	}
	
	public static ArrayList <String> splitArgumentsString (String a_argumentsString) throws Exception {
		if (a_argumentsString != null) {
			ArrayList <String> l_arguments = new ArrayList <String> ();
			int l_argumentsStringCharactersLength = a_argumentsString.length ();
			StringBuffer l_argumentBuffer = new StringBuffer ();
			char l_character = GeneralConstantsConstantsGroup.c_anyUnspecifiedCharacter;
			boolean l_isInBlock = false;
			boolean l_isEscaped = false;
			boolean l_isAtArgumentStart = true;
			char l_blockingCharacter = GeneralConstantsConstantsGroup.c_anyUnspecifiedCharacter;
			int l_characterIndex = GeneralConstantsConstantsGroup.c_iterationStartingNumber;
			for (; l_characterIndex < l_argumentsStringCharactersLength; l_characterIndex ++) {
				l_character = a_argumentsString.charAt (l_characterIndex);
				// Is in a block Start
				if (l_isInBlock) {
					// Is escaped Start
					if (l_isEscaped) {
						// Is or not at an argument start Start
						if (l_isAtArgumentStart || !l_isAtArgumentStart) {
							if (l_character == GeneralConstantsConstantsGroup.c_doubleQuotationMarkCharacter || l_character == GeneralConstantsConstantsGroup.c_apostropheCharacter) {
								l_argumentBuffer.append (l_character );
								l_isEscaped = false;
								l_isAtArgumentStart = false;
							}
							else if (l_character == GeneralConstantsConstantsGroup.c_escapingCharacter) {
								l_argumentBuffer.append (l_character );
								l_isEscaped = false;
								l_isAtArgumentStart = false;
							}
							else if (l_character == GeneralConstantsConstantsGroup.c_argumentsDelimiter) {
								// error
								throw new Exception (String.format ("There is an invalid expression at %d.", l_characterIndex));
							}
							else {
								// error
								throw new Exception (String.format ("There is an invalid expression at %d.", l_characterIndex));
							}
						}
						// Is or not at an argument start End
					}
					// Is escaped End
					// Is not escaped Start
					else {
						// Is or not at an argument start Start
						if (l_isAtArgumentStart || !l_isAtArgumentStart) {
							if (l_character == l_blockingCharacter) {
								l_blockingCharacter = GeneralConstantsConstantsGroup.c_anyUnspecifiedCharacter;
								l_isInBlock = false;
							}
							else if (l_character == GeneralConstantsConstantsGroup.c_escapingCharacter) {
								l_isEscaped = true;
							}
							else if (l_character == GeneralConstantsConstantsGroup.c_argumentsDelimiter) {
								l_argumentBuffer.append (l_character);
								l_isAtArgumentStart = false;
							}
							else {
								l_argumentBuffer.append (l_character);
								l_isAtArgumentStart = false;
							}
						}
						// Is or not at an argument start End
					}
					// Is not escaped End
				}
				// Is in a block End
				// Is not in a block Start
				else {
					// Is escaped Start
					if (l_isEscaped) {
						// Is or not at an argument start Start
						if (l_isAtArgumentStart || !l_isAtArgumentStart) {
							if (l_character == GeneralConstantsConstantsGroup.c_doubleQuotationMarkCharacter || l_character == GeneralConstantsConstantsGroup.c_apostropheCharacter) {
								l_argumentBuffer.append (l_character);
								l_isEscaped = false;
								l_isAtArgumentStart = false;
							}
							else if (l_character == GeneralConstantsConstantsGroup.c_escapingCharacter) {
								l_argumentBuffer.append (l_character);
								l_isEscaped = false;
								l_isAtArgumentStart = false;
							}
							else if (l_character == GeneralConstantsConstantsGroup.c_argumentsDelimiter) {
								// error
								throw new Exception (String.format ("There is an invalid expression at %d.", l_characterIndex));
							}
							else {
								// error
								throw new Exception (String.format ("There is an invalid expression at %d.", l_characterIndex));
							}
						}
						// Is or not at an argument start End
					}
					// Is escaped End
					// Is not escaped Start
					else {
						// Is or not at an argument start Start
						if (l_isAtArgumentStart || !l_isAtArgumentStart) {
							if (l_character == GeneralConstantsConstantsGroup.c_doubleQuotationMarkCharacter || l_character == GeneralConstantsConstantsGroup.c_apostropheCharacter) {
								l_blockingCharacter = l_character;
								l_isInBlock = true;
							}
							else if (l_character == GeneralConstantsConstantsGroup.c_escapingCharacter) {
								l_isEscaped = true;
							}
							else if (l_character == GeneralConstantsConstantsGroup.c_argumentsDelimiter) {
								if (l_isAtArgumentStart ) {
								}
								else {
									l_arguments.add (l_argumentBuffer.toString ());
									l_argumentBuffer.setLength (0);
									l_isAtArgumentStart = true;
								}
							}
							else {
								l_argumentBuffer.append (l_character);
								l_isAtArgumentStart = false;
							}
						}
						// Is or not at an argument start End
					}
					// Is not escaped End
				}
				// Is not in a block End
			}
			if (l_isInBlock) {
				// error
				throw new Exception (String.format ("There is an invalid expression at %d.", l_characterIndex));
			}
			else {
				if (l_isEscaped) {
					// error
					throw new Exception (String.format ("There is an invalid expression at %d.", l_characterIndex));
				}
				else {
					if (l_isAtArgumentStart) {
					}
					else {
						l_arguments.add (l_argumentBuffer.toString ());
						l_argumentBuffer.setLength (0);
						l_isAtArgumentStart = true;
					}
				}
			}
			return l_arguments;
		}
		else {
			return null;
		}
	}
	
	public static String getUrl (String a_filePath) {
		return (Paths.get (a_filePath)).normalize ().toUri ().toString ();
	}
	
	public static String getFileNameExtension (String a_fileName) {
		int l_indexOfLastPeriod = a_fileName.lastIndexOf (GeneralConstantsConstantsGroup.c_fileNameElementsDelimiter);
		if (l_indexOfLastPeriod >= GeneralConstantsConstantsGroup.c_iterationStartingNumber) {
			return a_fileName.substring (l_indexOfLastPeriod + 1);
		}
		else {
			return null;
		}
	}
}

