package theBiasPlanet.coreUtilities.collections;

import java.util.AbstractMap;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

public class NavigableLinkedHashMap <T, U> implements Map <T, U> {
	private class ValueAndLinks <T, U> {
		U i_value;
		T i_previousKey;
		T i_nextKey;
		
		public ValueAndLinks (U a_value, T a_previousKey, T a_nextKey) {
			i_value = a_value;
			i_previousKey = a_previousKey;
			i_nextKey = a_nextKey;
		}
		
		public U getValue () {
			return i_value;
		}
		
		public void setValue (U a_value) {
			i_value = a_value;
		}
		
		public T getPreviousKey () {
			return i_previousKey;
		}
		
		public void setPreviousKey (T a_previousKey) {
			i_previousKey = a_previousKey;
		}
		
		public T getNextKey () {
			return i_nextKey;
		}
		
		public void setNextKey (T a_nextKey) {
			i_nextKey = a_nextKey;
		}
	}
	
	private HashMap <T, ValueAndLinks <T, U>> i_keyToValueAndLinksHashMap;
	private T i_firstKey;
	private T i_lastKey;
	
	public NavigableLinkedHashMap () {
		i_keyToValueAndLinksHashMap = new HashMap <T, ValueAndLinks <T, U>> ();
		initialize ();
	}
	
	public NavigableLinkedHashMap (int a_initialCapacity) {
		i_keyToValueAndLinksHashMap = new HashMap <T, ValueAndLinks <T, U>> (a_initialCapacity);
		initialize ();
	}
	
	public NavigableLinkedHashMap (int a_initialCapacity, float a_loadFactor) {
		i_keyToValueAndLinksHashMap = new HashMap <T, ValueAndLinks <T, U>> (a_initialCapacity, a_loadFactor);
		initialize ();
	}
	
	public NavigableLinkedHashMap (Map <? extends T,? extends U> a_map) {
		
		i_keyToValueAndLinksHashMap = new HashMap <T, ValueAndLinks <T, U>> (a_map.size ());
		initialize ();
		putAll (a_map);
	}
	
	private void initialize () {
		i_firstKey = null;
		i_lastKey = null;
	}
	
	@Override
	public boolean containsKey (Object a_key) {
		return i_keyToValueAndLinksHashMap.containsKey (a_key);
	}
	
	@Override
	public boolean containsValue (Object a_value) {
		for (Map.Entry <T, ValueAndLinks <T, U>> l_keyToValueAndLinksHashMapEntry: i_keyToValueAndLinksHashMap.entrySet ()) {
			U l_value = l_keyToValueAndLinksHashMapEntry.getValue ().getValue ();
			return (a_value == null ? l_value == null : a_value.equals (l_value));
		}
		return false;
	}
	
	@Override
	public U get (Object a_key) {
		return i_keyToValueAndLinksHashMap.get (a_key).getValue ();
	}
	
	@Override
	public int hashCode () {
		return i_keyToValueAndLinksHashMap.hashCode ();
	}
	
	@Override
	public boolean isEmpty () {
		return i_keyToValueAndLinksHashMap.isEmpty ();
	}
	
	@Override
	public Set <T> keySet () {
		LinkedHashSet <T> l_keys = new LinkedHashSet <T> ();
		for (T l_key = i_firstKey, l_nexyKey = null; l_key != null; l_key = l_nexyKey) {
			ValueAndLinks <T, U> l_valueAndLinks = i_keyToValueAndLinksHashMap.get (l_key);
			l_keys.add (l_key);
			l_nexyKey = l_valueAndLinks.getNextKey ();
		}
		return l_keys;
	}
	
	@Override
	public U put (T a_key, U a_value) {
		ValueAndLinks <T, U> l_valueAndLinks = i_keyToValueAndLinksHashMap.get (a_key);
		if (l_valueAndLinks != null) {
			U l_value = l_valueAndLinks.getValue ();
			l_valueAndLinks.setValue (a_value);
			return l_value;
		}
		else {
			l_valueAndLinks = new ValueAndLinks <T, U> (a_value, i_lastKey, null);
			i_keyToValueAndLinksHashMap.put (a_key, l_valueAndLinks);
			T l_previousKey = l_valueAndLinks.getPreviousKey ();
			if (l_previousKey != null) {
				i_keyToValueAndLinksHashMap.get (l_previousKey).setNextKey (a_key);
			}
			else {
				i_firstKey = a_key;
			}
			i_lastKey = a_key;
			return null;
		}
	}
	
	public U putBefore (T a_insertedPositionKey, T a_key, U a_value) {
		ValueAndLinks <T, U> l_existingValueAndLinks = i_keyToValueAndLinksHashMap.get (a_key);
		if (l_existingValueAndLinks != null) {
			return null;
		}
		else {
			ValueAndLinks <T, U> l_insertedPositionValueAndLinks = i_keyToValueAndLinksHashMap.get (a_insertedPositionKey);
			if (l_insertedPositionValueAndLinks == null) {
				return null;
			}
			else {
				T l_previousKeyOfInsertedPosition = l_insertedPositionValueAndLinks.getPreviousKey ();
				ValueAndLinks <T, U> l_valueAndLinks = new ValueAndLinks <T, U> (a_value, l_previousKeyOfInsertedPosition, a_insertedPositionKey);
				i_keyToValueAndLinksHashMap.put (a_key, l_valueAndLinks);
				if (l_previousKeyOfInsertedPosition != null) {
					i_keyToValueAndLinksHashMap.get (l_previousKeyOfInsertedPosition).setNextKey (a_key);
				}
				else {
					i_firstKey = a_key;
				}
				l_insertedPositionValueAndLinks.setPreviousKey (a_key);
				return l_insertedPositionValueAndLinks.getValue ();
			}
		}
	}
	
	@Override
	public void putAll (Map <? extends T,? extends U> a_map) {
		for (Map.Entry <? extends T,? extends U> l_mapEntry: a_map.entrySet ()) {
			put (l_mapEntry.getKey (), l_mapEntry.getValue ());
		}
	}
	
	@Override
	public U remove(Object a_key) {
		ValueAndLinks <T, U> l_valueAndLinks = i_keyToValueAndLinksHashMap.get (a_key);
		if (l_valueAndLinks != null) {
			i_keyToValueAndLinksHashMap.remove (a_key);
			T l_previousKey = l_valueAndLinks.getPreviousKey ();
			T l_nextKey = l_valueAndLinks.getNextKey ();
			if (l_previousKey != null) {
				i_keyToValueAndLinksHashMap.get (l_previousKey).setNextKey (l_nextKey);
			}
			else {
				i_firstKey = l_nextKey;
			}
			if (l_nextKey != null) {
				i_keyToValueAndLinksHashMap.get (l_nextKey).setPreviousKey (l_previousKey);
			}
			else {
				i_lastKey = l_previousKey;
			}
			return l_valueAndLinks.getValue ();
		}
		else {
			return null;
		}
	}
	
	@Override
	public void clear () {
		i_keyToValueAndLinksHashMap.clear ();
		i_firstKey = null;
		i_lastKey = null;
	}
	
	@Override
	public Set <Map.Entry <T, U>> entrySet () {
		LinkedHashSet <Map.Entry <T, U>> l_keyToValueEntries = new LinkedHashSet <Map.Entry <T, U>> ();
		for (T l_key = i_firstKey, l_nexyKey = null; l_key != null; l_key = l_nexyKey) {
			ValueAndLinks <T, U> l_valueAndLinks = i_keyToValueAndLinksHashMap.get (l_key);
			l_keyToValueEntries.add (new AbstractMap.SimpleEntry <T, U> (l_key, l_valueAndLinks.getValue ()));
			l_nexyKey = l_valueAndLinks.getNextKey ();
		}
		return l_keyToValueEntries;
	}
	
	@Override
	public Collection <U> values () {
		LinkedHashSet <U> l_values = new LinkedHashSet <U> ();
		for (T l_key = i_firstKey, l_nexyKey = null; l_key != null; l_key = l_nexyKey) {
			ValueAndLinks <T, U> l_valueAndLinks = i_keyToValueAndLinksHashMap.get (l_key);
			l_values.add (l_valueAndLinks.getValue ());
			l_nexyKey = l_valueAndLinks.getNextKey ();
		}
		return l_values;
	}
	
	@Override
	public boolean equals (Object a_object) {
		if (a_object == null || a_object instanceof Map) {
			return false;
		}
		return entrySet ().equals ( ( (Map) a_object).entrySet ());
	}
	
	@Override
	public int size () {
		return i_keyToValueAndLinksHashMap.size ();
	}
	
	public T getPreviousKey (T a_key) {
		ValueAndLinks <T, U> l_valueAndLinks = i_keyToValueAndLinksHashMap.get (a_key);
		if (l_valueAndLinks != null) {
			return l_valueAndLinks.getPreviousKey ();
		}
		else {
			return null;
		}
	}
	
	public T getNextKey (T a_key) {
		ValueAndLinks <T, U> l_valueAndLinks = i_keyToValueAndLinksHashMap.get (a_key);
		if (l_valueAndLinks != null) {
			return l_valueAndLinks.getNextKey ();
		}
		else {
			return null;
		}
	}
	
	public T getFirstKey () {
		return i_firstKey;
	}
	
	public T getLastKey () {
		return i_lastKey;
	}
}

