#include "theBiasPlanet/coreUtilities/constantsGroups/DefaultValuesConstantsGroup.hpp"

namespace theBiasPlanet {
	namespace coreUtilities {
		namespace constantsGroups {
			int const DefaultValuesConstantsGroup::c_smallBufferSize (1024);
			int const DefaultValuesConstantsGroup::c_largeBufferSize (102400);
			int const DefaultValuesConstantsGroup::c_smallestBufferSize (1);
		}
	}
}

