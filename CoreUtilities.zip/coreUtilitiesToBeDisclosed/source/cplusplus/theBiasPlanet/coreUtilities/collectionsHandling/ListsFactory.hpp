#ifndef __theBiasPlanet_coreUtilities_collectionsHandling_ListsFactory_hpp__
#define __theBiasPlanet_coreUtilities_collectionsHandling_ListsFactory_hpp__

#include <list>
#include "theBiasPlanet/coreUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"

using namespace ::std;

namespace theBiasPlanet {
	namespace coreUtilities {
		namespace collectionsHandling {
			class __theBiasPlanet_coreUtilities_symbolExportingOrImportingDeclarationForVisualCplusplus__ ListsFactory {
				public:
					template <typename T, typename ... U> static list <T> * createList (list <T> * const a_resultList, T const & a_currentElement, U const & ... a_remainingElements);
					template <typename T> static list <T> * createList (list <T> * const a_resultList);
					template <typename T, typename ... U> static list <T> createList (T const & a_currentElement, U const & ... a_remainingElements);
			};
		}
	}
}

#endif

