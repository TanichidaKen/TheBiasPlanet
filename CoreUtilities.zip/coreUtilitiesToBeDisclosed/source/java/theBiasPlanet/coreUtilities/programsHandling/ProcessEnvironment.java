package theBiasPlanet.coreUtilities.programsHandling;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Properties;
import java.util.StringTokenizer;
import theBiasPlanet.coreUtilities.constantsGroups.*;

public class ProcessEnvironment {
	public static ProcessEnvironment s_currentEnvironment;
	protected String i_identification = null;
	protected Properties i_properties = null;
	protected String i_operatingSystemName = null; // 'Linux' or 'Windows'
	protected ArrayList <String> i_operatingSystemCommandsPaths = null; // Doesn't suppose that 'PATH' has ';' as any part of any path.
	protected char i_operatingSystemDirectoriesDelimiter = GeneralConstantsConstantsGroup.c_anyUnspecifiedCharacter;
	protected String i_operatingSystemFilePathFormat = null;
	
	public ProcessEnvironment (String a_identification, String a_propertyFileUrl) throws FileNotFoundException, IOException {
		i_identification = a_identification;
		i_properties = new Properties();
		if (a_propertyFileUrl != null) {
			i_properties.loadFromXML (new FileInputStream (a_propertyFileUrl));
		}
		char l_operatingSystemPathsDelimiter = GeneralConstantsConstantsGroup.c_anyUnspecifiedCharacter;
		i_operatingSystemName = System.getProperty (JavaPropertyNamesConstantsGroup.c_operatingSystemName); 
		if (i_operatingSystemName .startsWith (OperatingSystemNamesConstantsGroup.c_linux)) {
			i_operatingSystemName = OperatingSystemNamesConstantsGroup.c_linux;
			l_operatingSystemPathsDelimiter = GeneralConstantsConstantsGroup.c_linuxPathsDelimiter;
			i_operatingSystemDirectoriesDelimiter = GeneralConstantsConstantsGroup.c_linuxDirectoriesDelimiter;
			i_operatingSystemFilePathFormat = GeneralConstantsConstantsGroup.c_linuxFilePathFormat;
		}
		else if (i_operatingSystemName .startsWith (OperatingSystemNamesConstantsGroup.c_windows)) {
			i_operatingSystemName = OperatingSystemNamesConstantsGroup.c_windows;
			l_operatingSystemPathsDelimiter = GeneralConstantsConstantsGroup.c_windowsPathsDelimiter;
			i_operatingSystemDirectoriesDelimiter = GeneralConstantsConstantsGroup.c_windowsDirectoriesDelimiter;
			i_operatingSystemFilePathFormat = GeneralConstantsConstantsGroup.c_windowsFilePathFormat;
		}
		else {
		}
		String l_operatingSystemCommandsPathsExpression = System.getenv (OperatingSystemEnvironmentVariableNamesConstantsGroup.c_path);
		StringTokenizer l_operatingSystemCommandsPathTokenizer = new StringTokenizer (l_operatingSystemCommandsPathsExpression, String.valueOf (l_operatingSystemPathsDelimiter));
		i_operatingSystemCommandsPaths = new ArrayList <String> ();
		while (l_operatingSystemCommandsPathTokenizer.hasMoreTokens()) {
			i_operatingSystemCommandsPaths.add (l_operatingSystemCommandsPathTokenizer.nextToken ());
		}
		s_currentEnvironment = this;
	}
	
	public final String getIdentification () {
		return i_identification;
	}
	
	public final Properties getProperties () {
		return i_properties;
	}
	
	public final String getOperatingSystemName () {
		return i_operatingSystemName;
	}
	
	public final char getOperatingSystemDirectoriesDelimiter () {
		return i_operatingSystemDirectoriesDelimiter;
	}
	
	public final String getOperatingSystemFilePathFormat () {
		return i_operatingSystemFilePathFormat;
	}
	
	// 'a_commandName' has to include the file extension, for example 'exe'.
	public final String getCommandAbsolutePath (String a_commandName) {
		String l_commandAbsolutePathCandidate = null;
		for (String l_operatingSystemCommandsPath: i_operatingSystemCommandsPaths) {
			l_commandAbsolutePathCandidate = String.format (GeneralConstantsConstantsGroup.c_linuxFilePathFormat, l_operatingSystemCommandsPath, a_commandName);
			if (Files.isExecutable (Paths.get (l_commandAbsolutePathCandidate))) {
				return l_commandAbsolutePathCandidate;
			}
		}
		return null;
	}
}

