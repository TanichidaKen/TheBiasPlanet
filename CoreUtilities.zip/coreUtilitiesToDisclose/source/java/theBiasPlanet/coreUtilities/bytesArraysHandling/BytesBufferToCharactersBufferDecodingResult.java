package theBiasPlanet.coreUtilities.bytesArraysHandling;

import java.nio.ByteBuffer;
import java.nio.charset.CoderResult;
import theBiasPlanet.coreUtilities.constantsGroups.*;

public class BytesBufferToCharactersBufferDecodingResult {
	private int i_resultStatus = GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger;
	private int i_inputsResidueStartingIndex = GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger;
	private final int c_justFitResultStatus = 0;
	private final int c_underflowedResultStatus = 1;
	private final int c_overflowedResultStatus = 2;
	private final int c_malformedResultStatus = 3;
	private final int c_unmappableResultStatus = 4;
	
	public BytesBufferToCharactersBufferDecodingResult (CoderResult a_instanceOfCoderResult, ByteBuffer a_inputBuffer) {
		if (a_instanceOfCoderResult.isUnderflow ()) {
			if (a_inputBuffer.position () == a_inputBuffer.limit ()) {
				i_resultStatus = c_justFitResultStatus;
			}
			else {
				i_resultStatus = c_underflowedResultStatus;
				i_inputsResidueStartingIndex = a_inputBuffer.position ();
			}
		}
		else {
			if (a_instanceOfCoderResult.isOverflow ()) {
				i_resultStatus = c_overflowedResultStatus;
			}
			else if (a_instanceOfCoderResult.isMalformed ()) {
				i_resultStatus = c_malformedResultStatus;
			}
			else if (a_instanceOfCoderResult.isUnmappable ()) {
				i_resultStatus = c_unmappableResultStatus;
			}
			else {
				// impossible
			}
			i_inputsResidueStartingIndex = a_inputBuffer.position ();
		}
	}
	
	public BytesBufferToCharactersBufferDecodingResult (int a_inputsResidueStartingIndex) {
		i_inputsResidueStartingIndex = a_inputsResidueStartingIndex;
		i_resultStatus = c_malformedResultStatus;
	}
	
	public boolean isJustFit () {
		return (i_resultStatus == c_justFitResultStatus) ? true : false;
	}
	
	public boolean isUnderflowed () {
		return (i_resultStatus == c_underflowedResultStatus) ? true : false;
	}
	
	public boolean isOverflowed () {
		return (i_resultStatus == c_overflowedResultStatus) ? true : false;
	}
	
	public boolean isMalformed () {
		return (i_resultStatus == c_malformedResultStatus) ? true : false;
	}
	
	public boolean isUnmappable () {
		return (i_resultStatus == c_unmappableResultStatus) ? true : false;
	}
	
	public int getInputsResidueStartingIndex () {
		return i_inputsResidueStartingIndex;
	}
	
	public void setInputsResidueStartingIndex (int a_inputsResidueStartingIndex) {
		i_inputsResidueStartingIndex = a_inputsResidueStartingIndex;
	}
	
	public String toString () {
		if (isJustFit ()) {
			return "Just fit";
		}
		else if (isUnderflowed ()) {
			return "Underflowed";
		}
		else if (isOverflowed ()) {
			return "Overflowed";
		}
		else if (isMalformed ()) {
			return "Malformed";
		}
		else if (isUnmappable ()) {
			return "Unmappable";
		}
		else {
			return "Impossible status";
		}
	}
}

