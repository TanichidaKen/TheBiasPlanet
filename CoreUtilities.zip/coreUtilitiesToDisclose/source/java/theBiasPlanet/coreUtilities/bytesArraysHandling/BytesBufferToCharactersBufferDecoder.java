package theBiasPlanet.coreUtilities.bytesArraysHandling;

import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import theBiasPlanet.coreUtilities.constantsGroups.*;

public class BytesBufferToCharactersBufferDecoder {
	private CharsetDecoder i_instanceOfCharsetDecoder = null;
	// Although the encoding may not be UTF-8, any character of any major encoding isn't supposed to be longer than the per-UTF-8-character maximum bytes length.
	private	ByteBuffer i_previousInputsResidueBuffer = ByteBuffer.wrap (new byte [GeneralConstantsConstantsGroup.c_maximumBytesLengthPerUtf8Character]);
	
	public BytesBufferToCharactersBufferDecoder (String a_encoding) {
		i_instanceOfCharsetDecoder = Charset.forName (a_encoding).newDecoder ();
	}
	
	public BytesBufferToCharactersBufferDecodingResult decode (ByteBuffer a_newInputBuffer, CharBuffer a_outputBuffer, boolean a_isLastInput) {
		BytesBufferToCharactersBufferDecodingResult l_decodingResult = null;
		int l_previousInputsResidueBufferStartingPointOfTimeIndex = i_previousInputsResidueBuffer.position ();
		if (l_previousInputsResidueBufferStartingPointOfTimeIndex != 0) {
			int l_supplementalInputCandidateLength = Math.min (a_newInputBuffer.limit () - a_newInputBuffer.position (), i_previousInputsResidueBuffer.capacity () - l_previousInputsResidueBufferStartingPointOfTimeIndex);
			if (l_supplementalInputCandidateLength == 0) {
				l_decodingResult = new BytesBufferToCharactersBufferDecodingResult (-1 * l_previousInputsResidueBufferStartingPointOfTimeIndex);
				return l_decodingResult;
			}
			int l_newInputBufferLimit = a_newInputBuffer.limit ();
			a_newInputBuffer.limit (a_newInputBuffer.position () + l_supplementalInputCandidateLength);
			i_previousInputsResidueBuffer.put (a_newInputBuffer);
			a_newInputBuffer.limit (l_newInputBufferLimit);
			i_previousInputsResidueBuffer.flip ();
			l_decodingResult = new BytesBufferToCharactersBufferDecodingResult (i_instanceOfCharsetDecoder.decode (i_previousInputsResidueBuffer, a_outputBuffer, false), i_previousInputsResidueBuffer);
			if (l_decodingResult.isUnderflowed ()) {
				if (l_decodingResult.getInputsResidueStartingIndex() == GeneralConstantsConstantsGroup.c_iterationStartingNumber) {
					i_previousInputsResidueBuffer.position (i_previousInputsResidueBuffer.limit ());
					i_previousInputsResidueBuffer.limit (i_previousInputsResidueBuffer.capacity ());
					l_decodingResult.setInputsResidueStartingIndex (-1 * l_previousInputsResidueBufferStartingPointOfTimeIndex);
					return l_decodingResult;
				}
				else {
					a_newInputBuffer.position (a_newInputBuffer.position () - (i_previousInputsResidueBuffer.limit () -  l_decodingResult.getInputsResidueStartingIndex ()));
					i_previousInputsResidueBuffer.clear ();
				}
			}
			else if (l_decodingResult.isJustFit ()) {
				i_previousInputsResidueBuffer.clear ();
			}
			else {
				int l_inputsResidueStartingIndex = l_decodingResult.getInputsResidueStartingIndex () < l_previousInputsResidueBufferStartingPointOfTimeIndex ? -1 * (l_previousInputsResidueBufferStartingPointOfTimeIndex - l_decodingResult.getInputsResidueStartingIndex ()) :  a_newInputBuffer.position () - l_supplementalInputCandidateLength + (l_decodingResult.getInputsResidueStartingIndex () - l_previousInputsResidueBufferStartingPointOfTimeIndex);
				l_decodingResult.setInputsResidueStartingIndex (l_inputsResidueStartingIndex);
				return l_decodingResult;
			}
		}
		l_decodingResult = new BytesBufferToCharactersBufferDecodingResult (i_instanceOfCharsetDecoder.decode (a_newInputBuffer, a_outputBuffer, a_isLastInput), a_newInputBuffer);
		if (a_isLastInput) {
			i_instanceOfCharsetDecoder.flush (a_outputBuffer);
		}
		if (l_decodingResult.isUnderflowed ()) {
			i_previousInputsResidueBuffer.put (a_newInputBuffer);
		}
		return l_decodingResult;
	}
	
	public void reset () {
		i_instanceOfCharsetDecoder.reset ();
		i_previousInputsResidueBuffer.clear ();
	}
}

