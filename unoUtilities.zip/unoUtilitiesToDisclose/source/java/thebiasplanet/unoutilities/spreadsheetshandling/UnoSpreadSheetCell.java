package thebiasplanet.unoutilities.spreadsheetshandling;

import java.io.InputStream;
import java.io.Reader;
import java.io.StringReader;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import com.sun.star.uno.XComponentContext;
import com.sun.star.uno.UnoRuntime;
import com.sun.star.lang.WrappedTargetException;
import com.sun.star.awt.FontSlant;
import com.sun.star.awt.FontUnderline;
import com.sun.star.awt.FontStrikeout;
import com.sun.star.view.XSelectionSupplier;
import com.sun.star.table.XCell;
import com.sun.star.table.CellContentType;
import com.sun.star.table.CellAddress;
import com.sun.star.table.XCellRange;
import com.sun.star.table.BorderLine2;
import com.sun.star.table.BorderLineStyle;
import com.sun.star.table.CellHoriJustify;
import com.sun.star.text.XText;
import com.sun.star.text.XTextCursor;
import com.sun.star.beans.XPropertySet;
import com.sun.star.beans.UnknownPropertyException;
import com.sun.star.beans.PropertyVetoException;
import com.sun.star.sheet.XCellAddressable;
import com.sun.star.util.MalformedNumberFormatException;

public class UnoSpreadSheetCell {
	private static Pattern NUMBERS_REGULAR_EXPRESSION_PATTERN = Pattern.compile ("^(\\d*|\\d{1,3}(,\\d{3})*)(\\.\\d+)?([eE][-+]?\\d+)?$");
	private UnoSpreadSheet spreadSheet = null;
	private XCell bareSpreadSheetCellInXCell = null;
	private XCellAddressable bareSpreadSheetCellInXCellAddressable = null;
	private XPropertySet bareSpreadSheetCellInXPropertySet = null;
	private XText bareSpreadSheetCellInXText = null;
	
	public static UnoSpreadSheetCell getCurrentCell (XComponentContext p_componentContextInXComponentContext) throws Exception {
		UnoSpreadSheet l_currentSpreadSheat = UnoSpreadSheet.getCurrentSpreadSheet (p_componentContextInXComponentContext);
		XCellRange l_currentCellsInXCellRange = (XCellRange) UnoRuntime.queryInterface (XCellRange.class, l_currentSpreadSheat.getSpreadSheetDocument ().getBareSpreadSheetDocumentinXModel ().getCurrentSelection ());
		if (l_currentCellsInXCellRange != null) {
			return new UnoSpreadSheetCell (l_currentSpreadSheat, l_currentCellsInXCellRange.getCellByPosition (0, 0));
			
		}
		else {
			return null;
		}
	}
	
	public UnoSpreadSheetCell (UnoSpreadSheet p_spreadSheet, XCell p_bareSpreadSheetCellInXCell) {
		spreadSheet = p_spreadSheet;
		bareSpreadSheetCellInXCell = p_bareSpreadSheetCellInXCell;
		bareSpreadSheetCellInXCellAddressable = (XCellAddressable) UnoRuntime.queryInterface (XCellAddressable.class, bareSpreadSheetCellInXCell);
		bareSpreadSheetCellInXPropertySet = (XPropertySet) UnoRuntime.queryInterface (XPropertySet.class, bareSpreadSheetCellInXCell);
		bareSpreadSheetCellInXText = (XText) UnoRuntime.queryInterface (XText.class, p_bareSpreadSheetCellInXCell);
	}
	
	public UnoSpreadSheet getSpreadSheet () {
		return spreadSheet;
	}
	
	public XCell getBareSpreadSheetCellInXCell () {
		return bareSpreadSheetCellInXCell;
	}
	
	public Object getValue () throws UnknownPropertyException, WrappedTargetException, IOException {
		CellContentType l_cellContentType = bareSpreadSheetCellInXCell.getType ();
		if (l_cellContentType == CellContentType.EMPTY) {
			return null;
		}
		// l_cellContentType can be CellContentType.VALUE, CellContentType.TEXT, or CellContentType.FORMULA
		int l_cellValueExpressionFormatKey = ((Integer) bareSpreadSheetCellInXPropertySet.getPropertyValue ("NumberFormat")).intValue ();
		String l_cellValueExpression = bareSpreadSheetCellInXText.getString ();
		if (l_cellValueExpressionFormatKey == spreadSheet.getSpreadSheetDocument ().getDateExpressionFormatKey ()) {
			LocalDate l_date = LocalDate.parse (l_cellValueExpression, DateTimeFormatter.ISO_LOCAL_DATE);
			return l_date;
		}
		else if (l_cellValueExpressionFormatKey == spreadSheet.getSpreadSheetDocument ().getTimeExpressionFormatKey ()) {
			LocalTime l_time = LocalTime.parse (l_cellValueExpression, DateTimeFormatter.ISO_LOCAL_TIME);
			return l_time;
		}
		else if (l_cellValueExpressionFormatKey == spreadSheet.getSpreadSheetDocument ().getDateTimeExpressionFormatKey ()) {
			LocalDateTime l_dateTime = LocalDateTime.parse (l_cellValueExpression, DateTimeFormatter.ISO_LOCAL_DATE_TIME);
			return l_dateTime;
		}
		else if (l_cellValueExpressionFormatKey == spreadSheet.getSpreadSheetDocument ().getBooleanExpressionFormatKey ()) {
			Boolean l_boolean = Boolean.valueOf (l_cellValueExpression);
			return l_boolean;
		}
		else if (l_cellValueExpressionFormatKey == spreadSheet.getSpreadSheetDocument ().getStringExpressionFormatKey ()) {
			return l_cellValueExpression;
		}
		else if (l_cellValueExpressionFormatKey == spreadSheet.getSpreadSheetDocument ().getIntegerExpressionFormatKey ()) {
			Integer l_integer = Integer.valueOf (l_cellValueExpression.replaceAll (",", ""));
			return l_integer;
		}
		else {
			Matcher l_matcher = NUMBERS_REGULAR_EXPRESSION_PATTERN.matcher (l_cellValueExpression);
			if (l_matcher.find ()) {
				Double l_double = Double.valueOf (l_cellValueExpression.replaceAll (",", ""));
				return l_double;
			}
			else {
				return l_cellValueExpression;
			}
		}
	 }
	
	public Object getFormulaOrValue () throws UnknownPropertyException, WrappedTargetException, IOException {
		CellContentType l_cellContentType = bareSpreadSheetCellInXCell.getType ();
		// l_cellContentType can be CellContentType.VALUE, CellContentType.TEXT, or CellContentType.FORMULA
		if (l_cellContentType == CellContentType.FORMULA) {
			return new UnoSpreadSheetFormula (bareSpreadSheetCellInXCell.getFormula (), ((Integer) bareSpreadSheetCellInXPropertySet.getPropertyValue ("NumberFormat")).intValue ());
		}
		else {
			return getValue ();
		}
	}
	
	public int getNumberOfDecimalPlaces () throws UnknownPropertyException, WrappedTargetException {
		CellContentType l_cellContentType = bareSpreadSheetCellInXCell.getType ();
		if (l_cellContentType == CellContentType.EMPTY) {
			return -1;
		}
		int l_cellValueExpressionFormatKey = ((Integer) bareSpreadSheetCellInXPropertySet.getPropertyValue ("NumberFormat")).intValue ();
		return spreadSheet.getSpreadSheetDocument ().getNumberOfDecimalPlaces (l_cellValueExpressionFormatKey);
	}
	
	public void setValue (Object p_value) throws UnknownPropertyException, PropertyVetoException, MalformedNumberFormatException, WrappedTargetException {
		if (p_value instanceof Date) {
			p_value = ((Date) p_value).toLocalDate ();
		}
		if (p_value instanceof Time) {
			p_value = ((Time) p_value).toLocalTime ();
		}
		if (p_value instanceof Timestamp) {
			p_value = ((Timestamp) p_value).toLocalDateTime ();
		}
		if (p_value == null || p_value instanceof String) {
			String l_string = "";
			if (p_value != null) {
				l_string = (String) p_value;
			}
			bareSpreadSheetCellInXPropertySet.setPropertyValue("NumberFormat", new Integer (spreadSheet.getSpreadSheetDocument ().getStringExpressionFormatKey ()));
			bareSpreadSheetCellInXCell.setFormula ("");
			XTextCursor l_textCursor = bareSpreadSheetCellInXText.createTextCursor();
			bareSpreadSheetCellInXText.insertString( l_textCursor, l_string, true);
		}
		else if (p_value instanceof Integer) {
			Integer l_integer = (Integer) p_value;
			bareSpreadSheetCellInXPropertySet.setPropertyValue("NumberFormat", new Integer (spreadSheet.getSpreadSheetDocument ().getIntegerExpressionFormatKey ()));
			bareSpreadSheetCellInXCell.setValue (l_integer.intValue ());
		}
		else if (p_value instanceof Double) {
			Double l_double = (Double) p_value;
			bareSpreadSheetCellInXPropertySet.setPropertyValue("NumberFormat", new Integer (spreadSheet.getSpreadSheetDocument ().getDoubleExpressionFormatKey (-1)));
			bareSpreadSheetCellInXCell.setValue (l_double.doubleValue ());
		}
		else if (p_value instanceof Boolean) {
			Boolean l_boolean = (Boolean) p_value;
			bareSpreadSheetCellInXPropertySet.setPropertyValue("NumberFormat", new Integer (spreadSheet.getSpreadSheetDocument ().getBooleanExpressionFormatKey ()));
			bareSpreadSheetCellInXCell.setFormula (l_boolean.toString ());
		}
		else if (p_value instanceof LocalDate) {
			LocalDate l_date = (LocalDate) p_value;
			String l_dateString = l_date.format (DateTimeFormatter.ISO_LOCAL_DATE);
			bareSpreadSheetCellInXPropertySet.setPropertyValue("NumberFormat", new Integer (spreadSheet.getSpreadSheetDocument ().getDateExpressionFormatKey ()));
			bareSpreadSheetCellInXCell.setFormula (l_dateString);
		}
		else if (p_value instanceof LocalTime) {
			LocalTime l_time = (LocalTime) p_value;
			String l_timeString = l_time.format (DateTimeFormatter.ISO_LOCAL_TIME);
			bareSpreadSheetCellInXPropertySet.setPropertyValue("NumberFormat", new Integer (spreadSheet.getSpreadSheetDocument ().getTimeExpressionFormatKey ()));
			bareSpreadSheetCellInXCell.setFormula (l_timeString);
		}
		else if (p_value instanceof LocalDateTime) {
			LocalDateTime l_dateTime = (LocalDateTime) p_value;
			String l_dateTimeString = l_dateTime.format (DateTimeFormatter.ISO_LOCAL_DATE_TIME);
			bareSpreadSheetCellInXPropertySet.setPropertyValue("NumberFormat", new Integer (spreadSheet.getSpreadSheetDocument ().getDateTimeExpressionFormatKey ()));
			bareSpreadSheetCellInXCell.setFormula (l_dateTimeString);
		}
		else if (p_value instanceof UnoSpreadSheetFormula) {
			UnoSpreadSheetFormula l_formula = (UnoSpreadSheetFormula) p_value;
			if (l_formula.getCellValueExpressionFormatKey () != -1) {
				bareSpreadSheetCellInXPropertySet.setPropertyValue("NumberFormat", new Integer (l_formula.getCellValueExpressionFormatKey ()));
			}
			bareSpreadSheetCellInXCell.setFormula (l_formula.getFormulaString ());
		}
		else {
			String l_string = p_value.toString ();
			bareSpreadSheetCellInXPropertySet.setPropertyValue("NumberFormat", new Integer (spreadSheet.getSpreadSheetDocument ().getStringExpressionFormatKey ()));
			bareSpreadSheetCellInXCell.setFormula ("");
			XTextCursor l_textCursorInXTextCursor = bareSpreadSheetCellInXText.createTextCursor();
			bareSpreadSheetCellInXText.insertString( l_textCursorInXTextCursor, l_string, true);
		}
		//return p_value;
	}
	
	public void setValue (Double p_value, int p_numberOfDecimalPlaces) throws UnknownPropertyException, PropertyVetoException, MalformedNumberFormatException, WrappedTargetException {
		bareSpreadSheetCellInXPropertySet.setPropertyValue("NumberFormat", new Integer (spreadSheet.getSpreadSheetDocument ().getDoubleExpressionFormatKey (p_numberOfDecimalPlaces)));
		bareSpreadSheetCellInXCell.setValue (p_value.doubleValue ());
	}
	
	 public void insertString (String p_string, int p_characterIndex) throws Exception {
		CellContentType l_cellContentType = bareSpreadSheetCellInXCell.getType ();
		// l_cellContentType can be CellContentType.VALUE, CellContentType.TEXT, or CellContentType.FORMULA
		if (l_cellContentType == CellContentType.TEXT) {
			XTextCursor l_textCursorInXTextCursor = bareSpreadSheetCellInXText.createTextCursorByRange (bareSpreadSheetCellInXText.getStart ());
			l_textCursorInXTextCursor.goRight ( (short) p_characterIndex, false);
			bareSpreadSheetCellInXText.insertString (l_textCursorInXTextCursor, p_string, false);
			return;
		}
		else {
			throw new Exception ("The cell isn't a string value cell.");
		}
	}
	
	 public void replaceString (String p_string, int p_startCharacterIndex, int p_endCharacterIndex) throws Exception {
		CellContentType l_cellContentType = bareSpreadSheetCellInXCell.getType ();
		// l_cellContentType can be CellContentType.VALUE, CellContentType.TEXT, or CellContentType.FORMULA
		if (l_cellContentType == CellContentType.TEXT) {
			XTextCursor l_textCursorInXTextCursor = bareSpreadSheetCellInXText.createTextCursorByRange (bareSpreadSheetCellInXText.getStart ());
			l_textCursorInXTextCursor.goRight ( (short) p_startCharacterIndex, false);
			l_textCursorInXTextCursor.goRight ( (short) (p_endCharacterIndex + 1 - p_startCharacterIndex), true);
			bareSpreadSheetCellInXText.insertString (l_textCursorInXTextCursor, p_string, true);
			return;
		}
		else {
			throw new Exception ("The cell isn't a string value cell.");
		}
	}
	
	public int getRowIndex () {
		CellAddress l_cellAdress = bareSpreadSheetCellInXCellAddressable.getCellAddress ();
		return l_cellAdress.Row;
	}
	
	public int getColumnIndex () {
		CellAddress l_cellAdress = bareSpreadSheetCellInXCellAddressable.getCellAddress ();
		return l_cellAdress.Column;
	}
	
	public UnoSpreadSheetCell getUpperCell () throws com.sun.star.lang.IndexOutOfBoundsException {
		return spreadSheet.getSpreadSheetCell (getRowIndex () - 1, getColumnIndex ());
	}
	
	public UnoSpreadSheetCell getDownCell () throws com.sun.star.lang.IndexOutOfBoundsException {
		return spreadSheet.getSpreadSheetCell (getRowIndex () + 1, getColumnIndex ());
	}
	
	public UnoSpreadSheetCell getLeftCell () throws com.sun.star.lang.IndexOutOfBoundsException {
		return spreadSheet.getSpreadSheetCell (getRowIndex (), getColumnIndex () - 1);
	}
	
	public UnoSpreadSheetCell getRightCell () throws com.sun.star.lang.IndexOutOfBoundsException {
		return spreadSheet.getSpreadSheetCell (getRowIndex (), getColumnIndex () + 1);
	}
	
	public void setFocus () {
		XSelectionSupplier l_selectionSupplierInXSelectionSupplier = (XSelectionSupplier) UnoRuntime.queryInterface (XSelectionSupplier.class, spreadSheet.getSpreadSheetDocument ().getControllerInXSpreadsheetView ());
		l_selectionSupplierInXSelectionSupplier.select (bareSpreadSheetCellInXCell);
	}
	
	public int getBackgroundColor () throws UnknownPropertyException, WrappedTargetException {
		return ((Integer) bareSpreadSheetCellInXPropertySet.getPropertyValue ("CellBackColor")).intValue ();
	}
	
	public void setBackgroundColor (int p_pixelValue) throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		bareSpreadSheetCellInXPropertySet.setPropertyValue ("CellBackColor", new Integer (p_pixelValue));
		bareSpreadSheetCellInXPropertySet.setPropertyValue ("IsCellBackgroundTransparent", new Boolean (false));
	}
	
	public void removeBackgroundColor () throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		bareSpreadSheetCellInXPropertySet.setPropertyValue ("CellBackColor", new Integer (-1));
		bareSpreadSheetCellInXPropertySet.setPropertyValue ("IsCellBackgroundTransparent", new Boolean (true));
	}
	
	public int getForegroundColor () throws UnknownPropertyException, WrappedTargetException {
		return ((Integer) bareSpreadSheetCellInXPropertySet.getPropertyValue ("CharColor")).intValue ();
	}
	
	public void setForegroundColor (int p_pixelValue) throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		bareSpreadSheetCellInXPropertySet.setPropertyValue ("CharColor", new Integer (p_pixelValue));
	}
	
	public void setForegroundColorAutomatic () throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		bareSpreadSheetCellInXPropertySet.setPropertyValue ("CharColor", new Integer (-1));
	}
	
	public String getFontName () throws UnknownPropertyException, WrappedTargetException {
		return (String) bareSpreadSheetCellInXPropertySet.getPropertyValue ("CharFontName");
	}
	
	public void setFontName (String p_name) throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		bareSpreadSheetCellInXPropertySet.setPropertyValue ("CharFontName", p_name);
	}
	
	public float getFontSize () throws UnknownPropertyException, WrappedTargetException {
		return ((Float) bareSpreadSheetCellInXPropertySet.getPropertyValue ("CharHeight")).floatValue ();
	}
	
	public void setFontSize (float p_size) throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		bareSpreadSheetCellInXPropertySet.setPropertyValue ("CharHeight", new Float (p_size));
	}
	
	public FontSlant getFontPosture () throws UnknownPropertyException, WrappedTargetException {
		return (FontSlant) bareSpreadSheetCellInXPropertySet.getPropertyValue ("CharPosture");
	}
	
	// com.sun.star.awt.FontSlant.(NONE, OBLIQUE, ITALIC, DONTKNOW, REVERSE_OBLIQUE, or REVERSE_ITALIC)
	public void setFontPosture (FontSlant p_style) throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		bareSpreadSheetCellInXPropertySet.setPropertyValue ("CharPosture", p_style);
	}
	
	public float getFontWeight () throws UnknownPropertyException, WrappedTargetException {
		return ((Float) bareSpreadSheetCellInXPropertySet.getPropertyValue ("CharWeight")).floatValue ();
	}
	
	// com.sun.star.awt.FontWeight.(DONTKNOW, THIN, ULTRALIGHT, LIGHT, SEMILIGHT, NORMAL, SEMIBOLD, BOLD, ULTRABOLD, or BLACK)
	public void setFontWeight (float p_weight) throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		bareSpreadSheetCellInXPropertySet.setPropertyValue ("CharWeight", new Float (p_weight));
	}
	
	public short getUnderLineStyle () throws UnknownPropertyException, WrappedTargetException {
		return ((Short) bareSpreadSheetCellInXPropertySet.getPropertyValue ("CharUnderline")).shortValue ();
	}
	
	public int getUnderLineColor () throws UnknownPropertyException, WrappedTargetException {
		return ((Integer) bareSpreadSheetCellInXPropertySet.getPropertyValue ("CharUnderlineColor")).intValue ();
	}
	
	// com.sun.star.awt.FontUnderline.(NONE, SINGLE, DOUBLE, DOTTED, DONTKNOW, DASH, LONGDASH, DASHDOT, DASHDOTDOT, SMALLWAVE, WAVE, DOUBLEWAVE, BOLD, BOLDDOTTED, BOLDDASH, BOLDLONGDASH, BOLDDASHDOT, BOLDDASHDOTDOT, BOLDWAVE)
	public void setUnderLine (short p_style, int p_pixelValue) throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		bareSpreadSheetCellInXPropertySet.setPropertyValue ("CharUnderline", new Short (p_style));
		bareSpreadSheetCellInXPropertySet.setPropertyValue ("CharUnderlineHasColor", p_pixelValue != -1 ? new Boolean (true): new Boolean (false));
		bareSpreadSheetCellInXPropertySet.setPropertyValue ("CharUnderlineColor", new Integer (p_pixelValue));
	}
	
	public void removeUnderLine () throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		bareSpreadSheetCellInXPropertySet.setPropertyValue ("CharUnderline",FontUnderline.NONE);
		bareSpreadSheetCellInXPropertySet.setPropertyValue ("CharUnderlineHasColor", new Boolean (false));
		bareSpreadSheetCellInXPropertySet.setPropertyValue ("CharUnderlineColor", new Integer (-1));
	}
	
	public short getOverLineStyle () throws UnknownPropertyException, WrappedTargetException {
		return ((Short) bareSpreadSheetCellInXPropertySet.getPropertyValue ("CharOverline")).shortValue ();
	}
	
	public int getOverLineColor () throws UnknownPropertyException, WrappedTargetException {
		return ((Integer) bareSpreadSheetCellInXPropertySet.getPropertyValue ("CharOverlineColor")).intValue ();
	}
	
	// com.sun.star.awt.FontUnderline.(NONE, SINGLE, DOUBLE, DOTTED, DONTKNOW, DASH, LONGDASH, DASHDOT, DASHDOTDOT, SMALLWAVE, WAVE, DOUBLEWAVE, BOLD, BOLDDOTTED, BOLDDASH, BOLDLONGDASH, BOLDDASHDOT, BOLDDASHDOTDOT, BOLDWAVE)
	public void setOverLine (short p_style, int p_pixelValue) throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		bareSpreadSheetCellInXPropertySet.setPropertyValue ("CharOverline", new Short (p_style));
		bareSpreadSheetCellInXPropertySet.setPropertyValue ("CharOverlineHasColor", p_pixelValue != -1 ? new Boolean (true): new Boolean (false));
		bareSpreadSheetCellInXPropertySet.setPropertyValue ("CharOverlineColor", new Integer (p_pixelValue));
	}
	
	public void removeOverLine () throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		bareSpreadSheetCellInXPropertySet.setPropertyValue ("CharOverline",FontUnderline.NONE);
		bareSpreadSheetCellInXPropertySet.setPropertyValue ("CharOverlineHasColor", new Boolean (false));
		bareSpreadSheetCellInXPropertySet.setPropertyValue ("CharOverlineColor", new Integer (-1));
	}
	
	public short getStrikeOutStyle () throws UnknownPropertyException, WrappedTargetException {
		return ((Short) bareSpreadSheetCellInXPropertySet.getPropertyValue ("CharStrikeout")).shortValue ();
	}
	
	// com.sun.star.awt.FontStrikeout.(NONE, SINGLE, DOUBLE, DONTKNOW, BOLD, SLASH, or X)
	public void setStrikeOut (short p_style) throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		bareSpreadSheetCellInXPropertySet.setPropertyValue ("CharStrikeout", new Short (p_style));
	}
	
	public void removeStrikeOut () throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		bareSpreadSheetCellInXPropertySet.setPropertyValue ("CharStrikeout", FontStrikeout.NONE);
	}
	
	public boolean getWrappedFlag () throws UnknownPropertyException, WrappedTargetException {
		return ((Boolean) bareSpreadSheetCellInXPropertySet.getPropertyValue ("IsTextWrapped")).booleanValue ();
	}
	
	public void setWrapped (boolean p_isWrapped) throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		bareSpreadSheetCellInXPropertySet.setPropertyValue ("IsTextWrapped", new Boolean (p_isWrapped));
	}
	
	public CellHoriJustify getHorizontalAlignmentStyle () throws UnknownPropertyException, WrappedTargetException {
		return (CellHoriJustify) bareSpreadSheetCellInXPropertySet.getPropertyValue ("HoriJustify");
	}
	
	// com.sun.star.table.CellHoriJustify.(STANDARD, LEFT, CENTER, RIGHT, BLOCK, REPEAT)
	public void setHorizontalAlignment (CellHoriJustify p_style) throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		bareSpreadSheetCellInXPropertySet.setPropertyValue ("HoriJustify", p_style);
	}
	
	public int getVerticalAlignmentStyle () throws UnknownPropertyException, WrappedTargetException {
		return ((Integer) bareSpreadSheetCellInXPropertySet.getPropertyValue ("VertJustify")).intValue ();
	}
	
	// com.sun.star.table.CellVertJustify2.(STANDARD, TOP, CENTER, BOTTOM, or BLOCK)
	public void setVerticalAlignment (int p_style) throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		bareSpreadSheetCellInXPropertySet.setPropertyValue ("VertJustify", new Integer (p_style));
	}
	
	public short getLeftBorderStyle () throws UnknownPropertyException, WrappedTargetException {
		BorderLine2 l_borderline = (BorderLine2) bareSpreadSheetCellInXPropertySet.getPropertyValue ("LeftBorder2");
		return l_borderline.LineStyle;
	}
	
	public int getLeftBorderWidth () throws UnknownPropertyException, WrappedTargetException {
		BorderLine2 l_borderline = (BorderLine2) bareSpreadSheetCellInXPropertySet.getPropertyValue ("LeftBorder2");
		return l_borderline.LineWidth;
	}
	
	public int getLeftBorderColor () throws UnknownPropertyException, WrappedTargetException {
		BorderLine2 l_borderline = (BorderLine2) bareSpreadSheetCellInXPropertySet.getPropertyValue ("LeftBorder2");
		return l_borderline.Color;
	}
	
	// com.sun.star.table.BorderLineStyle.(NONE, SOLID, DOTTED, DASHED, DOUBLE, THINTHICK_SMALLGAP, THINTHICK_MEDIUMGAP, THINTHICK_LARGEGAP, THICKTHIN_SMALLGAP, THICKTHIN_MEDIUMGAP, THICKTHIN_LARGEGAP, EMBOSSED, ENGRAVED, OUTSET, INSET, FINE_DASHED, DOUBLE_THIN, DASH_DOT, DASH_DOT_DOT, or BORDER_LINE_STYLE_MAX)
	public void setLeftBorder (short p_style, int p_width, int p_color) throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		BorderLine2 l_borderline = new BorderLine2 ();
		l_borderline.LineStyle = p_style;
		l_borderline.LineWidth = p_width;
		l_borderline.Color = p_color;
		bareSpreadSheetCellInXPropertySet.setPropertyValue ("LeftBorder2", l_borderline);
	}
	
	public void removeLeftBorder () throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		BorderLine2 l_borderline = new BorderLine2 ();
		l_borderline.LineStyle =BorderLineStyle.NONE;
		l_borderline.LineWidth = 0;
		l_borderline.Color = -1;
		bareSpreadSheetCellInXPropertySet.setPropertyValue ("LeftBorder2", l_borderline);
	}
	
	public short getRightBorderStyle () throws UnknownPropertyException, WrappedTargetException {
		BorderLine2 l_borderline = (BorderLine2) bareSpreadSheetCellInXPropertySet.getPropertyValue ("RightBorder2");
		return l_borderline.LineStyle;
	}
	
	public int getRightBorderWidth () throws UnknownPropertyException, WrappedTargetException {
		BorderLine2 l_borderline = (BorderLine2) bareSpreadSheetCellInXPropertySet.getPropertyValue ("RightBorder2");
		return l_borderline.LineWidth;
	}
	
	public int getRightBorderColor () throws UnknownPropertyException, WrappedTargetException {
		BorderLine2 l_borderline = (BorderLine2) bareSpreadSheetCellInXPropertySet.getPropertyValue ("RightBorder2");
		return l_borderline.Color;
	}
	
	// com.sun.star.table.BorderLineStyle.(NONE, SOLID, DOTTED, DASHED, DOUBLE, THINTHICK_SMALLGAP, THINTHICK_MEDIUMGAP, THINTHICK_LARGEGAP, THICKTHIN_SMALLGAP, THICKTHIN_MEDIUMGAP, THICKTHIN_LARGEGAP, EMBOSSED, ENGRAVED, OUTSET, INSET, FINE_DASHED, DOUBLE_THIN, DASH_DOT, DASH_DOT_DOT, or BORDER_LINE_STYLE_MAX)
	public void setRightBorder (short p_style, int p_width, int p_color) throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		BorderLine2 l_borderline = new BorderLine2 ();
		l_borderline.LineStyle = p_style;
		l_borderline.LineWidth = p_width;
		l_borderline.Color = p_color;
		bareSpreadSheetCellInXPropertySet.setPropertyValue ("RightBorder2", l_borderline);
	}
	
	public void removeRightBorder () throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		BorderLine2 l_borderline = new BorderLine2 ();
		l_borderline.LineStyle = BorderLineStyle.NONE;
		l_borderline.LineWidth = 0;
		l_borderline.Color = -1;
		bareSpreadSheetCellInXPropertySet.setPropertyValue ("RightBorder2", l_borderline);
	}
	
	public short getTopBorderStyle () throws UnknownPropertyException, WrappedTargetException {
		BorderLine2 l_borderline = (BorderLine2) bareSpreadSheetCellInXPropertySet.getPropertyValue ("TopBorder2");
		return l_borderline.LineStyle;
	}
	
	public int getTopBorderWidth () throws UnknownPropertyException, WrappedTargetException {
		BorderLine2 l_borderline = (BorderLine2) bareSpreadSheetCellInXPropertySet.getPropertyValue ("TopBorder2");
		return l_borderline.LineWidth;
	}
	
	public int getTopBorderColor () throws UnknownPropertyException, WrappedTargetException {
		BorderLine2 l_borderline = (BorderLine2) bareSpreadSheetCellInXPropertySet.getPropertyValue ("TopBorder2");
		return l_borderline.Color;
	}
	
	// com.sun.star.table.BorderLineStyle.(NONE, SOLID, DOTTED, DASHED, DOUBLE, THINTHICK_SMALLGAP, THINTHICK_MEDIUMGAP, THINTHICK_LARGEGAP, THICKTHIN_SMALLGAP, THICKTHIN_MEDIUMGAP, THICKTHIN_LARGEGAP, EMBOSSED, ENGRAVED, OUTSET, INSET, FINE_DASHED, DOUBLE_THIN, DASH_DOT, DASH_DOT_DOT, or BORDER_LINE_STYLE_MAX)
	public void setTopBorder (short p_style, int p_width, int p_color) throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		BorderLine2 l_borderline = new BorderLine2 ();
		l_borderline.LineStyle = p_style;
		l_borderline.LineWidth = p_width;
		l_borderline.Color = p_color;
		bareSpreadSheetCellInXPropertySet.setPropertyValue ("TopBorder2", l_borderline);
	}
	
	public void removeTopBorder () throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		BorderLine2 l_borderline = new BorderLine2 ();
		l_borderline.LineStyle = BorderLineStyle.NONE;
		l_borderline.LineWidth = 0;
		l_borderline.Color = -1;
		bareSpreadSheetCellInXPropertySet.setPropertyValue ("TopBorder2", l_borderline);
	}
	
	public short getBottomBorderStyle () throws UnknownPropertyException, WrappedTargetException {
		BorderLine2 l_borderline = (BorderLine2) bareSpreadSheetCellInXPropertySet.getPropertyValue ("BottomBorder2");
		//thebiasplanet.coreutilities.messaging.Publisher.show (String.format ("Border: %d, %d, %d, %d, %d", l_borderline.LineStyle, l_borderline.InnerLineWidth, l_borderline.OuterLineWidth, l_borderline.LineDistance, l_borderline.LineWidth));
		return l_borderline.LineStyle;
	}
	
	public int getBottomBorderWidth () throws UnknownPropertyException, WrappedTargetException {
		BorderLine2 l_borderline = (BorderLine2) bareSpreadSheetCellInXPropertySet.getPropertyValue ("BottomBorder2");
		return l_borderline.LineWidth;
	}
	
	public int getBottomBorderColor () throws UnknownPropertyException, WrappedTargetException {
		BorderLine2 l_borderline = (BorderLine2) bareSpreadSheetCellInXPropertySet.getPropertyValue ("BottomBorder2");
		return l_borderline.Color;
	}
	
	// com.sun.star.table.BorderLineStyle.(NONE, SOLID, DOTTED, DASHED, DOUBLE, THINTHICK_SMALLGAP, THINTHICK_MEDIUMGAP, THINTHICK_LARGEGAP, THICKTHIN_SMALLGAP, THICKTHIN_MEDIUMGAP, THICKTHIN_LARGEGAP, EMBOSSED, ENGRAVED, OUTSET, INSET, FINE_DASHED, DOUBLE_THIN, DASH_DOT, DASH_DOT_DOT, or BORDER_LINE_STYLE_MAX)
	public void setBottomBorder (short p_style, int p_width, int p_color) throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		BorderLine2 l_borderline = new BorderLine2 ();
		l_borderline.LineStyle = p_style;
		l_borderline.LineWidth = p_width;
		l_borderline.Color = p_color;
		bareSpreadSheetCellInXPropertySet.setPropertyValue ("BottomBorder2", l_borderline);
	}
	
	public void removeBottomBorder () throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		BorderLine2 l_borderline = new BorderLine2 ();
		l_borderline.LineStyle = BorderLineStyle.NONE;
		l_borderline.LineWidth = 0;
		l_borderline.Color = -1;
		bareSpreadSheetCellInXPropertySet.setPropertyValue ("BottomBorder2", l_borderline);
	}
}
