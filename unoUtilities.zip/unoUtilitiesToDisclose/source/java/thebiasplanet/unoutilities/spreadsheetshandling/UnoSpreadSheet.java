package thebiasplanet.unoutilities.spreadsheetshandling;

import com.sun.star.lang.WrappedTargetException;
import com.sun.star.uno.XComponentContext;
import com.sun.star.uno.UnoRuntime;
import com.sun.star.sheet.XSpreadsheet;
import com.sun.star.sheet.XCellRangeMovement;
import com.sun.star.sheet.CellInsertMode;
import com.sun.star.sheet.CellDeleteMode;
import com.sun.star.container.XNamed;
import com.sun.star.container.XIndexAccess;
import com.sun.star.table.CellRangeAddress;

public class UnoSpreadSheet {
	private UnoSpreadSheetsDocument spreadSheetDocument = null;
	private XSpreadsheet bareSpreadSheetInXSpreadsheet = null;
	private XNamed bareSpreadSheetInXNamed = null;
	private XCellRangeMovement bareSpreadSheetInXCellRangeMovement = null;
	
	public static UnoSpreadSheet getCurrentSpreadSheet (XComponentContext p_componentContextInXComponentContext) throws Exception {
		UnoSpreadSheetsDocument l_currentSpreadSheetDocument = UnoSpreadSheetsDocument.getCurrentSpreadSheetsDocument (p_componentContextInXComponentContext);
		return new UnoSpreadSheet (l_currentSpreadSheetDocument, l_currentSpreadSheetDocument.getControllerInXSpreadsheetView ().getActiveSheet ());
	}
	
	public UnoSpreadSheet (UnoSpreadSheetsDocument p_spreadSheetDocument, XSpreadsheet p_bareSpreadSheetInXSpreadsheet) throws Exception {
		if (p_spreadSheetDocument == null) {
			throw new Exception ("The spread sheet document is null.");
		}
		spreadSheetDocument = p_spreadSheetDocument;
		if (p_bareSpreadSheetInXSpreadsheet == null) {
			throw new Exception ("The bare spread sheet is null.");
		}
		bareSpreadSheetInXSpreadsheet = p_bareSpreadSheetInXSpreadsheet;
		bareSpreadSheetInXNamed = (XNamed) UnoRuntime.queryInterface (XNamed.class, bareSpreadSheetInXSpreadsheet);
		bareSpreadSheetInXCellRangeMovement = (XCellRangeMovement) UnoRuntime.queryInterface (XCellRangeMovement.class, bareSpreadSheetInXSpreadsheet);
	}
	
	public UnoSpreadSheetsDocument getSpreadSheetDocument () {
		return spreadSheetDocument;
	}
	
	public XSpreadsheet getBareSpreadSheetInXSpreadsheet () {
		return bareSpreadSheetInXSpreadsheet;
	}
	
	public UnoSpreadSheetCell getSpreadSheetCell (int p_cellRowIndex, int p_cellColumnIndex) throws com.sun.star.lang.IndexOutOfBoundsException {
		return new UnoSpreadSheetCell (this, bareSpreadSheetInXSpreadsheet.getCellByPosition (p_cellColumnIndex, p_cellRowIndex));
	}
	
	public String getSpreadSheetName () {
		return bareSpreadSheetInXNamed.getName ();
	}
	
	public int getSpreadSheetIndex () throws com.sun.star.lang.IndexOutOfBoundsException, WrappedTargetException {
		XIndexAccess l_spreadSheetsInXIndexAccess = UnoRuntime.queryInterface (XIndexAccess.class, spreadSheetDocument.getSpreadSheetsInXSpreadsheets ());
		int l_spreadSheetsCount = l_spreadSheetsInXIndexAccess.getCount ();
		String l_spreadSheetName = getSpreadSheetName ();
		XNamed l_bareSpreadSheetInXNamed = null;
		int l_spreadSheetIndex = 0;
		for (; l_spreadSheetIndex < l_spreadSheetsCount; l_spreadSheetIndex ++) {
			l_bareSpreadSheetInXNamed = UnoRuntime.queryInterface (XNamed.class, l_spreadSheetsInXIndexAccess.getByIndex (l_spreadSheetIndex));
			if (l_spreadSheetName.equals (l_bareSpreadSheetInXNamed.getName ())) {
				break;
			}
		}
		if (l_spreadSheetIndex < l_spreadSheetsCount) {
			return l_spreadSheetIndex;
		}
		else {
			return -1;
		}
	}
	
	public void insertRows (int p_startRowIndex, int p_endRowIndex) throws com.sun.star.lang.IndexOutOfBoundsException, WrappedTargetException {
		CellRangeAddress l_cellsRangeAddress = new CellRangeAddress ();
		l_cellsRangeAddress.Sheet = (short) getSpreadSheetIndex ();
		l_cellsRangeAddress.StartRow = p_startRowIndex;
		l_cellsRangeAddress.EndRow = p_endRowIndex;
		bareSpreadSheetInXCellRangeMovement.insertCells (l_cellsRangeAddress, CellInsertMode.ROWS);
	}
	
	public void insertColumns (int p_startColumnIndex, int p_endColumnIndex) throws com.sun.star.lang.IndexOutOfBoundsException, WrappedTargetException {
		CellRangeAddress l_cellsRangeAddress = new CellRangeAddress ();
		l_cellsRangeAddress.Sheet = (short) getSpreadSheetIndex ();
		l_cellsRangeAddress.StartColumn = p_startColumnIndex;
		l_cellsRangeAddress.EndColumn = p_endColumnIndex;
		bareSpreadSheetInXCellRangeMovement.insertCells (l_cellsRangeAddress, CellInsertMode.COLUMNS);
	}
	
	public void removeRows (int p_startRowIndex, int p_endRowIndex) throws com.sun.star.lang.IndexOutOfBoundsException, WrappedTargetException {
		CellRangeAddress l_cellsRangeAddress = new CellRangeAddress ();
		l_cellsRangeAddress.Sheet = (short) getSpreadSheetIndex ();
		l_cellsRangeAddress.StartRow = p_startRowIndex;
		l_cellsRangeAddress.EndRow = p_endRowIndex;
		bareSpreadSheetInXCellRangeMovement.removeRange (l_cellsRangeAddress, CellDeleteMode.ROWS);
	}
	
	public void removeColumns (int p_startColumnIndex, int p_endColumnIndex) throws com.sun.star.lang.IndexOutOfBoundsException, WrappedTargetException {
		CellRangeAddress l_cellsRangeAddress = new CellRangeAddress ();
		l_cellsRangeAddress.Sheet = (short) getSpreadSheetIndex ();
		l_cellsRangeAddress.StartColumn = p_startColumnIndex;
		l_cellsRangeAddress.EndColumn = p_endColumnIndex;
		bareSpreadSheetInXCellRangeMovement.removeRange (l_cellsRangeAddress, CellDeleteMode.COLUMNS);
	}
}

