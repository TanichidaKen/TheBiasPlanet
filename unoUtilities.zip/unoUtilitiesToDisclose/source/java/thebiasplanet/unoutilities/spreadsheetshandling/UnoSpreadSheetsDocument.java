package thebiasplanet.unoutilities.spreadsheetshandling;

import java.util.Map;
import java.util.HashMap;
import com.sun.star.lang.Locale;
import com.sun.star.lang.WrappedTargetException;
import com.sun.star.frame.XDesktop;
import com.sun.star.frame.XModel;
import com.sun.star.frame.FrameSearchFlag;
import com.sun.star.frame.XStorable;
import com.sun.star.frame.XComponentLoader;
import com.sun.star.uno.XComponentContext;
import com.sun.star.uno.UnoRuntime;
import com.sun.star.sheet.XSpreadsheetDocument;
import com.sun.star.sheet.XSpreadsheets;
import com.sun.star.sheet.XSpreadsheet;
import com.sun.star.sheet.XSpreadsheetView;
import com.sun.star.util.XNumberFormatsSupplier;
import com.sun.star.util.XNumberFormats;
import com.sun.star.util.MalformedNumberFormatException;
import com.sun.star.util.XCloseable;
import com.sun.star.util.CloseVetoException;
import com.sun.star.beans.XPropertySet;
import com.sun.star.beans.PropertyValue;
import com.sun.star.beans.UnknownPropertyException;
import com.sun.star.container.NoSuchElementException;
import thebiasplanet.unoutilities.serviceshandling.UnoServiceHandler;

public class UnoSpreadSheetsDocument {
	private XSpreadsheetDocument bareSpreadSheetDocumentInXSpreadsheetDocument = null;
	private XStorable bareSpreadSheetDocumentInXStorable = null;
	private XModel bareSpreadSheetDocumentInXModel = null;
	private XSpreadsheetView controllerInXSpreadsheetView = null;
	private XSpreadsheets spreadSheetsInXSpreadsheets = null;
	private Locale defaultLocale = null;
	private XNumberFormats cellValueExpressionFormatsInXNumberFormats = null;
	private int dateExpressionFormatKey = -1;
	private int timeExpressionFormatKey = -1;
	private int dateTimeExpressionFormatKey = -1;
	private int booleanExpressionFormatKey = -1;
	private int stringExpressionFormatKey = -1;
	private int integerExpressionFormatKey = -1;
	private Map <Integer, Integer> numberOfDecimalPlacesToDoubleExpressionFormatKeyMap = null;
	private Map <Integer, Integer> doubleExpressionFormatKeyToNumberOfDecimalPlacesMap = null;
	
	private int getAndSetIfNecessaryCellValueExpressionFormatKey (String l_formatString) throws MalformedNumberFormatException {
		int l_formatKey = cellValueExpressionFormatsInXNumberFormats.queryKey (l_formatString, defaultLocale, false);
		if (l_formatKey == -1) {
			l_formatKey = cellValueExpressionFormatsInXNumberFormats.addNew (l_formatString, defaultLocale);
		}
		return l_formatKey;
	}
	
	private static UnoSpreadSheetsDocument createSpreadSheetsDocumentOrOpenSpreadSheetsDocumentFile (XComponentContext p_componentContextInXComponentContext, String p_fileUrl) throws Exception, com.sun.star.io.IOException {
		XComponentLoader l_desktopInXComponentLoader = (XComponentLoader) UnoServiceHandler.getServiceInstance (p_componentContextInXComponentContext, "com.sun.star.frame.Desktop", XComponentLoader.class);
		PropertyValue [] l_loadProperties = new PropertyValue [0];
		return new UnoSpreadSheetsDocument ((XSpreadsheetDocument) UnoRuntime.queryInterface (XSpreadsheetDocument.class, l_desktopInXComponentLoader.loadComponentFromURL (p_fileUrl, "_blank", FrameSearchFlag.CREATE, l_loadProperties)));
	}
	
	public static UnoSpreadSheetsDocument createSpreadSheetsDocument (XComponentContext p_componentContextInXComponentContext) throws Exception, com.sun.star.io.IOException {
		return createSpreadSheetsDocumentOrOpenSpreadSheetsDocumentFile (p_componentContextInXComponentContext, "private:factory/scalc");
	}
	
	public static UnoSpreadSheetsDocument openSpreadSheetsDocumentFile (XComponentContext p_componentContextInXComponentContext, String p_fileUrl) throws Exception, com.sun.star.io.IOException {
		return createSpreadSheetsDocumentOrOpenSpreadSheetsDocumentFile (p_componentContextInXComponentContext, p_fileUrl);
	}
	
	public static UnoSpreadSheetsDocument getCurrentSpreadSheetsDocument (XComponentContext p_componentContextInXComponentContext) throws Exception {
		XDesktop l_desktopInXDesktop = (XDesktop) UnoServiceHandler.getServiceInstance (p_componentContextInXComponentContext,    "com.sun.star.frame.Desktop", XDesktop.class);
		return new UnoSpreadSheetsDocument ( (XSpreadsheetDocument) UnoRuntime.queryInterface (XSpreadsheetDocument.class, l_desktopInXDesktop.getCurrentComponent ()));
	}
	
	public UnoSpreadSheetsDocument (XSpreadsheetDocument p_bareSpreadSheetDocumentInXSpreadsheetDocument) throws Exception, MalformedNumberFormatException {
		if (p_bareSpreadSheetDocumentInXSpreadsheetDocument == null) {
			throw new Exception ("The bare spread sheet document is null.");
		}
		bareSpreadSheetDocumentInXSpreadsheetDocument = p_bareSpreadSheetDocumentInXSpreadsheetDocument;
		defaultLocale = new Locale ();
		String l_dateExpressionFormatString = "YYYY-MM-DD";
		String l_timeExpressionFormatString = "HH:MM:SS";
		String l_dateTimeExpressionFormatString = "YYYY-MM-DD\"T\"HH:MM:SS";
		String l_booleanExpressionFormatString = "BOOLEAN";
		String l_stringExpressionFormatString = "@";
		String l_integerExpressionFormatString = "0";
		String l_doubleDefaultExpressionFormatString = "Global";
		XNumberFormatsSupplier l_bareSpreadSheetDocumentInXNumberFormatsSupplier = UnoRuntime.queryInterface (XNumberFormatsSupplier.class, bareSpreadSheetDocumentInXSpreadsheetDocument);
		cellValueExpressionFormatsInXNumberFormats = l_bareSpreadSheetDocumentInXNumberFormatsSupplier.getNumberFormats ();
		dateExpressionFormatKey = getAndSetIfNecessaryCellValueExpressionFormatKey (l_dateExpressionFormatString);
		timeExpressionFormatKey = getAndSetIfNecessaryCellValueExpressionFormatKey (l_timeExpressionFormatString);
		dateTimeExpressionFormatKey = getAndSetIfNecessaryCellValueExpressionFormatKey (l_dateTimeExpressionFormatString);
		booleanExpressionFormatKey = getAndSetIfNecessaryCellValueExpressionFormatKey (l_booleanExpressionFormatString);
		stringExpressionFormatKey = getAndSetIfNecessaryCellValueExpressionFormatKey (l_stringExpressionFormatString);
		integerExpressionFormatKey = getAndSetIfNecessaryCellValueExpressionFormatKey (l_integerExpressionFormatString);
		numberOfDecimalPlacesToDoubleExpressionFormatKeyMap = new HashMap <Integer, Integer> ();
		doubleExpressionFormatKeyToNumberOfDecimalPlacesMap = new HashMap <Integer, Integer> ();
		int l_doubleDefaultExpressionFormatKey = -1;
		l_doubleDefaultExpressionFormatKey = cellValueExpressionFormatsInXNumberFormats.queryKey (l_doubleDefaultExpressionFormatString, defaultLocale, false);
		if (l_doubleDefaultExpressionFormatKey == -1) {
			l_doubleDefaultExpressionFormatString = "Standard";
			l_doubleDefaultExpressionFormatKey = cellValueExpressionFormatsInXNumberFormats.queryKey (l_doubleDefaultExpressionFormatString, defaultLocale, false);
		}
		if (l_doubleDefaultExpressionFormatKey == -1) {
			// Doesn't seem possible
		}
		else {
			Integer l_defaultNumberOfDecimalPlaces = new Integer (-1);
			Integer l_doubleDefaultExpressionFormatKeyInInteger = new Integer (l_doubleDefaultExpressionFormatKey);
			numberOfDecimalPlacesToDoubleExpressionFormatKeyMap.put (l_defaultNumberOfDecimalPlaces, l_doubleDefaultExpressionFormatKeyInInteger);
			doubleExpressionFormatKeyToNumberOfDecimalPlacesMap.put (l_doubleDefaultExpressionFormatKeyInInteger, l_defaultNumberOfDecimalPlaces);
		}
		bareSpreadSheetDocumentInXModel = (XModel) UnoRuntime.queryInterface (XModel.class, bareSpreadSheetDocumentInXSpreadsheetDocument);
		bareSpreadSheetDocumentInXStorable = (XStorable) UnoRuntime.queryInterface (XStorable.class, bareSpreadSheetDocumentInXSpreadsheetDocument);
		controllerInXSpreadsheetView = (XSpreadsheetView) UnoRuntime.queryInterface (XSpreadsheetView.class, bareSpreadSheetDocumentInXModel.getCurrentController ());
		spreadSheetsInXSpreadsheets = bareSpreadSheetDocumentInXSpreadsheetDocument.getSheets ();
	}
	
	public XSpreadsheetDocument getBareSpreadSheetDocumentInXSpreadsheetDocument () {
		return bareSpreadSheetDocumentInXSpreadsheetDocument;
	}
	
	public XModel getBareSpreadSheetDocumentinXModel () {
		return bareSpreadSheetDocumentInXModel;
	}
	
	public XSpreadsheets getSpreadSheetsInXSpreadsheets () {
		return spreadSheetsInXSpreadsheets;
	}
	
	public int getDateExpressionFormatKey () {
		return dateExpressionFormatKey;
	}
	
	public int getTimeExpressionFormatKey () {
		return timeExpressionFormatKey;
	}
	
	public int getDateTimeExpressionFormatKey () {
		return dateTimeExpressionFormatKey;
	}
	
	public int getBooleanExpressionFormatKey () {
		return booleanExpressionFormatKey;
	}
	
	public int getStringExpressionFormatKey () {
		return stringExpressionFormatKey;
	}
	
	public int getIntegerExpressionFormatKey () {
		return integerExpressionFormatKey;
	}
	
	// p_numberOfDecimalPlaces: -1 for automatic number of decimal places
	public int getDoubleExpressionFormatKey (int p_numberOfDecimalPlaces) throws MalformedNumberFormatException {
		Integer l_numberOfDecimalPlacesInInteger = new Integer (p_numberOfDecimalPlaces);
		Integer l_doubleExpressionFormatKeyInInteger = numberOfDecimalPlacesToDoubleExpressionFormatKeyMap.get (l_numberOfDecimalPlacesInInteger);
		int l_doubleExpressionFormatKey = -1;
		if (l_doubleExpressionFormatKeyInInteger == null) {
			String l_doubleExpressionFormatString = String.format (String.format ("%%.%df", p_numberOfDecimalPlaces), 0.0);
			l_doubleExpressionFormatKey = getAndSetIfNecessaryCellValueExpressionFormatKey (l_doubleExpressionFormatString);
			l_doubleExpressionFormatKeyInInteger = new Integer (l_doubleExpressionFormatKey);
			numberOfDecimalPlacesToDoubleExpressionFormatKeyMap.put (l_numberOfDecimalPlacesInInteger, l_doubleExpressionFormatKeyInInteger);
			doubleExpressionFormatKeyToNumberOfDecimalPlacesMap.put (l_doubleExpressionFormatKeyInInteger, l_numberOfDecimalPlacesInInteger);
		}
		else {
			l_doubleExpressionFormatKey = l_doubleExpressionFormatKeyInInteger.intValue ();
		}
		return l_doubleExpressionFormatKey;
	}
	
	public int getNumberOfDecimalPlaces (int p_cellValueExpressionFormatKey) throws UnknownPropertyException, WrappedTargetException {
		Integer l_cellValueExpressionFormatKeyInInteger = new Integer (p_cellValueExpressionFormatKey);
		Integer l_numberOfDecimalPlacesInInteger = doubleExpressionFormatKeyToNumberOfDecimalPlacesMap.get (l_cellValueExpressionFormatKeyInInteger);
		int l_numberOfDecimalPlaces = -1;
		if (l_numberOfDecimalPlacesInInteger != null) {
			l_numberOfDecimalPlaces = l_numberOfDecimalPlacesInInteger.intValue ();
		}
		else {
			XPropertySet l_cellValueExpressionFormatPropertiesSetInXPropertySet = cellValueExpressionFormatsInXNumberFormats.getByKey (p_cellValueExpressionFormatKey);
			if (l_cellValueExpressionFormatPropertiesSetInXPropertySet != null) {
				String l_formatString = (String) l_cellValueExpressionFormatPropertiesSetInXPropertySet.getPropertyValue ("FormatString");
				if (l_formatString.equals ("Global") || l_formatString.equals ("Standard")) {
					l_numberOfDecimalPlaces = -1;
				}
				else {
					int l_periodIndex = -1;
					l_periodIndex = l_formatString.lastIndexOf ('.');
					if (l_periodIndex == -1) {
						l_numberOfDecimalPlaces = -1;
					}
					else {
						int l_formatStringLength = l_formatString.length ();
						l_numberOfDecimalPlaces = 0;
						for (int l_characterIndex = l_periodIndex + 1; l_characterIndex < l_formatStringLength; l_characterIndex ++) {
							if (l_formatString.charAt (l_characterIndex) != '0') {
								break;
							}
							else {
								l_numberOfDecimalPlaces ++;
							}
						}
						l_numberOfDecimalPlacesInInteger = new Integer (l_numberOfDecimalPlaces);
						numberOfDecimalPlacesToDoubleExpressionFormatKeyMap.put (l_numberOfDecimalPlacesInInteger, l_cellValueExpressionFormatKeyInInteger);
						doubleExpressionFormatKeyToNumberOfDecimalPlacesMap.put (l_cellValueExpressionFormatKeyInInteger, l_numberOfDecimalPlacesInInteger);
					}
				}
			}
			else {
				l_numberOfDecimalPlaces = -1;
			}
		}
		return l_numberOfDecimalPlaces;
	}
	
	public XSpreadsheetView getControllerInXSpreadsheetView () {
		return controllerInXSpreadsheetView;
	}
	
	public void store () throws com.sun.star.io.IOException {
		bareSpreadSheetDocumentInXStorable.store ();
	}
	
	public void storeAtUrl (String p_fileUrl) throws com.sun.star.io.IOException {
		PropertyValue [] l_loadProperties = new PropertyValue [0];
		bareSpreadSheetDocumentInXStorable.storeAsURL (p_fileUrl, l_loadProperties);
	}
	
	public void close () throws CloseVetoException {
		XCloseable l_bareSpreadSheetDocumentXCloseable = (XCloseable) UnoRuntime.queryInterface(XCloseable.class, bareSpreadSheetDocumentInXSpreadsheetDocument);
		l_bareSpreadSheetDocumentXCloseable.close (false); 
	}
	
	public void insertSpreadSheet (String p_spreadSheetName, int p_spreadSheetIndex) {
		spreadSheetsInXSpreadsheets.insertNewByName (p_spreadSheetName, (short) p_spreadSheetIndex);
	}
	
	public void copySpreadSheet (String p_originalSpreadSheetName, String p_copiedSpreadSheetName, int p_copiedSpreadSheetIndex) {
		spreadSheetsInXSpreadsheets.copyByName (p_originalSpreadSheetName, p_copiedSpreadSheetName, (short) p_copiedSpreadSheetIndex);
	}
	
	public void removeSpreadSheet (String p_spreadSheetName) throws NoSuchElementException, WrappedTargetException {
		spreadSheetsInXSpreadsheets.removeByName (p_spreadSheetName);
	}
	
	public UnoSpreadSheet getSpreadSheet (String p_spreadSheetName) throws Exception, NoSuchElementException, WrappedTargetException {
		XSpreadsheet l_spreadSheetInXSpreadsheet = (XSpreadsheet) UnoRuntime.queryInterface(XSpreadsheet.class, spreadSheetsInXSpreadsheets.getByName (p_spreadSheetName));
		return new UnoSpreadSheet (this, l_spreadSheetInXSpreadsheet);
	}
	
	public void activateSpreadSheet (UnoSpreadSheet p_spreadSheet) throws NoSuchElementException {
		controllerInXSpreadsheetView.setActiveSheet (p_spreadSheet.getBareSpreadSheetInXSpreadsheet ());
	}
}
