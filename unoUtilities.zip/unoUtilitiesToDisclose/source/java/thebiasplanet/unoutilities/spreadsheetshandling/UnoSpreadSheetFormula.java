package thebiasplanet.unoutilities.spreadsheetshandling;

public class UnoSpreadSheetFormula {
	private String formulaString = null;
	private int cellValueExpressionFormatKey = -1;
	
	public UnoSpreadSheetFormula (String p_formulaString, int p_cellValueExpressionFormatKey) {
		formulaString = p_formulaString;
		cellValueExpressionFormatKey = p_cellValueExpressionFormatKey;
	}
	
	public String getFormulaString () {
		return formulaString;
	}
	
	public void setFormulaString (String p_formulaString) {
		formulaString = p_formulaString;
	}
	
	public int getCellValueExpressionFormatKey () {
		return cellValueExpressionFormatKey;
	}
	
	public void setCellValueExpressionFormatKey (int p_cellValueExpressionFormatKey) {
		cellValueExpressionFormatKey = p_cellValueExpressionFormatKey;
	}
	
	@Override
	public String toString () {
		return formulaString;
	}
}
