package thebiasplanet.unoutilities.serviceshandling;

import com.sun.star.uno.XComponentContext;
import com.sun.star.uno.UnoRuntime;
import com.sun.star.uno.XInterface;
import com.sun.star.uno.Type;
import com.sun.star.uno.TypeClass;

public final class UnoServiceHandler {
	private UnoServiceHandler () {
	}
	
	public static Object getServiceInstance (XComponentContext p_componentContextInXComponentContext, String p_serviceName, Class p_targetClass, Object[] p_arguments) throws com.sun.star.uno.Exception {
		Object l_serviceInstance = null;
		Object l_targetProxy = null;
		if (p_arguments == null) {
			l_serviceInstance = p_componentContextInXComponentContext.getServiceManager ().createInstanceWithContext (p_serviceName, p_componentContextInXComponentContext);
		}
		else {
			l_serviceInstance = p_componentContextInXComponentContext.getServiceManager ().createInstanceWithArgumentsAndContext (p_serviceName, p_arguments, p_componentContextInXComponentContext);
		}
		if (l_serviceInstance != null && p_targetClass != null && XInterface.class.isAssignableFrom(p_targetClass)) {
			l_targetProxy =  UnoRuntime.queryInterface (new Type (p_targetClass.getName (), TypeClass.INTERFACE), l_serviceInstance);
		}
		return l_targetProxy;
	}
	
	public static Object getServiceInstance (XComponentContext p_componentContextInXComponentContext, String p_serviceName, Class p_targetClass) throws com.sun.star.uno.Exception {
		return getServiceInstance (p_componentContextInXComponentContext, p_serviceName, p_targetClass, null);
	}
}
