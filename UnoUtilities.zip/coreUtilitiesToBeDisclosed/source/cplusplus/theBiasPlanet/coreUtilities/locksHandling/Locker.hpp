#ifndef __theBiasPlanet_coreUtilities_locksHandling_Locker_hpp__
#define __theBiasPlanet_coreUtilities_locksHandling_Locker_hpp__

#include <mutex>
#include "theBiasPlanet/coreUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"

using namespace ::std;

namespace theBiasPlanet {
	namespace coreUtilities {
		namespace locksHandling {
			class __theBiasPlanet_coreUtilities_symbolExportingOrImportingDeclarationForVisualCplusplus__ Locker {
				private:
					mutex * i_mutex;
				public:
					Locker (mutex * a_mutex);
					~Locker ();
			};
		}
	}
}

#endif

