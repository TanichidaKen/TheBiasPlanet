#include "theBiasPlanet/coreUtilities/constantsGroups/FileNameSuffixesConstantsGroup.hpp"

namespace theBiasPlanet {
	namespace coreUtilities {
		namespace constantsGroups {
			string const FileNameSuffixesConstantsGroup::c_xmlFileNameSuffix ("xml");
			string const FileNameSuffixesConstantsGroup::c_styleSheetFileNameSuffix ("xslt");
			string const FileNameSuffixesConstantsGroup::c_jarFileNameSuffix ("jar");
			string const FileNameSuffixesConstantsGroup::c_javaFileNameSuffix ("java");
			string const FileNameSuffixesConstantsGroup::c_saveFileNameSuffix ("save");
		}
	}
}

