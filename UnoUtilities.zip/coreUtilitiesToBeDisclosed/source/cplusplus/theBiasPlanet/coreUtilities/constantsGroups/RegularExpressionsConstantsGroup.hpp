#ifndef __theBiasPlanet_coreUtilities_constantsGroups_RegularExpressionsConstantsGroup_hpp__
#define __theBiasPlanet_coreUtilities_constantsGroups_RegularExpressionsConstantsGroup_hpp__

#include <regex>
#include <string>
#include "theBiasPlanet/coreUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"

using namespace ::std;

namespace theBiasPlanet {
	namespace coreUtilities {
		namespace constantsGroups {
			class __theBiasPlanet_coreUtilities_symbolExportingOrImportingDeclarationForVisualCplusplus__ RegularExpressionsConstantsGroup {
				public:
					static regex const c_cProgramTraceOutputLineRegularExpression;
					// nm is the name of a command
					static regex const c_nmOutputLineRegularExpression;
					// addr2line is the name of a command
					static regex const c_addr2lineOutputSecondLineRegularExpression;
					static regex const c_numbersRegularExpression;
					static regex const c_javaPackageDelimiterRegularExpression;
					static regex const c_windowsDirectoryDelimiterRegularExpression;
					static regex const c_wordRegularExpression;
					static regex const c_termRegularExpression;
					static regex const c_doubleQuotedTermRegularExpression;
			};
		}
	}
}

#endif

