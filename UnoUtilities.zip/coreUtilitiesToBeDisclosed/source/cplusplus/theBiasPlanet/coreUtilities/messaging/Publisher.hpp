#ifndef __theBiasPlanet_coreUtilities_messaging_Publisher_hpp__
#define __theBiasPlanet_coreUtilities_messaging_Publisher_hpp__

#include <optional>
#include <string>
#include "theBiasPlanet/coreUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"

#ifdef GCC
using namespace ::std;
#endif

namespace theBiasPlanet {
	namespace coreUtilities {
		namespace messaging {
			class __theBiasPlanet_coreUtilities_symbolExportingOrImportingDeclarationForVisualCplusplus__ Publisher {
				private:
					static int const c_processIdentification;
					// 0: error, 1: error and warning, 2: error, warning, and normal, 3: error, warning, normal, and debug
					static int s_loggingLevel;
					Publisher ();
				public:
					static int const & getLoggingLevel ();
					static void setLoggingLevel (int a_loggingLevel);
					static ::std::string getMessage (::std::string const & a_messageIngredient);
					static ::std::string show (::std::string const & a_messageIngredient);
					static ::std::optional <::std::string> logDebugInformation (::std::string const & a_messageIngredient);
					static ::std::optional <::std::string> logNormalInformation (::std::string const & a_messageIngredient);
					static ::std::optional <::std::string> logWarningInformation (::std::string const & a_messageIngredient);
					static ::std::optional <::std::string> logWarningInformation (::std::exception const & a_messageException);
					static ::std::optional <::std::string> logErrorInformation (::std::string const & a_messageIngredient);
					static ::std::optional <::std::string> logErrorInformation (::std::exception const & a_messageException);
					static void appendToFile (::std::string const & a_fileName, ::std::string const & a_contents);
			};
		}
	}
}

#endif

