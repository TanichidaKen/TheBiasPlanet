package theBiasPlanet.coreUtilities.collectionsHandling;

import java.util.ArrayList;
import java.util.Arrays;

public class ListsFactory {
	@SafeVarargs
	@SuppressWarnings("unchecked")
	public static <T> ArrayList <T> createArrayList (Object ... a_items) {
		ArrayList <T> l_arrayList = new ArrayList <T> ();
		if (a_items != null) {
			Arrays.stream (a_items).forEach (a_item -> {
				l_arrayList.add ( (T) a_item);
			});
		}
		return l_arrayList;
	}
	
	// This doesn't accept any array as an expandable item; pass Iterables instead.
	@SafeVarargs
	@SuppressWarnings("unchecked")
	public static <T> ArrayList <T> createArrayListExpandingItems (Object ... a_items) {
		ArrayList <T> l_arrayList = new ArrayList <T> ();
		if (a_items != null) {
			Arrays.stream (a_items).forEach (a_item -> {
				if (a_item instanceof Iterable) {
					for (Object l_element: (Iterable) a_item) {
						l_arrayList.add ( (T) l_element);
					}
				}
				else {
					l_arrayList.add ( (T) a_item);
				}
			});
		}
		return l_arrayList;
	}
}

