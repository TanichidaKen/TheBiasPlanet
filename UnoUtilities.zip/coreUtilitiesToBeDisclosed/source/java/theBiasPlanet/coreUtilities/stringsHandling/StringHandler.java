package theBiasPlanet.coreUtilities.stringsHandling;

import java.nio.file.Paths;

public class StringHandler {
	public static String getUrl (String a_filePath) {
		return (Paths.get (a_filePath)).normalize ().toUri ().toString ();
	}
}

