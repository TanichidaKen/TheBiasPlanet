package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

public interface UnoDocumentOpeningPropertyNamesSet extends UnoPropertyNamesSet {
	String c_readOnly_Boolean = "ReadOnly";
	String c_hidden_Boolean = "Hidden";
}

