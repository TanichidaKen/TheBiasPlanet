package theBiasPlanet.unoUtilities.programsHandling;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;
import com.sun.star.comp.helper.Bootstrap;
import com.sun.star.container.XSet;
import com.sun.star.lang.XSingleComponentFactory;
import com.sun.star.uno.UnoRuntime;
import com.sun.star.uno.XComponentContext;
import theBiasPlanet.unoUtilities.connectionsHandling.UnoObjectsContext;
import theBiasPlanet.unoUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.servicesHandling.UnoServiceHandler;

public class UnoProcessEnvironment {
	private UnoObjectsContext i_localObjectsContext;
	
	public UnoProcessEnvironment (String a_identification, String a_servicesSettingFileUrl) throws IOException, ParserConfigurationException, SAXException, ClassNotFoundException, NoSuchMethodException, InvocationTargetException, IllegalAccessException, com.sun.star.uno.Exception {
		try {
			Map <String, Object> l_objectsContextExtraNameToValueMap = new HashMap <String, Object> ();
			l_objectsContextExtraNameToValueMap.put (UnoObjectsContextPropertyNamesConstantsGroup.c_identification, a_identification);
			XComponentContext l_originalLocalObjectsContext = Bootstrap.createInitialComponentContext (null);
			i_localObjectsContext = new UnoObjectsContext (l_originalLocalObjectsContext, l_objectsContextExtraNameToValueMap);
		}
		catch (Exception l_exception) {
			throw new com.sun.star.uno.Exception (String.format ("%s %s", UnoMessagesConstantsGroup.c_objectsContextNotCreated,  l_exception.toString ()));
		}
		if (a_servicesSettingFileUrl != null) {
			List <XSingleComponentFactory> l_singleServiceFactories = UnoServiceHandler.getSingleServiceFactories (a_servicesSettingFileUrl);
			XSet l_localServiceManagerInXSet = (XSet) UnoRuntime.queryInterface (XSet.class, i_localObjectsContext.getServiceManager ());
			for (XSingleComponentFactory l_singleServicesFactoryInXSingleComponentFactory: l_singleServiceFactories) {
				l_localServiceManagerInXSet.insert (l_singleServicesFactoryInXSingleComponentFactory);
			}
		}
	}
	
	public final UnoObjectsContext getLocalObjectsContext () {
		return i_localObjectsContext;
	}
}

