package theBiasPlanet.unoUtilities.connectionsHandling;

import com.sun.star.lang.EventObject;

public interface UnoConnectionEventsListener {
	public void connected (EventObject a_event);
	
	public void disconnected (EventObject a_event);
}

