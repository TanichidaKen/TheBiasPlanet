package theBiasPlanet.unoUtilities.displaysHandling;

import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.coreUtilities.messaging.CustomizedAlert;
import theBiasPlanet.coreUtilities.programsHandling.FxProcessEnvironment;
import theBiasPlanet.unoUtilities.connectionsHandling.UnoConnectionEventsListener;
import theBiasPlanet.unoUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.*;

public abstract class UnoConnectionBaseScene extends Scene implements UnoConnectionEventsListener {
	private static final int c_urlTextFieldWidth;
	protected String i_title = null;
	protected GridPane i_basePane = null;
	protected GridPane i_inputOutputPane = null;
	protected GridPane i_commandsPane = null;
	protected TextField i_urlTextField = null;
	protected Label i_statusLabel = null;
	protected Button i_disconnectButton = null;
	
	static {
		c_urlTextFieldWidth = 700;
	}
	
	protected UnoConnectionBaseScene (String a_title, double a_width, double a_height) {
		super (new GridPane (), a_width, a_height);
		getStylesheets ().add (FxProcessEnvironment.s_currentEnvironment.getProperties ().getProperty (ProcessPropertyNamesConstantsGroup.c_styleSheetUrl));
		i_title = a_title;
		i_basePane = new GridPane();
		i_basePane.getStyleClass().add (FxStyleClassesConstantsGroup.c_pane);
		i_basePane.getStyleClass().add (FxStyleClassesConstantsGroup.c_basePane);
		i_basePane.getStyleClass().add (FxStyleClassesConstantsGroup.c_visibleBorderLinesPane);
		GridPane l_rooPane = (GridPane) getRoot ();
		l_rooPane.getStyleClass().add (FxStyleClassesConstantsGroup.c_pane);
		i_inputOutputPane = new GridPane ();
		i_inputOutputPane.getStyleClass().add (FxStyleClassesConstantsGroup.c_pane);
		i_inputOutputPane.getStyleClass().add (FxStyleClassesConstantsGroup.c_invisibleBorderLinesPane);
		i_commandsPane = new GridPane ();
		i_commandsPane.getStyleClass().add (FxStyleClassesConstantsGroup.c_pane);
		i_commandsPane.getStyleClass().add (FxStyleClassesConstantsGroup.c_invisibleBorderLinesPane);
		i_urlTextField = new TextField (FxProcessEnvironment.s_currentEnvironment.getProperties ().getProperty (UnoConnectionPropertyNamesSet.c_url));
		i_urlTextField.setPrefWidth (c_urlTextFieldWidth);
		i_inputOutputPane.add (i_urlTextField, 0, 0);
		i_statusLabel = new Label (MessagesConstantsGroup.c_notConnected);
		i_inputOutputPane.add (i_statusLabel, 0, 1);
		i_basePane.add (i_inputOutputPane, 0, 0);
		i_basePane.add (i_commandsPane, 0, 1);
		i_disconnectButton = new Button (UserInterfaceComponentCaptionsConstantsGroup.c_disconnect);
		l_rooPane.add (i_basePane, 0, 0);
	}
	
	public String getTitle () {
		return i_title;
	}
	
	protected void close () {
		showAlertImmediately (CustomizedAlert.AlertType.INFORMATION, MessagesConstantsGroup.c_exiting);
		Platform.exit ();
		System.exit (0);
	}
	
	protected void showAlert (CustomizedAlert.AlertType a_alertType, String a_content) {
		Platform.runLater(() -> {
			showAlertImmediately (a_alertType, a_content);
		});
	}
	
	protected void showAlertImmediately (CustomizedAlert.AlertType a_alertType, String a_content) {
		CustomizedAlert l_alert = new CustomizedAlert (a_alertType, String.format ("%s %s", MessagesConstantsGroup.c_fromHeader, this.getClass ().toString ()), a_content);
		l_alert.initOwner (getWindow ());
		l_alert.showAndWait ();
	}
}

