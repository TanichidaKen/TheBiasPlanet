#include "theBiasPlanet/unoUtilities/documentsHandling/textDocumentsHandling/UnoTextDocument.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/UnoMessagesConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/UnoSpecialFileUrlsConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/stringsHandling/UnoExtendedStringHandler.hpp"

using namespace ::theBiasPlanet::unoUtilities::constantsGroups;
using namespace ::theBiasPlanet::unoUtilities::stringsHandling;

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace documentsHandling {
			namespace textDocumentsHandling {
				Reference <UnoTextDocument> UnoTextDocument::createTextDocument (Reference <UnoObjectsContext> a_objectsContext, bool a_hiddenly) {
					return Reference <UnoTextDocument> (new UnoTextDocument (a_objectsContext, UnoDocument::createUnoDocumentOrOpenUnoDocumentFile (a_objectsContext, UnoSpecialFileUrlsConstantsGroup::c_writerNewDocument, a_hiddenly)));
				}
				
				Reference <UnoTextDocument> UnoTextDocument::openTextDocumentFile (Reference <UnoObjectsContext> a_objectsContext, string const & a_fileUrl, bool a_hiddenly) {
					return Reference <UnoTextDocument> (new UnoTextDocument (a_objectsContext, UnoDocument::createUnoDocumentOrOpenUnoDocumentFile (a_objectsContext, a_fileUrl, a_hiddenly)));
				}
				
				Reference <UnoTextDocument> UnoTextDocument::getCurrentTextDocument (Reference <UnoObjectsContext> a_objectsContext) {
					return Reference <UnoTextDocument> (new UnoTextDocument (a_objectsContext, getCurrentUnoDocument (a_objectsContext)));
				}
				
				UnoTextDocument::UnoTextDocument (Reference <UnoObjectsContext> a_objectsContext, Reference <XComponent> a_textDocumentInXComponent) : UnoDocument (a_objectsContext, a_textDocumentInXComponent) {
					i_textDocumentInXTextDocument = Reference <XTextDocument> (a_textDocumentInXComponent, UNO_QUERY);
					if (i_textDocumentInXTextDocument.get () == nullptr) {
						throw Exception (UnoExtendedStringHandler::getOustring (UnoMessagesConstantsGroup::c_isNotTextDocument), *this);
					}
					i_controllerInXTextViewCursorSupplier = Reference <XTextViewCursorSupplier> (i_controllerInXController, UNO_QUERY);
				}
				
				Reference <XTextViewCursor> UnoTextDocument::getViewCursor () {
					return i_controllerInXTextViewCursorSupplier->getViewCursor ();
				}
			}
		}
	}
}

