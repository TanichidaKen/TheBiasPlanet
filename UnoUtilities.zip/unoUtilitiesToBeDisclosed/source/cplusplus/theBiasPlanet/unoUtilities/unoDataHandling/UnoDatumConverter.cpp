#include "theBiasPlanet/unoUtilities/unoDataHandling/UnoDatumConverter.hpp"

#include <iomanip>
#include <iostream>
#include <com/sun/star/uno/Any.hxx>
#include <com/sun/star/uno/Type.hxx>
#include <cppu/unotype.hxx>
#include "theBiasPlanet/unoUtilities/collectionsHandling/UnoSequenceHandler.hpp"
#include "theBiasPlanet/unoUtilities/stringsHandling/UnoExtendedStringHandler.hpp"

using namespace ::theBiasPlanet::unoUtilities::collectionsHandling;
using namespace ::theBiasPlanet::unoUtilities::stringsHandling;

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace unoDataHandling  {
			/*
			template <typename T> auto UnoDatumConverter::convertToNonUnoDatum (T const & a_unoDatum) {
				return a_unoDatum;
			}
			
			template <> auto UnoDatumConverter::convertToNonUnoDatum <OUString> (OUString const & a_unoDatum) {
				return UnoExtendedStringHandler::getString (a_unoDatum);
			}
			*/
			bool UnoDatumConverter::convertToNonUnoDatum (sal_Bool const & a_unoDatum) {
				return (bool) a_unoDatum;
			}
			
			unsigned char UnoDatumConverter::convertToNonUnoDatum (sal_Int8 const & a_unoDatum) {
				return (unsigned char) a_unoDatum;
			}
			
			short UnoDatumConverter::convertToNonUnoDatum (sal_Int16 const & a_unoDatum) {
				return (short) a_unoDatum;
			}
			
			long UnoDatumConverter::convertToNonUnoDatum (sal_Int32 const & a_unoDatum) {
				return (long) a_unoDatum;
			}
			
			long long UnoDatumConverter::convertToNonUnoDatum (sal_Int64 const & a_unoDatum) {
				return (long long) a_unoDatum;
			}
			
			float UnoDatumConverter::convertToNonUnoDatum (float const & a_unoDatum) {
				return a_unoDatum;
			}
			
			double UnoDatumConverter::convertToNonUnoDatum (double const & a_unoDatum) {
				return a_unoDatum;
			}
			
			char UnoDatumConverter::convertToNonUnoDatum (sal_Unicode const & a_unoDatum) {
				return (char) a_unoDatum;
			}
			
			string UnoDatumConverter::convertToNonUnoDatum (OUString const & a_unoDatum) {
				return UnoExtendedStringHandler::getString (a_unoDatum);
			}
			
			string UnoDatumConverter::convertToNonUnoDatum (Type const & a_unoDatum) {
				return UnoExtendedStringHandler::getString (a_unoDatum.getTypeName ());
			}
			
			string UnoDatumConverter::convertToNonUnoDatum (Any const & a_unoDatum) {
				ostringstream l_stringStream;
				TypeClass l_containedDatumType = a_unoDatum.getValueTypeClass ();
				if (l_containedDatumType == TypeClass_SEQUENCE) {
					string l_containdeDatumTypeName = UnoExtendedStringHandler::getString (a_unoDatum.getValueTypeName ());
					l_stringStream << l_containdeDatumTypeName << ":";
					if (l_containdeDatumTypeName == "[]boolean") {
						Sequence <sal_Bool> * l_unoSequence = (Sequence <sal_Bool> *) a_unoDatum.getValue ();
						l_stringStream << UnoSequenceHandler::toString (*l_unoSequence);
					}
					else if (l_containdeDatumTypeName == "[]byte") {
						Sequence <sal_Int8> * l_unoSequence = (Sequence <sal_Int8> *) a_unoDatum.getValue ();
						l_stringStream << UnoSequenceHandler::toString (*l_unoSequence);
					}
					else if (l_containdeDatumTypeName == "[]short") {
						Sequence <sal_Int16> * l_unoSequence = (Sequence <sal_Int16> *) a_unoDatum.getValue ();
						l_stringStream << UnoSequenceHandler::toString (*l_unoSequence);
					}
					else if (l_containdeDatumTypeName == "[]long") {
						Sequence <sal_Int32> * l_unoSequence = (Sequence <sal_Int32> *) a_unoDatum.getValue ();
						l_stringStream << UnoSequenceHandler::toString (*l_unoSequence);
					}
					else if (l_containdeDatumTypeName == "[]hyper") {
						Sequence <sal_Int64> * l_unoSequence = (Sequence <sal_Int64> *) a_unoDatum.getValue ();
						l_stringStream << UnoSequenceHandler::toString (*l_unoSequence);
					}
					else if (l_containdeDatumTypeName == "[]float") {
						Sequence <float> * l_unoSequence = (Sequence <float> *) a_unoDatum.getValue ();
						l_stringStream << UnoSequenceHandler::toString (*l_unoSequence);
					}
					else if (l_containdeDatumTypeName == "[]double") {
						Sequence <double> * l_unoSequence = (Sequence <double> *) a_unoDatum.getValue ();
						l_stringStream << UnoSequenceHandler::toString (*l_unoSequence);
					}
					else if (l_containdeDatumTypeName == "[]char") {
						Sequence <sal_Unicode> * l_unoSequence = (Sequence <sal_Unicode> *) a_unoDatum.getValue ();
						l_stringStream << UnoSequenceHandler::toString (*l_unoSequence);
					}
					else if (l_containdeDatumTypeName == "[]string") {
						Sequence <OUString> * l_unoSequence = (Sequence <OUString> *) a_unoDatum.getValue ();
						l_stringStream << UnoSequenceHandler::toString (*l_unoSequence);
					}
					else if (l_containdeDatumTypeName == "[]type") {
						Sequence <Type> * l_unoSequence = (Sequence <Type> *) a_unoDatum.getValue ();
						l_stringStream << UnoSequenceHandler::toString (*l_unoSequence);
					}
					else if (l_containdeDatumTypeName == "[]any") {
						Sequence <Any> * l_unoSequence = (Sequence <Any> *) a_unoDatum.getValue ();
						l_stringStream << UnoSequenceHandler::toString (*l_unoSequence);
					}
					else {
						// TODO
						l_stringStream << "An unsupported sequence";
					}
				}
				else if (l_containedDatumType == TypeClass_BOOLEAN) {
					l_stringStream << *((sal_Bool *) a_unoDatum.getValue ());
				}
				else if (l_containedDatumType == TypeClass_BYTE) {
					l_stringStream << *((sal_Int8 *) a_unoDatum.getValue ());
				}
				else if (l_containedDatumType == TypeClass_SHORT) {
					l_stringStream << *((sal_Int16 *) a_unoDatum.getValue ());
				}
				else if (l_containedDatumType == TypeClass_SHORT) {
					l_stringStream << *((sal_Int16 *) a_unoDatum.getValue ());
				}
				else if (l_containedDatumType == TypeClass_LONG) {
					l_stringStream << *((sal_Int32 *) a_unoDatum.getValue ());
				}
				else if (l_containedDatumType == TypeClass_HYPER) {
					l_stringStream << *((sal_Int64 *) a_unoDatum.getValue ());
				}
				else if (l_containedDatumType == TypeClass_FLOAT) {
					l_stringStream << *((float *) a_unoDatum.getValue ());
				}
				else if (l_containedDatumType == TypeClass_DOUBLE) {
					l_stringStream << *((double *) a_unoDatum.getValue ());
				}
				else if (l_containedDatumType == TypeClass_CHAR) {
					l_stringStream << *((sal_Unicode *) a_unoDatum.getValue ());
				}
				else if (l_containedDatumType == TypeClass_STRING) {
					l_stringStream << UnoExtendedStringHandler::getString (*((OUString *) a_unoDatum.getValue ()));
				}
				else if (l_containedDatumType == TypeClass_TYPE) {
					l_stringStream << UnoExtendedStringHandler::getString (((Type *) a_unoDatum.getValue ())->getTypeName ());
				}
				return l_stringStream.str ();
			}
			
			sal_Bool UnoDatumConverter::convertToUnoDatum (bool const & a_unoDatum) {
				return (sal_Bool) a_unoDatum;
			}
			
			sal_Int8 UnoDatumConverter::convertToUnoDatum (unsigned char const & a_unoDatum) {
				return (sal_Int8) a_unoDatum;
			}
			
			sal_Int16 UnoDatumConverter::convertToUnoDatum (short const & a_unoDatum) {
				return (sal_Int16) a_unoDatum;
			}
			
			sal_Int32 UnoDatumConverter::convertToUnoDatum (long const & a_unoDatum) {
				return (sal_Int32) a_unoDatum;
			}
			
			sal_Int64 UnoDatumConverter::convertToUnoDatum (long long const & a_unoDatum) {
				return (sal_Int64) a_unoDatum;
			}
			
			float UnoDatumConverter::convertToUnoDatum (float const & a_unoDatum) {
				return a_unoDatum;
			}
			
			double UnoDatumConverter::convertToUnoDatum (double const & a_unoDatum) {
				return a_unoDatum;
			}
			
			sal_Unicode UnoDatumConverter::convertToUnoDatum (char const & a_unoDatum) {
				return (sal_Unicode) a_unoDatum;
			}
			
			OUString UnoDatumConverter::convertToUnoDatum (string const & a_unoDatum) {
				return UnoExtendedStringHandler::getOustring (a_unoDatum);
			}
		}
	}
}

