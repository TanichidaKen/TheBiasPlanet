#ifndef __theBiasPlanet_unoUtilities_unoDataHandling_UnoDatumConverter_hpp__
#define __theBiasPlanet_unoUtilities_unoDataHandling_UnoDatumConverter_hpp__

#include <cstddef>
#include <list>
#include <string>
#include <com/sun/star/uno/Any.hxx>
#include <com/sun/star/uno/Sequence.hxx>
#include <com/sun/star/uno/Type.hxx>
#include <cppu/unotype.hxx>
#include <rtl/ustring.hxx>
#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"

using namespace ::std;
using namespace ::com::sun::star::uno;
using namespace ::rtl;

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace unoDataHandling {
			class __theBiasPlanet_unoUtilities_symbolExportingOrImportingDeclarationForVisualCplusplus__ UnoDatumConverter {
				public:
					//template <typename T> static auto convertToNonUnoDatum (T const & a_unoDatum);
					static bool convertToNonUnoDatum (sal_Bool const & a_unoDatum);
					static unsigned char convertToNonUnoDatum (sal_Int8 const & a_unoDatum);
					static short convertToNonUnoDatum (sal_Int16 const & a_unoDatum);
					static long convertToNonUnoDatum (sal_Int32 const & a_unoDatum);
					static long long convertToNonUnoDatum (sal_Int64 const & a_unoDatum);
					static float convertToNonUnoDatum (float const & a_unoDatum);
					static double convertToNonUnoDatum (double const & a_unoDatum);
					static char convertToNonUnoDatum (sal_Unicode const & a_unoDatum);
					static string convertToNonUnoDatum (OUString const & a_unoDatum);
					static string convertToNonUnoDatum (Type const & a_unoDatum);
					static string convertToNonUnoDatum (Any const & a_unoDatum);
					template <typename T, typename U> static list <U> convertToNonUnoDatum (Sequence <T> const & a_unoDatum);
					template <typename T> static T convertToNonUnoDatum (T const & a_unoDatum);
					
					static sal_Bool convertToUnoDatum (bool const & a_unoDatum);
					static sal_Int8 convertToUnoDatum (unsigned char const & a_unoDatum);
					static sal_Int16 convertToUnoDatum (short const & a_unoDatum);
					static sal_Int32 convertToUnoDatum (long const & a_unoDatum);
					static sal_Int64  convertToUnoDatum (long long const & a_unoDatum);
					static float convertToUnoDatum (float const & a_unoDatum);
					static double convertToUnoDatum (double const & a_unoDatum);
					static sal_Unicode convertToUnoDatum (char const & a_unoDatum);
					static OUString convertToUnoDatum (string  const & a_unoDatum);
					template <typename T, typename U> static Sequence <U> convertToUnoDatum (list <T> const & a_unoDatum);
					template <typename T> static T convertToUnoDatum (T const & a_unoDatum);
			};
		}
	}
}

#endif

