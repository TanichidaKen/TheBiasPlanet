#include "theBiasPlanet/unoUtilities/propertiesHandling/UnoPropertiesHandler.hpp"
#include "theBiasPlanet/unoUtilities/stringsHandling/UnoExtendedStringHandler.hpp"

using namespace ::theBiasPlanet::unoUtilities::stringsHandling;

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace propertiesHandling {
			list <PropertyValue> UnoPropertiesHandler::buildPropertyNameValuePairs (list <string> a_propertyNames, list <Any> a_propertyValues) {
				list <PropertyValue> l_propertyNameValuePairs;
				list <Any>::iterator a_propertyValuesIterator = a_propertyValues.begin ();
				for (string l_propertyName: a_propertyNames) {
					PropertyValue l_propertyNameValuePair = PropertyValue ();
					l_propertyNameValuePair.Name = UnoExtendedStringHandler::getOustring (l_propertyName);
					l_propertyNameValuePair.Value = *a_propertyValuesIterator;
					l_propertyNameValuePairs.push_back (l_propertyNameValuePair);
					a_propertyValuesIterator ++;
				}
				return l_propertyNameValuePairs;
			}
		}
	}
}

