//#include "theBiasPlanet/unoUtilities/anotherProjectTemplatesInstantiators/CoreUtilitiesTemplatesInstantiator.hpp"
#include <com/sun/star/beans/PropertyValue.hpp>
#include <com/sun/star/uno/Any.h>
#include "theBiasPlanet/coreUtilities/collectionsHandling/ArraysFactory.tpp"
#include "theBiasPlanet/coreUtilities/collectionsHandling/ListsFactory.tpp"
#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"

using namespace ::com::sun::star::beans;
using namespace ::com::sun::star::uno;
using namespace ::theBiasPlanet::coreUtilities::collectionsHandling;

template __theBiasPlanet_unoUtilities_symbolExportingOrImportingDeclarationForVisualCplusplus__ PropertyValue * ArraysFactory::createArray <PropertyValue> (PropertyValue * a_targetArray, list <PropertyValue> const & a_list);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingDeclarationForVisualCplusplus__ list <Any> ListsFactory::createList <Any, Any> (Any const & a_currentElement, Any const & a_remainingElement0);

/*
namespace theBiasPlanet {
	namespace unoUtilities {
		namespace anotherProjectTemplatesInstantiators {
			void CoreUtilitiesTemplatesInstantiator::instantiateTemplates () {
				//ListsFactory::createList (Any (false), Any (false));
				//PropertyValue l_propertyValusArray [2];
				//ArraysFactory::createArray <PropertyValue> (l_propertyValusArray, list <PropertyValue> ());
			}
		}
	}
}
*/

