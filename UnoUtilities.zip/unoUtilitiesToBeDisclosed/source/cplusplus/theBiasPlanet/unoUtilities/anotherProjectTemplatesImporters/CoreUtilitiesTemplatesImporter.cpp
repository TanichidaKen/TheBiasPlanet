#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"

#ifndef GCC
#include "theBiasPlanet/coreUtilities/templatesInstantiator/TemplatesInstantiator.cpp"
#endif

