#ifndef __theBiasPlanet_unoUtilities_constantsGroups_UnoSpecialFileUrlsConstantsGroup_hpp__
#define __theBiasPlanet_unoUtilities_constantsGroups_UnoSpecialFileUrlsConstantsGroup_hpp__

#include <string>
#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"

using namespace ::std;

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			class __theBiasPlanet_unoUtilities_symbolExportingOrImportingDeclarationForVisualCplusplus__ UnoSpecialFileUrlsConstantsGroup {
				public:
					static string const c_calcNewDocument;
					static string const c_writerNewDocument;
			};
		}
	}
}

#endif

