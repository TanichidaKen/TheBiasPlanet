#ifndef __theBiasPlanet_unoUtilities_constantsGroups_UnoGeneralConstantsConstantsGroup_hpp__
#define __theBiasPlanet_unoUtilities_constantsGroups_UnoGeneralConstantsConstantsGroup_hpp__

#include <string>
#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"

using namespace ::std;

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			class __theBiasPlanet_unoUtilities_symbolExportingOrImportingDeclarationForVisualCplusplus__ UnoGeneralConstantsConstantsGroup {
				public:
					static string const c_anyUnspecifiedString;
					static char const c_digitPlaceCharacter;
					static double const c_numberExpressionModelNumber;
					static string const c_cellPositionExpressionFormat;
					static int const c_rowIndexToRowPositionExpressionDifference;
					static string const c_connectionUrlDelimiter;
					static string const c_moduleDlimiter;
					static string const c_unoServiceNameFormat;
					static string const c_unoIdlFileNameFormat;
					static string const c_unoModuleBeginningRelativeExpressionFormat;
					static string const c_unoModuleEndRelativeExpressionFormat;
			};
		}
	}
}

#endif

