#ifndef __theBiasPlanet_unoUtilities_constantsGroups_UnoMessagesConstantsGroup_hpp__
#define __theBiasPlanet_unoUtilities_constantsGroups_UnoMessagesConstantsGroup_hpp__

#include <string>
#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"

using namespace ::std;

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			class __theBiasPlanet_unoUtilities_symbolExportingOrImportingDeclarationForVisualCplusplus__ UnoMessagesConstantsGroup {
				public:
					static string const c_remoteInstanceNotProvided;
					static string const c_cellNotString;
					static string const c_unoDocumentNotSpecified;
					static string const c_isNotSpreadSheetsDocument;
					static string const c_isNotTextDocument;
					static string const c_spreadSheetsDocumentNotSpecified;
					static string const c_spreadSheetNotSpecified;
					static string const c_objectsContextNotCreated;
					static string const c_objectsContextNotSpecified;
					static string const c_noCurrentSpreadSheetCell;
			};
		}
	}
}

#endif

