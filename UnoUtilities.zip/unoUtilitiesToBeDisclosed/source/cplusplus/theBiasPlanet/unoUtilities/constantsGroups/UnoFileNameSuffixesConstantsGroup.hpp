#ifndef __theBiasPlanet_unoUtilities_constantsGroups_UnoFileNameSuffixesConstantsGroup_hpp__
#define __theBiasPlanet_unoUtilities_constantsGroups_UnoFileNameSuffixesConstantsGroup_hpp__

#include <string>
#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"

using namespace ::std;

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			class __theBiasPlanet_unoUtilities_symbolExportingOrImportingDeclarationForVisualCplusplus__ UnoFileNameSuffixesConstantsGroup {
				public:
					static string const c_unoIdlFileNameSuffix;
					static string const c_unoDataTypesMergedRegistryFileNameSuffix;
			};
		}
	}
}

#endif

