#ifndef __theBiasPlanet_unoUtilities_constantsGroups_propertyNamesSets_UnoDocumentOpeningEnumerablePropertyNamesSet_hpp__
#define __theBiasPlanet_unoUtilities_constantsGroups_propertyNamesSets_UnoDocumentOpeningEnumerablePropertyNamesSet_hpp__

#include "theBiasPlanet/coreUtilities/constantsGroups/BaseEnumerableConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/UnoDocumentOpeningPropertyNamesSet.hpp"
#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"

using namespace ::theBiasPlanet::coreUtilities::constantsGroups;

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			namespace propertyNamesSets {
				class __theBiasPlanet_unoUtilities_symbolExportingOrImportingDeclarationForVisualCplusplus__ UnoDocumentOpeningEnumerablePropertyNamesSet : public BaseEnumerableConstantsGroup <string>, public UnoDocumentOpeningPropertyNamesSet {
					private:
						UnoDocumentOpeningEnumerablePropertyNamesSet ();
					public:
						static UnoDocumentOpeningEnumerablePropertyNamesSet const c_instance;
				};
			}
		}
	}
}

#endif

