#include "theBiasPlanet/unoUtilities/connectionsHandling/UnoObjectsContext.hpp"
#include <rtl/ustrbuf.hxx>
#include <com/sun/star/uno/Exception.hpp>
#include "theBiasPlanet/unoUtilities/constantsGroups/UnoMessagesConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/UnoObjectsContextPropertyNamesConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/stringsHandling/UnoExtendedStringHandler.hpp"

using namespace ::theBiasPlanet::unoUtilities::constantsGroups;
using namespace ::theBiasPlanet::unoUtilities::stringsHandling;

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace connectionsHandling {
			UnoObjectsContext::UnoObjectsContext (Reference <XComponentContext> a_originalObjectsContextInXComponentContext, optional <map <string, Any>> a_extraNameToValueMap) : WeakComponentImplHelper1 (i_mutex) {
				i_originalObjectsContextInXComponentContext = a_originalObjectsContextInXComponentContext;
				i_originalObjectsContextInXNameContainer = Reference <XNameContainer> (i_originalObjectsContextInXComponentContext, UNO_QUERY);
				i_extraNameToValueMap = a_extraNameToValueMap;
			}
			
			UnoObjectsContext::~UnoObjectsContext () {
			}
			
			Any UnoObjectsContext::getValueByName (const OUString & a_name) {
				if (i_extraNameToValueMap.has_value ()) {
					map <string, Any>::iterator l_extraNameToValueMapIterator = i_extraNameToValueMap->find (UnoExtendedStringHandler::getString (a_name));
					if (l_extraNameToValueMapIterator != i_extraNameToValueMap->end ()) {
						return l_extraNameToValueMapIterator->second;
					}
					else {
						return i_originalObjectsContextInXComponentContext->getValueByName (a_name);
					}
				}
				else {
					return i_originalObjectsContextInXComponentContext->getValueByName (a_name);
				}
			}
			
			Reference <XMultiComponentFactory> UnoObjectsContext::getServiceManager () {
				return i_originalObjectsContextInXComponentContext->getServiceManager ();
			}
			
			bool UnoObjectsContext::isFromSameOrigin (Reference <UnoObjectsContext> a_unoObjectsContext) {
				if (i_extraNameToValueMap.has_value ()) {
					map <string, Any>::iterator l_extraNameToValueMapIterator = i_extraNameToValueMap->find (UnoObjectsContextPropertyNamesConstantsGroup::c_identification);
					if (l_extraNameToValueMapIterator == i_extraNameToValueMap->end ()) {
						return false;
					}
					if (l_extraNameToValueMapIterator->second == a_unoObjectsContext->getValueByName (UnoExtendedStringHandler::getOustring (UnoObjectsContextPropertyNamesConstantsGroup::c_identification))) {
						return true;
					}
					else {
						return false;
					}
				}
				else {
					return false;
				}
			}
		}
	}
}

