#ifndef __theBiasPlanet_unoUtilities_connectionsHandling_UnoConnectionEventsListener_hpp__
#define __theBiasPlanet_unoUtilities_connectionsHandling_UnoConnectionEventsListener_hpp__

#include <com/sun/star/lang/EventObject.hpp>
#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"

using namespace ::com::sun::star::lang;

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace connectionsHandling {
			class __theBiasPlanet_unoUtilities_symbolExportingOrImportingDeclarationForVisualCplusplus__ UnoConnectionEventsListener {
				public:
					virtual void connected (EventObject const & a_event) const = 0;
	
					virtual void disconnected (EventObject const & a_event) const = 0;
			};
		}
	}
}

#endif

