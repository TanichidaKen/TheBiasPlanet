#ifndef __theBiasPlanet_unoUtilities_connectionsHandling_UnoConnection_hpp__
#define __theBiasPlanet_unoUtilities_connectionsHandling_UnoConnection_hpp__

#include <list>
#include <optional>
#include <com/sun/star/bridge/XBridge.hpp>
#include <com/sun/star/lang/EventObject.hpp>
#include <com/sun/star/lang/XComponent.hpp>
#include <com/sun/star/lang/XEventListener.hpp>
#include <com/sun/star/uno/Reference.hxx>
#include <cppuhelper/compbase1.hxx>
#include <osl/mutex.hxx>
#include "theBiasPlanet/unoUtilities/connectionsHandling/UnoConnectionEventsListener.hpp"
#include "theBiasPlanet/unoUtilities/connectionsHandling/UnoObjectsContext.hpp"
#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"

using namespace ::std;
using namespace ::com::sun::star::bridge;
using namespace ::com::sun::star::lang;
using namespace ::osl;

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace connectionsHandling {
			class __theBiasPlanet_unoUtilities_symbolExportingOrImportingDeclarationForVisualCplusplus__ UnoConnection : public WeakComponentImplHelper1 <XEventListener> {
				private:
					Mutex i_mutex;
					Reference <UnoObjectsContext> i_remoteObjectsContext;
					Reference <XComponent> i_bridgeInXComponent;
					optional <list <UnoConnectionEventsListener *>> i_eventListeners;
				public:
					UnoConnection (Reference <XComponentContext> const a_originalObjectsContextInXComponentContext, optional <map <string, Any> const> const a_extraNameToValueMap, Reference <XBridge> const a_bridgeInXBridge, optional <list <UnoConnectionEventsListener *>> a_eventListeners);
					~UnoConnection ();
					virtual Reference <UnoObjectsContext> getRemoteObjectsContext () final;
					virtual void disconnect () final;
					virtual void SAL_CALL disposing (EventObject const & a_event) override final;
			};
		}
	}
}

#endif

