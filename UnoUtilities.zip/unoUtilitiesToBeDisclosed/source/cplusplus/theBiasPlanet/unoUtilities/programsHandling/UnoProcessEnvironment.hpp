#ifndef __theBiasPlanet_unoUtilities_programsHandling_UnoProcessEnvironment_hpp__
#define __theBiasPlanet_unoUtilities_programsHandling_UnoProcessEnvironment_hpp__

#include <optional>
#include <string>
#include <com/sun/star/uno/Reference.hxx>
#include "theBiasPlanet/unoUtilities/connectionsHandling/UnoObjectsContext.hpp"
#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"

using namespace ::std;
using namespace ::theBiasPlanet::unoUtilities::connectionsHandling;

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace programsHandling {
			class __theBiasPlanet_unoUtilities_symbolExportingOrImportingDeclarationForVisualCplusplus__ UnoProcessEnvironment {
				private:
					//optional <UnoObjectsContext> i_localObjectsContext;
					Reference <UnoObjectsContext> i_localObjectsContext;
				public:
					//UnoProcessEnvironment (string const & a_identification, optional <string const> & a_servicesSettingFileUrl);
					UnoProcessEnvironment (string const & a_identification);
					~UnoProcessEnvironment ();
					virtual Reference <UnoObjectsContext> & getLocalObjectsContext () const final;
			};
		}
	}
}

#endif

