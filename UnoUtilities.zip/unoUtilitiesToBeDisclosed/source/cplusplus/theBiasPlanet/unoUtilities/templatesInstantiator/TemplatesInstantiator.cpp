//#include "theBiasPlanet/unoUtilities/templatesInstantiator/TemplatesInstantiator.hpp"
#include <string>
#include <com/sun/star/beans/PropertyValue.hpp>
#include <com/sun/star/bridge/XBridgeFactory.hpp>
#include <com/sun/star/connection/XConnector.hpp>
#include <com/sun/star/frame/XComponentLoader.hpp>
#include <com/sun/star/frame/XDesktop2.hpp>
#include <com/sun/star/uno/Any.h>
#include <com/sun/star/uno/Type.hxx>
#include <com/sun/star/uno/Reference.hxx>
#include <cppu/unotype.hxx>
#include <rtl/ustring.hxx>
#include "theBiasPlanet/unoUtilities/collectionsHandling/UnoSequenceHandler.tpp"
#include "theBiasPlanet/unoUtilities/connectionsHandling/UnoObjectsContext.hpp"
#include "theBiasPlanet/unoUtilities/servicesHandling/UnoServiceHandler.tpp"
#include "theBiasPlanet/unoUtilities/unoDataHandling/UnoDatumConverter.tpp"
#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"

using namespace ::com::sun::star::beans;
using namespace ::com::sun::star::frame;
using namespace ::com::sun::star::uno;
using namespace ::rtl;
using namespace ::theBiasPlanet::unoUtilities::collectionsHandling;
using namespace ::theBiasPlanet::unoUtilities::servicesHandling;
using namespace ::theBiasPlanet::unoUtilities::unoDataHandling;

template __theBiasPlanet_unoUtilities_symbolExportingOrImportingDeclarationForVisualCplusplus__ Any UnoDatumConverter::convertToUnoDatum <Any> (Any const & a_unoDatum);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingDeclarationForVisualCplusplus__ Sequence <Any> * UnoSequenceHandler::fillSequence <Any, Any> (Sequence <Any> * a_sequence, list <Any> const & a_list);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingDeclarationForVisualCplusplus__ Sequence <PropertyValue> * UnoSequenceHandler::fillSequence <PropertyValue, PropertyValue> (Sequence <PropertyValue> * a_sequence, list <PropertyValue> const & a_list);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingDeclarationForVisualCplusplus__ string UnoSequenceHandler::toString <sal_Bool> (Sequence <sal_Bool> const & a_sequence);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingDeclarationForVisualCplusplus__ string UnoSequenceHandler::toString <sal_Int8> (Sequence <sal_Int8> const & a_sequence);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingDeclarationForVisualCplusplus__ string UnoSequenceHandler::toString <sal_Int16> (Sequence <sal_Int16> const & a_sequence);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingDeclarationForVisualCplusplus__ string UnoSequenceHandler::toString <sal_Int32> (Sequence <sal_Int32> const & a_sequence);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingDeclarationForVisualCplusplus__ string UnoSequenceHandler::toString <sal_Int64> (Sequence <sal_Int64> const & a_sequence);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingDeclarationForVisualCplusplus__ string UnoSequenceHandler::toString <float> (Sequence <float> const & a_sequence);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingDeclarationForVisualCplusplus__ string UnoSequenceHandler::toString <double> (Sequence <double> const & a_sequence);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingDeclarationForVisualCplusplus__ string UnoSequenceHandler::toString <sal_Unicode> (Sequence <sal_Unicode> const & a_sequence);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingDeclarationForVisualCplusplus__ string UnoSequenceHandler::toString <OUString> (Sequence <OUString> const & a_sequence);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingDeclarationForVisualCplusplus__ string UnoSequenceHandler::toString <Type> (Sequence <Type> const & a_sequence);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingDeclarationForVisualCplusplus__ string UnoSequenceHandler::toString <Any> (Sequence <Any> const & a_sequence);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingDeclarationForVisualCplusplus__ Reference <XBridgeFactory> UnoServiceHandler::getServiceInstance <XBridgeFactory> (Reference <UnoObjectsContext> a_objectsContext, string const & a_serviceName);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingDeclarationForVisualCplusplus__ Reference <XConnector> UnoServiceHandler::getServiceInstance <XConnector> (Reference <UnoObjectsContext> a_objectsContext, string const & a_serviceName);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingDeclarationForVisualCplusplus__ Reference <XComponentLoader> UnoServiceHandler::getServiceInstance <XComponentLoader> (Reference <UnoObjectsContext> a_objectsContext, string const & a_serviceName);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingDeclarationForVisualCplusplus__ Reference <XDesktop2> UnoServiceHandler::getServiceInstance <XDesktop2> (Reference <UnoObjectsContext> a_objectsContext, string const & a_serviceName);

/*
namespace theBiasPlanet {
	namespace unoUtilities {
		namespace templatesInstantiator {
			void  TemplatesInstantiator::instantiateTemplates () {
				//Reference <UnoObjectsContext> l_unoObjectsContext;
				//UnoServiceHandler::getServiceInstance <XBridgeFactory> (l_unoObjectsContext, string (""));
				//UnoServiceHandler::getServiceInstance <XConnector> (l_unoObjectsContext, string (""));
				//UnoServiceHandler::getServiceInstance <XComponentLoader> (l_unoObjectsContext, string (""));
				//UnoServiceHandler::getServiceInstance <XDesktop2> (l_unoObjectsContext, string (""));
			}
		}
	}
}
*/

