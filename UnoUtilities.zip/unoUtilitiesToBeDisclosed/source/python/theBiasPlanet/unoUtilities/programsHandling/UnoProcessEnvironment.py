from typing import Dict
from typing import Optional
import uno
from uno import Any
from com.sun.star.uno import Exception as com_sun_star_uno_Exception
from com.sun.star.uno import XComponentContext
from theBiasPlanet.unoUtilities.connectionsHandling.UnoObjectsContext import UnoObjectsContext
from theBiasPlanet.unoUtilities.constantsGroups.UnoDatumTypeNamesConstantsGroup import UnoDatumTypeNamesConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.UnoMessagesConstantsGroup import UnoMessagesConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.UnoObjectsContextPropertyNamesSet import UnoObjectsContextPropertyNamesSet

class UnoProcessEnvironment:
	i_localObjectsContext: "UnoObjectsContext"
	
	def __init__ (a_this: "UnoProcessEnvironment", a_identification: str, a_servicesSettingFileUrl: Optional [str]) -> None:
		try:
			l_unoObjectsContextExtraNameToValueMap: Dict [str, Any] = dict ()
			l_unoObjectsContextExtraNameToValueMap.update ({UnoObjectsContextPropertyNamesSet.c_identification_string: Any (UnoDatumTypeNamesConstantsGroup.c_stringTypeName, a_identification)})
			l_originalLocalObjectsContext: XComponentContext = uno.getComponentContext ()
			a_this.i_localObjectsContext = UnoObjectsContext (l_originalLocalObjectsContext, l_unoObjectsContextExtraNameToValueMap)
		except (com_sun_star_uno_Exception) as l_exception:
			raise com_sun_star_uno_Exception ("{0:s} {1:s}".format (UnoMessagesConstantsGroup.c_unoObjectsContextNotCreated, str (l_exception)), None)
	
	def getLocalObjectsContext (a_this: "UnoProcessEnvironment") -> "UnoObjectsContext":
		return a_this.i_localObjectsContext

