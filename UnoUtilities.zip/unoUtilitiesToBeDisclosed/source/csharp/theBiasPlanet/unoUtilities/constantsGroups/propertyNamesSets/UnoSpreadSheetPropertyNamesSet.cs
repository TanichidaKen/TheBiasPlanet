namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			namespace propertyNamesSets {
				using System;
				
				public static class UnoSpreadSheetPropertyNamesSet {
					public const String c_whetherIsVisible_boolean = "IsVisible";
					public const String c_pageStyle = "PageStyle";
				}
			}
		}
	}
}

