namespace theBiasPlanet {
	namespace unoUtilities {
		namespace connectionsHandling {
			using System;
			using System.Collections.Generic;
			using uno;
			using unoidl.com.sun.star.bridge;
			using unoidl.com.sun.star.connection;
			using unoidl.com.sun.star.uno;
			using theBiasPlanet.coreUtilities.stringsHandling;
			using theBiasPlanet.unoUtilities.constantsGroups;
			using theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;
			
			abstract public class UnoConnectionsFactory {
				private class InitialUnoObjectsProvider : XInstanceProvider {
					private UnoObjectsContext i_localObjectsContext;
					
					public InitialUnoObjectsProvider (UnoObjectsContext a_localObjectsContext) {
						i_localObjectsContext = a_localObjectsContext;
					}
					
					public Object getInstance (String a_initialUnoObjectName) {
						if (UnoDefaultValuesConstantsGroup.c_initiallyOfferedUnoObjectName.Equals (a_initialUnoObjectName)) {
							return i_localObjectsContext;
						}
						else {
							return null;
						}
					}
				}
				protected UnoObjectsContext i_localObjectsContext;
				protected XBridgeFactory i_bridgesFactoryInXBridgeFactory;
				
				protected UnoConnectionsFactory (UnoObjectsContext a_localObjectsContext) {
					i_localObjectsContext = a_localObjectsContext;
				}
				
				protected void initialize () {
					i_bridgesFactoryInXBridgeFactory = (XBridgeFactory) i_localObjectsContext.getServiceInstance (UnoServiceNamesConstantsGroup.c_com_sun_star_bridge_BridgeFactory, null);
				}
				
				protected UnoConnection setupConnection (XConnection a_connectionInXConnection, StringTokenizer a_urlTokenizer, String a_connectionIdentification, List <UnoConnectionEventsListener> a_eventListeners) {
					XBridge l_bridgeInXBridge = null;
					try {
						l_bridgeInXBridge = i_bridgesFactoryInXBridgeFactory.createBridge ("", a_urlTokenizer.nextToken (), a_connectionInXConnection, new InitialUnoObjectsProvider (i_localObjectsContext));
					}
					catch (BridgeExistsException l_exception) {
						// This can't happen
						Console.Out.WriteLine (l_exception);
					}
					Object l_remoteObjectsContextInXInterface =  l_bridgeInXBridge.getInstance (a_urlTokenizer.nextToken ());
					if (l_remoteObjectsContextInXInterface == null) {
						throw new unoidl.com.sun.star.uno.Exception (UnoMessagesConstantsGroup.c_remoteInstanceNotProvided, null);
					}
					Dictionary <String, Any> l_unoObjectsContextExtraNameToValueMap = new Dictionary <String, Any> ();
					l_unoObjectsContextExtraNameToValueMap.Add (UnoObjectsContextPropertyNamesSet.c_identification_string, new Any (String.Format ("{0}: {1}", a_connectionInXConnection.getDescription (), a_connectionIdentification)));
					UnoConnection l_unoConnection = new UnoConnection ((XComponentContext) l_remoteObjectsContextInXInterface, l_unoObjectsContextExtraNameToValueMap, l_bridgeInXBridge, a_eventListeners);
					return l_unoConnection;
				}
			}
		}
	}
}

