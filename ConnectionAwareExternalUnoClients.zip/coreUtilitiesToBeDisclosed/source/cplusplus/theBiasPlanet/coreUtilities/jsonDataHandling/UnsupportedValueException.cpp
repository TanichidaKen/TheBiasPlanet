#include "theBiasPlanet/coreUtilities/jsonDataHandling/UnsupportedValueException.hpp"

namespace theBiasPlanet {
	namespace coreUtilities {
		namespace jsonDataHandling {
			UnsupportedValueException::UnsupportedValueException (string a_message) : exception (), i_message (a_message) {
			}
			
			UnsupportedValueException::~UnsupportedValueException () {
			}
			
			char const * UnsupportedValueException::what () const throw () {
    			return i_message.c_str ();
    		}
		}
	}
}

