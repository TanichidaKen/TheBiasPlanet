#ifndef __theBiasPlanet_coreUtilities_jsonDataHandling_UnsupportedClassException_hpp__
	#define __theBiasPlanet_coreUtilities_jsonDataHandling_UnsupportedClassException_hpp__
	
	#include <exception>
	#include <string>
	#include "theBiasPlanet/coreUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	
	namespace theBiasPlanet {
		namespace coreUtilities {
			namespace jsonDataHandling {
				class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ UnsupportedClassException : public exception {
					private:
						string i_message;
					public:
						UnsupportedClassException (string a_message);
						virtual ~UnsupportedClassException ();
						virtual char const * what () const throw () override;
				};
			}
		}
	}
#endif

