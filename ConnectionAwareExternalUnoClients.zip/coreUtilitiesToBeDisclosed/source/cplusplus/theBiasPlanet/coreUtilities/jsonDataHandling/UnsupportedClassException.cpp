#include "theBiasPlanet/coreUtilities/jsonDataHandling/UnsupportedClassException.hpp"

namespace theBiasPlanet {
	namespace coreUtilities {
		namespace jsonDataHandling {
			UnsupportedClassException::UnsupportedClassException (string a_message) : exception (), i_message (a_message) {
			}
			
			UnsupportedClassException::~UnsupportedClassException () {
			}
			
			char const * UnsupportedClassException::what () const throw () {
    			return i_message.c_str ();
    		}
		}
	}
}

