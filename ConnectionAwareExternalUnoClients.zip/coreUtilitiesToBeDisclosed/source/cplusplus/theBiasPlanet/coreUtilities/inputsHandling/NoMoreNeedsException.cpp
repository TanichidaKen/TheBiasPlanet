#include "theBiasPlanet/coreUtilities/inputsHandling/NoMoreNeedsException.hpp"

namespace theBiasPlanet {
	namespace coreUtilities {
		namespace inputsHandling {
			NoMoreNeedsException::NoMoreNeedsException (string a_message) : exception (), i_message (a_message) {
			}
			
			NoMoreNeedsException::~NoMoreNeedsException () {
			}
			
			char const * NoMoreNeedsException::what () const throw () {
    			return i_message.c_str ();
    		}
		}
	}
}

