#include "theBiasPlanet/coreUtilities/inputsHandling/BufferOverflowedException.hpp"

namespace theBiasPlanet {
	namespace coreUtilities {
		namespace inputsHandling {
			BufferOverflowedException::BufferOverflowedException (string a_message) : exception (), i_message (a_message) {
			}
			
			BufferOverflowedException::~BufferOverflowedException () {
			}
			
			char const * BufferOverflowedException::what () const throw () {
    			return i_message.c_str ();
    		}
		}
	}
}

