#ifndef __theBiasPlanet_coreUtilities_inputsHandling_NoMoreNeedsException_hpp__
	#define __theBiasPlanet_coreUtilities_inputsHandling_NoMoreNeedsException_hpp__
	
	#include <exception>
	#include <string>
	#include "theBiasPlanet/coreUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	
	namespace theBiasPlanet {
		namespace coreUtilities {
			namespace inputsHandling {
				class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ NoMoreNeedsException : public exception {
					private:
						string i_message;
					public:
						NoMoreNeedsException (string a_message);
						virtual ~NoMoreNeedsException ();
						virtual char const * what () const throw () override;
				};
			}
		}
	}
#endif

