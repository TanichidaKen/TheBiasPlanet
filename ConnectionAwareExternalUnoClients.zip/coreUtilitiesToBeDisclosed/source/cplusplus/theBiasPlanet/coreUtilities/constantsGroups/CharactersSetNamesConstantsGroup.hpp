#ifndef __theBiasPlanet_coreUtilities_constantsGroups_CharactersSetNamesConstantsGroup_hpp__
	#define __theBiasPlanet_coreUtilities_constantsGroups_CharactersSetNamesConstantsGroup_hpp__

	#include <string>
	#include "theBiasPlanet/coreUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	
	namespace theBiasPlanet {
		namespace coreUtilities {
			namespace constantsGroups {
				class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ CharactersSetNamesConstantsGroup {
					public:
						static string const c_utf8CharactersSetName;
						static string const c_utf8InputStreamReaderReturningCharactersSetName;
				};
			}
		}
	}
#endif

