#ifndef __theBiasPlanet_coreUtilities_inputs_PushableReader_hpp__
	#define __theBiasPlanet_coreUtilities_inputs_PushableReader_hpp__
	
	#include <istream>
	#include "theBiasPlanet/coreUtilities/constantsGroups/GeneralConstantsConstantsGroup.hpp"
	#include "theBiasPlanet/coreUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	using namespace ::theBiasPlanet::coreUtilities::constantsGroups;
	
	namespace theBiasPlanet {
		namespace coreUtilities {
			namespace inputs {
				class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ PushableReader {
					private:
						istream * i_underlyingStream;
						int i_bufferSize;
						char * i_buffer;
						int i_characterStartIndex = GeneralConstantsConstantsGroup::c_iterationStartNumber;
						int i_characterUntilIndex = GeneralConstantsConstantsGroup::c_iterationStartNumber;
						char i_inMethodBuffer [1];
						int readFromBuffer (char * const a_characters, int const & a_offset, int const & a_length);
					public:
						PushableReader (istream * const a_underlyingStream, int const & a_bufferSize);
						virtual ~PushableReader ();
						virtual int readFixedLengthData (char * const a_characters, int const & a_offset, int const & a_length);
						virtual int read ();
						virtual void pushData (char const * const a_characters, int const & a_offset, int const & a_length);
						virtual void pushData (char const & a_character);
						// return: the number of skipped white spaces
						virtual int skipWhiteSpaces ();
						// return: the number of skipped characters
						virtual int skipThrough (string const & a_throughString);
						// return: the number of skipped characters
						virtual int skipWhiteSpacesAndFromThroughAreas (string const & a_fromString, string const & a_throughString);
				};
			}
		}
	}
#endif

