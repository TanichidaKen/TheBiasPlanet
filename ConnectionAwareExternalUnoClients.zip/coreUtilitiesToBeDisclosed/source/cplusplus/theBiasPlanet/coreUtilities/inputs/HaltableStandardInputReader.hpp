#ifndef __theBiasPlanet_coreUtilities_inputs_HaltableStandardInputReader_hpp__
	#define __theBiasPlanet_coreUtilities_inputs_HaltableStandardInputReader_hpp__
	
	#include <istream>
	#include "theBiasPlanet/coreUtilities/constantsGroups/DefaultValuesConstantsGroup.hpp"
	#include "theBiasPlanet/coreUtilities/inputs/HaltableReader.hpp"
	#include "theBiasPlanet/coreUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	
	namespace theBiasPlanet {
		namespace coreUtilities {
			namespace inputs {
				class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ HaltableStandardInputReader: public HaltableReader {
					private:
						static HaltableStandardInputReader * s_singletonInstance;
						HaltableStandardInputReader ();
					public:
						~HaltableStandardInputReader ();
						static HaltableStandardInputReader & getInstance ();
				};
			}
		}
	}
#endif

