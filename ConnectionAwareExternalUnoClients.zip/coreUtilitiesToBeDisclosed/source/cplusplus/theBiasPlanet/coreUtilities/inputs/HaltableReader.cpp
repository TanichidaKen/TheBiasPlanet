#include "theBiasPlanet/coreUtilities/inputs/HaltableReader.hpp"
#include <exception>
#include <sstream>
#include "theBiasPlanet/coreUtilities/constantsGroups/DefaultValuesConstantsGroup.hpp"
#include "theBiasPlanet/coreUtilities/inputsHandling/NoMoreDataException.hpp"
#include "theBiasPlanet/coreUtilities/inputsHandling/NoMoreNeedsException.hpp"
#include "theBiasPlanet/coreUtilities/messagingHandling/Publisher.hpp"

using namespace ::theBiasPlanet::coreUtilities::inputsHandling;
using namespace ::theBiasPlanet::coreUtilities::messagingHandling;

namespace theBiasPlanet {
	namespace coreUtilities {
		namespace inputs {
			HaltableReader::HaltableReader (istream * const a_underlyingReader, int const & a_bufferSize) : i_underlyingReader (a_underlyingReader), i_bufferSize (a_bufferSize) {
			}
			
			HaltableReader::~HaltableReader () {
			}
			
			void HaltableReader::addSubscriber (string const & a_subscriberIdentification) {
				unique_lock <shared_mutex> l_exclusiveLock (i_sharableMutex);
				i_subscriberIdentificationToStringPipeMap.insert (make_pair (a_subscriberIdentification, new StringPipe (i_bufferSize, false)));
			}
			
			void HaltableReader::removeSubscriber (string const & a_subscriberIdentification) {
				{
					shared_lock <shared_mutex> l_sharedLock (i_sharableMutex);
					StringPipe * l_stringPipe = i_subscriberIdentificationToStringPipeMap.at (a_subscriberIdentification);
					if (l_stringPipe != nullptr) {
						l_stringPipe->finishWriting ();
					}
				}
				{
					unique_lock <shared_mutex> l_exclusiveLock (i_sharableMutex);
					i_subscriberIdentificationToStringPipeMap.erase (a_subscriberIdentification);
				}
			}
			
			void HaltableReader::startDispatchDataThread () {
				if (! (i_dispatchDataThread.has_value ())) {
					i_dispatchDataThread = thread ( [this] () -> void {
						try {
							char l_inputData [DefaultValuesConstantsGroup::c_smallBufferSize];
							int l_inputDataLength = -1;
							while (i_underlyingReader->good ()) {
								i_underlyingReader->read (l_inputData, DefaultValuesConstantsGroup::c_smallBufferSize);
								l_inputDataLength = i_underlyingReader->gcount ();
								istringstream l_inputDataReader (string (l_inputData, l_inputDataLength));
								{
									shared_lock <shared_mutex> l_sharedLock (i_sharableMutex);
									NavigableLinkedMap <string, StringPipe *>::iterator l_subscriberIdentificationToStringPipeMapIterator (i_subscriberIdentificationToStringPipeMap.begin ());
									NavigableLinkedMap <string, StringPipe *>::iterator l_subscriberIdentificationToStringPipeMapIteratorAtEnd (i_subscriberIdentificationToStringPipeMap.end ());
									for (; l_subscriberIdentificationToStringPipeMapIterator != l_subscriberIdentificationToStringPipeMapIteratorAtEnd; l_subscriberIdentificationToStringPipeMapIterator ++) {
										try {
											l_subscriberIdentificationToStringPipeMapIterator->second->writeWholeString (&l_inputDataReader);
										}
										catch (NoMoreNeedsException & l_exception) {
										}
									}
								}
							}
						}
						catch (exception & l_exception) {
							Publisher::logErrorInformation (l_exception);
						}
						{
							shared_lock <shared_mutex> l_sharedLock (i_sharableMutex);
							NavigableLinkedMap <string, StringPipe *>::iterator l_subscriberIdentificationToStringPipeMapIterator (i_subscriberIdentificationToStringPipeMap.begin ());
							NavigableLinkedMap <string, StringPipe *>::iterator l_subscriberIdentificationToStringPipeMapIteratorAtEnd (i_subscriberIdentificationToStringPipeMap.end ());
							for (; l_subscriberIdentificationToStringPipeMapIterator != l_subscriberIdentificationToStringPipeMapIteratorAtEnd; l_subscriberIdentificationToStringPipeMapIterator ++) {
								l_subscriberIdentificationToStringPipeMapIterator->second->finishWriting ();
							}
						}
					});
				}
			}
			
			string HaltableReader::read (string const & a_subscriberIdentification, int const & a_maximumLength, int const & a_timeOutPeriodInMilliseconds) {
				StringPipe * l_stringPipe = nullptr;
				{
					shared_lock <shared_mutex> l_sharedLock (i_sharableMutex);
					try {
						l_stringPipe = i_subscriberIdentificationToStringPipeMap.at (a_subscriberIdentification);
					}
					catch (out_of_range & l_exception) {
					}
				}
				if (l_stringPipe != nullptr) {
					return l_stringPipe->readString (a_maximumLength, a_timeOutPeriodInMilliseconds);
				}
				else {
					throw NoMoreDataException ("");
				}
			}
			
			string HaltableReader::readLine (string const & a_subscriberIdentification, int const & a_maximumLength, int const & a_timeOutPeriodInMilliseconds) {
				StringPipe * l_stringPipe = nullptr;
				{
					shared_lock <shared_mutex> l_sharedLock (i_sharableMutex);
					try {
						l_stringPipe = i_subscriberIdentificationToStringPipeMap.at (a_subscriberIdentification);
					}
					catch (out_of_range & l_exception) {
					}
				}
				if (l_stringPipe != nullptr) {
					return l_stringPipe->readStringLine (a_maximumLength, a_timeOutPeriodInMilliseconds);
				}
				else {
					throw new NoMoreDataException ("");
				}
			}
			
			bool HaltableReader::isReady (string const & a_subscriberIdentification) {
				StringPipe * l_stringPipe = nullptr;
				{
					shared_lock <shared_mutex> l_sharedLock (i_sharableMutex);
					try {
						l_stringPipe = i_subscriberIdentificationToStringPipeMap.at (a_subscriberIdentification);
					}
					catch (out_of_range & l_exception) {
					}
				}
				if (l_stringPipe != nullptr) {
					return ! (l_stringPipe->isEmpty ());
				}
				else {
					return false;
				}
			}
		}
	}
}

