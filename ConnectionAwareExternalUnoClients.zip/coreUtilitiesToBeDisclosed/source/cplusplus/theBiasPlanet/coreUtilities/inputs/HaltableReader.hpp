#ifndef __theBiasPlanet_coreUtilities_inputs_HaltableReader_hpp__
	#define __theBiasPlanet_coreUtilities_inputs_HaltableReader_hpp__
	
	#include <istream>
	#include <optional>
	#include <shared_mutex>
	#include <string>
	#include <thread>
	#include "theBiasPlanet/coreUtilities/collections/NavigableLinkedMap.hpp"
	#include "theBiasPlanet/coreUtilities/constantsGroups/GeneralConstantsConstantsGroup.hpp"
	#include "theBiasPlanet/coreUtilities/pipes/StringPipe.hpp"
	#include "theBiasPlanet/coreUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	using namespace ::theBiasPlanet::coreUtilities::constantsGroups;
	using namespace ::theBiasPlanet::coreUtilities::pipes;
	
	namespace theBiasPlanet {
		namespace coreUtilities {
			namespace inputs {
				class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ HaltableReader {
					private:
						istream * i_underlyingReader;
						int i_bufferSize;
						optional <thread> i_dispatchDataThread;
						NavigableLinkedMap <string, StringPipe *> i_subscriberIdentificationToStringPipeMap;
						shared_mutex i_sharableMutex;
					public:
						HaltableReader (istream * const a_underlyingReader, int const & a_bufferSize);
						virtual ~HaltableReader ();
						// Any subscriber has to read consistently, or the other subscribers may be stuck because the dispatching thread will be stuck waiting to write to the string pipe for the neglecting subscriber.
						virtual void addSubscriber (string const & a_subscriberIdentification);
						virtual void removeSubscriber (string const & a_subscriberIdentification);
						virtual void startDispatchDataThread ();
						virtual string read (string const & a_subscriberIdentification, int const & a_maximumLength, int const & a_timeOutPeriodInMilliseconds = -1);
						virtual string readLine (string const & a_subscriberIdentification, int const & a_maximumLength, int const & a_timeOutPeriodInMilliseconds = -1);
						virtual bool isReady (string const & a_subscriberIdentification);
				};
			}
		}
	}
#endif

