#ifndef __theBiasPlanet_coreUtilities_inputsHandling_TimeOutException_hpp__
	#define __theBiasPlanet_coreUtilities_inputsHandling_TimeOutException_hpp__
	
	#include <exception>
	#include <string>
	#include "theBiasPlanet/coreUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	
	namespace theBiasPlanet {
		namespace coreUtilities {
			namespace timersHandling {
				class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ TimeOutException : public exception {
					private:
						string i_message;
					public:
						TimeOutException (string a_message);
						virtual ~TimeOutException ();
						virtual char const * what () const throw () override;
				};
			}
		}
	}
#endif

