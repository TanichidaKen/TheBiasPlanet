#ifndef __theBiasPlanet_coreUtilities_stringsHandling_StringHandler_hpp__
	#define __theBiasPlanet_coreUtilities_stringsHandling_StringHandler_hpp__
	
	#include <chrono>
	#include <codecvt>
	#include <list>
	#include <optional>
	#include <regex>
	#include <sstream>
	#include <string>
	#include "theBiasPlanet/coreUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	using namespace ::std::chrono;
	
	namespace theBiasPlanet {
		namespace coreUtilities {
			namespace stringsHandling {
				class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ StringHandler {
					private:
						#ifdef GCC
							static wstring_convert <codecvt_utf8_utf16 <char16_t>, char16_t> c_wstringConverter;
						#else
							static wstring_convert <codecvt_utf8_utf16 <wchar_t>, wchar_t> c_wstringConverter;
						#endif
						static regex const c_environmentVariableRegularExpression;
					public:
						class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ ParsedUrl {
							private:
								string i_protocol;
								string i_localPath;
							public:
								ParsedUrl (string const & a_url);
								virtual ~ParsedUrl ();
								virtual string const & getProtocol ();
								virtual string const & getLocalPath ();
						};
						static u16string getUtf16String (string const & a_utf8String);
						static string getUtf8String (u16string const & a_utf16String);
						static string getString (unsigned char const * a_charactersArray, int const & a_charactersArrayLength);
						static string getString (list <string> const & a_object, optional <string> const & a_delimiter);
						template <typename T, typename ... U> static ostringstream * format (ostringstream * const a_resultStream, istringstream * const a_formatStream, T const & a_currentItem, U const & ... a_remainderItems);
						static ostringstream * format (ostringstream * a_resultStream, istringstream * a_formatStream);
						template <typename T, typename ... U> static string format (string const & a_formatString, T const & a_currentItem, U const & ... a_remainderItems);
						template <typename T, typename ... U> static ostringstream * format (ostringstream * const a_resultStream, istringstream * const a_formatStream, time_point <T> const & a_currentItem, U const & ... a_remainderItems);
						template <typename T, typename ... U> static string format (string const & a_formatString, time_point <T> const & a_currentItem, U const & ... a_remainderItems);
						template <typename ... U> static ostringstream * format (ostringstream * const a_resultStream, istringstream * const a_formatStream, time_point <system_clock> const & a_currentItem, U const & ... a_remainderItems);
						template <typename ... U> static string format (string const & a_formatString, time_point <system_clock> const & a_currentItem, U const & ... a_remainderItems);
						static string & replaceAll (string * a_targetString, regex const & a_stringFragmentToBeReplacedRegularExpression, string const & a_stringFragmentThatReplaces);
						static string getThousandsSeparatedLongString (long const & a_long);
						static string getDateAndTimeString (time_t const & a_dateAndTime);
						static string createUnNullifiedString (char const * const a_originalCharactersArray);
						static string effectuateEnvironmentVariables (string const & a_originalString);
						static bool validateAsUrl (string const & a_string);
				};
			}
		}
	}
#endif

