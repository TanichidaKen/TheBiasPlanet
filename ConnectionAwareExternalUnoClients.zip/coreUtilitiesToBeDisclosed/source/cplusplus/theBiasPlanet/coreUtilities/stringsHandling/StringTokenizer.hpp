#ifndef __theBiasPlanet_coreUtilities_stringsHandling_StringTokenizer_hpp__
	#define __theBiasPlanet_coreUtilities_stringsHandling_StringTokenizer_hpp__
	
	#include <optional>
	#include <list>
	#include <sstream>
	#include <string>
	#include "theBiasPlanet/coreUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	
	namespace theBiasPlanet {
		namespace coreUtilities {
			namespace stringsHandling {
				class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ StringTokenizer {
					private:
						stringstream i_originalStringStream;
						string const i_delimiter;
						list <string> i_tokens;
						int i_numberOfTokens;
						list <string>::iterator i_tokensIterator;
						int i_currentIndex;
						virtual optional <string> getNextToken ();
					public:
						StringTokenizer (string const & a_targetString, string const a_delimiter);
						virtual int countTokens ();
						virtual bool hasMoreTokens ();
						virtual optional <string> nextToken ();
				};
			}
		}
	}
#endif

