#ifndef __theBiasPlanet_coreUtilities_clipboardHandling_ClipboardFormatSpecificDatum_hpp__
	#define __theBiasPlanet_coreUtilities_clipboardHandling_ClipboardFormatSpecificDatum_hpp__
	
	#include <string>
	#include "theBiasPlanet/coreUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	namespace theBiasPlanet {
		namespace coreUtilities {
			namespace clipboardHandling {
				class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ ClipboardFormatSpecificDatum {
					private:
						::std::string i_formatName;
						unsigned int i_formatNumber;
						bool i_datumIsArray;
						int i_datumSize;
						void * i_datum;
					public:
						ClipboardFormatSpecificDatum ();
						ClipboardFormatSpecificDatum (::std::string const & a_formatName, unsigned int const & a_formatNumber, bool const & a_datumIsArray, int const & a_datumSize, void * const a_datum);
						virtual ~ClipboardFormatSpecificDatum ();
						ClipboardFormatSpecificDatum (ClipboardFormatSpecificDatum const & a_copiedObject) = delete; // because the datum is not meant to be shared by multiple instances
						virtual ClipboardFormatSpecificDatum & operator = (ClipboardFormatSpecificDatum const & a_assignedFromObject) = delete; // because the datum is not meant to be shared by multiple instances
						virtual ::std::string const & getFormatName () const;
						virtual unsigned int const & getFormatNumber () const;
						virtual int const & getDatumSize () const;
						virtual void * const getDatum () const;
				};
			}
		}
	}
#endif

