#include "theBiasPlanet/coreUtilities/clipboardHandling/ClipboardFormatSpecificDataComposite.hpp"

namespace theBiasPlanet {
	namespace coreUtilities {
		namespace clipboardHandling {
			ClipboardFormatSpecificDataComposite::ClipboardFormatSpecificDataComposite () {
			}
			
			ClipboardFormatSpecificDataComposite::~ClipboardFormatSpecificDataComposite () {
				for (::std::pair <::std::string const, ClipboardFormatSpecificDatum const *> const & l_formatNameToDatumMapEntry: i_formatNameToDatumMap) {
					delete l_formatNameToDatumMapEntry.second;
				}
			}
			
			/*
			ClipboardFormatSpecificDataComposite::ClipboardFormatSpecificDataComposite (ClipboardFormatSpecificDataComposite const & a_copiedObject): i_formatNameToDatumMap (a_copiedObject.i_formatNameToDatumMap) {
			}
			*/
			
			/*
			ClipboardFormatSpecificDataComposite & ClipboardFormatSpecificDataComposite::operator = (ClipboardFormatSpecificDataComposite const & a_assignedFromObject) {
				i_formatNameToDatumMap = a_assignedFromObject.i_formatNameToDatumMap;
				return *this;
			}
			*/
			
			bool ClipboardFormatSpecificDataComposite::addFormatSpecificDatum (ClipboardFormatSpecificDatum const * const a_formatSpecificDatum) {
				i_formatNameToDatumMap [a_formatSpecificDatum->getFormatName ()] = a_formatSpecificDatum;
				return true;
			}
			
			::std::list <::std::string> ClipboardFormatSpecificDataComposite::getFormatNames () const {
				::std::list <::std::string> l_formatNames;
				for (::std::pair <::std::string const, ClipboardFormatSpecificDatum const *> const & l_formatNameToDatumMapEntry: i_formatNameToDatumMap) {
					l_formatNames.push_back (l_formatNameToDatumMapEntry.first);
				}
				return l_formatNames;
			}
			
			ClipboardFormatSpecificDatum const * const ClipboardFormatSpecificDataComposite::getFormatSpecificDatum (::std::string const & a_formatName) const {
				return i_formatNameToDatumMap.at (a_formatName);
			}
		}
	}
}

