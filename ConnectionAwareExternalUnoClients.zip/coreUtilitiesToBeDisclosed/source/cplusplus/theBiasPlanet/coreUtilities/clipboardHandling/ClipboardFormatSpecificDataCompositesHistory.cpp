#include "theBiasPlanet/coreUtilities/clipboardHandling/ClipboardFormatSpecificDataCompositesHistory.hpp"

namespace theBiasPlanet {
	namespace coreUtilities {
		namespace clipboardHandling {
			ClipboardFormatSpecificDataCompositesHistory::ClipboardFormatSpecificDataCompositesHistory () {
			}
			
			ClipboardFormatSpecificDataCompositesHistory::~ClipboardFormatSpecificDataCompositesHistory () {
				for (::std::pair <string const, ClipboardFormatSpecificDataComposite const *> const & l_dataCompositeKeyToDataCompositeMapEntry: i_dataCompositeKeyToDataCompositeMap) {
					delete l_dataCompositeKeyToDataCompositeMapEntry.second;
				}
			}
			
			/*
			ClipboardFormatSpecificDataCompositesHistory::ClipboardFormatSpecificDataCompositesHistory (ClipboardFormatSpecificDataCompositesHistory const & a_copiedObject): i_dataCompositeKeyToDataCompositeMap (a_copiedObject.i_dataCompositeKeyToDataCompositeMap) {
			}
			*/
			
			/*
			ClipboardFormatSpecificDataCompositesHistory & ClipboardFormatSpecificDataCompositesHistory::operator = (ClipboardFormatSpecificDataCompositesHistory const & a_assignedFromObject) {
				i_dataCompositeKeyToDataCompositeMap = a_assignedFromObject.i_dataCompositeKeyToDataCompositeMap;
				return *this;
			}
			*/
			
			bool ClipboardFormatSpecificDataCompositesHistory::addDataComposite (string const & a_dataCompositeKey, ClipboardFormatSpecificDataComposite const * const a_dataComposite) {
				i_dataCompositeKeyToDataCompositeMap [a_dataCompositeKey] = a_dataComposite;
				return true;
			}
			
			bool ClipboardFormatSpecificDataCompositesHistory::removeDataComposite (string const & a_dataCompositeKey) {
				delete i_dataCompositeKeyToDataCompositeMap.at (a_dataCompositeKey);
				i_dataCompositeKeyToDataCompositeMap.erase (i_dataCompositeKeyToDataCompositeMap.find (a_dataCompositeKey));
				return true;
			}
			
			ClipboardFormatSpecificDataComposite const * const ClipboardFormatSpecificDataCompositesHistory::getDataComposite (string const & a_dataCompositeKey) {
				return i_dataCompositeKeyToDataCompositeMap.at (a_dataCompositeKey);
			}
		}
	}
}

