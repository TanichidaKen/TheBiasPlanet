#include "theBiasPlanet/coreUtilities/clipboardHandling/ClipboardFormatSpecificDatum.hpp"

namespace theBiasPlanet {
	namespace coreUtilities {
		namespace clipboardHandling {
			ClipboardFormatSpecificDatum::ClipboardFormatSpecificDatum () {
			}
			
			ClipboardFormatSpecificDatum::ClipboardFormatSpecificDatum (::std::string const & a_formatName, unsigned int const & a_formatNumber, bool const & a_datumIsArray, int const & a_datumSize, void * const a_datum): i_formatName (a_formatName), i_formatNumber (a_formatNumber), i_datumIsArray (a_datumIsArray), i_datumSize (a_datumSize), i_datum (a_datum) {
			}
			
			ClipboardFormatSpecificDatum::~ClipboardFormatSpecificDatum () {
				if (i_datumIsArray) {
					delete [] i_datum;
				}
				else {
					delete i_datum;
				}
			}
			
			/*
			ClipboardFormatSpecificDatum::ClipboardFormatSpecificDatum (ClipboardFormatSpecificDatum const & a_copiedObject): i_formatName (a_copiedObject.i_formatName), i_formatNumber (a_copiedObject.i_formatNumber), i_datumIsArray (a_copiedObject.i_datumIsArray), i_datumSize (a_copiedObject.i_datumSize), i_datum (a_copiedObject.i_datum) {
			}
			*/
			
			/*
			ClipboardFormatSpecificDatum & ClipboardFormatSpecificDatum::operator = (ClipboardFormatSpecificDatum const & a_assignedFromObject) {
				i_formatName = a_assignedFromObject.i_formatName;
				i_formatNumber = a_assignedFromObject.i_formatNumber;
				i_datumIsArray = a_assignedFromObject.i_datumIsArray;
				i_datumSize = a_assignedFromObject.i_datumSize;
				i_datum = a_assignedFromObject.i_datum;
				return *this;
			}
			*/
			
			::std::string const & ClipboardFormatSpecificDatum::getFormatName () const {
				return i_formatName;
			}
			
			unsigned int const & ClipboardFormatSpecificDatum::getFormatNumber () const {
				return static_cast <unsigned int const> (i_formatNumber);
			}
			
			int const & ClipboardFormatSpecificDatum::getDatumSize () const {
				return i_datumSize;
			}
			
			void * const ClipboardFormatSpecificDatum::getDatum () const {
				return i_datum;
			}
		}
	}
}

