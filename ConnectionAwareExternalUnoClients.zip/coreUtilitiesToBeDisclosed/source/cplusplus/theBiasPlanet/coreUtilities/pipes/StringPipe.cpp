#include "theBiasPlanet/coreUtilities/pipes/StringPipe.hpp"
#include <sstream>
#include "theBiasPlanet/coreUtilities/inputsHandling/NoMoreDataException.hpp"
#include "theBiasPlanet/coreUtilities/inputsHandling/NoMoreNeedsException.hpp"
#include "theBiasPlanet/coreUtilities/messagingHandling/Publisher.hpp"
#include "theBiasPlanet/coreUtilities/timersHandling/TimeOutException.hpp"

using namespace ::theBiasPlanet::coreUtilities::inputsHandling;
using namespace ::theBiasPlanet::coreUtilities::messagingHandling;
using namespace ::theBiasPlanet::coreUtilities::timersHandling;

namespace theBiasPlanet {
	namespace coreUtilities {
		namespace pipes {
			StringPipe::StringPipe (int const & a_bufferSize, bool const & a_notificationIsDelayed): ObjectsPipe (a_bufferSize, a_notificationIsDelayed) {
			}
			
			StringPipe::~StringPipe () {
			}
			
			void StringPipe::writeWholeString (istream * a_reader) {
				char l_writtenCharacter;
				while (a_reader->get (l_writtenCharacter)) {
					try {
						write (l_writtenCharacter);
					}
					catch (NoMoreNeedsException & l_exception) {
						break;
					}
				}
			}
			
			string StringPipe::readString (int a_maximumLength, long a_timeOutPeriodInMilliseconds) {
				char l_readCharacter;
				string l_readString;
				int l_readStringLength = 0;
				while (l_readStringLength < a_maximumLength) {
					try {
						if (l_readStringLength == 0) {
							l_readCharacter = read (a_timeOutPeriodInMilliseconds);
						}
						else {
							l_readCharacter = read ();
						}
					}
					catch (NoMoreDataException & l_exception) {
						if (l_readStringLength == 0) {
							throw l_exception;
						}
						break;
					}
					catch (TimeOutException & l_exception) {
						if (l_readStringLength == 0) {
							throw l_exception;
						}
						break;
					}
					l_readString.push_back (l_readCharacter);
					l_readStringLength ++;
				}
				return l_readString;
			}
			
			string StringPipe::readStringLine (int a_maximumLength, long a_timeOutPeriodInMilliseconds) {
				string l_readString;
				int l_readStringLength = 0;
				while (true) {
					try {
						char l_readCharacter (read (a_timeOutPeriodInMilliseconds));
						l_readString.push_back (l_readCharacter);
						l_readStringLength ++;
						if (l_readCharacter == GeneralConstantsConstantsGroup::c_newLineCharacter || l_readStringLength >= a_maximumLength) {
							break;
						}
					}
					catch (NoMoreDataException & l_exception) {
						if (l_readStringLength == 0) {
							throw l_exception;
						}
						break;
					}
					catch (TimeOutException & l_exception) {
						if (l_readStringLength == 0) {
							throw l_exception;
						}
						break;
					}
				}
				return l_readString;
			}
			
			string StringPipe::readWholeString () {
				char l_readCharacter;
				string l_readString;
				while (true) {
					try {
						l_readCharacter = read ();
					}
					catch (NoMoreDataException & l_exception) {
						break;
					}
					l_readString.push_back (l_readCharacter);
				}
				return l_readString;
			}
		}
	}
}

