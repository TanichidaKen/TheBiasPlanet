#include "theBiasPlanet/coreUtilities/constantsGroups/DefaultValuesConstantsGroup.hpp"
#include "theBiasPlanet/coreUtilities/constantsGroups/CharactersSetNamesConstantsGroup.hpp"
#include "theBiasPlanet/coreUtilities/constantsGroups/FileNameSuffixesConstantsGroup.hpp"
#include "theBiasPlanet/coreUtilities/constantsGroups/GeneralConstantsConstantsGroup.hpp"
#include "theBiasPlanet/coreUtilities/constantsGroups/RegularExpressionsConstantsGroup.hpp"
#include "theBiasPlanet/coreUtilities/cryptographyHandling/Hasher.hpp"
#include "theBiasPlanet/coreUtilities/inputs/HaltableStandardInputReader.hpp"
#include "theBiasPlanet/coreUtilities/jsonDataHandling/ExtendedJsonDatumParser.hpp"
#include "theBiasPlanet/coreUtilities/messagingHandling/Publisher.hpp"
#include "theBiasPlanet/coreUtilities/performanceMeasuringHandling/PerformanceMeasurer.hpp"
#include "theBiasPlanet/coreUtilities/processesHandling/ProcessHandler.hpp"
#ifdef GCC
	#include <sys/types.h>
	#include <unistd.h>
#else
	#include <process.h>
#endif
#include "theBiasPlanet/coreUtilities/stringsHandling/StringHandler.hpp"

using namespace ::theBiasPlanet::coreUtilities::stringsHandling;

namespace theBiasPlanet {
	namespace coreUtilities {
		namespace constantsGroups {
			int const DefaultValuesConstantsGroup::c_smallBufferSize;
			int const DefaultValuesConstantsGroup::c_largeBufferSize (102400);
			int const DefaultValuesConstantsGroup::c_smallestBufferSize (1);
			string const CharactersSetNamesConstantsGroup::c_utf8CharactersSetName ("UTF-8");
			string const CharactersSetNamesConstantsGroup::c_utf8InputStreamReaderReturningCharactersSetName ("UTF8");
			string const FileNameSuffixesConstantsGroup::c_xmlFileNameSuffix ("xml");
			string const FileNameSuffixesConstantsGroup::c_styleSheetFileNameSuffix ("xslt");
			string const FileNameSuffixesConstantsGroup::c_jarFileNameSuffix ("jar");
			string const FileNameSuffixesConstantsGroup::c_javaFileNameSuffix ("java");
			string const FileNameSuffixesConstantsGroup::c_saveFileNameSuffix ("save");
			int const GeneralConstantsConstantsGroup::GeneralConstantsConstantsGroup::c_maximumBytesLengthPerUtf8Character (4);
			int const GeneralConstantsConstantsGroup::c_numberOfAlphabets (26);
			int const GeneralConstantsConstantsGroup::c_unspecifiedInteger (-1);
			float const GeneralConstantsConstantsGroup::c_unspecifiedFloat (-1.0f);
			char const GeneralConstantsConstantsGroup::c_unspecifiedCharacter ((char) 0);
			int const GeneralConstantsConstantsGroup::c_iterationStartNumber (0);
			int const GeneralConstantsConstantsGroup::c_normalResult (0);
			string const GeneralConstantsConstantsGroup::c_emptyString ("");
			char const GeneralConstantsConstantsGroup::c_radixPointCharacter ('.');
			char const GeneralConstantsConstantsGroup::c_thousandsDelimiter (',');
			char const GeneralConstantsConstantsGroup::c_minimumDigit ('0');
			char const GeneralConstantsConstantsGroup::c_maximumDigit ('9');
			char const GeneralConstantsConstantsGroup::c_plusCharacter ('+');
			char const GeneralConstantsConstantsGroup::c_minusCharacter ('-');
			char const GeneralConstantsConstantsGroup::c_exponentOpener1 ('E');
			char const GeneralConstantsConstantsGroup::c_exponentOpener2 ('e');
			char const GeneralConstantsConstantsGroup::c_unicodeEscapeIndicator ('u');
			char const GeneralConstantsConstantsGroup::c_escapingCharacter ('\\');
			char const GeneralConstantsConstantsGroup::c_newLineCharacter ('\n');
			char const GeneralConstantsConstantsGroup::c_carriageReturnCharacter ('\r');
			char const GeneralConstantsConstantsGroup::c_tabCharacter ('\t');
			char const GeneralConstantsConstantsGroup::c_backspaceCharacter ('\b');
			char const GeneralConstantsConstantsGroup::c_formFeedCharacter ('\f');
			char const GeneralConstantsConstantsGroup::c_colonCharacter (':');
			char const GeneralConstantsConstantsGroup::c_semicolonCharacter (';');
			char const GeneralConstantsConstantsGroup::c_spaceCharacter (' ');
			char const GeneralConstantsConstantsGroup::c_equalCharacter ('=');
			string const GeneralConstantsConstantsGroup::c_utfBomCharacter ("\uFEFF");
			char const GeneralConstantsConstantsGroup::c_lessThanCharacter ('<');
			char const GeneralConstantsConstantsGroup::c_greaterThanCharacter ('>');
			char const GeneralConstantsConstantsGroup::c_ampersandCharacter ('&');
			char const GeneralConstantsConstantsGroup::c_doubleQuotationMarkCharacter ('\"');
			char const GeneralConstantsConstantsGroup::c_apostropheCharacter ('\'');
			char const GeneralConstantsConstantsGroup::c_controlCharactersStart (0x00);
			char const GeneralConstantsConstantsGroup::c_controlCharactersUntil (0x20);
			char const GeneralConstantsConstantsGroup::c_argumentsDelimiter (' ');
			string const GeneralConstantsConstantsGroup::c_carriageReturnAndNewLineString (StringHandler::format (string ("%c%c"), c_carriageReturnCharacter, c_newLineCharacter));
			string const GeneralConstantsConstantsGroup::c_notANumberExpression ("NaN");
			string const GeneralConstantsConstantsGroup::c_positiveInfinityExpression ("Infinity");
			string const GeneralConstantsConstantsGroup::c_negativeInfinityExpression (StringHandler::format (string ("%c%s"), c_minusCharacter, c_positiveInfinityExpression));
			string const GeneralConstantsConstantsGroup::c_nullExpression ("null");
			string const GeneralConstantsConstantsGroup::c_trueExpression ("true");
			string const GeneralConstantsConstantsGroup::c_falseExpression ("false");
			string const GeneralConstantsConstantsGroup::c_isoDateAndTimeExpression ("%Y-%m-%dT%H:%M:%S");
			string const GeneralConstantsConstantsGroup::c_isoDateExpression ("%Y-%m-%d");
			string const GeneralConstantsConstantsGroup::c_isoTimeExpression ("%H:%M:%S");
			string const GeneralConstantsConstantsGroup::c_colonDelimiter (": ");
			string const GeneralConstantsConstantsGroup::c_commaDelimiter (", ");
			char const GeneralConstantsConstantsGroup::c_linuxDirectoriesDelimiter ('/');
			char const GeneralConstantsConstantsGroup::c_windowsDirectoriesDelimiter ('\\');
			char const GeneralConstantsConstantsGroup::c_javaPackagesDelimiter ('.');
			char const GeneralConstantsConstantsGroup::c_fileNameElementsDelimiter ('.');
			char const GeneralConstantsConstantsGroup::c_nameElementsDelimiter ('_');
			char const GeneralConstantsConstantsGroup::c_linuxPathsDelimiter (':');
			char const GeneralConstantsConstantsGroup::c_windowsPathsDelimiter (';');
			char const GeneralConstantsConstantsGroup::c_dataCommentLineStarter ('#');
			string const GeneralConstantsConstantsGroup::c_jsonItemsSeparator (c_commaDelimiter);
			string const GeneralConstantsConstantsGroup::c_jsonKeyValueSeparator (c_colonDelimiter);
			char const GeneralConstantsConstantsGroup::c_jsonItemsSeparatorOpener (c_jsonItemsSeparator [c_iterationStartNumber]);
			char const GeneralConstantsConstantsGroup::c_jsonKeyValueSeparatorOpener (c_jsonKeyValueSeparator [c_iterationStartNumber]);
			char const GeneralConstantsConstantsGroup::c_jsonDictionaryOpener ('{');
			char const GeneralConstantsConstantsGroup::c_jsonDictionaryCloser ('}');
			char const GeneralConstantsConstantsGroup::c_jsonArrayOpener ('[');
			char const GeneralConstantsConstantsGroup::c_jsonArrayCloser (']');
			char const GeneralConstantsConstantsGroup::c_jsonDateEtcOpener ('d');
			char const GeneralConstantsConstantsGroup::c_jsonDateAndTimeTimePartOpener ('T');
			char const GeneralConstantsConstantsGroup::c_jsonBytesArrayOpener ('b');
			string const GeneralConstantsConstantsGroup::c_integerDefaultFormat ("%d");
			string const GeneralConstantsConstantsGroup::c_doubleDefaultFormat ("%f");
			string const GeneralConstantsConstantsGroup::c_booleanDefaultFormat ("%b");
			string const GeneralConstantsConstantsGroup::c_hexadecimalStringFormat ("0x%s");
			string const GeneralConstantsConstantsGroup::c_globExpressionFormat ("glob:%s");
			string const GeneralConstantsConstantsGroup::c_commandSwitchOrFlagStarter ("-");
			string const GeneralConstantsConstantsGroup::c_linuxDirectoryPathFormat (StringHandler::format (string ("%%s%s%%s"), GeneralConstantsConstantsGroup::c_linuxDirectoriesDelimiter));
			string const GeneralConstantsConstantsGroup::c_windowsDirectoryPathFormat (StringHandler::format (string ("%%s%s%%s"), GeneralConstantsConstantsGroup::c_windowsDirectoriesDelimiter));
			string const GeneralConstantsConstantsGroup::c_linuxFilePathFormat (StringHandler::format (string ("%%s%s%%s"), GeneralConstantsConstantsGroup::c_linuxDirectoriesDelimiter));
			string const GeneralConstantsConstantsGroup::c_windowsFilePathFormat (StringHandler::format (string ("%%s%s%%s"), GeneralConstantsConstantsGroup::c_windowsDirectoriesDelimiter));
			string const GeneralConstantsConstantsGroup::c_fileNameFormat (StringHandler::format (string ("%%s%s%%s"), GeneralConstantsConstantsGroup::c_fileNameElementsDelimiter));
			string const GeneralConstantsConstantsGroup::c_javaClassNameFormat (StringHandler::format (string ("%%s%s%%s"), GeneralConstantsConstantsGroup::c_javaPackagesDelimiter));
			string const GeneralConstantsConstantsGroup::c_styleSheetFileNameFormat (StringHandler::format (string ("%%s%s%s"), GeneralConstantsConstantsGroup::c_fileNameElementsDelimiter, FileNameSuffixesConstantsGroup::c_styleSheetFileNameSuffix));
			string const GeneralConstantsConstantsGroup::c_javaFileNameFormat (StringHandler::format (string ("%%s%s%s"), GeneralConstantsConstantsGroup::c_fileNameElementsDelimiter, FileNameSuffixesConstantsGroup::c_javaFileNameSuffix));
			string const GeneralConstantsConstantsGroup::c_quotedByDoubleQuotationsFormat ("\"%s\"");
			string const GeneralConstantsConstantsGroup::c_quotedByAngleBracketsFormat ("<%s>");
			string const GeneralConstantsConstantsGroup::c_definitionNameFormat (StringHandler::format ("%1$s%1$s%%s%1$s%1$s", GeneralConstantsConstantsGroup::c_nameElementsDelimiter));
			string const GeneralConstantsConstantsGroup::c_plus ("+");
			string const GeneralConstantsConstantsGroup::c_propertyValueFormat ("${%s}");
			NavigableLinkedMap <string, string> const GeneralConstantsConstantsGroup::c_escapedCharacterToCharacterMap { {string ("\\\\"), string ("\\")}, {string ("\\\""), string ("\"")}, {string ("\\b"), string ("\b")}, {string ("\\f"), string ("\f")}, {string ("\\n"), string ("\n")}, {string ("\\r"), string ("\r")}, {string ("\\t"), string ("\t")}};
			NavigableLinkedMap <char, int> const GeneralConstantsConstantsGroup::c_alphabetToAlphabetIndexMap { {'A', 0}, {'B', 1}, {'C', 2}, {'D', 3}, {'E', 4}, {'F', 5}, {'G', 6}, {'H', 7}, {'I', 8}, {'J', 9}, {'K', 10}, {'L', 11}, {'M', 12}, {'N', 13}, {'O', 14}, {'P', 15}, {'Q', 16}, {'R', 17}, {'S', 18}, {'T', 19}, {'U', 20}, {'V', 21}, {'W', 22}, {'X', 23}, {'Y', 24}, {'Z', 25}};
			NavigableLinkedMap <int, char> const GeneralConstantsConstantsGroup::c_alphabetIndexToAlphabetMap { {0, 'A'}, {1, 'B'}, {2, 'C'}, {3, 'D'}, {4, 'E'}, {5, 'F'}, {6, 'G'}, {7, 'H'}, {8, 'I'}, {9, 'J'}, {10, 'K'}, {11, 'L'}, {12, 'M'}, {13, 'N'}, {14, 'O'}, {15, 'P'}, {16, 'Q'}, {17, 'R'}, {18, 'S'}, {19, 'T'}, {20, 'U'}, {21, 'V'}, {22, 'W'}, {23, 'X'}, {24, 'Y'}, {25, 'Z'}};
			regex const RegularExpressionsConstantsGroup::c_cProgramTraceOutputLineRegularExpression ("(#.*: )(.*)\\((.*)\\+0x(.*)\\) \\[(.*)\\] (.*)");
			regex const RegularExpressionsConstantsGroup::c_nmOutputLineRegularExpression ("(.*) (.*) (.*)");
			regex const RegularExpressionsConstantsGroup::c_addr2lineOutputSecondLineRegularExpression ("(.*):(.*)");
			regex const RegularExpressionsConstantsGroup::c_numbersRegularExpression ("^(\\d*|\\d{1,3}(,\\d{3})*)(\\.\\d+)?([eE][-+]?\\d+)?$");
			regex const RegularExpressionsConstantsGroup::c_dateAndTimesRegularExpression ("(\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2})(.\\d*)?");
			regex const RegularExpressionsConstantsGroup::c_datesRegularExpression ("(\\d{4}-\\d{2}-\\d{2})");
			regex const RegularExpressionsConstantsGroup::c_timesRegularExpression ("(\\d{2}:\\d{2}:\\d{2})");
			regex const RegularExpressionsConstantsGroup::c_javaPackageDelimiterRegularExpression ("\\.");
			regex const RegularExpressionsConstantsGroup::c_windowsDirectoryDelimiterRegularExpression ("\\\\");
			regex const RegularExpressionsConstantsGroup::c_wordRegularExpression ("(\\w+)");
			regex const RegularExpressionsConstantsGroup::c_termRegularExpression ("(\\S+)");
			regex const RegularExpressionsConstantsGroup::c_doubleQuotedTermRegularExpression ("\"(\\S+)\"");
			regex const RegularExpressionsConstantsGroup::c_urlRegularExpression ("(\\b(https?|ftp|file)://)?[-A-Za-z0-9+&@#/%?=~_|!:,.;]+[-A-Za-z0-9+&@#/%=~_|]");
		}
		namespace cryptographyHandling {
			random_device Hasher::s_seedGenerator;
			mt19937 Hasher::s_randomNumberGenerator (s_seedGenerator ());
		}
		namespace inputs {
			HaltableStandardInputReader * HaltableStandardInputReader::s_singletonInstance (nullptr);
		}
		namespace jsonDataHandling {
			int const ExtendedJsonDatumParser::c_bufferSize (1024);
			char const ExtendedJsonDatumParser::c_notANumberExpressionOpener (GeneralConstantsConstantsGroup::c_notANumberExpression.at (GeneralConstantsConstantsGroup::c_iterationStartNumber));
			char const ExtendedJsonDatumParser::c_positiveInfinityExpressionOpener (GeneralConstantsConstantsGroup::c_positiveInfinityExpression.at (GeneralConstantsConstantsGroup::c_iterationStartNumber));
			char const ExtendedJsonDatumParser::c_negativeInfinityExpressionOpener (GeneralConstantsConstantsGroup::c_negativeInfinityExpression.at (GeneralConstantsConstantsGroup::c_iterationStartNumber));
			char const ExtendedJsonDatumParser::c_nullExpressionOpener (GeneralConstantsConstantsGroup::c_nullExpression.at (GeneralConstantsConstantsGroup::c_iterationStartNumber));
			char const ExtendedJsonDatumParser::c_trueExpressionOpener (GeneralConstantsConstantsGroup::c_trueExpression.at (GeneralConstantsConstantsGroup::c_iterationStartNumber));
			char const ExtendedJsonDatumParser::c_falseExpressionOpener (GeneralConstantsConstantsGroup::c_falseExpression.at (GeneralConstantsConstantsGroup::c_iterationStartNumber));
			string const ExtendedJsonDatumParser::c_exceptionMessageFormattingExpression ("character position: %d");
		}
		namespace messagingHandling  {
#ifdef GCC
			int const Publisher::c_processIdentification (getpid ());
#else
			int const Publisher::c_processIdentification (_getpid ());
#endif
			int const Publisher::c_functionNameMaximumLength = 16384;
			int Publisher::s_loggingLevel (0);
		}
		namespace performanceMeasuringHandling {
			steady_clock::time_point PerformanceMeasurer::s_startTime;
		}
		namespace processesHandling {
#ifdef GCC
			HaltableStandardInputReader & ProcessHandler::s_haltableStandardInputReader = [] () -> HaltableStandardInputReader & {HaltableStandardInputReader & l_haltableStandardInputReader = HaltableStandardInputReader::getInstance (); l_haltableStandardInputReader.startDispatchDataThread (); return l_haltableStandardInputReader;} ();
			//recursive_mutex ProcessHandler::s_mutex;
			//optional <thread> ProcessHandler::s_dispatchStandardInputThread;
			//NavigableLinkedMap <thread *, StringPipe *> ProcessHandler::s_relayStandardInputThreadToStringPipeMap;
#endif
		}
		namespace stringsHandling {
#ifdef GCC
			wstring_convert <codecvt_utf8_utf16 <char16_t>, char16_t> StringHandler::c_wstringConverter;
#else
			wstring_convert <codecvt_utf8_utf16 <wchar_t>, wchar_t> StringHandler::c_wstringConverter;
#endif
			regex const StringHandler::c_environmentVariableRegularExpression ("\\$\\{(.*?)\\}");
		}
	}
}

