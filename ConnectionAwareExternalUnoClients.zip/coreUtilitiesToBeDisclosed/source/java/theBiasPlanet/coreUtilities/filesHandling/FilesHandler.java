package theBiasPlanet.coreUtilities.filesHandling;

import java.time.ZonedDateTime;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.time.LocalDateTime;
import java.time.ZoneId;

public class FilesHandler {
	public static String c_exportingTokenFileName = "Exporting.token";
	
	public static Path getAbsolutePath (Path a_baseAbsolutePath, Path ... a_relativePaths) {
		Path l_absolutePath = a_baseAbsolutePath;
		if (l_absolutePath != null && a_relativePaths != null) {
			for (Path l_relativePath: a_relativePaths) {
				if (l_relativePath != null) {
					l_absolutePath = l_absolutePath.resolve (l_relativePath);
				}
			}
		}
		return l_absolutePath;
	}
	
	// the return: 'true' -> the file had existed, 'false' -> the had not existed.
	public static boolean touch (Path a_filePath) throws IOException {
		if (Files.exists (a_filePath)) {
			Files.setLastModifiedTime (a_filePath, FileTime.fromMillis (System.currentTimeMillis ()));
			return true;
		}
		else {
			Files.createFile (a_filePath);
			return false;
		}
	}
	
	public static boolean copy (Path a_sourceFilePath, Path a_destinationFilePath, boolean a_overwrite) throws IOException {
		if (!Files.exists (a_sourceFilePath)) {
			return false;
		}
		if (Files.exists (a_destinationFilePath) && !a_overwrite) {
			return false;
		}
		createDirectoryIfNecessary (a_destinationFilePath);
		Files.copy (a_sourceFilePath, a_destinationFilePath, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.COPY_ATTRIBUTES);
		return true;
	}
	
	public static boolean move (Path a_sourceFilePath, Path a_destinationFilePath, boolean a_overwrite) throws IOException {
		if (!Files.exists (a_sourceFilePath)) {
			return false;
		}
		if (Files.exists (a_destinationFilePath) && !a_overwrite) {
			return false;
		}
		createDirectoryIfNecessary (a_destinationFilePath);
		Files.move (a_sourceFilePath, a_destinationFilePath, StandardCopyOption.REPLACE_EXISTING);
		return true;
	}
	
	public static boolean delete (Path a_filePath) throws IOException {
		if (!Files.exists (a_filePath)) {
			return false;
		}
		Files.delete (a_filePath);
		return true;
	}
	
	// return: true -> created, false -> not created
	public static boolean createDirectoryIfNecessary (Path a_fileOrDirectoryPath) throws IOException {
		Path l_targetDirectoryPath = null;
		if (!Files.isDirectory (a_fileOrDirectoryPath)) {
			l_targetDirectoryPath = a_fileOrDirectoryPath.getParent ();
		}
		else {
			l_targetDirectoryPath = a_fileOrDirectoryPath;
		}
		if (l_targetDirectoryPath != null && !Files.exists (l_targetDirectoryPath)) {
			Files.createDirectories (l_targetDirectoryPath);
			return true;
		}
		return false;
	}
	
	public static LocalDateTime getFileLastModifiedDateAndTime (Path a_filePath) throws NoSuchFileException, IOException {
		try {
			BasicFileAttributes l_fileAttribues = Files.readAttributes (a_filePath, BasicFileAttributes.class);
			return (LocalDateTime.ofInstant (l_fileAttribues.lastModifiedTime ().toInstant (), ZoneId.systemDefault ()));
		}
		catch (UnsupportedOperationException l_exception) {
			return null;
		}
	}
	
	public static void setFileLastModifiedDateAndTime (Path a_filePath, LocalDateTime a_lastModifiedDateAndTime) throws NoSuchFileException, IOException {
		ZonedDateTime l_zonedDateAndTime = a_lastModifiedDateAndTime.atZone (ZoneId.systemDefault ());
		 long l_epockMilliseconds = l_zonedDateAndTime.toInstant ().toEpochMilli ();
		Files.setLastModifiedTime (a_filePath, FileTime.fromMillis (l_epockMilliseconds));
	}
	
	public static LocalDateTime getFileCreatedDateAndTime (Path a_filePath) throws NoSuchFileException, IOException {
		try {
			BasicFileAttributes l_fileAttribues = Files.readAttributes (a_filePath, BasicFileAttributes.class);
			return (LocalDateTime.ofInstant (l_fileAttribues.creationTime ().toInstant (), ZoneId.systemDefault ()));
		}
		catch (UnsupportedOperationException l_exception) {
			return null;
		}
	}
	
	public static void setFileCreatedDateAndTime (Path a_filePath, LocalDateTime a_createdDateAndTime) throws NoSuchFileException, IOException {
		try {
			ZonedDateTime l_zonedDateAndTime = a_createdDateAndTime.atZone (ZoneId.systemDefault ());
			long l_epockMilliseconds = l_zonedDateAndTime.toInstant ().toEpochMilli ();
			Files.setAttribute (a_filePath, "creationTime", FileTime.fromMillis (l_epockMilliseconds));
		}
		catch (UnsupportedOperationException l_exception) {
			return;
		}
	}
}

