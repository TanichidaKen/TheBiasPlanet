package theBiasPlanet.coreUtilities.jsonDataHandling;

import java.io.Reader;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import theBiasPlanet.coreUtilities.messagingHandling.Publisher;

public abstract class ExtendedJsonDatumParseEventsHandler {
	public abstract void initialize ();
	
	public boolean onNullFound () throws Exception {
		return true;
	}
	
	public boolean onBooleanFound (Boolean a_value) throws Exception {
		return true;
	}
	
	public boolean onIntegerFound (Integer a_value) throws Exception {
		return true;
	}
	
	public boolean onDoubleFound (Double a_value) throws Exception {
		return true;
	}
	
	public boolean onLocalDateAndTimeFound (LocalDateTime a_value) throws Exception {
		return true;
	}
	
	public boolean onLocalDateFound (LocalDate a_value) throws Exception {
		return true;
	}
	
	public boolean onLocalTimeFound (LocalTime a_value) throws Exception {
		return true;
	}
	
	public boolean onBytesArrayFound (Reader a_reader) throws Exception {
		return true;
	}
	
	public boolean onPathFound (Path a_value) throws Exception {
		return true;
	}
	
	public boolean onStringFound (Reader a_reader) throws Exception {
		return true;
	}
	
	public boolean onArrayStarted () throws Exception {
		return true;
	}
	
	public boolean onArrayEnded () throws Exception {
		return true;
	}
	
	public boolean onDictionaryStarted () throws Exception {
		return true;
	}
	
	public boolean onDictionaryEnded () throws Exception {
		return true;
	}
	
	public void onException (Exception a_exception) throws Exception {
		Publisher.logErrorInformation (a_exception);
	}
}

