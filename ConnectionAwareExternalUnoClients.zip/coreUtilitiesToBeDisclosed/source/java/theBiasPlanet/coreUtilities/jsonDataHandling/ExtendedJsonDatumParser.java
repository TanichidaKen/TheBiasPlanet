package theBiasPlanet.coreUtilities.jsonDataHandling;

import java.io.IOException;
import java.io.PipedReader;
import java.io.PipedWriter;
import java.io.Reader;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.regex.Matcher;
import theBiasPlanet.coreUtilities.constantsGroups.DefaultValuesConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.InputPropertiesConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.MessagesConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.RegularExpressionsConstantsGroup;
import theBiasPlanet.coreUtilities.inputs.PushableReader;
import theBiasPlanet.coreUtilities.inputsHandling.BufferOverflowedException;
import theBiasPlanet.coreUtilities.messagingHandling.Publisher;

public final class ExtendedJsonDatumParser {
	private static final int c_bufferSize = DefaultValuesConstantsGroup.c_smallBufferSize;
	private PushableReader i_extendedJsonDatumPushableReader = null;
	private ExtendedJsonDatumParseEventsHandler i_parseEventsHandler = null;
	private char [] i_characters = new char [c_bufferSize];
	private long i_characterIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
	
	public ExtendedJsonDatumParser () {
	}
	
	// return: true -> An item has been found, false -> No item has been found
	private boolean parseNextItem () throws IOException, InterruptedException, BufferOverflowedException, JsonDatumItemUnsupportedValueException, JsonParsingTerminatedException, Exception {
		int l_readFunctionReturn = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		int l_toReadLength = InputPropertiesConstantsGroup.c_lengthNotSet;
		int l_readLength = InputPropertiesConstantsGroup.c_noDataRetrieved; // This is used in the temporary purpose instead of 'i_characterIndex', which signifies the character index in the whole stream.
		l_toReadLength = 1;
		l_readFunctionReturn = i_extendedJsonDatumPushableReader.readFixedLengthData (i_characters, l_readLength, l_toReadLength);
		if (l_readFunctionReturn < l_toReadLength) {
			return false;
		}
		l_readLength += l_readFunctionReturn;
		Matcher l_matcher = null;
		String l_itemValue = null; // This is the anticipated datum.
		String l_readData = null; // This is the read datum.
		if (i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_doubleQuotationMarkCharacter) {
			i_characterIndex += l_readFunctionReturn;
			parseString ();
			return true;
		}
		else if (i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_jsonDictionaryOpener) {
			i_characterIndex += l_readFunctionReturn;
			parseDictionary ();
			return true;
		}
		else if (i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_jsonArrayOpener) {
			i_characterIndex += l_readFunctionReturn;
			parseArray ();
			return true;
		}
		else if (i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_nullExpressionOpener || i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_trueExpressionOpener || i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_falseExpressionOpener || i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_notANumberExpressionOpener || i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_positiveInfinityExpressionOpener) {
			i_characterIndex += l_readFunctionReturn;
			if (i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_nullExpressionOpener) {
				l_itemValue = GeneralConstantsConstantsGroup.c_nullExpression;
			}
			else if (i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_trueExpressionOpener) {
				l_itemValue = GeneralConstantsConstantsGroup.c_trueExpression;
			}
			else if (i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_falseExpressionOpener) {
				l_itemValue = GeneralConstantsConstantsGroup.c_falseExpression;
			}
			else if (i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_notANumberExpressionOpener) {
				l_itemValue = GeneralConstantsConstantsGroup.c_notANumberExpression;
			}
			else if (i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_positiveInfinityExpressionOpener) {
				l_itemValue = GeneralConstantsConstantsGroup.c_positiveInfinityExpression;
			}
			l_toReadLength = l_itemValue.length () - 1;
			l_readFunctionReturn = i_extendedJsonDatumPushableReader.readFixedLengthData (i_characters, l_readLength, l_toReadLength);
			if (l_readFunctionReturn < l_toReadLength) {
				throw new JsonDatumItemUnsupportedValueException (String.format (MessagesConstantsGroup.c_characterPosition, i_characterIndex));
			}
			l_readLength += l_readFunctionReturn;
			i_characterIndex += l_readFunctionReturn;
			if (l_itemValue.equals (new String (i_characters, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength))) {
				if (i_characters [GeneralConstantsConstantsGroup.c_iterationStartNumber] == GeneralConstantsConstantsGroup.c_nullExpressionOpener) {
					if (! (i_parseEventsHandler.onNullFound ())) {
						throw new JsonParsingTerminatedException ("");
					}
					return true;
				}
				else if (i_characters [GeneralConstantsConstantsGroup.c_iterationStartNumber] == GeneralConstantsConstantsGroup.c_trueExpressionOpener || i_characters [GeneralConstantsConstantsGroup.c_iterationStartNumber] == GeneralConstantsConstantsGroup.c_falseExpressionOpener) {
					if (! (i_parseEventsHandler.onBooleanFound (Boolean.valueOf (l_itemValue)))) {
						throw new JsonParsingTerminatedException ("");
					}
					return true;
				}
				else if (i_characters [GeneralConstantsConstantsGroup.c_iterationStartNumber] == GeneralConstantsConstantsGroup.c_notANumberExpressionOpener) {
					if (! (i_parseEventsHandler.onDoubleFound (Double.valueOf(Double.NaN)))) {
						throw new JsonParsingTerminatedException ("");
					}
					return true;
				}
				else if (i_characters [GeneralConstantsConstantsGroup.c_iterationStartNumber] == GeneralConstantsConstantsGroup.c_positiveInfinityExpressionOpener) {
					if (! (i_parseEventsHandler.onDoubleFound (Double.valueOf(Double.POSITIVE_INFINITY)))) {
						throw new JsonParsingTerminatedException ("");
					}
					return true;
				}
			}
			else {
				throw new JsonDatumItemUnsupportedValueException (String.format (MessagesConstantsGroup.c_characterPosition, i_characterIndex));
			}
		}
		else if (i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_jsonDateEtcOpener) {
			i_characterIndex += l_readFunctionReturn;
			l_readLength = InputPropertiesConstantsGroup.c_noDataRetrieved;
			l_toReadLength = 8;
			l_readFunctionReturn = i_extendedJsonDatumPushableReader.readFixedLengthData (i_characters, l_readLength, l_toReadLength);
			if (l_readFunctionReturn < l_toReadLength) {
				throw new JsonDatumItemUnsupportedValueException (String.format (MessagesConstantsGroup.c_characterPosition, i_characterIndex));
			}
			l_readLength += l_readFunctionReturn;
			i_characterIndex += l_readFunctionReturn;
			l_readData = new String (i_characters, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength);
			l_matcher = RegularExpressionsConstantsGroup.c_timesRegularExpression.matcher (l_readData);
			if (l_matcher != null && l_matcher.lookingAt ()) {
				if (! (i_parseEventsHandler.onLocalTimeFound (LocalTime.parse (l_readData, DateTimeFormatter.ISO_LOCAL_TIME)))) {
					throw new JsonParsingTerminatedException ("");
				}
				return true;
			}
			l_toReadLength = 3;
			l_readFunctionReturn = i_extendedJsonDatumPushableReader.readFixedLengthData (i_characters, l_readLength, l_toReadLength);
			// The last character can be legitimately non-existent if the item is a date.
			if (l_readFunctionReturn < l_toReadLength - 1) {
				throw new JsonDatumItemUnsupportedValueException (String.format (MessagesConstantsGroup.c_characterPosition, i_characterIndex));
			}
			if (l_readFunctionReturn == l_toReadLength -1 || (l_readFunctionReturn == l_toReadLength && i_characters [l_readLength + l_readFunctionReturn - 1] != GeneralConstantsConstantsGroup.c_jsonDateAndTimeTimePartOpener)) {
				if (l_readFunctionReturn == l_toReadLength - 1) {
					l_readLength += l_readFunctionReturn;
					i_characterIndex += l_readFunctionReturn;
				}
				else {
					i_extendedJsonDatumPushableReader.pushData (i_characters, l_readLength + l_readFunctionReturn - 1, 1);
					l_readLength += (l_readFunctionReturn - 1);
					i_characterIndex += (l_readFunctionReturn - 1);
				}
				l_readData = new String (i_characters, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength);
				l_matcher = RegularExpressionsConstantsGroup.c_datesRegularExpression.matcher (l_readData);
				if (l_matcher != null && l_matcher.lookingAt ()) {
					if (! (i_parseEventsHandler.onLocalDateFound (LocalDate.parse (l_readData, DateTimeFormatter.ISO_LOCAL_DATE)))) {
						throw new JsonParsingTerminatedException ("");
					}
					return true;
				}
				else {
					throw new JsonDatumItemUnsupportedValueException (String.format (MessagesConstantsGroup.c_characterPosition, i_characterIndex));
				}
			}
			else {
				l_readLength += l_readFunctionReturn;
				i_characterIndex += l_readFunctionReturn;
				l_toReadLength = 9;
				l_readFunctionReturn = i_extendedJsonDatumPushableReader.readFixedLengthData (i_characters, l_readLength, l_toReadLength);
				if (l_readFunctionReturn < l_toReadLength - 1) {
					throw new JsonDatumItemUnsupportedValueException (String.format (MessagesConstantsGroup.c_characterPosition, i_characterIndex));
				}
				if (l_readFunctionReturn == l_toReadLength && i_characters [l_readLength + l_readFunctionReturn - 1] != GeneralConstantsConstantsGroup.c_radixPointCharacter) {
					i_extendedJsonDatumPushableReader.pushData (i_characters, l_readLength + l_readFunctionReturn - 1, 1);
					l_readLength += (l_readFunctionReturn - 1);
					i_characterIndex += (l_readFunctionReturn - 1);
				}
				else {
					l_readLength += l_readFunctionReturn;
					i_characterIndex += l_readFunctionReturn;
					if (l_readFunctionReturn == l_toReadLength) {
						l_toReadLength = 1;
						while ((l_readFunctionReturn = i_extendedJsonDatumPushableReader.readFixedLengthData (i_characters, l_readLength, l_toReadLength)) != InputPropertiesConstantsGroup.c_noMoreData) {
							if (i_characters [l_readLength] >= GeneralConstantsConstantsGroup.c_minimumDigit && i_characters [l_readLength] <= GeneralConstantsConstantsGroup.c_maximumDigit) {
								l_readLength += l_readFunctionReturn;
								i_characterIndex += l_readFunctionReturn;
							}
							else {
								i_extendedJsonDatumPushableReader.pushData (i_characters, l_readLength, 1);
								break;
							}
						}
					}
				}
				l_readData = new String (i_characters, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength);
				l_matcher = RegularExpressionsConstantsGroup.c_dateAndTimesRegularExpression.matcher (l_readData);
				if (l_matcher != null && l_matcher.lookingAt ()) {
					if (! (i_parseEventsHandler.onLocalDateAndTimeFound (LocalDateTime.parse (l_readData, DateTimeFormatter.ISO_LOCAL_DATE_TIME)))) {
						throw new JsonParsingTerminatedException ("");
					}
					return true;
				}
				else {
					throw new JsonDatumItemUnsupportedValueException (String.format (MessagesConstantsGroup.c_characterPosition, i_characterIndex));
				}
			}
		}
		else if (i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_jsonBytesArrayOpener) {
			i_characterIndex += l_readFunctionReturn;
			l_readLength = InputPropertiesConstantsGroup.c_noDataRetrieved;
			l_toReadLength = 1;
			l_readFunctionReturn = i_extendedJsonDatumPushableReader.readFixedLengthData (i_characters, l_readLength, l_toReadLength);
			if (l_readFunctionReturn < l_toReadLength) {
				throw new JsonDatumItemUnsupportedValueException (String.format (MessagesConstantsGroup.c_characterPosition, i_characterIndex));
			}
			l_readLength += l_readFunctionReturn;
			i_characterIndex += l_readFunctionReturn;
			if (i_characters [l_readLength - 1] != GeneralConstantsConstantsGroup.c_doubleQuotationMarkCharacter) {
				throw new JsonDatumItemUnsupportedValueException (String.format (MessagesConstantsGroup.c_characterPosition, i_characterIndex));
			}
			PipedWriter l_pipedStringWriter = new PipedWriter ();
			PipedReader l_pipedStringReader = new PipedReader (l_pipedStringWriter, c_bufferSize);
			try {
				Thread l_subThread = new Thread (() -> {
					try {
						if (! (i_parseEventsHandler.onBytesArrayFound (l_pipedStringReader))) {
							throw new JsonParsingTerminatedException ("");
						}
					}
					catch (Exception l_exception) {
						l_exception.printStackTrace ();
					}
				});
				l_subThread.start ();
				l_readLength = InputPropertiesConstantsGroup.c_noDataRetrieved;
				l_toReadLength = 1;
				while ((l_readFunctionReturn = i_extendedJsonDatumPushableReader.readFixedLengthData (i_characters, l_readLength, l_toReadLength)) != InputPropertiesConstantsGroup.c_noMoreData) {
					i_characterIndex += l_readFunctionReturn;
					if (i_characters [l_readLength] == GeneralConstantsConstantsGroup.c_doubleQuotationMarkCharacter) {
						if (l_readLength > InputPropertiesConstantsGroup.c_noDataRetrieved) {
							l_pipedStringWriter.write (i_characters, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength);
						}
						l_pipedStringWriter.close ();
						l_subThread.join ();
						l_pipedStringReader.close ();
						return true;
					}
					else {
						l_readLength += l_readFunctionReturn;
						// sends a part of the item per '4' characters
						if (l_readLength == 4) {
							l_pipedStringWriter.write (i_characters, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength);
							l_readLength = InputPropertiesConstantsGroup.c_noDataRetrieved;
						}
					}
				}
				if (l_readFunctionReturn == InputPropertiesConstantsGroup.c_noMoreData) {
					l_pipedStringWriter.close ();
					throw new JsonDatumItemUnsupportedValueException (String.format (MessagesConstantsGroup.c_characterPosition, i_characterIndex));
				}
			}
			finally {
				l_pipedStringWriter.close ();
			}
			/*
			try {
				byte[] l_base64ByteArray = l_readDataBuffer.toString ().getBytes ("UTF-8");
				i_parseEventsHandler.onBytesArrayFound (Base64.getDecoder ().decode (l_base64ByteArray));
				return true;
			}
			catch (UnsupportedEncodingException l_exception) {
				throw new JsonDatumItemUnsupportedValueException (String.format ("character position: %d", i_characterIndex));
			}
			*/
		}
		else if (i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_jsonPathOpener) {
			i_characterIndex += l_readFunctionReturn;
			l_readLength = InputPropertiesConstantsGroup.c_noDataRetrieved;
			l_toReadLength = 1;
			l_readFunctionReturn = i_extendedJsonDatumPushableReader.readFixedLengthData (i_characters, l_readLength, l_toReadLength);
			if (l_readFunctionReturn < l_toReadLength) {
				throw new JsonDatumItemUnsupportedValueException (String.format (MessagesConstantsGroup.c_characterPosition, i_characterIndex));
			}
			l_readLength += l_readFunctionReturn;
			i_characterIndex += l_readFunctionReturn;
			if (i_characters [l_readLength - 1] != GeneralConstantsConstantsGroup.c_doubleQuotationMarkCharacter) {
				throw new JsonDatumItemUnsupportedValueException (String.format (MessagesConstantsGroup.c_characterPosition, i_characterIndex));
			}
			l_readLength = InputPropertiesConstantsGroup.c_noDataRetrieved;
			l_toReadLength = 1;
			StringBuilder l_pathStringBuilder = new StringBuilder ();
			while ((l_readFunctionReturn = i_extendedJsonDatumPushableReader.readFixedLengthData (i_characters, l_readLength, l_toReadLength)) != InputPropertiesConstantsGroup.c_noMoreData) {
				i_characterIndex += l_readFunctionReturn;
				if (i_characters [l_readLength] == GeneralConstantsConstantsGroup.c_doubleQuotationMarkCharacter) {
					break;
				}
				else {
					l_pathStringBuilder.append (i_characters [l_readLength]);
				}
			}
			if (l_readFunctionReturn == InputPropertiesConstantsGroup.c_noMoreData) {
				throw new JsonDatumItemUnsupportedValueException (String.format (MessagesConstantsGroup.c_characterPosition, i_characterIndex));
			}
			if (! (i_parseEventsHandler.onPathFound (Paths.get (l_pathStringBuilder.toString ())))) {
				throw new JsonParsingTerminatedException ("");
			}
			return true;
		}
		else if ((i_characters [l_readLength - 1] >= GeneralConstantsConstantsGroup.c_minimumDigit && i_characters [l_readLength - 1] <= GeneralConstantsConstantsGroup.c_maximumDigit) || i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_plusCharacter || i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_minusCharacter) {
			i_characterIndex += l_readFunctionReturn;
			l_readLength = 1;
			l_toReadLength = 1;
			if (i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_negativeInfinityExpressionOpener) {
				l_readFunctionReturn = i_extendedJsonDatumPushableReader.readFixedLengthData (i_characters, l_readLength, l_toReadLength);
				if (l_readFunctionReturn < l_toReadLength) {
					throw new JsonDatumItemUnsupportedValueException (String.format (MessagesConstantsGroup.c_characterPosition, i_characterIndex));
				}
				l_readLength += l_readFunctionReturn;
				i_characterIndex += l_readFunctionReturn;
				if (i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_positiveInfinityExpressionOpener) {
					l_toReadLength = 7;
					l_readFunctionReturn = i_extendedJsonDatumPushableReader.readFixedLengthData (i_characters, l_readLength, l_toReadLength);
					if (l_readFunctionReturn < l_toReadLength) {
						throw new JsonDatumItemUnsupportedValueException (String.format (MessagesConstantsGroup.c_characterPosition, i_characterIndex));
					}
					l_readLength += l_readFunctionReturn;
					i_characterIndex += l_readFunctionReturn;
					l_readData = new String (i_characters, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength);
					if (GeneralConstantsConstantsGroup.c_negativeInfinityExpression.equals (l_readData)) {
						if (! (i_parseEventsHandler.onDoubleFound (Double.valueOf (Double.NEGATIVE_INFINITY)))) {
							throw new JsonParsingTerminatedException ("");
						}
						return true;
					}
				}
			}
			while ((l_readFunctionReturn = i_extendedJsonDatumPushableReader.readFixedLengthData (i_characters, l_readLength, l_toReadLength)) != InputPropertiesConstantsGroup.c_noMoreData) {
				if ((i_characters [l_readLength] >= GeneralConstantsConstantsGroup.c_minimumDigit && i_characters [l_readLength] <= GeneralConstantsConstantsGroup.c_maximumDigit) || i_characters [l_readLength] == GeneralConstantsConstantsGroup.c_radixPointCharacter || i_characters [l_readLength] == GeneralConstantsConstantsGroup.c_exponentOpener1 || i_characters [l_readLength] == GeneralConstantsConstantsGroup.c_exponentOpener2 || i_characters [l_readLength] == GeneralConstantsConstantsGroup.c_plusCharacter || i_characters [l_readLength] == GeneralConstantsConstantsGroup.c_minusCharacter) {
					l_readLength += l_readFunctionReturn;
					i_characterIndex += l_readFunctionReturn;
				}
				else {
					i_extendedJsonDatumPushableReader.pushData (i_characters, l_readLength, 1);
					break;
				}
			}
			l_readData = new String (i_characters, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength);
			l_matcher = RegularExpressionsConstantsGroup.c_numbersRegularExpression.matcher (l_readData);
			if (l_matcher != null && l_matcher.lookingAt ()) {
				String l_integerPart = l_matcher.group (1);
				String l_fractionPart = l_matcher.group (2);
				String l_exponentPart = l_matcher.group (3);
				if (l_fractionPart != null || l_exponentPart != null) {
					if (! (i_parseEventsHandler.onDoubleFound (Double.valueOf (l_integerPart + (l_fractionPart != null ? l_fractionPart: "") + (l_exponentPart != null ? l_exponentPart: ""))))) {
						throw new JsonParsingTerminatedException ("");
					}
					return true;
				}
				else {
					if (! (i_parseEventsHandler.onIntegerFound (Integer.valueOf (l_integerPart)))) {
						throw new JsonParsingTerminatedException ("");
					}
					return true;
				}
			}
			throw new JsonDatumItemUnsupportedValueException (String.format (MessagesConstantsGroup.c_characterPosition, i_characterIndex));
		}
		else if (i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_jsonArrayCloser || i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_jsonDictionaryCloser) {
			i_extendedJsonDatumPushableReader.pushData (i_characters, l_readLength - 1, 1);
			return false;
		}
		else {
			throw new JsonDatumItemUnsupportedValueException (String.format (MessagesConstantsGroup.c_characterPosition, i_characterIndex));
		}
		return false;
	}
	
	private boolean parseString () throws IOException, InterruptedException, JsonDatumItemUnsupportedValueException, JsonParsingTerminatedException {
		int l_readFunctionReturn = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		int l_toReadLength = InputPropertiesConstantsGroup.c_lengthNotSet;
		int l_readLength = InputPropertiesConstantsGroup.c_noDataRetrieved;
		char l_stringChunkTerminator = GeneralConstantsConstantsGroup.c_unspecifiedCharacter;
		Character l_originalCharacterOfEscapedCharacter;
		PipedWriter l_pipedStringWriter = new PipedWriter ();
		PipedReader l_pipedStringReader = new PipedReader (l_pipedStringWriter, c_bufferSize);
		try {
			boolean [] l_onStringFoundReturn = {false};
			Thread l_subThread = new Thread (() -> {
				try {
					l_onStringFoundReturn [GeneralConstantsConstantsGroup.c_iterationStartNumber] = i_parseEventsHandler.onStringFound (l_pipedStringReader);
				}
				catch (Exception l_exception) {
					l_exception.printStackTrace ();
				}
			});
			l_subThread.start ();
			while (true) {
				l_readLength = InputPropertiesConstantsGroup.c_noDataRetrieved;
				l_toReadLength = 1;
				// reading a chunk of the string, not the whole string
				while ( (l_readFunctionReturn = i_extendedJsonDatumPushableReader.readFixedLengthData (i_characters, l_readLength, l_toReadLength)) != InputPropertiesConstantsGroup.c_noMoreData) {
					if (l_readFunctionReturn < l_toReadLength) {
						throw new JsonDatumItemUnsupportedValueException (String.format (MessagesConstantsGroup.c_characterPosition, i_characterIndex));
					}
					l_readLength += l_readFunctionReturn;
					i_characterIndex += l_readFunctionReturn;
					// '\x00' ~ '\x1f' are control characters that must have been escaped, so they should not be really found.
					if (i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_doubleQuotationMarkCharacter || i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_escapingCharacter || (i_characters [l_readLength - 1] >= GeneralConstantsConstantsGroup.c_controlCharactersStart && i_characters [l_readLength - 1] < GeneralConstantsConstantsGroup.c_controlCharactersUntil)) {
						l_stringChunkTerminator = i_characters [l_readLength - 1];
						break;
					}
					else {
						try {
							//System.out.print (new String (i_characters, 0, l_readLength));
							if (l_pipedStringWriter != null) {
								l_pipedStringWriter. write (i_characters, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength);
							}
						}
						catch (IOException l_exception) {
							l_pipedStringWriter = null;
							Publisher.logWarningInformation (l_exception);
						}
					}
					l_readLength = InputPropertiesConstantsGroup.c_noDataRetrieved;
				}
				if (l_stringChunkTerminator == GeneralConstantsConstantsGroup.c_doubleQuotationMarkCharacter) {
					if (l_pipedStringWriter != null) {
						l_pipedStringWriter.close ();
						l_pipedStringWriter = null;
					}
					l_subThread.join ();
					l_pipedStringReader.close ();
					if (!l_onStringFoundReturn [GeneralConstantsConstantsGroup.c_iterationStartNumber]) {
						throw new JsonParsingTerminatedException ("");
					}
					return true;
				}
				else if (l_stringChunkTerminator != GeneralConstantsConstantsGroup.c_escapingCharacter) {
					throw new JsonDatumItemUnsupportedValueException (String.format (MessagesConstantsGroup.c_characterPosition, i_characterIndex));
				}
				l_toReadLength = 1;
				l_readFunctionReturn = i_extendedJsonDatumPushableReader.readFixedLengthData (i_characters, l_readLength, l_toReadLength);
				if (l_readFunctionReturn < l_toReadLength) {
					throw new JsonDatumItemUnsupportedValueException (String.format (MessagesConstantsGroup.c_characterPosition, i_characterIndex));
				}
				l_readLength += l_readFunctionReturn;
				i_characterIndex += l_readFunctionReturn;
				if (i_characters [l_readLength - 1] != GeneralConstantsConstantsGroup.c_unicodeEscapeIndicator) {
					l_originalCharacterOfEscapedCharacter= GeneralConstantsConstantsGroup.c_escapedCharacterToCharacterMap.get (new String (i_characters, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength));
					/*
					if (l_originalCharacterOfEscapedCharacter != null) {
					}
					*/
					if (l_originalCharacterOfEscapedCharacter == null) {
						throw new JsonDatumItemUnsupportedValueException (String.format (MessagesConstantsGroup.c_characterPosition, i_characterIndex));
					}
				}
				else {
					l_originalCharacterOfEscapedCharacter = decodeUnicodeEscape ();
				}
				//System.out.print ( l_originalCharacterOfEscapedCharacter.charValue ());
				try {
					if (l_pipedStringWriter != null) {
						l_pipedStringWriter. write (l_originalCharacterOfEscapedCharacter.charValue ());
					}
				}
				catch (IOException l_exception) {
					l_pipedStringWriter = null;
					Publisher.logWarningInformation (l_exception);
				}
			}
		}
		finally {
			if (l_pipedStringWriter != null) {
				l_pipedStringWriter.close ();
				l_pipedStringWriter = null;
			}
		}
	}
	
	private Character decodeUnicodeEscape () throws IOException, JsonDatumItemUnsupportedValueException {
		try {
			int l_readFunctionReturn = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
			int l_readLength = InputPropertiesConstantsGroup.c_noDataRetrieved;
			int l_toReadLength = 4;
			l_readFunctionReturn = i_extendedJsonDatumPushableReader.readFixedLengthData (i_characters, l_readLength, l_toReadLength);
			if (l_readFunctionReturn < l_toReadLength) {
				throw new JsonDatumItemUnsupportedValueException (String.format (MessagesConstantsGroup.c_characterPosition, i_characterIndex));
			}
			l_readLength += l_readFunctionReturn;
			i_characterIndex += l_readFunctionReturn;
			return Character.valueOf ((char) Integer.parseInt (new String (i_characters, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength), 16));
		}
		catch (NumberFormatException l_exception) {
			throw new JsonDatumItemUnsupportedValueException (String.format (MessagesConstantsGroup.c_characterPosition, i_characterIndex));
		}
	}
	
	private void skipWhiteSpaces () throws IOException, BufferOverflowedException {
		int l_readFunctionReturn = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		int l_readLength = InputPropertiesConstantsGroup.c_noDataRetrieved;
		int l_toReadLength = 1;
		while ((l_readFunctionReturn = i_extendedJsonDatumPushableReader.readFixedLengthData (i_characters, l_readLength, l_toReadLength)) != InputPropertiesConstantsGroup.c_noMoreData) {
			l_readLength += l_readFunctionReturn;
			if (i_characters [l_readLength - 1] != GeneralConstantsConstantsGroup.c_spaceCharacter && i_characters [l_readLength - 1] != GeneralConstantsConstantsGroup.c_tabCharacter && i_characters [l_readLength - 1] != GeneralConstantsConstantsGroup.c_newLineCharacter && i_characters [l_readLength - 1] != GeneralConstantsConstantsGroup.c_carriageReturnCharacter) {
				i_extendedJsonDatumPushableReader.pushData (i_characters, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength);
				break;
			}
			else {
				i_characterIndex += l_readFunctionReturn;
			}
			l_readLength = InputPropertiesConstantsGroup.c_noDataRetrieved;
		}
		return;
	}
	
	private boolean parseArray () throws IOException, InterruptedException, BufferOverflowedException, JsonDatumItemUnsupportedValueException, JsonParsingTerminatedException, Exception {
		int l_readFunctionReturn = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		int l_toReadLength = InputPropertiesConstantsGroup.c_lengthNotSet;
		int l_readLength = InputPropertiesConstantsGroup.c_noDataRetrieved;
		if (! (i_parseEventsHandler.onArrayStarted ())) {
			throw new JsonParsingTerminatedException ("");
		}
		boolean l_itemFound = false;
		while (true) {
			skipWhiteSpaces ();
			l_itemFound = parseNextItem ();
			skipWhiteSpaces ();
			l_readLength = InputPropertiesConstantsGroup.c_noDataRetrieved;
			l_toReadLength = 1;
			l_readFunctionReturn = i_extendedJsonDatumPushableReader.readFixedLengthData (i_characters, l_readLength, l_toReadLength);
			if (l_readFunctionReturn < l_toReadLength) {
				throw new JsonDatumItemUnsupportedValueException (String.format (MessagesConstantsGroup.c_characterPosition, i_characterIndex));
			}
			l_readLength += l_readFunctionReturn;
			i_characterIndex += l_readFunctionReturn;
			if (i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_jsonArrayCloser) {
				if (! (i_parseEventsHandler.onArrayEnded ())) {
					throw new JsonParsingTerminatedException ("");
				}
				skipWhiteSpaces ();
				return true;
			}
			else if (i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_jsonItemsSeparatorOpener) {
				if (!l_itemFound) {
					throw new JsonDatumItemUnsupportedValueException (String.format (MessagesConstantsGroup.c_characterPosition, i_characterIndex));
				}
			}
			else {
				throw new JsonDatumItemUnsupportedValueException (String.format (MessagesConstantsGroup.c_characterPosition, i_characterIndex));
			}
		}
	}
	
	private boolean parseDictionary () throws IOException, InterruptedException,BufferOverflowedException, JsonDatumItemUnsupportedValueException, JsonParsingTerminatedException, Exception {
		if (! (i_parseEventsHandler.onDictionaryStarted ())) {
			throw new JsonParsingTerminatedException ("");
		}
		int l_readFunctionReturn = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		int l_toReadLength = InputPropertiesConstantsGroup.c_lengthNotSet;
		int l_readLength = InputPropertiesConstantsGroup.c_noDataRetrieved;
		boolean l_itemFound = false;
		while (true) {
			skipWhiteSpaces ();
			l_itemFound = parseNextItem ();
			if (l_itemFound) {
				skipWhiteSpaces ();
				l_readLength = InputPropertiesConstantsGroup.c_noDataRetrieved;
				l_toReadLength = 1;
				l_readFunctionReturn = i_extendedJsonDatumPushableReader.readFixedLengthData (i_characters, l_readLength, l_toReadLength);
				if (l_readFunctionReturn < l_toReadLength) {
					throw new JsonDatumItemUnsupportedValueException (String.format (MessagesConstantsGroup.c_characterPosition, i_characterIndex));
				}
				l_readLength += l_readFunctionReturn;
				i_characterIndex += l_readFunctionReturn;
				if (i_characters [l_readLength - 1] != GeneralConstantsConstantsGroup.c_jsonKeyValueSeparatorOpener) {
					throw new JsonDatumItemUnsupportedValueException (String.format (MessagesConstantsGroup.c_characterPosition, i_characterIndex));
				}
				skipWhiteSpaces ();
				l_itemFound = parseNextItem ();
				if (!l_itemFound) {
					throw new JsonDatumItemUnsupportedValueException (String.format (MessagesConstantsGroup.c_characterPosition, i_characterIndex));
				}
				skipWhiteSpaces ();
			}
			l_readLength = InputPropertiesConstantsGroup.c_noDataRetrieved;
			l_toReadLength = 1;
			l_readFunctionReturn = i_extendedJsonDatumPushableReader.readFixedLengthData (i_characters, l_readLength, l_toReadLength);
			if (l_readFunctionReturn < l_toReadLength) {
				throw new JsonDatumItemUnsupportedValueException (String.format (MessagesConstantsGroup.c_characterPosition, i_characterIndex));
			}
			l_readLength += l_readFunctionReturn;
			i_characterIndex += l_readFunctionReturn;
			if (i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_jsonDictionaryCloser) {
				if (! (i_parseEventsHandler.onDictionaryEnded ())) {
					throw new JsonParsingTerminatedException ("");
				}
				skipWhiteSpaces ();
				return true;
			}
			else if (i_characters [l_readLength - 1] == GeneralConstantsConstantsGroup.c_jsonItemsSeparatorOpener) {
				if (!l_itemFound) {
					throw new JsonDatumItemUnsupportedValueException (String.format (MessagesConstantsGroup.c_characterPosition, i_characterIndex));
				}
			}
			else {
				//System.out.println ("###Error dict char" + i_characters [l_readLength - 1]);
				throw new JsonDatumItemUnsupportedValueException (String.format (MessagesConstantsGroup.c_characterPosition, i_characterIndex));
			}
		}
	}
	
	// return: true: An item has been found, false: No item has been found
	public boolean parse (Reader a_extendedJsonDatumReader, ExtendedJsonDatumParseEventsHandler a_parseEventsHandler) throws IOException, InterruptedException, BufferOverflowedException, JsonDatumItemUnsupportedValueException, JsonParsingTerminatedException, Exception {
		i_extendedJsonDatumPushableReader = new PushableReader (a_extendedJsonDatumReader, c_bufferSize);
		i_parseEventsHandler = a_parseEventsHandler;
		i_parseEventsHandler.initialize ();
		i_characterIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
		try {
			return parseNextItem ();
		}
		catch (IOException | InterruptedException | BufferOverflowedException l_exception) {
			try {
				i_parseEventsHandler.onException (l_exception);
			}
			catch (Exception l_exceptionOfInnerTry) {
				Publisher.logErrorInformation (l_exceptionOfInnerTry);
			}
			throw l_exception;
		}
	}
}

