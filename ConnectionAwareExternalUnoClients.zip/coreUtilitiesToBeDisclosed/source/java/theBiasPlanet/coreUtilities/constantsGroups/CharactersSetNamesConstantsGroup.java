package theBiasPlanet.coreUtilities.constantsGroups;

public interface CharactersSetNamesConstantsGroup {
	String c_utf8CharactersSetName = "UTF-8";
	String c_utf16CharactersSetName = "UTF-16BE";
	String c_utf16LittleEndianCharactersSetName = "UTF-16LE";
	String c_utf8InputStreamReaderReturningCharactersSetName = "UTF8";
	String c_utf16InputStreamReaderReturningCharactersSetName = "UTF16";
}

