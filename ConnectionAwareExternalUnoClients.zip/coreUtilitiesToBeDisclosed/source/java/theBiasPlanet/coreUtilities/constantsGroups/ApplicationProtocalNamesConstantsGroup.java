package theBiasPlanet.coreUtilities.constantsGroups;

public interface ApplicationProtocalNamesConstantsGroup {
	String c_httpsName = "https";
}

