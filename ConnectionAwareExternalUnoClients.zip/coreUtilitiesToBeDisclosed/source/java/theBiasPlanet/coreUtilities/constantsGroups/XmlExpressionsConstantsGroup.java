package theBiasPlanet.coreUtilities.constantsGroups;

public interface XmlExpressionsConstantsGroup {
	String c_xml1_0Declaration = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
	String c_xmlDeclarationOpener = "<?xml";
	String c_xhtml1_0DocumentTypeDeclaration = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Frameset//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd\">";
	String c_xhtmlDocumentTypeDeclarationOpener = "<!DOCTYPE";
	String c_xhtmlNamespace = "xmlns=\"http://www.w3.org/1999/xhtml\"";
	String c_xhtmlNamespaceOpener = "xmlns=";
	char c_tagEndCharacter = '>';
	String c_commentOpener = "<!--";
	String c_commentCloser = "-->";
	String c_lessThanXmlExpression = "&lt;";
	String c_greaterThanXmlExpression = "&gt;";
	String c_ampersandXmlExpression = "&amp;";
	String c_doubleQuotationMarkXmlExpression = "&quot;";
	String c_apostropheXmlExpression = "&apos;";
}

