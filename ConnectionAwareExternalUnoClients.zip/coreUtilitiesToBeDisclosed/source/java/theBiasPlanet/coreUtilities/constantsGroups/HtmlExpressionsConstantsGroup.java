package theBiasPlanet.coreUtilities.constantsGroups;

public interface HtmlExpressionsConstantsGroup {
	String c_htmlTagOpener = "<html";
	int c_htmlTagOpenerLength = c_htmlTagOpener.length ();
}

