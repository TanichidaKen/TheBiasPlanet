package theBiasPlanet.coreUtilities.constantsGroups;

import java.util.LinkedHashMap;
import theBiasPlanet.coreUtilities.collectionsHandling.MapsFactory;

public interface GeneralConstantsConstantsGroup {
	int c_maximumBytesLengthPerUtf8Character = 4;
	int c_numberOfAlphabets = 26;
	int c_unspecifiedInteger = -1;
	float c_unspecifiedFloat = (float) -1.0;
	char c_unspecifiedCharacter = (char) 0;
	int c_iterationStartNumber = 0;
	int c_normalResult = 0;
	String c_emptyString = "";
	char c_radixPointCharacter = '.';
	char c_thousandsDelimiter = ',';
	char c_minimumDigit = '0';
	char c_maximumDigit = '9';
	char c_plusCharacter = '+';
	char c_minusCharacter = '-';
	char c_exponentOpener1 = 'E';
	char c_exponentOpener2 = 'e';
	char c_unicodeEscapeIndicator = 'u';
	char c_escapingCharacter = '\\';
	String c_escapedEscapingCharacter = "\\\\";
	char c_newLineCharacter = '\n';
	String c_escapedNewLineCharacter = "\\n";
	char c_carriageReturnCharacter = '\r';
	String c_escapedCarriageReturnCharacter = "\\r";
	char c_tabCharacter = '\t';
	String c_escapedTabCharacter = "\\t";
	char c_backspaceCharacter = '\b';
	String c_escapedBackspaceCharacter = "\\b";
	char c_formFeedCharacter = '\f';
	String c_escapedFormFeedCharacter = "\\f";
	char c_colonCharacter = ':';
	char c_semicolonCharacter = ';';
	char c_spaceCharacter = ' ';
	char c_equalCharacter = '=';
	char c_utfBomCharacter = '\uFEFF';
	char c_lessThanCharacter = '<';
	char c_greaterThanCharacter = '>';
	char c_ampersandCharacter = '&';
	char c_doubleQuotationMarkCharacter = '\"';
	String c_escapedDoubleQuotationMarkCharacter = "\\\"";
	char c_apostropheCharacter = '\'';
	char c_controlCharactersStart = 0x00;
	char c_controlCharactersUntil = 0x20;
	String c_notSurrogatePairUnicodeCharacterEscapingExpression = "\\u%04x";
	char c_argumentsDelimiter = ' ';
	String c_carriageReturnAndNewLineString = String.format ("%c%c", c_carriageReturnCharacter, c_newLineCharacter);
	String c_notANumberExpression = "NaN";
	char c_notANumberExpressionOpener = c_notANumberExpression.charAt (c_iterationStartNumber);
	String c_positiveInfinityExpression = "Infinity";
	char c_positiveInfinityExpressionOpener = c_positiveInfinityExpression.charAt (c_iterationStartNumber);
	String c_negativeInfinityExpression = String.format ("%c%s", c_minusCharacter, c_positiveInfinityExpression);
	char c_negativeInfinityExpressionOpener = c_negativeInfinityExpression.charAt (c_iterationStartNumber);
	String c_nullExpression = "null";
	char c_nullExpressionOpener = c_nullExpression.charAt (c_iterationStartNumber);
	String c_trueExpression = "true";
	char c_trueExpressionOpener = c_trueExpression.charAt (c_iterationStartNumber);
	String c_falseExpression = "false";
	char c_falseExpressionOpener = c_falseExpression.charAt (c_iterationStartNumber);
	String c_colonDelimiter = ": ";
	String c_commaDelimiter = ", ";
	char c_linuxDirectoriesDelimiter = '/';
	char c_windowsDirectoriesDelimiter = '\\';
	char c_javaPackagesDelimiter = '.';
	char c_fileNameElementsDelimiter = '.';
	char c_nameElementsDelimiter = '_';
	char c_linuxPathsDelimiter = ':';
	char c_windowsPathsDelimiter = ';';
	char c_dataCommentLineStarter = '#';
	String c_jsonItemsSeparator = c_commaDelimiter;
	String c_jsonKeyValueSeparator = c_colonDelimiter;
	char c_jsonItemsSeparatorOpener = c_jsonItemsSeparator.charAt (c_iterationStartNumber);
	char c_jsonKeyValueSeparatorOpener = c_jsonKeyValueSeparator.charAt (c_iterationStartNumber);
	char c_jsonDictionaryOpener = '{';
	char c_jsonDictionaryCloser = '}';
	char c_jsonArrayOpener = '[';
	char c_jsonArrayCloser = ']';
	char c_jsonDateEtcOpener = 'd';
	char c_jsonDateAndTimeTimePartOpener = 'T';
	char c_jsonBytesArrayOpener = 'b';
	char c_jsonPathOpener = 'p';
	String c_booleanClassName = "boolean";
	String c_byteClassName = "byte";
	String c_charClassName = "char";
	String c_doubleClassName = "double";
	String c_floatClassName = "float";
	String c_intClassName = "int";
	String c_longClassName = "long";
	String c_shortClassName = "short";
	String c_objectClassName = "java.lang.Object";
	String c_stringClassName = "java.lang.String";
	String c_integerDefaultFormat = "%d";
	String c_doubleDefaultFormat = "%f";
	String c_booleanDefaultFormat = "%b";
	String c_hexadecimalStringFormat = "0x%s";
	String c_globExpressionFormat = "glob:%s";
	String c_commandSwitchOrFlagStarter = "-";
	String c_linuxDirectoryPathFormat = String.format ("%%s%s%%s", c_linuxDirectoriesDelimiter);
	String c_windowsDirectoryPathFormat = String.format ("%%s%s%%s", c_windowsDirectoriesDelimiter);
	String c_linuxFilePathFormat = String.format ("%%s%s%%s", c_linuxDirectoriesDelimiter);
	String c_windowsFilePathFormat = String.format ("%%s%s%%s", c_windowsDirectoriesDelimiter);
	String c_fileNameFormat = String.format ("%%s%s%%s", c_fileNameElementsDelimiter);
	String c_javaClassNameFormat = String.format ("%%s%s%%s", c_javaPackagesDelimiter);
	String c_styleSheetFileNameFormat = String.format ("%%s%s%s", c_fileNameElementsDelimiter, FileNameSuffixesConstantsGroup.c_styleSheetFileNameSuffix);
	String c_javaFileNameFormat = String.format ("%%s%s%s", c_fileNameElementsDelimiter, FileNameSuffixesConstantsGroup.c_javaFileNameSuffix);
	String c_quotedByDoubleQuotationsFormat = "\"%s\"";
	String c_quotedByAngleBracketsFormat = "<%s>";
	String c_definitionNameFormat = String.format ("%1$s%1$s%%s%1$s%1$s", c_nameElementsDelimiter);
	String c_propertyValueFormat = "${%s}";
	LinkedHashMap <Character, String> c_characterToEscapedCharacterMap = getCharacterToEscapedCharacterMap ();
	LinkedHashMap <String, Character> c_escapedCharacterToCharacterMap = getEscapedCharacterToCharacterMap ();
	LinkedHashMap <Character, Integer> c_alphabetToAlphabetIndexMap = MapsFactory. <Character, Integer>createLinkedHashMap ('A', 0, 'B', 1, 'C', 2, 'D', 3, 'E', 4, 'F', 5, 'G', 6, 'H', 7, 'I', 8, 'J', 9, 'K', 10, 'L', 11, 'M', 12, 'N', 13, 'O', 14, 'P', 15, 'Q', 16, 'R', 17, 'S', 18, 'T', 19, 'U', 20, 'V', 21, 'W', 22, 'X', 23, 'Y', 24, 'Z', 25);
	LinkedHashMap <Integer, Character> c_alphabetIndexToAlphabetMap = MapsFactory. <Integer, Character>createLinkedHashMap (0, 'A', 1, 'B', 2, 'C', 3, 'D', 4, 'E', 5, 'F', 6, 'G', 7, 'H', 8, 'I', 9, 'J', 10, 'K', 11, 'L', 12, 'M', 13, 'N', 14, 'O', 15, 'P', 16, 'Q', 17, 'R', 18, 'S', 19, 'T', 20, 'U', 21, 'V', 22, 'W', 23, 'X', 24, 'Y', 25, 'Z');
	// extracted from 'https://developer.mozilla.org/en-US/docs/Web/HTTP/Basics_of_HTTP/MIME_types/Common_types'
	LinkedHashMap <String, String> c_fileExtensionToMimeTypeMap = MapsFactory. <String, String>createLinkedHashMap ("aac", "audio/aac", "abw", "application/x-abiword", "arc", "application/x-freearc", "avi", "video/x-msvideo", "azw", "application/vnd.amazon.ebook", "bmp", "image/bmp", "bz", "application/x-bzip", "bz2", "application/x-bzip2", "csh", "application/x-csh", "css", "text/css", "csv", "text/csv", "doc", "application/msword", "docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "eot", "application/vnd.ms-fontobject", "epub", "application/epub+zip", "gz", "application/gzip", "gif", "image/gif", "htm", "text/html", "html", "text/html", "ico", "image/vnd.microsoft.icon", "ics", "text/calendar", "jar", "application/java-archive", "jpeg", "image/jpeg", "jpg", "image/jpeg", "js", "text/javascript", "json", "application/json", "jsonld", "application/ld+json", "mid", "audio/midi", "midi", "audio/x-midi", "mjs", "text/javascript", "mp3", "audio/mpeg", "mpeg", "video/mpeg", "mpkg", "application/vnd.apple.installer+xml", "odp", "application/vnd.oasis.opendocument.presentation", "ods", "application/vnd.oasis.opendocument.spreadsheet", "odt", "application/vnd.oasis.opendocument.text", "oga", "audio/ogg", "ogv", "video/ogg", "ogx", "application/ogg", "opus", "audio/opus", "otf", "font/otf", "png", "image/png", "pdf", "application/pdf", "php", "application/x-httpd-php", "ppt", "application/vnd.ms-powerpoint", "pptx", "application/vnd.openxmlformats-officedocument.presentationml.presentation", "rar", "application/vnd.rar", "rtf", "application/rtf", "sh", "application/x-sh", "svg", "image/svg+xml", "swf", "application/x-shockwave-flash", "tar", "application/x-tar", "tif", "image/tiff", "tiff", "image/tiff", "ts", "video/mp2t", "ttf", "font/ttf", "txt", "text/plain", "vsd", "application/vnd.visio", "wav", "audio/wav", "weba", "audio/webm", "webm", "video/webm", "webp", "image/webp", "woff", "font/woff", "woff2", "font/woff2", "xhtml", "application/xhtml+xml", "xls", "application/vnd.ms-excel", "xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "xml", "application/xml", "xul", "application/vnd.mozilla.xul+xml", "zip", "application/zip", "3gp", "video/3gpp", "3g2", "video/3gpp2", "7z", "application/x-7z-compressed");
	
	private static LinkedHashMap <Character, String> getCharacterToEscapedCharacterMap () {
		LinkedHashMap <Character, String> l_characterToEscapedCharacterMap = MapsFactory. <Character, String>createLinkedHashMap (c_escapingCharacter, c_escapedEscapingCharacter, c_doubleQuotationMarkCharacter, c_escapedDoubleQuotationMarkCharacter, c_backspaceCharacter, c_escapedBackspaceCharacter, c_formFeedCharacter, c_escapedFormFeedCharacter, c_newLineCharacter, c_escapedNewLineCharacter, c_carriageReturnCharacter, c_escapedCarriageReturnCharacter, c_tabCharacter, c_escapedTabCharacter);
		Character l_wrappedControlCharacter = null;
		for (char l_controlCharacter = c_controlCharactersStart; l_controlCharacter < c_controlCharactersUntil; l_controlCharacter++) {
			l_wrappedControlCharacter = Character.valueOf (l_controlCharacter);
			if (! (l_characterToEscapedCharacterMap.containsKey (l_wrappedControlCharacter))) {
				l_characterToEscapedCharacterMap.put (l_wrappedControlCharacter, String.format (c_notSurrogatePairUnicodeCharacterEscapingExpression, (int) l_controlCharacter));
			}
		}
		return l_characterToEscapedCharacterMap;
	}
	
	private static LinkedHashMap <String, Character> getEscapedCharacterToCharacterMap () {
		LinkedHashMap <String, Character> l_escapedCharacterToCharacterMap = MapsFactory. <String, Character>createLinkedHashMap (c_escapedEscapingCharacter, c_escapingCharacter, c_escapedDoubleQuotationMarkCharacter, c_doubleQuotationMarkCharacter, c_escapedBackspaceCharacter, c_backspaceCharacter, c_escapedFormFeedCharacter, c_formFeedCharacter, c_escapedNewLineCharacter, c_newLineCharacter, c_escapedCarriageReturnCharacter, c_carriageReturnCharacter, c_escapedTabCharacter, c_tabCharacter);
		Character l_wrappedControlCharacter = null;
		String l_escapedControlCharacter = null;
		for (char l_controlCharacter = c_controlCharactersStart; l_controlCharacter < c_controlCharactersUntil; l_controlCharacter++) {
			l_wrappedControlCharacter = Character.valueOf (l_controlCharacter);
			l_escapedControlCharacter = String.format (c_notSurrogatePairUnicodeCharacterEscapingExpression, (int) l_controlCharacter);
			if (! (l_escapedCharacterToCharacterMap.containsKey (l_escapedControlCharacter))) {
				l_escapedCharacterToCharacterMap.put (l_escapedControlCharacter, l_wrappedControlCharacter);
			}
		}
		return l_escapedCharacterToCharacterMap;
	}
}

