package theBiasPlanet.coreUtilities.constantsGroups;

public interface WarningNamesConstantsGroup {
	String c_notChecked = "unchecked";
}

