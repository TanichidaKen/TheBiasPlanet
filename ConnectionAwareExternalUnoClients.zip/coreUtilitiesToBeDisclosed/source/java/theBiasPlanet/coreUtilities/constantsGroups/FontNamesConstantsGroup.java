package theBiasPlanet.coreUtilities.constantsGroups;

public interface FontNamesConstantsGroup {
	String c_liberationMono = "Liberation Mono";
}

