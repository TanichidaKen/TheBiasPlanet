package theBiasPlanet.coreUtilities.constantsGroups;

// ## Comments that start with the mark, ##, are instructions for extending this class, where XXX is the class name of the extended class.
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import theBiasPlanet.coreUtilities.collectionsHandling.ListsFactory;
import theBiasPlanet.coreUtilities.collectionsHandling.MapsFactory;
import theBiasPlanet.coreUtilities.collectionsHandling.SetsFactory;
import theBiasPlanet.coreUtilities.reflectionHandling.ReflectionHandler;

// ## The class has to be public, extend BaseConstantsGroup, and implement some constants group interfaces of T constants
abstract public class BaseEnumerableConstantsGroup <T> {
	private LinkedHashMap <String, T> i_nameToValueMap;
	// ## Define this.
	// ## public static final XXX c_instance = new XXX ();
	
	// ## Define the private constructor.
	
	protected BaseEnumerableConstantsGroup () {
		i_nameToValueMap = MapsFactory. <String, T>createLinkedHashMapExpandingItems (ReflectionHandler.getFieldNameToValueMap (this.getClass (), null, true, false, null, ListsFactory. <Class <?>>createArrayList (this.getClass ()), true));
	}
	
	@Override
	protected void finalize () {
	}
	
	public LinkedHashSet <String> getNames () {
		return SetsFactory. <String>createLinkedHashSetExpandingItems (i_nameToValueMap.keySet ());
	}
	
	public ArrayList <T> getValues () {
		return ListsFactory. <T>createArrayListExpandingItems (i_nameToValueMap.values ());
	}
}

