package theBiasPlanet.coreUtilities.constantsGroups;

public interface TlsProtocalNamesConstantsGroup {
	String c_version1_2Name = "TLSv1.2";
}

