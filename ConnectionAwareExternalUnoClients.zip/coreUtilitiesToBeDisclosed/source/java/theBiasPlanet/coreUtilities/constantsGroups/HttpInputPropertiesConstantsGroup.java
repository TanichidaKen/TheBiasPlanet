package theBiasPlanet.coreUtilities.constantsGroups;

public interface HttpInputPropertiesConstantsGroup extends InputPropertiesConstantsGroup {
	int c_chunkLengthExpressionBase = 16;
	int c_closerChunkSize = 0;
}

