package theBiasPlanet.coreUtilities.constantsGroups;

public interface TcpIpSocketPortNumbersConstantsGroup {
	int c_defaultHttpNumber = 80;
	int c_defaultHttpsNumber = 443;
}

