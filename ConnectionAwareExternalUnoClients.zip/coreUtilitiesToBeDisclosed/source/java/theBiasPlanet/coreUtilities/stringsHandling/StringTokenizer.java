package theBiasPlanet.coreUtilities.stringsHandling;

import theBiasPlanet.coreUtilities.constantsGroups.*;

public class StringTokenizer {
	private String [] i_tokensArray = null;
	private int i_numberOfTokens = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
	private int i_currentIndex = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
	
	public StringTokenizer (String a_targetString, String a_delimitersRegularExpression) {
		if (a_targetString != null) {
			i_tokensArray = a_targetString.split (a_delimitersRegularExpression);
			i_numberOfTokens = i_tokensArray.length;
			i_currentIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
		}
		else {
			i_numberOfTokens = 0;
			i_currentIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
		}
	}
	
	public int countTokens () {
		return i_numberOfTokens - i_currentIndex;
	}
	
	public boolean hasMoreTokens () {
		return i_currentIndex < i_numberOfTokens;
	}
	
	public String nextToken () {
		if (i_currentIndex < i_numberOfTokens) {
			i_currentIndex ++;
			return i_tokensArray [i_currentIndex - 1];
		}
		else {
			return null;
		}
	}
}

