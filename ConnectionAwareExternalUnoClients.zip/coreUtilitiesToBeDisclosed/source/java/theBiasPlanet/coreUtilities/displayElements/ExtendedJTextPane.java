package theBiasPlanet.coreUtilities.displayElements;

import javax.swing.JTextPane;
import javax.swing.text.StyledDocument;
import theBiasPlanet.coreUtilities.displaysHandling.LinesWrappedEditorPaneStyledEditorKit;
import theBiasPlanet.coreUtilities.displaysHandling.PopUpMenuInjector;

public class ExtendedJTextPane extends JTextPane {
	public ExtendedJTextPane () {
		super ();
		initialize ();
	}
	
	public ExtendedJTextPane (StyledDocument a_styledDocument) {
		super (a_styledDocument);
		initialize ();
	}
	
	@Override
	protected void finalize () {
	}
	
	private void initialize () {
		setEditorKit (new LinesWrappedEditorPaneStyledEditorKit ());
		PopUpMenuInjector.injectEditorPopUpMenu (this);
	}
}

