package theBiasPlanet.coreUtilities.displayElements;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Element;
import javax.swing.text.Highlighter;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyleContext;
import javax.swing.text.StyledDocument;
import theBiasPlanet.coreUtilities.collectionsHandling.ArraysFactory;
import theBiasPlanet.coreUtilities.collectionsHandling.ListsFactory;
import theBiasPlanet.coreUtilities.constantsGroups.FontNamesConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.MimeTypesConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.MessagesConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.SwingStyleNamesConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.UserInterfaceComponentCaptionsConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.UserInterfaceComponentToolTipsConstantsGroup;
import theBiasPlanet.coreUtilities.displaysHandling.SimpleFocusTraversalPolicy;
import theBiasPlanet.coreUtilities.displaysHandling.SwingComponentsFactory;
import theBiasPlanet.coreUtilities.messagingHandling.Publisher;

public class EditorFrame extends JFrame {
	private static final int c_defaultControlPanelHeight = 70;
	private static final Color c_highlightColor = Color.RED;
	private static final int c_defaultFrameWidth = 800;
	private static final int c_defaultFrameHeight = 1000;
	private static final String c_defaultContentsTextPaneFontName = FontNamesConstantsGroup.c_liberationMono;
	private static final int c_defaultContentsTextPaneFontSize = 18;
	private static final ArrayList <JButton> c_userInstructionForReplacingButtons = ListsFactory. <JButton>createArrayList (SwingComponentsFactory.createButtonForOptionPane (UserInterfaceComponentCaptionsConstantsGroup.c_replaceAndSearch, KeyEvent.VK_A), SwingComponentsFactory.createButtonForOptionPane (UserInterfaceComponentCaptionsConstantsGroup.c_replace, KeyEvent.VK_P), SwingComponentsFactory.createButtonForOptionPane (UserInterfaceComponentCaptionsConstantsGroup.c_search, KeyEvent.VK_E), SwingComponentsFactory.createButtonForOptionPane (UserInterfaceComponentCaptionsConstantsGroup.c_cancel, KeyEvent.VK_C));
	private static final int c_replaceAndSearchButtonIndex = 0;
	private static final int c_replaceButtonIndex = 1;
	private static final int c_searchForReplacingButtonIndex = 2;
	private static final int c_cancelReplacingButtonIndex = 3;
	private Style i_normalPartStyle;
	private StyledDocument i_contentsTextDocument;
	private	Element i_contentsTextDocumentRootElement;
	private Highlighter i_contentsTextPaneHighlighter;
	private DefaultHighlighter.DefaultHighlightPainter i_contentsTextPaneHighlightPainter;
	private boolean i_isMainFrame;
	protected static Font s_frameFont = new Font (FontNamesConstantsGroup.c_liberationMono, Font.PLAIN, 12);
	protected JPanel i_leftControlPanel;
	protected JPanel i_centerControlPanel;
	protected JPanel i_rightControlPanel;
	protected WindowAdapter i_windowAdapter;
	protected JTextPane i_contentsTextPane;
	protected JScrollPane i_contentsScrollPane;
	protected JTextField i_searchPhraseTextField;
	protected JTextField i_replacePhraseTextField;
	protected JCheckBox i_searchCaseSensitiveCheckBox;
	protected JCheckBox i_searchFromTopCheckBox;
	protected JButton i_searchTextButton;
	protected JButton i_replaceTextButton;
	protected JButton i_goToTopButton;
	protected JButton i_goToBottomButton;
	protected JButton i_saveContentsButton;
	protected JButton i_saveCompressedContentsButton;
	protected JButton i_closeFrameButton;
	
	static {
		SwingComponentsFactory.setFont (s_frameFont);
		SwingComponentsFactory.setCaptionLength (8);
	}
	
	public EditorFrame (int a_frameWidth, int a_frameHeight, int a_controlPanelHeight, String a_contentsTextPaneFontName, int a_contentsTextPaneFontSize, String a_frameTitle, boolean a_isMainFrame) {
		super (a_frameTitle);
		setFont (s_frameFont);
		i_windowAdapter = new WindowAdapter () {
			public void windowClosing (WindowEvent a_event) {
				close ();
			}
		};
		addWindowListener (i_windowAdapter);
		int l_frameWidth = a_frameWidth == GeneralConstantsConstantsGroup.c_unspecifiedInteger ? c_defaultFrameWidth: a_frameWidth;
		int l_frameHeight = a_frameHeight == GeneralConstantsConstantsGroup.c_unspecifiedInteger ? c_defaultFrameHeight: a_frameHeight;
		int l_controlPanelHeight = a_controlPanelHeight == GeneralConstantsConstantsGroup.c_unspecifiedInteger ? c_defaultControlPanelHeight: a_controlPanelHeight;
		setSize (l_frameWidth, l_frameHeight);
		setResizable (true);
		i_isMainFrame = a_isMainFrame;
		// frame ingredients pane
		Container l_frameIngredientsPane = getContentPane ();
		GroupLayout l_frameIngredientsPaneLayout = new GroupLayout (l_frameIngredientsPane);
		l_frameIngredientsPaneLayout.setAutoCreateGaps (true);
		l_frameIngredientsPaneLayout.setAutoCreateContainerGaps (true);
		l_frameIngredientsPane.setLayout (l_frameIngredientsPaneLayout);
		JPanel l_contentsPanel = new JPanel () {
			@Override
			public Dimension getPreferredSize () {
				Dimension l_prefferedSize = super.getPreferredSize ();
				l_prefferedSize.setSize (l_prefferedSize.getWidth(), getParent ().getHeight () - l_controlPanelHeight);
				return l_prefferedSize;
			}
		};
		JPanel l_controlPanel = new JPanel ();
		l_frameIngredientsPaneLayout.setHorizontalGroup (l_frameIngredientsPaneLayout.createParallelGroup (GroupLayout.Alignment.CENTER).addComponent (l_contentsPanel).addComponent (l_controlPanel));
		l_frameIngredientsPaneLayout.setVerticalGroup (l_frameIngredientsPaneLayout.createSequentialGroup ().addComponent (l_contentsPanel).addComponent (l_controlPanel, l_controlPanelHeight, l_controlPanelHeight, l_controlPanelHeight));
		// contents panel
		GroupLayout l_contentsPanelLayout = new GroupLayout (l_contentsPanel);
		l_contentsPanel.setLayout (l_contentsPanelLayout);
		i_contentsTextPane = new ExtendedJTextPane ();
		i_contentsTextDocument = i_contentsTextPane.getStyledDocument ();
		i_contentsTextDocumentRootElement = i_contentsTextDocument.getDefaultRootElement ();
		i_contentsTextPaneHighlighter = i_contentsTextPane.getHighlighter ();
		i_contentsTextPaneHighlightPainter = new DefaultHighlighter.DefaultHighlightPainter (c_highlightColor);
		String l_contentsTextPaneFontName = null;
		int l_contentsTextPaneFontSize = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		if (a_contentsTextPaneFontName == null) {
			l_contentsTextPaneFontName = c_defaultContentsTextPaneFontName;
		}
		else {
			l_contentsTextPaneFontName = a_contentsTextPaneFontName;
		}
		if (a_contentsTextPaneFontSize == GeneralConstantsConstantsGroup.c_unspecifiedInteger) {
			l_contentsTextPaneFontSize = c_defaultContentsTextPaneFontSize;
		}
		else {
			l_contentsTextPaneFontSize = a_contentsTextPaneFontSize;
		}
		i_contentsTextPane.setFont (new Font (l_contentsTextPaneFontName, Font.PLAIN, l_contentsTextPaneFontSize));
		StyleContext l_styleContext = new StyleContext ();
		i_normalPartStyle = l_styleContext.addStyle (SwingStyleNamesConstantsGroup.c_normal, null);
		i_contentsScrollPane = new LineNumberedTextScrollPane (i_contentsTextPane);
		l_contentsPanelLayout.setHorizontalGroup (l_contentsPanelLayout.createParallelGroup (GroupLayout.Alignment.CENTER).addComponent (i_contentsScrollPane));
		l_contentsPanelLayout.setVerticalGroup (l_contentsPanelLayout.createSequentialGroup ().addComponent (i_contentsScrollPane));
		// control panel
		GroupLayout l_controlPanelLayout = new GroupLayout (l_controlPanel);
		l_controlPanel.setLayout (l_controlPanelLayout);
		i_leftControlPanel = new JPanel ();
		i_centerControlPanel = new JPanel ();
		i_rightControlPanel = new JPanel ();
		l_controlPanelLayout.setHorizontalGroup (l_controlPanelLayout.createSequentialGroup ().addComponent (i_leftControlPanel).addComponent (i_centerControlPanel).addComponent (i_rightControlPanel));
		l_controlPanelLayout.setVerticalGroup (l_controlPanelLayout.createParallelGroup (GroupLayout.Alignment.LEADING).addComponent (i_leftControlPanel).addComponent (i_centerControlPanel).addComponent (i_rightControlPanel));
		// left control panel
		GroupLayout l_leftControlPanelLayout = new GroupLayout (i_leftControlPanel);
		i_leftControlPanel.setLayout (l_leftControlPanelLayout);
		i_searchPhraseTextField = SwingComponentsFactory.createTextField (UserInterfaceComponentToolTipsConstantsGroup.c_searchPhrase, null, null);
		i_replacePhraseTextField = SwingComponentsFactory.createTextField (UserInterfaceComponentToolTipsConstantsGroup.c_replacePhrase, null, null);
		i_searchCaseSensitiveCheckBox = SwingComponentsFactory.createCheckBox (UserInterfaceComponentToolTipsConstantsGroup.c_caseSensitive, true, null, null);
		i_searchFromTopCheckBox = SwingComponentsFactory.createCheckBox (UserInterfaceComponentToolTipsConstantsGroup.c_fromTop, false, null, null);
		i_searchTextButton = SwingComponentsFactory.createButton (UserInterfaceComponentToolTipsConstantsGroup.c_search, KeyEvent.VK_E,
			(a_event) -> {
				searchTextButtonActionPerformed (a_event);
			},
			null, null
		);
		i_replaceTextButton = SwingComponentsFactory.createButton (UserInterfaceComponentToolTipsConstantsGroup.c_replace, KeyEvent.VK_P,
			(a_event) -> {
				replaceTextButtonActionPerformed (a_event);
			},
			null, null
		);
		i_goToTopButton = SwingComponentsFactory.createButton (UserInterfaceComponentToolTipsConstantsGroup.c_goToTop, KeyEvent.VK_G,
			(a_event) -> {
				goToTopButtonActionPerformed (a_event);
			},
			null, null
		);
		i_goToBottomButton = SwingComponentsFactory.createButton (UserInterfaceComponentToolTipsConstantsGroup.c_goToBottom, KeyEvent.VK_O,
			(a_event) -> {
				goToBottomButtonActionPerformed (a_event);
			},
			null, null
		);
		l_leftControlPanelLayout.setHorizontalGroup (l_leftControlPanelLayout.createParallelGroup (GroupLayout.Alignment.TRAILING).addGroup (l_leftControlPanelLayout.createSequentialGroup ().addGroup (l_leftControlPanelLayout.createParallelGroup (GroupLayout.Alignment.LEADING).addComponent (i_searchPhraseTextField, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE).addComponent (i_replacePhraseTextField, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE)).addGroup (l_leftControlPanelLayout.createParallelGroup (GroupLayout.Alignment.LEADING).addComponent (i_searchCaseSensitiveCheckBox).addComponent (i_searchFromTopCheckBox)).addGroup (l_leftControlPanelLayout.createParallelGroup (GroupLayout.Alignment.LEADING).addComponent (i_searchTextButton).addComponent (i_replaceTextButton))).addGroup (l_leftControlPanelLayout.createParallelGroup (GroupLayout.Alignment.LEADING).addComponent (i_goToTopButton).addComponent (i_goToBottomButton)));
		l_leftControlPanelLayout.setVerticalGroup (l_leftControlPanelLayout.createSequentialGroup ().addGroup (l_leftControlPanelLayout.createParallelGroup (GroupLayout.Alignment.LEADING).addGroup (l_leftControlPanelLayout.createSequentialGroup ().addComponent (i_searchPhraseTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.PREFERRED_SIZE, GroupLayout.PREFERRED_SIZE).addComponent (i_replacePhraseTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.PREFERRED_SIZE, GroupLayout.PREFERRED_SIZE)).addGroup (l_leftControlPanelLayout.createSequentialGroup ().addComponent (i_searchCaseSensitiveCheckBox).addComponent (i_searchFromTopCheckBox)).addGroup (l_leftControlPanelLayout.createSequentialGroup ().addComponent (i_searchTextButton).addComponent (i_replaceTextButton))).addGroup (l_leftControlPanelLayout.createSequentialGroup ().addComponent (i_goToTopButton).addComponent (i_goToBottomButton)));
		// center control panel
		// right control panel
		GroupLayout l_rightControlPanelLayout = new GroupLayout (i_rightControlPanel);
		i_rightControlPanel.setLayout (l_rightControlPanelLayout);
		i_saveContentsButton = SwingComponentsFactory.createButton (UserInterfaceComponentToolTipsConstantsGroup.c_save, KeyEvent.VK_S,
			(a_event) -> {
				saveContentsButtonActionPerformed (a_event);
			},
			null, null
		);
		i_saveContentsButton.setEnabled (false);
		i_saveCompressedContentsButton = SwingComponentsFactory.createButton (UserInterfaceComponentToolTipsConstantsGroup.c_saveCompressed, KeyEvent.VK_A,
			(a_event) -> {
				saveCompressedContentsButtonActionPerformed (a_event);
			},
			null, null
		);
		i_saveCompressedContentsButton.setEnabled (false);
		i_closeFrameButton = SwingComponentsFactory.createButton (UserInterfaceComponentToolTipsConstantsGroup.c_close, KeyEvent.VK_C,
			(a_event) -> {
				closeFrameButtonActionPerformed (a_event);
			},
			null, null
		);
		l_rightControlPanelLayout.setHorizontalGroup (l_rightControlPanelLayout.createParallelGroup (GroupLayout.Alignment.CENTER).addComponent (i_saveContentsButton).addComponent (i_saveCompressedContentsButton).addComponent (i_closeFrameButton));
		l_rightControlPanelLayout.setVerticalGroup (l_rightControlPanelLayout.createSequentialGroup ().addComponent (i_saveContentsButton).addComponent (i_saveCompressedContentsButton).addComponent (i_closeFrameButton));
		setFocusTraversalPolicy (new SimpleFocusTraversalPolicy (i_closeFrameButton, i_contentsTextPane, i_searchPhraseTextField, i_searchCaseSensitiveCheckBox, i_searchFromTopCheckBox, i_searchTextButton, i_replacePhraseTextField, i_replaceTextButton, i_goToTopButton, i_goToBottomButton, i_saveContentsButton, i_saveCompressedContentsButton, i_closeFrameButton));
	}
	
	public EditorFrame (String a_frameTitle, boolean a_isMainFrame) {
		this (GeneralConstantsConstantsGroup.c_unspecifiedInteger, GeneralConstantsConstantsGroup.c_unspecifiedInteger, GeneralConstantsConstantsGroup.c_unspecifiedInteger, null, GeneralConstantsConstantsGroup.c_unspecifiedInteger, a_frameTitle, a_isMainFrame);
	}
	
	@Override
	protected void finalize () {
	}
	
	public void setContents (String a_contents) {
		i_contentsTextPane.setContentType (MimeTypesConstantsGroup.c_textPlain);
		StyleConstants.setForeground (i_normalPartStyle, Color.BLACK);
		try {
			i_contentsTextDocument.remove (GeneralConstantsConstantsGroup.c_iterationStartNumber, i_contentsTextDocument.getLength());
			if (a_contents != null) {
				i_contentsTextDocument.insertString (GeneralConstantsConstantsGroup.c_iterationStartNumber, a_contents, i_normalPartStyle);
				setCurrentCaretOffset (GeneralConstantsConstantsGroup.c_iterationStartNumber);
			}
		}
		catch (BadLocationException l_badLocationException) {
			// This won't happen except because of a bug.
			Publisher.show (l_badLocationException.toString ());
		}
	}
	
	public String getContents () {
		String l_contents = null;
		try {
			l_contents = i_contentsTextDocument.getText (GeneralConstantsConstantsGroup.c_iterationStartNumber, i_contentsTextDocument.getLength ());
		}
		catch (BadLocationException l_exception) {
			// This won't happen except because of a bug.
			Publisher.show (l_exception.toString ());
		}
		return l_contents;
	}
	
	public int getCurrentCaretOffset () {
		return i_contentsTextPane.getCaretPosition ();
	}
	
	public void setCurrentCaretOffset (int a_movedCaretOffset) {
		i_contentsTextPane.setCaretPosition (a_movedCaretOffset);
	}
	
	public void selectText (int a_startOffset, int a_endOffset) {
		i_contentsTextPane.select (a_startOffset, a_endOffset);
	}
	
	public String getSelectedText () {
		return i_contentsTextPane.getSelectedText ();
	}
	
	public void setFocusOnContentsTextPane () {
		i_contentsTextPane.grabFocus ();
	}
	
	public int searchText (String a_serchedText) {
		i_searchPhraseTextField.setText (a_serchedText);
		Highlighter.Highlight [] l_highLights = i_contentsTextPaneHighlighter.getHighlights ();
		for (int l_highLightIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber; l_highLightIndex < l_highLights.length; l_highLightIndex ++) {
			if (l_highLights [l_highLightIndex].getPainter () == i_contentsTextPaneHighlightPainter) {
				i_contentsTextPaneHighlighter.removeHighlight (l_highLights [l_highLightIndex]);
			}
		}
		int l_foundTextsCount = 0;
		if (a_serchedText == null || a_serchedText.equals (GeneralConstantsConstantsGroup.c_emptyString)) {
			return l_foundTextsCount;
		}
		int l_textDocumentElementsCount = i_contentsTextDocumentRootElement.getElementCount ();
		Element l_textDocumentElement = null;
		int l_searchStartPositionOffset = GeneralConstantsConstantsGroup.c_iterationStartNumber;
		if (!i_searchFromTopCheckBox.isSelected ()) {
			l_searchStartPositionOffset = i_contentsTextPane.getCaretPosition ();
		}
		int l_movedCaretOffset = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		if (!i_searchCaseSensitiveCheckBox.isSelected ()) {
			a_serchedText = a_serchedText.toLowerCase ();
		}
		for (int l_textDocumentElementIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber; l_textDocumentElementIndex < l_textDocumentElementsCount; l_textDocumentElementIndex ++) {
			l_textDocumentElement = i_contentsTextDocumentRootElement.getElement (l_textDocumentElementIndex);
			int l_textDocumentElementStartOffset = l_textDocumentElement.getStartOffset ();
			try {
				String l_textLine = i_contentsTextDocument.getText (l_textDocumentElementStartOffset, l_textDocumentElement.getEndOffset () - l_textDocumentElementStartOffset);
				if (!i_searchCaseSensitiveCheckBox.isSelected ()) {
					l_textLine = l_textLine.toLowerCase ();
				}
				int l_searchStartIndexInTextLine = GeneralConstantsConstantsGroup.c_iterationStartNumber;
				int l_foundTextIndexInTextLine = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
				while (l_searchStartIndexInTextLine ==  GeneralConstantsConstantsGroup.c_iterationStartNumber || l_foundTextIndexInTextLine >= GeneralConstantsConstantsGroup.c_iterationStartNumber) {
					l_foundTextIndexInTextLine = l_textLine.indexOf (a_serchedText, l_searchStartIndexInTextLine);
					if (l_foundTextIndexInTextLine >= GeneralConstantsConstantsGroup.c_iterationStartNumber) {
						if (l_movedCaretOffset == GeneralConstantsConstantsGroup.c_unspecifiedInteger && l_textDocumentElementStartOffset + l_foundTextIndexInTextLine >= l_searchStartPositionOffset) {
							l_movedCaretOffset = l_textDocumentElementStartOffset + l_foundTextIndexInTextLine;
							i_contentsTextPane.setCaretPosition (l_movedCaretOffset);
							i_contentsTextPane.select (l_movedCaretOffset, l_movedCaretOffset + a_serchedText.length ());
							i_contentsTextPane.grabFocus ();
						}
						i_contentsTextPaneHighlighter.addHighlight (l_textDocumentElementStartOffset + l_foundTextIndexInTextLine, l_textDocumentElementStartOffset + l_foundTextIndexInTextLine + a_serchedText.length (), i_contentsTextPaneHighlightPainter);
						l_foundTextsCount ++;
						l_searchStartIndexInTextLine ++;
					}
				}
			}
			catch (BadLocationException l_exception) {
				// This won't happen except because of a bug.
				Publisher.show (l_exception.toString ());
			}
		}
		return l_foundTextsCount;
	}
	
	public int replaceText (String a_serchedText, String a_replacingText) {
		i_searchPhraseTextField.setText (a_serchedText);
		i_replacePhraseTextField.setText (a_replacingText);
		int l_replacedTextsCount = 0;
		if (a_serchedText == null || a_serchedText.equals (GeneralConstantsConstantsGroup.c_emptyString)) {
			return l_replacedTextsCount;
		}
		if (a_replacingText == null) {
			a_replacingText = GeneralConstantsConstantsGroup.c_emptyString;
		}
		int l_textDocumentElementsCount = i_contentsTextDocumentRootElement.getElementCount ();
		Element l_textDocumentElement = null;
		int l_searchStartPositionOffset = GeneralConstantsConstantsGroup.c_iterationStartNumber;
		if (!i_searchFromTopCheckBox.isSelected ()) {
			l_searchStartPositionOffset = i_contentsTextPane.getCaretPosition ();
		}
		if (!i_searchCaseSensitiveCheckBox.isSelected ()) {
			a_serchedText = a_serchedText.toLowerCase ();
		}
		for (int l_textDocumentElementIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber; l_textDocumentElementIndex < l_textDocumentElementsCount; l_textDocumentElementIndex ++) {
			l_textDocumentElement = i_contentsTextDocumentRootElement.getElement (l_textDocumentElementIndex);
			int l_textDocumentElementStartOffset = l_textDocumentElement.getStartOffset ();
			try {
				String l_textLine = i_contentsTextDocument.getText (l_textDocumentElementStartOffset, l_textDocumentElement.getEndOffset () - l_textDocumentElementStartOffset);
				if (!i_searchCaseSensitiveCheckBox.isSelected ()) {
					l_textLine = l_textLine.toLowerCase ();
				}
				int l_searchStartIndexInTextLine = GeneralConstantsConstantsGroup.c_iterationStartNumber;
				int l_foundTextIndexInTextLine = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
				int l_numberOfIncreasedCharacters = 0;
				while (l_searchStartIndexInTextLine ==  GeneralConstantsConstantsGroup.c_iterationStartNumber || l_foundTextIndexInTextLine >= GeneralConstantsConstantsGroup.c_iterationStartNumber) {
					l_foundTextIndexInTextLine = l_textLine.indexOf (a_serchedText, l_searchStartIndexInTextLine);
					if (l_foundTextIndexInTextLine >= GeneralConstantsConstantsGroup.c_iterationStartNumber) {
						int l_replacingPositionOffset = l_textDocumentElementStartOffset + l_foundTextIndexInTextLine + l_numberOfIncreasedCharacters;
						if (l_replacingPositionOffset >= l_searchStartPositionOffset) {
							i_contentsTextPane.setCaretPosition (l_replacingPositionOffset);
							i_contentsTextPane.select (l_replacingPositionOffset, l_replacingPositionOffset + a_serchedText.length ());
							i_contentsTextPane.grabFocus ();
							int l_userDirection = JOptionPane.showOptionDialog (this, MessagesConstantsGroup.c_replacingConfirmation, UserInterfaceComponentCaptionsConstantsGroup.c_replace, JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, ArraysFactory. <JButton>createArray (JButton.class, c_userInstructionForReplacingButtons), c_cancelReplacingButtonIndex);
							if (l_userDirection == c_cancelReplacingButtonIndex) {
								return l_replacedTextsCount;
							}
							else if (l_userDirection == c_searchForReplacingButtonIndex)  {
							}
							else {
								i_contentsTextDocument.remove (l_replacingPositionOffset, a_serchedText.length());
								i_contentsTextDocument.insertString (l_replacingPositionOffset, a_replacingText, i_normalPartStyle);
								l_numberOfIncreasedCharacters += (a_replacingText.length () - a_serchedText.length ());
								setCurrentCaretOffset (l_replacingPositionOffset + a_replacingText.length ());
								i_contentsTextPane.grabFocus ();
								l_replacedTextsCount ++;
							}
							if (l_userDirection == c_replaceButtonIndex) {
								return l_replacedTextsCount;
							}
						}
						l_searchStartIndexInTextLine ++;
					}
				}
			}
			catch (BadLocationException l_exception) {
				Publisher.show (l_exception.toString ());
			}
		}
		return l_replacedTextsCount;
	}
	
	public void replaceWindowListener (WindowAdapter a_windowAdapter) {
		removeWindowListener (i_windowAdapter);
		i_windowAdapter = a_windowAdapter;
		addWindowListener (i_windowAdapter);
	}
	
	private void searchTextButtonActionPerformed (ActionEvent a_event) {
		searchText (i_searchPhraseTextField.getText ());
	}
	
	private void replaceTextButtonActionPerformed (ActionEvent a_event) {
		replaceText (i_searchPhraseTextField.getText (), i_replacePhraseTextField.getText ());
	}
	
	private void goToTopButtonActionPerformed (ActionEvent a_event) {
		i_contentsTextPane.setCaretPosition (GeneralConstantsConstantsGroup.c_iterationStartNumber);
		i_contentsTextPane.grabFocus ();
	}
	
	private void goToBottomButtonActionPerformed (ActionEvent a_event) {
		i_contentsTextPane.setCaretPosition (i_contentsTextDocument.getLength());
		i_contentsTextPane.grabFocus ();
	}
	
	private void closeFrameButtonActionPerformed (ActionEvent a_event) {
		dispatchEvent (new WindowEvent (this, WindowEvent.WINDOW_CLOSING));
	}
	
	protected void saveContentsButtonActionPerformed (ActionEvent a_event) {
	}
	
	protected void saveCompressedContentsButtonActionPerformed (ActionEvent a_event) {
	}
	
	protected void close () {
		if (i_isMainFrame) {
			System.exit (GeneralConstantsConstantsGroup.c_normalResult);
		}
	}
}

