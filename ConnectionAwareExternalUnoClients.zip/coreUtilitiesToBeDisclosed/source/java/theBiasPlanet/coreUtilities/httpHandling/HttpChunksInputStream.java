package theBiasPlanet.coreUtilities.httpHandling;

import java.io.IOException;
import java.io.InputStream;
import theBiasPlanet.coreUtilities.constantsGroups.DefaultValuesConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.HttpInputPropertiesConstantsGroup;

public class HttpChunksInputStream extends InputStream {
	private static final int c_inMethodBufferSize = DefaultValuesConstantsGroup.c_smallestBufferSize;
	private InputStream i_underlyingInputStream;
	private byte [] i_inMethodBuffer;
	private int i_chunkLength;
	private int i_chunkReadLength;
	private HttpResponseHeader i_inTrailerHttpResponseHeader;
	
	public HttpChunksInputStream (InputStream a_underlyingInputStream) {
		super ();
		i_inMethodBuffer = new byte [c_inMethodBufferSize];
		i_chunkLength = HttpInputPropertiesConstantsGroup.c_lengthNotSet;
		i_chunkReadLength = HttpInputPropertiesConstantsGroup.c_lengthNotRead;
		i_underlyingInputStream = a_underlyingInputStream;
	}
	
	@Override
	protected void finalize () {
	}
	
	public HttpResponseHeader getInTrailerHttpResponseHeader () {
		return i_inTrailerHttpResponseHeader;
	}
	
	@Override
	public int read (byte [] a_bytesArray, int a_offset, int a_length) throws IOException {
		if (i_inTrailerHttpResponseHeader != null) {
			return HttpInputPropertiesConstantsGroup.c_noMoreData;
		}
		if (a_length <= HttpInputPropertiesConstantsGroup.c_noDataRetrieved) {
			return HttpInputPropertiesConstantsGroup.c_noDataRetrieved;
		}
		boolean l_isInTrailer = false;
		int l_toReadLength = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		int l_readMethodReturn = HttpInputPropertiesConstantsGroup.c_noMoreData;
		if (i_chunkLength == HttpInputPropertiesConstantsGroup.c_lengthNotSet) {
			l_toReadLength = 1;
			boolean l_isInChunkLengthPart = true;
			StringBuilder l_chunkLengthPartStringBuilder = new StringBuilder ();
			char l_readCharacter;
			while ((l_readMethodReturn = i_underlyingInputStream.read ()) != HttpInputPropertiesConstantsGroup.c_noMoreData) {
				l_readCharacter = (char) l_readMethodReturn;
				if (l_readCharacter == GeneralConstantsConstantsGroup.c_semicolonCharacter || l_readCharacter == GeneralConstantsConstantsGroup.c_carriageReturnCharacter) {
					l_isInChunkLengthPart = false;
				}
				else if (l_readCharacter == GeneralConstantsConstantsGroup.c_newLineCharacter) {
					break;
				}
				else if (l_isInChunkLengthPart) {
					l_chunkLengthPartStringBuilder.append (l_readCharacter);
				}
			}
			i_chunkLength = Integer.parseInt (l_chunkLengthPartStringBuilder.toString (), HttpInputPropertiesConstantsGroup.c_chunkLengthExpressionBase);
			i_chunkReadLength = HttpInputPropertiesConstantsGroup.c_lengthNotRead;
		}
		l_toReadLength = Math.min (a_length, i_chunkLength - i_chunkReadLength);
		int l_readLength = HttpInputPropertiesConstantsGroup.c_noDataRetrieved;
		if (l_toReadLength > HttpInputPropertiesConstantsGroup.c_noDataRetrieved) {
			l_readMethodReturn = i_underlyingInputStream.read (a_bytesArray, a_offset, l_toReadLength);
			if (l_readMethodReturn == HttpInputPropertiesConstantsGroup.c_noMoreData) {
				return HttpInputPropertiesConstantsGroup.c_noMoreData;
			}
			l_readLength += l_readMethodReturn;
			i_chunkReadLength += l_readLength;
		}
		if (i_chunkReadLength == i_chunkLength) {
			if (i_chunkLength != HttpInputPropertiesConstantsGroup.c_closerChunkSize) {
				while ((l_readMethodReturn = i_underlyingInputStream.read ()) != HttpInputPropertiesConstantsGroup.c_noMoreData) {
					if ( (char) l_readMethodReturn == GeneralConstantsConstantsGroup.c_newLineCharacter) {
						break;
					}
				}
			}
			else {
				l_isInTrailer = true;
			}
			i_chunkLength = HttpInputPropertiesConstantsGroup.c_lengthNotSet;
			i_chunkReadLength = HttpInputPropertiesConstantsGroup.c_lengthNotRead;
		}
		if (l_isInTrailer) {
			i_inTrailerHttpResponseHeader = HttpClient.getHttpResponseHeader (i_underlyingInputStream);
		}
		if (l_readLength > HttpInputPropertiesConstantsGroup.c_noDataRetrieved) {
			return l_readLength;
		}
		else {
			return HttpInputPropertiesConstantsGroup.c_noMoreData;
		}
	}
	
	@Override
	public int read () throws IOException {
		int l_toReadLength = 1;
		int l_readMethodReturn = HttpInputPropertiesConstantsGroup.c_noMoreData;
		while ( (l_readMethodReturn = read (i_inMethodBuffer, 0, l_toReadLength)) != HttpInputPropertiesConstantsGroup.c_noMoreData) {
			if (l_readMethodReturn > HttpInputPropertiesConstantsGroup.c_noDataRetrieved) {
				return (int) i_inMethodBuffer [0];
			}
		}
		return l_readMethodReturn;
	}
	
	@Override
	public void close () throws IOException {
		i_underlyingInputStream.close ();
	}
}

