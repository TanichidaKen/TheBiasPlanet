package theBiasPlanet.coreUtilities.httpHandling;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PipedReader;
import java.io.PipedWriter;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.net.Socket;
import java.net.URL;
import java.net.UnknownHostException;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import theBiasPlanet.coreUtilities.constantsGroups.ApplicationProtocalNamesConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.CharactersSetNamesConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.DefaultValuesConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.InputPropertiesConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.TcpIpSocketPortNumbersConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.TlsProtocalNamesConstantsGroup;
import theBiasPlanet.coreUtilities.inputsHandling.ReaderHandler;

public class HttpClient {
	private static final String c_defaultCharactersSetName = CharactersSetNamesConstantsGroup.c_utf8CharactersSetName;
	private static final String c_acceptedContentsEncodingName = "deflate";
	private static final String c_chunckedTransferEncodingName = "chunked";
	private static final String c_closeConnectionType = "close";
	private static final String c_acceptedTlsProtocolName = TlsProtocalNamesConstantsGroup.c_version1_2Name;
	private static final String c_transferEncodingHttpRequestHeaderExpression = String.format ("Transfer-Encoding: %%s%s", GeneralConstantsConstantsGroup.c_carriageReturnAndNewLineString);
	private static final String c_contentsTypeAndCharactersSetHttpRequestHeaderExpression = String.format ("Content-Type: %%s; charset=%%s%s", GeneralConstantsConstantsGroup.c_carriageReturnAndNewLineString);
	private static final String c_connectionTypeHttpRequestHeaderExpression = String.format ("Connection: %%s%s", GeneralConstantsConstantsGroup.c_carriageReturnAndNewLineString);
	private static final String c_contentsTypeHttpResponseHeaderOpener = "Content-Type";
	private static final String c_charactersSetHttpResponseHeaderOpener = "charset";
	private static final String c_transferEncodingHttpResponseHeaderOpener = "Transfer-Encoding";
	private static final String c_contentsLengthHttpResponseHeaderOpener = "Content-Length";
	private static final String c_contentsEncodingHttpResponseHeaderOpener = "Content-Encoding";
	private static final String c_httpRequestHeaderCloser = GeneralConstantsConstantsGroup.c_carriageReturnAndNewLineString;
	private static final String c_getRequestCommandExpression = String.format ("GET %%s HTTP/1.1%s", GeneralConstantsConstantsGroup.c_carriageReturnAndNewLineString);
	private static final String c_postRequestCommandExpression = String.format ("POST %%s HTTP/1.1%s", GeneralConstantsConstantsGroup.c_carriageReturnAndNewLineString);
	private static final String c_hostRequestHeaderExpression = String.format ("Host: %%s%s", GeneralConstantsConstantsGroup.c_carriageReturnAndNewLineString);
	private static final String c_acceptedCharactersSetRequestHeaderExpression = String.format ("Accept-Charset: %%s%s", GeneralConstantsConstantsGroup.c_carriageReturnAndNewLineString);
	private static final String c_acceptedContentsEncodingRequestHeaderExpression = String.format ("Accept-Encoding: %%s%s", GeneralConstantsConstantsGroup.c_carriageReturnAndNewLineString);
	private static final String c_chunkExpression = String.format ("%%x%s%%s%s", GeneralConstantsConstantsGroup.c_carriageReturnAndNewLineString, GeneralConstantsConstantsGroup.c_carriageReturnAndNewLineString);
	private static final String c_closerChunkContents = GeneralConstantsConstantsGroup.c_emptyString;
	private static final int c_closerChunkSize = 0;
	private static final int c_bufferSize = DefaultValuesConstantsGroup.c_smallBufferSize;
	private static final String c_socketNotOpenErrorMessage = "The socket isn't open.";
	private Socket i_socket;
	private String i_serverHostName;
	private int i_serverPortNumber;
	private boolean i_usesTls;
	
	public HttpClient (String a_serverHostName, int a_serverPortNumber, boolean a_usesTls) {
		i_socket = null;
		i_serverHostName = a_serverHostName;
		i_serverPortNumber = a_serverPortNumber;
		i_usesTls = a_usesTls;
	}
	
	private enum HttpResponseStatusReadingState {
		c_readingHttpVersion,
		c_readingStatusCode,
		c_readingStatusReason,
		c_finishedReading
	}
	
	private enum HttpResponseHeaderReadingState {
		c_readingNothing,
		c_readingContentsType,
		c_readingCharactersSet,
		c_readingTransferEncoding,
		c_readingContentsLength,
		c_readingContentsEncoding,
		c_readingAnother
	}
	
	public static HttpResponse openGetAndClose (String a_urlString) throws IOException {
		URL l_url = new URL (a_urlString);
		boolean l_usesTls = ApplicationProtocalNamesConstantsGroup.c_httpsName.equals (l_url.getProtocol ()) ? true: false;
		int l_specifiedPortNumber = l_url.getPort ();
		HttpClient l_httpClient = new HttpClient (l_url.getHost (), l_specifiedPortNumber != -1 ? l_specifiedPortNumber: l_usesTls ? TcpIpSocketPortNumbersConstantsGroup.c_defaultHttpsNumber: TcpIpSocketPortNumbersConstantsGroup.c_defaultHttpNumber, l_usesTls);
		HttpResponse l_httpResponse = null;
		try {
			l_httpClient.openSocket ();
			l_httpResponse = l_httpClient.get (String.format ("%s?%s", l_url.getPath (), l_url.getQuery ()));
			PipedWriter l_pipedHttpResponseBodyWriter = new PipedWriter ();
			BufferedReader l_pipedHttpResponseBodyReader = new BufferedReader (new PipedReader (l_pipedHttpResponseBodyWriter, c_bufferSize));
			Reader l_httpResponseBodyReader = l_httpResponse.getBodyReader ();
			l_httpResponse.setBodyReader (l_pipedHttpResponseBodyReader);
			Thread l_subThread = new Thread ( () -> {
				try {
					ReaderHandler.writeWholeStringToWriter (l_httpResponseBodyReader, l_pipedHttpResponseBodyWriter);
				}
				catch (Exception l_exception) {
					throw new RuntimeException (l_exception);
				}
				finally {
					try {
						l_pipedHttpResponseBodyWriter.flush ();
						l_pipedHttpResponseBodyWriter.close ();
						l_httpClient.closeSocket ();
					}
					catch (Exception l_exception) {
						throw new RuntimeException (l_exception);
					}
				}
			});
			l_subThread.start ();
		}
		catch (IOException l_exception) {
			l_httpClient.closeSocket ();
		}
		return l_httpResponse;
	}
	
	public HttpResponse get (String a_urlString) throws IOException, UnknownHostException, UnsupportedEncodingException {
		if (i_socket == null) {
			throw new IOException (c_socketNotOpenErrorMessage);
		}
		OutputStreamWriter l_socketWriter = null;
		boolean l_socketIsNew = false;
		while (true) {
			if (i_socket == null) {
				openSocket ();
				l_socketIsNew = true;
			}
			try {
				l_socketWriter = new OutputStreamWriter (i_socket.getOutputStream (), c_defaultCharactersSetName);
				l_socketWriter.write (String.format (c_getRequestCommandExpression, a_urlString));
				setGetPostCommonHttpRequestHeaderPart (l_socketWriter);
				l_socketWriter.write (c_httpRequestHeaderCloser);
				l_socketWriter.flush ();
				break;
			}
			catch (IOException l_exception) {
				i_socket = null;
				if (l_socketIsNew) {
					throw l_exception;
				}
			}
		}
		return getHttpResponse (i_socket.getInputStream ());
	}
	
	public HttpResponse asynchronousPost (String a_urlString, String a_contentsType, Reader a_postDataReader) throws IOException, UnknownHostException, UnsupportedEncodingException {
		if (i_socket == null) {
			throw new IOException (c_socketNotOpenErrorMessage);
		}
		OutputStreamWriter l_socketWriter = null;
		boolean l_socketIsNew = false;
		while (true) {
			if (i_socket == null) {
				openSocket ();
				l_socketIsNew = true;
			}
			try {
				l_socketWriter = new OutputStreamWriter (i_socket.getOutputStream (), c_defaultCharactersSetName);
				l_socketWriter.write (String.format (c_postRequestCommandExpression, a_urlString));
				setGetPostCommonHttpRequestHeaderPart (l_socketWriter);
				l_socketWriter.write (String.format (c_transferEncodingHttpRequestHeaderExpression, c_chunckedTransferEncodingName));
				l_socketWriter.write (String.format (c_contentsTypeAndCharactersSetHttpRequestHeaderExpression, a_contentsType, c_defaultCharactersSetName));
				l_socketWriter.write (c_httpRequestHeaderCloser);
				l_socketWriter.flush ();
				break;
			}
			catch (IOException l_exception) {
				i_socket = null;
				if (l_socketIsNew) {
					throw l_exception;
				}
			}
		}
		OutputStreamWriter l_socketWriterFinal = l_socketWriter;
		Thread l_subThread = new Thread (() -> {
			try {
				char [] l_characters = new char [c_bufferSize];
				int l_readMethodReturn = InputPropertiesConstantsGroup.c_noMoreData;
				String l_chunk;
				while((l_readMethodReturn = a_postDataReader.read (l_characters, 0, c_bufferSize)) != InputPropertiesConstantsGroup.c_noMoreData){
					if (l_readMethodReturn > InputPropertiesConstantsGroup.c_noDataRetrieved) {
						l_chunk = new String (l_characters, 0, l_readMethodReturn);
						l_socketWriterFinal.write (String.format (c_chunkExpression, l_chunk.getBytes (c_defaultCharactersSetName).length, l_chunk));
						l_socketWriterFinal.flush ();
					}
				}
				l_socketWriterFinal.write (String.format (c_chunkExpression, c_closerChunkSize, c_closerChunkContents));
				l_socketWriterFinal.flush ();
			}
			catch (Exception l_exception) {
				throw new RuntimeException (l_exception);
			}
		});
		l_subThread.start ();
		return getHttpResponse (i_socket.getInputStream ());
	}
	
	public void openSocket () throws IOException {
		if (i_usesTls) {
			SSLSocketFactory l_sslSocketsFactory = (SSLSocketFactory) SSLSocketFactory.getDefault ();
			i_socket = l_sslSocketsFactory.createSocket (i_serverHostName, i_serverPortNumber);
			String[] l_enabledProtocols = {c_acceptedTlsProtocolName};
			SSLSocket l_sslCocket = (SSLSocket) i_socket;
			l_sslCocket.setEnabledProtocols (l_enabledProtocols);
			l_sslCocket.startHandshake ();
		}
		else {
			i_socket = new Socket (i_serverHostName, i_serverPortNumber);
		}
	}
	
	public void closeSocket () throws IOException {
		if (i_socket != null) {
			i_socket.close ();
		}
	}
	
	private void setGetPostCommonHttpRequestHeaderPart (OutputStreamWriter a_socketWriter) throws IOException {
		a_socketWriter.write (String.format (c_hostRequestHeaderExpression, i_serverHostName));
		a_socketWriter.write (String.format (c_acceptedCharactersSetRequestHeaderExpression, c_defaultCharactersSetName));
		a_socketWriter.write (String.format (c_acceptedContentsEncodingRequestHeaderExpression, c_acceptedContentsEncodingName));
		//a_socketWriter.write (String.format (c_connectionTypeHttpRequestHeaderExpression, c_closeConnectionType));
	}
	
	private static HttpResponse getHttpResponse (InputStream a_socketInputStream) throws IOException {
		InputStream l_socketInputStream = a_socketInputStream;
		HttpResponseStatus l_httpResponseStatus = getHttpResponseStatus (l_socketInputStream);
		HttpResponseHeader l_httpResponseHeader = getHttpResponseHeader (l_socketInputStream);
		if (c_chunckedTransferEncodingName.equals (l_httpResponseHeader.getTransferEncoding ())) {
			l_socketInputStream = new HttpChunksInputStream (l_socketInputStream);
		}
		else {
			l_socketInputStream = new HttpFixedLengthInputStream (l_socketInputStream, l_httpResponseHeader.getContentsLength ());
		}
		BufferedReader l_httpResponseBodyReader = new BufferedReader (new InputStreamReader (l_socketInputStream, l_httpResponseHeader.getCharactersSet ()));
		return new HttpResponse (l_httpResponseStatus, l_httpResponseHeader, l_httpResponseBodyReader);
	}
	
	private static HttpResponseStatus getHttpResponseStatus (InputStream a_socketInputStream) throws IOException {
		int l_readMethodReturn = InputPropertiesConstantsGroup.c_noMoreData;
		char l_readCharacter = GeneralConstantsConstantsGroup.c_unspecifiedCharacter;
		StringBuilder l_responseStatusItemBuffer = new StringBuilder ();
		HttpResponseStatusReadingState l_readingState = HttpResponseStatusReadingState.c_readingHttpVersion;
		HttpResponseStatus l_httpResponseStatus = new HttpResponseStatus ();
		while ((l_readMethodReturn = a_socketInputStream.read ()) != InputPropertiesConstantsGroup.c_noMoreData) {
			l_readCharacter = (char) l_readMethodReturn;
			if (l_readCharacter == GeneralConstantsConstantsGroup.c_newLineCharacter) {
				break;
			}
			else if ((l_readingState != HttpResponseStatusReadingState.c_readingStatusReason && l_readCharacter == GeneralConstantsConstantsGroup.c_spaceCharacter) || l_readCharacter == GeneralConstantsConstantsGroup.c_carriageReturnCharacter) {
				if (l_readingState == HttpResponseStatusReadingState.c_readingHttpVersion) {
					l_httpResponseStatus.setHttpVersion (l_responseStatusItemBuffer.toString ());
				}
				else if (l_readingState == HttpResponseStatusReadingState.c_readingStatusCode) {
					l_httpResponseStatus.setStatusCode (Integer.parseInt (l_responseStatusItemBuffer.toString ()));
				}
				else if (l_readingState == HttpResponseStatusReadingState.c_readingStatusReason) {
					l_httpResponseStatus.setStatusReason (l_responseStatusItemBuffer.toString ());
				}
				l_readingState = HttpResponseStatusReadingState.values () [l_readingState.ordinal () + 1];
				l_responseStatusItemBuffer.delete (0, l_responseStatusItemBuffer.length ());
			}
			else {
				l_responseStatusItemBuffer.append (l_readCharacter);
			}
		}
		return l_httpResponseStatus;
	}
	
	public static HttpResponseHeader getHttpResponseHeader (InputStream a_socketInputStream) throws IOException {
		int l_readMethodReturn = InputPropertiesConstantsGroup.c_noMoreData;
		char l_readCharacter = GeneralConstantsConstantsGroup.c_unspecifiedCharacter;
		StringBuilder l_httpResponseHeaderItemBuffer = new StringBuilder ();
		HttpResponseHeaderReadingState l_readingState = HttpResponseHeaderReadingState.c_readingNothing;
		HttpResponseHeader l_httpResponseHeader = new HttpResponseHeader ();
		while ((l_readMethodReturn = a_socketInputStream.read ()) != InputPropertiesConstantsGroup.c_noMoreData) {
			l_readCharacter = (char) l_readMethodReturn;
			if (l_readCharacter == GeneralConstantsConstantsGroup.c_newLineCharacter) {
				if (l_readingState == HttpResponseHeaderReadingState.c_readingNothing) {
					break;
				}
				l_readingState = HttpResponseHeaderReadingState.c_readingNothing;
				continue;
			}
			else if (l_readCharacter == GeneralConstantsConstantsGroup.c_semicolonCharacter || l_readCharacter == GeneralConstantsConstantsGroup.c_carriageReturnCharacter) {
				if (l_readingState == HttpResponseHeaderReadingState.c_readingContentsType) {
					l_httpResponseHeader.setContentsType (l_httpResponseHeaderItemBuffer.toString ().trim ());
				}
				else if (l_readingState == HttpResponseHeaderReadingState.c_readingCharactersSet) {
					l_httpResponseHeader.setCharactersSet (l_httpResponseHeaderItemBuffer.toString ().trim ());
				}
				else if (l_readingState == HttpResponseHeaderReadingState.c_readingTransferEncoding) {
					l_httpResponseHeader.setTransferEncoding (l_httpResponseHeaderItemBuffer.toString ().trim ());
				}
				else if (l_readingState == HttpResponseHeaderReadingState.c_readingContentsLength) {
					l_httpResponseHeader.setContentsLength (Integer.parseInt(l_httpResponseHeaderItemBuffer.toString ().trim ()));
				}
				else if (l_readingState == HttpResponseHeaderReadingState.c_readingContentsEncoding) {
					l_httpResponseHeader.setContentsEncoding (l_httpResponseHeaderItemBuffer.toString ().trim ());
				}
				l_httpResponseHeaderItemBuffer.delete (0, l_httpResponseHeaderItemBuffer.length ());
			}
			else if (l_readCharacter == GeneralConstantsConstantsGroup.c_colonCharacter || l_readCharacter == GeneralConstantsConstantsGroup.c_equalCharacter) {
				if (c_contentsTypeHttpResponseHeaderOpener.equals (l_httpResponseHeaderItemBuffer.toString ())) {
					l_readingState = HttpResponseHeaderReadingState.c_readingContentsType;
				}
				else if (c_charactersSetHttpResponseHeaderOpener.equals (l_httpResponseHeaderItemBuffer.toString ())) {
					l_readingState = HttpResponseHeaderReadingState.c_readingCharactersSet;
				}
				else if (c_transferEncodingHttpResponseHeaderOpener.equals (l_httpResponseHeaderItemBuffer.toString ())) {
					l_readingState = HttpResponseHeaderReadingState.c_readingTransferEncoding;
				}
				else if (c_contentsLengthHttpResponseHeaderOpener.equals (l_httpResponseHeaderItemBuffer.toString ())) {
					l_readingState = HttpResponseHeaderReadingState.c_readingContentsLength;
				}
				else if (c_contentsEncodingHttpResponseHeaderOpener.equals (l_httpResponseHeaderItemBuffer.toString ())) {
					l_readingState = HttpResponseHeaderReadingState.c_readingContentsEncoding;
				}
				else {
					if (l_httpResponseHeaderItemBuffer.length () > 0) {
						l_readingState = HttpResponseHeaderReadingState.c_readingAnother;
					}
				}
				l_httpResponseHeaderItemBuffer.delete (0, l_httpResponseHeaderItemBuffer.length ());
			}
			else {
				l_httpResponseHeaderItemBuffer.append (l_readCharacter);
			}
		}
		return l_httpResponseHeader;
	}
}

