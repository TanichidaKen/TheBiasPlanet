package theBiasPlanet.coreUtilities.httpHandling;

import theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup;

public class HttpResponseStatus {
	private String i_httpVersion = null;
	private int i_statusCode = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
	private String i_statusReason = null;
	
	public HttpResponseStatus () {
	}
	
	public String getHttpVersion () {
		return i_httpVersion;
	}
	
	public void setHttpVersion (String a_httpVersion) {
		i_httpVersion = a_httpVersion;
	}
	
	public int getStatusCode () {
		return i_statusCode;
	}
	
	public void setStatusCode (int a_statusCode) {
		i_statusCode = a_statusCode;
	}
	
	public String getStatusReason () {
		return i_statusReason;
	}
	
	public void setStatusReason (String a_statusReason) {
		i_statusReason = a_statusReason;
	}
	
	public String toString () {
		return String.format ("%s %d %s", i_httpVersion, i_statusCode, i_statusReason);
	}
}

