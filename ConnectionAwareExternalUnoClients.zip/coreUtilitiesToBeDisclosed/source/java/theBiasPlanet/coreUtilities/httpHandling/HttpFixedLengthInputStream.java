package theBiasPlanet.coreUtilities.httpHandling;

import java.io.IOException;
import java.io.InputStream;
import theBiasPlanet.coreUtilities.constantsGroups.DefaultValuesConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.InputPropertiesConstantsGroup;

public class HttpFixedLengthInputStream extends InputStream {
	private InputStream i_underlyingInputStream = null;
	private int i_contentsLength = InputPropertiesConstantsGroup.c_lengthNotSet;
	private int i_contentsReadLength = InputPropertiesConstantsGroup.c_lengthNotRead;
	private byte [] i_inMethodBuffer = new byte [DefaultValuesConstantsGroup.c_smallestBufferSize];
	
	public HttpFixedLengthInputStream (InputStream a_underlyingInputStream, int a_contentsLength) {
		super ();
		i_underlyingInputStream = a_underlyingInputStream;
		i_contentsLength = a_contentsLength;
	}
	
	@Override
	public int read (byte [] a_bytesArray, int a_offset, int a_length) throws IOException {
		if (i_contentsReadLength == i_contentsLength) {
			return InputPropertiesConstantsGroup.c_noMoreData;
		}
		if (a_length <= InputPropertiesConstantsGroup.c_noDataRetrieved) {
			return InputPropertiesConstantsGroup.c_noDataRetrieved;
		}
		int l_toReadLength = Math.min (a_length, i_contentsLength - i_contentsReadLength);
		int l_readMethodReturn = InputPropertiesConstantsGroup.c_noMoreData;
		l_readMethodReturn = i_underlyingInputStream.read (a_bytesArray, a_offset, l_toReadLength);
		if (l_readMethodReturn == InputPropertiesConstantsGroup.c_noMoreData) {
			return InputPropertiesConstantsGroup.c_noMoreData;
		}
		i_contentsReadLength += l_readMethodReturn;
		return l_readMethodReturn;
	}
	
	@Override
	public int read () throws IOException {
		int l_toReadLength = 1;
		int l_readMethodReturn = InputPropertiesConstantsGroup.c_noMoreData;
		while ( (l_readMethodReturn = read (i_inMethodBuffer, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_toReadLength)) != InputPropertiesConstantsGroup.c_noMoreData) {
			if (l_readMethodReturn > InputPropertiesConstantsGroup.c_noDataRetrieved) {
				return (int) i_inMethodBuffer [GeneralConstantsConstantsGroup.c_iterationStartNumber];
			}
		}
		return l_readMethodReturn;
	}
	
	@Override
	public void close () throws IOException {
		i_underlyingInputStream.close ();
	}
}

