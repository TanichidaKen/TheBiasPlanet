package theBiasPlanet.coreUtilities.xmlDataHandling;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.Map;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.SAXException;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import theBiasPlanet.coreUtilities.httpHandling.HttpClient;
import theBiasPlanet.coreUtilities.httpHandling.HttpResponse;
import theBiasPlanet.coreUtilities.inputs.HtmlToXmlFilterReader;
import theBiasPlanet.coreUtilities.inputsHandling.ReaderHandler;
import theBiasPlanet.coreUtilities.messagingHandling.Publisher;

public class SaxParser {
	private static SAXParserFactory s_saxParsersFactory = SAXParserFactory.newInstance ();
	private XMLReader i_underlyingSaxParser;
	private boolean i_isFromHtml = false;
	
	public SaxParser (Map <String, String> a_dtdUrlToContentsMap, boolean a_isFromHtml) throws ParserConfigurationException, SAXException {
		i_underlyingSaxParser = s_saxParsersFactory.newSAXParser ().getXMLReader ();
		i_underlyingSaxParser.setFeature ("http://xml.org/sax/features/namespaces", true);
		i_underlyingSaxParser.setFeature ("http://xml.org/sax/features/validation", false);
		i_underlyingSaxParser.setFeature ("http://apache.org/xml/features/validation/schema", false);
		i_underlyingSaxParser.setFeature ("http://xml.org/sax/features/external-parameter-entities", true);
		i_underlyingSaxParser.setEntityResolver ( (a_publicId, a_systemId) -> {
			if (a_systemId.endsWith (".dtd") || a_systemId.endsWith (".ent")) {
				if (a_dtdUrlToContentsMap == null) {
					return null;
				}
				else {
					try {
						String l_dtdContent = a_dtdUrlToContentsMap.get (a_systemId);
						if (l_dtdContent == null) {
							HttpResponse l_httpResponse = HttpClient.openGetAndClose (a_systemId);
							if (l_httpResponse.getStatus ().getStatusCode () == 200) {
								l_dtdContent = ReaderHandler.getWholeString (l_httpResponse.getBodyReader ());
								a_dtdUrlToContentsMap.put (a_systemId, l_dtdContent);
							}
							else {
								Publisher.logErrorInformation (String.format ("Entity: %s couldn't be found.", a_systemId));
								return null;
							}
						}
						InputSource l_inputSourceForDtd = new InputSource (new StringReader (l_dtdContent));
						l_inputSourceForDtd.setPublicId (a_publicId);
						l_inputSourceForDtd.setSystemId (a_systemId);
						return l_inputSourceForDtd;
					}
					catch (IOException l_exception) {
						Publisher.logErrorInformation (l_exception.toString ());
						return null;
					}
				}
			}
			else {
				return null;
			}
		});
		i_isFromHtml = a_isFromHtml;
	}
	
	public void parse (Reader a_xmlDatumReader, DefaultHandler a_saxEventHandler) throws SAXException, IOException {
		i_underlyingSaxParser.setContentHandler (a_saxEventHandler);
		i_underlyingSaxParser.setProperty ("http://xml.org/sax/properties/lexical-handler", a_saxEventHandler);
		InputSource l_xmlDatumInputSource = null;
		if (i_isFromHtml) {
			l_xmlDatumInputSource = new InputSource (new HtmlToXmlFilterReader (a_xmlDatumReader));
		}
		else {
			l_xmlDatumInputSource = new InputSource (a_xmlDatumReader);
		}
		i_underlyingSaxParser.parse (l_xmlDatumInputSource);
	}
}

