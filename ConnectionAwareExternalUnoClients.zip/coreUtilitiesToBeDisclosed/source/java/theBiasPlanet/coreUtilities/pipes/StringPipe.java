package theBiasPlanet.coreUtilities.pipes;

import java.io.IOException;
import java.io.Reader;
import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.coreUtilities.inputsHandling.NoMoreDataException;
import theBiasPlanet.coreUtilities.inputsHandling.NoMoreNeedsException;
import theBiasPlanet.coreUtilities.timersHandling.TimeOutException;

public class StringPipe extends ObjectsPipe <Character> {
	public StringPipe (int a_bufferSize, boolean a_notificationIsDelayed) {
		super (a_bufferSize, a_notificationIsDelayed);
	}
	
	@Override
	protected void finalize () {
	}
	
	public void writeWholeString (Reader a_reader) {
		int l_writtenCharacter;
		while (true) {
			try {
				l_writtenCharacter = a_reader.read ();
			}
			catch (IOException l_exception) {
				// Impossible
				break;
			}
			if (l_writtenCharacter == GeneralConstantsConstantsGroup.c_unspecifiedInteger) {
				break;
			}
			try {
				write (Character.valueOf ( (char) l_writtenCharacter));
			}
			catch (NoMoreNeedsException l_exception) {
				break;
			}
		}
	}
	
	public String readString (int a_maximumLength, long a_timeOutPeriodInMilliseconds) throws NoMoreDataException, TimeOutException {
		Character l_readCharacter;
		StringBuilder l_readStringBuilder = new StringBuilder ();
		int l_readStringLength = 0;
		while (l_readStringLength < a_maximumLength) {
			try {
				if (l_readStringLength == 0) {
					l_readCharacter = read (a_timeOutPeriodInMilliseconds);
				}
				else {
					l_readCharacter = read ();
				}
			}
			catch (NoMoreDataException | TimeOutException l_exception) {
				if (l_readStringLength == 0) {
					throw l_exception;
				}
				break;
			}
			if (l_readCharacter != null) {
				l_readStringBuilder.append (l_readCharacter);
				l_readStringLength ++;
			}
		}
		return l_readStringBuilder.toString ();
	}
	
	public String readString (int a_maximumLength) throws NoMoreDataException, TimeOutException {
		return readString (a_maximumLength, -1);
	}
	
	public String readStringLine (int a_maximumLength, long a_timeOutPeriodInMilliseconds) throws NoMoreDataException, TimeOutException {
		StringBuilder l_readStringBuilder = new StringBuilder ();
		int l_readStringLength = 0;
		while (true) {
			try {
				Character l_readCharacter = read (a_timeOutPeriodInMilliseconds);
				if (l_readCharacter != null) {
					l_readStringBuilder.append (l_readCharacter);
					l_readStringLength ++;
					if (l_readCharacter == GeneralConstantsConstantsGroup.c_newLineCharacter || l_readStringLength >= a_maximumLength) {
						break;
					}
				}
			}
			catch (NoMoreDataException | TimeOutException l_exception) {
				if (l_readStringLength == 0) {
					throw l_exception;
				}
				break;
			}
		}
		return l_readStringBuilder.toString ();
	}
	
	public String readStringLine (int a_maximumLength) throws NoMoreDataException, TimeOutException {
		return readStringLine (a_maximumLength, -1);
	}
	
	public String readWholeString () {
		Character l_readCharacter;
		StringBuilder l_readStringBuilder = new StringBuilder ();
		while (true) {
			try {
				l_readCharacter = read ();
			}
			catch (NoMoreDataException l_exception) {
				break;
			}
			if (l_readCharacter != null) {
				l_readStringBuilder.append (l_readCharacter);
			}
		}
		return l_readStringBuilder.toString ();
	}
}

