package theBiasPlanet.coreUtilities.displaysHandling;

import java.awt.Font;
import java.awt.event.ActionListener;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JTextField;
import javax.swing.JOptionPane;
import theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup;
import theBiasPlanet.coreUtilities.displayElements.ExtendedJTextField;
import theBiasPlanet.coreUtilities.stringsHandling.StringHandler;

public class SwingComponentsFactory {
	private static Font s_font = null;
	private static int s_captionLength = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
	
	private static String getCaption (String a_toolTipText) {
		if (s_captionLength == GeneralConstantsConstantsGroup.c_unspecifiedInteger) {
			return a_toolTipText;
		}
		else {
			return StringHandler.getCaptionString (a_toolTipText, s_captionLength);
		}
	}
	
	public static void setFont (Font a_font) {
		s_font = a_font;
	}
	
	public static void setCaptionLength (int a_captionLength) {
		s_captionLength = a_captionLength;
	}
	
	public static JTextField createTextField (String a_toolTipText, GroupLayout.Group a_verticalGroup, GroupLayout.Group a_horizontalGroup) {
		JTextField l_createdTextField = new ExtendedJTextField ();
		l_createdTextField.setFont (s_font);
		l_createdTextField.setToolTipText (a_toolTipText);
		if (a_verticalGroup != null) {
			a_verticalGroup.addComponent (l_createdTextField);
		}
		if (a_horizontalGroup != null) {
			a_horizontalGroup.addComponent (l_createdTextField);
		}
		return l_createdTextField;
	}
	
	public static JCheckBox createCheckBox (String a_toolTipText, boolean a_defaultValue, GroupLayout.Group a_verticalGroup, GroupLayout.Group a_horizontalGroup) {
		JCheckBox l_createdCheckBox = new JCheckBox (getCaption (a_toolTipText), a_defaultValue);
		if (s_font != null) {
			l_createdCheckBox.setFont (s_font);
		}
		l_createdCheckBox.setToolTipText (a_toolTipText);
		if (a_verticalGroup != null) {
			a_verticalGroup.addComponent (l_createdCheckBox);
		}
		if (a_horizontalGroup != null) {
			a_horizontalGroup.addComponent (l_createdCheckBox);
		}
		return l_createdCheckBox;
	}
	
	public static JButton createButton (String a_toolTipText, int a_shorcutKey, ActionListener a_actionListener, GroupLayout.Group a_verticalGroup, GroupLayout.Group a_horizontalGroup) {
		JButton l_createdButton = new JButton (getCaption (a_toolTipText));
		if (s_font != null) {
			l_createdButton.setFont (s_font);
		}
		l_createdButton.setMnemonic (a_shorcutKey);
		l_createdButton.setToolTipText (a_toolTipText);
		if (a_verticalGroup != null) {
			a_verticalGroup.addComponent (l_createdButton);
		}
		if (a_horizontalGroup != null) {
			a_horizontalGroup.addComponent (l_createdButton);
		}
		l_createdButton.addActionListener (a_actionListener);
		return l_createdButton;
	}
	
	public static JButton createButtonForOptionPane (String a_toolTipText, int a_shortcutKey) {
		return createButton (a_toolTipText, a_shortcutKey,
			(a_event) -> {
				JOptionPane l_sourcePane = (JOptionPane) ( (JComponent) a_event.getSource ()).getParent ().getParent ();
				l_sourcePane.setValue (a_event.getSource ());
			},
			null, null
		);
	}
}

