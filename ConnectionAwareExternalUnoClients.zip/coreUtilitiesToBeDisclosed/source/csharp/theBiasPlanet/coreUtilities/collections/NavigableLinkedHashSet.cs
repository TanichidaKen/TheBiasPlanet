namespace theBiasPlanet {
	namespace coreUtilities {
		namespace collections {
			using System;
			using System.Collections;
			using System.Collections.Generic;
			using System.Runtime.Serialization;
			using theBiasPlanet.coreUtilities.optionalDatum;
			
			public class NavigableLinkedHashSet <T> : ISet <T> {
				private class Links {
					OptionalDatum <T> i_previousElement;
					OptionalDatum <T> i_nextElement;
					
					public Links (OptionalDatum <T> a_previousElement, OptionalDatum <T> a_nextElement) {
						i_previousElement = a_previousElement;
						i_nextElement = a_nextElement;
					}
					
					public OptionalDatum <T> getPreviousElement () {
						return i_previousElement;
					}
					
					public void setPreviousElement (OptionalDatum <T> a_previousElement) {
						i_previousElement = a_previousElement;
					}
					
					public OptionalDatum <T> getNextElement () {
						return i_nextElement;
					}
					
					public void setNextElement (OptionalDatum <T> a_nextElement) {
						i_nextElement = a_nextElement;
					}
				}
				
				private class NavigableLinkedHashSetEnumerator : IEnumerator <T> {
					private Dictionary <T, Links> i_elementToLinksHashMap = null;
					private OptionalDatum <T> i_firstElement = null;
					private OptionalDatum <T> i_lastElement = null;
					private OptionalDatum <T> i_currentElement = null;
					private Boolean i_isAtAfterLastElement = false; // this is required, because the current element's being empty means that the current element is before the first element or that the current element is after the last element, unlike in C++.
					
					public NavigableLinkedHashSetEnumerator (NavigableLinkedHashSet <T> a_navigableLinkedHashSet) {
						i_elementToLinksHashMap = a_navigableLinkedHashSet.i_elementToLinksHashMap;
						i_firstElement = a_navigableLinkedHashSet.i_firstElement;
						i_lastElement = a_navigableLinkedHashSet.i_lastElement;
						i_currentElement = new OptionalDatum <T> ();
						if (!i_firstElement.hasDatum ()) {
							i_isAtAfterLastElement = true;
						}
					}
					
					~NavigableLinkedHashSetEnumerator () {
					}
					
					public virtual T Current {
						get {
							if (i_currentElement.hasDatum ()) {
								Links l_currentLinks = i_elementToLinksHashMap [i_currentElement.getDatum ()];
								return i_currentElement.getDatum ();
							}
							else {
								return default (T);
							}
						}
					}
					
					Object IEnumerator.Current {
						get {
							return this.Current;
						}
					}
					
					public virtual Boolean MoveNext () {
						if (i_isAtAfterLastElement) {
							return false;
						}
						else {
							if (i_currentElement.hasDatum ()) {
								Links l_currentLinks = i_elementToLinksHashMap [i_currentElement.getDatum ()];
								i_currentElement = l_currentLinks.getNextElement ();
								if (i_currentElement.hasDatum ()) {
									return true;
								}
								else {
									i_isAtAfterLastElement = true;
									return false;
								}
							}
							else {
								i_currentElement = i_firstElement;
								return true;
							}
						}
					}
					
					public virtual void Reset () {
						i_currentElement = new OptionalDatum <T> ();
						if (!i_firstElement.hasDatum ()) {
							// This is just in order to avoid a warning of 'i_lastElement''s not being used.
							if (!i_lastElement.hasDatum ()) {
							}
							i_isAtAfterLastElement = true;
						}
					}
					
					public virtual void Dispose () {
					}
				}
				
				private Dictionary <T, Links> i_elementToLinksHashMap;
				private OptionalDatum <T> i_firstElement;
				private OptionalDatum <T> i_lastElement;
				
				public NavigableLinkedHashSet () {
					i_elementToLinksHashMap = new Dictionary <T, Links> ();
					initialize ();
				}
				
				public NavigableLinkedHashSet (ISet <T> a_set) {
					i_elementToLinksHashMap = new Dictionary <T, Links> ();
					initialize ();
					putAll (a_set);
				}
				
				public NavigableLinkedHashSet (IEnumerable <T> a_enumerable) {
					i_elementToLinksHashMap = new Dictionary <T, Links> ();
					initialize ();
					putAll (a_enumerable);
				}
				
				public NavigableLinkedHashSet (IEqualityComparer <T> a_elementComparer) {
					i_elementToLinksHashMap = new Dictionary <T, Links> (a_elementComparer);
					initialize ();
				}
				
				public NavigableLinkedHashSet (Int32 a_initialCapacity) {
					i_elementToLinksHashMap = new Dictionary <T, Links> (a_initialCapacity);
					initialize ();
				}
				
				public NavigableLinkedHashSet (ISet <T> a_set, IEqualityComparer <T> a_elementComparer) {
					i_elementToLinksHashMap = new Dictionary <T, Links> (a_elementComparer);
					initialize ();
					putAll (a_set);
				}
				
				public NavigableLinkedHashSet (IEnumerable <T> a_enumerable, IEqualityComparer <T> a_elementComparer) {
					i_elementToLinksHashMap = new Dictionary <T, Links> (a_elementComparer);
					initialize ();
					putAll (a_enumerable);
				}
				
				public NavigableLinkedHashSet (Int32 a_initialCapacity, IEqualityComparer <T> a_elementComparer) {
					i_elementToLinksHashMap = new Dictionary <T, Links> (a_initialCapacity, a_elementComparer);
					initialize ();
				}
				
				~NavigableLinkedHashSet () {
				}
				
				private void initialize () {
					i_firstElement = new OptionalDatum <T> ();
					i_lastElement = new OptionalDatum <T> ();
				}
				
				public virtual Int32 Count {
					get {
						return i_elementToLinksHashMap.Count; 
					}
				}
				
				public virtual Boolean IsReadOnly {
					get {
						return false; 
					}
				}
				
				public virtual Boolean Add (T a_element) {
					Links l_links = new Links (i_lastElement, new OptionalDatum <T> ());
					if (Contains (a_element)) {
						return false;
					}
					else {
						i_elementToLinksHashMap.Add (a_element, l_links);
						OptionalDatum <T> l_previousElement = l_links.getPreviousElement ();
						if (l_previousElement.hasDatum ()) {
							i_elementToLinksHashMap [l_previousElement.getDatum ()].setNextElement (new OptionalDatum <T> (a_element));
						}
						else {
							i_firstElement = new OptionalDatum <T> (a_element);
						}
						i_lastElement = new OptionalDatum <T> (a_element);
						return true;
					}
				}
				
				void ICollection <T>.Add (T a_element) {
					this.Add (a_element);
				}
				
				public virtual void put (T a_element) {
					Add (a_element);
				}
				
				public virtual void putAll (IEnumerable <T> a_enumerable) {
					foreach (T l_element in a_enumerable) {
						put (l_element);
					}
				}
				
				public virtual void putBefore (T a_insertedPositionElement, T a_element) {
					if (i_elementToLinksHashMap.ContainsKey (a_element)) {
						throw new ArgumentException ("The element to be inserted already exists.");
					}
					else {
						// An exception will be thrown if the element does not exist.
						Links l_insertedPositionLinks = i_elementToLinksHashMap [a_insertedPositionElement];
						OptionalDatum <T> l_previousElementOfInsertedPosition = l_insertedPositionLinks.getPreviousElement ();
						Links l_links = new Links (l_previousElementOfInsertedPosition, new OptionalDatum <T> (a_insertedPositionElement));
						i_elementToLinksHashMap.Add (a_element, l_links);
						OptionalDatum <T> l_wrappedElement = new OptionalDatum <T> (a_element);
						if (l_previousElementOfInsertedPosition.hasDatum ()) {
							i_elementToLinksHashMap [l_previousElementOfInsertedPosition.getDatum ()].setNextElement (l_wrappedElement);
						}
						else {
							i_firstElement = l_wrappedElement;
						}
						l_insertedPositionLinks.setPreviousElement (l_wrappedElement);
					}
				}
				
				public virtual void Clear () {
					i_elementToLinksHashMap.Clear ();
					i_firstElement.removeDatum ();
					i_lastElement.removeDatum ();
				}
				
				public virtual Boolean Contains (T a_element) {
					return i_elementToLinksHashMap.ContainsKey (a_element);
				}
				
				public virtual void CopyTo (T [] a_elements, Int32 a_arrayIndex) {
					Int32 l_elementIndex = a_arrayIndex;
					foreach (T l_element in this) {
						a_elements [l_elementIndex] = l_element;
						l_elementIndex ++;
					}
				}
				
				public virtual void ExceptWith (IEnumerable <T> a_removedElements) {
					foreach (T l_removedElement in a_removedElements) {
						Remove (l_removedElement);
					}
				}
			
				public virtual IEnumerator <T> GetEnumerator () {
					return new NavigableLinkedHashSetEnumerator (this);
				}
				
				IEnumerator IEnumerable.GetEnumerator () {
					return this.GetEnumerator ();
				}
				
				public virtual void IntersectWith (IEnumerable <T> a_remainingElements) {
					ISet <T> l_remainingElements = null;
					if (a_remainingElements is ISet <T>) {
						l_remainingElements = (ISet <T>) a_remainingElements;
					}
					else {
						l_remainingElements = new HashSet <T> (a_remainingElements);
					}
					foreach (T l_element in this) {
						if (!(l_remainingElements.Contains (l_element))) {
							Remove (l_element);
						}
					}
				}
				
				public virtual Boolean IsProperSubsetOf (IEnumerable <T> a_comparedSet) {
					ISet <T> l_comparedSet = null;
					if (a_comparedSet is ISet <T>) {
						l_comparedSet = (ISet <T>) a_comparedSet;
					}
					else {
						l_comparedSet = new HashSet <T> (a_comparedSet);
					}
					Int32 l_numberOfElememtsOfThisSet = 0;
					foreach (T l_element in this) {
						if (!(l_comparedSet.Contains (l_element))) {
							return false;
						}
						else {
						}
						l_numberOfElememtsOfThisSet ++;
					}
					if (l_numberOfElememtsOfThisSet < l_comparedSet.Count) {
						return true;
					}
					else {
						return false;
					}
				}
				
				public virtual Boolean IsProperSupersetOf (IEnumerable <T> a_comparedSet) {
					Int32 l_numberOfElememtsOfComparedSet = 0;
					foreach (T l_comparedSetElement in a_comparedSet) {
						if (!(Contains (l_comparedSetElement))) {
							return false;
						}
						l_numberOfElememtsOfComparedSet ++;
					}
					if (Count > l_numberOfElememtsOfComparedSet ) {
						return true;
					}
					else {
						return false;
					}
				}
				
				public virtual Boolean IsSubsetOf (IEnumerable <T> a_comparedSet) {
					ISet <T> l_comparedSet = null;
					if (a_comparedSet is ISet <T>) {
						l_comparedSet = (ISet <T>) a_comparedSet;
					}
					else {
						l_comparedSet = new HashSet <T> (a_comparedSet);
					}
					foreach (T l_element in this) {
						if (!(l_comparedSet.Contains (l_element))) {
							return false;
						}
						else {
						}
					}
					return true;
				}
				
				public virtual Boolean IsSupersetOf (IEnumerable <T> a_comparedSet) {
					foreach (T l_comparedSetElement in a_comparedSet) {
						if (!(Contains (l_comparedSetElement))) {
							return false;
						}
					}
					return true;
				}
				
				public Boolean Overlaps (IEnumerable <T> a_comparedSet) {
					foreach (T l_comparedSetElement in a_comparedSet) {
						if (Contains (l_comparedSetElement)) {
							return true;
						}
					}
					return false;
				}
				
				public virtual Boolean Remove (T a_element) {
					if (i_elementToLinksHashMap.ContainsKey (a_element)) {
						Links l_links = i_elementToLinksHashMap [a_element];
						i_elementToLinksHashMap.Remove (a_element);
						OptionalDatum <T> l_previousElement = l_links.getPreviousElement ();
						OptionalDatum <T> l_nextElement = l_links.getNextElement ();
						if (l_previousElement.hasDatum ()) {
							i_elementToLinksHashMap [l_previousElement.getDatum ()].setNextElement (l_nextElement);
						}
						else {
							i_firstElement = l_nextElement;
						}
						if (l_nextElement.hasDatum ()) {
							i_elementToLinksHashMap [l_nextElement.getDatum ()].setPreviousElement (l_previousElement);
						}
						else {
							i_lastElement = l_previousElement;
						}
						return true;
					}
					else {
						return false;
					}
				}
				
				public Boolean SetEquals (IEnumerable <T> a_comparedSet) {
					Int32 l_numberOfElememtsOfComparedSet = 0;
					foreach (T l_comparedSetElement in a_comparedSet) {
						if (!(Contains (l_comparedSetElement))) {
							return false;
						}
						else {
						}
						l_numberOfElememtsOfComparedSet ++;
					}
					if (Count == l_numberOfElememtsOfComparedSet) {
						return true;
					}
					else {
						return false;
					}
				}
				
				public void SymmetricExceptWith (IEnumerable <T> a_comparedSet) {
					foreach (T l_comparedElement in a_comparedSet) {
						if (Contains (l_comparedElement)) {
							Remove (l_comparedElement);
						}
						else {
							Add (l_comparedElement);
						}
					}
				}
				
				public void UnionWith (IEnumerable <T> a_comparedSet) {
					foreach (T l_comparedElement in a_comparedSet) {
						put (l_comparedElement);
					}
				}
				
				public virtual OptionalDatum <T> getPreviousElement (T a_element) {
					if (i_elementToLinksHashMap.ContainsKey (a_element)) {
						Links l_links = i_elementToLinksHashMap [a_element];
						return l_links.getPreviousElement ();
					}
					else {
						return new OptionalDatum <T> ();
					}
				}
				
				public virtual OptionalDatum <T> getNextElement (T a_element) {
					if (i_elementToLinksHashMap.ContainsKey (a_element)) {
						Links l_links = i_elementToLinksHashMap [a_element];
						return l_links.getNextElement ();
					}
					else {
						return new OptionalDatum <T> ();
					}
				}
				
				public OptionalDatum <T> getFirstElement () {
					return i_firstElement;
				}
				
				public OptionalDatum <T> getLastElement () {
					return i_lastElement;
				}
			}
		}
	}
}

