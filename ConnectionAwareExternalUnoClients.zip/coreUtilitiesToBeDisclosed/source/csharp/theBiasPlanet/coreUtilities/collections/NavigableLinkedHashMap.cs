namespace theBiasPlanet {
	namespace coreUtilities {
		namespace collections {
			using System;
			using System.Collections;
			using System.Collections.Generic;
			using System.Runtime.Serialization;
			using theBiasPlanet.coreUtilities.optionalDatum;
			
			public class NavigableLinkedHashMap <T, U>: IDictionary <T, U> {
				private class ValueAndLinks {
					U i_value;
					OptionalDatum <T> i_previousKey;
					OptionalDatum <T> i_nextKey;
					
					public ValueAndLinks (U a_value, OptionalDatum <T> a_previousKey, OptionalDatum <T> a_nextKey) {
						i_value = a_value;
						i_previousKey = a_previousKey;
						i_nextKey = a_nextKey;
					}
					
					~ValueAndLinks () {
					}
					
					public virtual U getValue () {
						return i_value;
					}
					
					public virtual void setValue (U a_value) {
						i_value = a_value;
					}
					
					public virtual OptionalDatum <T> getPreviousKey () {
						return i_previousKey;
					}
					
					public virtual void setPreviousKey (OptionalDatum <T> a_previousKey) {
						i_previousKey = a_previousKey;
					}
					
					public virtual OptionalDatum <T> getNextKey () {
						return i_nextKey;
					}
					
					public virtual void setNextKey (OptionalDatum <T> a_nextKey) {
						i_nextKey = a_nextKey;
					}
				}
				
				private class NavigableLinkedHashMapEnumerator : IEnumerator <KeyValuePair <T, U>> {
					private Dictionary <T, ValueAndLinks> i_keyToValueAndLinksHashMap = null;
					private OptionalDatum <T> i_firstKey = null;
					private OptionalDatum <T> i_lastKey = null;
					private OptionalDatum <T> i_currentKey = null;
					private Boolean i_isAtAfterLastKey = false; // this is required, because the current key's being empty means that the current key is before the first key or that the current key is after the last key, unlike in C++.
					public NavigableLinkedHashMapEnumerator (NavigableLinkedHashMap <T, U> a_navigableLinkedHashMap) {
						i_keyToValueAndLinksHashMap = a_navigableLinkedHashMap.i_keyToValueAndLinksHashMap;
						i_firstKey = a_navigableLinkedHashMap.i_firstKey;
						i_lastKey = a_navigableLinkedHashMap.i_lastKey;
						i_currentKey = new OptionalDatum <T> ();
						if (!i_firstKey.hasDatum ()) {
							i_isAtAfterLastKey = true;
						}
					}
					
					~NavigableLinkedHashMapEnumerator () {
					}
					
					public virtual KeyValuePair <T, U> Current {
						get {
							if (i_currentKey.hasDatum ()) {
								ValueAndLinks l_currentValueAndLinks = i_keyToValueAndLinksHashMap [i_currentKey.getDatum ()];
								return new KeyValuePair <T, U> (i_currentKey.getDatum (), l_currentValueAndLinks.getValue ());
							}
							else {
								return new KeyValuePair <T, U> (default (T), default (U));
							}
						}
					}
					
					Object IEnumerator.Current {
						get {
							return this.Current;
						}
					}
					
					public virtual Boolean MoveNext () {
						if (i_isAtAfterLastKey) {
							return false;
						}
						else {
							if (i_currentKey.hasDatum ()) {
								ValueAndLinks l_currentValueAndLinks = i_keyToValueAndLinksHashMap [i_currentKey.getDatum ()];
								i_currentKey = l_currentValueAndLinks.getNextKey ();
								if (i_currentKey.hasDatum ()) {
									return true;
								}
								else {
									i_isAtAfterLastKey = true;
									return false;
								}
							}
							else {
								i_currentKey = i_firstKey;
								return true;
							}
						}
					}
					
					public virtual void Reset () {
						i_currentKey = new OptionalDatum <T> ();
						if (!i_firstKey.hasDatum ()) {
							// This is just in order to avoid a warning of 'i_lastKey''s not being used.
							if (!i_lastKey.hasDatum ()) {
							}
							i_isAtAfterLastKey = true;
						}
					}
					
					public virtual void Dispose () {
					}
				}
				
				private Dictionary <T, ValueAndLinks> i_keyToValueAndLinksHashMap;
				private OptionalDatum <T> i_firstKey;
				private OptionalDatum <T> i_lastKey;
				
				public NavigableLinkedHashMap () {
					i_keyToValueAndLinksHashMap = new Dictionary <T, ValueAndLinks> ();
					initialize ();
				}
				
				public NavigableLinkedHashMap (IDictionary <T, U> a_map) {
					i_keyToValueAndLinksHashMap = new Dictionary <T, ValueAndLinks> (a_map.Count);
					initialize ();
					putAll (a_map);
				}
				
				public NavigableLinkedHashMap (IEnumerable <KeyValuePair <T,U>> a_enumerable) {
					i_keyToValueAndLinksHashMap = new Dictionary <T, ValueAndLinks> ();
					initialize ();
					putAll (a_enumerable);
				}
				
				public NavigableLinkedHashMap (IEqualityComparer <T> a_keyComparer) {
					i_keyToValueAndLinksHashMap = new Dictionary <T, ValueAndLinks> (a_keyComparer);
					initialize ();
				}
				
				public NavigableLinkedHashMap (Int32 a_initialCapacity) {
					i_keyToValueAndLinksHashMap = new Dictionary <T, ValueAndLinks> (a_initialCapacity);
					initialize ();
				}
				
				public NavigableLinkedHashMap  (IDictionary <T, U> a_map, IEqualityComparer <T> a_keyComparer) {
					i_keyToValueAndLinksHashMap = new Dictionary <T, ValueAndLinks> (a_map.Count, a_keyComparer);
					initialize ();
					putAll (a_map);
				}
				
				public NavigableLinkedHashMap (IEnumerable <KeyValuePair <T,U>> a_enumerable, IEqualityComparer <T> a_keyComparer) {
					i_keyToValueAndLinksHashMap = new Dictionary <T, ValueAndLinks> (a_keyComparer);
					initialize ();
					putAll (a_enumerable);
				}
				
				public NavigableLinkedHashMap (Int32 a_initialCapacity, IEqualityComparer <T> a_keyComparer) {
					i_keyToValueAndLinksHashMap = new Dictionary <T, ValueAndLinks> (a_initialCapacity, a_keyComparer);
					initialize ();
				}
				
				/*
				protected NavigableLinkedHashMap (SerializationInfo a_serializationInformation, StreamingContext a_streamingContext) {
				}
				*/
				
				~NavigableLinkedHashMap () {
				}
				
				private void initialize () {
					i_firstKey = new OptionalDatum <T> ();
					i_lastKey = new OptionalDatum <T> ();
				}
				
				public virtual Int32 Count {
					get {
						return i_keyToValueAndLinksHashMap.Count; 
					}
				}
				
				public virtual Boolean IsReadOnly {
					get {
						return false; 
					}
				}
				
				public virtual U this [T a_key] {
					get {
						// A 'KeyNotFoundException' exception will be thrown if the key does not exist.
						ValueAndLinks l_valueAndLinks = i_keyToValueAndLinksHashMap [a_key];
						return l_valueAndLinks.getValue (); 
					}
					
					set {
						// A 'KeyNotFoundException' exception will be thrown if the key does not exist.
						ValueAndLinks l_valueAndLinks = i_keyToValueAndLinksHashMap [a_key];
						l_valueAndLinks.setValue (value);
					}
				}
				
				public virtual ICollection <T> Keys {
					get {
						List <T> l_keys = new List <T> (i_keyToValueAndLinksHashMap.Count);
						foreach (KeyValuePair <T, U> l_element in this) {
							l_keys.Add (l_element.Key);
						}
						return l_keys; 
					}
				}
				
				public virtual ICollection <U> Values {
					get {
						List <U> l_values = new List <U> (i_keyToValueAndLinksHashMap.Count);
						foreach (KeyValuePair <T, U> l_element in this) {
							l_values.Add (l_element.Value);
						}
						return l_values; 
					}
				}
				
				public virtual void Add (KeyValuePair <T, U> a_element) {
					Add (a_element.Key, a_element.Value);
				}
				
				public virtual void Add (T a_key, U a_value) {
					ValueAndLinks l_valueAndLinks = new ValueAndLinks (a_value, i_lastKey, new OptionalDatum <T> ());
					// An exception will be thrown if the key already exists.
					i_keyToValueAndLinksHashMap.Add (a_key, l_valueAndLinks);
					OptionalDatum <T> l_previousKey = l_valueAndLinks.getPreviousKey ();
					if (l_previousKey.hasDatum ()) {
						i_keyToValueAndLinksHashMap [l_previousKey.getDatum ()].setNextKey (new OptionalDatum <T> (a_key));
					}
					else {
						i_firstKey = new OptionalDatum <T> (a_key);
					}
					i_lastKey = new OptionalDatum <T> (a_key);
				}
				
				public virtual void put (KeyValuePair <T, U> a_element) {
					put (a_element.Key, a_element.Value);
				}
				
				public virtual void put (T a_key, U a_value) {
					if (ContainsKey (a_key)) {
						this [a_key] = a_value;
					}
					else {
						Add (a_key, a_value);
					}
				}
				
				public virtual void putAll (IEnumerable <KeyValuePair <T,U>> a_enumerable) {
					foreach (KeyValuePair <T, U> l_element in a_enumerable) {
						put (l_element);
					}
				}
				
				public virtual void putBefore (T a_insertedPositionKey, T a_key, U a_value) {
					if (i_keyToValueAndLinksHashMap.ContainsKey (a_key)) {
						throw new ArgumentException ("The key to be inserted already exists.");
					}
					else {
						// An exception will be thrown if the key does not exist.
						ValueAndLinks l_insertedPositionValueAndLinks = i_keyToValueAndLinksHashMap [a_insertedPositionKey];
						OptionalDatum <T> l_previousKeyOfInsertedPosition = l_insertedPositionValueAndLinks.getPreviousKey ();
						ValueAndLinks l_valueAndLinks = new ValueAndLinks (a_value, l_previousKeyOfInsertedPosition, new OptionalDatum <T> (a_insertedPositionKey));
						i_keyToValueAndLinksHashMap.Add (a_key, l_valueAndLinks);
						OptionalDatum <T> l_wrappedKey = new OptionalDatum <T> (a_key);
						if (l_previousKeyOfInsertedPosition.hasDatum ()) {
							i_keyToValueAndLinksHashMap [l_previousKeyOfInsertedPosition.getDatum ()].setNextKey (l_wrappedKey);
						}
						else {
							i_firstKey = l_wrappedKey;
						}
						l_insertedPositionValueAndLinks.setPreviousKey (l_wrappedKey);
					}
				}
				
				public virtual void Clear () {
					i_keyToValueAndLinksHashMap.Clear ();
					i_firstKey.removeDatum ();
					i_lastKey.removeDatum ();
				}
				
				public virtual Boolean Contains (KeyValuePair <T, U> a_element) {
					if (i_keyToValueAndLinksHashMap.ContainsKey (a_element.Key)) {
						return EqualityComparer <U>.Default.Equals (this [a_element.Key], a_element.Value);
					}
					else {
						return false;
					}
				}
				
				public virtual Boolean ContainsKey (T a_key) {
					return i_keyToValueAndLinksHashMap.ContainsKey (a_key);
				}
				
				public virtual void CopyTo (KeyValuePair <T, U> [] a_elements, Int32 a_arrayIndex) {
					Int32 l_elementIndex = a_arrayIndex;
					foreach (KeyValuePair <T, U> l_element in this) {
						a_elements [l_elementIndex] = l_element;
						l_elementIndex ++;
					}
				}
				
				public virtual IEnumerator <KeyValuePair <T, U>> GetEnumerator () {
					return new NavigableLinkedHashMapEnumerator (this);
				}
				
				IEnumerator IEnumerable.GetEnumerator () {
					return this.GetEnumerator ();
				}
				
				public virtual Boolean Remove (T a_key) {
					if (i_keyToValueAndLinksHashMap.ContainsKey (a_key)) {
						ValueAndLinks l_valueAndLinks = i_keyToValueAndLinksHashMap [a_key];
						i_keyToValueAndLinksHashMap.Remove (a_key);
						OptionalDatum <T> l_previousKey = l_valueAndLinks.getPreviousKey ();
						OptionalDatum <T> l_nextKey = l_valueAndLinks.getNextKey ();
						if (l_previousKey.hasDatum ()) {
							i_keyToValueAndLinksHashMap [l_previousKey.getDatum ()].setNextKey (l_nextKey);
						}
						else {
							i_firstKey = l_nextKey;
						}
						if (l_nextKey.hasDatum ()) {
							i_keyToValueAndLinksHashMap [l_nextKey.getDatum ()].setPreviousKey (l_previousKey);
						}
						else {
							i_lastKey = l_previousKey;
						}
						return true;
					}
					else {
						return false;
					}
				}
				
				public virtual Boolean Remove (KeyValuePair <T, U> a_element) {
					return Remove (a_element.Key);
				}
				
				public virtual Boolean TryGetValue (T a_key, out U a_value) {
					if (ContainsKey (a_key)) {
						a_value = this [a_key];
						return true;
					}
					else {
						a_value = default (U);
						return false;
					}
				}
				
				public virtual OptionalDatum <T> getPreviousKey (T a_key) {
					if (i_keyToValueAndLinksHashMap.ContainsKey (a_key)) {
						ValueAndLinks l_valueAndLinks = i_keyToValueAndLinksHashMap [a_key];
						return l_valueAndLinks.getPreviousKey ();
					}
					else {
						return new OptionalDatum <T> ();
					}
				}
				
				public virtual OptionalDatum <T> getNextKey (T a_key) {
					if (i_keyToValueAndLinksHashMap.ContainsKey (a_key)) {
						ValueAndLinks l_valueAndLinks = i_keyToValueAndLinksHashMap [a_key];
						return l_valueAndLinks.getNextKey ();
					}
					else {
						return new OptionalDatum <T> ();
					}
				}
				
				public OptionalDatum <T> getFirstKey () {
					return i_firstKey;
				}
				
				public OptionalDatum <T> getLastKey () {
					return i_lastKey;
				}
			}
		}
	}
}

