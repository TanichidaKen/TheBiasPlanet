namespace theBiasPlanet {
	namespace coreUtilities {
		namespace collectionsHandling {
			using System;
			using System.Collections;
			using System.Collections.Generic;
			using theBiasPlanet.coreUtilities.collections;
			
			public static class SetsFactory {
				public static NavigableLinkedHashSet <T> createNavigableLinkedHashSet <T> (params Object [] a_items) {
					NavigableLinkedHashSet <T> l_navigableLinkedHashSet = new NavigableLinkedHashSet <T> ();
					if (a_items != null) {
						foreach (Object l_item in a_items) {
							l_navigableLinkedHashSet.Add ( (T) l_item);
						}
					}
					return l_navigableLinkedHashSet;
				}
				
				public static NavigableLinkedHashSet  <T> createNavigableLinkedHashSetExpandingItems <T> (params Object [] a_items) {
					NavigableLinkedHashSet <T> l_navigableLinkedHashSet = new NavigableLinkedHashSet <T> ();
					if (a_items != null) {
						foreach (Object l_item in a_items) {
							Type l_itemType = l_item.GetType ();
							Boolean l_currentArgumentIsSet = false;
							foreach (Type l_implementedInterface in l_itemType.GetInterfaces () ) {
								if (l_implementedInterface.IsGenericType) {
							  		if (l_implementedInterface.GetGenericTypeDefinition () == typeof (ISet<>)) {
										l_currentArgumentIsSet = true;
										break;
									}
									else {
									}
								}
								else {
								}
							}
							if (l_currentArgumentIsSet) {
							
								foreach (Object l_setElement in (IEnumerable) l_item) {
									l_navigableLinkedHashSet.Add ( (T) l_setElement);
								}
							}
							else {
								l_navigableLinkedHashSet.Add ( (T) l_item);
							}
						}
					}
					else {
					}
					return l_navigableLinkedHashSet ;
				}
			}
		}
	}
}

