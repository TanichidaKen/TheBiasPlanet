namespace theBiasPlanet {
	namespace coreUtilities {
		namespace collectionsHandling {
			using System;
			using System.Collections;
			using System.Collections.Generic;
			using theBiasPlanet.coreUtilities.collections;
			
			public static class MapsFactory {
				public static NavigableLinkedHashMap <T, U> createNavigableLinkedHashMap <T, U> (params Object [] a_alternatelyKeyAndValue) {
					NavigableLinkedHashMap <T, U> l_navigableLinkedHashMap = new NavigableLinkedHashMap <T, U> ();
					Boolean l_currentArgumentIsKey = true;
					T l_key = default (T);
					if (a_alternatelyKeyAndValue != null) {
						foreach (Object l_keyOrValue in a_alternatelyKeyAndValue) {
							if (l_currentArgumentIsKey) {
								l_key = (T) l_keyOrValue;
								l_currentArgumentIsKey = false;
							}
							else {
								l_navigableLinkedHashMap.Add (l_key, (U) l_keyOrValue);
								l_currentArgumentIsKey = true;
							}
						}
					}
					else {
					}
					return l_navigableLinkedHashMap ;
				}
				
				public static NavigableLinkedHashMap  <T, U> createNavigableLinkedHashMapExpandingItems <T, U> (params Object [] a_alternatelyKeyAndValueOrMaps) {
					NavigableLinkedHashMap <T, U> l_navigableLinkedHashMap = new NavigableLinkedHashMap <T, U> ();
					Boolean l_currentArgumentIsKey = true;
					T l_key = default (T);
					Boolean l_currentArgumentIsMap = false;
					if (a_alternatelyKeyAndValueOrMaps != null) {
						foreach (Object l_keyOrValueOrMap in a_alternatelyKeyAndValueOrMaps) {
							Type l_keyOrValueOrMapType = l_keyOrValueOrMap.GetType ();
							l_currentArgumentIsMap = false;
							foreach (Type l_implementedInterface in l_keyOrValueOrMapType.GetInterfaces () ) {
								if (l_implementedInterface.IsGenericType) {
							  		if (l_implementedInterface.GetGenericTypeDefinition () == typeof (IDictionary<, >)) {
										l_currentArgumentIsMap = true;
										break;
									}
									else {
									}
								}
								else {
									if (l_implementedInterface == typeof (IDictionary)) {
										l_currentArgumentIsMap = true;
										break;
									}
								}
							}
							if (l_currentArgumentIsMap) {
							
								foreach (Object l_mapEntry in (IEnumerable) l_keyOrValueOrMap) {
									l_navigableLinkedHashMap.Add ((T) l_mapEntry.GetType ().GetProperty ("Key").GetValue (l_mapEntry, null), (U) l_mapEntry.GetType ().GetProperty ("Value").GetValue (l_mapEntry, null));
								}
								l_currentArgumentIsKey = true;
							}
							else {
								if (l_currentArgumentIsKey) {
									l_key = (T) l_keyOrValueOrMap ;
									l_currentArgumentIsKey = false;
								}
								else {
									l_navigableLinkedHashMap.Add (l_key, (U) l_keyOrValueOrMap );
									l_currentArgumentIsKey = true;
								}
							}
						}
					}
					else {
					}
					return l_navigableLinkedHashMap ;
				}
			}
		}
	}
}

