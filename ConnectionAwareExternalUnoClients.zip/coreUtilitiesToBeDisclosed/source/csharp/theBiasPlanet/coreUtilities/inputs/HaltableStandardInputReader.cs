namespace theBiasPlanet {
	namespace coreUtilities {
		namespace inputs {
			using System;
			using theBiasPlanet.coreUtilities.constantsGroups;
			
			public class HaltableStandardInputReader: HaltableReader {
				private static HaltableStandardInputReader s_singletonInstance = null;
				
				private HaltableStandardInputReader (): base (Console.In, DefaultValuesConstantsGroup.c_smallBufferSize) {
				}
				
				public static HaltableStandardInputReader getInstance () {
					if (s_singletonInstance == null) {
						s_singletonInstance = new HaltableStandardInputReader ();
					}
					return s_singletonInstance;
				}
			}
		}
	}
}

