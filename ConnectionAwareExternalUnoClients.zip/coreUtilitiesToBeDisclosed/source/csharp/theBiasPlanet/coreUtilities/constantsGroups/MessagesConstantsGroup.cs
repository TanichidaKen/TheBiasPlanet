namespace theBiasPlanet {
	namespace coreUtilities {
		namespace constantsGroups {
			using System;
			
			public static class MessagesConstantsGroup {
				public const String c_notConnected = "Not connected.";
				public const String c_connected = "Connected.";
				public const String c_exiting = "Exiting . . .";
				public const String c_accepting = "Accepting . . .";
				public const String c_connecting = "Connecting . . .";
				public const String c_fromHeader = "From";
				public const String c_replacingConfirmation = "Do you replace this?";
				public const String c_invalidAxis = "Invalid Axis: %s";
				public const String c_errorHasOccurred = "An error has occurred: %s.";
			}
		}
	}
}

