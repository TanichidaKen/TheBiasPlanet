namespace theBiasPlanet {
	namespace coreUtilities {
		namespace constantsGroups {
			using System;
			using System.Text.RegularExpressions;
			
			public static class RegularExpressionsConstantsGroup {
				public static readonly Regex c_numbersRegularExpression = new Regex ("^(\\d*|\\d{1,3}(,\\d{3})*)(\\.\\d+)?([eE][-+]?\\d+)?$");
				public static readonly Regex c_dateAndTimesRegularExpression = new Regex ("(\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2})(.\\d*)?");
				public static readonly Regex c_datesRegularExpression = new Regex ("(\\d{4}-\\d{2}-\\d{2})");
				public static readonly Regex c_timesRegularExpression = new Regex ("(\\d{2}:\\d{2}:\\d{2})");
				public static readonly Regex c_csharpPackageDelimiterRegularExpression = new Regex ("\\.");
				public static readonly Regex c_windowsDirectoryDelimiterRegularExpression = new Regex ("\\\\");
				public static readonly Regex c_wordRegularExpression = new Regex ("(\\w+)");
				public static readonly Regex c_termRegularExpression = new Regex ("(\\S+)");
				public static readonly Regex c_doubleQuotedTermRegularExpression = new Regex ("\"(\\S+)\"");
				public static readonly Regex c_urlRegularExpression = new Regex ("(\\b(https?|ftp|file)://)?[-A-Za-z0-9+&@#/%?=~_|!:,.;]+[-A-Za-z0-9+&@#/%=~_|]");
			}
		}
	}
}

