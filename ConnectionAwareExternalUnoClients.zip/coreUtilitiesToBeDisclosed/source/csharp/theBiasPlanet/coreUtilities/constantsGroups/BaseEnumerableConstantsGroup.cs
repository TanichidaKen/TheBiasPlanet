namespace theBiasPlanet {
	namespace coreUtilities {
		namespace constantsGroups {
			// ## Comments that start with the mark, ##, are instructions for extending this class, where XXX is the class name of the extended class.
			using System;
			using System.Collections.Generic;
			using theBiasPlanet.coreUtilities.collections;
			using theBiasPlanet.coreUtilities.collectionsHandling;
			using theBiasPlanet.coreUtilities.reflectionHandling;
			
			// ## The class has to be public, extend BaseConstantsGroup, and implement some constants group interfaces of T constants
			abstract public class BaseEnumerableConstantsGroup <T> {
				private NavigableLinkedHashMap <String, T> i_nameToValueMap;
				// ## Define this.
				// ## public static final XXX c_instance = new XXX ();
				
				// ## Define the private constructor.
				
				protected BaseEnumerableConstantsGroup () {
					i_nameToValueMap = MapsFactory.createNavigableLinkedHashMapExpandingItems <String, T> (ReflectionHandler.getFieldNameToValueMap (this.GetType (), null, true, false, null, ListsFactory.createList <Type> (this.GetType ()), true));
				}
				
				public virtual NavigableLinkedHashSet <String> getNames () {
					return new NavigableLinkedHashSet <String> (i_nameToValueMap.Keys);
				}
	
				public List <T> getValues () {
					return ListsFactory.createListExpandingItems <T> (i_nameToValueMap.Values);
				}
			}
		}
	}
}

