namespace theBiasPlanet {
	namespace coreUtilities {
		namespace constantsGroups {
			using System;
			using theBiasPlanet.coreUtilities.collections;
			using theBiasPlanet.coreUtilities.collectionsHandling;
			
			public static class GeneralConstantsConstantsGroup {
				public const Int32 c_maximumBytesLengthPerUtf8Character = 4;
				public const Int32 c_numberOfAlphabets = 26;
				public const Int32 c_unspecifiedInteger = -1;
				public const Single c_unspecifiedFloat = -1.0f;
				public const Char c_unspecifiedCharacter = (Char) 0;
				public const Int32 c_iterationStartNumber = 0;
				public const Int32 c_normalResult = 0;
				public const String c_emptyString = "";
				public const Char c_radixPointCharacter = '.';
				public const Char c_thousandsDelimiter = ',';
				public const Char c_minimumDigit = '0';
				public const Char c_maximumDigit = '9';
				public const Char c_plusCharacter = '+';
				public const Char c_minusCharacter = '-';
				public const Char c_exponentOpener1 = 'E';
				public const Char c_exponentOpener2 = 'e';
				public const Char c_unicodeEscapeIndicator = 'u';
				public const Char c_escapingCharacter = '\\';
				public const Char c_newLineCharacter = '\n';
				public const Char c_carriageReturnCharacter = '\r';
				public const Char c_tabCharacter = '\t';
				public const Char c_colonCharacter = ':';
				public const Char c_semicolonCharacter = ';';
				public const Char c_spaceCharacter = ' ';
				public const Char c_equalCharacter = '=';
				public const Char c_utfBomCharacter = '\uFEFF';
				public const Char c_lessThanCharacter = '<';
				public const Char c_greaterThanCharacter = '>';
				public const Char c_ampersandCharacter = '&';
				public const Char c_doubleQuotationMarkCharacter = '\"';
				public const Char c_apostropheCharacter = '\'';
				public const Char c_controlCharactersStart = (Char) 0x00;
				public const Char c_controlCharactersUntil = (Char) 0x20;
				public const Char c_argumentsDelimiter = ' ';
				public static readonly String c_carriageReturnAndNewLineString = String.Format ("{0:c}{1:c}", c_carriageReturnCharacter, c_newLineCharacter);
				public const String c_notANumberExpression = "NaN";
				public const String c_positiveInfinityExpression = "Infinity";
				public static readonly String c_negativeInfinityExpression = String.Format ("{0:c}{1:s}", c_minusCharacter, c_positiveInfinityExpression);
				public const String c_nullExpression = "null";
				public const String c_trueExpression = "true";
				public const String c_falseExpression = "false";
				public const String c_colonDelimiter = ": ";
				public const String c_commaDelimiter = ", ";
				public const Char c_linuxDirectoriesDelimiter = '/';
				public const Char c_windowsDirectoriesDelimiter = '\\';
				public const Char c_javaPackagesDelimiter = '.';
				public const Char c_fileNameElementsDelimiter = '.';
				public const Char c_nameElementsDelimiter = '_';
				public const Char c_linuxPathsDelimiter = ':';
				public const Char c_windowsPathsDelimiter = ';';
				public const Char c_dataCommentLineStarter = '#';
				public const String c_jsonItemsSeparator = c_commaDelimiter;
				public const String c_jsonKeyValueSeparator = c_colonDelimiter;
				public static readonly Char c_jsonItemsSeparatorOpener = c_jsonItemsSeparator [c_iterationStartNumber];
				public static readonly Char c_jsonKeyValueSeparatorOpener = c_jsonKeyValueSeparator [c_iterationStartNumber];
				public const Char c_jsonDictionaryOpener = '{';
				public const Char c_jsonDictionaryCloser = '}';
				public const Char c_jsonArrayOpener = '[';
				public const Char c_jsonArrayCloser = ']';
				public const Char c_jsonDateEtcOpener = 'd';
				public const Char c_jsonDateAndTimeTimePartOpener = 'T';
				public const Char c_jsonBytesArrayOpener = 'b';
				public const String c_integerDefaultFormat = "d";
				public const String c_doubleDefaultFormat = "f";
				public const String c_booleanDefaultFormat = "b";
				public const String c_hexadecimalStringFormat = "0x%s";
				public const String c_globExpressionFormat = "glob:%s";
				public const String c_commandSwitchOrFlagStarter = "-";
				public static readonly String c_linuxDirectoryPathFormat = String.Format ("{{0}}{0}{{1}}", c_linuxDirectoriesDelimiter);
				public static readonly String c_windowsDirectoryPathFormat = String.Format ("{{0}}{0}{{1}}", c_windowsDirectoriesDelimiter);
				public static readonly String c_linuxFilePathFormat = String.Format ("{{0}}{0}{{1}}", c_linuxDirectoriesDelimiter);
				public static readonly String c_windowsFilePathFormat = String.Format ("{{0}}{0}{{1}}", c_windowsDirectoriesDelimiter);
				public static readonly String c_fileNameFormat = String.Format ("%%s%s%%s", c_fileNameElementsDelimiter);
				public static readonly String c_javaClassNameFormat = String.Format ("{{0}}{0}{{1}}", c_javaPackagesDelimiter);
				public static readonly String c_styleSheetFileNameFormat = String.Format ("{{0}}{0}{1}", c_fileNameElementsDelimiter, FileNameSuffixesConstantsGroup.c_styleSheetFileNameSuffix);
				public static readonly String c_javaFileNameFormat = String.Format ("{{0}}{0}{1}", c_fileNameElementsDelimiter, FileNameSuffixesConstantsGroup.c_javaFileNameSuffix);
				public const String c_quotedByDoubleQuotationsFormat = "\"{0}\"";
				public const String c_quotedByAngleBracketsFormat = "<{0}>";
				public static readonly String c_definitionNameFormat = String.Format ("{0}{0}{{0}}{0}{0}", c_nameElementsDelimiter);
				public const String c_plus = "+";
				public const String c_propertyValueFormat = "${{{0}}}";
				public static readonly NavigableLinkedHashMap <String, Char> c_escapedCharacterToCharacterMap = MapsFactory.createNavigableLinkedHashMap <String, Char> ("\\\\", '\\', "\\\"", '\"', "\\b", '\b', "\\f", '\f', "\\n", '\n', "\\r", '\r', "\\t", '\t');
				public static readonly NavigableLinkedHashMap <Char, Int32> c_alphabetToAlphabetIndexMap = MapsFactory.createNavigableLinkedHashMap <Char, Int32> ('A', 0, 'B', 1, 'C', 2, 'D', 3, 'E', 4, 'F', 5, 'G', 6, 'H', 7, 'I', 8, 'J', 9, 'K', 10, 'L', 11, 'M', 12, 'N', 13, 'O', 14, 'P', 15, 'Q', 16, 'R', 17, 'S', 18, 'T', 19, 'U', 20, 'V', 21, 'W', 22, 'X', 23, 'Y', 24, 'Z', 25);
				public static readonly NavigableLinkedHashMap  <Int32, Char> c_alphabetIndexToAlphabetMap = MapsFactory.createNavigableLinkedHashMap <Int32, Char> ( 0, 'A', 1, 'B', 2, 'C', 3, 'D', 4, 'E', 5, 'F', 6, 'G', 7, 'H', 8, 'I', 9, 'J', 10, 'K', 11, 'L', 12, 'M', 13, 'N', 14, 'O', 15, 'P', 16, 'Q', 17, 'R', 18, 'S', 19, 'T', 20, 'U', 21, 'V', 22, 'W', 23, 'X', 24, 'Y', 25, 'Z');
			}
		}
	}
}

