namespace theBiasPlanet {
	namespace coreUtilities {
		namespace constantsGroups {
			using System;
			
			public static class OperatingSystemNamesConstantsGroup {
				public const String c_linux = "Linux";
				public const String c_windows = "Windows";
			}
		}
	}
}

