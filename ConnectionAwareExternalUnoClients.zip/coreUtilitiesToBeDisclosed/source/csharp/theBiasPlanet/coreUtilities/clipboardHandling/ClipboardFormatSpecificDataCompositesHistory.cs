namespace theBiasPlanet {
	namespace coreUtilities {
		namespace clipboardHandling {
			using System;
			using System.Collections.Generic;
			using theBiasPlanet.coreUtilities.collections;
			
			public class ClipboardFormatSpecificDataCompositesHistory {
				private NavigableLinkedHashMap <String, ClipboardFormatSpecificDataComposite> i_dataCompositeKeyToDataCompositeMap = new NavigableLinkedHashMap <String, ClipboardFormatSpecificDataComposite> ();
				
				public ClipboardFormatSpecificDataCompositesHistory () {
				}
				
				~ClipboardFormatSpecificDataCompositesHistory () {
				}
				
				public Boolean addDataComposite (String a_dataCompositeKey, ClipboardFormatSpecificDataComposite a_dataComposite) {
					try {
						i_dataCompositeKeyToDataCompositeMap [a_dataCompositeKey] = a_dataComposite;
					}
					catch (KeyNotFoundException) {
						i_dataCompositeKeyToDataCompositeMap.Add (a_dataCompositeKey, a_dataComposite);
					}
					return true;
				}
				
				public Boolean removeDataComposite (String a_dataCompositeKey) {
					i_dataCompositeKeyToDataCompositeMap.Remove (a_dataCompositeKey);
					return true;
				}
				
				public ClipboardFormatSpecificDataComposite getDataComposite (String a_dataCompositeKey) {
					return i_dataCompositeKeyToDataCompositeMap [a_dataCompositeKey];
				}
			}
		}
	}
}

