namespace theBiasPlanet {
	namespace coreUtilities {
		namespace clipboardHandling {
			using System;
			
			public class ClipboardFormatSpecificDatum {
				private String i_formatName;
				private	Object i_datum;
				
				public ClipboardFormatSpecificDatum () {
				}
				
				public ClipboardFormatSpecificDatum (String a_formatName, Object a_datum) {
					i_formatName = a_formatName;
					i_datum = a_datum;
				}
				
				~ClipboardFormatSpecificDatum () {
				}
				
				public String getFormatName () {
					return i_formatName;
				}
				
				/*
				public Int32 getDatumSize () {
					return i_datum.Length;
				}
				*/
				
				public Object getDatum () {
					return i_datum;
				}
			}
		}
	}
}

