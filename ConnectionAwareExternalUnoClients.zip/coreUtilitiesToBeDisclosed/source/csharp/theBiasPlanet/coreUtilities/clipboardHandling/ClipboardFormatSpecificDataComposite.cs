namespace theBiasPlanet {
	namespace coreUtilities {
		namespace clipboardHandling {
			using System;
			using System.Collections.Generic;
			using theBiasPlanet.coreUtilities.collections;
			
			public class ClipboardFormatSpecificDataComposite {
				private NavigableLinkedHashMap <String, ClipboardFormatSpecificDatum> i_formatNameToDatumMap = new NavigableLinkedHashMap <String, ClipboardFormatSpecificDatum> ();
				
				public ClipboardFormatSpecificDataComposite () {
				}
				
				~ClipboardFormatSpecificDataComposite () {
				}
				
				public Boolean addFormatSpecificDatum (ClipboardFormatSpecificDatum a_formatSpecificDatum) {
					try {
						i_formatNameToDatumMap [a_formatSpecificDatum.getFormatName ()] = a_formatSpecificDatum;
					}
					catch (KeyNotFoundException) {
						i_formatNameToDatumMap.Add (a_formatSpecificDatum.getFormatName (), a_formatSpecificDatum);
					}
					return true;
				}
				
				public List <String> getFormatNames () {
					List <String> l_formatNames = new List <String> ();
					
					foreach (KeyValuePair <String, ClipboardFormatSpecificDatum> l_formatNameToDatumMapEntry in i_formatNameToDatumMap) {
						l_formatNames.Add (l_formatNameToDatumMapEntry.Key);
					}
					return l_formatNames;
				}
				
				public ClipboardFormatSpecificDatum getFormatSpecificDatum (String a_formatName) {
					return i_formatNameToDatumMap [a_formatName];
				}
			}
		}
	}
}

