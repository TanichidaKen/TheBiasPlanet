namespace theBiasPlanet {
	namespace coreUtilities {
		namespace jsonDataHandling {
			using System;
			using theBiasPlanet.coreUtilities.messagingHandling;
			using theBiasPlanet.coreUtilities.pipes;
			
			public abstract class ExtendedJsonDatumParseEventsHandler {
				public abstract void initialize ();
				
				public virtual Boolean onNullFound () {
					return true;
				}
				
				public virtual Boolean onBooleanFound (Boolean a_value) {
					return true;
				}
				
				public virtual Boolean onIntegerFound (Int32 a_value) {
					return true;
				}
				
				public virtual Boolean onDoubleFound (Double a_value) {
					return true;
				}
				
				public virtual Boolean onLocalDateAndTimeFound (DateTime a_value) {
					return true;
				}
				
				public virtual Boolean onLocalDateFound (DateTime a_value) {
					return true;
				}
				
				public virtual Boolean onLocalTimeFound (DateTime a_value) {
					return true;
				}
				
				public virtual Boolean onBytesArrayFound (StringPipe a_reader) {
					return true;
				}
				
				public virtual Boolean onStringFound (StringPipe a_reader) {
					return true;
				}
				
				public virtual Boolean onArrayStarted () {
					return true;
				}
				
				public virtual Boolean onArrayEnded () {
					return true;
				}
				
				public virtual Boolean onDictionaryStarted () {
					return true;
				}
				
				public virtual Boolean onDictionaryEnded () {
					return true;
				}
				
				public virtual void onException (Exception a_exception) {
					Publisher.logErrorInformation (a_exception);
				}
			}
		}
	}
}

