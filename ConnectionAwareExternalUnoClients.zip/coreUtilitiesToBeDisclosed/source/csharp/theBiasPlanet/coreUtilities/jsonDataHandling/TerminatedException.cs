namespace theBiasPlanet {
	namespace coreUtilities {
		namespace jsonDataHandling {
			using System;
			
			public class TerminatedException : Exception {
				public TerminatedException (String a_message) : base (a_message) {
				}
			}
		}
	}
}


