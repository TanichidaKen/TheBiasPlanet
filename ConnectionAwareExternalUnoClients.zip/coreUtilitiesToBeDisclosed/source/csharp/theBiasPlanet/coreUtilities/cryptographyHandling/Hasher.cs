namespace theBiasPlanet {
	namespace coreUtilities {
		namespace cryptographyHandling {
			using System;
			using System.Security.Cryptography;
			
			public sealed class Hasher {
				private static RNGCryptoServiceProvider s_randomNumberGenerator = new RNGCryptoServiceProvider ();
				
				public static Byte [] createSalt (Int32 a_numberOfBytes) {
					Byte [] l_saltArray = new Byte [a_numberOfBytes];
					s_randomNumberGenerator.GetBytes (l_saltArray);
					return l_saltArray;
				}
				
				public static Byte [] hashInPbkdf2 (String a_originalDatum, Byte [] a_saltArray, Int32 a_numberOfIteration, Int32 a_keyLength) {
					Rfc2898DeriveBytes l_pbkdf2SecretKeyGenerator = new Rfc2898DeriveBytes (a_originalDatum, a_saltArray, a_numberOfIteration);
					return l_pbkdf2SecretKeyGenerator.GetBytes (a_keyLength);
				}
			}
		}
	}
}

