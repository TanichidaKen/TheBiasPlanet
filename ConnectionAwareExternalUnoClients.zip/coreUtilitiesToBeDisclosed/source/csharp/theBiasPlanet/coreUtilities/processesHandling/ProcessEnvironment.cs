namespace theBiasPlanet {
	namespace coreUtilities {
		namespace processesHandling {
			using System;
			using System.Configuration;
			using System.Collections.Generic;
			using System.IO;
			using System.Runtime.InteropServices;
			using theBiasPlanet.coreUtilities.constantsGroups;
			
			public class ProcessEnvironment {
				public static ProcessEnvironment s_currentEnvironment;
				protected String i_identification = null;
				protected KeyValueConfigurationCollection i_properties = null;
				protected String i_operatingSystemName = null; // 'Linux' or 'Windows'
				protected List <String> i_operatingSystemCommandsPaths = null; // Doesn't suppose that 'PATH' has ';' as any part of any path.
				protected Char i_operatingSystemDirectoriesDelimiter = GeneralConstantsConstantsGroup.c_unspecifiedCharacter;
				protected String i_operatingSystemFilePathFormat = null;
				[StructLayout (LayoutKind.Sequential)]
				internal struct WSAData {
					public Int16 wVersion;
					public Int16 wHighVersion;
					[MarshalAs (UnmanagedType.ByValTStr, SizeConst=257)]
					public String szDescription;
					[MarshalAs (UnmanagedType.ByValTStr, SizeConst=129)]
					public String szSystemStatus;
					public Int16 iMaxSockets;
					public Int16 iMaxUdpDg;
					public Int32 lpVendorInfo;
				}
				[DllImport ("ws2_32.dll", CharSet=CharSet.Ansi, SetLastError=true)]
				internal static extern Int32 WSAStartup (
					[In] Int16 wVersionRequested,
					[Out] out WSAData lpWSAData
				);
				[DllImport ("ws2_32.dll", CharSet=CharSet.Ansi, SetLastError=true)]
				internal static extern Int32 WSACleanup ();
				private const Int32 c_windowsSocketStartupSuccessStatus = 0;
				private const Int16 c_windowsSocketVersion = 0x0202;
				
				public ProcessEnvironment (String a_identification, String a_propertiesFileUrl) {
					i_identification = a_identification;
					ExeConfigurationFileMap l_propertiesFileMap = new ExeConfigurationFileMap ();
					if (a_propertiesFileUrl != null) {
						l_propertiesFileMap.ExeConfigFilename = a_propertiesFileUrl;
						i_properties = ConfigurationManager.OpenMappedExeConfiguration (l_propertiesFileMap, ConfigurationUserLevel.None).AppSettings.Settings;
					}
					else {
						i_properties = new KeyValueConfigurationCollection ();
					}
					Char l_operatingSystemPathsDelimiter = GeneralConstantsConstantsGroup.c_unspecifiedCharacter;
					i_operatingSystemName = Environment.OSVersion.ToString ();
					if (i_operatingSystemName.StartsWith (OperatingSystemNamesConstantsGroup.c_linux)) {
						i_operatingSystemName = OperatingSystemNamesConstantsGroup.c_linux;
						l_operatingSystemPathsDelimiter = GeneralConstantsConstantsGroup.c_linuxPathsDelimiter;
						i_operatingSystemDirectoriesDelimiter = GeneralConstantsConstantsGroup.c_linuxDirectoriesDelimiter;
						i_operatingSystemFilePathFormat = GeneralConstantsConstantsGroup.c_linuxFilePathFormat;
					}
					else if (i_operatingSystemName .StartsWith (OperatingSystemNamesConstantsGroup.c_windows)) {
						i_operatingSystemName = OperatingSystemNamesConstantsGroup.c_windows;
						l_operatingSystemPathsDelimiter = GeneralConstantsConstantsGroup.c_windowsPathsDelimiter;
						i_operatingSystemDirectoriesDelimiter = GeneralConstantsConstantsGroup.c_windowsDirectoriesDelimiter;
						i_operatingSystemFilePathFormat = GeneralConstantsConstantsGroup.c_windowsFilePathFormat;
					}
					else {
					}
					String l_operatingSystemCommandsPathsExpression = Environment.GetEnvironmentVariable (OperatingSystemEnvironmentVariableNamesConstantsGroup.c_path);
					String [] l_operatingSystemCommandsPathsArray = l_operatingSystemCommandsPathsExpression.Split (l_operatingSystemPathsDelimiter);
					i_operatingSystemCommandsPaths = new List <String> ();
					foreach (String l_operatingSystemCommandsPath in l_operatingSystemCommandsPathsArray) {
						i_operatingSystemCommandsPaths.Add (l_operatingSystemCommandsPath);
					}
					s_currentEnvironment = this;
				}
				
				public String getIdentification () {
					return i_identification;
				}
				
				public KeyValueConfigurationCollection getProperties () {
					return i_properties;
				}
				
				public String getOperatingSystemName () {
					return i_operatingSystemName;
				}
				
				public Char getOperatingSystemDirectoriesDelimiter () {
					return i_operatingSystemDirectoriesDelimiter;
				}
	
				public String getOperatingSystemFilePathFormat () {
					return i_operatingSystemFilePathFormat;
				}
				
				// 'a_commandName' has to include the file extension, for example 'exe'.
				public String getCommandAbsolutePath (String a_commandName) {
					String l_commandAbsolutePathCandidate = null;
					foreach (String l_operatingSystemCommandsPath in i_operatingSystemCommandsPaths) {
						l_commandAbsolutePathCandidate = String.Format (i_operatingSystemFilePathFormat , l_operatingSystemCommandsPath, a_commandName);
						if (File.Exists (l_commandAbsolutePathCandidate)) {
							return l_commandAbsolutePathCandidate;
						}
					}
					return null;
				}
				
				public static void windowsSocketStartup () {
					WSAData l_windowsSocketData;
					Int32 l_windowsSocketStartupStatus = WSAStartup (c_windowsSocketVersion, out l_windowsSocketData);
					if (l_windowsSocketStartupStatus != c_windowsSocketStartupSuccessStatus) {
						throw new System.Exception (String.Format ("WSAStartup failed: return code = {0:D}", l_windowsSocketStartupStatus));
					}
				}
				
				public static void windowsSocketCleanup () {
					WSACleanup ();
				}
			}
		}
	}
}

