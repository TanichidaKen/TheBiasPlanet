namespace theBiasPlanet {
	namespace coreUtilities {
		namespace stringsHandling {
			using System;
			using System.Collections;
			using System.Collections.Generic;
			using System.Globalization;
			using System.Text;
			using System.Text.RegularExpressions;
			using theBiasPlanet.coreUtilities.collections;
			using theBiasPlanet.coreUtilities.constantsGroups;
			using theBiasPlanet.coreUtilities.reflectionHandling;
			
			public class StringHandler {
				private static readonly Regex c_environmentVariableRegularExpression = new Regex ("\\$\\{(.*?)\\}");
				public static String getEscapedArgument (String a_argument) {
					StringBuilder l_escapedArgumentStringBuilder = new StringBuilder ();
					l_escapedArgumentStringBuilder.Append ("\"");
					l_escapedArgumentStringBuilder.Append (a_argument.Replace ("\\", "\\\\").Replace("\"", "\\\""));
					l_escapedArgumentStringBuilder.Append ("\"");
					return l_escapedArgumentStringBuilder.ToString ();
					
				}
				
				public static String getString (Object a_object) {
					if (a_object == null) {
						return "null";
					}
					else {
						Type l_class = a_object.GetType ();
						StringBuilder l_stringBuilder = new StringBuilder ();
						l_stringBuilder.Append (l_class.ToString ());
						l_stringBuilder.Append (": ");
						if (l_class.IsArray) {
							Int32 l_numberOfElements = ((Array) a_object).GetLength (GeneralConstantsConstantsGroup.c_iterationStartNumber);
							for (Int32 l_elementIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber; l_elementIndex < l_numberOfElements; l_elementIndex ++) {
								if (l_elementIndex != GeneralConstantsConstantsGroup.c_iterationStartNumber) {
									l_stringBuilder.Append (", ");
								}
								l_stringBuilder.Append (String.Format ("{0:d}-", l_elementIndex));
								l_stringBuilder.Append (getString (((Array) a_object).GetValue (l_elementIndex)));
							}
						}
						else if (a_object is IDictionary) {
							Int32 l_elementIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
							foreach (DictionaryEntry l_mapEntry in (IDictionary) a_object) {
								if (l_elementIndex != GeneralConstantsConstantsGroup.c_iterationStartNumber) {
									l_stringBuilder.Append (", ");
								}
								l_stringBuilder.Append (getString (l_mapEntry.Key));
								l_stringBuilder.Append ("-> ");
								l_stringBuilder.Append (getString (l_mapEntry.Value));
								l_elementIndex ++;
							}
						}
						else if (a_object is IList) {
							Int32 l_elementIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
							foreach (Object l_element in (IList) a_object) {
								
								if (l_elementIndex != GeneralConstantsConstantsGroup.c_iterationStartNumber) {
									l_stringBuilder.Append (", ");
								}
								l_stringBuilder.Append (getString (l_element));
								l_elementIndex ++;
							}
						}
						else {
							if (a_object is String) {
								l_stringBuilder.Append ((String) a_object);
							}
							else if (a_object is Int32) {
								l_stringBuilder.Append (String.Format (String.Format ("{0:s}", GeneralConstantsConstantsGroup.c_integerDefaultFormat), a_object));
							}
							else if (a_object is Int16) {
								l_stringBuilder.Append (String.Format (String.Format ("{0:s}", GeneralConstantsConstantsGroup.c_integerDefaultFormat), a_object));
							}
							else if (a_object is Decimal) {
								l_stringBuilder.Append (((Decimal) a_object).ToString (CultureInfo.InvariantCulture));
							}
							else if (a_object is Double) {
								l_stringBuilder.Append (String.Format (String.Format ("{0:s}", GeneralConstantsConstantsGroup.c_doubleDefaultFormat), a_object));
							}
							else if (a_object is Single) {
								l_stringBuilder.Append (String.Format (String.Format ("{0:s}", GeneralConstantsConstantsGroup.c_doubleDefaultFormat), a_object));
							}
							else if (a_object is Boolean) {
								l_stringBuilder.Append (String.Format (String.Format ("{0:s}", GeneralConstantsConstantsGroup.c_booleanDefaultFormat), a_object));
							}
							/*
							else if (a_object is Date) {
								Date l_date = (Date) a_object;
								l_stringBuilder.Append (l_date.ToString ("s", System.Globalization.CultureInfo.InvariantCulture));
							}
							else if (a_object is LocalTime) {
								LocalTime l_time = (LocalTime) a_object;
								l_stringBuilder.Append (l_time.Format (DateTimeFormatter.ISO_LOCAL_TIME));
							}
							*/
							else if (a_object is DateTime) {
								DateTime l_dateAndTime = (DateTime) a_object;
								l_stringBuilder.Append (l_dateAndTime.ToString ("s", System.Globalization.CultureInfo.InvariantCulture));
							}
							else if (a_object is Byte) {
								// showing the unsigned value
								//Int32 l_byteValue = ((Byte) a_object).byteValue ();
								Int32 l_byteValue = (Byte) a_object;
								l_stringBuilder.Append (String.Format ("{0:X2}", l_byteValue));
							}
							else if (a_object is Type) {
								l_stringBuilder.Append (a_object.ToString ());
							}
							else if (l_class.ToString ().StartsWith ("System") || l_class.ToString ().StartsWith ("unoidl.com.sun.star.lib") || l_class.ToString ().StartsWith ("unoidl.com.sun.star.comp")) {
								l_stringBuilder.Append (a_object.ToString ());
							}
							else {
								NavigableLinkedHashMap <String, Object> l_fieldNamesAndValuesMap = null;
								try {
									l_fieldNamesAndValuesMap = ReflectionHandler.getFieldNameToValueMap (l_class, a_object, false, true, null, null, true);
								}
								catch (Exception) {
								}
								if (l_fieldNamesAndValuesMap != null) {
									Int32 l_elementIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
									foreach (KeyValuePair <String, Object> l_fieldNamesAndValuesMapEntry in l_fieldNamesAndValuesMap) {
										if (l_elementIndex != GeneralConstantsConstantsGroup.c_iterationStartNumber) {
											l_stringBuilder.Append (", ");
										}
										l_stringBuilder.Append (String.Format ("{0:s}-> {1:s}", l_fieldNamesAndValuesMapEntry.Key, StringHandler.getString (l_fieldNamesAndValuesMapEntry.Value)));
										l_elementIndex ++;
									}
								}
								else {
									l_stringBuilder.Append (a_object.ToString ());
								}
							}
						}
		 				return l_stringBuilder.ToString ();
					}
				}
				
				public static String unNullify (String a_originalString) {
					if (a_originalString != null) {
						return a_originalString;
					}
					else {
						return "";
					}
				}
				
				public static String effectuateEnvironmentVariables (String a_originalString) {
					StringBuilder l_targetStringBuilder = new StringBuilder ();
					MatchCollection l_environmentVariableMatchers = c_environmentVariableRegularExpression.Matches (a_originalString);
					Int32 l_currentCharacterIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
					Group l_environmentVariableMatcherGroup0 = null; 
					foreach (Match l_environmentVariableMatcher in l_environmentVariableMatchers) {
						l_environmentVariableMatcherGroup0 = l_environmentVariableMatcher.Groups [GeneralConstantsConstantsGroup.c_iterationStartNumber];
						l_targetStringBuilder.Append (a_originalString.Substring (l_currentCharacterIndex, l_environmentVariableMatcherGroup0.Index));
					   	l_targetStringBuilder.Append (StringHandler.unNullify (Environment.GetEnvironmentVariable (l_environmentVariableMatcher.Groups [GeneralConstantsConstantsGroup.c_iterationStartNumber + 1].Value)));
						l_currentCharacterIndex = l_environmentVariableMatcherGroup0.Index + l_environmentVariableMatcherGroup0.Length;
					}
					l_targetStringBuilder.Append (a_originalString.Substring (l_currentCharacterIndex));
					return l_targetStringBuilder.ToString ();
				}
				
				public static bool validateAsUrl (String a_string) {
					MatchCollection l_matchers = RegularExpressionsConstantsGroup.c_urlRegularExpression.Matches (a_string);
					foreach (Match l_matcher in l_matchers) {
						return true;
					}
					return false;
				}
			}
		}
	}
}

