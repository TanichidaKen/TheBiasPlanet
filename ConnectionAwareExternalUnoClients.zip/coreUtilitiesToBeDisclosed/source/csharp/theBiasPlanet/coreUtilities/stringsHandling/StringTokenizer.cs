namespace theBiasPlanet {
	namespace coreUtilities {
		namespace stringsHandling {
			using System;
			using theBiasPlanet.coreUtilities.constantsGroups;
			
			public class StringTokenizer {
				private String [] i_tokensArray = null;
				private int i_numberOfTokens = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
				private int i_currentIndex = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
				
				public StringTokenizer (String a_targetString, String a_delimiters) {
					if (a_targetString != null) {
						i_tokensArray = a_targetString.Split (a_delimiters.ToCharArray ());
						i_numberOfTokens = i_tokensArray.Length;
						i_currentIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
					}
				}
				
				public int countTokens () {
					return i_numberOfTokens - i_currentIndex;
				}
				
				public bool hasMoreTokens () {
					return i_currentIndex < i_numberOfTokens;
				}
				
				public String nextToken () {
					i_currentIndex ++;
					return i_tokensArray [i_currentIndex - 1];
				}
			}
		}
	}
}

