namespace theBiasPlanet {
	namespace coreUtilities {
		namespace inputsHandling {
			using System;
			
			public class BufferOverflowedException : Exception {
				public BufferOverflowedException (String a_message) : base (a_message) {
				}
			}
		}
	}
}

