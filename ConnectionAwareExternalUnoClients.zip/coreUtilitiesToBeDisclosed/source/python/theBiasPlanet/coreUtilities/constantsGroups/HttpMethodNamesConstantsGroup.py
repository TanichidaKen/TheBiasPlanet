
class HttpMethodNamesConstantsGroup:
	c_get: str = "GET"
	c_post: str = "POST"
	c_put: str = "PUT"

