
class HttpStatusCodesConstantsGroup:
	c_success: int = 200
	c_notFound: int = 404
