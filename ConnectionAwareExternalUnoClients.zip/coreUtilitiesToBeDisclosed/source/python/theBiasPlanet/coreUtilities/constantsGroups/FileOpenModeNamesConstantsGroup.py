
class FileOpenModeNamesConstantsGroup:
	c_readModeName: str = "r"
	c_eraseAndWriteModeName: str = "w"
	c_addModeName: str = "a"

