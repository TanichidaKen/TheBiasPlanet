
class FileNameSuffixesConstantsGroup:
	c_xmlFileNameSuffix: str = "xml"
	c_styleSheetFileNameSuffix: str = "xslt"
	c_jarFileNameSuffix: str = "jar"
	c_javaFileNameSuffix: str = "java"
	c_pythonModuleFileNameSuffix: str = "py"
	c_saveFileNameSuffix: str = "save"
	c_modifiedFileNameSuffix: str = "modified"

