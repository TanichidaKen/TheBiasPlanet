from typing import cast
from typing import List
from typing import Type
from typing import TypeVar
from typing import Union
from collections import Sequence
from theBiasPlanet.coreUtilities.datumConversionsHandling.DatumConverter import DatumConverter

T = TypeVar ("T")

class ListsFactory:
	@staticmethod
	def createList (a_type0: Type [T], *a_items: T) -> List [T]:
		l_list: List [T] = []
		if not (a_items is None):
			l_item: object
			for l_item in a_items:
				l_list.append (cast (T, l_item))
		return l_list;
	
	@staticmethod
	def createListExpandingItems (a_type0: Type [T], *a_items: Union [T, "Sequence [T]"]) -> List [T]:
		l_list:List [T] = []
		if not (a_items is None):
			l_item: Union [T, "Sequence [T]"]
			for l_item in a_items:
				if isinstance (l_item, Sequence):
					l_element: T
					for l_element in l_item:
						l_list.append (cast (T, l_element))
				else:
					l_list.append (cast (T, l_item))
		return l_list;
	
	@staticmethod
	def createSignedBytesList (a_bytes: bytes) -> List [int]:
		l_list: List [int] = []
		l_item: int
		for l_item in a_bytes:
			l_list.append (DatumConverter.getSignedByte (l_item))
		return l_list

