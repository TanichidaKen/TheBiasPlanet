from typing import Iterator
from typing import List
from typing import Match
from typing import Optional
from typing import Pattern
from typing import Type
from typing import TypeVar
import os
import re
from theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup import GeneralConstantsConstantsGroup
from theBiasPlanet.coreUtilities.constantsGroups.RegularExpressionsConstantsGroup import RegularExpressionsConstantsGroup

T = TypeVar ("T")

class StringHandler:
	c_environmentVariableRegularExpression: Pattern = re.compile ("\\$\\{(.*?)\\}")
	
	@staticmethod
	def getString (a_object: object) -> str:
		# TODO
		return str (a_object)
	
	@staticmethod
	def getFilePath (a_url: str) -> str:
		return os.path.basename (a_url)
	
	@staticmethod
	def unNullify (a_originalString: Optional [str]) -> str:
		if a_originalString is not None:
			return a_originalString
		else:
			return ""
	
	@staticmethod
	def effectuateEnvironmentVariables (a_originalString: str) -> str:
		l_targetStringBuilder: List [str] = []
		l_environmentVariableMatchersIterator: Iterator = StringHandler.c_environmentVariableRegularExpression.finditer (a_originalString)
		l_environmentVariableMatcher: Match [str]
		l_currentCharacterIndex: int = GeneralConstantsConstantsGroup.c_iterationStartNumber
		for l_environmentVariableMatcher in l_environmentVariableMatchersIterator:
			l_targetStringBuilder.append (a_originalString [l_currentCharacterIndex: l_environmentVariableMatcher.start (GeneralConstantsConstantsGroup.c_iterationStartNumber)])
			l_targetStringBuilder.append (StringHandler.unNullify (os.getenv (l_environmentVariableMatcher.group (GeneralConstantsConstantsGroup.c_iterationStartNumber + 1))))
			l_currentCharacterIndex = l_environmentVariableMatcher.end (GeneralConstantsConstantsGroup.c_iterationStartNumber)
		l_targetStringBuilder.append (a_originalString [l_currentCharacterIndex:])
		return "".join (l_targetStringBuilder)
	
	@staticmethod
	def validateAsUrl (a_string: str) -> bool:
		l_matchersIterator: Iterator = RegularExpressionsConstantsGroup.c_urlRegularExpression.finditer (a_string)
		l_matcher: Match [str]
		for l_matcher in l_matchersIterator:
			return True
		return False
	
	@staticmethod
	def joinListElements (a_type0: Type [T], a_list: List [Optional [T]], a_offset: int, a_stopper: int) -> str:
		l_string: str = ""
		l_elementIndex: int = GeneralConstantsConstantsGroup.c_iterationStartNumber
		for l_elementIndex in range (a_offset, a_stopper, 1):
			l_string = l_string + str (a_list [l_elementIndex])
		return l_string

