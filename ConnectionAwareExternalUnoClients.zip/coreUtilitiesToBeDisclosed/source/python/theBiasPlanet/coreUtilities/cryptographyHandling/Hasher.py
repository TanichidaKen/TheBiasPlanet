import hashlib
import os
from theBiasPlanet.coreUtilities.constantsGroups.CharactersSetNamesConstantsGroup import CharactersSetNamesConstantsGroup

class Hasher:
	c_sha1HashingAlgorismName: str = "sha1"
	c_sha256HashingAlgorismName: str = "sha256"
	
	@staticmethod
	def createSalt (a_numberOfBytes: int) -> bytes:
		return os.urandom (a_numberOfBytes)
	
	@staticmethod
	def hashInPbkdf2 (a_originalDatum: str, a_saltArray: bytes, a_numberOfIteration: int, a_keyLength: int) -> bytes:
		return hashlib.pbkdf2_hmac (Hasher.c_sha1HashingAlgorismName, a_originalDatum.encode (CharactersSetNamesConstantsGroup.c_utf8CharactersSetName), a_saltArray, a_numberOfIteration, a_keyLength)

