from typing import Generic
from typing import List
from typing import Optional
from typing import Type
from typing import TypeVar
from typing import cast
import sys
from threading import Condition
from theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup import GeneralConstantsConstantsGroup
from theBiasPlanet.coreUtilities.inputsHandling.NoMoreDataException import NoMoreDataException
from theBiasPlanet.coreUtilities.inputsHandling.NoMoreNeedsException import NoMoreNeedsException
from theBiasPlanet.coreUtilities.messagingHandling.Publisher import Publisher
from theBiasPlanet.coreUtilities.timersHandling.TimeOutException import TimeOutException

T = TypeVar ("T")

class ObjectsPipe (Generic [T]):
	def __init__ (a_this: "ObjectsPipe", a_bufferSize: int, a_notificationIsDelayed: bool) -> None:
		a_this.i_threadCondition: Condition
		a_this.i_objects: List [object]
		a_this.i_bufferSize: int = 0
		# No data: i_dataStartIndex == GeneralConstantsConstantsGroup.c_iterationStartNumber && i_dataUntilIndex == GeneralConstantsConstantsGroup.c_iterationStartNumber
		a_this.i_dataStartIndex: int = GeneralConstantsConstantsGroup.c_iterationStartNumber
		a_this.i_dataUntilIndex: int = GeneralConstantsConstantsGroup.c_iterationStartNumber
		a_this.i_isFinishedWriting: bool = False
		a_this.i_isFinishedReading: bool = False
		a_this.i_notificationIsDelayed: bool = False
		
		a_this.i_threadCondition = Condition ()
		a_this.i_bufferSize = a_bufferSize
		a_this.i_objects = [None] * a_this.i_bufferSize
		a_this.i_notificationIsDelayed = a_notificationIsDelayed
	
	def __del__ (a_this: "ObjectsPipe") -> None:
		None
	
	def isEmptyWithoutLocking (a_this: "ObjectsPipe") -> bool:
		return a_this.i_dataStartIndex == GeneralConstantsConstantsGroup.c_iterationStartNumber and a_this.i_dataUntilIndex == GeneralConstantsConstantsGroup.c_iterationStartNumber
	
	def isFullWithoutLocking (a_this: "ObjectsPipe") -> bool:
		return (a_this.i_dataStartIndex == GeneralConstantsConstantsGroup.c_iterationStartNumber and a_this.i_dataUntilIndex == a_this.i_bufferSize) or (a_this.i_dataStartIndex != GeneralConstantsConstantsGroup.c_iterationStartNumber and a_this.i_dataStartIndex == a_this.i_dataUntilIndex)
	
	# a_timeOutPeriodInMilliseconds: -1 -> waits indefinitely, 0 -> not wait
	def writeWithoutLocking (a_this: "ObjectsPipe", a_object: Optional [T], a_timeOutPeriodInMilliseconds: int = -1) -> None:
		if a_this.i_isFinishedReading:
			raise NoMoreNeedsException ("")
		if a_this.i_isFinishedWriting:
			a_this.i_isFinishedWriting = False
		while (True):
			if a_this.isFullWithoutLocking ():
				try:
					if a_timeOutPeriodInMilliseconds == -1:
						a_this.i_threadCondition.wait ()
					elif a_timeOutPeriodInMilliseconds == 0:
						None
					else:
						a_this.i_threadCondition.wait (a_timeOutPeriodInMilliseconds / 1000)
				except (Exception) as l_exception:
					Publisher.logErrorInformation (l_exception)
			# Checked again because the status may have changed while this thread was waiting.
			if a_this.i_isFinishedReading:
				raise NoMoreNeedsException ("")
			if not a_this.isFullWithoutLocking ():
				l_wasEmpty: bool = a_this.isEmptyWithoutLocking ()
				if a_this.i_dataUntilIndex == a_this.i_bufferSize:
					a_this.i_objects [GeneralConstantsConstantsGroup.c_iterationStartNumber] = a_object
					a_this.i_dataUntilIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber + 1
				else:
					a_this.i_objects [a_this.i_dataUntilIndex] = a_object
					a_this.i_dataUntilIndex = a_this.i_dataUntilIndex + 1
				if ((not a_this.i_notificationIsDelayed) and l_wasEmpty) or (a_this.i_notificationIsDelayed and a_this.isFullWithoutLocking ()):
					a_this.i_threadCondition.notifyAll ()
				return
			else:
				if a_timeOutPeriodInMilliseconds != -1:
					raise TimeOutException ("")
	
	# a_timeOutPeriodInMilliseconds: -1 -> waits indefinitely, 0 -> not wait
	def readWithoutLocking (a_this: "ObjectsPipe", a_timeOutPeriodInMilliseconds: int = -1) -> Optional [T]:
		l_readObject: Optional [T] = None
		if a_this.i_isFinishedReading:
			a_this.i_isFinishedReading = False
		while True:
			if a_this.isEmptyWithoutLocking ():
				if not a_this.i_isFinishedWriting:
					try:
						if a_timeOutPeriodInMilliseconds == -1:
							a_this.i_threadCondition.wait ()
						elif a_timeOutPeriodInMilliseconds == 0:
							None
						else:
							a_this.i_threadCondition.wait (a_timeOutPeriodInMilliseconds / 1000)
					except (Exception) as l_exception:
						Publisher.logErrorInformation (l_exception)
				else:
					raise NoMoreDataException ("")
			# Checked again because the status may have changed while this thread was waiting.
			if not a_this.isEmptyWithoutLocking ():
				l_wasFull: bool = a_this.isFullWithoutLocking ()
				l_readObject = cast (T, a_this.i_objects [a_this.i_dataStartIndex])
				a_this.i_objects [a_this.i_dataStartIndex] = None
				a_this.i_dataStartIndex = a_this.i_dataStartIndex + 1
				if a_this.i_dataStartIndex == a_this.i_dataUntilIndex:
					a_this.i_dataStartIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber
					a_this.i_dataUntilIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber
				else:
					if a_this.i_dataStartIndex == a_this.i_bufferSize:
						a_this.i_dataStartIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber
				if ((not a_this.i_notificationIsDelayed) and l_wasFull) or (a_this.i_notificationIsDelayed and a_this.isEmptyWithoutLocking ()):
					a_this.i_threadCondition.notifyAll ()
				return l_readObject
			else:
				if a_this.i_isFinishedWriting:
					raise NoMoreDataException ("")
				if a_timeOutPeriodInMilliseconds != -1:
					raise TimeOutException ("")
	
	def isEmpty (a_this: "ObjectsPipe") -> bool:
		try:
			a_this.i_threadCondition.acquire ()
			return a_this.isEmptyWithoutLocking ()
		finally:
			a_this.i_threadCondition.release ()
	
	def isFull (a_this: "ObjectsPipe") -> bool:
		try:
			a_this.i_threadCondition.acquire ()
			return a_this.isFullWithoutLocking ()
		finally:
			a_this.i_threadCondition.release ()
	
	# a_timeOutPeriodInMilliseconds: -1 -> waits indefinitely, 0 -> not wait
	def write (a_this: "ObjectsPipe", a_object: Optional [T], a_timeOutPeriodInMilliseconds: int = -1) -> None:
		try:
			a_this.i_threadCondition.acquire ()
			a_this.writeWithoutLocking (a_object, a_timeOutPeriodInMilliseconds)
		finally:
			a_this.i_threadCondition.release ()
	
	# a_timeOutPeriodInMilliseconds: -1 -> waits indefinitely, 0 -> not wait
	def write_1 (a_this: "ObjectsPipe", a_objects: List [Optional [T]], a_offset: int, a_length: int, a_timeOutPeriodInMilliseconds: int = -1) -> int:
		try:
			a_this.i_threadCondition.acquire ()
			l_writtenLength: int = 0
			for l_writtenLength in range (0, a_length, 1):
				try:
					if (l_writtenLength == 0) or not a_this.isFullWithoutLocking ():
						a_this.writeWithoutLocking (a_objects [a_offset + l_writtenLength], a_timeOutPeriodInMilliseconds)
				except (NoMoreNeedsException) as l_exception:
					if l_writtenLength == 0:
						raise l_exception
					else:
						break
			return l_writtenLength
		finally:
			a_this.i_threadCondition.release ()
	
	# a_timeOutPeriodInMilliseconds: -1 -> waits indefinitely, 0 -> not wait
	def read (a_this: "ObjectsPipe", a_timeOutPeriodInMilliseconds: int = -1) -> Optional [T]:
		try:
			a_this.i_threadCondition.acquire ()
			return a_this.readWithoutLocking (a_timeOutPeriodInMilliseconds)
		finally:
			a_this.i_threadCondition.release ()
	
	# a_timeOutPeriodInMilliseconds: -1 -> waits indefinitely, 0 -> not wait
	def read_1 (a_this: "ObjectsPipe", a_objects: List [Optional [T]], a_offset: int, a_length: int, a_timeOutPeriodInMilliseconds: int = -1) -> int:
		try:
			a_this.i_threadCondition.acquire ()
			l_readLength: int = 0
			for l_readLength in range (0, a_length, 1):
				if (l_readLength == 0) or not a_this.isEmptyWithoutLocking ():
					a_objects [a_offset + l_readLength] = a_this.readWithoutLocking (a_timeOutPeriodInMilliseconds)
				else:
					break
			return l_readLength
		finally:
			a_this.i_threadCondition.release ()
	
	
	def readWholeData (a_this: "ObjectsPipe") -> List [Optional [T]]:
		try:
			a_this.i_threadCondition.acquire ()
			l_objectsList: List [Optional [T]] = []
			while True:
				try:
					l_objectsList.append (a_this.readWithoutLocking ())
				except (NoMoreDataException) as l_exception:
					break
			return l_objectsList
		finally:
			a_this.i_threadCondition.release ()
	
	def finishWriting (a_this: "ObjectsPipe") -> None:
		try:
			a_this.i_threadCondition.acquire ()
			a_this.i_isFinishedWriting = True
			a_this.i_threadCondition.notifyAll ()
		finally:
			a_this.i_threadCondition.release ()
	
	def finishReading (a_this: "ObjectsPipe") -> None:
		try:
			a_this.i_threadCondition.acquire ()
			a_this.i_isFinishedReading = True
			a_this.i_threadCondition.notifyAll ()
		finally:
			a_this.i_threadCondition.release ()
	
	def reset (a_this: "ObjectsPipe") -> None:
		try:
			a_this.i_threadCondition.acquire ()
			a_this.i_isFinishedWriting = False
			a_this.i_isFinishedReading = False
			a_this.i_dataStartIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber
			a_this.i_dataUntilIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber
		finally:
			a_this.i_threadCondition.release ()

