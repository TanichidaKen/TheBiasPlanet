from typing import List
from typing import Optional
from typing import TextIO
import sys
from theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup import GeneralConstantsConstantsGroup
from theBiasPlanet.coreUtilities.inputsHandling.NoMoreDataException import NoMoreDataException
from theBiasPlanet.coreUtilities.inputsHandling.NoMoreNeedsException import NoMoreNeedsException
from theBiasPlanet.coreUtilities.pipes.ObjectsPipe import ObjectsPipe
from theBiasPlanet.coreUtilities.timersHandling.TimeOutException import TimeOutException

class StringPipe (ObjectsPipe [str]):
	def __init__ (a_this: "StringPipe", a_bufferSize: int, a_notificationIsDelayed: bool) -> None:
		
		super ().__init__ (a_bufferSize, a_notificationIsDelayed)
	
	def __del__ (a_this: "StringPipe") -> None:
		None
	
	def writeWholeString (a_this: "StringPipe", a_reader: TextIO) -> None:
		l_writtenCharacter: Optional [str] = None
		while True:
			l_writtenCharacter = a_reader.read (1)
			if l_writtenCharacter == "":
				break
			try:
				a_this.write (l_writtenCharacter)
			except (NoMoreNeedsException) as l_exception:
				break
	
	def readString (a_this: "StringPipe", a_maximumLength: int, a_timeOutPeriodInMilliseconds: int = -1) -> str:
		l_readCharacter: Optional [str] = None
		l_readStringBuilder: List [str] = []
		l_readStringLength: int = 0
		while l_readStringLength < a_maximumLength:
			try:
				if l_readStringLength == 0:
					l_readCharacter = a_this.read (a_timeOutPeriodInMilliseconds)
				else:
					l_readCharacter = a_this.read ()
			except (NoMoreDataException, TimeOutException) as l_exception:
				if l_readStringLength == 0:
					raise l_exception
				break
			if l_readCharacter is not None:
				l_readStringBuilder.append (l_readCharacter)
				l_readStringLength = l_readStringLength + 1
		return "".join (l_readStringBuilder)
	
	def readStringLine (a_this: "StringPipe", a_maximumLength: int, a_timeOutPeriodInMilliseconds: int = -1) -> str:
		l_readStringBuilder: List [str] = []
		l_readStringLength: int = 0
		while True:
			try:
				l_readCharacter: str = a_this.read (a_timeOutPeriodInMilliseconds)
				if l_readCharacter is not None:
					l_readStringBuilder.append (l_readCharacter)
					l_readStringLength = l_readStringLength + 1
					if l_readCharacter == GeneralConstantsConstantsGroup.c_newLineCharacter or l_readStringLength >= a_maximumLength:
						break
			except (NoMoreDataException, TimeOutException) as l_exception:
				if l_readStringLength == 0:
					raise l_exception
				break
		return "".join (l_readStringBuilder)
	
	def readWholeString (a_this: "StringPipe") -> str:
		l_readCharacter: Optional [str] = None
		l_readStringBuilder: List [str] = []
		while True:
			try:
				l_readCharacter = a_this.read ()
			except (NoMoreDataException) as l_exception:
				break
			if l_readCharacter is not None:
				l_readStringBuilder.append (l_readCharacter)
		return "".join (l_readStringBuilder)

