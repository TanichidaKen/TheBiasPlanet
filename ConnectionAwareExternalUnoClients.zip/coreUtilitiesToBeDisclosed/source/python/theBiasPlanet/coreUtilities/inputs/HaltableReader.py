from typing import List
from typing import Optional
from typing import TextIO
from collections import OrderedDict
from io import StringIO
from threading import Thread
from theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup import GeneralConstantsConstantsGroup
from theBiasPlanet.coreUtilities.inputsHandling.NoMoreDataException import NoMoreDataException
from theBiasPlanet.coreUtilities.inputsHandling.NoMoreNeedsException import NoMoreNeedsException
from theBiasPlanet.coreUtilities.locks.SharableLock import SharableLock
from theBiasPlanet.coreUtilities.messagingHandling.Publisher import Publisher
from theBiasPlanet.coreUtilities.pipes.StringPipe import StringPipe
from theBiasPlanet.coreUtilities.timersHandling.TimeOutException import TimeOutException

class HaltableReader:
	def __init__ (a_this: "HaltableReader", a_underlyingStream: TextIO, a_bufferSize: int, a_quittingCharacter: str = None) -> None:
		a_this.i_underlyingStream: TextIO
		a_this.i_bufferSize: int
		a_this.i_dispatchDataThread: Optional [Thread] = None
		a_this.i_subscriberIdentificationToStringPipeMap: "OrderedDict [str, StringPipe]" = OrderedDict ()
		a_this.i_sharableLock: "SharableLock" = SharableLock ()
		a_this.i_quittingCharacter: str
		
		a_this.i_underlyingStream = a_underlyingStream
		a_this.i_bufferSize = a_bufferSize
		a_this.i_quittingCharacter = a_quittingCharacter
	
	# Any subscriber has to read consistently, or the other subscribers may be stuck because the dispatching thread will be stuck waiting to write to the string pipe for the neglecting subscriber.
	def addSubscriber (a_this: "HaltableReader", a_subscriberIdentification: str) -> None:
		try:
			a_this.i_sharableLock.lockExclusively ()
			a_this.i_subscriberIdentificationToStringPipeMap.update ({a_subscriberIdentification: StringPipe (a_this.i_bufferSize, False)})
		finally:
			a_this.i_sharableLock.unlockExclusively ()
	
	def removeSubscriber (a_this: "HaltableReader", a_subscriberIdentification: str) -> None:
		try:
			a_this.i_sharableLock.lockSharedly ()
			try:
				l_stringPipe: "StringPipe" = a_this.i_subscriberIdentificationToStringPipeMap [a_subscriberIdentification]
				l_stringPipe.finishWriting ()
			except (KeyError) as l_exception:
				None
		finally:
			a_this.i_sharableLock.unlockSharedly ()
		try:
			a_this.i_sharableLock.lockExclusively ()
			a_this.i_subscriberIdentificationToStringPipeMap.pop (a_subscriberIdentification)
		finally:
			a_this.i_sharableLock.unlockExclusively ()
	
	def startDispatchDataThread (a_this: "HaltableReader") -> None:
		if a_this.i_dispatchDataThread is None:
			def l_dispatchDataThreadFunction () -> None:
				try:
					l_data: str
					while True:
						l_data = a_this.i_underlyingStream.read (1)
						if l_data == GeneralConstantsConstantsGroup.c_emptyString:
							break
						if a_this.i_quittingCharacter is not None and l_data == a_this.i_quittingCharacter:
							break
						l_subscriberIdentification: str = None
						try:
							a_this.i_sharableLock.lockSharedly ()
							for l_subscriberIdentification in a_this.i_subscriberIdentificationToStringPipeMap:
								a_this.i_subscriberIdentificationToStringPipeMap [l_subscriberIdentification].writeWholeString (StringIO (l_data))
						finally:
							a_this.i_sharableLock.unlockSharedly ()
				except (EOFError) as l_exception:
					None
				except (Exception) as l_exception:
					Publisher.logErrorInformation (l_exception)
				finally:
					try:
						a_this.i_sharableLock.lockSharedly ()
						for l_subscriberIdentification in a_this.i_subscriberIdentificationToStringPipeMap:
							a_this.i_subscriberIdentificationToStringPipeMap [l_subscriberIdentification].finishWriting ()
					finally:
						a_this.i_sharableLock.unlockSharedly ()
			a_this.i_dispatchDataThread = Thread (target = l_dispatchDataThreadFunction)
			a_this.i_dispatchDataThread.setDaemon (True)
			a_this.i_dispatchDataThread.start ()
	
	def close (a_this: "HaltableReader") -> None:
		a_this.i_underlyingStream.close ()
	
	def read (a_this: "HaltableReader", a_subscriberIdentification: str, a_maximumLength: int, a_timeOutPeriodInMilliseconds: int = -1) -> str:
		l_stringPipe: "Optional [StringPipe]" = None
		try:
			a_this.i_sharableLock.lockSharedly ()
			try:
				l_stringPipe = a_this.i_subscriberIdentificationToStringPipeMap [a_subscriberIdentification]
			except (KeyError) as l_exception:
				None
		finally:
			a_this.i_sharableLock.unlockSharedly ()
		if l_stringPipe is not None:
			return l_stringPipe.readString (a_maximumLength, a_timeOutPeriodInMilliseconds)
		else:
			raise NoMoreNeedsException ("")
	
	def readLine (a_this: "HaltableReader", a_subscriberIdentification: str, a_maximumLength: int, a_timeOutPeriodInMilliseconds: int = -1) -> str:
		l_stringPipe: "Optional [StringPipe]" = None
		try:
			a_this.i_sharableLock.lockSharedly ()
			try:
				l_stringPipe = a_this.i_subscriberIdentificationToStringPipeMap.get (a_subscriberIdentification)
			except (KeyError) as l_exception:
				None
		finally:
			a_this.i_sharableLock.unlockSharedly ()
		if l_stringPipe is not None:
			return l_stringPipe.readStringLine (a_maximumLength, a_timeOutPeriodInMilliseconds)
		else:
			raise NoMoreNeedsException ("")
	
	def isReady (a_this: "HaltableReader", a_subscriberIdentification: str) -> bool:
		l_stringPipe: "Optional [StringPipe]" = None
		try:
			a_this.i_sharableLock.lockSharedly ()
			try:
				l_stringPipe = a_this.i_subscriberIdentificationToStringPipeMap [a_subscriberIdentification]
			except (KeyError) as l_exception:
				None
		finally:
			a_this.i_sharableLock.unlockSharedly ()
		if l_stringPipe is not None:
			return not (l_stringPipe.isEmpty ())
		else:
			return False

