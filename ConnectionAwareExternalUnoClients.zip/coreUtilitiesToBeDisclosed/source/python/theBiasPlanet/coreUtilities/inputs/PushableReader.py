from typing import List
from typing import Optional
from typing import TextIO
from theBiasPlanet.coreUtilities.collectionsHandling.ListHandler import ListHandler
from theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup import GeneralConstantsConstantsGroup
from theBiasPlanet.coreUtilities.inputsHandling.BufferOverflowedException import BufferOverflowedException
from theBiasPlanet.coreUtilities.stringsHandling.StringHandler import StringHandler

class PushableReader:
	def __init__ (a_this: "PushableReader", a_underlyingStream: TextIO, a_bufferSize: int) -> None:
		a_this.i_underlyingStream: TextIO
		a_this.i_bufferSize: int
		a_this.i_buffer: List [Optional [str]]
		a_this.i_characterStartIndex: int = GeneralConstantsConstantsGroup.c_iterationStartNumber
		a_this.i_characterUntilIndex: int = GeneralConstantsConstantsGroup.c_iterationStartNumber
		a_this.i_inMethodBuffer: List [Optional [str]] = [None]
		
		a_this.i_underlyingStream = a_underlyingStream
		a_this.i_bufferSize = a_bufferSize
		a_this.i_buffer = [None] * a_bufferSize
	
	def readFromBuffer (a_this: "PushableReader", a_characters: List [Optional [str]], a_offset: int, a_length: int) -> int:
		l_readLength: int = 0
		l_toReadLength: int = GeneralConstantsConstantsGroup.c_unspecifiedInteger
		if a_this.i_characterStartIndex == GeneralConstantsConstantsGroup.c_iterationStartNumber and a_this.i_characterUntilIndex == GeneralConstantsConstantsGroup.c_iterationStartNumber:
			None
		elif a_this.i_characterUntilIndex > a_this.i_characterStartIndex:
			l_toReadLength = min (a_length, a_this.i_characterUntilIndex - a_this.i_characterStartIndex)
			ListHandler.copyElements (str, a_this.i_buffer, a_this.i_characterStartIndex, a_characters, a_offset, l_toReadLength)
			l_readLength = l_readLength + l_toReadLength
			a_this.i_characterStartIndex = a_this.i_characterStartIndex + l_toReadLength
			if a_this.i_characterStartIndex == a_this.i_characterUntilIndex:
				a_this.i_characterStartIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber
				a_this.i_characterUntilIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber
		else:
			l_toReadLength = min (a_length, a_this.i_bufferSize - a_this.i_characterStartIndex)
			ListHandler.copyElements (str, a_this.i_buffer, a_this.i_characterStartIndex, a_characters, a_offset, l_toReadLength)
			l_readLength = l_readLength + l_toReadLength
			a_this.i_characterStartIndex = a_this.i_characterStartIndex + l_toReadLength
			if a_this.i_characterStartIndex == a_this.i_bufferSize:
				characterStartIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber
				if l_readLength < a_length:
					l_toReadLength = min (a_length - l_readLength, a_this.i_characterUntilIndex - a_this.i_characterStartIndex)
					ListHandler.copyElements (str, a_this.i_buffer, a_this.i_characterStartIndex, a_characters, a_offset + l_readLength, l_toReadLength)
					l_readLength = l_readLength + l_toReadLength
					a_this.i_characterStartIndex = a_this.i_characterStartIndex + l_toReadLength
					if a_this.i_characterStartIndex == a_this.i_characterUntilIndex:
						a_this.i_characterStartIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber
						a_this.i_characterUntilIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber
		return l_readLength
	
	def readDataFromUnerlyingStream (a_this: "PushableReader", a_characters: List [Optional [str]], a_offset: int, a_length: int) -> int:
		l_string: str = a_this.i_underlyingStream.read (a_length)
		l_readLength: int = len (l_string)
		for l_characterIndex in range(GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength, 1):
			a_characters [a_offset + l_characterIndex] = l_string [l_characterIndex]
		if l_readLength == 0 and a_length > 0:
			l_readLength = GeneralConstantsConstantsGroup.c_unspecifiedInteger
		return l_readLength
	
	def close (a_this: "PushableReader") -> None:
		a_this.i_underlyingStream.close ()
	
	def readFixedLengthData (a_this: "PushableReader", a_characters: List [Optional [str]], a_offset: int, a_length: int) -> int:
		l_readLength: int = 0
		l_readLength = a_this.readFromBuffer (a_characters, a_offset, a_length)
		if l_readLength < a_length:
			l_readFunctionReturn: int = GeneralConstantsConstantsGroup.c_unspecifiedInteger
			while True:
				l_readFunctionReturn = a_this.readDataFromUnerlyingStream (a_characters, a_offset + l_readLength, a_length - l_readLength)
				if l_readFunctionReturn == GeneralConstantsConstantsGroup.c_unspecifiedInteger:
					break
				l_readLength = l_readLength + l_readFunctionReturn
				if l_readLength == a_length:
					break
		if l_readLength == 0 and a_length > 0:
			l_readLength = -1;
		return l_readLength
	
	def readData (a_this: "PushableReader", a_characters: List [Optional [str]], a_offset: int, a_length: int) -> int:
		l_readLength: int = 0
		l_readLength = a_this.readFromBuffer (a_characters, a_offset, a_length)
		if l_readLength < a_length:
			l_readFunctionReturn: int = GeneralConstantsConstantsGroup.c_unspecifiedInteger
			l_readFunctionReturn = a_this.readDataFromUnerlyingStream (a_characters, a_offset + l_readLength, a_length - l_readLength)
			if l_readFunctionReturn != GeneralConstantsConstantsGroup.c_unspecifiedInteger:
				l_readLength = l_readLength + l_readFunctionReturn
			else:
				if l_readLength == 0:
					l_readLength = GeneralConstantsConstantsGroup.c_unspecifiedInteger
		return l_readLength
	
	def readSingleCharacter (a_this: "PushableReader") -> Optional [str]:
		l_readFunctionReturn: int = a_this.readData (a_this.i_inMethodBuffer, GeneralConstantsConstantsGroup.c_iterationStartNumber, 1)
		if l_readFunctionReturn == GeneralConstantsConstantsGroup.c_unspecifiedInteger:
			return None
		else:
			return a_this.i_inMethodBuffer [GeneralConstantsConstantsGroup.c_iterationStartNumber]
	
	def pushData (a_this: "PushableReader", a_characters: List [Optional [str]], a_offset: int, a_length: int) -> None:
		l_toPushLength: int = GeneralConstantsConstantsGroup.c_unspecifiedInteger
		l_pushedLength: int = 0
		if a_length <= 0:
			return
		if a_this.i_characterStartIndex == a_this.i_characterUntilIndex and a_this.i_characterStartIndex == GeneralConstantsConstantsGroup.c_iterationStartNumber:
			l_toPushLength = min (a_this.i_bufferSize, a_length)
			if l_toPushLength > 0:
				ListHandler.copyElements (str, a_characters, a_offset, a_this.i_buffer, a_this.i_characterStartIndex, l_toPushLength)
				l_pushedLength += l_toPushLength
				a_this.i_characterUntilIndex = a_this.i_characterUntilIndex + l_pushedLength
		elif a_this.i_characterUntilIndex > a_this.i_characterStartIndex:
			l_toPushLength = min (a_this.i_characterStartIndex, a_length)
			if l_toPushLength > 0:
				ListHandler.copyElements (str, a_characters, a_offset, a_this.i_buffer, a_this.i_characterStartIndex - l_toPushLength, l_toPushLength)
				l_pushedLength += l_toPushLength
				a_this.i_characterStartIndex = a_this.i_characterStartIndex - l_pushedLength
			if l_pushedLength < a_length:
				l_toPushLength = min (a_this.i_bufferSize - a_this.i_characterUntilIndex, a_length - l_pushedLength)
				if l_toPushLength > 0:
					ListHandler.copyElements (str, a_characters, a_offset + l_pushedLength, a_this.i_buffer, a_this.i_bufferSize - l_toPushLength, l_toPushLength)
					l_pushedLength += l_toPushLength
					a_this.i_characterStartIndex = a_this.i_bufferSize - l_pushedLength
		else:
			l_toPushLength = min (a_this.i_characterStartIndex - a_this.i_characterUntilIndex, a_length)
			if l_toPushLength > 0:
				ListHandler.copyElements (str, a_characters, a_offset, a_this.i_buffer, a_this.i_characterStartIndex - l_toPushLength, l_toPushLength)
				l_pushedLength += l_toPushLength
				a_this.i_characterStartIndex -= l_pushedLength
		if l_pushedLength < a_length:
			raise BufferOverflowedException (None)
	
	def pushSingleCharacter (a_this: "PushableReader", a_character: str) -> None:
		a_this.i_inMethodBuffer [0] = a_character
		a_this.pushData (a_this.i_inMethodBuffer, GeneralConstantsConstantsGroup.c_iterationStartNumber, 1)
	
	# return: the number of skipped white spaces
	def skipWhiteSpaces (a_this: "PushableReader") -> int:
		l_toReadLength: int = 1
		l_readLength: int = 0
		l_readFunctionReturn: int = GeneralConstantsConstantsGroup.c_unspecifiedInteger
		while True:
			l_readFunctionReturn = a_this.readFixedLengthData (a_this.i_inMethodBuffer, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_toReadLength)
			if l_readFunctionReturn == GeneralConstantsConstantsGroup.c_unspecifiedInteger:
				break
			if a_this.i_inMethodBuffer [GeneralConstantsConstantsGroup.c_iterationStartNumber] != GeneralConstantsConstantsGroup.c_spaceCharacter and a_this.i_inMethodBuffer [GeneralConstantsConstantsGroup.c_iterationStartNumber] != GeneralConstantsConstantsGroup.c_tabCharacter and a_this.i_inMethodBuffer [GeneralConstantsConstantsGroup.c_iterationStartNumber] != GeneralConstantsConstantsGroup.c_newLineCharacter and a_this.i_inMethodBuffer [GeneralConstantsConstantsGroup.c_iterationStartNumber] != GeneralConstantsConstantsGroup.c_carriageReturnCharacter:
				a_this.pushData (a_this.i_inMethodBuffer, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readFunctionReturn)
				break
			l_readLength = l_readLength + l_readFunctionReturn
		return l_readLength
	
	# return: the number of skipped characters
	def skipThrough (a_this: "PushableReader", a_throughString: str) -> int:
		l_toReadLength: int = 1
		l_readLength: int = 0
		l_readFunctionReturn: int = GeneralConstantsConstantsGroup.c_unspecifiedInteger
		l_throughStringLength: int = len (a_throughString)
		l_throughStringMatchedCharactersIndex: int = GeneralConstantsConstantsGroup.c_unspecifiedInteger
		while True:
			l_readFunctionReturn = a_this.readFixedLengthData (a_this.i_inMethodBuffer, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_toReadLength)
			if l_readFunctionReturn == GeneralConstantsConstantsGroup.c_unspecifiedInteger:
				break
			l_readLength = l_readLength + l_readFunctionReturn
			if l_readFunctionReturn < l_toReadLength:
				return l_readLength
			if a_this.i_inMethodBuffer [GeneralConstantsConstantsGroup.c_iterationStartNumber] == a_throughString [l_throughStringMatchedCharactersIndex + 1]:
				l_throughStringMatchedCharactersIndex = l_throughStringMatchedCharactersIndex + 1
			else:
				l_throughStringMatchedCharactersIndex = GeneralConstantsConstantsGroup.c_unspecifiedInteger
				if a_this.i_inMethodBuffer [GeneralConstantsConstantsGroup.c_iterationStartNumber] == a_throughString [l_throughStringMatchedCharactersIndex + 1]:
					l_throughStringMatchedCharactersIndex = l_throughStringMatchedCharactersIndex + 1
			if l_throughStringMatchedCharactersIndex == l_throughStringLength - 1:
				return l_readLength
		return l_readLength
	
	# return: the number of skipped characters
	def skipWhiteSpacesAndFromThroughAreas (a_this: "PushableReader", a_fromString: str, a_throughString: str) -> int:
		l_fromStringLength: int = len (a_fromString)
		l_toReadLength: int = l_fromStringLength
		l_readLength: int = 0
		l_readFunctionReturn: int = GeneralConstantsConstantsGroup.c_unspecifiedInteger
		l_readData: Optional [str] = None
		l_skipFinished: bool = False
		l_inMethodBuffer: List [Optional [str]] = [None] * l_fromStringLength
		while True:
			l_readLength = l_readLength + a_this.skipWhiteSpaces ()
			l_readFunctionReturn = a_this.readFixedLengthData (l_inMethodBuffer, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_toReadLength)
			if l_readFunctionReturn == GeneralConstantsConstantsGroup.c_unspecifiedInteger:
				l_skipFinished = True
			else:
				if l_readFunctionReturn == l_toReadLength:
					l_readData = StringHandler.joinListElements (str, l_inMethodBuffer, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readFunctionReturn)
					if a_fromString == l_readData:
						l_readLength = l_readLength + l_readFunctionReturn
						l_readLength = l_readLength + a_this.skipThrough (a_throughString)
					else:
						l_skipFinished = True
				else:
					l_skipFinished = True
			if l_skipFinished:
				if l_readFunctionReturn > 0:
					a_this.pushData (l_inMethodBuffer, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readFunctionReturn)
				return l_readLength
		return l_readLength

