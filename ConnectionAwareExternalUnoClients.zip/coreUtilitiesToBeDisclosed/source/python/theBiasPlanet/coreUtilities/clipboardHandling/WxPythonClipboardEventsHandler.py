from typing import List
from typing import cast
from collections import OrderedDict
import sys
from wx import DataFormat as wx_DataFormat
from wx import DataObject as wx_DataObject
import wx
from theBiasPlanet.coreUtilities.clipboardHandling.ClipboardFormatSpecificDataComposite import ClipboardFormatSpecificDataComposite
from theBiasPlanet.coreUtilities.clipboardHandling.ClipboardFormatSpecificDatum import ClipboardFormatSpecificDatum

class WxPythonClipboardEventsHandler (wx_DataObject):
	s_possibleDatumFormatNameToFormatMap: "OrderedDict [str, wx_DataFormat]" = None
	s_preferedDatumFormatName: str = None
	s_possibleDatumFormats: List [wx_DataFormat] = None
	
	@staticmethod
	def getDatumFormatName (a_datumFormat: wx_DataFormat) -> str:
		l_datumFormatNumber: int = a_datumFormat.GetType ()
		l_datumFormatName: str = None
		if l_datumFormatNumber == wx.DF_TEXT:
			l_datumFormatName = "Text"
		elif l_datumFormatNumber == wx.DF_BITMAP:
			l_datumFormatName = "Bitmap"
		elif l_datumFormatNumber == wx.DF_METAFILE:
			l_datumFormatName = "Metafile"
		elif l_datumFormatNumber == wx.DF_FILENAME:
			l_datumFormatName = "Filename"
		elif l_datumFormatNumber == wx.DF_HTML:
			l_datumFormatName = "HTML Format"
		else:
			l_datumFormatName = a_datumFormat.GetId ()
		return l_datumFormatName
	
	def __init__ (a_this: "WxPythonClipboardEventsHandler", a_formatSpecificDataComposite: "ClipboardFormatSpecificDataComposite") -> None:
		a_this.i_formatSpecificDataComposite: "ClipboardFormatSpecificDataComposite" = a_formatSpecificDataComposite
		a_this.i_supportedDatumFormats: List [wx_DataFormat] = None
		
		super ().__init__ ()
		l_availableDatumFormatNames: List [str] = a_this.i_formatSpecificDataComposite.getFormatNames ()
		if len (l_availableDatumFormatNames) > 0:
			a_this.i_supportedDatumFormats = []
			l_datumFormatName: str = None
			for l_datumFormatName in l_availableDatumFormatNames:
				a_this.i_supportedDatumFormats.append (WxPythonClipboardEventsHandler.s_possibleDatumFormatNameToFormatMap [l_datumFormatName])
		else:
			a_this.i_supportedDatumFormats = WxPythonClipboardEventsHandler.s_possibleDatumFormats
	
	def getFormatSpecificDataComposite (a_this: "WxPythonClipboardEventsHandler") -> "ClipboardFormatSpecificDataComposite":
		return a_this.i_formatSpecificDataComposite
	
	def GetFormatCount (a_this: "WxPythonClipboardEventsHandler", a_datumTransferDirection: wx_DataObject.Direction = wx_DataObject.Direction.Get) -> int:
		sys.stdout.write ("### GetFormatCount: {0:d}\n".format (len (a_this.i_supportedDatumFormats)))
		return len (a_this.i_supportedDatumFormats)
	
	def GetAllFormats (a_this: "WxPythonClipboardEventsHandler", a_datumTransferDirection: wx_DataObject.Direction = wx_DataObject.Direction.Get) -> List [wx_DataFormat]:
		sys.stdout.write ("### GetAllFormats:\n")
		return a_this.i_supportedDatumFormats
	
	# 'a_formatSpecificDatum' is not really 'bytearray', but 'memoryview', but the stub of 'memoryview' seems to be mistaken, which makes me use 'bytearray' instead.
	def GetDataHere (a_this: "WxPythonClipboardEventsHandler", a_datumFormat: wx_DataFormat, a_formatSpecificDatum: bytearray) -> bool:
		sys.stdout.write ("### GetDataHere: {0:s}\n".format (WxPythonClipboardEventsHandler.getDatumFormatName (a_datumFormat)))
		l_formatSpecificDatumIsFound: bool = False
		if a_formatSpecificDatum is not None:
			l_formatSpecificDatum: "ClipboardFormatSpecificDatum" = a_this.i_formatSpecificDataComposite.getFormatSpecificDatum (WxPythonClipboardEventsHandler.getDatumFormatName (a_datumFormat))
			if l_formatSpecificDatum is not None:
				l_copiedFormatSpecificDatum: bytearray = l_formatSpecificDatum.getDatum ()
				l_byteIndex: int = 0
				for l_byteIndex in range (0, len (a_formatSpecificDatum), 1):
					#a_formatSpecificDatum [l_byteIndex:l_byteIndex + 1] = cast (Sequence [bytes], bytes ([l_copiedFormatSpecificDatum [l_byteIndex]])) # This is if I rather use 'memoryview'.
					a_formatSpecificDatum [l_byteIndex] = l_copiedFormatSpecificDatum [l_byteIndex]
				l_formatSpecificDatumIsFound = True
		return l_formatSpecificDatumIsFound
	
	def GetDataSize (a_this: "WxPythonClipboardEventsHandler", a_datumFormat: wx_DataFormat) -> int:
		sys.stdout.write ("### GetDataSize:\n")
		l_size: int = 0
		l_formatSpecificDatum: "ClipboardFormatSpecificDatum" = a_this.i_formatSpecificDataComposite.getFormatSpecificDatum (WxPythonClipboardEventsHandler.getDatumFormatName (a_datumFormat))
		if l_formatSpecificDatum is not None:
			l_size = len (l_formatSpecificDatum.getDatum ())
		return l_size
	
	def GetPreferredFormat (a_this: "WxPythonClipboardEventsHandler", a_datumTransferDirection: wx_DataObject.Direction = wx_DataObject.Direction.Get) -> wx_DataFormat:
		sys.stdout.write ("### GetPreferredFormat:\n")
		return WxPythonClipboardEventsHandler.s_possibleDatumFormatNameToFormatMap [WxPythonClipboardEventsHandler.s_preferedDatumFormatName]
	
	def IsSupported (a_this: "WxPythonClipboardEventsHandler", a_datumFormat: wx_DataFormat, a_datumTransferDirection: wx_DataObject.Direction = wx_DataObject.Direction.Get) -> bool:
		sys.stdout.write ("### IsSupported:\n")
		try:
			WxPythonClipboardEventsHandler.s_possibleDatumFormatNameToFormatMap [WxPythonClipboardEventsHandler.getDatumFormatName (a_datumFormat)]
			return True
		except (KeyError) as l_exception:
			return False
	
	def SetData (a_this: "WxPythonClipboardEventsHandler", a_datumFormat: wx_DataFormat, a_formatSpecificDatum: memoryview) -> bool:
		sys.stdout.write ("### SetData: {0:s}\n".format (WxPythonClipboardEventsHandler.getDatumFormatName (a_datumFormat)))
		l_datumFormatName: str = WxPythonClipboardEventsHandler.getDatumFormatName (a_datumFormat)
		if a_formatSpecificDatum is not None:
			l_datumSize = len (a_formatSpecificDatum)
			l_copiedFormatSpecificDatum: bytearray = None
			if l_datumFormatName == "Text" or l_datumFormatName == "HTML Format":
				l_copiedFormatSpecificDatum = bytearray (l_datumSize + 1)
				l_copiedFormatSpecificDatum [l_datumSize] = 0
			else:
				l_copiedFormatSpecificDatum = bytearray (l_datumSize)
			l_byteIndex: int = 0
			for l_byteIndex in range (0, len (a_formatSpecificDatum), 1):
				l_copiedFormatSpecificDatum [l_byteIndex] = a_formatSpecificDatum [l_byteIndex]
			a_this.i_formatSpecificDataComposite.addFormatSpecificDatum (ClipboardFormatSpecificDatum (l_datumFormatName, a_datumFormat.GetType (), l_copiedFormatSpecificDatum))
		return False

