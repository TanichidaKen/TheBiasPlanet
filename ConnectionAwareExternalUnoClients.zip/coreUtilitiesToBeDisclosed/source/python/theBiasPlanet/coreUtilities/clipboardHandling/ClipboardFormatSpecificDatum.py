
class ClipboardFormatSpecificDatum:
	def __init__ (a_this: "ClipboardFormatSpecificDatum", a_formatName: str, a_formatNumber: int, a_datum: bytearray) -> None:
		a_this.i_formatName: str = a_formatName
		a_this.i_formatNumber: int = a_formatNumber
		a_this.i_datum: bytearray = a_datum
	
	def __del__ (a_this: "ClipboardFormatSpecificDatum") -> None:
		None
	
	def getFormatName (a_this: "ClipboardFormatSpecificDatum") -> str:
		return a_this.i_formatName
	
	def getFormatNumber (a_this: "ClipboardFormatSpecificDatum") -> int:
		return a_this.i_formatNumber
	
	def getDatumSize (a_this: "ClipboardFormatSpecificDatum") -> int:
		return len (a_this.i_datum)
	
	def getDatum (a_this: "ClipboardFormatSpecificDatum") -> bytearray:
		return a_this.i_datum

