from collections import OrderedDict
from theBiasPlanet.coreUtilities.clipboardHandling.ClipboardFormatSpecificDataComposite import ClipboardFormatSpecificDataComposite

class ClipboardFormatSpecificDataCompositesHistory:
	def __init__ (a_this: "ClipboardFormatSpecificDataCompositesHistory") -> None:
		a_this.i_dataCompositeKeyToDataCompositeMap: "OrderedDict [str, ClipboardFormatSpecificDataComposite]" = OrderedDict ()
	
	def __del__ (a_this: "ClipboardFormatSpecificDataCompositesHistory") -> None:
		None
	
	def addDataComposite (a_this: "ClipboardFormatSpecificDataCompositesHistory", a_dataCompositeKey: str, a_dataComposite: "ClipboardFormatSpecificDataComposite") -> bool:
		a_this.i_dataCompositeKeyToDataCompositeMap [a_dataCompositeKey] = a_dataComposite
		return True
	
	def removeDataComposite (a_this: "ClipboardFormatSpecificDataCompositesHistory", a_dataCompositeKey: str) -> bool:
		try:
			a_this.i_dataCompositeKeyToDataCompositeMap.pop (a_dataCompositeKey)
			return True
		except (KeyError) as l_exception:
			return False
	
	def getDataComposite (a_this: "ClipboardFormatSpecificDataCompositesHistory", a_dataCompositeKey: str) -> "ClipboardFormatSpecificDataComposite":
		l_dataComposite: "ClipboardFormatSpecificDataComposite" = None
		try:
			l_dataComposite = a_this.i_dataCompositeKeyToDataCompositeMap [a_dataCompositeKey]
		except (KeyError) as l_exception:
			None
		return l_dataComposite

