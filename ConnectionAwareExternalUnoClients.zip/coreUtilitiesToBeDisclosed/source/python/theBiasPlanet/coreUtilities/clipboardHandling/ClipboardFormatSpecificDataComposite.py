from typing import List
from collections import OrderedDict
from theBiasPlanet.coreUtilities.clipboardHandling.ClipboardFormatSpecificDatum import ClipboardFormatSpecificDatum

class ClipboardFormatSpecificDataComposite:
	def __init__ (a_this: "ClipboardFormatSpecificDataComposite") -> None:
		a_this.i_formatNameToDatumMap: "OrderedDict [str, ClipboardFormatSpecificDatum]" = OrderedDict ()
	
	def __del__ (a_this: "ClipboardFormatSpecificDataComposite") -> None:
		None
	
	def addFormatSpecificDatum (a_this: "ClipboardFormatSpecificDataComposite", a_formatSpecificDatum: "ClipboardFormatSpecificDatum") -> bool:
		a_this.i_formatNameToDatumMap [a_formatSpecificDatum.getFormatName ()] = a_formatSpecificDatum
		return True
	
	def getFormatNames (a_this: "ClipboardFormatSpecificDataComposite") -> List [str]:
		l_formatNames: List [str] = []
		l_formatName: str = None
		for l_formatName in a_this.i_formatNameToDatumMap:
			l_formatNames.append (l_formatName)
		return l_formatNames
	
	def getFormatSpecificDatum (a_this: "ClipboardFormatSpecificDataComposite", a_formatName: str) -> "ClipboardFormatSpecificDatum":
		l_formatSpecificDatum: "ClipboardFormatSpecificDatum" = None
		try:
			l_formatSpecificDatum = a_this.i_formatNameToDatumMap [a_formatName]
		except (KeyError) as l_exception:
			None
		return l_formatSpecificDatum

