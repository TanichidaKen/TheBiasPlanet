from abc import ABCMeta
from abc import abstractmethod
from datetime import date
from datetime import datetime
from datetime import time
from theBiasPlanet.coreUtilities.messagingHandling.Publisher import Publisher
from theBiasPlanet.coreUtilities.pipes.StringPipe import StringPipe

class ExtendedJsonDatumParseEventsHandler (metaclass=ABCMeta):
	@abstractmethod
	def initialize (a_this: "ExtendedJsonDatumParseEventsHandler") -> None:
		None
	
	def onNullFound (a_this: "ExtendedJsonDatumParseEventsHandler") -> bool:
		return True
	
	def onBooleanFound (a_this: "ExtendedJsonDatumParseEventsHandler", a_value: bool) -> bool:
		return True
	
	def onIntegerFound (a_this: "ExtendedJsonDatumParseEventsHandler", a_value: int) -> bool:
		return True
	
	def onDoubleFound (a_this: "ExtendedJsonDatumParseEventsHandler", a_value: float) -> bool:
		return True
	
	def onLocalDateAndTimeFound (a_this: "ExtendedJsonDatumParseEventsHandler", a_value: datetime) -> bool:
		return True
	
	def onLocalDateFound (a_this: "ExtendedJsonDatumParseEventsHandler", a_value: date) -> bool:
		return True
	
	def onLocalTimeFound (a_this: "ExtendedJsonDatumParseEventsHandler", a_value: time) -> bool:
		return True
	
	def onBytesArrayFound (a_this: "ExtendedJsonDatumParseEventsHandler", a_reader: StringPipe) -> bool:
		return True
	
	def onStringFound (a_this: "ExtendedJsonDatumParseEventsHandler", a_reader: StringPipe) -> bool:
		return True
	
	def onArrayStarted (a_this: "ExtendedJsonDatumParseEventsHandler") -> bool:
		return True
	
	def onArrayEnded (a_this: "ExtendedJsonDatumParseEventsHandler") -> bool:
		return True
	
	def onDictionaryStarted (a_this: "ExtendedJsonDatumParseEventsHandler") -> bool:
		return True
	
	def onDictionaryEnded (a_this: "ExtendedJsonDatumParseEventsHandler") -> bool:
		return True
	
	def onException (a_this: "ExtendedJsonDatumParseEventsHandler", a_exception: Exception) -> None:
		Publisher.logErrorInformation (a_exception)

