
class JsonDatumItemUnsupportedClassException  (Exception):
	def __init__ (a_this: "JsonDatumItemUnsupportedClassException ", a_message: str) -> None:
		
		super ().__init__ (a_message)

