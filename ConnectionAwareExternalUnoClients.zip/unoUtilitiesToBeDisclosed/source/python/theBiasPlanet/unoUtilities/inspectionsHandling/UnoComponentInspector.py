from typing import List
from typing import cast
from collections import OrderedDict
from com.sun.star.beans import XPropertySet
from com.sun.star.beans import XPropertySetInfo
from com.sun.star.beans import Property
from com.sun.star.beans import UnknownPropertyException
from com.sun.star.lang import WrappedTargetException
from com.sun.star.lang import XTypeProvider
from com.sun.star.uno import XInterface
from uno import Type as UnoType
from theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup import GeneralConstantsConstantsGroup
from theBiasPlanet.unoUtilities.inspectionsHandling.UnoInterfaceNotImplementedException import UnoInterfaceNotImplementedException

class UnoComponentInspector:
	@staticmethod
	def getUnoTypeNames (a_unoObject: XInterface) -> List [str]:
		l_UnoTypes: List [UnoType] = None
		try:
			l_UnoTypes = cast (XTypeProvider, a_unoObject).getTypes ()
		except (Exception) as l_exception:
			raise UnoInterfaceNotImplementedException ("XTypeProvider");
		l_numberOfUnoTypes: int = len (l_UnoTypes)
		l_unoTypeNames: List [str] = [None] * l_numberOfUnoTypes
		l_unoTypeIndex: int
		for l_unoTypeIndex in range (GeneralConstantsConstantsGroup.c_iterationStartNumber, l_numberOfUnoTypes, 1):
			l_unoTypeNames [l_unoTypeIndex] = l_UnoTypes [l_unoTypeIndex].typeName
		return l_unoTypeNames
	
	@staticmethod
	def getPropertyNameToValueMap (a_unoObject: XInterface) -> "OrderedDict [str, object]":
		l_propertyNameToValueMap: "OrderedDict [str, object]" = OrderedDict ()
		l_propertySetInfo: XPropertySetInfo = None
		try:
			l_propertySetInfo = cast (XPropertySet, a_unoObject).getPropertySetInfo ()
		except (Exception) as l_exception:
			raise UnoInterfaceNotImplementedException ("XPropertySet")
		if l_propertySetInfo is not None:
			l_properties: List [Property]  = l_propertySetInfo.getProperties ()
			l_numberOfProperties: int = len (l_properties)
			l_propertyIndex: int = GeneralConstantsConstantsGroup.c_iterationStartNumber
			for l_propertyIndex in range (GeneralConstantsConstantsGroup.c_iterationStartNumber, l_numberOfProperties, 1):
				try:
					l_propertyNameToValueMap.update ( {l_properties [l_propertyIndex].Name: cast (XPropertySet, a_unoObject).getPropertyValue (l_properties [l_propertyIndex].Name)})
				except (UnknownPropertyException) as l_exception:
					l_propertyNameToValueMap.update ( {l_properties [l_propertyIndex].Name: "Not Found"})
				except (Exception) as l_exception:
					l_propertyNameToValueMap.update ( {l_properties [l_propertyIndex].Name: ": ### An error has occurred in getting the property value: exception is {0:s}.".format (l_exception)})
			return l_propertyNameToValueMap
		else:
			return l_propertyNameToValueMap
	
	@staticmethod
	def implementsUnoType (a_unoObject: XInterface, a_unoTypeName: str) -> bool:
		l_unoTypeNames: List [str] = UnoComponentInspector.getUnoTypeNames (a_unoObject)
		l_unoTypeName: str = None
		for l_unoTypeName in l_unoTypeNames:
			if l_unoTypeName == a_unoTypeName:
				return True
		return False

