from typing import Optional
from collections import OrderedDict
import sys
from types import ModuleType
from theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup import GeneralConstantsConstantsGroup
from theBiasPlanet.unoUtilities.pythonSourceLoader.UnoExtendedPythonSourceLoader import UnoExtendedPythonSourceLoader

class UnoExtendedPythonModuleImporter:
	c_pythonModulesBaseDirectoryIndicator: str = "/Scripts/python/"
	c_sourceFileUrlModulePropertyName: str = "s_sourceFileUrl"
	
	@staticmethod
	def getUriPrefix (a_sourceFileUrl: str) -> str:
		l_uriPrefix: str = a_sourceFileUrl [GeneralConstantsConstantsGroup.c_iterationStartNumber: a_sourceFileUrl.find (UnoExtendedPythonModuleImporter.c_pythonModulesBaseDirectoryIndicator) + len (UnoExtendedPythonModuleImporter.c_pythonModulesBaseDirectoryIndicator)]
		return l_uriPrefix
	
	@staticmethod
	def importModule (a_unoExtendedPythonSourceLoader: "UnoExtendedPythonSourceLoader", a_moduleName: str, a_setModuleProperties: "Optional [OrderedDict [str, object]]") -> ModuleType:
		l_pythonModule = ModuleType (a_moduleName)
		l_pythonModule.__dict__ [UnoExtendedPythonModuleImporter.c_sourceFileUrlModulePropertyName] = a_unoExtendedPythonSourceLoader.get_filename (a_moduleName)
		l_propertyName: str
		l_propertyValue: object
		for l_propertyName, l_propertyValue in a_setModuleProperties.items ():
			l_pythonModule.__dict__ [l_propertyName] = l_propertyValue
		a_unoExtendedPythonSourceLoader.exec_module (l_pythonModule)
		sys.modules [a_moduleName] = l_pythonModule
		return l_pythonModule

