from typing import Dict
from typing import Optional
import uno
from uno import Any as UnoAny
from com.sun.star.uno import Exception as com_sun_star_uno_Exception
from com.sun.star.uno import XComponentContext
from theBiasPlanet.unoUtilities.constantsGroups.UnoDatumTypeNamesConstantsGroup import UnoDatumTypeNamesConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.UnoMessagesConstantsGroup import UnoMessagesConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.UnoObjectsContextPropertyNamesSet import UnoObjectsContextPropertyNamesSet
from theBiasPlanet.unoUtilities.unoObjectsContexts.LocalUnoObjectsContext import LocalUnoObjectsContext

class UnoProcessEnvironment:
	
	def __init__ (a_this: "UnoProcessEnvironment", a_identification: str, a_globalUnoServiceInstancesFactoriesConfigurationFileUrl: Optional [str]) -> None:
		a_this.i_localObjectsContext: "LocalUnoObjectsContext"
		
		try:
			l_unoObjectsContextExtraNameToValueMap: Dict [str, UnoAny] = dict ()
			l_unoObjectsContextExtraNameToValueMap.update ({UnoObjectsContextPropertyNamesSet.c_identification_string: UnoAny (UnoDatumTypeNamesConstantsGroup.c_stringTypeName, a_identification)})
			#l_unoObjectsContextExtraNameToValueMap.update ({UnoObjectsContextPropertyNamesSet.c_identification_string: a_identification})
			a_this.i_localObjectsContext = LocalUnoObjectsContext (uno.getComponentContext (), l_unoObjectsContextExtraNameToValueMap)
		except (com_sun_star_uno_Exception) as l_exception:
			raise com_sun_star_uno_Exception ("{0:s} {1:s}".format (UnoMessagesConstantsGroup.c_unoObjectsContextNotCreated, str (l_exception)), None)
	
	def getLocalObjectsContext (a_this: "UnoProcessEnvironment") -> "LocalUnoObjectsContext":
		return a_this.i_localObjectsContext

