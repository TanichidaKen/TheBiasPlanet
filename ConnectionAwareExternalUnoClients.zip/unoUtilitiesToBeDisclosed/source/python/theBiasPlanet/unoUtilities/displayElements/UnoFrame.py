from typing import Optional
from typing import List
from typing import cast
import threading
from threading import Lock
import uno
from com.sun.star.awt import XWindow
from com.sun.star.beans import PropertyValue
from com.sun.star.frame import DispatchResultEvent
from com.sun.star.frame import FeatureStateEvent
from com.sun.star.frame import XDispatchProvider
from com.sun.star.frame import XDispatchResultListener
from com.sun.star.frame import XFrame
from com.sun.star.frame import XNotifyingDispatch
from com.sun.star.frame import XStatusListener
from com.sun.star.frame import XSynchronousDispatch
from com.sun.star.lang import EventObject
from com.sun.star.util import URL as com_sun_star_util_URL
from theBiasPlanet.coreUtilities.collectionsHandling.ListsFactory import ListsFactory
from theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup import GeneralConstantsConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.UnoDispatchSlotsConstantsGroup import UnoDispatchSlotsConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.UnoSpecialFrameNamesConstantsGroup import UnoSpecialFrameNamesConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.UnoDispatchesCommonArgumentEnumerablePropertyNamesSet import UnoDispatchesCommonArgumentEnumerablePropertyNamesSet
from theBiasPlanet.unoUtilities.dispatchingHandling.UnoDispatchResultAndRelatedInformation import UnoDispatchResultAndRelatedInformation
from theBiasPlanet.unoUtilities.pointers.UnoObjectPointer import UnoObjectPointer
from theBiasPlanet.unoUtilities.propertiesHandling.UnoPropertiesHandler import UnoPropertiesHandler
from theBiasPlanet.unoUtilities.unoComponentBases.UnoComponentBase import UnoComponentBase
from theBiasPlanet.unoUtilities.unoObjectsContexts.RemoteUnoObjectsContext import RemoteUnoObjectsContext

class UnoFrame  (UnoComponentBase, XDispatchResultListener, XStatusListener):
	def __init__ (a_this: "UnoFrame", a_remoteUnoObjectsContext: "RemoteUnoObjectsContext", a_underlyingUnoObject: "UnoObjectPointer [XFrame]") -> None:
		a_this.i_lock: Lock
		a_this.i_remoteUnoObjectsContext: "RemoteUnoObjectsContext"
		a_this.i_underlyingUnoObject: "UnoObjectPointer [XFrame]"
		a_this.i_containerWindow: "UnoObjectPointer [XWindow]"
		a_this.i_dispatchResultAndRelatedInformation: "UnoDispatchResultAndRelatedInformation"
		
		a_this.i_lock = threading.Lock ()
		a_this.i_remoteUnoObjectsContext = a_remoteUnoObjectsContext
		a_this.i_underlyingUnoObject = a_underlyingUnoObject
		a_this.i_containerWindow = a_this.i_underlyingUnoObject.getAddress ().getContainerWindow ()
		a_this.i_dispatchResultAndRelatedInformation = None
	
	def __del__ (a_this: "UnoFrame") -> None:
		None
	
	def dispatchFinished (a_this: "UnoFrame", a_dispatchResultEvent: DispatchResultEvent) -> None:
		a_this.i_dispatchResultAndRelatedInformation.setResult (a_dispatchResultEvent)
	
	def statusChanged (a_this: "UnoFrame", a_featureStateEvent: FeatureStateEvent) -> None:
		a_this.i_dispatchResultAndRelatedInformation.addRelatedInformationPiece (a_featureStateEvent)
	
	def disposing (a_this: "UnoFrame", a_source: EventObject) -> None:
		None
	
	def getRemoteUnoObjectsContext (a_this: "UnoFrame") -> "RemoteUnoObjectsContext":
		return a_this.i_remoteUnoObjectsContext
	
	def getUnderlyingUnoObject (a_this: "UnoFrame") -> "UnoObjectPointer [XFrame]":
		return a_this.i_underlyingUnoObject
	
	def getUnoDispatcher (a_this: "UnoFrame", a_urlInURL: com_sun_star_util_URL) -> "UnoObjectPointer [XNotifyingDispatch]":
		return UnoObjectPointer (XNotifyingDispatch, a_this.i_underlyingUnoObject.getAddress ().queryDispatch (a_urlInURL, UnoSpecialFrameNamesConstantsGroup.c_self, GeneralConstantsConstantsGroup.c_unspecifiedInteger))
	
	def fulfill (a_this: "UnoFrame", a_unoDispatchSlot: "UnoDispatchSlotsConstantsGroup.BaseUnoDispatchSlot", a_unoDispatchArgumentValues: Optional [List [object]]) -> "UnoDispatchResultAndRelatedInformation":
		try:
			a_this.i_lock.acquire ()
			a_this.i_dispatchResultAndRelatedInformation = UnoDispatchResultAndRelatedInformation ()
			l_unoDispatchArgumentProperties: Optional [List [PropertyValue]] = None
			if a_unoDispatchSlot.c_unoDispatchArgumentPropertyNamesSet is not None:
				if a_unoDispatchArgumentValues is not None:
					l_unoDispatchArgumentProperties = UnoPropertiesHandler.buildProperties (ListsFactory.createListExpandingItems (str, UnoDispatchesCommonArgumentEnumerablePropertyNamesSet.c_instance.getValues (),  a_unoDispatchSlot.c_unoDispatchArgumentPropertyNamesSet.getValues ()), ListsFactory.createListExpandingItems (object, True, a_unoDispatchArgumentValues))
				else:
					l_unoDispatchArgumentProperties = UnoPropertiesHandler.buildProperties (UnoDispatchesCommonArgumentEnumerablePropertyNamesSet.c_instance.getValues (), ListsFactory.createList (object, True))
			else:
				if a_unoDispatchArgumentValues is not None:
					l_unoDispatchArgumentProperties = UnoPropertiesHandler.buildProperties (ListsFactory.createListExpandingItems (str, UnoDispatchesCommonArgumentEnumerablePropertyNamesSet.c_instance.getValues (), a_unoDispatchSlot.c_urlInURL.Path), ListsFactory.createListExpandingItems (object, True, a_unoDispatchArgumentValues [0]))
				else:
					l_unoDispatchArgumentProperties = UnoPropertiesHandler.buildProperties (UnoDispatchesCommonArgumentEnumerablePropertyNamesSet.c_instance.getValues (), ListsFactory.createList (object, True))
			l_urlInURL: com_sun_star_util_URL  = a_unoDispatchSlot.c_urlInURL
			l_unoDispatcher: "UnoObjectPointer [XNotifyingDispatch]" = a_this.getUnoDispatcher (l_urlInURL)
			if l_unoDispatcher is not None:
				l_unoDispatcher.getAddress ().addStatusListener (a_this, l_urlInURL)
				l_unoDispatcher.getAddress ().dispatchWithNotification (l_urlInURL, l_unoDispatchArgumentProperties, a_this)
				l_unoDispatcher.getAddress ().removeStatusListener (a_this, l_urlInURL)
			else:
				a_this.i_dispatchResultAndRelatedInformation = None
			return a_this.i_dispatchResultAndRelatedInformation;
		finally:
			a_this.i_lock.release ()

