from typing import cast
from typing import Dict
from typing import List
from typing import Optional
from abc import ABCMeta
from sys import stdout
import uno
from uno import Any as UnoAny
from com.sun.star.bridge import BridgeExistsException
from com.sun.star.bridge import XBridge
from com.sun.star.bridge import XBridgeFactory
from com.sun.star.bridge import XInstanceProvider
from com.sun.star.connection import XConnection
from com.sun.star.uno import Exception as com_sun_star_uno_Exception
from com.sun.star.uno import XComponentContext
from com.sun.star.uno import XInterface
from theBiasPlanet.coreUtilities.stringsHandling.StringTokenizer import StringTokenizer
from theBiasPlanet.unoUtilities.connection.UnoConnection import UnoConnection
from theBiasPlanet.unoUtilities.constantsGroups.UnoDefaultValuesConstantsGroup import UnoDefaultValuesConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.UnoMessagesConstantsGroup import UnoMessagesConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.UnoServiceNamesConstantsGroup import UnoServiceNamesConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.UnoObjectsContextPropertyNamesSet import UnoObjectsContextPropertyNamesSet
from theBiasPlanet.unoUtilities.pointers.UnoObjectPointer import UnoObjectPointer
from theBiasPlanet.unoUtilities.unoDataHandling.UnoDatumConverter import UnoDatumConverter
from theBiasPlanet.unoUtilities.unoObjectsContexts.LocalUnoObjectsContext import LocalUnoObjectsContext

class UnoConnectionsFactory (metaclass=ABCMeta):
	def __init__ (a_this: "UnoConnectionsFactory", a_localUnoObjectsContext: LocalUnoObjectsContext) -> None:
		a_this.i_localUnoObjectsContext: "LocalUnoObjectsContext" = None
		a_this.i_unoBridgesFactory: XBridgeFactory = None
		
		a_this.i_localUnoObjectsContext = a_localUnoObjectsContext
	
	def __del__ (a_this: "UnoConnectionsFactory") -> None:
		None
	
	def initialize (a_this: "UnoConnectionsFactory") -> None:
		a_this.i_unoBridgesFactory = a_this.i_localUnoObjectsContext.getLocalUnoServiceInstance (XBridgeFactory, UnoServiceNamesConstantsGroup.c_com_sun_star_bridge_BridgeFactory, None)
	
	def setUpUnoConnection (a_this: "UnoConnectionsFactory", a_connection: XConnection, a_urlTokenizer: StringTokenizer, a_connectionIdentification: str, a_eventsListeners: "Optional [List [UnoConnection.UnoConnectionEventsListener]]") -> UnoConnection:
		l_initialUnoObjectsProvider: "UnoConnection.InitialUnoObjectsProvider" = UnoConnection.InitialUnoObjectsProvider (a_this.i_localUnoObjectsContext)
		l_unoBridge: XBridge = None
		try:
			l_unoBridge = a_this.i_unoBridgesFactory.createBridge ("", a_urlTokenizer.nextToken (), a_connection, l_initialUnoObjectsProvider)
		except (BridgeExistsException) as l_exception:
			# This can't happen
			None
		l_remoteUnoObjectsContext: "UnoObjectPointer [XComponentContext]" = UnoObjectPointer (XComponentContext, l_unoBridge.getInstance (a_urlTokenizer.nextToken ()))
		if (l_remoteUnoObjectsContext.isEmpty ()):
			raise Exception (UnoMessagesConstantsGroup.c_remoteInstanceNotProvided)
		#l_unoObjectsContextExtraNameToValueMap:Dict [str, object] = Dict [str, object] ()
		l_unoObjectsContextExtraNameToValueMap: Dict [str, UnoAny] = dict ()
		l_unoObjectsContextExtraNameToValueMap.update ({UnoObjectsContextPropertyNamesSet.c_identification_string: UnoDatumConverter.getAny ("{0:s}: {1:s}".format (a_connection.getDescription (), a_connectionIdentification))})
		return UnoConnection (l_remoteUnoObjectsContext, l_unoObjectsContextExtraNameToValueMap, l_unoBridge, l_initialUnoObjectsProvider, a_eventsListeners)

