from typing import List
from typing import Optional
from typing import cast
from datetime import datetime
from com.sun.star.connection import NoConnectException
from com.sun.star.connection import XConnection
from com.sun.star.connection import XConnector
from theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup import GeneralConstantsConstantsGroup
from theBiasPlanet.coreUtilities.messagingHandling.Publisher import Publisher
from theBiasPlanet.coreUtilities.stringsHandling.StringTokenizer import StringTokenizer
from theBiasPlanet.unoUtilities.connection.UnoConnection import UnoConnection
from theBiasPlanet.unoUtilities.connectionsHandling.UnoConnectionsFactory import UnoConnectionsFactory
from theBiasPlanet.unoUtilities.constantsGroups.UnoGeneralConstantsConstantsGroup import UnoGeneralConstantsConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.UnoServiceNamesConstantsGroup import UnoServiceNamesConstantsGroup
from theBiasPlanet.unoUtilities.unoObjectsContexts.LocalUnoObjectsContext import LocalUnoObjectsContext

class UnoConnectionConnector (UnoConnectionsFactory):
	def __init__ (a_this: "UnoConnectionConnector", a_localUnoObjectsContext: "LocalUnoObjectsContext") -> None:
		
		UnoConnectionsFactory.__init__ (a_this, a_localUnoObjectsContext)
		a_this.initialize ()
	
	def __del__ (a_this: "UnoConnectionConnector") -> None:
		None
	
	def connect (a_this: "UnoConnectionConnector", a_url: str, a_eventsListeners: "Optional [List [UnoConnection.UnoConnectionEventsListener]]") -> UnoConnection:
		l_urlTokenizer:StringTokenizer = StringTokenizer (a_url, UnoGeneralConstantsConstantsGroup.c_connectionUrlDelimiter)
		l_unoConnectionConnector: XConnector = a_this.i_localUnoObjectsContext.getLocalUnoServiceInstance (XConnector, UnoServiceNamesConstantsGroup.c_com_sun_star_connection_Connector, None)
		try:
			l_unoConnection: XConnection = l_unoConnectionConnector.connect (l_urlTokenizer.nextToken ())
			return a_this.setUpUnoConnection (l_unoConnection, l_urlTokenizer, str (datetime.now ()), a_eventsListeners)
		except (NoConnectException) as l_exception:
			Publisher.logErrorInformation (str (l_exception))
			return None

