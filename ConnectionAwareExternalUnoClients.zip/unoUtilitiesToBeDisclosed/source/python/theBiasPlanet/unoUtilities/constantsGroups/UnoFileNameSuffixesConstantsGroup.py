
class UnoFileNameSuffixesConstantsGroup:
	c_unoIdlFileNameSuffix: str = "idl"
	c_unoDataTypesMergedRegistryFileNameSuffix: str = "rdb"

