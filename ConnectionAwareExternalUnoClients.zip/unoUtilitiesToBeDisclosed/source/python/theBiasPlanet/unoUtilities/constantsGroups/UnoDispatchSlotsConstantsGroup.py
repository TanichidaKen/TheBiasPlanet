from typing import Optional
from com.sun.star.util import URL as com_sun_star_util_URL
from theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup import BaseEnumerableConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.Uno_uno_BasicIDEAppearEnumerablePropertyNamesSet import Uno_uno_BasicIDEAppearEnumerablePropertyNamesSet
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.Uno_uno_BasicIDEAppearEnumerablePropertyNamesSet import Uno_uno_BasicIDEAppearEnumerablePropertyNamesSet
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.Uno_uno_ClipboardFormatItemsEnumerablePropertyNamesSet import Uno_uno_ClipboardFormatItemsEnumerablePropertyNamesSet
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.Uno_uno_DeleteEnumerablePropertyNamesSet import Uno_uno_DeleteEnumerablePropertyNamesSet
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.Uno_uno_GoToCellEnumerablePropertyNamesSet import Uno_uno_GoToCellEnumerablePropertyNamesSet
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.Uno_uno_PasteEnumerablePropertyNamesSet import Uno_uno_PasteEnumerablePropertyNamesSet
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.Uno_uno_PasteSpecialEnumerablePropertyNamesSet import Uno_uno_PasteSpecialEnumerablePropertyNamesSet
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet import Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet
from theBiasPlanet.unoUtilities.unoDataHandling.UnoDatumConverter import UnoDatumConverter

class UnoDispatchSlotsConstantsGroup:
	# Base class for all the constants in this group
	class BaseUnoDispatchSlot:
		def __init__ (a_this: "UnoDispatchSlotsConstantsGroup.BaseUnoDispatchSlot", a_url: str, a_unoDispatchArgumentPropertyNamesSet: "Optional [BaseEnumerableConstantsGroup [str]]"):
			a_this.c_urlInURL: com_sun_star_util_URL
			a_this.c_unoDispatchArgumentPropertyNamesSet: "Optional [BaseEnumerableConstantsGroup [str]]"
			
			a_this.c_urlInURL = UnoDatumConverter.getUrlInURL (a_url)
			a_this.c_unoDispatchArgumentPropertyNamesSet = a_unoDispatchArgumentPropertyNamesSet
	c__uno_BasicIDEAppear: "BaseUnoDispatchSlot" = BaseUnoDispatchSlot (".uno:BasicIDEAppear", Uno_uno_BasicIDEAppearEnumerablePropertyNamesSet.c_instance)
	c__uno_CompileBasic: "BaseUnoDispatchSlot" = BaseUnoDispatchSlot (".uno:CompileBasic", None)
	c__uno_GoToCell: "BaseUnoDispatchSlot" = BaseUnoDispatchSlot (".uno:GoToCell", Uno_uno_GoToCellEnumerablePropertyNamesSet.c_instance)
	c__uno_Paste: "BaseUnoDispatchSlot" = BaseUnoDispatchSlot (".uno:Paste", Uno_uno_PasteEnumerablePropertyNamesSet.c_instance)
	c__uno_SelectAll: "BaseUnoDispatchSlot" = BaseUnoDispatchSlot (".uno:SelectAll", None)
	c__uno_StyleNewByExample: "BaseUnoDispatchSlot" = BaseUnoDispatchSlot (".uno:StyleNewByExample", Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet.c_instance)
	c__uno_ClipboardFormatItems: "BaseUnoDispatchSlot" = BaseUnoDispatchSlot (".uno:ClipboardFormatItems", Uno_uno_ClipboardFormatItemsEnumerablePropertyNamesSet.c_instance)
	c__uno_PasteSpecial: "BaseUnoDispatchSlot" = BaseUnoDispatchSlot (".uno:PasteSpecial", Uno_uno_PasteSpecialEnumerablePropertyNamesSet.c_instance)
	c__uno_PasteUnformatted: "BaseUnoDispatchSlot" = BaseUnoDispatchSlot (".uno:PasteUnformatted", None)
	c__uno_PasteOnlyText: "BaseUnoDispatchSlot" = BaseUnoDispatchSlot (".uno:PasteOnlyText", None)
	c__uno_PasteOnlyFormula: "BaseUnoDispatchSlot" = BaseUnoDispatchSlot (".uno:PasteOnlyFormula", None)
	c__uno_PasteOnlyValue: "BaseUnoDispatchSlot" = BaseUnoDispatchSlot (".uno:PasteOnlyValue", None)
	c__uno_Cut: "BaseUnoDispatchSlot" = BaseUnoDispatchSlot (".uno:Cut", None)
	c__uno_Copy: "BaseUnoDispatchSlot" = BaseUnoDispatchSlot (".uno:Copy", None)
	c__uno_Delete: "BaseUnoDispatchSlot" = BaseUnoDispatchSlot (".uno:Delete", Uno_uno_DeleteEnumerablePropertyNamesSet.c_instance)

