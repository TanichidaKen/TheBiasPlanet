
class UnoSingletonNamesConstantsGroup:
	c_com_sun_star_frame_theGlobalEventBroadcaster: str = "com.sun.star.frame.theGlobalEventBroadcaster";

