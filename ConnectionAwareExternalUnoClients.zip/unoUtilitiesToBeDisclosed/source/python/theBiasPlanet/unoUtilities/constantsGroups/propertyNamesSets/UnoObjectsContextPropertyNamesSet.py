from theBiasPlanet.unoUtilities.constantsGroups.UnoGeneralConstantsConstantsGroup import UnoGeneralConstantsConstantsGroup

class UnoObjectsContextPropertyNamesSet:
	c_identification_string: str = "identification"
	c_unoDesktopSingleton_string: str = UnoGeneralConstantsConstantsGroup.c_singletonUrlFormat.format ("theBiasPlanet.unoUtilities.displayElements")

