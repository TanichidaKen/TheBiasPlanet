from theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup import BaseEnumerableConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.UnoPropertyNamesSet import UnoPropertyNamesSet

class Uno_uno_ClipboardFormatItemsEnumerablePropertyNamesSet (BaseEnumerableConstantsGroup [str], UnoPropertyNamesSet):
	c_selectedFormatForPasting_int: str = "SelectedFormat"
	c_instance: "Uno_uno_ClipboardFormatItemsEnumerablePropertyNamesSet"
	
	def __init__ (a_this: "Uno_uno_ClipboardFormatItemsEnumerablePropertyNamesSet") -> None:
		BaseEnumerableConstantsGroup.__init__ (a_this, str)

Uno_uno_ClipboardFormatItemsEnumerablePropertyNamesSet.c_instance = Uno_uno_ClipboardFormatItemsEnumerablePropertyNamesSet ()

