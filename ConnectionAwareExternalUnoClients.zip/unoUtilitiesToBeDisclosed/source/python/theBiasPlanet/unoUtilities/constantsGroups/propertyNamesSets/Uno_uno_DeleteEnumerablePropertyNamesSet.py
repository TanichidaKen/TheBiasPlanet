from theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup import BaseEnumerableConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.UnoPropertyNamesSet import UnoPropertyNamesSet

class Uno_uno_DeleteEnumerablePropertyNamesSet (BaseEnumerableConstantsGroup [str], UnoPropertyNamesSet):
	c_deletedElementsFlags_string: str = "Flags"
	c_instance: "Uno_uno_DeleteEnumerablePropertyNamesSet"
	
	def __init__ (a_this: "Uno_uno_DeleteEnumerablePropertyNamesSet") -> None:
		BaseEnumerableConstantsGroup.__init__ (a_this, str)

Uno_uno_DeleteEnumerablePropertyNamesSet.c_instance = Uno_uno_DeleteEnumerablePropertyNamesSet ()

