from theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup import BaseEnumerableConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.UnoPropertyNamesSet import UnoPropertyNamesSet

class Uno_uno_PasteEnumerablePropertyNamesSet (BaseEnumerableConstantsGroup [str], UnoPropertyNamesSet):
	c_dummy_short: str = "AnchorType";
	c_instance: "Uno_uno_PasteEnumerablePropertyNamesSet"
	
	def __init__ (a_this: "Uno_uno_PasteEnumerablePropertyNamesSet") -> None:
		BaseEnumerableConstantsGroup.__init__ (a_this, str)

Uno_uno_PasteEnumerablePropertyNamesSet.c_instance = Uno_uno_PasteEnumerablePropertyNamesSet ()

