from theBiasPlanet.unoUtilities.constantsGroups.UnoFileNameSuffixesConstantsGroup import UnoFileNameSuffixesConstantsGroup

class UnoGeneralConstantsConstantsGroup:
	c_unspecifiedString: str = ""
	c_digitPlaceCharacter: str = '0' # char
	c_numberExpressionModelNumber: float = 0.0
	c_cellPositionExpressionFormat: str = "$%s$%s"
	c_rowIndexToRowPositionExpressionDifference: int = -1
	c_connectionUrlDelimiter: str = ";"
	c_moduleDlimiter: str = "::"
	c_unoServiceNameFormat: str = "%s.%s"
	c_unoIdlFileNameFormat: str = "%s.{0:s}".format (UnoFileNameSuffixesConstantsGroup.c_unoIdlFileNameSuffix)
	c_unoModuleStartRelativeExpressionFormat: str = "module %s {"
	c_unoModuleEndRelativeExpressionFormat: str = "};"
	c_macroUrlFormat: str = "vnd.sun.star.script:{0:s}?language={1:s}&location={2:s}"

