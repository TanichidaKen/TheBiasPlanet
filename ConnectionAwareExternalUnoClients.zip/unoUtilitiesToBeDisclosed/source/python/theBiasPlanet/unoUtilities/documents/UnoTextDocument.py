from typing import cast
from typing import Optional
from com.sun.star.frame import XModel
from com.sun.star.lang import XComponent
from com.sun.star.text import XText
from com.sun.star.text import XTextDocument
from com.sun.star.text import XTextViewCursor
from com.sun.star.text import XTextViewCursorSupplier
from theBiasPlanet.unoUtilities.constantsGroups.UnoMessagesConstantsGroup import UnoMessagesConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.UnoSpecialFileUrlsConstantsGroup import UnoSpecialFileUrlsConstantsGroup
from theBiasPlanet.unoUtilities.displayElements.UnoDesktop import UnoDesktop
from theBiasPlanet.unoUtilities.documents.UnoDocument import UnoDocument
from theBiasPlanet.unoUtilities.pointers.UnoObjectPointer import UnoObjectPointer
from theBiasPlanet.unoUtilities.unoObjectsContexts.RemoteUnoObjectsContext import RemoteUnoObjectsContext

class UnoTextDocument (UnoDocument):
	@staticmethod
	def createDocument (a_unoDesktop: "UnoDesktop", a_unoDocumentIsHidden: bool) -> "UnoTextDocument":
		return UnoTextDocument (a_unoDesktop.getRemoteUnoObjectsContext (), a_unoDesktop.loadUnoDocument (UnoSpecialFileUrlsConstantsGroup.c_writerNewDocument, None, a_unoDocumentIsHidden))
	
	@staticmethod
	def openFile (a_unoDesktop: "UnoDesktop", a_fileUrl: str, a_password: str, a_unoDocumentIsHidden: bool) -> "UnoTextDocument":
		return UnoTextDocument (a_unoDesktop.getRemoteUnoObjectsContext (), a_unoDesktop.loadUnoDocument (a_fileUrl, a_password, a_unoDocumentIsHidden))
	
	@staticmethod
	def getCurrentDocument (a_unoDesktop: "UnoDesktop") -> "UnoTextDocument":
		return UnoTextDocument (a_unoDesktop.getRemoteUnoObjectsContext (), a_unoDesktop.getCurrentDocument ())
	
	def __init__ (a_this: "UnoTextDocument", a_remoteUnoObjectsContext: "RemoteUnoObjectsContext", a_underlyingUnoObject: "UnoObjectPointer [XModel]") -> None:
		a_this.i_unoTextViewCursor: "UnoObjectPointer [XTextViewCursor]"
		a_this.i_unoText: "UnoObjectPointer [XText]"
		
		UnoDocument.__init__ (a_this, a_remoteUnoObjectsContext, a_underlyingUnoObject)
		a_this.i_unoTextViewCursor = UnoObjectPointer (XTextViewCursor, a_this.i_unoController.getAddress ().getViewCursor ())
		a_this.i_unoText = UnoObjectPointer (XText, a_this.i_underlyingUnoObject.getAddress ().getText ())
	
	def getUnoTextViewCursor (a_this: "UnoTextDocument") -> "UnoObjectPointer [XTextViewCursor]":
		return a_this.i_unoTextViewCursor

