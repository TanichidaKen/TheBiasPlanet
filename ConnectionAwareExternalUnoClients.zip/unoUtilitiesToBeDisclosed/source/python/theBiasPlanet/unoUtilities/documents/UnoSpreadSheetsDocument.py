from typing import cast
from typing import Dict
from typing import Optional
from com.sun.star.frame import XModel
from com.sun.star.lang import Locale
from com.sun.star.lang import XComponent
from com.sun.star.sheet import XSpreadsheetDocument
from com.sun.star.sheet import XSpreadsheets
from com.sun.star.sheet import XSpreadsheetView;
from com.sun.star.util import XNumberFormats
from theBiasPlanet.unoUtilities.constantsGroups.UnoMessagesConstantsGroup import UnoMessagesConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.UnoSpecialFileUrlsConstantsGroup import UnoSpecialFileUrlsConstantsGroup
from theBiasPlanet.unoUtilities.displayElements.UnoDesktop import UnoDesktop
from theBiasPlanet.unoUtilities.documents.UnoDocument import UnoDocument
from theBiasPlanet.unoUtilities.pointers.UnoObjectPointer import UnoObjectPointer
from theBiasPlanet.unoUtilities.unoObjectsContexts.RemoteUnoObjectsContext import RemoteUnoObjectsContext

class UnoSpreadSheetsDocument (UnoDocument):
	@staticmethod
	def createDocument (a_unoDesktop: "UnoDesktop", a_unoDocumentIsHidden: bool) -> "UnoSpreadSheetsDocument":
		return UnoSpreadSheetsDocument (a_unoDesktop.getRemoteUnoObjectsContext (), a_unoDesktop.loadUnoDocument (UnoSpecialFileUrlsConstantsGroup.c_calcNewDocument, None, a_unoDocumentIsHidden))
	
	@staticmethod
	def openFile (a_unoDesktop: "UnoDesktop ", a_fileUrl: str, a_password: Optional [str], a_unoDocumentIsHidden: bool) -> "UnoSpreadSheetsDocument":
		return UnoSpreadSheetsDocument (a_unoDesktop.getRemoteUnoObjectsContext (), a_unoDesktop.loadUnoDocument (a_fileUrl, a_password, a_unoDocumentIsHidden))
	
	@staticmethod
	def getCurrentDocument (a_unoDesktop: "UnoDesktop") -> "UnoSpreadSheetsDocument":
		return UnoSpreadSheetsDocument (a_unoDesktop.getRemoteUnoObjectsContext (), a_unoDesktop.getCurrentDocument ())
	
	@staticmethod
	def getDocument (a_unoDesktop: "UnoDesktop", a_fileName: str) -> "UnoSpreadSheetsDocument":
		return UnoSpreadSheetsDocument (a_unoDesktop.getRemoteUnoObjectsContext (), a_unoDesktop.getDocument (a_fileName))
	
	def __init__ (a_this: "UnoSpreadSheetsDocument", a_remoteUnoObjectsContext: "RemoteUnoObjectsContext", a_underlyingUnoObject: "UnoObjectPointer [XModel]") -> None:
		a_this.i_sheets: "UnoObjectPointer [XSpreadsheets]"
		i_defaultLocale: Locale
		i_cellValueExpressionFormats: "UnoObjectPointer [XNumberFormats]"
		i_dateExpressionFormatKey: int
		i_timeExpressionFormatKey: int
		i_dateAndTimeExpressionFormatKey: int
		i_booleanExpressionFormatKey: int
		i_stringExpressionFormatKey: int
		i_integerExpressionFormatKey: int
		i_numberOfDecimalPlacesToDoubleExpressionFormatKeyMap: Dict [int, int]
		i_doubleExpressionFormatKeyToNumberOfDecimalPlacesMap: Dict [int, int]
		
		UnoDocument.__init__ (a_this, a_remoteUnoObjectsContext, a_underlyingUnoObject)
		a_this.i_defaultLocale = Locale ()
		# ~
		a_this.i_sheets = UnoObjectPointer (XSpreadsheets, a_this.i_underlyingUnoObject.getAddress ().getSheets ())

