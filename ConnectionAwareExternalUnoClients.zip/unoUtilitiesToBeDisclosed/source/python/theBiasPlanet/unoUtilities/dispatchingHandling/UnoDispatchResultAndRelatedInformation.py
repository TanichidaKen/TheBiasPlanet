import sys
from typing import cast
from typing import List
from typing import Optional
from com.sun.star.frame import DispatchResultEvent
from com.sun.star.frame import DispatchResultState
from com.sun.star.frame import FeatureStateEvent
from theBiasPlanet.coreUtilities.stringsHandling.StringHandler import StringHandler

class UnoDispatchResultAndRelatedInformation:
	def __init__ (a_this: "UnoDispatchResultAndRelatedInformation") -> None:
		a_this.i_finalStatus: int
		a_this.i_result: Optional [object]
		a_this.i_relatedInformation: List [object]
		
		a_this.i_finalStatus = DispatchResultState.FAILURE
		a_this.i_result = None
		a_this.i_relatedInformation = []
	
	def getResult (a_this: "UnoDispatchResultAndRelatedInformation") -> object:
		return a_this.i_result
	
	def setResult (a_this: "UnoDispatchResultAndRelatedInformation", a_resultEvent: DispatchResultEvent) -> None:
		if a_resultEvent is not None:
			a_this.i_finalStatus = a_resultEvent.State
			a_this.i_result = a_resultEvent.Result;
		else:
			a_this.i_result = None
	
	def getRelatedInformation (a_this: "UnoDispatchResultAndRelatedInformation") -> List [object]:
		return a_this.i_relatedInformation
	
	def addRelatedInformationPiece (a_this: "UnoDispatchResultAndRelatedInformation", a_relatedInformationPieceEvent: FeatureStateEvent) -> None:
		if a_relatedInformationPieceEvent is not None:
			if a_relatedInformationPieceEvent.State is not None:
				a_this.i_relatedInformation.append (a_relatedInformationPieceEvent.State)
			else:
				a_this.i_relatedInformation.append (None)
		else:
			a_this.i_relatedInformation.append (None)
	
	def toString (a_this: "UnoDispatchResultAndRelatedInformation") -> str:
		l_stringBuilder: List [str] = []
		l_stringBuilder.append ("State = ")
		l_stringBuilder.append ("{0:d}".format (a_this.i_finalStatus))
		l_stringBuilder.append (", Result = ")
		if a_this.i_result is not None:
			l_stringBuilder.append (StringHandler.getString (a_this.i_result))
		else:
			l_stringBuilder.append ("null")
		l_stringBuilder.append (", Related information = ")
		l_isInFirstIterationOfRelatedInformationPieces: bool  = True
		l_relatedInformationPiece: object 
		for l_relatedInformationPiece in a_this.i_relatedInformation:
			if not l_isInFirstIterationOfRelatedInformationPieces:
				l_stringBuilder.append (", ")
			else:
				l_isInFirstIterationOfRelatedInformationPieces = False
			l_stringBuilder.append (StringHandler.getString (l_relatedInformationPiece));
		return "".join (l_stringBuilder)

