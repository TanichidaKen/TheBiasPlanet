package theBiasPlanet.unoUtilities.stringsHandling;

import java.lang.reflect.Array;
import java.util.List;
import java.util.Map;
import com.sun.star.script.browse.XBrowseNode;
import com.sun.star.uno.XInterface;
import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.coreUtilities.stringsHandling.StringHandler;
import theBiasPlanet.unoUtilities.documentElements.UnoSpreadSheetFormula;
import theBiasPlanet.unoUtilities.pointers.UnoObjectPointer;

public class UnoExtendedStringHandler extends StringHandler {
	public static Object getObject (String a_string, Class a_objectClass) throws UnsupportedOperationException {
		if (a_objectClass == UnoSpreadSheetFormula.class) {
			return new UnoSpreadSheetFormula (a_string, GeneralConstantsConstantsGroup.c_unspecifiedInteger);
		}
		else {
			return StringHandler.getObject (a_string, a_objectClass);
		}
	}
	
	public static String getString (Object a_object) {
		if (a_object == null) {
			return "null";
		}
		else {
			Class l_class = a_object.getClass ();
			StringBuilder l_stringBuilder = new StringBuilder ();
			l_stringBuilder.append (l_class.toString ());
			l_stringBuilder.append (": ");
			if (l_class.isArray ()) {
				int l_numberOfElements = Array.getLength (a_object);
				for (int l_elementIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber; l_elementIndex < l_numberOfElements; l_elementIndex ++) {
					if (l_elementIndex != GeneralConstantsConstantsGroup.c_iterationStartNumber) {
						l_stringBuilder.append (", ");
					}
					l_stringBuilder.append (String.format ("%d-", l_elementIndex));
					l_stringBuilder.append (getString (Array.get (a_object, l_elementIndex)));
				}
			}
			else if (a_object instanceof Map) {
				int l_elementIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
				for (Map.Entry <?, ?> l_mapEntry: ((Map <?, ?>) a_object).entrySet ()) {
					if (l_elementIndex != GeneralConstantsConstantsGroup.c_iterationStartNumber) {
						l_stringBuilder.append (", ");
					}
					l_stringBuilder.append (getString (l_mapEntry.getKey ()));
					l_stringBuilder.append ("-> ");
					l_stringBuilder.append (getString (l_mapEntry.getValue ()));
					l_elementIndex ++;
				}
			}
			else if (a_object instanceof List) {
				int l_elementIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
				for (Object l_element: (List <?>) a_object) {
					
					if (l_elementIndex != GeneralConstantsConstantsGroup.c_iterationStartNumber) {
						l_stringBuilder.append (", ");
					}
					l_stringBuilder.append (getString (l_element));
					l_elementIndex ++;
				}
			}
			else if (a_object instanceof XBrowseNode) {
				XBrowseNode l_node = (XBrowseNode) a_object;
				l_stringBuilder.append (l_node.getName ());
				if (l_node.hasChildNodes ()) {
					l_stringBuilder.append ("|> ");
					l_stringBuilder.append (getString (l_node.getChildNodes ()));
				}
			}
			else if (a_object instanceof UnoObjectPointer) {
				UnoObjectPointer <? extends XInterface> l_node = (UnoObjectPointer <? extends XInterface>) a_object;
				if (l_node. <XBrowseNode>getAddress (XBrowseNode.class) != null) {
					l_stringBuilder.append (l_node. <XBrowseNode>getAddress (XBrowseNode.class).getName ());
					if (l_node. <XBrowseNode>getAddress (XBrowseNode.class).hasChildNodes ()) {
						l_stringBuilder.append ("|> ");
						l_stringBuilder.append (getString (l_node. <XBrowseNode>getAddress (XBrowseNode.class).getChildNodes ()));
					}
				}
				else {
					l_stringBuilder.append (StringHandler.getString (a_object));
				}
			}
			else {
				l_stringBuilder.append (StringHandler.getString (a_object));
			}
		 	return l_stringBuilder.toString ();
		}
	}
}

