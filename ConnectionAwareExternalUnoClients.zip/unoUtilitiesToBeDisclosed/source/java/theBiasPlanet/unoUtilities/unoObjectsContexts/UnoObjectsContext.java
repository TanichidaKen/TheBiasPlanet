package theBiasPlanet.unoUtilities.unoObjectsContexts;

import java.util.List;
import java.util.Map;
import com.sun.star.uno.XComponentContext;
import com.sun.star.uno.XInterface;
import theBiasPlanet.coreUtilities.collectionsHandling.ArraysFactory;
import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.*;
import theBiasPlanet.unoUtilities.unoComponentBases.UnoComponentBase;

public abstract class UnoObjectsContext extends UnoComponentBase implements XComponentContext {
	protected Map <String, Object> i_extraPropertyNameToValueMap = null;
	
	public UnoObjectsContext (Map <String, Object> a_extraPropertyNameToValueMap) {
		i_extraPropertyNameToValueMap = i_extraPropertyNameToValueMap;
	}
	
	@Override
	protected void finalize () {
	}
	
	public boolean isFromSameOrigin (UnoObjectsContext a_comparedUnoObjectsContext) {
		if (i_extraPropertyNameToValueMap == null || a_comparedUnoObjectsContext ==  null) {
			return false;
		}
		String l_identification = (String) i_extraPropertyNameToValueMap.get (UnoObjectsContextPropertyNamesSet.c_identification_string);
		if (l_identification == null) {
			return false;
		}
		if (l_identification.equals (a_comparedUnoObjectsContext.getValueByName (UnoObjectsContextPropertyNamesSet.c_identification_string))) {
			return true;
		}
		return false;
	}
	
	@SuppressWarnings (WarningNamesConstantsGroup.c_notChecked)
	public <T extends XInterface> T getLocalUnoServiceInstance (String a_unoServiceName, List <Object> a_unoServiceInstantiationArguments) throws com.sun.star.uno.Exception {
		if (a_unoServiceInstantiationArguments == null) {
			return (T) (getServiceManager ().createInstanceWithContext (a_unoServiceName, this));
		}
		else {
			return (T) (getServiceManager ().createInstanceWithArgumentsAndContext (a_unoServiceName, ArraysFactory. <Object>createArray (Object.class, a_unoServiceInstantiationArguments), this));
		}
	}
}

