package theBiasPlanet.unoUtilities.unoObjectsContexts;

import java.util.ArrayList;
import java.util.List;
import com.sun.star.lang.XMultiComponentFactory;
import com.sun.star.security.XCertificate;
import com.sun.star.uno.XComponentContext;
import com.sun.star.uno.XInterface;
import com.sun.star.xml.crypto.XSEInitializer;
import com.sun.star.xml.crypto.XSecurityEnvironment;
import com.sun.star.xml.crypto.XXMLSecurityContext;
import theBiasPlanet.coreUtilities.collectionsHandling.ArraysFactory;
import theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup;
import theBiasPlanet.unoUtilities.connection.UnoConnection;
import theBiasPlanet.unoUtilities.constantsGroups.UnoServiceNamesConstantsGroup;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.*;
import theBiasPlanet.unoUtilities.pointers.UnoObjectPointer;
import theBiasPlanet.unoUtilities.unoDataHandling.UnoDatumConverter;

public class RemoteUnoObjectsContext extends UnoObjectsContext {
	private UnoObjectPointer <XComponentContext> i_underlyingUnoObject = null;
	private UnoObjectPointer <XMultiComponentFactory> i_unoGlobalServicesManager = null;
	private UnoObjectPointer <XSecurityEnvironment> i_gnupgUnoSecurityEnvironment = null;
	private UnoObjectPointer <XSecurityEnvironment> i_networkSecurityServicesUnoSecurityEnvironment = null;
	
	public RemoteUnoObjectsContext (UnoObjectPointer <XComponentContext> a_underlyingUnoObject, String a_unoConnectionIdentification) throws com.sun.star.uno.Exception {
		super (a_unoConnectionIdentification);
		i_underlyingUnoObject = a_underlyingUnoObject;
		i_unoGlobalServicesManager = new UnoObjectPointer <XMultiComponentFactory> (i_underlyingUnoObject.getAddress ().getServiceManager ());
	}
	
	@Override
	protected void finalize () {
	}
	
	@Override
	public final Object getValueByName (String a_propertyName) {
		if (i_extraGlobalPropertyNameToValueMap.containsKey (a_propertyName)) {
			return i_extraGlobalPropertyNameToValueMap.get (a_propertyName);
		}
		else {
			return i_underlyingUnoObject.getAddress ().getValueByName (a_propertyName);
		}
	}
	
	@Override
	public final XMultiComponentFactory getServiceManager () {
		return i_unoGlobalServicesManager.getAddress ();
	}
	
	public <T extends XInterface> UnoObjectPointer <T> getRemoteUnoServiceInstance (String a_unoServiceName, Class <T> a_targetClass, List <Object> a_unoServiceInstantiationArguments) throws com.sun.star.uno.Exception {
		if (a_targetClass == null) {
			return null;
		}
		if (a_unoServiceInstantiationArguments == null) {
			return new UnoObjectPointer <T> ( (XInterface) (getServiceManager ().createInstanceWithContext (a_unoServiceName, this)), a_targetClass);
		}
		else {
			return new UnoObjectPointer <T> ( (XInterface) (getServiceManager ().createInstanceWithArgumentsAndContext (a_unoServiceName, ArraysFactory. <Object>createArray (Object.class, a_unoServiceInstantiationArguments), this)), a_targetClass);
		}
	}
	
	public boolean increaseCriticalSessionCount () {
		return ( (UnoConnection) getLocalPropertyValue (UnoObjectsContextPropertyNamesSet.c_unoConnectionSingleton_string)).increaseCriticalSessionCount ();
	}
	
	public void decreaseCriticalSessionCount () {
		( (UnoConnection) getLocalPropertyValue (UnoObjectsContextPropertyNamesSet.c_unoConnectionSingleton_string)).decreaseCriticalSessionCount ();
	}
	
	private UnoObjectPointer <XCertificate> selectCertificateFromCertificates (List <UnoObjectPointer <XCertificate>> a_certificates, String a_certificateIssuerName, byte [] a_certificateSerialNumber) {
		if (a_certificates != null) {
			for (UnoObjectPointer <XCertificate> l_certificate: a_certificates) {
				if (a_certificateIssuerName.equals (l_certificate.getAddress ().getIssuerName ())) {
					if (a_certificateSerialNumber == null) {
						return l_certificate;
					}
					else {
						byte [] l_certificateSerialNumber = l_certificate.getAddress ().getSerialNumber ();
						if (a_certificateSerialNumber.length == l_certificateSerialNumber.length) {
							int l_certificateSerialNumberByteIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
							for (byte l_certificateSerialNumberByte: l_certificateSerialNumber) {
								if (a_certificateSerialNumber [l_certificateSerialNumberByteIndex] != l_certificateSerialNumberByte) {
									break;
								}
								l_certificateSerialNumberByteIndex ++;
							}
							if (l_certificateSerialNumberByteIndex == l_certificateSerialNumber.length) {
								return l_certificate;
							}
						}
					}
				}
			}
		}
		return null;
	}
	
	public UnoObjectPointer <XCertificate> getGnupgCertificate (String a_certificateIssuerName) throws com.sun.star.uno.Exception {
		if (i_gnupgUnoSecurityEnvironment == null) {
			UnoObjectPointer <XSEInitializer> l_gnupgSecurityEnvironmentInitializer = this. <XSEInitializer>getRemoteUnoServiceInstance (UnoServiceNamesConstantsGroup.c_com_sun_star_xml_crypto_GPGSEInitializer, XSEInitializer.class, null);
			UnoObjectPointer <XXMLSecurityContext> l_gnupgSecurityContext = new UnoObjectPointer <XXMLSecurityContext> (l_gnupgSecurityEnvironmentInitializer.getAddress ().createSecurityContext ("Gnupg")); 
			if (l_gnupgSecurityContext.getAddress ().getSecurityEnvironmentNumber () > 0) {
				i_gnupgUnoSecurityEnvironment = new UnoObjectPointer <XSecurityEnvironment> (l_gnupgSecurityContext.getAddress ().getSecurityEnvironmentByIndex (GeneralConstantsConstantsGroup.c_iterationStartNumber));
			}
		}
		if (! (i_gnupgUnoSecurityEnvironment.isEmpty ())) {
			ArrayList <UnoObjectPointer <XCertificate>> l_gnupgCertificates = UnoDatumConverter. <XCertificate>getUnoObjects (i_gnupgUnoSecurityEnvironment.getAddress().getAllCertificates ());
			return selectCertificateFromCertificates (l_gnupgCertificates, a_certificateIssuerName, null);
		}
		return null;
	}
	
	public UnoObjectPointer <XCertificate> getNetworkSecurityServicesCertificate (String a_certificateIssuerName, byte [] a_certificateSerialNumber) throws com.sun.star.uno.Exception {
		if (i_networkSecurityServicesUnoSecurityEnvironment == null) {
			UnoObjectPointer <XSEInitializer> l_networkSecurityServicesSecurityEnvironmentInitializer = this. <XSEInitializer>getRemoteUnoServiceInstance (UnoServiceNamesConstantsGroup.c_com_sun_star_xml_crypto_SEInitializer, XSEInitializer.class, null);
			UnoObjectPointer <XXMLSecurityContext> l_networkSecurityServicesSecurityContext = new UnoObjectPointer <XXMLSecurityContext> (l_networkSecurityServicesSecurityEnvironmentInitializer.getAddress ().createSecurityContext ("NetworkSecurityServices")); 
			if (l_networkSecurityServicesSecurityContext.getAddress().getSecurityEnvironmentNumber () > 0) {
				i_networkSecurityServicesUnoSecurityEnvironment = new UnoObjectPointer <XSecurityEnvironment> (l_networkSecurityServicesSecurityContext.getAddress ().getSecurityEnvironmentByIndex (GeneralConstantsConstantsGroup.c_iterationStartNumber));
			}
		}
		if (i_networkSecurityServicesUnoSecurityEnvironment != null) {
			ArrayList <UnoObjectPointer <XCertificate>> l_networkSecurityServicesCertificates = UnoDatumConverter. <XCertificate>getUnoObjects (i_networkSecurityServicesUnoSecurityEnvironment.getAddress ().getPersonalCertificates ());
			return selectCertificateFromCertificates (l_networkSecurityServicesCertificates, a_certificateIssuerName, a_certificateSerialNumber);
		}
		return null;
	}
}

