package theBiasPlanet.unoUtilities.dispatchers;

import java.util.Map;
import java.util.HashMap;
import com.sun.star.frame.DispatchResultEvent;
import com.sun.star.frame.XDispatchResultListener;
import com.sun.star.frame.XFrame;
import com.sun.star.frame.XNotifyingDispatch;
import com.sun.star.frame.XStatusListener;
//import com.sun.star.frame.FeatureStateEvent;
import com.sun.star.util.URL;
import com.sun.star.beans.PropertyValue;
import com.sun.star.uno.RuntimeException;
import theBiasPlanet.unoUtilities.pointers.UnoObjectPointer;
import theBiasPlanet.unoUtilities.unoComponentBases.UnoComponentBase;
import theBiasPlanet.unoUtilities.unoObjectsContexts.UnoObjectsContext;

public class UnoBaseDispatcher extends UnoComponentBase implements XNotifyingDispatch {
	protected UnoObjectsContext i_unoObjectsContext = null;
	protected UnoObjectPointer <XFrame> i_unoFrame = null;
	protected URL i_urlInURL = null;
	protected Map <String, XStatusListener> i_urlToRelatedInformationPieceEventsListenerMap = null;
	//protected FeatureStateEvent i_featureStateEvent = null;
	
	public UnoBaseDispatcher (UnoObjectsContext a_unoObjectsContext, UnoObjectPointer <XFrame> a_unoFrame, URL a_urlInURL) {
		i_unoObjectsContext = a_unoObjectsContext;
		i_unoFrame = a_unoFrame;
		i_urlInURL = a_urlInURL;
		i_urlToRelatedInformationPieceEventsListenerMap = new HashMap <String, XStatusListener> ();
		/*
		i_featureStateEvent = new FeatureStateEvent ();
		i_featureStateEvent.FeatureURL = a_urlInURL;
		i_featureStateEvent.FeatureDescriptor = "";
		i_featureStateEvent.IsEnabled = true;
		i_featureStateEvent.Requery = false;
		i_featureStateEvent.State = "Initialized";
		*/
	}
	
	@Override
	public void dispatchWithNotification (URL a_urlInURL, PropertyValue [] a_propertiesArray, XDispatchResultListener a_unoDispatchResultListener) throws RuntimeException {
		DispatchResultEvent l_unoDispatchResultEvent = new DispatchResultEvent ();
		l_unoDispatchResultEvent.State = 0;
		l_unoDispatchResultEvent.Result = "";
		//i_featureStateEvent.State = "Dispatched";
		if (a_unoDispatchResultListener != null) {
			a_unoDispatchResultListener.dispatchFinished (l_unoDispatchResultEvent);
		}
	}
	
	@Override
	public void dispatch (URL a_urlInURL, PropertyValue [] a_propertiesArray) throws RuntimeException {
		dispatchWithNotification (a_urlInURL, a_propertiesArray, null);
	}
	
	@Override
	public void addStatusListener (XStatusListener a_relatedInformationPieceEventsListener, URL a_urlInURL) throws RuntimeException {
		if (a_urlInURL != null && a_relatedInformationPieceEventsListener != null) {
			i_urlToRelatedInformationPieceEventsListenerMap.put (a_urlInURL.Complete, a_relatedInformationPieceEventsListener);
			//a_statusListener.statusChanged (i_featureStateEvent);
		}
	}
	
	@Override
	public void removeStatusListener (XStatusListener a_relatedInformationPieceEventsListener, URL a_urlInURL) throws RuntimeException {
		if (a_urlInURL != null) {
			i_urlToRelatedInformationPieceEventsListenerMap.remove (a_urlInURL.Complete);
		}
	}
}

