package theBiasPlanet.unoUtilities.documentsHandling;

import java.util.ArrayList;
import com.sun.star.lang.WrappedTargetException;
import com.sun.star.sheet.XSheetCellRangeContainer;
import com.sun.star.table.XCell2;
import com.sun.star.uno.AnyConverter;
import com.sun.star.uno.XInterface;
import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.documentElements.UnoSpreadSheet;
import theBiasPlanet.unoUtilities.pointers.UnoObjectPointer;

public class UnoSpreadSheetCellsRectangles {
	ArrayList <UnoSpreadSheetCellsRectangle> i_unoCellsRectangles;
	
	public UnoSpreadSheetCellsRectangles (ArrayList <UnoSpreadSheetCellsRectangle> a_unoCellsRectangles) {
		i_unoCellsRectangles = a_unoCellsRectangles;
	}
	
	public static UnoSpreadSheetCellsRectangles getCellsRectangles (UnoSpreadSheet a_unoSpreadSheet, UnoObjectPointer <XInterface> a_selection) {
		if (a_selection. <XSheetCellRangeContainer>getAddress (XSheetCellRangeContainer.class) == null) {
			return null;
		}
		else {
			ArrayList <UnoSpreadSheetCellsRectangle> l_unoCellsRectangles = new ArrayList <UnoSpreadSheetCellsRectangle> ();
			UnoObjectPointer <XInterface> l_cellOrCellsRangeCellsIterator = null;
			for (int l_unoCellsRangeIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber; ; l_unoCellsRangeIndex ++) {
				try {
					l_cellOrCellsRangeCellsIterator = new UnoObjectPointer <XInterface> ( (XInterface) AnyConverter.toObject (XInterface.class , a_selection. <XSheetCellRangeContainer>getAddress (XSheetCellRangeContainer.class).getByIndex (l_unoCellsRangeIndex)));
					if (l_cellOrCellsRangeCellsIterator.getAddress (XCell2.class) != null) {
						l_unoCellsRectangles.add (UnoSpreadSheetCellPosition.getCellPosition (a_unoSpreadSheet, l_cellOrCellsRangeCellsIterator));
					}
					else {
						l_unoCellsRectangles.add (UnoSpreadSheetCellsRectangle.getCellsRectangle (a_unoSpreadSheet, l_cellOrCellsRangeCellsIterator));
					}
				}
				catch (com.sun.star.lang.IndexOutOfBoundsException | WrappedTargetException l_exception) {
					break;
				}
			}
			return new UnoSpreadSheetCellsRectangles (l_unoCellsRectangles);
		}
	}
	
	public ArrayList <UnoSpreadSheetCellsRectangle> getCellsRectangles () {
		return i_unoCellsRectangles;
	}
	
	public boolean contains (UnoSpreadSheetCellPosition a_cellPosition) {
		for (UnoSpreadSheetCellsRectangle l_unoCellsRectangle: i_unoCellsRectangles) {
			if (l_unoCellsRectangle.contains (a_cellPosition)) {
				return true;
			}
		}
		return false;
	}
	
	public UnoSpreadSheetCellPosition getVerticallyNextMemberCellPosition (UnoSpreadSheetCellPosition a_originalCellPosition) {
		UnoSpreadSheetCellPosition l_nextCellPosition = null;
		UnoSpreadSheetCellPosition l_nextCellPositionCandidate = null;
		UnoSpreadSheetCellPosition l_firstCellPosition = null;
		UnoSpreadSheetCellPosition l_firstCellPositionCandidate = null;
		// Ordered by the leftmost column index and the top row index.
		for (UnoSpreadSheetCellsRectangle l_unoCellsRectangle: i_unoCellsRectangles) {
			l_nextCellPositionCandidate = l_unoCellsRectangle.getVerticallyNextMemberCellPosition (a_originalCellPosition, false);
			l_nextCellPosition = UnoSpreadSheetCellPosition.getLeftmostTopCellPosition (l_nextCellPosition, l_nextCellPositionCandidate);
			l_firstCellPositionCandidate = l_unoCellsRectangle.getFirstCellPosition ();
			l_firstCellPosition = UnoSpreadSheetCellPosition.getLeftmostTopCellPosition (l_firstCellPosition, l_firstCellPositionCandidate);
		}
		if (l_nextCellPosition !=null) {
			return l_nextCellPosition;
		}
		else {
			return l_firstCellPosition;
		}
		
		/*
		UnoSpreadSheetCellPosition l_nextCellPosition = null;
		int l_cellRowIndex = a_cellPosition.getRowIndex ();
		int l_cellColumnIndex = a_cellPosition.getColumnIndex ();
		int l_sameColumnNextCellRowIndex = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		int l_sameColumnNextCellColumnIndex = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		int l_nearestRightCellTopRowIndex = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		int l_nearestRightCellColumnIndex = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		// Ordered by the leftmost column index and the top row index.
		for (UnoSpreadSheetCellsRectangle l_unoCellsRectangle: i_unoCellsRectangles) {
			// This cells range can't be any candidate.
			if (l_unoCellsRectangle.getRightmostColumnIndex () < l_cellColumnIndex) {
				continue;
			}
			// The cell is among cells range columns.
			if (l_unoCellsRectangle.getLeftmostColumnIndex () <= l_cellColumnIndex) {
				// This cells range is a candidate for including the next cell.
				if (l_unoCellsRectangle.getBottomRowIndex () > l_cellRowIndex) {
					// The previous cell column is determined.
					l_sameColumnNextCellColumnIndex = l_cellColumnIndex;
					// This cells range exists below the cell.
					if (l_unoCellsRectangle.getTopRowIndex () > l_cellRowIndex) {
						l_sameColumnNextCellRowIndex = l_unoCellsRectangle.getTopRowIndex ();
					}
					else {
						l_sameColumnNextCellRowIndex = l_cellRowIndex + 1;
					}
					break;
				}
			}
			// The next cell may exist right of the cell.
			if (l_unoCellsRectangle.getRightmostColumnIndex () > l_cellColumnIndex) {
				if (l_nearestRightCellColumnIndex == GeneralConstantsConstantsGroup.c_unspecifiedInteger) {
					l_nearestRightCellColumnIndex = Math.max (l_cellColumnIndex + 1, l_unoCellsRectangle.getLeftmostColumnIndex ());
					l_nearestRightCellTopRowIndex = l_unoCellsRectangle.getTopRowIndex ();
				}
				else {
					int l_nearestRightCellColumnIndexCandidate = Math.max (l_cellColumnIndex + 1, l_unoCellsRectangle.getLeftmostColumnIndex ());
					if (l_nearestRightCellColumnIndexCandidate < l_nearestRightCellColumnIndex) {
						l_nearestRightCellColumnIndex = l_nearestRightCellColumnIndexCandidate;
						l_nearestRightCellTopRowIndex = l_unoCellsRectangle.getTopRowIndex ();
					}
					else if (l_nearestRightCellColumnIndexCandidate == l_nearestRightCellColumnIndex) {
						l_nearestRightCellTopRowIndex = Math.min (l_nearestRightCellTopRowIndex, l_unoCellsRectangle.getTopRowIndex ());
					}
				}
			}
		}
		if (l_sameColumnNextCellRowIndex != GeneralConstantsConstantsGroup.c_unspecifiedInteger) {
			return new UnoSpreadSheetCellPosition (l_sameColumnNextCellRowIndex, l_sameColumnNextCellColumnIndex);
		}
		else {
			if (l_nearestRightCellTopRowIndex != GeneralConstantsConstantsGroup.c_unspecifiedInteger) {
				return new UnoSpreadSheetCellPosition (l_nearestRightCellTopRowIndex, l_nearestRightCellColumnIndex);
			}
			else {
				return i_unoCellsRectangles.get (GeneralConstantsConstantsGroup.c_iterationStartNumber).getFirstCellPosition ();
			}
		}
		*/
	}
	
	public UnoSpreadSheetCellPosition getVerticallyPreviousMemberCellPosition (UnoSpreadSheetCellPosition a_originalCellPosition) {
		UnoSpreadSheetCellPosition l_nextCellPosition = null;
		UnoSpreadSheetCellPosition l_nextCellPositionCandidate = null;
		UnoSpreadSheetCellPosition l_firstCellPosition = null;
		UnoSpreadSheetCellPosition l_firstCellPositionCandidate = null;
		// Ordered by the leftmost column index and the top row index.
		for (UnoSpreadSheetCellsRectangle l_unoCellsRectangle: i_unoCellsRectangles) {
			l_nextCellPositionCandidate = l_unoCellsRectangle.getVerticallyNextMemberCellPosition (a_originalCellPosition, false);
			l_nextCellPosition = UnoSpreadSheetCellPosition.getLeftmostTopCellPosition (l_nextCellPosition, l_nextCellPositionCandidate);
			l_firstCellPositionCandidate = l_unoCellsRectangle.getFirstCellPosition ();
			l_firstCellPosition = UnoSpreadSheetCellPosition.getLeftmostTopCellPosition (l_firstCellPosition, l_firstCellPositionCandidate);
		}
		if (l_nextCellPosition !=null) {
			return l_nextCellPosition;
		}
		else {
			return l_firstCellPosition;
		}
		
		/*
		UnoSpreadSheetCellPosition l_nextCellPosition = null;
		int l_cellRowIndex = a_cellPosition.getRowIndex ();
		int l_cellColumnIndex = a_cellPosition.getColumnIndex ();
		int l_sameColumnPreviousCellRowIndex = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		int l_sameColumnPreviousCellColumnIndex = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		int l_nearestLeftCellBottomRowIndex = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		int l_nearestLeftCellColumnIndex = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		// Ordered by the leftmost column index and the top row index.
		for (UnoSpreadSheetCellsRectangle l_unoCellsRectangle: i_unoCellsRectangles) {
			// There can be no more candidate cells range.
			if (l_unoCellsRectangle.getLeftmostColumnIndex () > l_cellColumnIndex) {
				break;
			}
			// The cell is among cells range columns.
			if (l_unoCellsRectangle.getRightmostColumnIndex () >= l_cellColumnIndex) {
				// This cells range is a candidate for including the previous cell.
				if (l_unoCellsRectangle.getTopRowIndex () < l_cellRowIndex) {
					// The previous cell column is determined.
					l_sameColumnPreviousCellColumnIndex = l_cellColumnIndex;
					// This cells range exists above the cell.
					if (l_unoCellsRectangle.getBottomRowIndex () < l_cellRowIndex) {
						l_sameColumnPreviousCellRowIndex = Math.max (l_sameColumnPreviousCellRowIndex, l_unoCellsRectangle.getBottomRowIndex ());
					}
					// This cells range contains the cell.
					else {
						l_sameColumnPreviousCellRowIndex = l_cellRowIndex - 1;
						break;
					}
				}
			}
			// The previous cell may exist left of the cell.
			if (l_sameColumnPreviousCellRowIndex == GeneralConstantsConstantsGroup.c_unspecifiedInteger) {
				if (l_unoCellsRectangle.getLeftmostColumnIndex () < l_cellColumnIndex) {
					if (l_nearestLeftCellColumnIndex == GeneralConstantsConstantsGroup.c_unspecifiedInteger) {
						l_nearestLeftCellColumnIndex = Math.min (l_cellColumnIndex - 1, l_unoCellsRectangle.getRightmostColumnIndex ());
						l_nearestLeftCellBottomRowIndex = l_unoCellsRectangle.getBottomRowIndex ();
					}
					else {
						int l_nearestLeftCellColumnIndexCandidate = Math.min (l_cellColumnIndex - 1, l_unoCellsRectangle.getRightmostColumnIndex ());
						if (l_nearestLeftCellColumnIndexCandidate > l_nearestLeftCellColumnIndex) {
							l_nearestLeftCellColumnIndex = l_nearestLeftCellColumnIndexCandidate;
							l_nearestLeftCellBottomRowIndex = l_unoCellsRectangle.getBottomRowIndex ();
						}
						else if (l_nearestLeftCellColumnIndexCandidate == l_nearestLeftCellColumnIndex) {
							l_nearestLeftCellBottomRowIndex = Math.max (l_nearestLeftCellBottomRowIndex, l_unoCellsRectangle.getBottomRowIndex ());
						}
					}
				}
			}
		}
		if (l_sameColumnPreviousCellRowIndex != GeneralConstantsConstantsGroup.c_unspecifiedInteger) {
			return new UnoSpreadSheetCellPosition (l_sameColumnPreviousCellRowIndex, l_sameColumnPreviousCellColumnIndex);
		}
		else {
			if (l_nearestLeftCellBottomRowIndex != GeneralConstantsConstantsGroup.c_unspecifiedInteger) {
				return new UnoSpreadSheetCellPosition (l_nearestLeftCellBottomRowIndex, l_nearestLeftCellColumnIndex);
			}
			else {
				return i_unoCellsRectangles.get (i_unoCellsRectangles.size () - 1).getLastCellPosition ();
			}
		}
		*/
	}
	
	@Override
	public boolean equals (Object a_objectToBeCompared) {
		if (!(a_objectToBeCompared instanceof UnoSpreadSheetCellsRectangles)) {
			return false;
		}
		else {
			UnoSpreadSheetCellsRectangles l_unoCellsRectanglesToBeCompared = (UnoSpreadSheetCellsRectangles) a_objectToBeCompared;
			if (l_unoCellsRectanglesToBeCompared.getCellsRectangles ().equals (i_unoCellsRectangles)) {
				return true;
			}
			else {
				return false;
			}
		}
	}
	
	@Override
	public String toString () {
		StringBuilder l_buffer = new StringBuilder ();
		for (UnoSpreadSheetCellsRectangle l_unoCellsRectangle: i_unoCellsRectangles) {
			l_buffer.append (String.format ("; %s", l_unoCellsRectangle.toString ()));
		}
		return l_buffer.toString ();
	}
}

