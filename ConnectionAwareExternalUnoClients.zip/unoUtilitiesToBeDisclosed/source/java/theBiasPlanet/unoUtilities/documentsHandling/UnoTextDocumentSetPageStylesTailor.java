package theBiasPlanet.unoUtilities.documentsHandling;

import java.util.HashMap;
import java.util.HashSet;
import com.sun.star.beans.PropertyVetoException;
import com.sun.star.beans.UnknownPropertyException;
import com.sun.star.beans.XPropertySet;
import com.sun.star.container.NoSuchElementException;
import com.sun.star.container.XNameContainer;
import com.sun.star.frame.XModel;
import com.sun.star.lang.WrappedTargetException;
import com.sun.star.style.XStyle;
import com.sun.star.style.XStyleFamiliesSupplier;
import com.sun.star.text.XPageCursor;
import com.sun.star.text.XTextDocument;
import com.sun.star.text.XTextViewCursorSupplier;
import com.sun.star.uno.AnyConverter;
import com.sun.star.uno.XInterface;
import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.coreUtilities.messagingHandling.Publisher;
import theBiasPlanet.unoUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.*;
import theBiasPlanet.unoUtilities.documentsHandling.UnoDocumentTailor;
import theBiasPlanet.unoUtilities.pointers.UnoObjectPointer;
import theBiasPlanet.unoUtilities.unoObjectsContexts.RemoteUnoObjectsContext;

public class UnoTextDocumentSetPageStylesTailor extends UnoDocumentTailor {
	private HashMap <String, Object> i_pageStylePropertyNameToPropertyValueMap = null;
	
	public UnoTextDocumentSetPageStylesTailor (RemoteUnoObjectsContext a_objectsContext, HashMap <String, Object> a_pageStylePropertyNameToPropertyValueMap) {
		super (a_objectsContext);
		i_pageStylePropertyNameToPropertyValueMap = a_pageStylePropertyNameToPropertyValueMap;
	}
	
	@Override
	public boolean tailor (UnoObjectPointer <XModel> a_unoDocument) {
		if (a_unoDocument. <XTextDocument>getAddress (XTextDocument.class) == null) {
			Publisher.logErrorInformation ("The document is not any text document.");
			return false;
		}
		else {
			try {
				UnoObjectPointer <XNameContainer> l_pageStyles = new UnoObjectPointer <XNameContainer> ( (XNameContainer) AnyConverter.toObject (XNameContainer.class, a_unoDocument. <XStyleFamiliesSupplier>getAddress (XStyleFamiliesSupplier.class).getStyleFamilies ().getByName (UnoStylesFamiliesConstantsGroup.c_unoPageStylesFamily.c_name)));
				UnoObjectPointer <XTextViewCursorSupplier> l_controller = new UnoObjectPointer <XTextViewCursorSupplier> ( (XInterface) a_unoDocument. <XModel>getAddress (XModel.class).getCurrentController (), XTextViewCursorSupplier.class);
				UnoObjectPointer <XPageCursor> l_viewCursor = new UnoObjectPointer <XPageCursor> (l_controller.getAddress ().getViewCursor (), XPageCursor.class);
				boolean l_pageIsValid = l_viewCursor.getAddress ().jumpToPage ( (short) (GeneralConstantsConstantsGroup.c_iterationStartNumber + 1));
				String l_pageStyleName = null;
				HashSet <String> l_processedPageStyleNamesSet = new HashSet <String> ();
				UnoObjectPointer <XPropertySet> l_pageStyle = null;
				while (l_pageIsValid) {
					l_pageStyleName = (String) l_controller. <XPropertySet>getAddress (XPropertySet.class).getPropertyValue (UnoTextPageCursorPropertyNamesSet.c_pageStyleName_string);
					if (l_processedPageStyleNamesSet.contains (l_pageStyleName)) {
						continue;
					}
					else {
						l_pageStyle = new UnoObjectPointer <XPropertySet> ( (XStyle) AnyConverter.toObject (XStyle.class, l_pageStyles.getAddress ().getByName (l_pageStyleName)), XPropertySet.class);
						for (HashMap.Entry <String, Object> l_pageStylePropertyNameToPropertyValueMapEntry: i_pageStylePropertyNameToPropertyValueMap.entrySet ()) {
							l_pageStyle.getAddress ().setPropertyValue (l_pageStylePropertyNameToPropertyValueMapEntry.getKey (), l_pageStylePropertyNameToPropertyValueMapEntry.getValue ());
						}
						l_processedPageStyleNamesSet.add (l_pageStyleName);
					}
					l_pageIsValid =  l_viewCursor.getAddress ().jumpToNextPage ();
				}
			}
			catch (NoSuchElementException | UnknownPropertyException | WrappedTargetException | PropertyVetoException l_exception) {
				// Supposed not to happen.
			}
			return true;
		}
	}
}

