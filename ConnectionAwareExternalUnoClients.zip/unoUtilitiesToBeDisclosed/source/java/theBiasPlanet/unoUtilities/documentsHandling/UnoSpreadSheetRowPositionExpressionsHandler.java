package theBiasPlanet.unoUtilities.documentsHandling;

import theBiasPlanet.unoUtilities.constantsGroups.*;

public class UnoSpreadSheetRowPositionExpressionsHandler {
	public static int getRowIndex (String a_rowPositionExpression) {
		return Integer.parseInt (a_rowPositionExpression) + UnoGeneralConstantsConstantsGroup.c_rowIndexToRowPositionExpressionDifference;
	}
	
	public static String getRowPositionExpression (int a_rowIndex) {
		return String.valueOf (a_rowIndex - UnoGeneralConstantsConstantsGroup.c_rowIndexToRowPositionExpressionDifference);
	}
}

