package theBiasPlanet.unoUtilities.documentsHandling;

import java.util.regex.Matcher;
import com.sun.star.beans.XPropertySet;
import com.sun.star.table.XCell2;
import com.sun.star.uno.XInterface;
import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.*;
import theBiasPlanet.unoUtilities.documentElements.UnoSpreadSheet;
import theBiasPlanet.unoUtilities.documentElements.UnoSpreadSheetCell;
import theBiasPlanet.unoUtilities.pointers.UnoObjectPointer;

public class UnoSpreadSheetCellPosition extends UnoSpreadSheetCellsRectangle {
	public UnoSpreadSheetCellPosition (UnoSpreadSheet a_spreadSheet, int a_rowIndex, int a_columnIndex) {
		super (a_spreadSheet, a_rowIndex, a_columnIndex, a_rowIndex, a_columnIndex);
	}
	
	public static UnoSpreadSheetCellPosition getCellPosition (UnoSpreadSheet a_spreadSheet, String a_cellPositionExpression) {
		String l_rowExpression = null;
		String l_columnExpression = null;
		Matcher l_matcher = UnoRegularExpressionsConstantsGroup.c_cellPositionExpressionRegularExpression.matcher (a_cellPositionExpression);
		if (l_matcher != null && l_matcher.lookingAt ()) {
			l_rowExpression = l_matcher.group (3);
			l_columnExpression  = l_matcher.group (2);
			return new UnoSpreadSheetCellPosition (a_spreadSheet, UnoSpreadSheetRowPositionExpressionsHandler.getRowIndex (l_rowExpression), UnoSpreadSheetColumnPositionExpressionsHandler.getColumnIndex (l_columnExpression));
		}
		else {
			return null;
		}
	}
	
	public static UnoSpreadSheetCellPosition getCellPosition (UnoSpreadSheet a_spreadSheet, UnoObjectPointer <? extends XInterface> a_cellOrSelection) {
		if (a_cellOrSelection == null) {
			return null;
		}
		else {
			if (a_cellOrSelection.getAddress (XCell2.class) == null) {
				return null;
			}
			try {
				String l_cellPositionExpression = (String) a_cellOrSelection.getAddress (XPropertySet.class).getPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_absoluteName);
				return getCellPosition (a_spreadSheet, l_cellPositionExpression);
			}
			catch (Exception l_exception) {
				// This will never happen.
				return null;
			}
		}
	}
	
	public static String getCellPositionExpression (int a_rowIndex, int a_columnIndex) {
		return String.format (UnoGeneralConstantsConstantsGroup.c_cellPositionExpressionFormat, UnoSpreadSheetColumnPositionExpressionsHandler.getColumnPositionExpression (a_columnIndex), UnoSpreadSheetRowPositionExpressionsHandler.getRowPositionExpression (a_rowIndex));
	}
	
	public static String getCellPositionExpression (UnoSpreadSheetCellPosition a_cellPosition) {
		return String.format (UnoGeneralConstantsConstantsGroup.c_cellPositionExpressionFormat, UnoSpreadSheetColumnPositionExpressionsHandler.getColumnPositionExpression (a_cellPosition.getColumnIndex ()), UnoSpreadSheetRowPositionExpressionsHandler.getRowPositionExpression (a_cellPosition.getRowIndex ()));
	}
	
	public static UnoSpreadSheetCellPosition getLeftmostTopCellPosition (UnoSpreadSheetCellPosition a_leftmostTopCellPositionCandidate1, UnoSpreadSheetCellPosition a_leftmostTopCellPositionCandidate2) {
		if (a_leftmostTopCellPositionCandidate1 == null) {
			if (a_leftmostTopCellPositionCandidate2 == null) {
				return null;
			}
			else {
				return a_leftmostTopCellPositionCandidate2;
			}
		}
		else {
			if (a_leftmostTopCellPositionCandidate2 == null) {
				return a_leftmostTopCellPositionCandidate1;
			}
		}
		if (a_leftmostTopCellPositionCandidate1.getColumnIndex () < a_leftmostTopCellPositionCandidate2.getColumnIndex ()) {
			return a_leftmostTopCellPositionCandidate1;
		}
		else if (a_leftmostTopCellPositionCandidate1.getColumnIndex () > a_leftmostTopCellPositionCandidate2.getColumnIndex ()) {
			return a_leftmostTopCellPositionCandidate2;
		}
		else {
			if (a_leftmostTopCellPositionCandidate1.getRowIndex () <= a_leftmostTopCellPositionCandidate2.getRowIndex ()) {
				return a_leftmostTopCellPositionCandidate1;
			}
			else {
				return a_leftmostTopCellPositionCandidate2;
			}
		}
	}
	
	public static UnoSpreadSheetCellPosition getRightmostBottomCellPosition (UnoSpreadSheetCellPosition a_rightmostBottomCellPositionCandidate1, UnoSpreadSheetCellPosition a_rightmostBottomCellPositionCandidate2) {
		if (a_rightmostBottomCellPositionCandidate1 == null) {
			if (a_rightmostBottomCellPositionCandidate2 == null) {
				return null;
			}
			else {
				return a_rightmostBottomCellPositionCandidate2;
			}
		}
		else {
			if (a_rightmostBottomCellPositionCandidate2 == null) {
				return a_rightmostBottomCellPositionCandidate1;
			}
		}
		if (a_rightmostBottomCellPositionCandidate1.getColumnIndex () > a_rightmostBottomCellPositionCandidate2.getColumnIndex ()) {
			return a_rightmostBottomCellPositionCandidate1;
		}
		else if (a_rightmostBottomCellPositionCandidate1.getColumnIndex () < a_rightmostBottomCellPositionCandidate2.getColumnIndex ()) {
			return a_rightmostBottomCellPositionCandidate2;
		}
		else {
			if (a_rightmostBottomCellPositionCandidate1.getRowIndex () >= a_rightmostBottomCellPositionCandidate2.getRowIndex ()) {
				return a_rightmostBottomCellPositionCandidate1;
			}
			else {
				return a_rightmostBottomCellPositionCandidate2;
			}
		}
	}
	
	public static UnoSpreadSheetCellPosition getTopLeftmostCellPosition (UnoSpreadSheetCellPosition a_topLeftmostCellPositionCandidate1, UnoSpreadSheetCellPosition a_topLeftmostCellPositionCandidate2) {
		if (a_topLeftmostCellPositionCandidate1 == null) {
			if (a_topLeftmostCellPositionCandidate2 == null) {
				return null;
			}
			else {
				return a_topLeftmostCellPositionCandidate2;
			}
		}
		else {
			if (a_topLeftmostCellPositionCandidate2 == null) {
				return a_topLeftmostCellPositionCandidate1;
			}
		}
		if (a_topLeftmostCellPositionCandidate1.getRowIndex () < a_topLeftmostCellPositionCandidate2.getRowIndex ()) {
			return a_topLeftmostCellPositionCandidate1;
		}
		else if (a_topLeftmostCellPositionCandidate1.getRowIndex () > a_topLeftmostCellPositionCandidate2.getRowIndex ()) {
			return a_topLeftmostCellPositionCandidate2;
		}
		else {
			if (a_topLeftmostCellPositionCandidate1.getColumnIndex () <= a_topLeftmostCellPositionCandidate2.getColumnIndex ()) {
				return a_topLeftmostCellPositionCandidate1;
			}
			else {
				return a_topLeftmostCellPositionCandidate2;
			}
		}
	}
	
	public static UnoSpreadSheetCellPosition getBottomRightmostCellPosition (UnoSpreadSheetCellPosition a_bottomRightmostCellPositionCandidate1, UnoSpreadSheetCellPosition a_bottomRightmostCellPositionCandidate2) {
		if (a_bottomRightmostCellPositionCandidate1 == null) {
			if (a_bottomRightmostCellPositionCandidate2 == null) {
				return null;
			}
			else {
				return a_bottomRightmostCellPositionCandidate2;
			}
		}
		else {
			if (a_bottomRightmostCellPositionCandidate2 == null) {
				return a_bottomRightmostCellPositionCandidate1;
			}
		}
		if (a_bottomRightmostCellPositionCandidate1.getRowIndex () > a_bottomRightmostCellPositionCandidate2.getRowIndex ()) {
			return a_bottomRightmostCellPositionCandidate1;
		}
		else if (a_bottomRightmostCellPositionCandidate1.getRowIndex () < a_bottomRightmostCellPositionCandidate2.getRowIndex ()) {
			return a_bottomRightmostCellPositionCandidate2;
		}
		else {
			if (a_bottomRightmostCellPositionCandidate1.getColumnIndex () >= a_bottomRightmostCellPositionCandidate2.getColumnIndex ()) {
				return a_bottomRightmostCellPositionCandidate1;
			}
			else {
				return a_bottomRightmostCellPositionCandidate2;
			}
		}
	}
	
	public UnoSpreadSheetCellPosition getVerticallyNextCellPosition () throws com.sun.star.lang.IndexOutOfBoundsException {
		UnoSpreadSheetCell l_cell = i_sheet.getCell (i_topRowIndex, i_leftmostColumnIndex);
		UnoSpreadSheetCell l_nextCell = l_cell.getDownCell ();
		return l_nextCell.getRepresentativeCellPosition ();
	}
	
	public UnoSpreadSheetCellPosition getVerticallyPreviousCellPosition () throws com.sun.star.lang.IndexOutOfBoundsException {
		UnoSpreadSheetCell l_cell = i_sheet.getCell (i_topRowIndex, i_leftmostColumnIndex);
		UnoSpreadSheetCell l_previousCell = l_cell.getUpperCell ();
		return l_previousCell.getRepresentativeCellPosition ();
	}
	
	public UnoSpreadSheetCellPosition getHorizontallyNextCellPosition () throws com.sun.star.lang.IndexOutOfBoundsException {
		UnoSpreadSheetCell l_cell = i_sheet.getCell (i_topRowIndex, i_leftmostColumnIndex);
		UnoSpreadSheetCell l_nextCell = l_cell.getRightCell ();
		return l_nextCell.getRepresentativeCellPosition ();
	}
	
	public UnoSpreadSheetCellPosition getHorizontallyPreviousCellPosition () throws com.sun.star.lang.IndexOutOfBoundsException {
		UnoSpreadSheetCell l_cell = i_sheet.getCell (i_topRowIndex, i_leftmostColumnIndex);
		UnoSpreadSheetCell l_previousCell = l_cell.getLeftCell ();
		return l_previousCell.getRepresentativeCellPosition ();
	}
	
	public int getRowIndex () {
		return i_topRowIndex;
	}
	
	public int getColumnIndex () {
		return i_leftmostColumnIndex;
	}
	
	@Override
	public boolean equals (Object a_objectToBeCompared) {
		if (!(a_objectToBeCompared instanceof UnoSpreadSheetCellPosition)) {
			return false;
		}
		UnoSpreadSheetCellPosition l_cellPositionToBeCompared = (UnoSpreadSheetCellPosition) a_objectToBeCompared;
		if (l_cellPositionToBeCompared.getRowIndex () == i_topRowIndex && l_cellPositionToBeCompared.getColumnIndex () == i_leftmostColumnIndex) {
			return true;
		}
		else {
			return false;
		}
	}
	
	@Override
	public String toString () {
		return String.format ("%d, %d", i_topRowIndex, i_leftmostColumnIndex);
	}
}

