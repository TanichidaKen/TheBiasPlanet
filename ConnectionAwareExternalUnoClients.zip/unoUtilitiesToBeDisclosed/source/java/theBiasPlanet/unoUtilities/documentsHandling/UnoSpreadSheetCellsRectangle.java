package theBiasPlanet.unoUtilities.documentsHandling;

import java.util.regex.Matcher;
import com.sun.star.beans.XPropertySet;
import com.sun.star.sheet.XSheetCellRange;
import com.sun.star.uno.XInterface;
import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.*;
import theBiasPlanet.unoUtilities.documentElements.UnoSpreadSheet;
import theBiasPlanet.unoUtilities.documentElements.UnoSpreadSheetCell;
import theBiasPlanet.unoUtilities.pointers.UnoObjectPointer;

public class UnoSpreadSheetCellsRectangle {
	protected UnoSpreadSheet i_sheet;
	protected int i_topRowIndex;
	protected int i_leftmostColumnIndex;
	protected int i_bottomRowIndex;
	protected int i_rightmostColumnIndex;
	
	public UnoSpreadSheetCellsRectangle (UnoSpreadSheet a_unoSpreadSheet, int a_topRowIndex, int a_leftmostColumnIndex, int a_bottomRowIndex, int a_rightmostColumnIndex) {
		i_sheet = a_unoSpreadSheet;
		i_topRowIndex = a_topRowIndex;
		i_leftmostColumnIndex = a_leftmostColumnIndex;
		i_bottomRowIndex = a_bottomRowIndex;
		i_rightmostColumnIndex = a_rightmostColumnIndex;
	}
	
	public static UnoSpreadSheetCellsRectangle getCellsRectangle (UnoSpreadSheet a_unoSpreadSheet, String a_cellsRectangleExpression) {
		String l_topRowExpression = null;
		String l_leftmostColumnExpression = null;
		String l_bottomRowExpression = null;
		String l_rightmostColumnExpression = null;
		Matcher l_matcher = UnoRegularExpressionsConstantsGroup.c_cellsRectangleExpressionRegularExpression.matcher (a_cellsRectangleExpression);
		if (l_matcher != null && l_matcher.lookingAt ()) {
			l_topRowExpression = l_matcher.group (3);
			l_leftmostColumnExpression = l_matcher.group (2);
			if (l_matcher.group (4) != null) {
				l_bottomRowExpression = l_matcher.group (6);
				l_rightmostColumnExpression = l_matcher.group (5);
			}
			else {
				l_bottomRowExpression = l_topRowExpression;
				l_rightmostColumnExpression = l_leftmostColumnExpression;
			}
			return new UnoSpreadSheetCellsRectangle (a_unoSpreadSheet, UnoSpreadSheetRowPositionExpressionsHandler.getRowIndex (l_topRowExpression), UnoSpreadSheetColumnPositionExpressionsHandler.getColumnIndex (l_leftmostColumnExpression), UnoSpreadSheetRowPositionExpressionsHandler.getRowIndex (l_bottomRowExpression), UnoSpreadSheetColumnPositionExpressionsHandler.getColumnIndex (l_rightmostColumnExpression));
		}
		else {
			return null;
		}
	}
	
	public static UnoSpreadSheetCellsRectangle getCellsRectangle (UnoSpreadSheet a_unoSpreadSheet, UnoObjectPointer <? extends XInterface> a_selection) {
		if (a_selection.getAddress (XSheetCellRange.class) == null) {
			return null;
		}
		else {
			try {
				String l_cellsRectangleExpression = (String) a_selection.getAddress (XPropertySet.class).getPropertyValue (UnoSpreadSheetCellsRangePropertyNamesSet.c_absoluteName);
				return getCellsRectangle (a_unoSpreadSheet, l_cellsRectangleExpression);
			}
			catch (Exception l_exception) {
				// This will never happen.
				return null;
			}
		}
	}
	
	public int getLeftmostColumnIndex () {
		return i_leftmostColumnIndex;
	}
	
	public int getTopRowIndex () {
		return i_topRowIndex;
	}
	
	public int getRightmostColumnIndex () {
		return i_rightmostColumnIndex;
	}
	
	public int getBottomRowIndex () {
		return i_bottomRowIndex;
	}
	
	public UnoSpreadSheetCellPosition getTopLeftmostCellPosition () {
		return new UnoSpreadSheetCellPosition (i_sheet, i_topRowIndex, i_leftmostColumnIndex);
	}
	
	public boolean contains (int a_rowIndex, int a_columnIndex) {
		if (a_rowIndex >= i_topRowIndex && a_rowIndex <= i_bottomRowIndex && a_columnIndex >= i_leftmostColumnIndex && a_columnIndex <= i_rightmostColumnIndex) {
			return true;
		}
		return false;
	}
	
	public boolean contains (UnoSpreadSheetCellPosition a_cellPosition) {
		return contains (a_cellPosition.getRowIndex (), a_cellPosition.getColumnIndex ());
	}
	
	public UnoSpreadSheetCellPosition getVerticallyNextMemberCellPosition (UnoSpreadSheetCellPosition a_originalCellPosition, boolean a_doesCyclic) {
		int l_originalCellRowIndex = a_originalCellPosition.getRowIndex ();
		int l_originalCellColumnIndex = a_originalCellPosition.getColumnIndex ();
		int l_nextMemberCellRowIndex = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		int l_nextMemberCellColumnIndex = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		if (l_originalCellColumnIndex < i_leftmostColumnIndex) {
			l_nextMemberCellRowIndex = i_topRowIndex;
			l_nextMemberCellColumnIndex = i_leftmostColumnIndex;
		}
		else if (l_originalCellColumnIndex > i_rightmostColumnIndex) {
			if (a_doesCyclic) {
				l_nextMemberCellRowIndex = i_topRowIndex;
				l_nextMemberCellColumnIndex = i_leftmostColumnIndex;
			}
			else {
				return null;
			}
		}
		else {
			int l_nextMemberCellRowIndexCandidate = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
			int l_nextMemberCellColumnIndexCandidate = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
			if (l_originalCellRowIndex < i_topRowIndex) {
				l_nextMemberCellRowIndexCandidate = i_topRowIndex;
				l_nextMemberCellColumnIndexCandidate = l_originalCellColumnIndex;
			}
			else if (l_originalCellRowIndex >= i_bottomRowIndex)  {
				l_nextMemberCellRowIndexCandidate = i_topRowIndex;
				l_nextMemberCellColumnIndexCandidate = l_originalCellColumnIndex + 1;
			}
			else {
				l_nextMemberCellRowIndexCandidate = l_originalCellRowIndex + 1;
				l_nextMemberCellColumnIndexCandidate = l_originalCellColumnIndex;
			}
			NEXT_MEMBER_CANDIDATES_LOOP:
			for (; l_nextMemberCellColumnIndexCandidate <= i_rightmostColumnIndex; l_nextMemberCellColumnIndexCandidate ++) {
				for (; l_nextMemberCellRowIndexCandidate <= i_bottomRowIndex; l_nextMemberCellRowIndexCandidate ++) {
					UnoSpreadSheetCell l_nextMemberCellCandidate = null;
					try {
						l_nextMemberCellCandidate = i_sheet.getCell (l_nextMemberCellRowIndexCandidate, l_nextMemberCellColumnIndexCandidate);
					}
					catch (com.sun.star.lang.IndexOutOfBoundsException l_exception) {
						// This will never happen, if this rectangle is valid.
						return null;
					}
					UnoSpreadSheetCellPosition l_nextMemberCellCandidatePosition = l_nextMemberCellCandidate.getRepresentativeCellPosition ();
					if (l_nextMemberCellCandidatePosition.getRowIndex () == l_nextMemberCellRowIndexCandidate && l_nextMemberCellCandidatePosition.getColumnIndex () == l_nextMemberCellColumnIndexCandidate) {
						l_nextMemberCellRowIndex = l_nextMemberCellRowIndexCandidate;
						l_nextMemberCellColumnIndex = l_nextMemberCellColumnIndexCandidate;
						break NEXT_MEMBER_CANDIDATES_LOOP;
					}
					
				}
				l_nextMemberCellRowIndexCandidate = i_topRowIndex;
			}
			if (l_nextMemberCellRowIndex == GeneralConstantsConstantsGroup.c_unspecifiedInteger || l_nextMemberCellColumnIndex == GeneralConstantsConstantsGroup.c_unspecifiedInteger) {
				if (a_doesCyclic) {
					l_nextMemberCellRowIndex = i_topRowIndex;
					l_nextMemberCellColumnIndex = i_leftmostColumnIndex;
				}
				else {
					return null;
				}
			}
		}
		return new UnoSpreadSheetCellPosition (i_sheet, l_nextMemberCellRowIndex, l_nextMemberCellColumnIndex);
		
		/*
				try {
					if (l_originalCellRowIndex >= i_bottomRowIndex) {
						l_nextMemberCellRowIndex = i_topRowIndex;
						if (l_originalCellColumnIndex < i_rightmostColumnIndex) {
							UnoSpreadSheetCell l_topRowOriginalColumnCell = i_sheet.getCell (i_topRowIndex, l_originalCellColumnIndex);
							UnoSpreadSheetCell l_topRowNextColumnOfOriginalColumnCell = l_topRowOriginalColumnCell.getRightCell ();
							int l_nextMemberCellColumnIndexCandidate = l_topRowNextColumnOfOriginalColumnCell.getRepresentativeColumnIndex ();
							if (l_nextMemberCellColumnIndexCandidate <= i_rightmostColumnIndex) {
								l_nextMemberCellColumnIndex = l_nextMemberCellColumnIndexCandidate;
							}
							else {
								if (a_doesCyclic) {
									l_nextMemberCellColumnIndex = i_leftmostColumnIndex;
								}
								else {
									return null;
								}
							}
						}
						else {
							if (a_doesCyclic) {
								l_nextMemberCellColumnIndex = i_leftmostColumnIndex;
							}
							else {
								return null;
							}
						}
					}
					else {
						UnoSpreadSheetCell l_originalCell = i_sheet.getCell (l_originalCellRowIndex, l_originalCellColumnIndex);
						UnoSpreadSheetCell l_nextCell = l_originalCell.getDownCell ();
						int l_nextMemberCellRowIndexCandidate = l_nextCell.getRepresentativeRowIndex ();
						if (l_nextMemberCellRowIndexCandidate <= i_bottomRowIndex) {
							l_nextMemberCellRowIndex = l_nextMemberCellRowIndexCandidate;
							l_nextMemberCellColumnIndex = l_originalCellColumnIndex;
						}
						else {
							l_nextMemberCellRowIndex = i_topRowIndex;
							UnoSpreadSheetCell l_topRowOriginalColumnCell = i_sheet.getCell (i_topRowIndex, l_originalCellColumnIndex);
							UnoSpreadSheetCell l_topRowNextColumnOfOriginalColumnCell = l_topRowOriginalColumnCell.getRightCell ();
							int l_nextMemberCellColumnIndexCandidate = l_topRowNextColumnOfOriginalColumnCell.getRepresentativeColumnIndex ();
							if (l_nextMemberCellColumnIndexCandidate <= i_rightmostColumnIndex) {
								l_nextMemberCellColumnIndex = l_nextMemberCellColumnIndexCandidate;
							}
							else {
								if (a_doesCyclic) {
									l_nextMemberCellColumnIndex = i_leftmostColumnIndex;
								}
								else {
									return null;
								}
							}
						}
					}
				}
				catch (com.sun.star.lang.IndexOutOfBoundsException l_exception) {
					// This will never happenas far as the UnoSpreadSheetCellsRectangle instance is legitimately constructed.
				}
			}
		}
		return new UnoSpreadSheetCellPosition (i_sheet, l_nextMemberCellRowIndex, l_nextMemberCellColumnIndex);
		*/
	}
	
	public UnoSpreadSheetCellPosition getVerticallyPreviousMemberCellPosition (UnoSpreadSheetCellPosition a_originalCellPosition, boolean a_doesCyclic) {
		int l_originalCellRowIndex = a_originalCellPosition.getRowIndex ();
		int l_originalCellColumnIndex = a_originalCellPosition.getColumnIndex ();
		int l_previousMemberCellRowIndex = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		int l_previousMemberCellColumnIndex = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		int l_previousMemberCellRowIndexCandidate = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		int l_previousMemberCellColumnIndexCandidate = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		if (l_originalCellColumnIndex > i_rightmostColumnIndex) {
			l_previousMemberCellRowIndexCandidate = i_bottomRowIndex;
			l_previousMemberCellColumnIndexCandidate = i_rightmostColumnIndex;
		}
		else if (l_originalCellColumnIndex < i_leftmostColumnIndex) {
			if (a_doesCyclic) {
				l_previousMemberCellRowIndexCandidate = i_bottomRowIndex;
				l_previousMemberCellColumnIndexCandidate = i_rightmostColumnIndex;
			}
			else {
				return null;
			}
		}
		else {
			if (l_originalCellRowIndex > i_bottomRowIndex) {
				l_previousMemberCellRowIndexCandidate = i_bottomRowIndex;
				l_previousMemberCellColumnIndexCandidate = l_originalCellColumnIndex;
			}
			else if (l_originalCellRowIndex <= i_topRowIndex)  {
				if (l_originalCellColumnIndex == i_leftmostColumnIndex && l_originalCellRowIndex == i_topRowIndex) {
					if (a_doesCyclic) {
						l_previousMemberCellRowIndexCandidate = i_bottomRowIndex;
						l_previousMemberCellColumnIndexCandidate = i_rightmostColumnIndex;
					}
					else {
						return null;
					}
				}
				else {
					l_previousMemberCellRowIndexCandidate = i_bottomRowIndex;
					l_previousMemberCellColumnIndexCandidate = l_originalCellColumnIndex - 1;
				}
			}
			else {
				l_previousMemberCellRowIndexCandidate = l_originalCellRowIndex - 1;
				l_previousMemberCellColumnIndexCandidate = l_originalCellColumnIndex;
			}
		}
		PREVIOUS_MEMBER_CANDIDATES_LOOP:
		for (; l_previousMemberCellColumnIndexCandidate >= i_leftmostColumnIndex; l_previousMemberCellColumnIndexCandidate --) {
			for (; l_previousMemberCellRowIndexCandidate >= i_topRowIndex; l_previousMemberCellRowIndexCandidate --) {
				UnoSpreadSheetCell l_previousMemberCellCandidate = null;
				try {
					l_previousMemberCellCandidate = i_sheet.getCell (l_previousMemberCellRowIndexCandidate, l_previousMemberCellColumnIndexCandidate);
				}
				catch (com.sun.star.lang.IndexOutOfBoundsException l_exception) {
					// This will never happen, if this rectangle is valid.
					return null;
				}
				UnoSpreadSheetCellPosition l_previousMemberCellCandidatePosition = l_previousMemberCellCandidate.getRepresentativeCellPosition ();
				if (l_previousMemberCellCandidatePosition.getRowIndex () == l_previousMemberCellRowIndexCandidate && l_previousMemberCellCandidatePosition.getColumnIndex () == l_previousMemberCellColumnIndexCandidate) {
					l_previousMemberCellRowIndex = l_previousMemberCellRowIndexCandidate;
					l_previousMemberCellColumnIndex = l_previousMemberCellColumnIndexCandidate;
					break PREVIOUS_MEMBER_CANDIDATES_LOOP;
				}
			}
			l_previousMemberCellRowIndexCandidate = i_bottomRowIndex;
		}
		if (l_previousMemberCellRowIndex == GeneralConstantsConstantsGroup.c_unspecifiedInteger || l_previousMemberCellColumnIndex == GeneralConstantsConstantsGroup.c_unspecifiedInteger) {
			return null;
		}
		return new UnoSpreadSheetCellPosition (i_sheet, l_previousMemberCellRowIndex, l_previousMemberCellColumnIndex);
		
		
		
		/*
		int l_cellRowIndex = a_cellPosition.getRowIndex ();
		int l_cellColumnIndex = a_cellPosition.getColumnIndex ();
		int l_previousCellRowIndex = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		int l_previousCellColumnIndex = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		if (l_cellColumnIndex < i_leftmostColumnIndex || l_cellColumnIndex > i_rightmostColumnIndex) {
			l_previousCellRowIndex = i_bottomRowIndex;
			l_previousCellColumnIndex = i_rightmostColumnIndex;
		}
		else {
			if (l_cellRowIndex > i_bottomRowIndex) {
				l_previousCellRowIndex = i_bottomRowIndex;
				l_previousCellColumnIndex = l_cellColumnIndex;
			}
			else {
				if (l_cellRowIndex <= i_topRowIndex) {
					l_previousCellRowIndex = i_bottomRowIndex;
					if (l_cellColumnIndex > i_leftmostColumnIndex) {
						l_previousCellColumnIndex = l_cellColumnIndex - 1;
					}
					else {
						l_previousCellColumnIndex = i_rightmostColumnIndex;
					}
				}
				else {
					l_previousCellRowIndex = l_cellRowIndex - 1;
					l_previousCellColumnIndex = l_cellColumnIndex;
				}
			}
		}
		return new UnoSpreadSheetCellPosition (i_sheet, l_previousCellRowIndex, l_previousCellColumnIndex);
		*/
	}
	
	public UnoSpreadSheetCellPosition getHolizontallyNextMemberCellPosition (UnoSpreadSheetCellPosition a_originalCellPosition, boolean a_doesCyclic) {
		int l_originalCellRowIndex = a_originalCellPosition.getRowIndex ();
		int l_originalCellColumnIndex = a_originalCellPosition.getColumnIndex ();
		int l_nextMemberCellRowIndex = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		int l_nextMemberCellColumnIndex = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		if (l_originalCellColumnIndex < i_leftmostColumnIndex) {
			l_nextMemberCellRowIndex = i_topRowIndex;
			l_nextMemberCellColumnIndex = i_leftmostColumnIndex;
		}
		else if (l_originalCellColumnIndex > i_rightmostColumnIndex) {
			if (a_doesCyclic) {
				l_nextMemberCellRowIndex = i_topRowIndex;
				l_nextMemberCellColumnIndex = i_leftmostColumnIndex;
			}
			else {
				return null;
			}
		}
		else {
			int l_nextMemberCellRowIndexCandidate = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
			int l_nextMemberCellColumnIndexCandidate = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
			if (l_originalCellRowIndex < i_topRowIndex) {
				l_nextMemberCellRowIndexCandidate = i_topRowIndex;
				l_nextMemberCellColumnIndexCandidate = l_originalCellColumnIndex;
			}
			else if (l_originalCellRowIndex >= i_bottomRowIndex)  {
				l_nextMemberCellRowIndexCandidate = i_topRowIndex;
				l_nextMemberCellColumnIndexCandidate = l_originalCellColumnIndex + 1;
			}
			else {
				l_nextMemberCellRowIndexCandidate = l_originalCellRowIndex + 1;
				l_nextMemberCellColumnIndexCandidate = l_originalCellColumnIndex;
			}
			NEXT_MEMBER_CANDIDATES_LOOP:
			for (; l_nextMemberCellColumnIndexCandidate <= i_rightmostColumnIndex; l_nextMemberCellColumnIndexCandidate ++) {
				for (; l_nextMemberCellRowIndexCandidate <= i_bottomRowIndex; l_nextMemberCellRowIndexCandidate ++) {
					UnoSpreadSheetCell l_nextMemberCellCandidate = null;
					try {
						l_nextMemberCellCandidate = i_sheet.getCell (l_nextMemberCellRowIndexCandidate, l_nextMemberCellColumnIndexCandidate);
					}
					catch (com.sun.star.lang.IndexOutOfBoundsException l_exception) {
						// This will never happen, if this rectangle is valid.
						return null;
					}
					UnoSpreadSheetCellPosition l_nextMemberCellCandidatePosition = l_nextMemberCellCandidate.getRepresentativeCellPosition ();
					if (l_nextMemberCellCandidatePosition.getRowIndex () == l_nextMemberCellRowIndexCandidate && l_nextMemberCellCandidatePosition.getColumnIndex () == l_nextMemberCellColumnIndexCandidate) {
						l_nextMemberCellRowIndex = l_nextMemberCellRowIndexCandidate;
						l_nextMemberCellColumnIndex = l_nextMemberCellColumnIndexCandidate;
						break NEXT_MEMBER_CANDIDATES_LOOP;
					}
					
				}
				l_nextMemberCellRowIndexCandidate = i_topRowIndex;
			}
			if (l_nextMemberCellRowIndex == GeneralConstantsConstantsGroup.c_unspecifiedInteger || l_nextMemberCellColumnIndex == GeneralConstantsConstantsGroup.c_unspecifiedInteger) {
				if (a_doesCyclic) {
					l_nextMemberCellRowIndex = i_topRowIndex;
					l_nextMemberCellColumnIndex = i_leftmostColumnIndex;
				}
				else {
					return null;
				}
			}
		}
		return new UnoSpreadSheetCellPosition (i_sheet, l_nextMemberCellRowIndex, l_nextMemberCellColumnIndex);
		
		/*
				try {
					if (l_originalCellRowIndex >= i_bottomRowIndex) {
						l_nextMemberCellRowIndex = i_topRowIndex;
						if (l_originalCellColumnIndex < i_rightmostColumnIndex) {
							UnoSpreadSheetCell l_topRowOriginalColumnCell = i_sheet.getCell (i_topRowIndex, l_originalCellColumnIndex);
							UnoSpreadSheetCell l_topRowNextColumnOfOriginalColumnCell = l_topRowOriginalColumnCell.getRightCell ();
							int l_nextMemberCellColumnIndexCandidate = l_topRowNextColumnOfOriginalColumnCell.getRepresentativeColumnIndex ();
							if (l_nextMemberCellColumnIndexCandidate <= i_rightmostColumnIndex) {
								l_nextMemberCellColumnIndex = l_nextMemberCellColumnIndexCandidate;
							}
							else {
								if (a_doesCyclic) {
									l_nextMemberCellColumnIndex = i_leftmostColumnIndex;
								}
								else {
									return null;
								}
							}
						}
						else {
							if (a_doesCyclic) {
								l_nextMemberCellColumnIndex = i_leftmostColumnIndex;
							}
							else {
								return null;
							}
						}
					}
					else {
						UnoSpreadSheetCell l_originalCell = i_sheet.getCell (l_originalCellRowIndex, l_originalCellColumnIndex);
						UnoSpreadSheetCell l_nextCell = l_originalCell.getDownCell ();
						int l_nextMemberCellRowIndexCandidate = l_nextCell.getRepresentativeRowIndex ();
						if (l_nextMemberCellRowIndexCandidate <= i_bottomRowIndex) {
							l_nextMemberCellRowIndex = l_nextMemberCellRowIndexCandidate;
							l_nextMemberCellColumnIndex = l_originalCellColumnIndex;
						}
						else {
							l_nextMemberCellRowIndex = i_topRowIndex;
							UnoSpreadSheetCell l_topRowOriginalColumnCell = i_sheet.getCell (i_topRowIndex, l_originalCellColumnIndex);
							UnoSpreadSheetCell l_topRowNextColumnOfOriginalColumnCell = l_topRowOriginalColumnCell.getRightCell ();
							int l_nextMemberCellColumnIndexCandidate = l_topRowNextColumnOfOriginalColumnCell.getRepresentativeColumnIndex ();
							if (l_nextMemberCellColumnIndexCandidate <= i_rightmostColumnIndex) {
								l_nextMemberCellColumnIndex = l_nextMemberCellColumnIndexCandidate;
							}
							else {
								if (a_doesCyclic) {
									l_nextMemberCellColumnIndex = i_leftmostColumnIndex;
								}
								else {
									return null;
								}
							}
						}
					}
				}
				catch (com.sun.star.lang.IndexOutOfBoundsException l_exception) {
					// This will never happenas far as the UnoSpreadSheetCellsRectangle instance is legitimately constructed.
				}
			}
		}
		return new UnoSpreadSheetCellPosition (i_sheet, l_nextMemberCellRowIndex, l_nextMemberCellColumnIndex);
		*/
	}
	
	public UnoSpreadSheetCellPosition getFirstCellPosition () {
		return new UnoSpreadSheetCellPosition (i_sheet, i_topRowIndex, i_leftmostColumnIndex);
	}
	
	public UnoSpreadSheetCellPosition getLastCellPosition () {
		try {
			UnoSpreadSheetCell l_lastCell = i_sheet.getCell (i_bottomRowIndex, i_rightmostColumnIndex);
			return l_lastCell.getRepresentativeCellPosition ();
		}
		catch (com.sun.star.lang.IndexOutOfBoundsException l_exception) {
			// This will never happen as far as the UnoSpreadSheetCellsRectangle instance is legitimately constructed.
			return null;
		}
	}
	@Override
	public boolean equals (Object a_objectToBeCompared) {
		if (!(a_objectToBeCompared instanceof UnoSpreadSheetCellsRectangle)) {
			return false;
		}
		else {
			UnoSpreadSheetCellsRectangle l_cellsRectangle = (UnoSpreadSheetCellsRectangle) a_objectToBeCompared;
			if (l_cellsRectangle.getTopRowIndex () == i_topRowIndex && l_cellsRectangle.getLeftmostColumnIndex () == i_leftmostColumnIndex && l_cellsRectangle.getBottomRowIndex () == i_bottomRowIndex && l_cellsRectangle.getRightmostColumnIndex () == i_rightmostColumnIndex) {
				return true;
			}
			else {
				return false;
			}
		}
	}
	
	@Override
	public String toString () {
		return String.format ("%d, %d, %d, %d", i_topRowIndex, i_leftmostColumnIndex, i_bottomRowIndex, i_rightmostColumnIndex);
	}
}

