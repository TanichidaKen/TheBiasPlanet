package theBiasPlanet.unoUtilities.documentsHandling;

import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.constantsGroups.*;

public class UnoSpreadSheetColumnPositionExpressionsHandler {
	public static int getColumnIndex (String a_columnPositionExpression) {
		int l_columnIndex = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		int l_columnPositionExpressionLength = a_columnPositionExpression.length ();
		for (int l_characterIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber; l_characterIndex < l_columnPositionExpressionLength; l_characterIndex ++) {
			l_columnIndex = (l_columnIndex - UnoGeneralConstantsConstantsGroup.c_rowIndexToRowPositionExpressionDifference) * GeneralConstantsConstantsGroup.c_numberOfAlphabets + GeneralConstantsConstantsGroup.c_alphabetToAlphabetIndexMap.get (a_columnPositionExpression.charAt (l_characterIndex)).intValue ();
		}
		return l_columnIndex;
	}
	
	public static String getColumnPositionExpression (int a_columnIndex) {
		StringBuilder l_columnPositionExpresionInReverse = new StringBuilder ();
		int l_unprocessedColumnAlpabetsCycleIndex = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		int l_unprocessedColumnAlpabetsCycleIndexSaved = a_columnIndex;
		while (true) {
			l_unprocessedColumnAlpabetsCycleIndex = l_unprocessedColumnAlpabetsCycleIndexSaved / GeneralConstantsConstantsGroup.c_numberOfAlphabets + UnoGeneralConstantsConstantsGroup.c_rowIndexToRowPositionExpressionDifference;
			int l_columnInsideAlpabetsCycleIndex = l_unprocessedColumnAlpabetsCycleIndexSaved - (l_unprocessedColumnAlpabetsCycleIndex - UnoGeneralConstantsConstantsGroup.c_rowIndexToRowPositionExpressionDifference) * GeneralConstantsConstantsGroup.c_numberOfAlphabets;
			l_columnPositionExpresionInReverse.append (GeneralConstantsConstantsGroup.c_alphabetIndexToAlphabetMap.get (l_columnInsideAlpabetsCycleIndex));
			if (l_unprocessedColumnAlpabetsCycleIndex < GeneralConstantsConstantsGroup.c_iterationStartNumber) {
				break;
			}
			l_unprocessedColumnAlpabetsCycleIndexSaved = l_unprocessedColumnAlpabetsCycleIndex;
		}
		return l_columnPositionExpresionInReverse.reverse ().toString ();
	}
}

