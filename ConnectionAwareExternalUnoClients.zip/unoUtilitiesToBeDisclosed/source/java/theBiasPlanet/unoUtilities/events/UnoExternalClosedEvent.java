package theBiasPlanet.unoUtilities.events;

import theBiasPlanet.unoDatumTypes.unoExternalEventsHandling.events.XExternalClosedEvent;

public class UnoExternalClosedEvent extends UnoExternalEvent implements XExternalClosedEvent {
	public UnoExternalClosedEvent (String a_eventTypeString, String a_eventSourceIdentification, String a_propertiesString) {
		super (a_eventTypeString, a_eventSourceIdentification, a_propertiesString);
	}
}

