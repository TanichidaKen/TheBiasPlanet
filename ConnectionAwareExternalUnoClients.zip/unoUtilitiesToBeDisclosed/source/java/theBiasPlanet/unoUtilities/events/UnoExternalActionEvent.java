package theBiasPlanet.unoUtilities.events;

import theBiasPlanet.unoDatumTypes.unoExternalEventsHandling.events.XExternalActionEvent;

public class UnoExternalActionEvent extends UnoExternalEvent implements XExternalActionEvent {
	protected String i_commandString;
	protected int i_modificationCode;
	
	public UnoExternalActionEvent (String a_eventTypeString, String a_eventSourceIdentification, String a_propertiesString, String a_commandString, int a_modificationCode) {
		super (a_eventTypeString, a_eventSourceIdentification, a_propertiesString);
		i_commandString = a_commandString;
		i_modificationCode = a_modificationCode;
	}
	
	@Override
	public String getCommandString () {
		return i_commandString;
	}
	
	@Override
	public int getModificationCode () {
		return i_modificationCode;
	}
}

