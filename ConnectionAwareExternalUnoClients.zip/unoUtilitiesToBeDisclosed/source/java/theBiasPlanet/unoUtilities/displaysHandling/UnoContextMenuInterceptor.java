package theBiasPlanet.unoUtilities.displaysHandling;

import java.util.List;
import com.sun.star.awt.Point;
import com.sun.star.awt.XWindow;
import com.sun.star.beans.XPropertySet;
import com.sun.star.beans.UnknownPropertyException;
import com.sun.star.container.XIndexContainer;
import com.sun.star.lang.XMultiServiceFactory;
import com.sun.star.lang.IndexOutOfBoundsException;
import com.sun.star.ui.XContextMenuInterceptor;
import com.sun.star.ui.ContextMenuInterceptorAction;
import com.sun.star.ui.ContextMenuExecuteEvent;
import com.sun.star.ui.ActionTriggerSeparatorType;
import com.sun.star.uno.XInterface;
import com.sun.star.view.XSelectionSupplier;
import theBiasPlanet.coreUtilities.messagingHandling.Publisher;
import theBiasPlanet.unoUtilities.pointers.UnoObjectPointer;
import theBiasPlanet.unoUtilities.unoComponentBases.UnoComponentBase;

public class UnoContextMenuInterceptor extends UnoComponentBase implements XContextMenuInterceptor {
	private List <UnoContextMenuItemConfiguration> i_contextMenuItemConfigurations;
	private boolean i_callsNextMenuInterceptor = true;
	
	public UnoContextMenuInterceptor (List <UnoContextMenuItemConfiguration> a_contextMenuItemConfigurations, boolean a_callsNextMenuInterceptor) {
		i_contextMenuItemConfigurations = a_contextMenuItemConfigurations;
		i_callsNextMenuInterceptor = a_callsNextMenuInterceptor;
	}
	
	@Override
	public ContextMenuInterceptorAction notifyContextMenuExecute (ContextMenuExecuteEvent a_contextMenuExecuteEvent) throws RuntimeException {
		try {
			UnoObjectPointer <XIndexContainer> l_contextMenuContainer = new UnoObjectPointer <XIndexContainer> (a_contextMenuExecuteEvent.ActionTriggerContainer);
			Point l_contextMenuExecutionPosition = a_contextMenuExecuteEvent.ExecutePosition;
			UnoObjectPointer <XWindow> l_sourceWindow = new UnoObjectPointer <XWindow> (a_contextMenuExecuteEvent.SourceWindow);
			UnoObjectPointer <XSelectionSupplier> l_contentSelectionSupplier = new UnoObjectPointer <XSelectionSupplier> (a_contextMenuExecuteEvent.Selection);
			//XMultiServiceFactory l_contextMenuItemsServicesManager = (XMultiServiceFactory) UnoRuntime.queryInterface (XMultiServiceFactory.class, l_contextMenuContainer);
			if (l_contextMenuContainer.getAddress (XMultiServiceFactory.class) != null) {
				for (int l_contextMenuItemConfigurationIndex = 0; l_contextMenuItemConfigurationIndex < i_contextMenuItemConfigurations.size (); l_contextMenuItemConfigurationIndex ++) {
					createContextMenuItemPropertiesSet (l_contextMenuContainer, l_contextMenuExecutionPosition, l_sourceWindow, l_contentSelectionSupplier.getAddress ().getSelection (), i_contextMenuItemConfigurations.get (l_contextMenuItemConfigurationIndex));
				}
				if (i_callsNextMenuInterceptor) {
					return ContextMenuInterceptorAction.CONTINUE_MODIFIED;
				}
				else {
					return ContextMenuInterceptorAction.EXECUTE_MODIFIED;
				}
			}
		}
		catch (UnknownPropertyException l_unknownPropertyException) {
			Publisher.show (l_unknownPropertyException.toString ());
		}
		catch (IndexOutOfBoundsException l_indexOutOfBoundsException) {
			Publisher.show (l_indexOutOfBoundsException.toString ());
		}
		catch (com.sun.star.uno.Exception l_exception) {
			Publisher.show (l_exception.toString ());
		}
		return ContextMenuInterceptorAction.IGNORED;
	}
	
	private UnoObjectPointer <XPropertySet> createContextMenuItemPropertiesSet (UnoObjectPointer <XIndexContainer> a_contextMenuItemsContainer, Point a_contextMenuExecutionPosition, UnoObjectPointer <XWindow> a_sourceWindow, Object a_contentSelection, UnoContextMenuItemConfiguration a_contextMenuItemConfiguration) throws com.sun.star.uno.Exception {
		String l_contextMenuItemType = a_contextMenuItemConfiguration.getType ();
		UnoObjectPointer <XPropertySet> l_contextMenuItemPropertiesSet =new UnoObjectPointer <XPropertySet> ( (XInterface) a_contextMenuItemsContainer.getAddress (XMultiServiceFactory.class).createInstance (l_contextMenuItemType), XPropertySet.class);
		if (l_contextMenuItemType.equals ("com.sun.star.ui.ActionTriggerSeparator")) {
			l_contextMenuItemPropertiesSet.getAddress ().setPropertyValue ("SeparatorType",  Short.valueOf (ActionTriggerSeparatorType.LINE));
		}
		if (l_contextMenuItemType.equals ("com.sun.star.ui.ActionTrigger")) {
			l_contextMenuItemPropertiesSet.getAddress ().setPropertyValue ("Text", a_contextMenuItemConfiguration.getCaption ());
			StringBuilder l_commandUrlStringBuilder = new StringBuilder ();
			l_commandUrlStringBuilder.append (a_contextMenuItemConfiguration.getCommandUrl ());
			if (a_contentSelection != null) {
				l_commandUrlStringBuilder.append (String.format ("?positionX=%d&positionY=%d&sourceWindow=%s&selection=%s", a_contextMenuExecutionPosition.X, a_contextMenuExecutionPosition.Y, a_sourceWindow, a_contentSelection));
			}
			l_contextMenuItemPropertiesSet.getAddress ().setPropertyValue ("CommandURL", l_commandUrlStringBuilder.toString ());
			List <UnoContextMenuItemConfiguration> l_subItemConfigurations = a_contextMenuItemConfiguration.getSubItemConfigurations ();
			if (l_subItemConfigurations != null) {
				UnoObjectPointer <XIndexContainer> l_subItemsContainer = new UnoObjectPointer <XIndexContainer> ( (XInterface) a_contextMenuItemsContainer.getAddress (XMultiServiceFactory.class).createInstance ("com.sun.star.ui.ActionTriggerContainer"), XIndexContainer.class);
				l_contextMenuItemPropertiesSet.getAddress ().setPropertyValue ("SubContainer", l_subItemsContainer);
				for (int l_subItemConfigurationIndex = 0; l_subItemConfigurationIndex < l_subItemConfigurations.size (); l_subItemConfigurationIndex ++) {
					createContextMenuItemPropertiesSet (l_subItemsContainer, a_contextMenuExecutionPosition, a_sourceWindow, a_contentSelection, l_subItemConfigurations.get (l_subItemConfigurationIndex));
				}
			}
		}
		a_contextMenuItemsContainer.getAddress ().insertByIndex (a_contextMenuItemsContainer.getAddress ().getCount (), l_contextMenuItemPropertiesSet);
		return l_contextMenuItemPropertiesSet;
	}
}

