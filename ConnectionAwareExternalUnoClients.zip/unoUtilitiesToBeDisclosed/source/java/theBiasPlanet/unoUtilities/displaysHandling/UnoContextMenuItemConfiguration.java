package theBiasPlanet.unoUtilities.displaysHandling;

import java.util.ArrayList;

public class UnoContextMenuItemConfiguration {
	// "com.sun.star.ui.ActionTrigger" or "com.sun.star.ui.ActionTriggerSeparator"
	private String i_type = null;
	private String i_caption = null;
	private String i_commandUrl = null;
	private ArrayList <UnoContextMenuItemConfiguration> i_subItemConfigurations;
	
	public UnoContextMenuItemConfiguration (String a_type, String a_caption, String a_commandUrl, ArrayList <UnoContextMenuItemConfiguration> a_subItemConfigurations) {
		i_type = a_type;
		i_caption = a_caption;
		i_commandUrl = a_commandUrl;
		i_subItemConfigurations = a_subItemConfigurations;
	}
	
	public String getType () {
		return i_type;
	}
	
	public String getCaption () {
		return i_caption;
	}
	
	// Cut -> slot:5710
	// Copy -> slot:5711
	// Paste -> slot:5712
	public String getCommandUrl () {
		return i_commandUrl;
	}
	
	public ArrayList <UnoContextMenuItemConfiguration> getSubItemConfigurations () {
		return i_subItemConfigurations;
	}
}

