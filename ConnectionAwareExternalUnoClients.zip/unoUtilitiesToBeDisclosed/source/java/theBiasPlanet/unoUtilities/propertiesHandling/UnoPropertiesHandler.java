package theBiasPlanet.unoUtilities.propertiesHandling;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import com.sun.star.beans.PropertyValue;
import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.property.UnoProperty;

public class UnoPropertiesHandler {
	public static PropertyValue [] buildPropertiesArray (List <String> a_propertyNames, List <Object> a_propertyValues) {
		if (a_propertyNames == null || a_propertyValues == null) {
			return null;
		}
		else {
			ArrayList <String> l_propertyNames = new ArrayList <String> ();
			ArrayList <Object> l_propertyValues = new ArrayList <Object> ();
			Iterator <Object> l_propertyValuesIterator = a_propertyValues.iterator ();
			Object l_propertyValue = null;
			for (String l_propertyName: a_propertyNames) {
				l_propertyValue = l_propertyValuesIterator.next ();
				if (l_propertyValue != null) {
					if (! (l_propertyValue instanceof String && ( (String) l_propertyValue).equals (""))) {
						l_propertyNames.add (l_propertyName);
						l_propertyValues.add (l_propertyValue);
					}
				}
			}
			PropertyValue [] l_propertiesArray = new PropertyValue [l_propertyNames.size ()];
			l_propertyValuesIterator = l_propertyValues.iterator ();
			int l_propertyIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
			for (String l_propertyName: l_propertyNames) {
				if (! (l_propertyName.startsWith ("#"))) {
					l_propertiesArray [l_propertyIndex] = new UnoProperty (l_propertyName, l_propertyValuesIterator.next ());
				}
				else {
					l_propertiesArray [l_propertyIndex] = new UnoProperty ("", l_propertyValuesIterator.next (), Integer.parseInt (l_propertyName.substring (1)));
				}
				l_propertyIndex ++;
			}
			return l_propertiesArray;
		}
	}
}

