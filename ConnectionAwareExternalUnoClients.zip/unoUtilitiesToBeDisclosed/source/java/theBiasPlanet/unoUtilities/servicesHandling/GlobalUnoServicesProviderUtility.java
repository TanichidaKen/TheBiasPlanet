package theBiasPlanet.unoUtilities.servicesHandling;

import java.util.Map;
import java.util.Set;
import com.sun.star.lang.XSingleComponentFactory;
import com.sun.star.registry.XRegistryKey;
import com.sun.star.lib.uno.helper.Factory;
import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.coreUtilities.collectionsHandling.MapHandler;
import theBiasPlanet.coreUtilities.collectionsHandling.ArraysFactory;

public class GlobalUnoServicesProviderUtility {
	public static XSingleComponentFactory getUnoServiceInstancesFactory (Map <String, Map <Class <?>, Set <String>>> a_unoComponentClassNameToUnoComponentClassToUnoServiceNamesMapMap, String a_unoComponentClassName) {
		XSingleComponentFactory l_globalUnoServiceInstancesFactory = null;
		Map <Class <?>, Set <String>> l_unoComponentClassToUnoServiceNamesMap = a_unoComponentClassNameToUnoComponentClassToUnoServiceNamesMapMap.get (a_unoComponentClassName);
		if (l_unoComponentClassToUnoServiceNamesMap != null) {
			@SuppressWarnings (WarningNamesConstantsGroup.c_notChecked)
			Map.Entry <Class <?>, Set <String>> l_unoComponentClassToUnoServiceNamesMapEntry = MapHandler. <Class <?>, Set <String>>getFirstEntry (l_unoComponentClassToUnoServiceNamesMap);
			Set <String> l_serviceNames =  l_unoComponentClassToUnoServiceNamesMapEntry.getValue ();
			l_globalUnoServiceInstancesFactory = Factory.createComponentFactory (l_unoComponentClassToUnoServiceNamesMapEntry.getKey (), ArraysFactory. <String>createArray (String.class, l_serviceNames));
		}
		return l_globalUnoServiceInstancesFactory;
	}
	
	public static boolean writeGlobalUnoServicesInformationToRegistry (Map <String, Map <Class <?>, Set <String>>> a_unoComponentClassNameToUnoComponentClassToUnoServiceNamesMapMap, XRegistryKey a_registryKeyInXRegistryKey) {
		boolean l_returnStatus = false;
		for (Map.Entry <String,  Map <Class <?>, Set <String>>> l_unoComponentClassNameToUnoComponentClassToUnoServiceNamesMapMapEntry: a_unoComponentClassNameToUnoComponentClassToUnoServiceNamesMapMap.entrySet ()) {
			@SuppressWarnings (WarningNamesConstantsGroup.c_notChecked)
			Map.Entry <Class <?>, Set <String>> l_unoComponentClassToUnoServiceNamesMapEntry = MapHandler. <Class <?>, Set <String>>getFirstEntry (l_unoComponentClassNameToUnoComponentClassToUnoServiceNamesMapMapEntry.getValue ());
			Set <String> l_serviceNames = l_unoComponentClassToUnoServiceNamesMapEntry.getValue ();
			l_returnStatus = Factory.writeRegistryServiceInfo (l_unoComponentClassNameToUnoComponentClassToUnoServiceNamesMapMapEntry.getKey (), ArraysFactory. <String>createArray (String.class, l_serviceNames), a_registryKeyInXRegistryKey);
			if (!l_returnStatus) {
				break;
			}
		}
		return l_returnStatus;
	}
}

