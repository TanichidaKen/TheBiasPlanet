package theBiasPlanet.unoUtilities.connection;

import java.util.List;
import java.util.Map;
import com.sun.star.bridge.XBridge;
import com.sun.star.bridge.XInstanceProvider;
import com.sun.star.frame.TerminationVetoException;
import com.sun.star.frame.XDesktop2;
import com.sun.star.frame.XTerminateListener;
import com.sun.star.lang.EventObject;
import com.sun.star.lang.XComponent;
import com.sun.star.lang.XEventListener;
import com.sun.star.uno.XComponentContext;
import com.sun.star.uno.XInterface;
import theBiasPlanet.coreUtilities.messagingHandling.Publisher;
import theBiasPlanet.unoUtilities.constantsGroups.UnoDefaultValuesConstantsGroup;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.UnoObjectsContextPropertyNamesSet;
import theBiasPlanet.unoUtilities.displayElements.UnoDesktop;
import theBiasPlanet.unoUtilities.pointers.UnoObjectPointer;
import theBiasPlanet.unoUtilities.unoComponentBases.UnoComponentBase;
import theBiasPlanet.unoUtilities.unoObjectsContexts.LocalUnoObjectsContext;
import theBiasPlanet.unoUtilities.unoObjectsContexts.RemoteUnoObjectsContext;

public class UnoConnection extends UnoComponentBase implements XEventListener {
	public static class InitialUnoObjectsProvider extends UnoComponentBase implements XInstanceProvider {
		private LocalUnoObjectsContext i_localUnoObjectsContext = null;
		
		public InitialUnoObjectsProvider (LocalUnoObjectsContext a_localUnoObjectsContext) {
			i_localUnoObjectsContext = a_localUnoObjectsContext;
		}
		
		@Override
		protected void finalize () {
		}
		
		@Override
		public XInterface getInstance (String a_initialUnoObjectName) {
			if (UnoDefaultValuesConstantsGroup.c_initiallyOfferedUnoObjectName.equals (a_initialUnoObjectName)) {
				return i_localUnoObjectsContext;
			}
			else {
				return null;
			}
		}
	}
	public static interface UnoConnectionEventsListener {
		public void connected (UnoConnection a_unoConnection);
		
		public void disconnected (UnoConnection a_unoConnection);
	}
	public static class OfficeTerminationQueryListener extends UnoComponentBase implements XTerminateListener {
		private UnoConnection i_unoConnection;
		private boolean i_vetoesOfficeTermination;
		
		public OfficeTerminationQueryListener (UnoConnection a_unoConnection, boolean a_vetoesOfficeTermination) {
			i_unoConnection = a_unoConnection;
			i_vetoesOfficeTermination = a_vetoesOfficeTermination;
		}
		
		@Override
		public void queryTermination (com.sun.star.lang.EventObject a_event) throws TerminationVetoException {
			Publisher.logNormalInformation ("### The termination of the office instance is queried.");
			if (i_vetoesOfficeTermination) {
				throw new TerminationVetoException ();
			}
			else {
				i_unoConnection.disconnect ();
			}
		}
		
		@Override
		public void notifyTermination (com.sun.star.lang.EventObject a_event) {
			Publisher.logNormalInformation ("### The termination of the office instance is notified.");
		}
		
		@Override
		public void disposing (com.sun.star.lang.EventObject a_event) {
		}
	}
	private RemoteUnoObjectsContext i_remoteUnoObjectsContext;
	private XComponent i_unoBridge;
	private	InitialUnoObjectsProvider i_initialUnoObjectsProvider;
	private List <UnoConnectionEventsListener> i_eventsListeners;
	private OfficeTerminationQueryListener i_officeTerminationQueryListener;
	
	public UnoConnection (UnoObjectPointer <XComponentContext> a_originalRemoteUnoObjectsContext, Map <String, Object> a_unoObjectsContextExtraNameToValueMap, XBridge a_unoBridge, InitialUnoObjectsProvider a_initialUnoObjectsProvider, List <UnoConnectionEventsListener> a_eventsListeners, boolean a_vetoesOfficeTermination) throws Exception {
		i_remoteUnoObjectsContext = new RemoteUnoObjectsContext (a_originalRemoteUnoObjectsContext, a_unoObjectsContextExtraNameToValueMap);
		i_unoBridge = (XComponent) a_unoBridge;
		i_initialUnoObjectsProvider = a_initialUnoObjectsProvider;
		i_eventsListeners = a_eventsListeners;
		i_unoBridge.addEventListener (this);
		if (i_eventsListeners != null) {
			for (UnoConnectionEventsListener l_eventsListener: i_eventsListeners){
				l_eventsListener.connected (this);
			}
		}
		// add singletons Start
		try {
			UnoDesktop l_unoDesktop = UnoDesktop.getInstance (i_remoteUnoObjectsContext);
			a_unoObjectsContextExtraNameToValueMap.put (UnoObjectsContextPropertyNamesSet.c_unoDesktopSingleton_string, l_unoDesktop);
		}
		catch (Exception l_exception) {
			// the remote UNO environment may not be any Office instance, and it is OK.
		}
		// add singletons End
		UnoDesktop l_unoDesktop = (UnoDesktop) (i_remoteUnoObjectsContext.getValueByName (UnoObjectsContextPropertyNamesSet.c_unoDesktopSingleton_string));
		if (l_unoDesktop != null) {
			i_officeTerminationQueryListener = new OfficeTerminationQueryListener (this, a_vetoesOfficeTermination);
			l_unoDesktop.getUnderlyingUnoObject (). <XDesktop2>getAddress (XDesktop2.class).addTerminateListener (i_officeTerminationQueryListener);
		}
		else {
			i_officeTerminationQueryListener = null;
		}
	}
	
	@Override
	protected void finalize () {
	}
	
	public final RemoteUnoObjectsContext getRemoteUnoObjectsContext () {
		return i_remoteUnoObjectsContext;
	}
	
	public final void disconnect () {
		if (i_unoBridge != null) {
			try {
				if (i_officeTerminationQueryListener != null) {
					UnoDesktop l_unoDesktop = (UnoDesktop) (i_remoteUnoObjectsContext.getValueByName (UnoObjectsContextPropertyNamesSet.c_unoDesktopSingleton_string));
					l_unoDesktop.getUnderlyingUnoObject (). <XDesktop2>getAddress (XDesktop2.class).removeTerminateListener (i_officeTerminationQueryListener);
				}
				i_unoBridge.dispose ();
			}
			catch (Exception l_exception) {
				Publisher.logErrorInformation (String.format ("### UnoConnection.disconnect error: %s.", l_exception.toString ()));
			}
		}
	}
	
	@Override
	public final void disposing (EventObject a_event) {
		Publisher.logNormalInformation (a_event.Source.toString ());
		if (i_eventsListeners != null) {
			for (UnoConnectionEventsListener l_eventsListener: i_eventsListeners) {
				l_eventsListener.disconnected (this);
			}
		}
		i_remoteUnoObjectsContext = null;
		i_unoBridge = null;
		i_initialUnoObjectsProvider = null;
		i_eventsListeners = null;
	}
}

