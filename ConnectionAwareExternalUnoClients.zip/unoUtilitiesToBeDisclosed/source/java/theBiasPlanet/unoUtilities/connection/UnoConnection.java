package theBiasPlanet.unoUtilities.connection;

import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;
import com.sun.star.bridge.XBridge;
import com.sun.star.bridge.XInstanceProvider;
import com.sun.star.frame.TerminationVetoException;
import com.sun.star.frame.XDesktop;
import com.sun.star.frame.XTerminateListener;
import com.sun.star.lang.EventObject;
import com.sun.star.lang.XComponent;
import com.sun.star.lang.XEventListener;
import com.sun.star.uno.XComponentContext;
import com.sun.star.uno.XInterface;
import theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup;
import theBiasPlanet.coreUtilities.messagingHandling.Publisher;
import theBiasPlanet.unoUtilities.constantsGroups.UnoDefaultValuesConstantsGroup;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.UnoObjectsContextPropertyNamesSet;
import theBiasPlanet.unoUtilities.displayElements.UnoDesktop;
import theBiasPlanet.unoUtilities.pointers.UnoObjectPointer;
import theBiasPlanet.unoUtilities.unoComponentBases.UnoComponentBase;
import theBiasPlanet.unoUtilities.unoObjectsContexts.LocalUnoObjectsContext;
import theBiasPlanet.unoUtilities.unoObjectsContexts.RemoteUnoObjectsContext;

public class UnoConnection extends UnoComponentBase implements XEventListener {
	public static class InitialUnoObjectsProvider extends UnoComponentBase implements XInstanceProvider {
		private LocalUnoObjectsContext i_localUnoObjectsContext = null;
		
		public InitialUnoObjectsProvider (LocalUnoObjectsContext a_localUnoObjectsContext) {
			i_localUnoObjectsContext = a_localUnoObjectsContext;
		}
		
		@Override
		protected void finalize () {
		}
		
		@Override
		public XInterface getInstance (String a_initialUnoObjectName) {
			if (UnoDefaultValuesConstantsGroup.c_initiallyOfferedUnoObjectName.equals (a_initialUnoObjectName)) {
				return i_localUnoObjectsContext;
			}
			else {
				return null;
			}
		}
	}
	public static interface UnoConnectionEventsListener {
		public void connected (UnoConnection a_unoConnection);
		
		public void disconnected (UnoConnection a_unoConnection);
	}
	public static class OfficeTerminationQueryListener extends UnoComponentBase implements XTerminateListener {
		private UnoConnection i_unoConnection;
		
		public OfficeTerminationQueryListener (UnoConnection a_unoConnection) {
			i_unoConnection = a_unoConnection;
		}
		
		@Override
		public void queryTermination (com.sun.star.lang.EventObject a_event) throws TerminationVetoException {
			Publisher.logNormalInformation ("### The termination of the office instance is queried.");
			try {
				i_unoConnection.lock ();
				if (! (i_unoConnection.serverIsPlannedToBeTerminated ()) || i_unoConnection.getCriticalSessionCount () > 0) {
					Publisher.logNormalInformation ("### And vetoed.");
					throw new TerminationVetoException ();
				}
				else {
					Publisher.logNormalInformation ("### And accepted.");
				}
			}
			finally {
				i_unoConnection.unlock ();
			}
		}
		
		@Override
		public void notifyTermination (com.sun.star.lang.EventObject a_event) {
			Publisher.logNormalInformation ("### The termination of the office instance is notified.");
			i_unoConnection.disconnect ();
		}
		
		@Override
		public void disposing (com.sun.star.lang.EventObject a_event) {
		}
	}
	private RemoteUnoObjectsContext i_remoteUnoObjectsContext;
	private XComponent i_unoBridge;
	private	InitialUnoObjectsProvider i_initialUnoObjectsProvider;
	private List <UnoConnectionEventsListener> i_eventsListeners;
	private OfficeTerminationQueryListener i_officeTerminationQueryListener;
	private ReentrantLock i_threadsLock;
	private Condition i_threadsCondition;
	private int i_criticalSessionCount;
	private boolean i_serverIsPlannedToBeTerminated;
	
	@Override
	public final void disposing (EventObject a_event) {
		if (i_eventsListeners != null) {
			for (UnoConnectionEventsListener l_eventsListener: i_eventsListeners) {
				l_eventsListener.disconnected (this);
			}
		}
		i_remoteUnoObjectsContext = null;
		i_unoBridge = null;
		i_initialUnoObjectsProvider = null;
		i_eventsListeners = null;
		i_officeTerminationQueryListener = null;
	}
	
	public UnoConnection (UnoObjectPointer <XComponentContext> a_originalRemoteUnoObjectsContext, String a_unoConnectionIdentification, XBridge a_unoBridge, InitialUnoObjectsProvider a_initialUnoObjectsProvider, List <UnoConnectionEventsListener> a_eventsListeners) throws Exception {
		i_remoteUnoObjectsContext = new RemoteUnoObjectsContext (a_originalRemoteUnoObjectsContext, a_unoConnectionIdentification);
		i_unoBridge = (XComponent) a_unoBridge;
		i_initialUnoObjectsProvider = a_initialUnoObjectsProvider;
		i_eventsListeners = a_eventsListeners;
		i_unoBridge.addEventListener (this);
		if (i_eventsListeners != null) {
			for (UnoConnectionEventsListener l_eventsListener: i_eventsListeners){
				l_eventsListener.connected (this);
			}
		}
		// add singletons Start
		i_remoteUnoObjectsContext.addLocalProperty (UnoObjectsContextPropertyNamesSet.c_unoConnectionSingleton_string, this);
		try {
			UnoDesktop l_unoDesktop = UnoDesktop.getInstance (i_remoteUnoObjectsContext);
			i_remoteUnoObjectsContext.addLocalProperty (UnoObjectsContextPropertyNamesSet.c_unoDesktopSingleton_string, l_unoDesktop);
		}
		catch (Exception l_exception) {
			// the remote UNO environment may not be any Office instance, and it is OK.
		}
		// add singletons End
		UnoDesktop l_unoDesktop = (UnoDesktop) (i_remoteUnoObjectsContext.getLocalPropertyValue (UnoObjectsContextPropertyNamesSet.c_unoDesktopSingleton_string));
		if (l_unoDesktop != null) {
			i_officeTerminationQueryListener = new OfficeTerminationQueryListener (this);
			l_unoDesktop.getUnderlyingUnoObject (). <XDesktop>getAddress (XDesktop.class).addTerminateListener (i_officeTerminationQueryListener);
		}
		else {
			i_officeTerminationQueryListener = null;
		}
		i_criticalSessionCount = 0;
		i_serverIsPlannedToBeTerminated = false;
		i_threadsLock = new ReentrantLock ();
		i_threadsCondition = i_threadsLock.newCondition ();
	}
	
	@Override
	protected void finalize () {
	}
	
	public final RemoteUnoObjectsContext getRemoteUnoObjectsContext () {
		return i_remoteUnoObjectsContext;
	}
	
	public void lock () {
		i_threadsLock.lock ();
	}
	
	public void unlock () {
		i_threadsLock.unlock ();
	}
	
	public boolean increaseCriticalSessionCount () {
		try {
			lock ();
			if (i_serverIsPlannedToBeTerminated) {
				return false;
			}
			else {
				i_criticalSessionCount ++;
				return true;
			}
		}
		finally {
			unlock ();
		}
	}
	
	public void decreaseCriticalSessionCount () {
		try {
			lock ();
			i_criticalSessionCount --;
			if (i_criticalSessionCount <= 0) {
				i_threadsCondition.signal ();
			}
		}
		finally {
			unlock ();
		}
	}
	
	public int getCriticalSessionCount () {
		try {
			lock ();
			return i_criticalSessionCount;
		}
		finally {
			unlock ();
		}
	}
	
	public void setServerAsPlannedToBeTerminated () {
		try {
			lock ();
			i_serverIsPlannedToBeTerminated = true;
		}
		finally {
			unlock ();
		}
	}
	
	public boolean serverIsPlannedToBeTerminated () {
		try {
			lock ();
			return i_serverIsPlannedToBeTerminated;
		}
		finally {
			unlock ();
		}
	}
	
	public boolean waitUntilNoCriticalSession (int a_timeOutInMilliseconds) {
		try {
			lock ();
			if (i_criticalSessionCount > 0) {
				try {
					if (a_timeOutInMilliseconds == GeneralConstantsConstantsGroup.c_unspecifiedInteger) {
						i_threadsCondition.await ();
						return true;
					}
					else {
						return i_threadsCondition.await (a_timeOutInMilliseconds, TimeUnit.MILLISECONDS);
					}
				}
				catch (InterruptedException l_exception) {
					return false;
				}
			}
			else {
				return true;
			}
		}
		finally {
			unlock ();
		}
	}
	
	public final void disconnect () {
		if (i_unoBridge != null) {
			try {
				if (i_officeTerminationQueryListener != null) {
					UnoDesktop l_unoDesktop = (UnoDesktop) (i_remoteUnoObjectsContext.getLocalPropertyValue (UnoObjectsContextPropertyNamesSet.c_unoDesktopSingleton_string));
					l_unoDesktop.getUnderlyingUnoObject (). <XDesktop>getAddress (XDesktop.class).removeTerminateListener (i_officeTerminationQueryListener);
				}
				i_unoBridge.dispose ();
			}
			catch (Exception l_exception) {
				Publisher.logErrorInformation (String.format ("### UnoConnection.disconnect error: %s.", l_exception.toString ()));
			}
		}
	}
}

