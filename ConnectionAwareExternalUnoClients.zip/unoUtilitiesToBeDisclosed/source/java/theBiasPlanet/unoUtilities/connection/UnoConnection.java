package theBiasPlanet.unoUtilities.connection;

import java.util.List;
import java.util.Map;
import com.sun.star.bridge.XBridge;
import com.sun.star.bridge.XInstanceProvider;
import com.sun.star.lang.EventObject;
import com.sun.star.lang.XComponent;
import com.sun.star.lang.XEventListener;
import com.sun.star.uno.XComponentContext;
import com.sun.star.uno.XInterface;
import theBiasPlanet.coreUtilities.messagingHandling.Publisher;
import theBiasPlanet.unoUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.*;
import theBiasPlanet.unoUtilities.pointers.UnoObjectPointer;
import theBiasPlanet.unoUtilities.unoComponentBases.UnoComponentBase;
import theBiasPlanet.unoUtilities.unoObjectsContexts.LocalUnoObjectsContext;
import theBiasPlanet.unoUtilities.unoObjectsContexts.RemoteUnoObjectsContext;

public class UnoConnection extends UnoComponentBase implements XEventListener {
	public static class InitialUnoObjectsProvider extends UnoComponentBase implements XInstanceProvider {
		private LocalUnoObjectsContext i_localUnoObjectsContext = null;
		
		public InitialUnoObjectsProvider (LocalUnoObjectsContext a_localUnoObjectsContext) {
			i_localUnoObjectsContext = a_localUnoObjectsContext;
		}
		
		@Override
		protected void finalize () {
		}
		
		@Override
		public XInterface getInstance (String a_initialUnoObjectName) {
			if (UnoDefaultValuesConstantsGroup.c_initiallyOfferedUnoObjectName.equals (a_initialUnoObjectName)) {
				return i_localUnoObjectsContext;
			}
			else {
				return null;
			}
		}
	}
	public static interface UnoConnectionEventsListener {
		public void connected (UnoConnection a_unoConnection);
		
		public void disconnected (UnoConnection a_unoConnection);
	}
	private RemoteUnoObjectsContext i_remoteUnoObjectsContext;
	private XComponent i_unoBridge;
	private	InitialUnoObjectsProvider i_initialUnoObjectsProvider;
	private List <UnoConnectionEventsListener> i_eventsListeners;
	
	public UnoConnection (UnoObjectPointer <XComponentContext> a_originalRemoteUnoObjectsContext, Map <String, Object> a_unoObjectsContextExtraNameToValueMap, XBridge a_unoBridge, InitialUnoObjectsProvider a_initialUnoObjectsProvider, List <UnoConnectionEventsListener> a_eventsListeners) throws com.sun.star.uno.Exception {
		i_remoteUnoObjectsContext = new RemoteUnoObjectsContext (a_originalRemoteUnoObjectsContext, a_unoObjectsContextExtraNameToValueMap);
		i_unoBridge = (XComponent) a_unoBridge;
		i_initialUnoObjectsProvider = a_initialUnoObjectsProvider;
		i_eventsListeners = a_eventsListeners;
		i_unoBridge.addEventListener (this);
		if (i_eventsListeners != null) {
			for (UnoConnectionEventsListener l_eventsListener: i_eventsListeners){
				l_eventsListener.connected (this);
			}
		}
	}
	
	@Override
	protected void finalize () {
	}
	
	public final RemoteUnoObjectsContext getRemoteUnoObjectsContext () {
		return i_remoteUnoObjectsContext;
	}
	
	public final void disconnect () {
		if (i_unoBridge != null) {
			try {
				i_unoBridge.dispose ();
			}
			catch (Exception l_exception) {
				Publisher.logErrorInformation (String.format ("### UnoConnection.disconnect error: %s.", l_exception.toString ()));
			}
		}
	}
	
	@Override
	public final void disposing (EventObject a_event) {
		Publisher.logNormalInformation (a_event.Source.toString ());
		if (i_eventsListeners != null) {
			for (UnoConnectionEventsListener l_eventsListener: i_eventsListeners) {
				l_eventsListener.disconnected (this);
			}
		}
		i_remoteUnoObjectsContext = null;
		i_unoBridge = null;
		i_initialUnoObjectsProvider = null;
		i_eventsListeners = null;
	}
}

