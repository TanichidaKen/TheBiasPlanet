package theBiasPlanet.unoUtilities.javaVirtualMachinesHandling;

public class UnoJavaVirtualMachineInitializer {
	public static void initializeJavaVirtualMachineForSwing () {
		Thread.currentThread ().setContextClassLoader (ClassLoader.getSystemClassLoader ());
	}
}

