package theBiasPlanet.unoUtilities.documentElements;

import theBiasPlanet.coreUtilities.constantsGroups.*;

public class UnoSpreadSheetFormula {
	private String i_formulaString;
	private int i_cellValueExpressionFormatKey = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
	
	public UnoSpreadSheetFormula (String a_formulaString, int a_cellValueExpressionFormatKey) {
		i_formulaString = a_formulaString;
		i_cellValueExpressionFormatKey = a_cellValueExpressionFormatKey;
	}
	
	public String getFormulaString () {
		return i_formulaString;
	}
	
	public void setFormulaString (String a_formulaString) {
		i_formulaString = a_formulaString;
	}
	
	public int getCellValueExpressionFormatKey () {
		return i_cellValueExpressionFormatKey;
	}
	
	public void setCellValueExpressionFormatKey (int a_cellValueExpressionFormatKey) {
		i_cellValueExpressionFormatKey = a_cellValueExpressionFormatKey;
	}
	
	@Override
	public String toString () {
		return i_formulaString;
	}
}

