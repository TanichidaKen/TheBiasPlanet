package theBiasPlanet.unoUtilities.documentElements;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.regex.Matcher;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.math.BigDecimal;
import com.sun.star.lang.WrappedTargetException;
import com.sun.star.sheet.XSheetCellCursor;
import com.sun.star.table.XCell2;
import com.sun.star.table.CellContentType;
import com.sun.star.text.XText;
import com.sun.star.text.XTextCursor;
import com.sun.star.beans.XPropertySet;
import com.sun.star.beans.UnknownPropertyException;
import com.sun.star.beans.PropertyVetoException;
import com.sun.star.util.MalformedNumberFormatException;
import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.*;
import theBiasPlanet.unoUtilities.displayElements.UnoDesktop;
import theBiasPlanet.unoUtilities.documentsHandling.UnoSpreadSheetCellPosition;
import theBiasPlanet.unoUtilities.documentsHandling.UnoSpreadSheetCellsRectangle;
import theBiasPlanet.unoUtilities.pointers.UnoObjectPointer;

// This class represents the whole of the group of the merged cells, if the specified cell is a member of such a group.
public class UnoSpreadSheetCell {
	private UnoSpreadSheet i_sheet;
	private UnoObjectPointer <XCell2> i_underlyingUnoObject;
	private UnoObjectPointer <XSheetCellCursor> i_unoSpreadSheetCellsRectangleCursor;
	
	// When the specified cell isn't the representative cell of the group of merged cells, the cell administered this class is moved to the representative cell.
	public UnoSpreadSheetCell (UnoSpreadSheet a_unoSpreadSheet, UnoObjectPointer <XCell2> a_underlyingUnoObject) {
		i_sheet = a_unoSpreadSheet;
		i_unoSpreadSheetCellsRectangleCursor = i_sheet.getCellsRangeCursor (a_underlyingUnoObject);
		i_unoSpreadSheetCellsRectangleCursor.getAddress ().collapseToMergedArea ();
		UnoSpreadSheetCellsRectangle l_cellsRectangle = UnoSpreadSheetCellsRectangle.getCellsRectangle (i_sheet, i_unoSpreadSheetCellsRectangleCursor);
		try {
			i_underlyingUnoObject = new UnoObjectPointer <XCell2> (i_sheet.getUnderlyingUnoObject ().getAddress ().getCellByPosition (l_cellsRectangle.getLeftmostColumnIndex (), l_cellsRectangle.getTopRowIndex ()), XCell2.class);
		}
		catch (com.sun.star.lang.IndexOutOfBoundsException l_exception) {
			// This will never happen because the indexes are gotten legitimately.
		}
	}
	
	public static UnoSpreadSheetCell getFirstSelectedCell (UnoDesktop a_unoDesktop) throws Exception {
		UnoSpreadSheet l_currentSheet = UnoSpreadSheet.getCurrentSheet (a_unoDesktop);
		if (l_currentSheet != null) {
			return l_currentSheet.getFirstSelectedCell ();
		}
		else {
			return null;
		}
	}
	
	public UnoSpreadSheet getSheet () {
		return i_sheet;
	}
	
	public UnoObjectPointer <XCell2> getUnderlyingUnoObject () {
		return i_underlyingUnoObject;
	}
	
	public Object getValue () throws IOException {
		try {
			CellContentType l_cellContentType = i_underlyingUnoObject.getAddress ().getType ();
			// l_cellContentType can be CellContentType.EMPTY, CellContentType.VALUE, CellContentType.TEXT, or CellContentType.FORMULA
			int l_cellValueExpressionFormatKey = ((Integer) i_underlyingUnoObject. <XPropertySet>getAddress (XPropertySet.class).getPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_numberFormat)).intValue ();
			String l_cellValueExpression = i_underlyingUnoObject. <XText>getAddress (XText.class).getString ();
			if (l_cellValueExpressionFormatKey == i_sheet.getDocument ().getDateExpressionFormatKey ()) {
				if (l_cellContentType == CellContentType.EMPTY) {
					return null;
				}
				LocalDate l_date = LocalDate.parse (l_cellValueExpression, DateTimeFormatter.ISO_LOCAL_DATE);
				return l_date;
			}
			else if (l_cellValueExpressionFormatKey == i_sheet.getDocument ().getTimeExpressionFormatKey ()) {
				if (l_cellContentType == CellContentType.EMPTY) {
					return null;
				}
				LocalTime l_time = LocalTime.parse (l_cellValueExpression, DateTimeFormatter.ISO_LOCAL_TIME);
				return l_time;
			}
			else if (l_cellValueExpressionFormatKey == i_sheet.getDocument ().getDateAndTimeExpressionFormatKey ()) {
				if (l_cellContentType == CellContentType.EMPTY) {
					return null;
				}
				LocalDateTime l_dateAndTime = LocalDateTime.parse (l_cellValueExpression, DateTimeFormatter.ISO_LOCAL_DATE_TIME);
				return l_dateAndTime;
			}
			else if (l_cellValueExpressionFormatKey == i_sheet.getDocument ().getBooleanExpressionFormatKey ()) {
				if (l_cellContentType == CellContentType.EMPTY) {
					return null;
				}
				Boolean l_boolean = Boolean.valueOf (l_cellValueExpression);
				return l_boolean;
			}
			else if (l_cellValueExpressionFormatKey == i_sheet.getDocument ().getStringExpressionFormatKey ()) {
				if (getBackgroundColor () == UnoPixelValuesConstantsGroup.c_compressedCellBackgroundPixelValue) {
					String l_expandedCellText = null;
					return l_expandedCellText;
				}
				else {
					return l_cellValueExpression;
				}
			}
			else if (l_cellValueExpressionFormatKey == i_sheet.getDocument ().getIntegerExpressionFormatKey ()) {
				if (l_cellContentType == CellContentType.EMPTY) {
					return null;
				}
				Integer l_integer = Integer.valueOf (l_cellValueExpression.replaceAll (String.valueOf (GeneralConstantsConstantsGroup.c_thousandsDelimiter), ""));
				return l_integer;
			}
			else {
				if (l_cellContentType == CellContentType.EMPTY) {
					return null;
				}
				Matcher l_matcher = RegularExpressionsConstantsGroup.c_numbersRegularExpression.matcher (l_cellValueExpression);
				if (l_matcher.find ()) {
					BigDecimal l_bigDecimal = new BigDecimal (l_cellValueExpression.replaceAll (String.valueOf (GeneralConstantsConstantsGroup.c_thousandsDelimiter), ""));
					return l_bigDecimal;
					//Double l_double = Double.valueOf (l_cellValueExpression.replaceAll (String.valueOf (GeneralConstantsConstantsGroup.c_thousandsDelimiter), ""));
					//return l_double;
				}
				else {
					return l_cellValueExpression;
				}
			}
		}
		catch (UnknownPropertyException | WrappedTargetException l_exception) {
			// This will never happen.
			return null;
		}
	}
	
	public void setValue (Object a_value) throws PropertyVetoException, MalformedNumberFormatException {
		try {
			if (a_value instanceof Date) {
				a_value = ((Date) a_value).toLocalDate ();
			}
			if (a_value instanceof Time) {
				a_value = ((Time) a_value).toLocalTime ();
			}
			if (a_value instanceof Timestamp) {
				a_value = ((Timestamp) a_value).toLocalDateTime ();
			}
			if (a_value == null || a_value instanceof String) {
				if (getBackgroundColor () == UnoPixelValuesConstantsGroup.c_compressedCellBackgroundPixelValue) {
					removeBackgroundColor ();
				}
				String l_string = UnoGeneralConstantsConstantsGroup.c_unspecifiedString;
				if (a_value != null) {
					l_string = (String) a_value;
				}
				i_underlyingUnoObject. <XPropertySet>getAddress (XPropertySet.class).setPropertyValue(UnoSpreadSheetCellPropertyNamesSet.c_numberFormat, Integer.valueOf (i_sheet.getDocument ().getStringExpressionFormatKey ()));
				i_underlyingUnoObject.getAddress ().setFormula (UnoGeneralConstantsConstantsGroup.c_unspecifiedString);
				UnoObjectPointer <XTextCursor> l_textCursor = new UnoObjectPointer <XTextCursor> (i_underlyingUnoObject. <XText>getAddress (XText.class).createTextCursor ());
				i_underlyingUnoObject. <XText>getAddress (XText.class).insertString (l_textCursor.getAddress (), l_string, true);
			}
			else if (a_value instanceof Integer) {
				Integer l_integer = (Integer) a_value;
				i_underlyingUnoObject. <XPropertySet>getAddress (XPropertySet.class).setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_numberFormat, Integer.valueOf (i_sheet.getDocument ().getIntegerExpressionFormatKey ()));
				i_underlyingUnoObject.getAddress ().setValue (l_integer.intValue ());
			}
			else if (a_value instanceof BigDecimal) {
				BigDecimal l_bigDeciaml = (BigDecimal) a_value;
				int l_scale = l_bigDeciaml.scale ();
				if (l_scale > 0) {
					i_underlyingUnoObject. <XPropertySet>getAddress (XPropertySet.class).setPropertyValue(UnoSpreadSheetCellPropertyNamesSet.c_numberFormat, Integer.valueOf (i_sheet.getDocument ().getDoubleExpressionFormatKey (l_scale)));
					i_underlyingUnoObject.getAddress ().setValue (l_bigDeciaml.doubleValue ());
				}
				else {
					i_underlyingUnoObject. <XPropertySet>getAddress (XPropertySet.class).setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_numberFormat, Integer.valueOf (i_sheet.getDocument ().getIntegerExpressionFormatKey ()));
					i_underlyingUnoObject.getAddress ().setValue (l_bigDeciaml.intValue ());
				}
			}
			else if (a_value instanceof Double) {
				Double l_double = (Double) a_value;
				i_underlyingUnoObject. <XPropertySet>getAddress (XPropertySet.class).setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_numberFormat, Integer.valueOf (i_sheet.getDocument ().getDoubleExpressionFormatKey (GeneralConstantsConstantsGroup.c_unspecifiedInteger)));
				i_underlyingUnoObject.getAddress ().setValue (l_double.doubleValue ());
			}
			else if (a_value instanceof Boolean) {
				Boolean l_boolean = (Boolean) a_value;
				i_underlyingUnoObject. <XPropertySet>getAddress (XPropertySet.class).setPropertyValue(UnoSpreadSheetCellPropertyNamesSet.c_numberFormat, Integer.valueOf (i_sheet.getDocument ().getBooleanExpressionFormatKey ()));
				i_underlyingUnoObject.getAddress ().setFormula (l_boolean.toString ());
			}
			else if (a_value instanceof LocalDate) {
				LocalDate l_date = (LocalDate) a_value;
				String l_dateString = l_date.format (DateTimeFormatter.ISO_LOCAL_DATE);
				i_underlyingUnoObject. <XPropertySet>getAddress (XPropertySet.class).setPropertyValue(UnoSpreadSheetCellPropertyNamesSet.c_numberFormat, Integer.valueOf (i_sheet.getDocument ().getDateExpressionFormatKey ()));
				i_underlyingUnoObject.getAddress ().setFormula (l_dateString);
			}
			else if (a_value instanceof LocalTime) {
				LocalTime l_time = (LocalTime) a_value;
				String l_timeString = l_time.format (DateTimeFormatter.ISO_LOCAL_TIME);
				i_underlyingUnoObject. <XPropertySet>getAddress (XPropertySet.class).setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_numberFormat, Integer.valueOf (i_sheet.getDocument ().getTimeExpressionFormatKey ()));
				i_underlyingUnoObject.getAddress ().setFormula (l_timeString);
			}
			else if (a_value instanceof LocalDateTime) {
				LocalDateTime l_dateAndTime = (LocalDateTime) a_value;
				String l_dateAndTimeString = l_dateAndTime.format (DateTimeFormatter.ISO_LOCAL_DATE_TIME);
				i_underlyingUnoObject. <XPropertySet>getAddress (XPropertySet.class).setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_numberFormat, Integer.valueOf (i_sheet.getDocument ().getDateAndTimeExpressionFormatKey ()));
				i_underlyingUnoObject.getAddress ().setFormula (l_dateAndTimeString);
			}
			else if (a_value instanceof UnoSpreadSheetFormula) {
				UnoSpreadSheetFormula l_formula = (UnoSpreadSheetFormula) a_value;
				if (l_formula.getCellValueExpressionFormatKey () != GeneralConstantsConstantsGroup.c_unspecifiedInteger) {
					i_underlyingUnoObject. <XPropertySet>getAddress (XPropertySet.class).setPropertyValue(UnoSpreadSheetCellPropertyNamesSet.c_numberFormat, Integer.valueOf (l_formula.getCellValueExpressionFormatKey ()));
				}
				i_underlyingUnoObject.getAddress ().setFormula (l_formula.getFormulaString ());
			}
			else {
				String l_string = a_value.toString ();
				i_underlyingUnoObject. <XPropertySet>getAddress (XPropertySet.class).setPropertyValue(UnoSpreadSheetCellPropertyNamesSet.c_numberFormat, Integer.valueOf (i_sheet.getDocument ().getStringExpressionFormatKey ()));
				i_underlyingUnoObject.getAddress ().setFormula (UnoGeneralConstantsConstantsGroup.c_unspecifiedString);
				i_underlyingUnoObject. <XText>getAddress (XText.class).insertString (i_underlyingUnoObject. <XText>getAddress (XText.class).createTextCursor(), l_string, true);
			}
		}
		catch (UnknownPropertyException | WrappedTargetException l_exception) {
			// This will never happen.
		}
	}
	
	public void setValue (Double a_value, int a_numberOfDecimalPlaces) throws PropertyVetoException, MalformedNumberFormatException {
		try {
			i_underlyingUnoObject. <XPropertySet>getAddress (XPropertySet.class).setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_numberFormat, Integer.valueOf (i_sheet.getDocument ().getDoubleExpressionFormatKey (a_numberOfDecimalPlaces)));
			i_underlyingUnoObject.getAddress ().setValue (a_value.doubleValue ());
		}
		catch (UnknownPropertyException | WrappedTargetException l_exception) {
			// This will never happen.
		}
	}
	
	public void setCompressedValue (Object a_value) throws PropertyVetoException, MalformedNumberFormatException, IOException {
		if (a_value instanceof String) {
		}
		else {
			setValue (a_value);
		}
	}
	
	public UnoSpreadSheetCellsRectangle getCellsRectangle () {
		try {
			return UnoSpreadSheetCellsRectangle.getCellsRectangle (i_sheet, (String) i_unoSpreadSheetCellsRectangleCursor. <XPropertySet>getAddress (XPropertySet.class).getPropertyValue (UnoSpreadSheetCellsRangePropertyNamesSet.c_absoluteName));
		}
		catch (UnknownPropertyException | WrappedTargetException l_exception) {
			// This will never happen.
			return null;
		}
	}
	
	public UnoSpreadSheetCellPosition getRepresentativeCellPosition () {
		return getCellsRectangle ().getTopLeftmostCellPosition ();
	}
	
	public int getRepresentativeRowIndex () {
		try {
			UnoSpreadSheetCellsRectangle l_cellsRectangle = UnoSpreadSheetCellsRectangle.getCellsRectangle (i_sheet, (String) i_unoSpreadSheetCellsRectangleCursor. <XPropertySet>getAddress (XPropertySet.class).getPropertyValue (UnoSpreadSheetCellsRangePropertyNamesSet.c_absoluteName));
			return l_cellsRectangle.getTopRowIndex ();
		}
		catch (UnknownPropertyException | WrappedTargetException l_exception) {
			// This will never happen.
			return GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		}
	}
	
	public int getRepresentativeColumnIndex () {
		try {
			UnoSpreadSheetCellsRectangle l_cellsRectangle = UnoSpreadSheetCellsRectangle.getCellsRectangle (i_sheet, (String) i_unoSpreadSheetCellsRectangleCursor. <XPropertySet>getAddress (XPropertySet.class).getPropertyValue (UnoSpreadSheetCellsRangePropertyNamesSet.c_absoluteName));
			return l_cellsRectangle.getLeftmostColumnIndex ();
		}
		catch (UnknownPropertyException | WrappedTargetException l_exception) {
			// This will never happen.
			return GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		}
	}
	
	// a_rowOffset: meant to be 1, 0, or -1 for correctly counting merged cells
	// a_columnOffset: meant to be 1, 0, or -1 for correctly counting merged cells
	public UnoSpreadSheetCell getNeighboringCell (int a_rowOffset, int a_columnOffset) throws com.sun.star.lang.IndexOutOfBoundsException {
		UnoSpreadSheetCellsRectangle l_cellsRectangle = null;
		try {
			l_cellsRectangle = UnoSpreadSheetCellsRectangle.getCellsRectangle (i_sheet, (String) i_unoSpreadSheetCellsRectangleCursor. <XPropertySet>getAddress (XPropertySet.class).getPropertyValue (UnoSpreadSheetCellsRangePropertyNamesSet.c_absoluteName));
		}
		catch (UnknownPropertyException | WrappedTargetException l_exception) {
			// This will never happen.
			return null;
		}
		int l_rowIndex = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		int l_columnIndex = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		if (a_rowOffset <= 0) {
			l_rowIndex = l_cellsRectangle.getTopRowIndex () + a_rowOffset;
		}
		else {
			l_rowIndex = l_cellsRectangle.getBottomRowIndex () + a_rowOffset;
		}
		if (a_columnOffset <= 0) {
			l_columnIndex = l_cellsRectangle.getLeftmostColumnIndex () + a_columnOffset;
		}
		else {
			l_columnIndex = l_cellsRectangle.getRightmostColumnIndex () + a_columnOffset;
		}
		if (l_rowIndex < GeneralConstantsConstantsGroup.c_iterationStartNumber || l_rowIndex > UnoCellsMaximumIndexesConstantsGroup.c_maximumRowIndex || l_columnIndex < GeneralConstantsConstantsGroup.c_iterationStartNumber || l_columnIndex > UnoCellsMaximumIndexesConstantsGroup.c_maximumColumnIndex) {
			throw new com.sun.star.lang.IndexOutOfBoundsException ();
		}
		return i_sheet.getCell (l_rowIndex, l_columnIndex);
	}
	
	public UnoSpreadSheetCell getUpperCell () throws com.sun.star.lang.IndexOutOfBoundsException {
		return getNeighboringCell (-1, 0);
	}
	
	public UnoSpreadSheetCell getDownCell () throws com.sun.star.lang.IndexOutOfBoundsException {
		return getNeighboringCell (1, 0);
	}
	
	public UnoSpreadSheetCell getLeftCell () throws com.sun.star.lang.IndexOutOfBoundsException {
		return getNeighboringCell (0, -1);
	}
	
	public UnoSpreadSheetCell getRightCell () throws com.sun.star.lang.IndexOutOfBoundsException {
		return getNeighboringCell (0, 1);
	}
	
	public int getBackgroundColor () {
		try {
			return ((Integer) i_unoSpreadSheetCellsRectangleCursor. <XPropertySet>getAddress (XPropertySet.class).getPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_backgroundColor)).intValue ();
		}
		catch (UnknownPropertyException | WrappedTargetException l_exception) {
			// This will never happen.
			return GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		}
	}
	
	public void setBackgroundColor (int a_pixelValue) throws PropertyVetoException {
		try {
			i_unoSpreadSheetCellsRectangleCursor. <XPropertySet>getAddress (XPropertySet.class).setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_backgroundColor, Integer.valueOf (a_pixelValue));
			i_unoSpreadSheetCellsRectangleCursor. <XPropertySet>getAddress (XPropertySet.class).setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_backgroundIsTransparent, Boolean.valueOf (false));
		}
		catch (UnknownPropertyException | WrappedTargetException l_exception) {
			// This will never happen.
		}
	}
	
	public void removeBackgroundColor () throws PropertyVetoException {
		try {
			i_unoSpreadSheetCellsRectangleCursor. <XPropertySet>getAddress (XPropertySet.class).setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_backgroundColor, Integer.valueOf (-1));
			i_unoSpreadSheetCellsRectangleCursor. <XPropertySet>getAddress (XPropertySet.class).setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_backgroundIsTransparent, Boolean.valueOf (true));
		}
		catch (UnknownPropertyException | WrappedTargetException l_exception) {
			// This will never happen.
		}
	}
}

