package theBiasPlanet.unoUtilities.officeInstance;

import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.awt.Toolkit;
import java.io.File;
import java.io.FileInputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
import com.sun.star.frame.XDesktop2;
import com.sun.star.frame.XFrame;
import com.sun.star.frame.XModel;
import com.sun.star.frame.XStorable2;
import com.sun.star.lang.DisposedException;
import com.sun.star.lang.XComponent;
import com.sun.star.lang.XServiceInfo;
import com.sun.star.script.browse.XBrowseNode;
import com.sun.star.script.provider.XScript;
import com.sun.star.script.provider.XScriptProvider;
import com.sun.star.util.CloseVetoException;
import com.sun.star.util.XCloseable;
import theBiasPlanet.coreUtilities.collectionsHandling.ListsFactory;
import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.coreUtilities.messagingHandling.Publisher;
import theBiasPlanet.unoUtilities.connection.UnoConnection;
import theBiasPlanet.unoUtilities.constantsGroups.UnoDispatchSlotsConstantsGroup;
import theBiasPlanet.unoUtilities.constantsGroups.UnoGeneralConstantsConstantsGroup;
import theBiasPlanet.unoUtilities.constantsGroups.UnoMacroLocationNamesConstantsGroup;
import theBiasPlanet.unoUtilities.constantsGroups.UnoServiceNamesConstantsGroup;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.UnoObjectsContextPropertyNamesSet;
import theBiasPlanet.unoUtilities.dispatchingHandling.UnoDispatchResultAndRelatedInformation;
import theBiasPlanet.unoUtilities.displayElements.UnoDesktop;
import theBiasPlanet.unoUtilities.displayElements.UnoFrame;
import theBiasPlanet.unoUtilities.documents.UnoDocument;
import theBiasPlanet.unoUtilities.pointers.UnoObjectPointer;
import theBiasPlanet.unoUtilities.unoDataHandling.UnoDatumConverter;
import theBiasPlanet.unoUtilities.unoObjectsContexts.RemoteUnoObjectsContext;

public class OfficeInstance {
	protected RemoteUnoObjectsContext i_remoteUnoObjectsContext = null;
	protected UnoDesktop i_unoDesktop = null;
	protected UnoObjectPointer <XScriptProvider> i_macroHandlersProvider = null;
	protected String i_basicSourceBasePath = null;
	protected SAXParser i_xmlParser = null;
	protected BasicSourceXmlParseHandler i_basicSourceXmlParseHandler = null;
	protected Clipboard i_clipboard = null;
	
	class BasicSourceXmlParseHandler extends DefaultHandler {
		String i_basicModuleName = null;
		StringBuilder i_basicCodeBuilder = null;
		boolean i_isInBasicCodeElement = false;
		
		public String getBasicModuleName () {
			return i_basicModuleName;
		}
		
		public String getBasicCode () {
			return i_basicCodeBuilder.toString ();
		}
		
		@Override
		public void startDocument () throws SAXException {
			i_isInBasicCodeElement = false;
		}
		
		@Override
		public void endDocument () throws SAXException {
		}
		
		@Override
		public void startElement (String a_namespaceUri,String a_localName, String a_qualifiedName, Attributes a_attributes) throws SAXException {
			if (a_qualifiedName.equals ("script:module")) {
				i_isInBasicCodeElement = true;
				i_basicModuleName = a_attributes.getValue ("script:name");
				i_basicCodeBuilder = new StringBuilder ();
			}
		}
		
		@Override
		public void endElement (String a_namespaceUri, String a_localName, String a_qualifiedName) throws SAXException {
		}
		
		@Override
		public void characters (char[] a_characters, int a_start, int a_length) throws SAXException {
			if (i_isInBasicCodeElement) {
				i_basicCodeBuilder.append (a_characters, a_start, a_length);
			}
		}
	}
	
	public OfficeInstance (RemoteUnoObjectsContext a_remoteUnoObjectsContext, String a_basicSourceBasePath) throws Exception {
		i_remoteUnoObjectsContext = a_remoteUnoObjectsContext;
		i_unoDesktop = (UnoDesktop) i_remoteUnoObjectsContext.getLocalPropertyValue (UnoObjectsContextPropertyNamesSet.c_unoDesktopSingleton_string);
		i_macroHandlersProvider = i_remoteUnoObjectsContext. <XScriptProvider>getRemoteUnoServiceInstance (UnoServiceNamesConstantsGroup.c_com_sun_star_script_provider_MasterScriptProvider, XScriptProvider.class, null);
		i_basicSourceBasePath = a_basicSourceBasePath;
		if (i_basicSourceBasePath != null) {
			SAXParserFactory l_saxParserFactory = SAXParserFactory.newInstance ();
			l_saxParserFactory.setFeature ("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
	     	i_xmlParser = l_saxParserFactory.newSAXParser ();
			i_basicSourceXmlParseHandler = new BasicSourceXmlParseHandler ();
			i_clipboard	= Toolkit.getDefaultToolkit ().getSystemClipboard ();
		}
	}
	
	public Object invokeMacro (String a_macroProgrammingLanguageName, String a_macroLocationName, String a_macroPathString, Object [] a_macroArgumentsArray, short [] [] a_macroOutputArgumentIndicesArray, Object [] [] a_macroOutputArgumentsArray) throws Exception {
		if (!a_macroLocationName.equals (UnoMacroLocationNamesConstantsGroup.c_userInPlace) && !a_macroLocationName.equals (UnoMacroLocationNamesConstantsGroup.c_userInExtension) && !a_macroLocationName.equals (UnoMacroLocationNamesConstantsGroup.c_applicationInPlace) && !a_macroLocationName.equals (UnoMacroLocationNamesConstantsGroup.c_applicationInExtension)) {
					throw new Exception ("The macro location name is invalid");
		}
		String l_macroUrl = String.format (UnoGeneralConstantsConstantsGroup.c_macroUrlFormat, a_macroPathString, a_macroProgrammingLanguageName, a_macroLocationName);
		UnoObjectPointer <XScript> l_macroHandler = new UnoObjectPointer <XScript> (i_macroHandlersProvider.getAddress ().getScript (l_macroUrl));
		return l_macroHandler.getAddress ().invoke (a_macroArgumentsArray, a_macroOutputArgumentIndicesArray, a_macroOutputArgumentsArray);
	}
	
	public boolean compileUserBasicScript (String a_libraryName, String a_moduleName) throws Exception {
		boolean l_resultStatus = false;
		boolean l_libraryHasBeenFound = false;
		boolean l_moduleHasBeenFound = false;
		UnoObjectPointer <XBrowseNode> l_scriptsProviderForBasic = i_remoteUnoObjectsContext. <XBrowseNode>getRemoteUnoServiceInstance (UnoServiceNamesConstantsGroup.c_com_sun_star_script_provider_ScriptProviderForBasic, XBrowseNode.class, ListsFactory. <Object>createArrayList ("user"));
		ArrayList <UnoObjectPointer <XBrowseNode>> l_libraryNodes = UnoDatumConverter. <XBrowseNode>getUnoObjects (l_scriptsProviderForBasic.getAddress ().getChildNodes ());
		String l_libraryName = null;
		for (UnoObjectPointer <XBrowseNode> l_libraryNode: l_libraryNodes) {
			l_libraryName = l_libraryNode.getAddress ().getName ();
			if (a_libraryName == null || a_libraryName.equals (l_libraryName)) {
				ArrayList <UnoObjectPointer <XBrowseNode>> l_moduleNodes = UnoDatumConverter. <XBrowseNode>getUnoObjects (l_libraryNode.getAddress ().getChildNodes ());
				String l_moduleName = null;
				for (UnoObjectPointer <XBrowseNode> l_moduleNode: l_moduleNodes) {
					l_moduleName = l_moduleNode. <XBrowseNode>getAddress (XBrowseNode.class).getName ();
					if (a_moduleName == null || a_moduleName.equals (l_moduleName)) {
						l_resultStatus = compileBasicScript ("application", l_libraryName, l_moduleName);
						if (!l_resultStatus) {
							break;
						}
						if (a_moduleName != null) {
							l_moduleHasBeenFound = true;
							break;
						}
					}
				}
				if (a_libraryName != null) {
					if (a_moduleName != null && !l_moduleHasBeenFound) {
						Publisher.logWarningInformation (String.format ("The module has not been loaded into the Office instance for %s.%s; maybe the Office instance has to be restarted.", a_libraryName, a_moduleName));
					}
					l_libraryHasBeenFound = true;
					break;
				}
			}
		}
		if (a_libraryName != null && !l_libraryHasBeenFound) {
			Publisher.logWarningInformation (String.format ("The library has not been loaded into the Office instance for %s; maybe the Office instance has to be restarted.", a_libraryName));
		}
		return l_resultStatus;
	}
	
	public boolean compileBasicScript (String a_containerName, String a_libraryName, String a_moduleName) throws Exception {
		boolean l_resultStatus = false;
		UnoDispatchResultAndRelatedInformation l_unoDispatchResult = i_unoDesktop.fulfill (UnoDispatchSlotsConstantsGroup.c__uno_BasicIDEAppear, ListsFactory. <Object>createArrayList (a_containerName, a_libraryName, a_moduleName, "Module", 1, 0, 0));
		List <UnoObjectPointer <XComponent>> l_unoObjects = i_unoDesktop.getChildObjects ();
		UnoFrame l_basicIdeFrame = null;
		for (UnoObjectPointer <XComponent> l_unoObject: l_unoObjects) {
			if (l_unoObject. <XServiceInfo>getAddress (XServiceInfo.class) != null) {
				if (l_unoObject. <XServiceInfo>getAddress (XServiceInfo.class).supportsService (UnoServiceNamesConstantsGroup.c_com_sun_star_script_BasicIDE)) {
					l_basicIdeFrame = new UnoFrame (i_remoteUnoObjectsContext, new UnoObjectPointer <XFrame> (l_unoObject. <XModel>getAddress (XModel.class).getCurrentController ().getFrame ()));
					break;
				}
			}
		}
		UnoDispatchResultAndRelatedInformation l_unoDispatchResultAndRelatedInformation = null;
		if (l_basicIdeFrame != null) {
			synchronized (this) {
				String l_basicSourceFilePath = String.format ("%s/%s/%s.xba", i_basicSourceBasePath, a_libraryName, a_moduleName);
				if (Files.exists (Paths.get (l_basicSourceFilePath))) {
					i_xmlParser.parse (new FileInputStream (new File (l_basicSourceFilePath)), i_basicSourceXmlParseHandler);
					if (a_moduleName.equals (i_basicSourceXmlParseHandler.getBasicModuleName ())) {
						Transferable l_previousClipboardContents = i_clipboard.getContents (null);
						StringSelection l_basicCodeTransferable = new StringSelection (i_basicSourceXmlParseHandler.getBasicCode ());
						i_clipboard.setContents (l_basicCodeTransferable, l_basicCodeTransferable);
						l_unoDispatchResultAndRelatedInformation = l_basicIdeFrame.fulfill (UnoDispatchSlotsConstantsGroup.c__uno_SelectAll, null);
						l_unoDispatchResultAndRelatedInformation = l_basicIdeFrame.fulfill (UnoDispatchSlotsConstantsGroup.c__uno_Paste, ListsFactory. <Object>createArrayList (Short.valueOf ((short) 0)));
						i_clipboard.setContents (l_previousClipboardContents, null);
						l_unoDispatchResultAndRelatedInformation = l_basicIdeFrame.fulfill (UnoDispatchSlotsConstantsGroup.c__uno_CompileBasic, null);
					}
					else {
						Publisher.logWarningInformation (String.format ("The module name specified in the module file is invalid for %s.%s.%s.", a_containerName, a_libraryName, a_moduleName));
					}
				}
				else {
					Publisher.logWarningInformation (String.format ("There is no source file for %s.%s.%s under the Basic source base.", a_containerName, a_libraryName, a_moduleName));
				}
			}
		}
		return l_unoDispatchResultAndRelatedInformation != null ? true: false;
	}
	
	public boolean terminate (int a_gracePeriodInMillisecondsBeforeForcing) {
		UnoConnection l_unoConnection = (UnoConnection) i_remoteUnoObjectsContext.getLocalPropertyValue (UnoObjectsContextPropertyNamesSet.c_unoConnectionSingleton_string);
		l_unoConnection.setServerAsPlannedToBeTerminated ();
		boolean l_noCriticalSession = l_unoConnection.waitUntilNoCriticalSession (a_gracePeriodInMillisecondsBeforeForcing);
		List <UnoObjectPointer <XComponent>> l_unoObjects = i_unoDesktop.getChildObjects ();
		for (UnoObjectPointer <XComponent> l_unoObject: l_unoObjects) {
			if (l_unoObject. <XCloseable>getAddress (XCloseable.class) == null) {
				continue;
			}
			UnoDocument l_unoDocument = null;
			try {
				l_unoDocument = new UnoDocument (i_remoteUnoObjectsContext, new UnoObjectPointer <XModel> (l_unoObject, XModel.class));
				Publisher.logWarningInformation (String.format ("The document '%s' is left opened.", l_unoDocument.getUrl ()));
				try {
					l_unoDocument.close ();
					Publisher.logWarningInformation (String.format ("The document '%s' has been closed.", l_unoDocument.getUrl ()));
				}
				catch (CloseVetoException l_exception) {
					Publisher.logWarningInformation (String.format ("The document '%s' has been vetoed to be closed.", l_unoDocument.getUrl ()));
					l_unoObject. <XComponent>getAddress (XComponent.class).dispose ();
					Publisher.logWarningInformation (String.format ("The document '%s' has been disposed.", l_unoDocument.getUrl ()));
				}
			}
			catch (DisposedException l_exception) {
				Publisher.logWarningInformation (String.format ("The document '%s' has been disposed.", l_unoDocument.getUrl ()));
			}
			catch (Exception l_exception) {
				Publisher.logErrorInformation (String.format ("An error has occurred: %s.", l_exception.toString ()));
			}
		}
		boolean l_shutdownTryResult = false;
		// loops because the shutdown may be vetoed.
		try {
			while (true) {
				try {
					l_shutdownTryResult = i_unoDesktop.getUnderlyingUnoObject (). <XDesktop2>getAddress (XDesktop2.class).terminate ();
				}
				catch (DisposedException l_exception) {
					return true;
				}
				if (l_shutdownTryResult) {
					return l_shutdownTryResult;
				}
				try {
					Thread.sleep (1000);
				}
				catch (InterruptedException l_exception) {
				}
			}
		}
		finally {
		}
	}
}

