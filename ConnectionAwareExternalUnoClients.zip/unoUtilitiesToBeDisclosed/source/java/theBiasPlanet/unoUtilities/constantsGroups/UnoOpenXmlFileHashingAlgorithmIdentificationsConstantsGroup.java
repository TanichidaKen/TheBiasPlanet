package theBiasPlanet.unoUtilities.constantsGroups;

public interface UnoOpenXmlFileHashingAlgorithmIdentificationsConstantsGroup {
	String c_md2 = "1";
	String c_md4 = "2";
	String c_md5 = "3";
	String c_sha1 = "4";
}

