package theBiasPlanet.unoUtilities.constantsGroups;

public interface UnoOpenXmlFileEncryptionAlgorithmTypesConstantsGroup {
	String c_any = "typeAny";
}

