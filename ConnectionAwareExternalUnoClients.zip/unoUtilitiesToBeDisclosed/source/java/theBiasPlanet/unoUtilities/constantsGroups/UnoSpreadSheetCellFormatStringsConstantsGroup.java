package theBiasPlanet.unoUtilities.constantsGroups;

public interface UnoSpreadSheetCellFormatStringsConstantsGroup {
	String c_globalNumber = "Global";
	String c_standardNumber = "Standard";
	String c_standardDate = "YYYY-MM-DD";
	String c_standardTime = "HH:MM:SS";
	String c_standardDateAndTime = "YYYY-MM-DD\"T\"HH:MM:SS";
	String c_standardBoolean = "BOOLEAN";
	String c_standardString = "@";
	String c_standardInteger = "0";
	String c_standardDoubleTemplate = "%%.%df";
}

