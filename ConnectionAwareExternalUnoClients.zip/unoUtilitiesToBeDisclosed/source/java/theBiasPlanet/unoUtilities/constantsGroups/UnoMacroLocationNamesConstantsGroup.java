package theBiasPlanet.unoUtilities.constantsGroups;

// Interface because this is not enumerable
public interface UnoMacroLocationNamesConstantsGroup {
	String c_userInPlace = "user";
	String c_userInExtension = "user:uno_packages";
	String c_applicationInPlace = "share";
	String c_applicationInExtension = "share:uno_packages";
	String c_document = "document";
}

