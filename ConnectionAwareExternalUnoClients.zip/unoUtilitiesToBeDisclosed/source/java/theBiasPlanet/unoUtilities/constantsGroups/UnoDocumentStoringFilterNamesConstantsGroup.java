package theBiasPlanet.unoUtilities.constantsGroups;

public interface UnoDocumentStoringFilterNamesConstantsGroup {
	String c_toOpenDocumentTextFileFilterName = "writer8";
	String c_toOpenDocumentSpreadsheetFileFilterName = "calc8";
	String c_toOpenDocumentPresentationFileFilterName = "impress8";
	String c_toMicrosoftWord2007XmlFileFilterName = "MS Word 2007 XML";
	String c_toMicrosoftExcel2007XmlFileFilterName = "Calc MS Excel 2007 XML";
	String c_toMicrosoftPowerPoint2007XmlFileFilterName = "Impress MS PowerPoint 2007 XML";
	String c_toMicrosoftWord97FileFilterName = "MS Word 97";
	String c_toMicrosoftExcel97FileFilterName = "MS Excel 97";
	String c_toMicrosoftPowerPoint97FileFilterName = "MS PowerPoint 97";
	String c_toCsvFileFilterName = "Text - txt - csv (StarCalc)";
	String c_toPdfFileFilterNameForTextDocuments = "writer_pdf_Export";
	String c_toPdfFileFilterNameForSpreadSheetsDocuments = "calc_pdf_Export";
	String c_toPdfFileFilterNameForPresentationDocuments = "impress_pdf_Export";
	String c_toPdfFileFilterNameForDrawDocuments = "draw_pdf_Export";
	String c_toEpubFileFilterName = "EPUB";
	String c_toXhtmlFileFilterNameForTextDocuments = "XHTML Writer File";
	String c_toXhtmlFileFilterNameForSpreadSheetsDocuments = "XHTML Calc File";
	String c_toXhtmlFileFilterNameForPresentationDocuments = "XHTML Impress File";
	String c_toXhtmlFileFilterNameForDrawDocuments = "XHTML Draw File";
	String c_toJpegFileFilterNameForTextDocuments = "writer_jpg_Export";
	String c_toJpegFileFilterNameForSpreadSheetsDocuments = "calc_jpg_Export";
	String c_toJpegFileFilterNameForPresentationDocuments = "impress_jpg_Export";
	String c_toJpegFileFilterNameForDrawDocuments = "draw_jpg_Export";
	String c_toPngFileFilterNameForTextDocuments = "writer_png_Export";
	String c_toPngFileFilterNameForSpreadSheetsDocuments = "calc_png_Export";
	String c_toPngFileFilterNameForPresentationDocuments = "impress_png_Export";
	String c_toPngFileFilterNameForDrawDocuments = "draw_png_Export";
	String c_toWriterLayoutFileFilterName = "writer_layout_dump";
}

