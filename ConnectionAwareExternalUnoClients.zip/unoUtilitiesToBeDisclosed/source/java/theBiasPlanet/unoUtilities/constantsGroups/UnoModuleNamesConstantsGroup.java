package theBiasPlanet.unoUtilities.constantsGroups;

public interface UnoModuleNamesConstantsGroup {
	String c_standardBasemoduleName = "com.sun.star";
}

