package theBiasPlanet.unoUtilities.constantsGroups;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.*;
import theBiasPlanet.unoUtilities.unoDataHandling.UnoDatumConverter;

// Interface because this is not enumerable
public interface UnoDispatchSlotsConstantsGroup {
	BaseUnoDispatchSlot c__uno_StyleNewByExample = new BaseUnoDispatchSlot (".uno:StyleNewByExample", Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_GoToCell = new BaseUnoDispatchSlot (".uno:GoToCell", Uno_uno_GoToCellEnumerablePropertyNamesSet.c_instance);
	// This slot is removed.
	BaseUnoDispatchSlot c__uno_Cells = new BaseUnoDispatchSlot (".uno:Cells", null);
	// This slot is removed.
	BaseUnoDispatchSlot c__uno_Range = new BaseUnoDispatchSlot (".uno:Range", Uno_uno_RangeEnumerablePropertyNamesSet.c_instance);
	// This slot is removed.
	BaseUnoDispatchSlot c__uno_CellText = new BaseUnoDispatchSlot (".uno:CellText", Uno_uno_CellTextEnumerablePropertyNamesSet.c_instance);
	// This slot is removed.
	BaseUnoDispatchSlot c__uno_Selection = new BaseUnoDispatchSlot (".uno:Selection", null);
	// This slot is removed.
	BaseUnoDispatchSlot c__uno_ActiveCell = new BaseUnoDispatchSlot (".uno:ActiveCell", null);
	// This slot is removed.
	BaseUnoDispatchSlot c__uno_ActiveTable = new BaseUnoDispatchSlot (".uno:ActiveTable", null);
	// This slot is removed.
	BaseUnoDispatchSlot c__uno_Tables = new BaseUnoDispatchSlot (".uno:Tables", null);
	// This slot is removed.
	BaseUnoDispatchSlot c__uno_DataPilotTables = new BaseUnoDispatchSlot (".uno:DataPilotTables", null);
	BaseUnoDispatchSlot c__uno_Position = new BaseUnoDispatchSlot (".uno:Position", Uno_uno_PositionEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_GoToCurrentCell = new BaseUnoDispatchSlot (".uno:GoToCurrentCell", null);
	BaseUnoDispatchSlot c__uno_StatusDocPos = new BaseUnoDispatchSlot (".uno:StatusDocPos", null);
	BaseUnoDispatchSlot c__uno_StatusSelectionMode = new BaseUnoDispatchSlot (".uno:StatusSelectionMode", null);
	BaseUnoDispatchSlot c__uno_StatusSelectionModeExp = new BaseUnoDispatchSlot (".uno:StatusSelectionModeExp", null);
	BaseUnoDispatchSlot c__uno_StatusSelectionModeExt = new BaseUnoDispatchSlot (".uno:StatusSelectionModeExt", null);
	BaseUnoDispatchSlot c__uno_StatusSelectionModeNorm = new BaseUnoDispatchSlot (".uno:StatusSelectionModeNorm", null);
	BaseUnoDispatchSlot c__uno_SelectData = new BaseUnoDispatchSlot (".uno:SelectData", null);
	BaseUnoDispatchSlot c__uno_SetInputMode = new BaseUnoDispatchSlot (".uno:SetInputMode", null);
	BaseUnoDispatchSlot c__uno_JumpToPreviousCell = new BaseUnoDispatchSlot (".uno:JumpToPreviousCell", null);
	BaseUnoDispatchSlot c__uno_DataSelect = new BaseUnoDispatchSlot (".uno:DataSelect", null);
	BaseUnoDispatchSlot c__uno_ExternalEdit = new BaseUnoDispatchSlot (".uno:ExternalEdit", null);
	BaseUnoDispatchSlot c__uno_PasteSpecial = new BaseUnoDispatchSlot (".uno:PasteSpecial", Uno_uno_PasteSpecialEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_CompareDocuments = new BaseUnoDispatchSlot (".uno:CompareDocuments", Uno_uno_CompareDocumentsEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_MergeDocuments = new BaseUnoDispatchSlot (".uno:MergeDocuments", Uno_uno_MergeDocumentsEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_FontNameList = new BaseUnoDispatchSlot (".uno:FontNameList", null);
	BaseUnoDispatchSlot c__uno_Notebookbar = new BaseUnoDispatchSlot (".uno:Notebookbar", Uno_uno_NotebookbarEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_GetColorTable = new BaseUnoDispatchSlot (".uno:GetColorTable", null);
	BaseUnoDispatchSlot c__uno_LanguageStatus = new BaseUnoDispatchSlot (".uno:LanguageStatus", Uno_uno_LanguageStatusEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_TableCount = new BaseUnoDispatchSlot (".uno:TableCount", null);
	BaseUnoDispatchSlot c__uno_ScenarioManager = new BaseUnoDispatchSlot (".uno:ScenarioManager", Uno_uno_ScenarioManagerEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_DeleteScenario = new BaseUnoDispatchSlot (".uno:DeleteScenario", Uno_uno_DeleteScenarioEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_EditScenario = new BaseUnoDispatchSlot (".uno:EditScenario", Uno_uno_EditScenarioEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_SelectScenario = new BaseUnoDispatchSlot (".uno:SelectScenario", Uno_uno_SelectScenarioEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_StatusFunction = new BaseUnoDispatchSlot (".uno:StatusFunction", null);
	BaseUnoDispatchSlot c__uno_GoToObject = new BaseUnoDispatchSlot (".uno:GoToObject", Uno_uno_GoToObjectEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_Name = new BaseUnoDispatchSlot (".uno:Name", Uno_uno_NameEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_GoDown = new BaseUnoDispatchSlot (".uno:GoDown", Uno_uno_GoDownEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_GoUp = new BaseUnoDispatchSlot (".uno:GoUp", Uno_uno_GoUpEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_GoRight = new BaseUnoDispatchSlot (".uno:GoRight", Uno_uno_GoRightEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_GoLeft = new BaseUnoDispatchSlot (".uno:GoLeft", Uno_uno_GoLeftEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_GoDownBlock = new BaseUnoDispatchSlot (".uno:GoDownBlock", Uno_uno_GoDownBlockEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_GoUpBlock = new BaseUnoDispatchSlot (".uno:GoUpBlock", Uno_uno_GoUpBlockEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_GoRightBlock = new BaseUnoDispatchSlot (".uno:GoRightBlock", Uno_uno_GoRightBlockEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_GoLeftBlock = new BaseUnoDispatchSlot (".uno:GoLeftBlock", Uno_uno_GoLeftBlockEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_GoToStart = new BaseUnoDispatchSlot (".uno:GoToStart", Uno_uno_GoToStartEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_GoToEndOfData = new BaseUnoDispatchSlot (".uno:GoToEndOfData", Uno_uno_GoToEndOfDataEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_GoToStartSel = new BaseUnoDispatchSlot (".uno:GoToStartSel", null);
	BaseUnoDispatchSlot c__uno_GoToEndOfDataSel = new BaseUnoDispatchSlot (".uno:GoToEndOfDataSel", null);
	BaseUnoDispatchSlot c__uno_GoDownSel = new BaseUnoDispatchSlot (".uno:GoDownSel", Uno_uno_GoDownSelEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_GoUpSel = new BaseUnoDispatchSlot (".uno:GoUpSel", Uno_uno_GoUpSelEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_GoRightSel = new BaseUnoDispatchSlot (".uno:GoRightSel", Uno_uno_GoRightSelEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_GoLeftSel = new BaseUnoDispatchSlot (".uno:GoLeftSel", Uno_uno_GoLeftSelEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_GoToStartOfRow = new BaseUnoDispatchSlot (".uno:GoToStartOfRow", Uno_uno_GoToStartOfRowEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_GoToStartOfRowSel = new BaseUnoDispatchSlot (".uno:GoToStartOfRowSel", null);
	BaseUnoDispatchSlot c__uno_GoToEndOfRow = new BaseUnoDispatchSlot (".uno:GoToEndOfRow", Uno_uno_GoToEndOfRowEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_GoToEndOfRowSel = new BaseUnoDispatchSlot (".uno:GoToEndOfRowSel", null);
	BaseUnoDispatchSlot c__uno_GoDownBlockSel = new BaseUnoDispatchSlot (".uno:GoDownBlockSel", Uno_uno_GoDownBlockSelEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_GoUpBlockSel = new BaseUnoDispatchSlot (".uno:GoUpBlockSel", Uno_uno_GoUpBlockSelEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_GoRightBlockSel = new BaseUnoDispatchSlot (".uno:GoRightBlockSel", Uno_uno_GoRightBlockSelEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_GoLeftBlockSel = new BaseUnoDispatchSlot (".uno:GoLeftBlockSel", Uno_uno_GoLeftBlockSelEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_GoUpToStartOfData = new BaseUnoDispatchSlot (".uno:GoUpToStartOfData", Uno_uno_GoUpToStartOfDataEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_GoUpToStartOfDataSel = new BaseUnoDispatchSlot (".uno:GoUpToStartOfDataSel", Uno_uno_GoUpToStartOfDataSelEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_GoDownToEndOfData = new BaseUnoDispatchSlot (".uno:GoDownToEndOfData", Uno_uno_GoDownToEndOfDataEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_GoDownToEndOfDataSel = new BaseUnoDispatchSlot (".uno:GoDownToEndOfDataSel", Uno_uno_GoDownToEndOfDataSelEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_GoLeftToStartOfData = new BaseUnoDispatchSlot (".uno:GoLeftToStartOfData", Uno_uno_GoLeftToStartOfDataEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_GoRightToEndOfData = new BaseUnoDispatchSlot (".uno:GoRightToEndOfData", Uno_uno_GoRightToEndOfDataEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_GoLeftToStartOfDataSel = new BaseUnoDispatchSlot (".uno:GoLeftToStartOfDataSel", Uno_uno_GoLeftToStartOfDataSelEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_GoRightToEndOfDataSel = new BaseUnoDispatchSlot (".uno:GoRightToEndOfDataSel", Uno_uno_GoRightToEndOfDataSelEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_ClipboardFormatItems = new BaseUnoDispatchSlot (".uno:ClipboardFormatItems", Uno_uno_ClipboardFormatItemsEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_PasteUnformatted = new BaseUnoDispatchSlot (".uno:PasteUnformatted", null);
	BaseUnoDispatchSlot c__uno_Paste = new BaseUnoDispatchSlot (".uno:Paste", Uno_uno_PasteEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_PasteOnlyText = new BaseUnoDispatchSlot (".uno:PasteOnlyText", null);
	BaseUnoDispatchSlot c__uno_PasteOnlyFormula = new BaseUnoDispatchSlot (".uno:PasteOnlyFormula", null);
	BaseUnoDispatchSlot c__uno_PasteOnlyValue = new BaseUnoDispatchSlot (".uno:PasteOnlyValue", null);
	BaseUnoDispatchSlot c__uno_Cut = new BaseUnoDispatchSlot (".uno:Cut", null);
	BaseUnoDispatchSlot c__uno_Copy = new BaseUnoDispatchSlot (".uno:Copy", null);
	BaseUnoDispatchSlot c__uno_Delete = new BaseUnoDispatchSlot (".uno:Delete", Uno_uno_DeleteEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_StateTableCell = new BaseUnoDispatchSlot (".uno:StateTableCell", null);
	BaseUnoDispatchSlot c__uno_ChangeCaseToUpper = new BaseUnoDispatchSlot (".uno:ChangeCaseToUpper", null);
	BaseUnoDispatchSlot c__uno_ChangeCaseToLower = new BaseUnoDispatchSlot (".uno:ChangeCaseToLower", null);
	BaseUnoDispatchSlot c__uno_ChangeCaseToHalfWidth = new BaseUnoDispatchSlot (".uno:ChangeCaseToHalfWidth", null);
	BaseUnoDispatchSlot c__uno_ChangeCaseToFullWidth = new BaseUnoDispatchSlot (".uno:ChangeCaseToFullWidth", null);
	BaseUnoDispatchSlot c__uno_ChangeCaseToHiragana = new BaseUnoDispatchSlot (".uno:ChangeCaseToHiragana", null);
	BaseUnoDispatchSlot c__uno_ChangeCaseToKatakana = new BaseUnoDispatchSlot (".uno:ChangeCaseToKatakana", null);
	BaseUnoDispatchSlot c__uno_HangulHanjaConversion = new BaseUnoDispatchSlot (".uno:HangulHanjaConversion", null);
	BaseUnoDispatchSlot c__uno_ChineseConversion = new BaseUnoDispatchSlot (".uno:ChineseConversion", null);
	BaseUnoDispatchSlot c__uno_ChangeCaseToSentenceCase = new BaseUnoDispatchSlot (".uno:ChangeCaseToSentenceCase", null);
	BaseUnoDispatchSlot c__uno_ChangeCaseToTitleCase = new BaseUnoDispatchSlot (".uno:ChangeCaseToTitleCase", null);
	BaseUnoDispatchSlot c__uno_ChangeCaseToToggleCase = new BaseUnoDispatchSlot (".uno:ChangeCaseToToggleCase", null);
	BaseUnoDispatchSlot c__uno_ChangeCaseRotateCase = new BaseUnoDispatchSlot (".uno:ChangeCaseRotateCase", null);
	BaseUnoDispatchSlot c__uno_StandardTextAttributes = new BaseUnoDispatchSlot (".uno:StandardTextAttributes", null);
	BaseUnoDispatchSlot c__uno_Text_Marquee = new BaseUnoDispatchSlot (".uno:Text_Marquee", null);
	BaseUnoDispatchSlot c__uno_ExecuteSearch = new BaseUnoDispatchSlot (".uno:ExecuteSearch", Uno_uno_ExecuteSearchEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_SearchOptions = new BaseUnoDispatchSlot (".uno:SearchOptions", null);
	BaseUnoDispatchSlot c__uno_SearchProperties = new BaseUnoDispatchSlot (".uno:SearchProperties", null);
	BaseUnoDispatchSlot c__uno_Search = new BaseUnoDispatchSlot (".uno:Search", Uno_uno_SearchEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_RepeatSearch = new BaseUnoDispatchSlot (".uno:RepeatSearch", null);
	BaseUnoDispatchSlot c__uno_SearchAll = new BaseUnoDispatchSlot (".uno:SearchAll", Uno_uno_SearchAllEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_Replace = new BaseUnoDispatchSlot (".uno:Replace", Uno_uno_ReplaceEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_ReplaceAll = new BaseUnoDispatchSlot (".uno:ReplaceAll", Uno_uno_ReplaceAllEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_Grow = new BaseUnoDispatchSlot (".uno:Grow", null);
	BaseUnoDispatchSlot c__uno_Shrink = new BaseUnoDispatchSlot (".uno:Shrink", null);
	BaseUnoDispatchSlot c__uno_Calculate = new BaseUnoDispatchSlot (".uno:Calculate", null);
	BaseUnoDispatchSlot c__uno_CalculateHard = new BaseUnoDispatchSlot (".uno:CalculateHard", null);
	BaseUnoDispatchSlot c__uno_BasicIDEAppear = new BaseUnoDispatchSlot (".uno:BasicIDEAppear", Uno_uno_BasicIDEAppearEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_CompileBasic = new BaseUnoDispatchSlot (".uno:CompileBasic", null);
	BaseUnoDispatchSlot c__uno_LoadBasic = new BaseUnoDispatchSlot (".uno:LoadBasic", null);
	BaseUnoDispatchSlot c__uno_UpdateAllModuleSources = new BaseUnoDispatchSlot (".uno:UpdateAllModuleSources", null);
	BaseUnoDispatchSlot c__uno_LibLoaded = new BaseUnoDispatchSlot (".uno:LibLoaded", Uno_uno_LibLoadedEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_SelectAll = new BaseUnoDispatchSlot (".uno:SelectAll", null);
	BaseUnoDispatchSlot c__uno_GetUndoStrings = new BaseUnoDispatchSlot (".uno:GetUndoStrings", null);
	BaseUnoDispatchSlot c__uno_GetRedoStrings = new BaseUnoDispatchSlot (".uno:GetRedoStrings", null);
	BaseUnoDispatchSlot c__uno_SaveAs = new BaseUnoDispatchSlot (".uno:SaveAs", Uno_uno_SaveAsEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_Save = new BaseUnoDispatchSlot (".uno:Save", Uno_uno_SaveEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_GotoDocument = new BaseUnoDispatchSlot (".uno:GotoDocument", Uno_uno_GotoDocumentEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_Protect = new BaseUnoDispatchSlot (".uno:Protect", Uno_uno_ProtectEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_SetDocumentProperties = new BaseUnoDispatchSlot (".uno:SetDocumentProperties", Uno_uno_SetDocumentPropertiesEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_IsLoading = new BaseUnoDispatchSlot (".uno:IsLoading", null);
	BaseUnoDispatchSlot c__uno_ModifiedStatus = new BaseUnoDispatchSlot (".uno:ModifiedStatus", null);
	BaseUnoDispatchSlot c__uno_PageStyle = new BaseUnoDispatchSlot (".uno:PageStyle", null);
	BaseUnoDispatchSlot c__uno_JumpToMark = new BaseUnoDispatchSlot (".uno:JumpToMark", Uno_uno_JumpToMarkEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_ThesaurusFromContext = new BaseUnoDispatchSlot (".uno:ThesaurusFromContext", Uno_uno_ThesaurusFromContextEnumerablePropertyNamesSet.c_instance);
	//BaseUnoDispatchSlot c__uno_CharFontName = new BaseUnoDispatchSlot (".uno:CharFontName", Uno_uno_CharFontNameEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_CharFontName = new BaseUnoDispatchSlot (".uno:CharFontName", null);
	BaseUnoDispatchSlot c__uno_CursorTopOfScreen = new BaseUnoDispatchSlot (".uno:CursorTopOfScreen", null);
	BaseUnoDispatchSlot c__uno_CursorEndOfScreen = new BaseUnoDispatchSlot (".uno:CursorEndOfScreen", null);
	BaseUnoDispatchSlot c__uno_Formula = new BaseUnoDispatchSlot (".uno:Formula", null);
	BaseUnoDispatchSlot c__uno_Value = new BaseUnoDispatchSlot (".uno:Value", null);
	BaseUnoDispatchSlot c__uno_TextValue = new BaseUnoDispatchSlot (".uno:TextValue", null);
	BaseUnoDispatchSlot c__uno_ToggleRelative = new BaseUnoDispatchSlot (".uno:ToggleRelative", null);
	BaseUnoDispatchSlot c__uno_EnterString = new BaseUnoDispatchSlot (".uno:EnterString", Uno_uno_EnterStringEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_Address = new BaseUnoDispatchSlot (".uno:Address", null);
	BaseUnoDispatchSlot c__uno_NoteText = new BaseUnoDispatchSlot (".uno:NoteText", null);
	BaseUnoDispatchSlot c__uno_Menubar = new BaseUnoDispatchSlot (".uno:Menubar", null);
	BaseUnoDispatchSlot c__uno_SignPDF = new BaseUnoDispatchSlot (".uno:SignPDF", Uno_uno_SignPDFEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_NewWindow = new BaseUnoDispatchSlot (".uno:NewWindow", null);
	BaseUnoDispatchSlot c__uno_CloseWin = new BaseUnoDispatchSlot (".uno:CloseWin", null);
	BaseUnoDispatchSlot c__uno_CurrentURL = new BaseUnoDispatchSlot (".uno:CurrentURL", null);
	BaseUnoDispatchSlot c__uno_JumpToTable = new BaseUnoDispatchSlot (".uno:JumpToTable", Uno_uno_JumpToTableEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_JumpToPrevTable = new BaseUnoDispatchSlot (".uno:JumpToPrevTable", null);
	BaseUnoDispatchSlot c__uno_JumpToNextTable = new BaseUnoDispatchSlot (".uno:JumpToNextTable", null);
	BaseUnoDispatchSlot c__uno_Underline = new BaseUnoDispatchSlot (".uno:Underline", null);
	BaseUnoDispatchSlot c__uno_Overline = new BaseUnoDispatchSlot (".uno:Overline", null);
	BaseUnoDispatchSlot c__uno_Strikeout = new BaseUnoDispatchSlot (".uno:Strikeout", null);
	BaseUnoDispatchSlot c__uno_UnderlineNone = new BaseUnoDispatchSlot (".uno:UnderlineNone", null);
	BaseUnoDispatchSlot c__uno_UnderlineSingle = new BaseUnoDispatchSlot (".uno:UnderlineSingle", null);
	BaseUnoDispatchSlot c__uno_UnderlineDouble = new BaseUnoDispatchSlot (".uno:UnderlineDouble", null);
	BaseUnoDispatchSlot c__uno_UnderlineDotted = new BaseUnoDispatchSlot (".uno:UnderlineDotted", null);
	BaseUnoDispatchSlot c__uno_SuperScript = new BaseUnoDispatchSlot (".uno:SuperScript", null);
	BaseUnoDispatchSlot c__uno_SubScript = new BaseUnoDispatchSlot (".uno:SubScript", null);
	BaseUnoDispatchSlot c__uno_FocusCellAddress = new BaseUnoDispatchSlot (".uno:FocusCellAddress", null);
	BaseUnoDispatchSlot c__uno_SelectedObjectName = new BaseUnoDispatchSlot (".uno:SelectedObjectName", null);
	BaseUnoDispatchSlot c__uno_DefinePrintArea = new BaseUnoDispatchSlot (".uno:DefinePrintArea", null);
	BaseUnoDispatchSlot c__uno_DeletePrintArea = new BaseUnoDispatchSlot (".uno:DeletePrintArea", null);
	BaseUnoDispatchSlot c__uno_EditPrintArea = new BaseUnoDispatchSlot (".uno:EditPrintArea", null);
	BaseUnoDispatchSlot c__uno_ChangePrintArea = new BaseUnoDispatchSlot (".uno:ChangePrintArea", Uno_uno_ChangePrintAreaEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_AddPrintArea = new BaseUnoDispatchSlot (".uno:AddPrintArea", null);
	BaseUnoDispatchSlot c__uno_AdjustPrintZoom = new BaseUnoDispatchSlot (".uno:AdjustPrintZoom", null);
	BaseUnoDispatchSlot c__uno_ResetPrintZoom = new BaseUnoDispatchSlot (".uno:ResetPrintZoom", null);
	BaseUnoDispatchSlot c__uno_Show = new BaseUnoDispatchSlot (".uno:Show", Uno_uno_ShowEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_Hide = new BaseUnoDispatchSlot (".uno:Hide", Uno_uno_HideEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_Visible = new BaseUnoDispatchSlot (".uno:Visible", null);
	BaseUnoDispatchSlot c__uno_CharmapControl = new BaseUnoDispatchSlot (".uno:CharmapControl", null);
	BaseUnoDispatchSlot c__uno_FontHeight = new BaseUnoDispatchSlot (".uno:FontHeight", null);
	BaseUnoDispatchSlot c__uno_Hyperlink = new BaseUnoDispatchSlot (".uno:Hyperlink", Uno_uno_HyperlinkEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_SetHyperlink = new BaseUnoDispatchSlot (".uno:SetHyperlink", Uno_uno_SetHyperlinkEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_OpenHyperlinkOnCursor = new BaseUnoDispatchSlot (".uno:OpenHyperlinkOnCursor", null);
	BaseUnoDispatchSlot c__uno_GoToStartOfLine = new BaseUnoDispatchSlot (".uno:GoToStartOfLine", null);
	BaseUnoDispatchSlot c__uno_GoToEndOfLine = new BaseUnoDispatchSlot (".uno:GoToEndOfLine", null);
	BaseUnoDispatchSlot c__uno_GoToStartOfDoc = new BaseUnoDispatchSlot (".uno:GoToStartOfDoc", null);
	BaseUnoDispatchSlot c__uno_GoToEndOfDoc = new BaseUnoDispatchSlot (".uno:GoToEndOfDoc", null);
	BaseUnoDispatchSlot c__uno_GoToStartOfNextPage = new BaseUnoDispatchSlot (".uno:GoToStartOfNextPage", null);
	BaseUnoDispatchSlot c__uno_GoToEndOfNextPage = new BaseUnoDispatchSlot (".uno:GoToEndOfNextPage", null);
	BaseUnoDispatchSlot c__uno_GoToStartOfPrevPage = new BaseUnoDispatchSlot (".uno:GoToStartOfPrevPage", null);
	BaseUnoDispatchSlot c__uno_GoToEndOfPrevPage = new BaseUnoDispatchSlot (".uno:GoToEndOfPrevPage", null);
	BaseUnoDispatchSlot c__uno_GoToStartOfPage = new BaseUnoDispatchSlot (".uno:GoToStartOfPage", null);
	BaseUnoDispatchSlot c__uno_GoToEndOfPage = new BaseUnoDispatchSlot (".uno:GoToEndOfPage", null);
	BaseUnoDispatchSlot c__uno_Redo = new BaseUnoDispatchSlot (".uno:Redo", Uno_uno_RedoEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_GoToStartOfColumn = new BaseUnoDispatchSlot (".uno:GoToStartOfColumn", null);
	BaseUnoDispatchSlot c__uno_GoToEndOfColumn = new BaseUnoDispatchSlot (".uno:GoToEndOfColumn", null);
	BaseUnoDispatchSlot c__uno_GoToStartOfPara = new BaseUnoDispatchSlot (".uno:GoToStartOfPara", null);
	BaseUnoDispatchSlot c__uno_GoToEndOfPara = new BaseUnoDispatchSlot (".uno:GoToEndOfPara", null);
	BaseUnoDispatchSlot c__uno_GoToNextWord = new BaseUnoDispatchSlot (".uno:GoToNextWord", null);
	BaseUnoDispatchSlot c__uno_GoToPrevWord = new BaseUnoDispatchSlot (".uno:GoToPrevWord", null);
	BaseUnoDispatchSlot c__uno_Undo = new BaseUnoDispatchSlot (".uno:Undo", Uno_uno_UndoEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_GoToNextSentence = new BaseUnoDispatchSlot (".uno:GoToNextSentence", null);
	BaseUnoDispatchSlot c__uno_GoToPrevSentence = new BaseUnoDispatchSlot (".uno:GoToPrevSentence", null);
	BaseUnoDispatchSlot c__uno_DelToEndOfSentence = new BaseUnoDispatchSlot (".uno:DelToEndOfSentence", null);
	BaseUnoDispatchSlot c__uno_DelToStartOfSentence = new BaseUnoDispatchSlot (".uno:DelToStartOfSentence", null);
	BaseUnoDispatchSlot c__uno_Repeat = new BaseUnoDispatchSlot (".uno:Repeat", null);
	BaseUnoDispatchSlot c__uno_InsertMode = new BaseUnoDispatchSlot (".uno:InsertMode", null);
	BaseUnoDispatchSlot c__uno_Spacing = new BaseUnoDispatchSlot (".uno:Spacing", null);
	BaseUnoDispatchSlot c__uno_ParaStyle = new BaseUnoDispatchSlot (".uno:ParaStyle", null);
	BaseUnoDispatchSlot c__uno_NewStyle = new BaseUnoDispatchSlot (".uno:NewStyle", Uno_uno_NewStyleEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_EditStyle = new BaseUnoDispatchSlot (".uno:EditStyle", Uno_uno_EditStyleEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_DeleteStyle = new BaseUnoDispatchSlot (".uno:DeleteStyle", Uno_uno_DeleteStyleEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_StyleWatercanMode = new BaseUnoDispatchSlot (".uno:StyleWatercanMode", null);
	BaseUnoDispatchSlot c__uno_Italic = new BaseUnoDispatchSlot (".uno:Italic", null);
	BaseUnoDispatchSlot c__uno_Activate = new BaseUnoDispatchSlot (".uno:Activate", null);
	BaseUnoDispatchSlot c__uno_PrintOut = new BaseUnoDispatchSlot (".uno:PrintOut", Uno_uno_PrintOutEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_SaveAsTemplate = new BaseUnoDispatchSlot (".uno:SaveAsTemplate", Uno_uno_SaveAsTemplateEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_CloseDoc = new BaseUnoDispatchSlot (".uno:CloseDoc", Uno_uno_CloseDocEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_Print = new BaseUnoDispatchSlot (".uno:Print", Uno_uno_PrintEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_DocumentRepair = new BaseUnoDispatchSlot (".uno:DocumentRepair", null);
	BaseUnoDispatchSlot c__uno_CheckOut = new BaseUnoDispatchSlot (".uno:CheckOut", null);
	BaseUnoDispatchSlot c__uno_SaveAsRemote = new BaseUnoDispatchSlot (".uno:SaveAsRemote", Uno_uno_SaveAsRemoteEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_SaveSimple = new BaseUnoDispatchSlot (".uno:SaveSimple", null);
	BaseUnoDispatchSlot c__uno_DocInfoTitle = new BaseUnoDispatchSlot (".uno:DocInfoTitle", null);
	BaseUnoDispatchSlot c__uno_FullName = new BaseUnoDispatchSlot (".uno:FullName", null);
	BaseUnoDispatchSlot c__uno_DocPath = new BaseUnoDispatchSlot (".uno:DocPath", null); // not supported any more
	BaseUnoDispatchSlot c__uno_Title = new BaseUnoDispatchSlot (".uno:Title", Uno_uno_TitleEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_IsLoadingImages = new BaseUnoDispatchSlot (".uno:IsLoadingImages", null);
	BaseUnoDispatchSlot c__uno_ReadOnly = new BaseUnoDispatchSlot (".uno:ReadOnly", null);
	BaseUnoDispatchSlot c__uno_Keywords = new BaseUnoDispatchSlot (".uno:Keywords", Uno_uno_KeywordsEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_Comments = new BaseUnoDispatchSlot (".uno:Comments", Uno_uno_CommentsEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_Author = new BaseUnoDispatchSlot (".uno:Author", Uno_uno_AuthorEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_Saved = new BaseUnoDispatchSlot (".uno:Saved", null);
	BaseUnoDispatchSlot c__uno_ExportTo = new BaseUnoDispatchSlot (".uno:ExportTo", Uno_uno_ExportToEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_SaveACopy = new BaseUnoDispatchSlot (".uno:SaveACopy", Uno_uno_SaveACopyEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_Closing = new BaseUnoDispatchSlot (".uno:Closing", null);
	BaseUnoDispatchSlot c__uno_VersionDialog = new BaseUnoDispatchSlot (".uno:VersionDialog", null);
	BaseUnoDispatchSlot c__uno_Signature = new BaseUnoDispatchSlot (".uno:Signature", null);
	BaseUnoDispatchSlot c__uno_ExportToPDF = new BaseUnoDispatchSlot (".uno:ExportToPDF", Uno_uno_ExportToPDFEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_ExportDirectToPDF = new BaseUnoDispatchSlot (".uno:ExportDirectToPDF", Uno_uno_ExportDirectToPDFEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_ExportToEPUB = new BaseUnoDispatchSlot (".uno:ExportToEPUB", Uno_uno_ExportToEPUBEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_ExportDirectToEPUB = new BaseUnoDispatchSlot (".uno:ExportDirectToEPUB", Uno_uno_ExportDirectToEPUBEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_MacroSignature = new BaseUnoDispatchSlot (".uno:MacroSignature", null);
	BaseUnoDispatchSlot c__uno_Modified = new BaseUnoDispatchSlot (".uno:Modified", null);
	BaseUnoDispatchSlot c__uno_PrinterSetup = new BaseUnoDispatchSlot (".uno:PrinterSetup", null);
	BaseUnoDispatchSlot c__uno_Printer = new BaseUnoDispatchSlot (".uno:Printer", null);
	BaseUnoDispatchSlot c__uno_SendMail = new BaseUnoDispatchSlot (".uno:SendMail", Uno_uno_SendMailEnumerablePropertyNamesSet.c_instance);
	BaseUnoDispatchSlot c__uno_WebHtml = new BaseUnoDispatchSlot (".uno:WebHtml", null);
	BaseUnoDispatchSlot c__uno_About = new BaseUnoDispatchSlot (".uno:About", null);
	BaseUnoDispatchSlot c__uno_PrintDefault = new BaseUnoDispatchSlot (".uno:PrintDefault", null);
	BaseUnoDispatchSlot c__uno_ActualStyleFamily = new BaseUnoDispatchSlot (".uno:ActualStyleFamily", null);
	BaseUnoDispatchSlot c__uno_Reload = new BaseUnoDispatchSlot (".uno:Reload", null);
	BaseUnoDispatchSlot c__uno_FullScreen = new BaseUnoDispatchSlot (".uno:FullScreen", null);
	
	/*
	UpdateModuleSource
	UpdateAllModuleSources
	*/
	
	// Base class for all the constants in this group
	static class BaseUnoDispatchSlot {
		public final com.sun.star.util.URL c_urlInURL;
		public final BaseEnumerableConstantsGroup <String> c_unoDispatchArgumentPropertyNamesSet;
		
		BaseUnoDispatchSlot (String a_url, BaseEnumerableConstantsGroup <String> a_unoDispatchArgumentPropertyNamesSet) {
			c_urlInURL = UnoDatumConverter.getUrlInURL (a_url);
			c_unoDispatchArgumentPropertyNamesSet = a_unoDispatchArgumentPropertyNamesSet;
		}
	}
}

