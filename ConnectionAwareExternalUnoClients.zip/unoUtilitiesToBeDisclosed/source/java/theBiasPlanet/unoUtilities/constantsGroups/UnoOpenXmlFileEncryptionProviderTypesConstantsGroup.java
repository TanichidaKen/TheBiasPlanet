package theBiasPlanet.unoUtilities.constantsGroups;

public interface UnoOpenXmlFileEncryptionProviderTypesConstantsGroup {
	String c_invalid = "invalid";
	String c_rsaAes = "rsaAES";
	String c_rsaFull = "rsaFull";
}

