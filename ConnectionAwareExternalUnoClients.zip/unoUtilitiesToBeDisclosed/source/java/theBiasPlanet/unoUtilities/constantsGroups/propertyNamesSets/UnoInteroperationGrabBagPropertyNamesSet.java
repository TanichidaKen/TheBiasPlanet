package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

public interface UnoInteroperationGrabBagPropertyNamesSet extends UnoPropertyNamesSet {
	String c_documentProtection_sequenceOfPropertyValues = "DocumentProtection";
}

