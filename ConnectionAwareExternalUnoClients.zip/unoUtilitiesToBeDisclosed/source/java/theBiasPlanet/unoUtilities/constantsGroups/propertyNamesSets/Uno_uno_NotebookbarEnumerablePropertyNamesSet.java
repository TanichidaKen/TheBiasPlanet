package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_NotebookbarEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_filePath_string = "File";
	public static final Uno_uno_NotebookbarEnumerablePropertyNamesSet c_instance = new Uno_uno_NotebookbarEnumerablePropertyNamesSet ();
	
	private Uno_uno_NotebookbarEnumerablePropertyNamesSet () {
	}
}

