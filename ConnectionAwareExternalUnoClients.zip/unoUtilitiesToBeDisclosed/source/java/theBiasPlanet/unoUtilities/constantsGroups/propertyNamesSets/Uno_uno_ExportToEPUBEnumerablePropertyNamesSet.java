package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_ExportToEPUBEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_exportedFileUrl_string = "URL";
	public static final String c_filterName_string = "FilterName";
	
	public static final Uno_uno_ExportToEPUBEnumerablePropertyNamesSet c_instance = new Uno_uno_ExportToEPUBEnumerablePropertyNamesSet ();
	
	private Uno_uno_ExportToEPUBEnumerablePropertyNamesSet () {
	}
}

