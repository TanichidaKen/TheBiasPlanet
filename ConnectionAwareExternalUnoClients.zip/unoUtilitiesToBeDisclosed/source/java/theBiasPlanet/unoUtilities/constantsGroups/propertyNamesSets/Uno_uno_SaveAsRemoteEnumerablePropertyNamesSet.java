package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_SaveAsRemoteEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_fileUrl_string = "URL";
	public static final String c_filterName_string = "FilterName";
	public static final String c_password_string = "Password";
	public static final String c_showsPasswordDialog_boolean = "PasswordInteraction";
	public static final String c_filterOptions_string = "FilterOptions";
	public static final String c_versionComment_string = "VersionComment";
	public static final String c_versionAuthor_string = "VersionAuthor";
	public static final String c_overwrites_boolean = "Overwrite";
	public static final String c_unpacked_boolean = "Unpacked";
	public static final String c_notOpenedAs_boolean = "SaveTo";
	public static final Uno_uno_SaveAsRemoteEnumerablePropertyNamesSet c_instance = new Uno_uno_SaveAsRemoteEnumerablePropertyNamesSet ();
	
	private Uno_uno_SaveAsRemoteEnumerablePropertyNamesSet () {
	}
}

