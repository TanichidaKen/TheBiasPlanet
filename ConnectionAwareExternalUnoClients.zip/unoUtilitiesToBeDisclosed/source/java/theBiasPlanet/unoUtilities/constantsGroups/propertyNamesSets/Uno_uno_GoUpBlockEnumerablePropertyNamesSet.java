package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_GoUpBlockEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_numberOfPagesToGoUpBy_short = "By";
	public static final String c_whetherTheCellsAreSelected_boolean = "Sel"; // Whether the command is in the changing-the-sells-selection mode
	public static final Uno_uno_GoUpBlockEnumerablePropertyNamesSet c_instance = new Uno_uno_GoUpBlockEnumerablePropertyNamesSet ();
	
	private Uno_uno_GoUpBlockEnumerablePropertyNamesSet () {
	}
}

