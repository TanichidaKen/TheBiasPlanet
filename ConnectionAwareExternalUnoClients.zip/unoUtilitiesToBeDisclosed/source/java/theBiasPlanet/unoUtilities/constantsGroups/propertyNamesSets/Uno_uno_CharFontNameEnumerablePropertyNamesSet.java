package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_CharFontNameEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_styleName_string = "CharFontName.StyleName"; // like oblique, italic, narrow
	public static final String c_pitch_short = "CharFontName.Pitch"; // Use com::sun::star::awt::FontPitch: '0' -> unknown, '1' -> fixed, '2' -> variable
	public static final String c_charactersSetCode_short = "CharFontName.CharSet"; // Use com::sun::star::awt::CharSet : '9' -> system, '1' -> ANSI, '0' -> unknown
	public static final String c_familyCode_short = "CharFontName.Family"; // Use com::sun::star::awt::FontFamily: '6' -> system, '4' -> script font, '3' -> roman font, '0' -> unknown
	public static final String c_familyName_string = "CharFontName.FamilyName"; // like Times New Roman, Thorndale, Andale or Arial
	public static final Uno_uno_CharFontNameEnumerablePropertyNamesSet c_instance = new Uno_uno_CharFontNameEnumerablePropertyNamesSet ();
	
	private Uno_uno_CharFontNameEnumerablePropertyNamesSet () {
	}
}

