package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

public interface UnoTextDocumentPageStylePropertyNamesSet extends UnoDocumentTypesCommonPageStylePropertyNamesSet {
	String c_pageStyleIsPhysical_boolean = "IsPhysical"; // read only and usually 'true'; unknown how a page style can be un-physical<!--???-->
	/*
	String c_pageIsInStandardPageMode_boolean = "StandardPageMode"; // ??? grid standard mode always 'false' ; not preserved
	*/
	String c_nextStyleName_string = "FollowStyle"; // 'Standard'
	/*
	String c_contentsVerticalAdjustment_com.sun.star.drawing.TextVerticalAdjust = "TextVerticalAdjust"; // ??? TOP, CENTER, BOTTOM, BLOCK  not preserved
	*/
	String c_nameOfParagraphStyleAccordingToWhoseSpacingTextLinesAreAlignedInInvisibleLinesGrid_string = "RegisterParagraphStyle"; // the name of the paragraph style according to whose spacing the lines are aligned in an invisible lines grid
	String c_textColums_com_sun_star_text_XTextColumns = "TextColumns"; // the text columns object
	String c_pageBackgroundStyle_com_sun_star_drawing_FillStyle = "FillStyle"; // 'FillStyle.NONE' -> none, 'FillStyle.SOLID' -> solid color, 'FillStyle.GRADIENT' -> gradient, 'FillStyle.HATCH' -> hatch, 'FillStyle.BITMAP' -> graphic or pattern
	String c_pageBackgroundIsFilled_boolean = "FillBackground"; // the page background is filled 
	String c_pageBackgroundTransparency_short = "FillTransparence"; // the page background transparency in %
	String c_pageBackgroundTransparencyGradientName_string = "FillTransparenceGradientName"; // "" -> nothing, "Transparency 2", etc.
	String c_pageBackgroundTransparencyGradient_com_sun_star_awt_Gradient = "FillTransparenceGradient";
	String c_pageBackgroundColor_duplicate_com_sun_star_util_Color = "FillColor"; // the page background color (duplicate of 'BackColor')
	/*
	String c_pageBackground2ndaryColor_com_sun_star_util_Color = "FillColor2"; // ??? Unknown how this is used
	*/
	String c_pageBackgroundGradientName_string = "FillGradientName"; // the background color gradient name: seems to be 'gradient' for any gradient type
	String c_pageBackgroundGradient_com_sun_star_awt_Gradient = "FillGradient"; // the background gradient

	String c_numberOfStepsOfPageBackgroundGradient_short = "FillGradientStepCount"; // the number of steps of the page background gradient

	String c_pageBackgroundGraphicOrPatternName_string = "FillBitmapName"; // the background graphic or pattern name
	String c_pageBackgroundGraphicUrlDuplicate_string = "FillBitmapURL"; // the background graphics URL vnd.sun.star.GraphicObject:100000000000005E0000005EAB6862D59EF3F3E6  
	String c_pageBackgroundGraphic_com_sun_star_awt_XBitmap = "FillBitmap"; // the background graphic
	String c_pageBackgroundGraphicFittingMode_com_sun_star_drawing_BitmapMode = "FillBitmapMode"; // the background graphics fitting mode REPEAT, STRETCH, NO_REPEAT
	String c_pageBackgroundGraphicIsStretched_boolean = "FillBitmapStretch"; // the background graphics is stretched
	String c_pageBackgroundGraphicIsTiled_boolean = "FillBitmapTile"; // the background graphic is tiled
	String c_pageBackgroundGraphicTilingHorizontalOffset_long = "FillBitmapPositionOffsetX"; // the background graphics tiling horizontal offset in %
	String c_pageBackgroundGraphicTilingVerticalOffset_long = "FillBitmapPositionOffsetY"; // the background graphics tiling vertical offset in %
	String c_pageBackgroundGraphicTilingRowsShift_long = "FillBitmapOffsetX"; // the background graphics tiling horizontal rows shift in %
	String c_pageBackgroundGraphicTilingColumnsShift_long = "FillBitmapOffsetY";// the background graphics tiling horizontal columns shift in %
	/*
	String c_pageBackgroundGraphicSizeIsLogical_boolean = "FillBitmapLogicalSize"; // ??? always true not preserved otherwise
	*/
	String c_pageBackgroundGraphicWidth_long = "FillBitmapSizeX"; // the background graphic width in hundredths of a millimeter
	String c_pageBackgroundGraphicHeight_long = "FillBitmapSizeY"; // the background graphic height in hundredths of a millimeter
	String c_pageBackgroundGraphicLocationInPage_com_sun_star_drawing_RectanglePoint = "FillBitmapRectanglePoint"; // the background graphic's location in the page
	String c_pageBackgroundHatchName_string = "FillHatchName"; // the background hatch name
	String c_pageBackgroundHatch_com_sun_star_drawing_Hatch = "FillHatch"; // the background hatch
	String c_gridIsDisplayed_boolean = "GridDisplay"; // the grid is displayed
	String c_gridIsPrinted_boolean = "GridPrint"; // the grid is printed
	String c_gridMode_short = "GridMode"; // the grid mode: 0 -> none, 1 -> lines, 2 -> lines and characters
	String c_gridSnapsToCharacters_boolean = "GridSnapToChars"; // seems not to be able to be changed from 'true' ???
	String c_numberOfGridLines_unsignedShort = "GridLines"; // the number of grid lines
	String c_gridColor_com_sun_star_util_Color = "GridColor"; // the grid color
	String c_gridBaseTextsMaximumWidth_long = "GridBaseWidth"; // the grid base texts maximum width in hundredths of a millimeter
	String c_gridBaseTextsMaximumHeight_long = "GridBaseHeight"; // the grid base texts maximum height in hundredths of a millimeter
	String c_gridRubiesMaximumyHeight_long = "GridRubyHeight"; // the grid rubies maximum height 
	String c_gridRubiesAreShownOnLeftOfOrBelowBaseTexts_boolean = "RubyBelow"; // Rubies are shown on the left of or below the base texts
	/*
	String c_pageShadowTransparency_byte = "ShadowTransparence"; // ??? set where
	*/
	String c_firstPageDoesNotHaveSpecificHeaderOrFooter_boolean = "FirstIsShared"; // the first page does not have any specific header or footer
	String c_pageHeaderSynchronizedText_com_sun_star_text_XText = "HeaderText"; // the synchronized header text
	String c_firstPageHeaderText_com_sun_star_text_XText = "HeaderTextFirst"; // the first page header text
	String c_leftPageHeaderText_com_sun_star_text_XText = "HeaderTextLeft"; // the left page header text
	String c_rightPageHeaderText_com_sun_star_text_XText = "HeaderTextRight"; // the right page header text
	String c_pageHeaderBackgroundStyle_com_sun_star_drawing_FillStyle = "HeaderFillStyle"; // hatch, color, . .. 
	String c_pageHeaderSpacingIsChangedImplicitly_boolean = "HeaderDynamicSpacing"; // the header spacing is changed implicitly
	String c_pageHeaderBackgroundIsFilled_boolean = "HeaderFillBackground";
	String c_pageHeaderBackgroundTransparency_short = "HeaderFillTransparence"; // the transparency in %
	String c_pageHeaderBackgroundTransparencyGradientName_string = "HeaderFillTransparenceGradientName"; // like "Transparency 3"
	String c_pageHeaderBackgroundTransparencyGradient_com_sun_star_awt_Gradient = "HeaderFillTransparenceGradient"; // the gradient object
	String c_pageHeaderBackgroundColorDuplicate_com_sun_star_util_Color = "HeaderFillColor"; // the background color
	/*
	String c_pageHeaderBackground2ndaryColor_com_sun_star_util_Color = "HeaderFillColor2"; // ??? Unknown how this is used
	*/
	String c_pageHeaderBackgroundGradientName_string = "HeaderFillGradientName"; // the name "gradient" always???
	String c_pageHeaderBackgroundGradient_com_sun_star_awt_Gradient = "HeaderFillGradient"; // the gradient object
	String c_numberOfStepsOfPageHeaderBackgroundGradient_short = "HeaderFillGradientStepCount"; // the gradient steps count
	String c_pageHeaderBackgroundGraphicOrPatternName_string = "HeaderFillBitmapName"; // the name
	String c_pageHeaderBackgroundGraphicUrlDuplicate_string = "HeaderFillBitmapURL"; // the header background graphics URL like ???
	String c_pageHeaderBackgroundGraphic_com_sun_star_awt_XBitmap = "HeaderFillBitmap";
	String c_pageHeaderBackgroundGraphicFittingMode_com_sun_star_drawing_BitmapMode = "HeaderFillBitmapMode"; // REPEAT, STRETCH, NO_REPEAT
	String c_pageHeaderBackgroundGraphicIsStretched_boolean = "HeaderFillBitmapStretch"; // the header background graphics is stretched
	String c_pageHeaderBackgroundGraphicIsTiled_boolean = "HeaderFillBitmapTile"; // is tiled
	String c_pageHeaderBackgroundGraphicTilingHorizontalOffset_long = "HeaderFillBitmapPositionOffsetX"; // %
	String c_pageHeaderBackgroundGraphicTilingVerticalOffset_long = "HeaderFillBitmapPositionOffsetY"; // the page header background graphic tiling vertical offset
	String c_pageHeaderBackgroundGraphicTilingRowsShift_long = "HeaderFillBitmapOffsetX"; // 
	String c_pageHeaderBackgroundGraphicTilingColumnsShift_long = "HeaderFillBitmapOffsetY"; // 
	/*
	String c_pageHeaderBackgroundGraphicSizeIsLogical_boolean??? = "HeaderFillBitmapLogicalSize"; // ???
	*/
	String c_pageHeaderBackgroundGraphicWidth_long = "HeaderFillBitmapSizeX";
	String c_pageHeaderBackgroundGraphicHeight_long = "HeaderFillBitmapSizeY"; // the header background graphics height in hundredths of a millimeter
	String c_pageHeaderBackgroundGraphicLocationInHeader_com_sun_star_drawing_RectanglePoint = "HeaderFillBitmapRectanglePoint"; // the location

	String c_pageHeaderBackgroundHatchName_string = "HeaderFillHatchName"; // the headwer background hatch name
	String c_pageHeaderBackgroundHatch_com_sun_star_drawing_Hatch = "HeaderFillHatch"; // the hatch
	String c_pageFooterSynchronizedText_com_sun_star_text_Text = "FooterText";
	String c_firstPageFooterText_com_sun_star_text_XText = "FooterTextFirst";
	String c_leftPageFooterText_com_sun_star_text_XText = "FooterTextLeft";
	String c_rightPageFooterText_com_sun_star_text_XText = "FooterTextRight";
	String c_pageFooterBackgroundStyle_com_sun_star_drawing_FillStyle = "FooterFillStyle"; // hatch, color, . .. 
	String c_pageFooterSpacingIsChangedImplicitly_boolean = "FooterDynamicSpacing";
	String c_pageFooterBackgroundIsFilled_boolean = "FooterFillBackground";
	String c_pageFooterBackgroundTransparency_short = "FooterFillTransparence"; // the transparency in %$
	String c_pageFooterBackgroundTransparenceGradientName_string = "FooterFillTransparenceGradientName"; // like "Transparency 3"
	String c_pageFooterBackgroundTransparencyGradient_com_sun_star_awt_Gradient = "FooterFillTransparenceGradient";
	String c_pageFooterBackgroundColorDuplicate_com_sun_star_util_Color = "FooterFillColor";
	/*
	String c_pageFooterBackground2ndaryColor_com_sun_star_util_Color = "FooterFillColor2"; // ??? Unknown how this is used
	*/
	String c_pageFooterBackgroundGradientName_string = "FooterFillGradientName"; // the name "gradient" always???
	String c_pageFooterBackgroundGradient_com_sun_star_awt_Gradient = "FooterFillGradient"; // the footer gradient object
	String c_numberOfStepsOfPageFooterBackgroundGradient_short = "FooterFillGradientStepCount"; // the gradient steps count
	String c_pageFooterBackgroundGraphicOrPatternName_string = "FooterFillBitmapName";
	String c_pageFooterBackgroundGraphicUrlDuplicate_string = "FooterFillBitmapURL"; // the header background graphics URL like ???
	String c_pageFooterBackgroundGraphic_com_sun_star_awt_XBitmap = "FooterFillBitmap";
	String c_pageFooterBackgroundGraphicFittingMode_com_sun_star_drawing_BitmapMode = "FooterFillBitmapMode"; // REPEAT, STRETCH, NO_REPEAT
	String c_pageFooterBackgroundGraphicIsStretched_boolean = "FooterFillBitmapStretch";
	String c_pageFooterBackgroundGraphicIsTiled_boolean = "FooterFillBitmapTile";
	String c_pageFooterBackgroundGraphicTilingHorizontalOffset_long = "FooterFillBitmapPositionOffsetX";
	String c_pageFooterBackgroundGraphicTilingVerticalOffset_long = "FooterFillBitmapPositionOffsetY";
	String c_pageFooterBackgroundGraphicTilingRowsShift_long = "FooterFillBitmapOffsetX";
	String c_pageFooterBackgroundGraphicTilingColumnsShift_long = "FooterFillBitmapOffsetY";
	/*
	String c_pageFooterBackgroundGraphicSizeIsLogical_boolean = "FooterFillBitmapLogicalSize"; // 'true' always ???
	*/
	String c_pageFooterBackgroundGraphicWidth_long = "FooterFillBitmapSizeX";
	String c_pageFooterBackgroundGraphicHeight_long = "FooterFillBitmapSizeY";
	String c_pageFooterBackgroundGraphicLocationInFooter_com_sun_star_drawing_RectanglePoint = "FooterFillBitmapRectanglePoint";
	String c_pageFooterBackgroundHatchName_string = "FooterFillHatchName";
	String c_pageFooterBackgroundHatch_com_sun_star_drawing_Hatch = "FooterFillHatch";
	
	String c_footnoteMaximumHeight_long = "FootnoteHeight"; // the footnote maximum height in hundredths of a millimeter
	String c_footnoteSpacing_long = "FootnoteLineTextDistance"; // space to main text in hundredths of a millimeter
	String c_footnoteLineStyle_byte = "FootnoteLineStyle"; // 0, -> none, 1 -> solid, etc.
	String c_footnoteLineWeight_short = "FootnoteLineWeight"; // Thickness 35 -> 1.00pt
	String c_footnoteLineColor_com_sun_star_util_Color = "FootnoteLineColor"; // color
	String c_footnoteSeparatorLineLocation_short = "FootnoteLineAdjust"; // the footnote separator line location 0 -> left, 1 -> center, 2 -> right
	String c_footnoteSeparatorLineRelativeWidth_byte = "FootnoteLineRelativeWidth"; // in % 
	String c_footnoteSeparatorLinePadding_long = "FootnoteLineDistance"; // padding to the footnote contents in hundredths of a millimeter
	// Invalid at least now String c_textLinesAreAlignedInInvisibleLinesGrid_boolean = "RegisterModeActive";
}

