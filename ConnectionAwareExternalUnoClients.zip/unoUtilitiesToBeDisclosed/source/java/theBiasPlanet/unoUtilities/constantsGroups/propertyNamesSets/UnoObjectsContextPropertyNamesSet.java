package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.unoUtilities.constantsGroups.UnoGeneralConstantsConstantsGroup;

public interface UnoObjectsContextPropertyNamesSet {
	String c_identification_string = "identification";
	String c_unoDesktopSingleton_string = String.format (UnoGeneralConstantsConstantsGroup.c_singletonUrlFormat, "theBiasPlanet.unoUtilities.displayElements");
}

