package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.unoUtilities.constantsGroups.UnoGeneralConstantsConstantsGroup;

public interface UnoObjectsContextPropertyNamesSet {
	String c_unoConnectionIdentification_string = "unoConnectionIdentification";
	String c_unoConnectionSingleton_string = String.format (UnoGeneralConstantsConstantsGroup.c_singletonUrlFormat, "theBiasPlanet.unoUtilities.connection.UnoConnection");
	String c_unoDesktopSingleton_string = String.format (UnoGeneralConstantsConstantsGroup.c_singletonUrlFormat, "theBiasPlanet.unoUtilities.displayElements.UnoDesktop");
}

