package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_SaveEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_versionCommment_string = "VersionComment";
	public static final String c_author_string = "Author";
	public static final String c_doNotTerminateEditing_boolean = "DontTerminateEdit";
	public static final String c_noFileSynchronization_boolean = "NoFileSync"; // the meaning unknown
	public static final Uno_uno_SaveEnumerablePropertyNamesSet c_instance = new Uno_uno_SaveEnumerablePropertyNamesSet ();
	
	private Uno_uno_SaveEnumerablePropertyNamesSet () {
	}
}

