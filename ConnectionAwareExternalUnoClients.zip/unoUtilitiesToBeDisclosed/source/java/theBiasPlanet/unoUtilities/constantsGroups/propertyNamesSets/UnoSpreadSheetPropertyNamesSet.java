package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

public interface UnoSpreadSheetPropertyNamesSet extends UnoPropertyNamesSet {
	String c_whetherIsVisible_boolean = "IsVisible";
	String c_pageStyle = "PageStyle";
}

