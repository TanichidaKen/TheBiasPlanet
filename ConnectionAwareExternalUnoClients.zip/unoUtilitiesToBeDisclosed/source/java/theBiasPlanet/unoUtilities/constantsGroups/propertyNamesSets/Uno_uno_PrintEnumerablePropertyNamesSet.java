package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_PrintEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_printerName_string = "PrinterName";
	public static final String c_fileName_string = "FileName";
	public static final String c_numberOfCopies_short = "Copies";
	public static final String c_pagesRangeText_string = "RangeText";
	public static final String c_doesOnlySelection_boolean = "Selection";
	//public static final String c_doesOnlySelection_boolean = "PrintSelectionOnly";
	public static final String c_doesAsynchronously_boolean = "Asynchron";
	public static final String c_collates_boolean = "Collate";
	public static final String c_doesSilently_boolean = "Silent";
	public static final Uno_uno_PrintEnumerablePropertyNamesSet c_instance = new Uno_uno_PrintEnumerablePropertyNamesSet ();
	
	private Uno_uno_PrintEnumerablePropertyNamesSet () {
	}
}

