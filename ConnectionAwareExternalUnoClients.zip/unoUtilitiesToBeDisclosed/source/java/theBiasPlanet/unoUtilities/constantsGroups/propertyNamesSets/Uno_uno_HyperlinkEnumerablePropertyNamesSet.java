package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_HyperlinkEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_text_string = "Hyperlink.Text";
	public static final String c_url_string = "Hyperlink.URL";
	public static final String c_target_string = "Hyperlink.Target"; // '_self' etc.?
	public static final String c_name_string = "Hyperlink.Name";
	public static final String c_type_short = "Hyperlink.Type"; // '1' -> text, '2' -> button
	public static final Uno_uno_HyperlinkEnumerablePropertyNamesSet c_instance = new Uno_uno_HyperlinkEnumerablePropertyNamesSet ();
	
	private Uno_uno_HyperlinkEnumerablePropertyNamesSet () {
	}
}

