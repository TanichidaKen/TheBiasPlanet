package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

public interface UnoSpreadSheetCellValueExpressionFormatPropertyNamesSet extends UnoPropertyNamesSet {
	String c_formatString = "FormatString";
}

