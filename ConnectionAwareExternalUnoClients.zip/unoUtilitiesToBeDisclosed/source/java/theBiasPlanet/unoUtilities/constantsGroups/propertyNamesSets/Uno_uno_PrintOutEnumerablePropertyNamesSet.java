package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_PrintOutEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	
	public static final String c_numberOfCopies_short = "copies";
	public static final String c_doesSilently_boolean = "silent";
	public static final Uno_uno_PrintOutEnumerablePropertyNamesSet c_instance = new Uno_uno_PrintOutEnumerablePropertyNamesSet ();
	
	private Uno_uno_PrintOutEnumerablePropertyNamesSet () {
	}
}

