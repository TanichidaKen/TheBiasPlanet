package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

public interface UnoTextPageCursorPropertyNamesSet extends UnoPropertyNamesSet {
	String c_pageStyleName_string = "PageStyleName";
}

