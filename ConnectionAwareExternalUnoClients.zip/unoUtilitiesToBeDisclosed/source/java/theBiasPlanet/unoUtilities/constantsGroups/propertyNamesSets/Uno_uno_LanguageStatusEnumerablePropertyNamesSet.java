package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_LanguageStatusEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_language_string = "Language";
	public static final Uno_uno_LanguageStatusEnumerablePropertyNamesSet c_instance = new Uno_uno_LanguageStatusEnumerablePropertyNamesSet ();
	
	private Uno_uno_LanguageStatusEnumerablePropertyNamesSet () {
	}
}

