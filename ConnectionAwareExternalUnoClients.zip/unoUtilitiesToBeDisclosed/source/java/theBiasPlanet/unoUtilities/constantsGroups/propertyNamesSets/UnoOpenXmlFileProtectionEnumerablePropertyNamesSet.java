package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class UnoOpenXmlFileProtectionEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_protectionMode_string = "edit";
	public static final String c_protectionIsEnforced_string = "enforcement";
	public static final String c_formatIsProtected_string = "formatting";
	public static final String c_encryptionProviderType_string = "cryptProviderType";
	public static final String c_encryptionAlgorithmClass_string = "cryptAlgorithmClass";
	public static final String c_encryptionAlgorithmType_string = "cryptAlgorithmType";
	public static final String c_encryptionAlgorithmIdentification_string = "cryptAlgorithmSid";
	public static final String c_encryptionSpinsCount_string = "cryptSpinCount";
	public static final String c_encryptionHashedPassword_string = "hash";
	public static final String c_encryptionPasswordSalt_string = "salt";

	public static final UnoOpenXmlFileProtectionEnumerablePropertyNamesSet c_instance = new UnoOpenXmlFileProtectionEnumerablePropertyNamesSet ();
	
	private UnoOpenXmlFileProtectionEnumerablePropertyNamesSet () {
	}
}

