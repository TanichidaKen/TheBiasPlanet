package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class UnoDispatchesCommonArgumentEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_synchronousMode_boolean = "SynchronMode";
	public static final UnoDispatchesCommonArgumentEnumerablePropertyNamesSet c_instance = new UnoDispatchesCommonArgumentEnumerablePropertyNamesSet ();
	
	private UnoDispatchesCommonArgumentEnumerablePropertyNamesSet () {
	}
}

