package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_TitleEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_namesake_string = "Title";
	public static final Uno_uno_TitleEnumerablePropertyNamesSet c_instance = new Uno_uno_TitleEnumerablePropertyNamesSet ();
	
	private Uno_uno_TitleEnumerablePropertyNamesSet () {
	}
}

