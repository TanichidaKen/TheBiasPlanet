package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_RedoEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_numberOfExecution_short = "Redo";
	public static final String c_dummy0_boolean = "Repair";
	public static final Uno_uno_RedoEnumerablePropertyNamesSet c_instance = new Uno_uno_RedoEnumerablePropertyNamesSet ();
	
	private Uno_uno_RedoEnumerablePropertyNamesSet () {
	}
}

