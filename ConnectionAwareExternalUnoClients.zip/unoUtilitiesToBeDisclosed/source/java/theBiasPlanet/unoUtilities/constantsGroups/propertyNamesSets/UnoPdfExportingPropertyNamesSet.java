package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

public interface UnoPdfExportingPropertyNamesSet extends UnoPropertyNamesSet {
	// General
	String c_pagesRangeSpecification_string = "PageRange"; // '' -> all the pages, '1-2,4', etc.
	String c_exportedSections_any = "Selection"; // the selection gotten by 'XSelectionSupplier.getSelection ()' of the controller of the document, or an arbitrary object (for example, a cells range)
	String c_losslessCompressionIsUsed_boolean = "UseLosslessCompression"; // 'false' -> a JPEG compression is used
	String c_jpegQuality_short = "Quality"; // in %
	String c_imageResolutionsAreReduced_boolean = "ReduceImageResolution";
	String c_maximumImageResolution_short = "MaxImageResolution"; // in DPI: 75, 150, 300, 600, or 1200
	String c_watermarkString_string = "Watermark";
	String c_originalDocumentIsEmbedded_boolean = "IsAddStream";
	String c_pdfVersionCode_short = "SelectPdfVersion"; // '0' -> PDF 1.4, '1' -> PDF/A-1
	String c_taggedPdfIsUsed_boolean = "UseTaggedPDF";
	String c_formFieldsAreExported_boolean = "ExportFormFields";
	String c_formsTypeCode_short = "FormsType"; // '0' -> FDF, '1' -> PDF, '2' -> HTML, '3' -> XML
	String c_someDuplicateFieldNamesAreAllowed_boolean = "AllowDuplicateFieldNames";
	String c_bookmarksAreExported_boolean = "ExportBookmarks";
	String c_placeholdersAreExported_boolean = "ExportPlaceholders";
	String c_commentsAreExported_boolean = "ExportNotes";
	String c_automaticallyInsertedEmptyPagesAreSkipped_boolean = "IsSkipEmptyPages";
	String c_formXobjectsAreUsed_boolean = "UseReferenceXObject";
	String c_targetFileIsShownAfterExportingHasBeenCompleted_boolean = "ViewPDFAfterExport";
	// Initial View
	String c_forAfterExportingShowingOfTargetFileInitialViewStyleCode_short = "InitialView"; // '0' -> pages only, '1' -> bookmarks and pages, '2' -> thumbnails and pages
	String c_forAfterExportingShowingOfTargetFileInitialPageNumber_short = "InitialPage";
	String c_forAfterExportingShowingOfTargetFileInitialMagnificationTypeCode_short = "Magnification"; // '0' -> default, '1' -> the whole page is fitted into the window, '2' -> the page width is fitted into the window, '3' -> the page contents are supposed to be fitted into the window, but not necessarily are so
	String c_forAfterExportingShowingOfTargetFileInitialZoomFactor_short = "Zoom"; // in %
	String c_forAfterExportingShowingOfTargetFileInitialPageLayoutStyleCode_short = "PageLayout"; // '0' -> default, '1' -> single page, '2' -> continuous, '3' -> each 2 facing pages are shown abreast and those pairs are shown continuously connected vertically
	String c_forAfterExportingShowingOfTargetFileFirstPageIsOnLeft_boolean = "FirstPageOnLeft"; // valid only when 'PageLayout' is '3'
	// User Interface
	String c_forAfterExportingShowingOfTargetFileWindowIsResizedToInitialPage_boolean = "ResizeWindowToInitialPage";
	String c_forAfterExportingShowingOfTargetFileWindowIsCenteredOnScreen_boolean = "CenterWindow";
	String c_forAfterExportingShowingOfTargetFileWindowIsOpenedInFullScreenMode_boolean = "OpenInFullScreenMode";
	String c_forAfterExportingShowingOfTargetFileDocumentTitleIsShown_boolean = "DisplayPDFDocumentTitle";
	String c_forAfterExportingShowingOfTargetFileTransitionEffectsAreUsed_boolean = "UseTransitionEffects";
	String c_forAfterExportingShowingOfTargetFileMenubarIsHidden_boolean = "HideViewerMenubar";
	String c_forAfterExportingShowingOfTargetFileToolbarIsHidden_boolean = "HideViewerToolbar";
	String c_forAfterExportingShowingOfTargetFileWindowControlsAreHidden_boolean = "HideViewerWindowControls";
	String c_forAfterExportingShowingOfTargetFileOpenedBookmarkLevels_short = "OpenBookmarkLevels"; // '-1' -> all
	// Links
	String c_bookmarksAreExportedAsNamedDestinations_boolean = " ExportBookmarksToPDFDestination";
	String c_documentLinksAreConvertedToPdfTargets_boolean = "ConvertOOoTargetToPDFTarget";
	String c_relativeFileLinksAreExported_boolean = "ExportLinksRelativeFsys";
	String c_crossDocumentsLinksViewerCode_short = "PDFViewSelection"; // '0' -> the default viewer, '1' -> a PDF reader application, '2' -> an internet browser
	// Security
	String c_fileIsEncrypted_boolean = "EncryptFile";
	String c_openingPassword_string = "DocumentOpenPassword";
	String c_someActionsAreRestricted_boolean = "RestrictPermissions";
	String c_restrictedActionsPassword_string = "PermissionPassword";
	String c_printingRestrictionCode_short = "Printing"; // '0' -> not permitted, '1' -> only in a low resolution (150 DPI), '2' -> also in high resolutions
	String c_changingRestrictionCode_short = "Changes"; // '0' -> not permitted, '1' -> inserting, deleting, and rotating pages, '2' -> filling in form fields, '3' -> commenting and filling in form fields, '4' -> any except extracting pages
	String c_copyingOfContentsIsAllowed_boolean = "EnableCopyingOfContent";
	String c_textAccessForAccessibilityToolsIsAllowed_boolean = "EnableTextAccessForAccessibilityTools";
	// Digital Signature
	String c_fileIsSigned_boolean = "SignPDF";
	String c_signatureCertificate_com_sun_star_security_XCertificate = "SignatureCertificate";
	String c_signatureCertificatePassword_string = "SignaturePassword";
	String c_signatureLocation_string = "SignatureLocation";
	String c_signatureReason_string = "SignatureReason";
	String c_signatureContactInformation_string = "SignatureContactInfo";
	String c_signatureTimeStampAuthorityUrl_string = "SignatureTSA";
}

