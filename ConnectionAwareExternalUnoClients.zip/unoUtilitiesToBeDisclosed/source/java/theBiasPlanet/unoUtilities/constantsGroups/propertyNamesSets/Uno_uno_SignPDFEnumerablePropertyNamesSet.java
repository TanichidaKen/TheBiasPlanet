package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_SignPDFEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_sourceFileUrl_string = "URL";
	public static final String c_fileOpeningFilterName_string = "FilterName";
	public static final String c_fileOpeningFlags_string = "OpenFlags";
	public static final String c_fileOpeningPassword_string = "Password";
	public static final String c_documentStoringFilterData_string = "FilterOptions";
	public static final String c_targetFilePdfVersion_short = "Version";
	public static final String c_targetFileReferer_short = "Referer";
	public static final String c_targetFileDirectoryPath_short = "SuggestedSaveAsDir";
	public static final String c_targetFileName_short = "SuggestedSaveAsName";
	public static final Uno_uno_SignPDFEnumerablePropertyNamesSet c_instance = new Uno_uno_SignPDFEnumerablePropertyNamesSet ();
	
	private Uno_uno_SignPDFEnumerablePropertyNamesSet () {
	}
}

