package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_SaveACopyEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_exportedFileUrl_string = "URL";
	public static final String c_filterName_string = "FilterName";
	public static final String c_overwrites_boolean = "Overwrite";
	public static final String c_filterOptions_string = "FilterOptions";
	public static final String c_savedAsACopy_boolean = "SaveACopy";
	
	public static final Uno_uno_SaveACopyEnumerablePropertyNamesSet c_instance = new Uno_uno_SaveACopyEnumerablePropertyNamesSet ();
	
	private Uno_uno_SaveACopyEnumerablePropertyNamesSet () {
	}
}

