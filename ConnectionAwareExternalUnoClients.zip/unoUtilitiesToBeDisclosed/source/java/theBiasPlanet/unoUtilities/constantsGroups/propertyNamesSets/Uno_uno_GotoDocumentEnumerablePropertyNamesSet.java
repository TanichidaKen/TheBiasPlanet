package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_GotoDocumentEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_documentName_string = "DocName";
	public static final Uno_uno_GotoDocumentEnumerablePropertyNamesSet c_instance = new Uno_uno_GotoDocumentEnumerablePropertyNamesSet ();
	
	private Uno_uno_GotoDocumentEnumerablePropertyNamesSet () {
	}
}

