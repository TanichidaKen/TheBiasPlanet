package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_SearchAllEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_searchedForString_string = "SearchString";
	
	public static final Uno_uno_SearchAllEnumerablePropertyNamesSet c_instance = new Uno_uno_SearchAllEnumerablePropertyNamesSet ();
	
	private Uno_uno_SearchAllEnumerablePropertyNamesSet () {
	}
}

