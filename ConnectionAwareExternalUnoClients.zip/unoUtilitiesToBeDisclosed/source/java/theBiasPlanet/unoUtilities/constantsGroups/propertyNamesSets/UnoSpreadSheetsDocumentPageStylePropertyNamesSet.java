package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

public interface UnoSpreadSheetsDocumentPageStylePropertyNamesSet extends UnoDocumentTypesCommonPageStylePropertyNamesSet {
	String c_rowHeadersAndColumnHeadersArePrinted_boolean = "PrintHeaders";
	String c_gridIsPrinted_boolean = "PrintGrid"; 
	String c_zerosArePrinted_boolean = "PrintZeroValues";
	String c_auxiliaryObjectsArePrinted_boolean = "PrintObjects";
	String c_formulaeArePrinted_boolean = "PrintFormulas"; 
	String c_chartsArePrinted_boolean = "PrintCharts"; 
	String c_shapesArePrinted_boolean = "PrintDrawing";
	String c_commentsArePrinted_boolean = "PrintAnnotations";
	String c_pagesArePrintedDownwardFirst_boolean = "PrintDownFirst";
	String c_firstPageNumber_short = "FirstPageNumber";
	String c_pageScale_short = "PageScale";
	String c_numberOfPagesForPrintToFitIn_short ="ScaleToPages";
	String c_horizontalNumberOfPagesForPrintToFitIn_short = "ScaleToPagesX";
	String c_verticalNumberOfPagesForPrintToFitIn_short  = "ScaleToPagesY";
	String c_contentsAreCenteredHorizontally_boolean = "CenterHorizontally";
	String c_contentsAreCenteredVertically_boolean = "CenterVertically";
	String c_pageBackgroundIsTransparent_duplicate_boolean = "IsBackgroundTransparent";
	String c_pageBackgroundColor_duplicate_com_sun_star_util_Color = "BackgroundColor";
	String c_pageHeaderIsPrinted_duplicate_boolean = "HeaderOn";
	String c_pageHeaderIsSharedAmongLefPagesAndRightPages_duplicate_boolean = "HeaderShared";
	String c_leftPageHeaderContents_com_sun_star_sheet_XHeaderFooterContent = "LeftPageHeaderContent";
	String c_rightPageHeaderContents_com_sun_star_sheet_XHeaderFooterContent = "RightPageHeaderContent";
	String c_pageHeaderHeightIsChangedImplicitly_duplicate_boolean = "HeaderDynamic";
	String c_pageHeaderBackgroundIsTransparent_duplicate_boolean = "TransparentHeaderBackground";
	String c_pageHeaderBackgroundColor_duplicate_com_sun_star_util_Color = "HeaderBackgroundColor";
	String c_pageFooterIsPrinted_duplicate_boolean = "FooterOn";
	String c_pageFooterIsSharedAmongLeftPagesAndRightPages_duplicate_boolean = "FooterShared";
	String c_leftPageFooterContents_com_sun_star_sheet_XHeaderFooterContent = "LeftPageFooterContent";
	String c_rightPageFooterContents_com_sun_star_sheet_XHeaderFooterContent = "RightPageFooterContent";
	String c_pageFooterHeightChangesImplicitly_duplicate_boolean = "FooterDynamic";
	String c_pageFooterBackgroundIsTransparent_duplicate_boolean = "TransparentFooterBackground";
	String c_pageFooterBackgroundColor_duplicate_com_sun_star_util_Color = "FooterBackgroundColor";
}

