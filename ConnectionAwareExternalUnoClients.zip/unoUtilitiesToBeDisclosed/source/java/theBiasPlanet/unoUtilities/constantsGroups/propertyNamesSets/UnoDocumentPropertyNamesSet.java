package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

public interface UnoDocumentPropertyNamesSet extends UnoPropertyNamesSet {
	String c_interoperationGrabBag_sequenceOfPropertyValues = "InteropGrabBag";
}

