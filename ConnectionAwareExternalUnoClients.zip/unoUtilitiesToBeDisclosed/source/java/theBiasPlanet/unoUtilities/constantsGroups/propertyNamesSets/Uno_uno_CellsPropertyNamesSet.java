package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

public interface Uno_uno_CellsPropertyNamesSet extends UnoPropertyNamesSet {
	String c_columnIndex_short = "Column";
	String c_rowIndex_int = "Row";
	String c_tableIndex_short = "Table";
}

