package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_ShowEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_spreadSheetName_string = "aTableName";
	public static final Uno_uno_ShowEnumerablePropertyNamesSet c_instance = new Uno_uno_ShowEnumerablePropertyNamesSet ();
	
	private Uno_uno_ShowEnumerablePropertyNamesSet () {
	}
}

