package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

public interface UnoSpreadSheetCellsRangePropertyNamesSet extends UnoPropertyNamesSet {
	String c_absoluteName = "AbsoluteName";
}

