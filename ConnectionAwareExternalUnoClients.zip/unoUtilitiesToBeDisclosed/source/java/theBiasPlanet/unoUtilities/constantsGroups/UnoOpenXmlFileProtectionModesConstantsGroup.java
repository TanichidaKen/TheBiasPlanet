package theBiasPlanet.unoUtilities.constantsGroups;

public interface UnoOpenXmlFileProtectionModesConstantsGroup {
	String c_none = "none";
	String c_whole = "readOnly";
	String c_comments = "comments";
	String c_trackedChanges = "trackedChanges";
	String c_forms = "forms";
}

