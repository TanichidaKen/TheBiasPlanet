package theBiasPlanet.unoUtilities.documents;

//import java.util.List;
import java.util.Map;
import java.util.HashMap;
import com.sun.star.beans.XPropertySet;
import com.sun.star.beans.UnknownPropertyException;
import com.sun.star.container.XIndexAccess;
import com.sun.star.container.XNameContainer;
import com.sun.star.container.NoSuchElementException;
import com.sun.star.frame.XModel;
import com.sun.star.lang.Locale;
import com.sun.star.lang.WrappedTargetException;
import com.sun.star.sheet.XSpreadsheetDocument;
import com.sun.star.sheet.XSpreadsheet;
import com.sun.star.sheet.XSpreadsheets;
import com.sun.star.sheet.XSpreadsheetView;
import com.sun.star.style.XStyleFamiliesSupplier;
import com.sun.star.uno.AnyConverter;
//import com.sun.star.uno.Any;
import com.sun.star.uno.UnoRuntime;
import com.sun.star.uno.XInterface;
import com.sun.star.util.XNumberFormatsSupplier;
import com.sun.star.util.XNumberFormats;
import com.sun.star.util.MalformedNumberFormatException;
import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.displayElements.UnoDesktop;
import theBiasPlanet.unoUtilities.documents.UnoDocument;
import theBiasPlanet.unoUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.*;
import theBiasPlanet.unoUtilities.documentElements.UnoSpreadSheet;
import theBiasPlanet.unoUtilities.pointers.UnoObjectPointer;
import theBiasPlanet.unoUtilities.unoDataHandling.UnoDatumConverter;
import theBiasPlanet.unoUtilities.unoObjectsContexts.RemoteUnoObjectsContext;

public class UnoSpreadSheetsDocument extends UnoDocument {
	private UnoObjectPointer <XSpreadsheets> i_sheets = null;
	//private XDispatchHelper i_dispatchHelperInXDispatchHelper;
	private Locale i_defaultLocale;
	private UnoObjectPointer <XNumberFormats> i_cellValueExpressionFormats = null;
	private int i_dateExpressionFormatKey;
	private int i_timeExpressionFormatKey;
	private int i_dateAndTimeExpressionFormatKey;
	private int i_booleanExpressionFormatKey;
	private int i_stringExpressionFormatKey;
	private int i_integerExpressionFormatKey;
	private Map <Integer, Integer> i_numberOfDecimalPlacesToDoubleExpressionFormatKeyMap;
	private Map <Integer, Integer> i_doubleExpressionFormatKeyToNumberOfDecimalPlacesMap;
	
	public static UnoSpreadSheetsDocument createDocument (UnoDesktop a_unoDesktop, boolean a_unoDocumentIsHidden) throws Exception, com.sun.star.io.IOException {
		return new UnoSpreadSheetsDocument (a_unoDesktop.getRemoteUnoObjectsContext (), a_unoDesktop.loadUnoDocument (UnoSpecialFileUrlsConstantsGroup.c_calcNewDocument, null, a_unoDocumentIsHidden));
	}
	
	public static UnoSpreadSheetsDocument openFile (UnoDesktop a_unoDesktop, String a_fileUrl, String a_password, boolean a_unoDocumentIsHidden) throws Exception, com.sun.star.io.IOException {
		return new UnoSpreadSheetsDocument (a_unoDesktop.getRemoteUnoObjectsContext (), a_unoDesktop.loadUnoDocument (a_fileUrl, a_password, a_unoDocumentIsHidden));
	}
	
	public static UnoSpreadSheetsDocument getCurrentDocument (UnoDesktop a_unoDesktop) throws Exception {
		return new UnoSpreadSheetsDocument (a_unoDesktop.getRemoteUnoObjectsContext (), a_unoDesktop.getCurrentDocument ());
	}
	
	public static UnoSpreadSheetsDocument getDocument (UnoDesktop a_unoDesktop, String a_fileName) throws Exception {
		return new UnoSpreadSheetsDocument (a_unoDesktop.getRemoteUnoObjectsContext (), a_unoDesktop.getDocument (a_fileName));
	}
	
	/*
	public static XCertificate getCertificateInXCertificate (RemoteUnoObjectsContext a_remoteUnoObjectsContext, String a_issuerName, byte [] a_serialNumber) throws com.sun.star.uno.Exception {
		XSecurityEnvironment l_securityEnvironmentInXSecurityEnvironment = (XSecurityEnvironment) a_remoteUnoObjectsContext.getUnoServiceInstance (UnoServiceNamesConstantsGroup.c_com_sun_star_xml_crypto_SecurityEnvironment, XSecurityEnvironment.class, null);
		//XCertificate l_certificateInXCertificate = l_securityEnvironmentInXSecurityEnvironment.getCertificate (a_issuerName, a_serialNumber);
		XCertificate [] l_certificatesArrayInXCertificate = l_securityEnvironmentInXSecurityEnvironment.getPersonalCertificates ();
		if (l_certificatesArrayInXCertificate != null) {
			for (XCertificate l_certificateInXCertificate: l_certificatesArrayInXCertificate) {
				byte [] l_serialNumber = l_certificateInXCertificate.getSerialNumber ();
				if (a_issuerName.equals (l_certificateInXCertificate.getIssuerName ()) && a_serialNumber.length == l_serialNumber.length) {
					int l_serialNumberByteIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
					for (byte l_serialNumberByte: l_serialNumber) {
						if (a_serialNumber [l_serialNumberByteIndex] != l_serialNumberByte) {
							break;
						}
						l_serialNumberByteIndex ++;
					}
					if (l_serialNumberByteIndex == l_serialNumber.length) {
						return l_certificateInXCertificate;
					}
				}
			}
		}
		return null;
	}
	*/
	
	public UnoSpreadSheetsDocument (RemoteUnoObjectsContext a_remoteUnoObjectsContext, UnoObjectPointer <XModel> a_underlyingUnoObject) throws Exception, MalformedNumberFormatException {
		super (a_remoteUnoObjectsContext, a_underlyingUnoObject);
		if (i_underlyingUnoObject. <XSpreadsheetDocument>getAddress (XSpreadsheetDocument.class) == null) {
			throw new Exception (UnoMessagesConstantsGroup.c_isNotSpreadSheetsDocument);
		}
		i_defaultLocale = new Locale ();
		i_cellValueExpressionFormats = new UnoObjectPointer <XNumberFormats> (i_underlyingUnoObject. <XNumberFormatsSupplier>getAddress (XNumberFormatsSupplier.class).getNumberFormats ());
		i_dateExpressionFormatKey = getAndSetIfNecessaryCellValueExpressionFormatKey (UnoSpreadSheetCellFormatStringsConstantsGroup.c_standardDate);
		i_timeExpressionFormatKey = getAndSetIfNecessaryCellValueExpressionFormatKey (UnoSpreadSheetCellFormatStringsConstantsGroup.c_standardTime);
		i_dateAndTimeExpressionFormatKey = getAndSetIfNecessaryCellValueExpressionFormatKey (UnoSpreadSheetCellFormatStringsConstantsGroup.c_standardDateAndTime);
		i_booleanExpressionFormatKey = getAndSetIfNecessaryCellValueExpressionFormatKey (UnoSpreadSheetCellFormatStringsConstantsGroup.c_standardBoolean);
		i_stringExpressionFormatKey = getAndSetIfNecessaryCellValueExpressionFormatKey (UnoSpreadSheetCellFormatStringsConstantsGroup.c_standardString);
		i_integerExpressionFormatKey = getAndSetIfNecessaryCellValueExpressionFormatKey (UnoSpreadSheetCellFormatStringsConstantsGroup.c_standardInteger);
		i_numberOfDecimalPlacesToDoubleExpressionFormatKeyMap = new HashMap <Integer, Integer> ();
		i_doubleExpressionFormatKeyToNumberOfDecimalPlacesMap = new HashMap <Integer, Integer> ();
		int l_doubleDefaultExpressionFormatKey = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		l_doubleDefaultExpressionFormatKey = i_cellValueExpressionFormats.getAddress ().queryKey (UnoSpreadSheetCellFormatStringsConstantsGroup.c_globalNumber, i_defaultLocale, false);
		if (l_doubleDefaultExpressionFormatKey == GeneralConstantsConstantsGroup.c_unspecifiedInteger) {
			l_doubleDefaultExpressionFormatKey = i_cellValueExpressionFormats.getAddress ().queryKey (UnoSpreadSheetCellFormatStringsConstantsGroup.c_standardNumber, i_defaultLocale, false);
		}
		if (l_doubleDefaultExpressionFormatKey == GeneralConstantsConstantsGroup.c_unspecifiedInteger) {
			// Doesn't seem possible
		}
		else {
			Integer l_defaultNumberOfDecimalPlaces = Integer.valueOf (GeneralConstantsConstantsGroup.c_unspecifiedInteger);
			Integer l_doubleDefaultExpressionFormatKeyInInteger = Integer.valueOf (l_doubleDefaultExpressionFormatKey);
			i_numberOfDecimalPlacesToDoubleExpressionFormatKeyMap.put (l_defaultNumberOfDecimalPlaces, l_doubleDefaultExpressionFormatKeyInInteger);
			i_doubleExpressionFormatKeyToNumberOfDecimalPlacesMap.put (l_doubleDefaultExpressionFormatKeyInInteger, l_defaultNumberOfDecimalPlaces);
		}
		i_sheets = new UnoObjectPointer <XSpreadsheets> (i_underlyingUnoObject. <XSpreadsheetDocument>getAddress (XSpreadsheetDocument.class).getSheets ());
		//i_dispatchHelperInXDispatchHelper = (XDispatchHelper) i_remoteUnoObjectsContextInXComponentContext.getUnoServiceInstance (UnoServiceNamesConstantsGroup.c_com_sun_star_frame_DispatchHelper, XDispatchHelper.class, null);
	}
	
	private int getAndSetIfNecessaryCellValueExpressionFormatKey (String a_formatString) throws MalformedNumberFormatException {
		int l_formatKey = i_cellValueExpressionFormats.getAddress ().queryKey (a_formatString, i_defaultLocale, false);
		if (l_formatKey == GeneralConstantsConstantsGroup.c_unspecifiedInteger) {
			l_formatKey = i_cellValueExpressionFormats.getAddress ().addNew (a_formatString, i_defaultLocale);
		}
		return l_formatKey;
	}
	
	
	public UnoObjectPointer <XSpreadsheets> getSheets () {
		return i_sheets;
	}
	
	@Override
	public boolean equals (Object a_unoSpreadSheetsDocumentToBeComparedWith) {
		if (a_unoSpreadSheetsDocumentToBeComparedWith != null) {
			UnoSpreadSheetsDocument l_unoSpreadSheetsDocumentToBeComparedWith = null;
			if (a_unoSpreadSheetsDocumentToBeComparedWith instanceof UnoSpreadSheetsDocument) {
				l_unoSpreadSheetsDocumentToBeComparedWith = (UnoSpreadSheetsDocument) a_unoSpreadSheetsDocumentToBeComparedWith;
			}
			return UnoRuntime.areSame (i_underlyingUnoObject, l_unoSpreadSheetsDocumentToBeComparedWith.getUnderlyingUnoObject ());
		}
		else {
			return false;
		}
	}
	
	public int getDateExpressionFormatKey () {
		return i_dateExpressionFormatKey;
	}
	
	public int getTimeExpressionFormatKey () {
		return i_timeExpressionFormatKey;
	}
	
	public int getDateAndTimeExpressionFormatKey () {
		return i_dateAndTimeExpressionFormatKey;
	}
	
	public int getBooleanExpressionFormatKey () {
		return i_booleanExpressionFormatKey;
	}
	
	public int getStringExpressionFormatKey () {
		return i_stringExpressionFormatKey;
	}
	
	public int getIntegerExpressionFormatKey () {
		return i_integerExpressionFormatKey;
	}
	
	// a_numberOfDecimalPlaces: GeneralConstantsConstantsGroup.c_unspecifiedInteger for automatic number of decimal places
	public int getDoubleExpressionFormatKey (int a_numberOfDecimalPlaces) throws MalformedNumberFormatException {
		Integer l_numberOfDecimalPlacesInInteger = Integer.valueOf (a_numberOfDecimalPlaces);
		Integer l_doubleExpressionFormatKeyInInteger = i_numberOfDecimalPlacesToDoubleExpressionFormatKeyMap.get (l_numberOfDecimalPlacesInInteger);
		int l_doubleExpressionFormatKey = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		if (l_doubleExpressionFormatKeyInInteger == null) {
			String l_doubleExpressionFormatString = String.format (String.format (UnoSpreadSheetCellFormatStringsConstantsGroup.c_standardDoubleTemplate, a_numberOfDecimalPlaces), UnoGeneralConstantsConstantsGroup.c_numberExpressionModelNumber);
			l_doubleExpressionFormatKey = getAndSetIfNecessaryCellValueExpressionFormatKey (l_doubleExpressionFormatString);
			l_doubleExpressionFormatKeyInInteger = Integer.valueOf (l_doubleExpressionFormatKey);
			i_numberOfDecimalPlacesToDoubleExpressionFormatKeyMap.put (l_numberOfDecimalPlacesInInteger, l_doubleExpressionFormatKeyInInteger);
			i_doubleExpressionFormatKeyToNumberOfDecimalPlacesMap.put (l_doubleExpressionFormatKeyInInteger, l_numberOfDecimalPlacesInInteger);
		}
		else {
			l_doubleExpressionFormatKey = l_doubleExpressionFormatKeyInInteger.intValue ();
		}
		return l_doubleExpressionFormatKey;
	}
	
	public int getNumberOfDecimalPlaces (int a_unoCellValueExpressionFormatKey) throws UnknownPropertyException, WrappedTargetException {
		Integer l_unoCellValueExpressionFormatKeyInInteger = Integer.valueOf (a_unoCellValueExpressionFormatKey);
		Integer l_numberOfDecimalPlacesInInteger = i_doubleExpressionFormatKeyToNumberOfDecimalPlacesMap.get (l_unoCellValueExpressionFormatKeyInInteger);
		int l_numberOfDecimalPlaces = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		if (l_numberOfDecimalPlacesInInteger != null) {
			l_numberOfDecimalPlaces = l_numberOfDecimalPlacesInInteger.intValue ();
		}
		else {
			UnoObjectPointer <XPropertySet> l_unoCellValueExpressionFormatPropertiesSet = new UnoObjectPointer <XPropertySet> (i_cellValueExpressionFormats.getAddress ().getByKey (a_unoCellValueExpressionFormatKey));
			if (! (l_unoCellValueExpressionFormatPropertiesSet.isEmpty ())) {
				String l_formatString = (String) l_unoCellValueExpressionFormatPropertiesSet.getAddress ().getPropertyValue (UnoSpreadSheetCellValueExpressionFormatPropertyNamesSet.c_formatString);
				if (l_formatString.equals (UnoSpreadSheetCellFormatStringsConstantsGroup.c_globalNumber) || l_formatString.equals (UnoSpreadSheetCellFormatStringsConstantsGroup.c_standardNumber)) {
					l_numberOfDecimalPlaces = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
				}
				else {
					int l_periodIndex = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
					l_periodIndex = l_formatString.lastIndexOf (GeneralConstantsConstantsGroup.c_radixPointCharacter);
					if (l_periodIndex == GeneralConstantsConstantsGroup.c_unspecifiedInteger) {
						l_numberOfDecimalPlaces = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
					}
					else {
						int l_formatStringLength = l_formatString.length ();
						l_numberOfDecimalPlaces = 0;
						for (int l_characterIndex = l_periodIndex + 1; l_characterIndex < l_formatStringLength; l_characterIndex ++) {
							if (l_formatString.charAt (l_characterIndex) != UnoGeneralConstantsConstantsGroup.c_digitPlaceCharacter) {
								break;
							}
							else {
								l_numberOfDecimalPlaces ++;
							}
						}
						l_numberOfDecimalPlacesInInteger = Integer.valueOf (l_numberOfDecimalPlaces);
						i_numberOfDecimalPlacesToDoubleExpressionFormatKeyMap.put (l_numberOfDecimalPlacesInInteger, l_unoCellValueExpressionFormatKeyInInteger);
						i_doubleExpressionFormatKeyToNumberOfDecimalPlacesMap.put (l_unoCellValueExpressionFormatKeyInInteger, l_numberOfDecimalPlacesInInteger);
					}
				}
			}
			else {
				l_numberOfDecimalPlaces = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
			}
		}
		return l_numberOfDecimalPlaces;
	}
	
	/*
	public Object getSelection () {
		return i_controllerInXSelectionSupplier.getSelection ();
	}
	
	public void setSelection (Object a_selectedObject) {
		i_controllerInXSelectionSupplier.select (a_selectedObject);
	}
	*/
	
	public UnoObjectPointer <XNameContainer> getPageStyles () {
		try {
			return new UnoObjectPointer <XNameContainer> ( (XNameContainer) AnyConverter.toObject (XNameContainer.class, i_underlyingUnoObject. <XStyleFamiliesSupplier>getAddress (XStyleFamiliesSupplier.class).getStyleFamilies ().getByName (UnoStylesFamiliesConstantsGroup.c_unoPageStylesFamily.c_name)));
		}
		catch (NoSuchElementException | WrappedTargetException l_exception) {
			// Impossible
			return null;
		}
	}
	
	/*
	public XNameContainer getCellStyles () throws NoSuchElementException, WrappedTargetException {
		return (XNameContainer) AnyConverter.toObject (XNameContainer.class , i_selfInXStyleFamiliesSupplier.getStyleFamilies ().getByName (UnoStylesFamiliesConstantsGroup.c_unoSpreadSheetCellStylesFamily.c_name));
	}
	
	private void copyUnoStyle (XStyle a_sourceStyleInXStyle, XStyle a_destinationStyleInXStyle) throws PropertyVetoException, WrappedTargetException {
		XMultiPropertySet l_sourceStyleInXMultiPropertySet = (XMultiPropertySet) UnoRuntime.queryInterface (XMultiPropertySet.class, a_sourceStyleInXStyle);
		XMultiPropertySet l_destinationStyleInXMultiPropertySet = (XMultiPropertySet) UnoRuntime.queryInterface (XMultiPropertySet.class, a_destinationStyleInXStyle);
		// TODO l_destinationStyleInXMultiPropertySet.setPropertyValues (ArraysFactory. <String>createArray (String.class, a_styleFamily.c_propertyNamesSet.getValues ()), l_sourceStyleInXMultiPropertySet.getPropertyValues (ArraysFactory. <String>createArray (String.class, a_styleFamily.c_propertyNamesSet.getValues ())));
	}
	
	private void insertUnoStyle (UnoStylesFamiliesConstantsGroup.BaseUnoStylesFamily a_stylesFamily, XNameContainer a_originalStylesInXNameContainer, XNameContainer a_destinationStylesInXNameContainer, String a_styleName) throws ElementExistException, WrappedTargetException, NoSuchElementException, PropertyVetoException, Exception {
		XStyle l_originalStyleInXStyle = (XStyle) AnyConverter.toObject (XStyle.class , a_originalStylesInXNameContainer.getByName (a_styleName));
		String l_parentStyleName = l_originalStyleInXStyle.getParentStyle ();
		theBiasPlanet.coreUtilities.messagingHandling.Publisher.show (String.format("%s, %s", a_styleName, l_parentStyleName + "#"));
		if (l_parentStyleName != null && !a_destinationStylesInXNameContainer.hasByName (l_parentStyleName)) {
			insertUnoStyle (a_stylesFamily, a_originalStylesInXNameContainer, a_destinationStylesInXNameContainer, l_parentStyleName);
		}
		getUnoFrame ().fulfill (UnoDispatchSlotsConstantsGroup.c__uno_StyleNewByExample, ListsFactory. <Object>createArrayList (a_styleName, Short.valueOf (a_stylesFamily.c_key)));
		XStyle l_insertedStyleInXStyle = (XStyle) AnyConverter.toObject (XStyle.class , a_destinationStylesInXNameContainer.getByName (a_styleName));
		l_insertedStyleInXStyle.setParentStyle (l_parentStyleName);
		copyUnoStyle (l_originalStyleInXStyle, l_insertedStyleInXStyle);
	}
	
	private void copyOrInsertUnoStyles (UnoStylesFamiliesConstantsGroup.BaseUnoStylesFamily a_stylesFamily, XNameContainer a_sourceStylesInXNameContainer, XNameContainer a_destinationStylesInXNameContainer, Set <String> a_namesOfStylesToCopy) throws NoSuchElementException, WrappedTargetException, PropertyVetoException, ElementExistException, Exception {
		String [] l_destinationStyleNames = a_destinationStylesInXNameContainer.getElementNames ();
		for (String l_destinationStyleName: l_destinationStyleNames) {
			XStyle l_sourceStyleInXStyle = null;
			if (a_sourceStylesInXNameContainer.hasByName (l_destinationStyleName)) {
				if (a_namesOfStylesToCopy == null || a_namesOfStylesToCopy.contains (l_destinationStyleName)) {
					l_sourceStyleInXStyle = (XStyle) AnyConverter.toObject (XStyle.class, a_sourceStylesInXNameContainer.getByName (l_destinationStyleName));
				}
			}
			else {
				if (a_sourceStylesInXNameContainer.hasByName (UnoDefaultValuesConstantsGroup.c_customDefaultStyleName)) {
					if (a_namesOfStylesToCopy == null || a_namesOfStylesToCopy.contains (UnoDefaultValuesConstantsGroup.c_customDefaultStyleName)) {
						l_sourceStyleInXStyle = (XStyle) AnyConverter.toObject (XStyle.class , a_sourceStylesInXNameContainer.getByName (UnoDefaultValuesConstantsGroup.c_customDefaultStyleName));
					}
				}
			}
			if (l_sourceStyleInXStyle != null) {
				copyUnoStyle (l_sourceStyleInXStyle, (XStyle) AnyConverter.toObject (XStyle.class , a_destinationStylesInXNameContainer.getByName (l_destinationStyleName)));
			}
		}
		String [] l_sourceStyleNames = a_sourceStylesInXNameContainer.getElementNames ();
		for (String l_sourceStyleName: l_sourceStyleNames) {
			if (!a_destinationStylesInXNameContainer.hasByName (l_sourceStyleName)) {
				if (a_namesOfStylesToCopy == null || a_namesOfStylesToCopy.contains (l_sourceStyleName)) {
					insertUnoStyle (a_stylesFamily, a_sourceStylesInXNameContainer, a_destinationStylesInXNameContainer, l_sourceStyleName);
				}
			}
		}
	}
	
	public void copyUnoStylesFromUnoSpreadSheetsDocument (UnoSpreadSheetsDocument a_sourceSpreadSheetsDocument, boolean a_copyPageStyles, Set <String> a_namesOfPageStylesToCopy, boolean a_copyCellStyles, Set <String> a_namesOfCellStylesToCopy, boolean a_resetRowHeights) throws NoSuchElementException, PropertyVetoException, WrappedTargetException, ElementExistException, Exception {
		if (a_copyPageStyles) {
			copyOrInsertUnoStyles (UnoStylesFamiliesConstantsGroup.c_unoPageStylesFamily, a_sourceSpreadSheetsDocument.getPageStyles (), getPageStyles (), a_namesOfPageStylesToCopy);
		}
		if (a_copyCellStyles) {
			copyOrInsertUnoStyles (UnoStylesFamiliesConstantsGroup.c_unoSpreadSheetCellStylesFamily, a_sourceSpreadSheetsDocument.getCellStyles (), getCellStyles (), a_namesOfCellStylesToCopy);
		}
	}
	
	public void insertUnoSpreadSheet (String a_unoSpreadSheetName, int a_unoSpreadSheetIndex) {
		i_sheetsInXSpreadsheets.insertNewByName (a_unoSpreadSheetName, (short) a_unoSpreadSheetIndex);
	}
	
	public void copyUnoSpreadSheet (String a_originalSpreadSheetName, String a_copiedSpreadSheetName, int a_copiedSpreadSheetIndex) {
		i_sheetsInXSpreadsheets.copyByName (a_originalSpreadSheetName, a_copiedSpreadSheetName, (short) a_copiedSpreadSheetIndex);
	}
	
	public void removeUnoSpreadSheet (String a_unoSpreadSheetName) throws NoSuchElementException, WrappedTargetException {
		i_sheetsInXSpreadsheets.removeByName (a_unoSpreadSheetName);
	}
	*/
	
	public UnoSpreadSheet getSheet (int a_unoSpreadSheetIndex) throws Exception, NoSuchElementException, WrappedTargetException {
		return new UnoSpreadSheet (this, new UnoObjectPointer <XSpreadsheet> ( (XInterface) i_sheets. <XIndexAccess>getAddress (XIndexAccess.class).getByIndex (a_unoSpreadSheetIndex), XSpreadsheet.class));
	}
	
	public UnoSpreadSheet getSheet (String a_unoSpreadSheetName) throws Exception, NoSuchElementException, WrappedTargetException {
		return new UnoSpreadSheet (this, new UnoObjectPointer <XSpreadsheet> ( (XInterface) UnoDatumConverter.getObject ((i_sheets.getAddress ().getByName (a_unoSpreadSheetName))), XSpreadsheet.class));
	}
	
	public UnoSpreadSheet getActiveSheet () throws Exception {
		return new UnoSpreadSheet (this, new UnoObjectPointer <XSpreadsheet> (i_unoController. <XSpreadsheetView>getAddress (XSpreadsheetView.class).getActiveSheet ()));
	}
	
	/*
	public void activateUnoSpreadSheet (UnoSpreadSheet a_unoSpreadSheet) throws NoSuchElementException {
		i_controllerInXSpreadsheetView.setActiveSheet (a_unoSpreadSheet.getSelfInXSpreadsheet ());
	}
	
	public void addSelectionChangeListener (XSelectionChangeListener a_selectionChangeEventsListener) {
		i_controllerInXSelectionSupplier.addSelectionChangeListener (a_selectionChangeEventsListener);
	}
	
	public void removeSelectionChangeListener (XSelectionChangeListener a_selectionChangeEventsListener) {
		i_controllerInXSelectionSupplier.removeSelectionChangeListener (a_selectionChangeEventsListener);
	}
	
	public void addEnhancedMouseClicksListener (XEnhancedMouseClickHandler a_enhancedMouseClicksListener) {
		i_controllerInXEnhancedMouseClickBroadcaster.addEnhancedMouseClickHandler (a_enhancedMouseClicksListener);
	}
	
	public void removeEnhancedMouseClicksListener (XEnhancedMouseClickHandler a_enhancedMouseClicksListener) {
		i_controllerInXEnhancedMouseClickBroadcaster.removeEnhancedMouseClickHandler (a_enhancedMouseClicksListener);
	}
	
	public void addMouseClicksListener (XMouseClickHandler a_mouseClicksListener) {
		i_controllerInXUserInputInterception.addMouseClickHandler (a_mouseClicksListener);
	}
	
	public void removeMouseClicksListener (XMouseClickHandler a_mouseClicksListener) {
		i_controllerInXUserInputInterception.removeMouseClickHandler (a_mouseClicksListener);
	}
	
	public void addKeyPressesListener (XKeyHandler a_keyPressesListener) {
		i_controllerInXUserInputInterception.addKeyHandler (a_keyPressesListener);
	}
	
	public void removeKeyPressesListener (XKeyHandler a_keyPressesListener) {
		i_controllerInXUserInputInterception.removeKeyHandler (a_keyPressesListener);
	}
	
	public void addWindowMouseListener (XMouseListener a_mouseEventsListener) {
		//XWindow l_componentWindowInXWindow = i_frameInXFrame.getContainerWindow ();
		XWindow l_componentWindowInXWindow = i_frameInXFrame.getComponentWindow ();
		//l_componentWindowInXWindow.setVisible (false);
		l_componentWindowInXWindow.addMouseListener (a_mouseEventsListener);
		l_componentWindowInXWindow.addWindowListener ( (com.sun.star.awt.XWindowListener) a_mouseEventsListener);
		
		com.sun.star.frame.XFramesSupplier l_frameInXFramesSupplier = (com.sun.star.frame.XFramesSupplier) UnoRuntime.queryInterface (com.sun.star.frame.XFramesSupplier.class, i_frameInXFrame);
		com.sun.star.container.XIndexAccess l_framesInXIndexAccess = (com.sun.star.container.XIndexAccess) UnoRuntime.queryInterface (com.sun.star.container.XIndexAccess.class, l_frameInXFramesSupplier.getFrames ());
theBiasPlanet.coreUtilities.messagingHandling.Publisher.appendToFile (String.format (GeneralConstantsConstantsGroup.c_linuxFilePathFormat, System.getProperty (JavaPropertyNamesConstantsGroup.c_userHomeDirectoryPath), "UnoMouseEvents.txt"), String.format ("Frames: %d", l_framesInXIndexAccess.getCount ()));
		for (int l_frameIndex = 0; l_frameIndex < l_framesInXIndexAccess.getCount (); l_frameIndex ++) {
			try {
			XFrame l_frameInXFrame = (XFrame) l_framesInXIndexAccess.getByIndex (l_frameIndex);
theBiasPlanet.coreUtilities.messagingHandling.Publisher.appendToFile (String.format (GeneralConstantsConstantsGroup.c_linuxFilePathFormat, System.getProperty (JavaPropertyNamesConstantsGroup.c_userHomeDirectoryPath), "UnoMouseEvents.txt"), "Frame: " + l_frameInXFrame.getName ());
			}
			catch (Exception l_exception) {
				
			}
		}
		
		
 //   com.sun.star.container.XIndexAccess

		
theBiasPlanet.coreUtilities.messagingHandling.Publisher.appendToFile (String.format (GeneralConstantsConstantsGroup.c_linuxFilePathFormat, System.getProperty (JavaPropertyNamesConstantsGroup.c_userHomeDirectoryPath), "UnoMouseEvents.txt"), "Window: " + l_componentWindowInXWindow);
try {
theBiasPlanet.coreUtilities.messagingHandling.Publisher.appendToFile (System.getProperty("user.home") + "/UnoMouseEvents.txt", "###\n" + String.join ("\n", theBiasPlanet.unoUtilities.inspecting.UnoComponentInspector.getTypeNames ( l_componentWindowInXWindow)));
}
catch (Exception l_exception) {
	
}
	}
*/
}

