package theBiasPlanet.unoUtilities.documents;

import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import com.sun.star.awt.XEnhancedMouseClickHandler;
import com.sun.star.awt.XKeyHandler;
import com.sun.star.awt.XMouseClickHandler;
import com.sun.star.awt.XMouseListener;
import com.sun.star.awt.XUserInputInterception;
import com.sun.star.awt.XWindow;
import com.sun.star.beans.XPropertySet;
import com.sun.star.beans.XMultiPropertySet;
import com.sun.star.beans.UnknownPropertyException;
import com.sun.star.beans.PropertyVetoException;
import com.sun.star.container.XIndexAccess;
import com.sun.star.container.XNameContainer;
import com.sun.star.container.NoSuchElementException;
import com.sun.star.container.ElementExistException;
import com.sun.star.document.XDocumentPropertiesSupplier;
import com.sun.star.frame.XFrame;
import com.sun.star.frame.XModel;
import com.sun.star.lang.XComponent;
import com.sun.star.lang.Locale;
import com.sun.star.lang.WrappedTargetException;
import com.sun.star.security.XCertificate;
import com.sun.star.sheet.XEnhancedMouseClickBroadcaster;
import com.sun.star.sheet.XSpreadsheetDocument;
import com.sun.star.sheet.XSpreadsheet;
import com.sun.star.sheet.XSpreadsheets;
import com.sun.star.sheet.XSpreadsheetView;
import com.sun.star.style.XStyleFamiliesSupplier;
import com.sun.star.style.XStyle;
import com.sun.star.uno.AnyConverter;
import com.sun.star.uno.UnoRuntime;
import com.sun.star.uno.XInterface;
import com.sun.star.util.XNumberFormatsSupplier;
import com.sun.star.util.XNumberFormats;
import com.sun.star.util.MalformedNumberFormatException;
import com.sun.star.view.XSelectionChangeListener;
import com.sun.star.view.XSelectionSupplier;
import com.sun.star.xml.crypto.XSecurityEnvironment;
import theBiasPlanet.coreUtilities.collectionsHandling.ListsFactory;
import theBiasPlanet.coreUtilities.collectionsHandling.ArraysFactory;
import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.displayElements.UnoDesktop;
import theBiasPlanet.unoUtilities.documents.UnoDocument;
import theBiasPlanet.unoUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.*;
import theBiasPlanet.unoUtilities.documentElements.UnoSpreadSheet;
import theBiasPlanet.unoUtilities.pointers.UnoObjectPointer;
import theBiasPlanet.unoUtilities.unoDataHandling.UnoDatumConverter;
import theBiasPlanet.unoUtilities.unoObjectsContexts.RemoteUnoObjectsContext;

public class UnoSpreadSheetsDocument extends UnoDocument {
	private UnoObjectPointer <XSpreadsheets> i_sheets = null;
	private Locale i_defaultLocale;
	private UnoObjectPointer <XNumberFormats> i_cellValueExpressionFormats = null;
	private int i_dateExpressionFormatKey;
	private int i_timeExpressionFormatKey;
	private int i_dateAndTimeExpressionFormatKey;
	private int i_booleanExpressionFormatKey;
	private int i_stringExpressionFormatKey;
	private int i_integerExpressionFormatKey;
	private Map <Integer, Integer> i_numberOfDecimalPlacesToDoubleExpressionFormatKeyMap;
	private Map <Integer, Integer> i_doubleExpressionFormatKeyToNumberOfDecimalPlacesMap;
	
	public static UnoSpreadSheetsDocument createDocument (UnoDesktop a_unoDesktop, boolean a_unoDocumentIsHidden) throws Exception, com.sun.star.io.IOException {
		return new UnoSpreadSheetsDocument (a_unoDesktop.getRemoteUnoObjectsContext (), a_unoDesktop.loadUnoDocument (UnoSpecialFileUrlsConstantsGroup.c_calcNewDocument, null, a_unoDocumentIsHidden));
	}
	
	public static UnoSpreadSheetsDocument openFile (UnoDesktop a_unoDesktop, String a_fileUrl, String a_password, boolean a_unoDocumentIsHidden) throws Exception, com.sun.star.io.IOException {
		return new UnoSpreadSheetsDocument (a_unoDesktop.getRemoteUnoObjectsContext (), a_unoDesktop.loadUnoDocument (a_fileUrl, a_password, a_unoDocumentIsHidden));
	}
	
	public static UnoSpreadSheetsDocument getCurrentDocument (UnoDesktop a_unoDesktop) throws Exception {
		return new UnoSpreadSheetsDocument (a_unoDesktop.getRemoteUnoObjectsContext (), a_unoDesktop.getCurrentDocument ());
	}
	
	public static UnoSpreadSheetsDocument getDocument (UnoDesktop a_unoDesktop, String a_fileName) throws Exception {
		return new UnoSpreadSheetsDocument (a_unoDesktop.getRemoteUnoObjectsContext (), a_unoDesktop.getDocument (a_fileName));
	}
	
	public UnoSpreadSheetsDocument (RemoteUnoObjectsContext a_remoteUnoObjectsContext, UnoObjectPointer <XModel> a_underlyingUnoObject) throws Exception, MalformedNumberFormatException {
		super (a_remoteUnoObjectsContext, a_underlyingUnoObject);
		if (i_underlyingUnoObject. <XSpreadsheetDocument>getAddress (XSpreadsheetDocument.class) == null) {
			throw new Exception (UnoMessagesConstantsGroup.c_isNotSpreadSheetsDocument);
		}
		i_defaultLocale = new Locale ();
		i_cellValueExpressionFormats = new UnoObjectPointer <XNumberFormats> (i_underlyingUnoObject. <XNumberFormatsSupplier>getAddress (XNumberFormatsSupplier.class).getNumberFormats ());
		i_dateExpressionFormatKey = getAndSetIfNecessaryCellValueExpressionFormatKey (UnoSpreadSheetCellFormatStringsConstantsGroup.c_standardDate);
		i_timeExpressionFormatKey = getAndSetIfNecessaryCellValueExpressionFormatKey (UnoSpreadSheetCellFormatStringsConstantsGroup.c_standardTime);
		i_dateAndTimeExpressionFormatKey = getAndSetIfNecessaryCellValueExpressionFormatKey (UnoSpreadSheetCellFormatStringsConstantsGroup.c_standardDateAndTime);
		i_booleanExpressionFormatKey = getAndSetIfNecessaryCellValueExpressionFormatKey (UnoSpreadSheetCellFormatStringsConstantsGroup.c_standardBoolean);
		i_stringExpressionFormatKey = getAndSetIfNecessaryCellValueExpressionFormatKey (UnoSpreadSheetCellFormatStringsConstantsGroup.c_standardString);
		i_integerExpressionFormatKey = getAndSetIfNecessaryCellValueExpressionFormatKey (UnoSpreadSheetCellFormatStringsConstantsGroup.c_standardInteger);
		i_numberOfDecimalPlacesToDoubleExpressionFormatKeyMap = new HashMap <Integer, Integer> ();
		i_doubleExpressionFormatKeyToNumberOfDecimalPlacesMap = new HashMap <Integer, Integer> ();
		int l_doubleDefaultExpressionFormatKey = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		l_doubleDefaultExpressionFormatKey = i_cellValueExpressionFormats.getAddress ().queryKey (UnoSpreadSheetCellFormatStringsConstantsGroup.c_globalNumber, i_defaultLocale, false);
		if (l_doubleDefaultExpressionFormatKey == GeneralConstantsConstantsGroup.c_unspecifiedInteger) {
			l_doubleDefaultExpressionFormatKey = i_cellValueExpressionFormats.getAddress ().queryKey (UnoSpreadSheetCellFormatStringsConstantsGroup.c_standardNumber, i_defaultLocale, false);
		}
		if (l_doubleDefaultExpressionFormatKey == GeneralConstantsConstantsGroup.c_unspecifiedInteger) {
			// Doesn't seem possible
		}
		else {
			Integer l_defaultNumberOfDecimalPlaces = Integer.valueOf (GeneralConstantsConstantsGroup.c_unspecifiedInteger);
			Integer l_doubleDefaultExpressionFormatKeyInInteger = Integer.valueOf (l_doubleDefaultExpressionFormatKey);
			i_numberOfDecimalPlacesToDoubleExpressionFormatKeyMap.put (l_defaultNumberOfDecimalPlaces, l_doubleDefaultExpressionFormatKeyInInteger);
			i_doubleExpressionFormatKeyToNumberOfDecimalPlacesMap.put (l_doubleDefaultExpressionFormatKeyInInteger, l_defaultNumberOfDecimalPlaces);
		}
		i_sheets = new UnoObjectPointer <XSpreadsheets> (i_underlyingUnoObject. <XSpreadsheetDocument>getAddress (XSpreadsheetDocument.class).getSheets ());
	}
	
	private int getAndSetIfNecessaryCellValueExpressionFormatKey (String a_formatString) throws MalformedNumberFormatException {
		int l_formatKey = i_cellValueExpressionFormats.getAddress ().queryKey (a_formatString, i_defaultLocale, false);
		if (l_formatKey == GeneralConstantsConstantsGroup.c_unspecifiedInteger) {
			l_formatKey = i_cellValueExpressionFormats.getAddress ().addNew (a_formatString, i_defaultLocale);
		}
		return l_formatKey;
	}
	
	
	public UnoObjectPointer <XSpreadsheets> getSheets () {
		return i_sheets;
	}
	
	@Override
	public boolean equals (Object a_unoSpreadSheetsDocumentToBeComparedWith) {
		if (a_unoSpreadSheetsDocumentToBeComparedWith != null) {
			UnoSpreadSheetsDocument l_unoSpreadSheetsDocumentToBeComparedWith = null;
			if (a_unoSpreadSheetsDocumentToBeComparedWith instanceof UnoSpreadSheetsDocument) {
				l_unoSpreadSheetsDocumentToBeComparedWith = (UnoSpreadSheetsDocument) a_unoSpreadSheetsDocumentToBeComparedWith;
			}
			return UnoRuntime.areSame (i_underlyingUnoObject, l_unoSpreadSheetsDocumentToBeComparedWith.getUnderlyingUnoObject ());
		}
		else {
			return false;
		}
	}
	
	public int getDateExpressionFormatKey () {
		return i_dateExpressionFormatKey;
	}
	
	public int getTimeExpressionFormatKey () {
		return i_timeExpressionFormatKey;
	}
	
	public int getDateAndTimeExpressionFormatKey () {
		return i_dateAndTimeExpressionFormatKey;
	}
	
	public int getBooleanExpressionFormatKey () {
		return i_booleanExpressionFormatKey;
	}
	
	public int getStringExpressionFormatKey () {
		return i_stringExpressionFormatKey;
	}
	
	public int getIntegerExpressionFormatKey () {
		return i_integerExpressionFormatKey;
	}
	
	// a_numberOfDecimalPlaces: GeneralConstantsConstantsGroup.c_unspecifiedInteger for automatic number of decimal places
	public int getDoubleExpressionFormatKey (int a_numberOfDecimalPlaces) throws MalformedNumberFormatException {
		Integer l_numberOfDecimalPlacesInInteger = Integer.valueOf (a_numberOfDecimalPlaces);
		Integer l_doubleExpressionFormatKeyInInteger = i_numberOfDecimalPlacesToDoubleExpressionFormatKeyMap.get (l_numberOfDecimalPlacesInInteger);
		int l_doubleExpressionFormatKey = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		if (l_doubleExpressionFormatKeyInInteger == null) {
			String l_doubleExpressionFormatString = String.format (String.format (UnoSpreadSheetCellFormatStringsConstantsGroup.c_standardDoubleTemplate, a_numberOfDecimalPlaces), UnoGeneralConstantsConstantsGroup.c_numberExpressionModelNumber);
			l_doubleExpressionFormatKey = getAndSetIfNecessaryCellValueExpressionFormatKey (l_doubleExpressionFormatString);
			l_doubleExpressionFormatKeyInInteger = Integer.valueOf (l_doubleExpressionFormatKey);
			i_numberOfDecimalPlacesToDoubleExpressionFormatKeyMap.put (l_numberOfDecimalPlacesInInteger, l_doubleExpressionFormatKeyInInteger);
			i_doubleExpressionFormatKeyToNumberOfDecimalPlacesMap.put (l_doubleExpressionFormatKeyInInteger, l_numberOfDecimalPlacesInInteger);
		}
		else {
			l_doubleExpressionFormatKey = l_doubleExpressionFormatKeyInInteger.intValue ();
		}
		return l_doubleExpressionFormatKey;
	}
	
	public int getNumberOfDecimalPlaces (int a_unoCellValueExpressionFormatKey) throws UnknownPropertyException, WrappedTargetException {
		Integer l_unoCellValueExpressionFormatKeyInInteger = Integer.valueOf (a_unoCellValueExpressionFormatKey);
		Integer l_numberOfDecimalPlacesInInteger = i_doubleExpressionFormatKeyToNumberOfDecimalPlacesMap.get (l_unoCellValueExpressionFormatKeyInInteger);
		int l_numberOfDecimalPlaces = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		if (l_numberOfDecimalPlacesInInteger != null) {
			l_numberOfDecimalPlaces = l_numberOfDecimalPlacesInInteger.intValue ();
		}
		else {
			UnoObjectPointer <XPropertySet> l_unoCellValueExpressionFormatPropertiesSet = new UnoObjectPointer <XPropertySet> (i_cellValueExpressionFormats.getAddress ().getByKey (a_unoCellValueExpressionFormatKey));
			if (! (l_unoCellValueExpressionFormatPropertiesSet.isEmpty ())) {
				String l_formatString = (String) l_unoCellValueExpressionFormatPropertiesSet.getAddress ().getPropertyValue (UnoSpreadSheetCellValueExpressionFormatPropertyNamesSet.c_formatString);
				if (l_formatString.equals (UnoSpreadSheetCellFormatStringsConstantsGroup.c_globalNumber) || l_formatString.equals (UnoSpreadSheetCellFormatStringsConstantsGroup.c_standardNumber)) {
					l_numberOfDecimalPlaces = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
				}
				else {
					int l_periodIndex = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
					l_periodIndex = l_formatString.lastIndexOf (GeneralConstantsConstantsGroup.c_radixPointCharacter);
					if (l_periodIndex == GeneralConstantsConstantsGroup.c_unspecifiedInteger) {
						l_numberOfDecimalPlaces = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
					}
					else {
						int l_formatStringLength = l_formatString.length ();
						l_numberOfDecimalPlaces = 0;
						for (int l_characterIndex = l_periodIndex + 1; l_characterIndex < l_formatStringLength; l_characterIndex ++) {
							if (l_formatString.charAt (l_characterIndex) != UnoGeneralConstantsConstantsGroup.c_digitPlaceCharacter) {
								break;
							}
							else {
								l_numberOfDecimalPlaces ++;
							}
						}
						l_numberOfDecimalPlacesInInteger = Integer.valueOf (l_numberOfDecimalPlaces);
						i_numberOfDecimalPlacesToDoubleExpressionFormatKeyMap.put (l_numberOfDecimalPlacesInInteger, l_unoCellValueExpressionFormatKeyInInteger);
						i_doubleExpressionFormatKeyToNumberOfDecimalPlacesMap.put (l_unoCellValueExpressionFormatKeyInInteger, l_numberOfDecimalPlacesInInteger);
					}
				}
			}
			else {
				l_numberOfDecimalPlaces = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
			}
		}
		return l_numberOfDecimalPlaces;
	}
	
	public UnoObjectPointer <XNameContainer> getPageStyles () {
		try {
			return new UnoObjectPointer <XNameContainer> ( (XNameContainer) AnyConverter.toObject (XNameContainer.class, i_underlyingUnoObject. <XStyleFamiliesSupplier>getAddress (XStyleFamiliesSupplier.class).getStyleFamilies ().getByName (UnoStylesFamiliesConstantsGroup.c_unoPageStylesFamily.c_name)));
		}
		catch (NoSuchElementException | WrappedTargetException l_exception) {
			// Impossible
			return null;
		}
	}
	
	public UnoSpreadSheet getSheet (int a_unoSpreadSheetIndex) throws Exception, NoSuchElementException, WrappedTargetException {
		return new UnoSpreadSheet (this, new UnoObjectPointer <XSpreadsheet> ( (XInterface) UnoDatumConverter.getObject (i_sheets. <XIndexAccess>getAddress (XIndexAccess.class).getByIndex (a_unoSpreadSheetIndex)), XSpreadsheet.class));
	}
	
	public UnoSpreadSheet getSheet (String a_unoSpreadSheetName) throws Exception, NoSuchElementException, WrappedTargetException {
		return new UnoSpreadSheet (this, new UnoObjectPointer <XSpreadsheet> ( (XInterface) UnoDatumConverter.getObject ((i_sheets.getAddress ().getByName (a_unoSpreadSheetName))), XSpreadsheet.class));
	}
	
	public UnoSpreadSheet getActiveSheet () throws Exception {
		return new UnoSpreadSheet (this, new UnoObjectPointer <XSpreadsheet> (i_unoController. <XSpreadsheetView>getAddress (XSpreadsheetView.class).getActiveSheet ()));
	}
}

