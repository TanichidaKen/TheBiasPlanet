package theBiasPlanet.unoUtilities.displayElements;

import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.List;
import com.sun.star.container.NoSuchElementException;
import com.sun.star.container.XEnumeration;
import com.sun.star.frame.FrameSearchFlag;
import com.sun.star.frame.XComponentLoader;
import com.sun.star.frame.XDispatchProvider;
import com.sun.star.frame.XDesktop2;
import com.sun.star.frame.XDispatchProvider;
import com.sun.star.frame.XFrame;
import com.sun.star.frame.XModel;
import com.sun.star.frame.XStorable2;
import com.sun.star.frame.XSynchronousDispatch;
import com.sun.star.frame.XTitle;
import com.sun.star.lang.WrappedTargetException;
import com.sun.star.lang.XComponent;
import com.sun.star.uno.XInterface;
import theBiasPlanet.coreUtilities.collectionsHandling.ListsFactory;
import theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.RegularExpressionsConstantsGroup;
import theBiasPlanet.coreUtilities.stringsHandling.StringHandler;
import theBiasPlanet.unoUtilities.constantsGroups.UnoServiceNamesConstantsGroup;
import theBiasPlanet.unoUtilities.constantsGroups.UnoSpecialFrameNamesConstantsGroup;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.UnoDocumentOpeningEnumerablePropertyNamesSet;
import theBiasPlanet.unoUtilities.inspectionsHandling.UnoInterfaceNotImplementedException;
import theBiasPlanet.unoUtilities.pointers.UnoObjectPointer;
import theBiasPlanet.unoUtilities.propertiesHandling.UnoPropertiesHandler;
import theBiasPlanet.unoUtilities.unoDataHandling.UnoDatumConverter;
import theBiasPlanet.unoUtilities.unoObjectsContexts.RemoteUnoObjectsContext;

public class UnoDesktop extends UnoFrame {
	private UnoObjectPointer <XSynchronousDispatch> i_fileOpeningDispatcher = null;
	
	public static UnoDesktop getInstance (RemoteUnoObjectsContext a_remoteUnoObjectsContext) throws Exception {
		return new UnoDesktop (a_remoteUnoObjectsContext);
	}
	
	public UnoDesktop (RemoteUnoObjectsContext a_remoteUnoObjectsContext) throws Exception {
		super (a_remoteUnoObjectsContext, a_remoteUnoObjectsContext. <XFrame>getRemoteUnoServiceInstance (UnoServiceNamesConstantsGroup.c_com_sun_star_frame_Desktop, XFrame.class, null));
		i_fileOpeningDispatcher = new UnoObjectPointer <XSynchronousDispatch> (i_underlyingUnoObject. <XDispatchProvider>getAddress (XDispatchProvider.class).queryDispatch (UnoDatumConverter.getUrlInURL ("file:///"), UnoSpecialFrameNamesConstantsGroup.c_new, GeneralConstantsConstantsGroup.c_unspecifiedInteger), XSynchronousDispatch.class);
	}
	
	@Override
	public void finalize () {
	}
	
	public List <UnoObjectPointer <XComponent>> getChildObjects () {
		List <UnoObjectPointer <XComponent>> l_childObjects = ListsFactory. <UnoObjectPointer <XComponent>>createArrayList ();
		UnoObjectPointer <XEnumeration> l_childObjectsIterator = new UnoObjectPointer <XEnumeration> (i_underlyingUnoObject. <XDesktop2>getAddress (XDesktop2.class).getComponents ().createEnumeration ());
		UnoObjectPointer <XComponent> l_childObject = null;
		while (l_childObjectsIterator.getAddress ().hasMoreElements ()) {
			try {
				l_childObject = new UnoObjectPointer <XComponent> ( (XComponent) (UnoDatumConverter.getObject (l_childObjectsIterator.getAddress ().nextElement ())));
				if (! (l_childObject.isEmpty ())) {
					l_childObjects.add (l_childObject);
				}
			}
			catch (NoSuchElementException | WrappedTargetException l_exception) {
				// Practically, never would happen
				break;
			}
		}
		return l_childObjects;
	}
	
	public UnoObjectPointer <XComponent> getChildObject (String a_title) {
		UnoObjectPointer <XEnumeration> l_childObjectsIterator = new UnoObjectPointer <XEnumeration> (i_underlyingUnoObject. <XDesktop2>getAddress (XDesktop2.class).getComponents ().createEnumeration ());
		UnoObjectPointer <XComponent> l_childObject = null;
		while (l_childObjectsIterator.getAddress ().hasMoreElements ()) {
			try {
				l_childObject = new UnoObjectPointer <XComponent> ( (XComponent) UnoDatumConverter.getObject ((l_childObjectsIterator.getAddress ().nextElement ())));
				if (! (l_childObject.isEmpty ())) {
					if (l_childObject. <XTitle>getAddress (XTitle.class).getTitle ().equals (a_title) ) {
						return l_childObject;
					}
				}
			}
			catch (NoSuchElementException | WrappedTargetException l_exception) {
				// Practically, never would happen
				break;
			}
		}
		return null;
	}
	
	public UnoObjectPointer <XModel> loadUnoDocument (String a_url, String a_password, boolean a_unoDocumentIsHidden) throws Exception, com.sun.star.io.IOException {
		return new UnoObjectPointer <XModel> (i_underlyingUnoObject. <XComponentLoader>getAddress (XComponentLoader.class).loadComponentFromURL (a_url.replaceAll (RegularExpressionsConstantsGroup.c_windowsDirectoryDelimiterRegularExpression.pattern (), String.valueOf (GeneralConstantsConstantsGroup.c_linuxDirectoriesDelimiter)), UnoSpecialFrameNamesConstantsGroup.c_new, FrameSearchFlag.CREATE, UnoPropertiesHandler.buildPropertiesArray (UnoDocumentOpeningEnumerablePropertyNamesSet.c_instance.getValues (), ListsFactory. <Object>createArrayList (Boolean.valueOf (false), Boolean.valueOf (a_unoDocumentIsHidden), Boolean.valueOf (false), Boolean.valueOf (a_unoDocumentIsHidden), a_password != null ? a_password: ""))), XModel.class);
	}
	
	public UnoFrame getCurrentUnoFrame () throws com.sun.star.uno.Exception {
		return new UnoFrame (i_remoteUnoObjectsContext, new UnoObjectPointer <XFrame> (i_underlyingUnoObject. <XDesktop2>getAddress (XDesktop2.class).getCurrentFrame ()));
	}
	 
	public UnoObjectPointer <XModel> getCurrentDocument () throws com.sun.star.uno.Exception {
		return new UnoObjectPointer <XModel> (i_underlyingUnoObject. <XDesktop2>getAddress (XDesktop2.class).getCurrentComponent (), XModel.class);
	}
	
	public UnoObjectPointer <XModel> getDocument (String a_fileName) throws com.sun.star.uno.Exception {
		UnoObjectPointer <XEnumeration> l_unoComponents = new UnoObjectPointer <XEnumeration> (i_underlyingUnoObject. <XDesktop2>getAddress (XDesktop2.class).getComponents ().createEnumeration ());
		while (l_unoComponents.getAddress ().hasMoreElements ()) {
			UnoObjectPointer <XStorable2> l_unoComponent = null;
			try {
				l_unoComponent = new UnoObjectPointer <XStorable2> ( (XInterface) (UnoDatumConverter.getObject (l_unoComponents.getAddress ().nextElement ())), XStorable2.class);
			}
			catch (NoSuchElementException | WrappedTargetException l_exception) {
				// Practically, never would happen
				break;
			}
			if (l_unoComponent.isEmpty ()) {
				continue;
			}
			try {
				String l_documentLocationString = l_unoComponent.getAddress ().getLocation ();
				if (l_documentLocationString != null && (l_documentLocationString.startsWith ("http://") || l_documentLocationString.startsWith ("https://"))) {
					try {
						if ( (new URL (l_documentLocationString)).getFile ().equals (a_fileName)) {
							try {
								return new UnoObjectPointer <XModel> (l_unoComponent, XModel.class);
							}
							catch (UnoInterfaceNotImplementedException l_exception) {
							}
						}
					}
					catch (MalformedURLException l_exception) {
					}
				}
				else {
					if (StringHandler.getFilePath (l_documentLocationString).getFileName ().toString ().equals (a_fileName)) {
						try {
							return new UnoObjectPointer <XModel> (l_unoComponent, XModel.class);
						}
						catch (UnoInterfaceNotImplementedException l_exception) {
						}
					}
				}
			}
			// The possibility is that 'getLocation' returned null.
			catch (IllegalArgumentException | URISyntaxException l_exception) {
				continue;
			}
		}
		return null;
	}
	
	public UnoObjectPointer <XSynchronousDispatch> getFileOpeningDispatcher () {
		return i_fileOpeningDispatcher;
	}
}

