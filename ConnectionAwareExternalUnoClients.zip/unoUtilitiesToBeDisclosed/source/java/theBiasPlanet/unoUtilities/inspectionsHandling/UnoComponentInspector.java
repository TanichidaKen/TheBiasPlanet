package theBiasPlanet.unoUtilities.inspectionsHandling;

import java.util.ArrayList;
import com.sun.star.beans.Property;
import com.sun.star.beans.UnknownPropertyException;
import com.sun.star.beans.XPropertySet;
import com.sun.star.beans.XPropertySetInfo;
import com.sun.star.lang.WrappedTargetException;
import com.sun.star.lang.XTypeProvider;
import com.sun.star.uno.Type;
import com.sun.star.uno.XInterface;
import com.sun.star.uno.UnoRuntime;
import theBiasPlanet.coreUtilities.collections.NavigableLinkedHashMap;
import theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup;

public class UnoComponentInspector {
	public static ArrayList <String> getUnoTypeNames (XInterface a_unoObjectInXInterface) throws UnoInterfaceNotImplementedException {
		XTypeProvider l_unoObjectInXTypeProvider = (XTypeProvider) UnoRuntime.queryInterface (XTypeProvider.class, a_unoObjectInXInterface);
		if (l_unoObjectInXTypeProvider != null) {
			Type [] l_UnoTypes = l_unoObjectInXTypeProvider.getTypes ();
			int l_numberOfUnoTypes = l_UnoTypes.length;
			ArrayList <String> l_unoTypeNames = new ArrayList <String> ();
			for (int l_unoTypeIndex = 0; l_unoTypeIndex < l_numberOfUnoTypes; l_unoTypeIndex ++) {
				l_unoTypeNames.add (l_UnoTypes [l_unoTypeIndex].getTypeName ());
			}
			return l_unoTypeNames;
		}
		else {
			throw new UnoInterfaceNotImplementedException ("XTypeProvider");
		}
	}
	
	public static NavigableLinkedHashMap <String, Object> getPropertyNameToValueMap (XInterface a_unoObjectInXInterface) throws UnoInterfaceNotImplementedException, WrappedTargetException {
		XPropertySet l_unoObjectInXPropertySet = UnoRuntime.queryInterface (XPropertySet.class, a_unoObjectInXInterface);
		if (l_unoObjectInXPropertySet != null) {
			NavigableLinkedHashMap <String, Object> l_propertyNameToValueMap = new NavigableLinkedHashMap <String, Object> ();
			// do not use 'UnoObjectPointer' for storing 'l_propertySetInfoInXPropertySetInfo', because an eternal loop would happen.
			XPropertySetInfo l_propertySetInfoInXPropertySetInfo = l_unoObjectInXPropertySet.getPropertySetInfo ();
			if (l_propertySetInfoInXPropertySetInfo != null) {
				Property [] l_properties = l_propertySetInfoInXPropertySetInfo.getProperties ();
				int l_numberOfProperties = l_properties.length;
				for (int l_propertyIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber; l_propertyIndex < l_numberOfProperties; l_propertyIndex ++) {
					try {
						l_propertyNameToValueMap.put (l_properties [l_propertyIndex].Name, l_unoObjectInXPropertySet.getPropertyValue (l_properties [l_propertyIndex].Name));
					}
					catch (UnknownPropertyException l_exception) {
						l_propertyNameToValueMap.put (l_properties [l_propertyIndex].Name, "Not Found");
					}
					catch (Exception l_exception) {
						l_propertyNameToValueMap.put (l_properties [l_propertyIndex].Name, String.format (": ### An error has occurred in getting the property value: exception is %s.", l_exception));
					}
				}
				return l_propertyNameToValueMap;
			}
			else {
				return l_propertyNameToValueMap;
			}
		}
		else {
			throw new UnoInterfaceNotImplementedException ("XPropertySet");
		}
	}
}

