package theBiasPlanet.unoUtilities.inspectionsHandling;

public class UnoInterfaceNotImplementedException extends Exception {
	public UnoInterfaceNotImplementedException (String a_message) {
		super (a_message);
	}
}

