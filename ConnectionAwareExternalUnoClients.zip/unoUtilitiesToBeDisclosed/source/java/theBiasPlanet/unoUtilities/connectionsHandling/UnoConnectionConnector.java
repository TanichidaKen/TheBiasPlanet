package theBiasPlanet.unoUtilities.connectionsHandling;

import java.time.LocalDateTime;
import java.util.List;
import java.util.StringTokenizer;
import com.sun.star.connection.XConnection;
import com.sun.star.connection.NoConnectException;
import com.sun.star.connection.XConnector;
import theBiasPlanet.coreUtilities.messagingHandling.Publisher;
import theBiasPlanet.unoUtilities.connection.UnoConnection;
import theBiasPlanet.unoUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.unoObjectsContexts.LocalUnoObjectsContext;

public class UnoConnectionConnector extends UnoConnectionsFactory {
	public UnoConnectionConnector (LocalUnoObjectsContext a_localUnoObjectsContext) throws com.sun.star.uno.Exception {
		super (a_localUnoObjectsContext);
		initialize ();
	}
	
	@Override
	protected void finalize () {
	}
	
	public final UnoConnection connect (String a_url, List <UnoConnection.UnoConnectionEventsListener> a_eventsListeners, boolean a_vetoesOfficeTermination) throws Exception {
		StringTokenizer l_urlTokenizer = new StringTokenizer (a_url, UnoGeneralConstantsConstantsGroup.c_connectionUrlDelimiter);
		XConnector l_unoConnectionConnector = i_localUnoObjectsContext. <XConnector>getLocalUnoServiceInstance (UnoServiceNamesConstantsGroup.c_com_sun_star_connection_Connector, null);
		try {
			XConnection l_unoConnection = l_unoConnectionConnector.connect (l_urlTokenizer.nextToken ());
			return setUpUnoConnection (l_unoConnection, l_urlTokenizer, LocalDateTime.now ().toString (), a_eventsListeners, a_vetoesOfficeTermination);
		}
		catch (NoConnectException l_exception) {
			Publisher.logErrorInformation (l_exception);
			return null;
		}
	}
}

