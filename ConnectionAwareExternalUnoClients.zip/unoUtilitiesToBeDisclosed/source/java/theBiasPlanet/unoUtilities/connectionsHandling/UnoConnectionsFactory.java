package theBiasPlanet.unoUtilities.connectionsHandling;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import com.sun.star.bridge.BridgeExistsException;
import com.sun.star.bridge.XBridge;
import com.sun.star.bridge.XBridgeFactory;
import com.sun.star.connection.XConnection;
import com.sun.star.uno.XComponentContext;
import com.sun.star.uno.XInterface;
import theBiasPlanet.unoUtilities.connection.UnoConnection;
import theBiasPlanet.unoUtilities.constantsGroups.UnoMessagesConstantsGroup;
import theBiasPlanet.unoUtilities.constantsGroups.UnoServiceNamesConstantsGroup;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.UnoObjectsContextPropertyNamesSet;
import theBiasPlanet.unoUtilities.pointers.UnoObjectPointer;
import theBiasPlanet.unoUtilities.unoObjectsContexts.LocalUnoObjectsContext;

abstract public class UnoConnectionsFactory {
	protected LocalUnoObjectsContext i_localUnoObjectsContext = null;
	protected XBridgeFactory i_unoBridgesFactory = null;
	
	protected UnoConnectionsFactory (LocalUnoObjectsContext a_localUnoObjectsContext) {
		i_localUnoObjectsContext = a_localUnoObjectsContext;
	}
	
	@Override
	protected void finalize () {
	}
	
	protected final void initialize () throws com.sun.star.uno.Exception {
		i_unoBridgesFactory = i_localUnoObjectsContext. <XBridgeFactory>getLocalUnoServiceInstance (UnoServiceNamesConstantsGroup.c_com_sun_star_bridge_BridgeFactory, null);
	}
	
	protected final UnoConnection setUpUnoConnection (XConnection a_unoConnection, StringTokenizer a_urlTokenizer, String a_unoConnectionIdentification, List <UnoConnection.UnoConnectionEventsListener> a_eventsListeners) throws Exception {
		UnoConnection.InitialUnoObjectsProvider l_initialUnoObjectsProvider = new UnoConnection.InitialUnoObjectsProvider (i_localUnoObjectsContext);
		XBridge l_unoBridge = null;
		try {
			l_unoBridge = i_unoBridgesFactory.createBridge ("", a_urlTokenizer.nextToken (), a_unoConnection, l_initialUnoObjectsProvider);
		}
		catch (BridgeExistsException l_exception) {
			// This can't happen
		}
		UnoObjectPointer <XComponentContext> l_remoteUnoObjectsContext = new UnoObjectPointer <XComponentContext> ( (XInterface) l_unoBridge.getInstance (a_urlTokenizer.nextToken ()), XComponentContext.class);
		if (l_remoteUnoObjectsContext.isEmpty ()) {
			throw new Exception (UnoMessagesConstantsGroup.c_remoteInstanceNotProvided);
		}
		return new UnoConnection (l_remoteUnoObjectsContext, a_unoConnectionIdentification, l_unoBridge, l_initialUnoObjectsProvider, a_eventsListeners);
	}
}

