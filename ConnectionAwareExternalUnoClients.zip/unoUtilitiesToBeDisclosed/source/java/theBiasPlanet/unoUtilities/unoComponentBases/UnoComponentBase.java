package theBiasPlanet.unoUtilities.unoComponentBases;

import com.sun.star.lang.XUnoTunnel;
import com.sun.star.lib.uno.helper.WeakBase;
import theBiasPlanet.coreUtilities.messagingHandling.Publisher;

public class UnoComponentBase extends WeakBase implements XUnoTunnel {
	public UnoComponentBase () {
		Publisher.logDebugInformation (String.format ("### An instance of a local UNO component, '%s', is being created.", this.getClass ().getName ()));
	}
	
	@Override
	protected void finalize () {
		Publisher.logDebugInformation (String.format ("### An instance of a local UNO component, '%s', is being destructed.", this.getClass ().getName ()));
	}
	
	@Override
	public long getSomething (byte [] a_datumIdentification) {
		return 0;
	}
}

