#ifndef INCLUDED_THEBIASPLANET_UNODATUMTYPES_HEYUNOEXTENSIONS_SCOLDERPRAISERUNOSERVICESINGLETON_HPP
#define INCLUDED_THEBIASPLANET_UNODATUMTYPES_HEYUNOEXTENSIONS_SCOLDERPRAISERUNOSERVICESINGLETON_HPP

#include "sal/config.h"

#include <cassert>

#include "com/sun/star/uno/DeploymentException.hpp"
#include "com/sun/star/uno/XComponentContext.hpp"
#include "theBiasPlanet/unoDatumTypes/heyUnoExtensions/XScolder.hpp"
#include "com/sun/star/uno/Any.hxx"
#include "com/sun/star/uno/Reference.hxx"
#include "cppu/unotype.hxx"
#include "rtl/ustring.h"
#include "rtl/ustring.hxx"

#if defined ANDROID || defined IOS //TODO
#include <com/sun/star/lang/XInitialization.hpp>
#include <osl/detail/component-defines.h>
#endif

#if defined LO_URE_CURRENT_ENV && defined LO_URE_CTOR_ENV_theBiasPlanet_dot_unoDatumTypes_dot_heyUnoExtensions_dot_ScolderPraiserUnoServiceSingleton && (LO_URE_CURRENT_ENV) == (LO_URE_CTOR_ENV_theBiasPlanet_dot_unoDatumTypes_dot_heyUnoExtensions_dot_ScolderPraiserUnoServiceSingleton) && defined LO_URE_CTOR_FUN_theBiasPlanet_dot_unoDatumTypes_dot_heyUnoExtensions_dot_ScolderPraiserUnoServiceSingleton
extern "C" ::css::uno::XInterface * SAL_CALL LO_URE_CTOR_FUN_theBiasPlanet_dot_unoDatumTypes_dot_heyUnoExtensions_dot_ScolderPraiserUnoServiceSingleton(::css::uno::XComponentContext *, ::css::uno::Sequence< ::css::uno::Any > const &);
#endif

namespace theBiasPlanet { namespace unoDatumTypes { namespace heyUnoExtensions {

class ScolderPraiserUnoServiceSingleton {
public:
    static ::css::uno::Reference< ::theBiasPlanet::unoDatumTypes::heyUnoExtensions::XScolder > get(::css::uno::Reference< ::css::uno::XComponentContext > const & the_context) {
        assert(the_context.is());
        ::css::uno::Reference< ::theBiasPlanet::unoDatumTypes::heyUnoExtensions::XScolder > instance;
#if defined LO_URE_CURRENT_ENV && defined LO_URE_CTOR_ENV_theBiasPlanet_dot_unoDatumTypes_dot_heyUnoExtensions_dot_ScolderPraiserUnoServiceSingleton && (LO_URE_CURRENT_ENV) == (LO_URE_CTOR_ENV_theBiasPlanet_dot_unoDatumTypes_dot_heyUnoExtensions_dot_ScolderPraiserUnoServiceSingleton) && defined LO_URE_CTOR_FUN_theBiasPlanet_dot_unoDatumTypes_dot_heyUnoExtensions_dot_ScolderPraiserUnoServiceSingleton
        instance = ::css::uno::Reference< ::theBiasPlanet::unoDatumTypes::heyUnoExtensions::XScolder >(::css::uno::Reference< ::css::uno::XInterface >(static_cast< ::css::uno::XInterface * >((*LO_URE_CTOR_FUN_theBiasPlanet_dot_unoDatumTypes_dot_heyUnoExtensions_dot_ScolderPraiserUnoServiceSingleton)(the_context.get(), ::css::uno::Sequence< ::css::uno::Any >())), ::SAL_NO_ACQUIRE), ::css::uno::UNO_QUERY);
#else
        the_context->getValueByName(::rtl::OUString( "/singletons/theBiasPlanet.unoDatumTypes.heyUnoExtensions.ScolderPraiserUnoServiceSingleton" )) >>= instance;
#endif
        if (!instance.is()) {
            throw ::css::uno::DeploymentException(::rtl::OUString( "component context fails to supply singleton theBiasPlanet.unoDatumTypes.heyUnoExtensions.ScolderPraiserUnoServiceSingleton of type theBiasPlanet.unoDatumTypes.heyUnoExtensions.XScolder" ), the_context);
        }
        return instance;
    }

private:
    ScolderPraiserUnoServiceSingleton(); // not implemented
    ScolderPraiserUnoServiceSingleton(ScolderPraiserUnoServiceSingleton &); // not implemented
    ~ScolderPraiserUnoServiceSingleton(); // not implemented
    void operator =(ScolderPraiserUnoServiceSingleton); // not implemented
};

} } }

#endif // INCLUDED_THEBIASPLANET_UNODATUMTYPES_HEYUNOEXTENSIONS_SCOLDERPRAISERUNOSERVICESINGLETON_HPP
