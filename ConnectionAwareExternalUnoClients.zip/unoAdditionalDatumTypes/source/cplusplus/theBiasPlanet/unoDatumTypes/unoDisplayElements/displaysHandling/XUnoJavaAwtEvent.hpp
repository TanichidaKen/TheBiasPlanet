#ifndef INCLUDED_THEBIASPLANET_UNODATUMTYPES_UNODISPLAYELEMENTS_DISPLAYSHANDLING_XUNOJAVAAWTEVENT_HPP
#define INCLUDED_THEBIASPLANET_UNODATUMTYPES_UNODISPLAYELEMENTS_DISPLAYSHANDLING_XUNOJAVAAWTEVENT_HPP

#include "sal/config.h"

#include "theBiasPlanet/unoDatumTypes/unoDisplayElements/displaysHandling/XUnoJavaAwtEvent.hdl"

#include "com/sun/star/uno/XInterface.hpp"
#include "com/sun/star/uno/Reference.hxx"
#include "com/sun/star/uno/Type.hxx"
#include "cppu/unotype.hxx"
#include "rtl/ustring.hxx"

namespace theBiasPlanet { namespace unoDatumTypes { namespace unoDisplayElements { namespace displaysHandling {

inline ::css::uno::Type const & cppu_detail_getUnoType(SAL_UNUSED_PARAMETER ::theBiasPlanet::unoDatumTypes::unoDisplayElements::displaysHandling::XUnoJavaAwtEvent const *) {
    static typelib_TypeDescriptionReference * the_type = 0;
    if ( !the_type )
    {
        typelib_static_mi_interface_type_init( &the_type, "theBiasPlanet.unoDatumTypes.unoDisplayElements.displaysHandling.XUnoJavaAwtEvent", 0, 0 );
    }
    return * reinterpret_cast< ::css::uno::Type * >( &the_type );
}

} } } }

SAL_DEPRECATED("use cppu::UnoType") inline ::css::uno::Type const & SAL_CALL getCppuType(SAL_UNUSED_PARAMETER ::css::uno::Reference< ::theBiasPlanet::unoDatumTypes::unoDisplayElements::displaysHandling::XUnoJavaAwtEvent > const *) {
    return ::cppu::UnoType< ::css::uno::Reference< ::theBiasPlanet::unoDatumTypes::unoDisplayElements::displaysHandling::XUnoJavaAwtEvent > >::get();
}

::css::uno::Type const & ::theBiasPlanet::unoDatumTypes::unoDisplayElements::displaysHandling::XUnoJavaAwtEvent::static_type(SAL_UNUSED_PARAMETER void *) {
    return ::cppu::UnoType< ::theBiasPlanet::unoDatumTypes::unoDisplayElements::displaysHandling::XUnoJavaAwtEvent >::get();
}

#endif // INCLUDED_THEBIASPLANET_UNODATUMTYPES_UNODISPLAYELEMENTS_DISPLAYSHANDLING_XUNOJAVAAWTEVENT_HPP
