from typing import List
from abc import ABCMeta
from com.sun.star.uno import XInterface
from theBiasPlanet.unoDatumTypes.unoExternalDisplaysHandling.displayElements import XExternalFrame

class XExternalFramesFactory (XInterface, metaclass=ABCMeta):
	def create (a_this: "XExternalFramesFactory", a_frameName: str, a_parameters: List [object]) -> XExternalFrame:
		return None

