from typing import List
from abc import ABCMeta
from com.sun.star.reflection import XIdlClass
from com.sun.star.uno import XInterface

class XUnoMethodInvoker (XInterface, metaclass=ABCMeta):
	#def invokeUnoMethod (a_this: "XUnoMethodInvoker", a_unoObject: XInterface, a_unoInterfaceType: XIdlClass, a_unoMethodName: str, a_argumentUnoTypes: List [XIdlClass], a_arguments: List [object], a_outputArgumentIndices: List [int]) -> object:
	def invokeUnoMethod (a_this: "XUnoMethodInvoker", a_unoObject: XInterface, a_unoInterfaceTypeName: str, a_unoMethodName: str, a_argumentUnoTypeNames: List [str], a_arguments: List [object], a_outputArgumentIndices: List [int]) -> List [object]:
		return None

