package thebiasplanet.unoutilities.constantsgroups;

public interface UnoPixelValuesConstantsGroup {
	int c_notSpecified = -1;
	int c_compressedCellBackgroundPixelValue = 3355443;
	int c_parameterCaptionBackgroundPixelValue = 6750054;
}
