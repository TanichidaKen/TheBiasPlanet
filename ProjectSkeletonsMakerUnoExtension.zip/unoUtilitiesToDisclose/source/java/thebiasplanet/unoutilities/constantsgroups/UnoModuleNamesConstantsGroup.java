package thebiasplanet.unoutilities.constantsgroups;

public interface UnoModuleNamesConstantsGroup {
	String c_standardBasemoduleName = "com.sun.star";
}
