package thebiasplanet.uno.projectskeletonsmakerunoextension;

import java.util.Set;
import java.util.HashSet;
import java.util.Map;
import com.sun.star.lib.uno.helper.WeakBase;
import com.sun.star.lang.XServiceInfo;
import com.sun.star.lang.XInitialization;
import com.sun.star.uno.XComponentContext;
import thebiasplanet.coreutilities.collectionshandling.MapFactory;
import thebiasplanet.coreutilities.collectionshandling.ArrayFactory;
// # Add necessary classes and interfaces START
import thebiasplanet.coreutilities.constantsgroups.*;
import thebiasplanet.coreutilities.messaging.Publisher;
import thebiasplanet.projectskeletonsmaker.environments.ProjectSkeletonsMakerEnvironment;
import thebiasplanet.projectskeletonsmaker.environments.ProjectEnvironment;
import thebiasplanet.projectskeletonsmaker.environments.UnoAdditionalDataTypesProjectEnvironmentInterface;
import thebiasplanet.projectskeletonsmaker.environments.JavaUnoExtensionProjectEnvironment;
import thebiasplanet.projectskeletonsmaker.filesmakers.ProjectFilesMaker;
import thebiasplanet.projectskeletonsmaker.filesmakers.UnoAdditionalDataTypesProjectFilesMaker;
import thebiasplanet.projectskeletonsmaker.filesmakers.JavaUnoExtensionProjectFilesMaker;
import thebiasplanet.projectskeletonsmaker.parameterssettinginterpreters.ParametersSettingInterpreter;
// # Add necessary classes and interfaces END

public class ProjectSkeletonsMakerUnoComponent extends WeakBase implements XServiceInfo, XInitialization, XProjectSkeletonsMaker {
	private static final Set <String> c_serviceNamesSet = new HashSet <String> ();
	private static final Class c_thisClass = new Object () { }.getClass ().getEnclosingClass ();
	private XComponentContext i_componentContextInXComponentContext;
	// # Add member variables START
	ParametersSettingInterpreter i_parametersSettingInterpreter;
	// # Add member variables END
	
	static {
		c_serviceNamesSet.add ("thebiasplanet.uno.projectskeletonsmakerunoextension.ProjectSkeletonsMakerUnoService");
	}
	
	public ProjectSkeletonsMakerUnoComponent (XComponentContext a_componentContextInXComponentContext)
			throws IllegalArgumentException {
		i_componentContextInXComponentContext = a_componentContextInXComponentContext;
	}
	
	static void setThisClassToServicesProvider (Map <String, Map <Class <?>, Set <String>>> a_implementationClassNameToImplementationClassToServiceNamesMapMap) {
		a_implementationClassNameToImplementationClassToServiceNamesMapMap.put (c_thisClass.getName (), MapFactory. <Class <?>, Set <String>> createLinkedHashMap (c_thisClass, c_serviceNamesSet));
	}
	
	public final void initialize (java.lang.Object [] a_arguments)
			throws com.sun.star.uno.Exception {
		// # Write the initialization START
		if (a_arguments != null && a_arguments.length == 2) {
			if (a_arguments[0] instanceof String) {
				ProjectSkeletonsMakerEnvironment.setStyleSheetsDirectoryPath ((String) a_arguments[0]);
			}
			else {
				throw new IllegalArgumentException("The first argument must be a String instance.");
			}
			if (a_arguments[1] instanceof String) {
				i_parametersSettingInterpreter = new ParametersSettingInterpreter ((String) a_arguments[1]);
			}
			else {
				throw new IllegalArgumentException("The second argument must be a String instance.");
			}
		}
		else {
			throw new IllegalArgumentException("The number of arguments must be 2.");
		}
		// # Write the initialization END
	}
	
	// # Add methods of the implemented UNO interface START
	public void makeProjectSkeleton () {
		try {
			i_parametersSettingInterpreter.interpret (i_componentContextInXComponentContext);
			ProjectEnvironment l_projectEnvironment = i_parametersSettingInterpreter.getProjectEnvironment ();
			ProjectFilesMaker.makeGradleBuildScript (l_projectEnvironment);
			ProjectFilesMaker.makeAntBuildFile (l_projectEnvironment);
			ProjectFilesMaker.makeJarManifestAdditionFile (l_projectEnvironment);
			if (l_projectEnvironment instanceof UnoAdditionalDataTypesProjectEnvironmentInterface) {
				UnoAdditionalDataTypesProjectFilesMaker.makeUnoInterfaceSourceFiles ( (UnoAdditionalDataTypesProjectEnvironmentInterface) l_projectEnvironment, i_parametersSettingInterpreter.getUnoModuleNameToUnoInterfaceRelativeCoreNameToSuperUnoInterfaceNamesMapMap ());
				UnoAdditionalDataTypesProjectFilesMaker.makeUnoServiceSpecificServiceInstancesFactorySourceFiles ( (UnoAdditionalDataTypesProjectEnvironmentInterface)l_projectEnvironment, i_parametersSettingInterpreter.getUnoModuleNameToUnoServiceRelativeCoreNameToReturnTypeUnoInterfaceNameMapMap ());
			}
			if (l_projectEnvironment instanceof JavaUnoExtensionProjectEnvironment) {
				JavaUnoExtensionProjectFilesMaker.makeUnoExtensionManifestFile ( (JavaUnoExtensionProjectEnvironment) l_projectEnvironment);
				JavaUnoExtensionProjectFilesMaker.makeJarManifestAdditionFile ( (JavaUnoExtensionProjectEnvironment) l_projectEnvironment);
				JavaUnoExtensionProjectFilesMaker.makeUnoComponentsSettingFile ( (JavaUnoExtensionProjectEnvironment) l_projectEnvironment, i_parametersSettingInterpreter.getUnoComponentClassRelativeCoreNameToUnoInterfaceNamesAndUnoServiceRelativeCoreNamesMap ());
				JavaUnoExtensionProjectFilesMaker.makeGlobalUnoServicesProviderSourceFile ( (JavaUnoExtensionProjectEnvironment) l_projectEnvironment, i_parametersSettingInterpreter.getUnoComponentClassRelativeCoreNameToUnoInterfaceNamesAndUnoServiceRelativeCoreNamesMap ());
				JavaUnoExtensionProjectFilesMaker.makeUnoComponentSourceFiles ( (JavaUnoExtensionProjectEnvironment) l_projectEnvironment, i_parametersSettingInterpreter.getUnoComponentClassRelativeCoreNameToUnoInterfaceNamesAndUnoServiceRelativeCoreNamesMap ());
			}
		}
		catch (Exception l_exception) {
			Publisher.show (l_exception.toString ());
		}
	}
	// # Add methods of the implemented UNO interface END
	
	// # Add other member methods START
	// # Add other member methods END
	
	@Override
	public String getImplementationName () {
		return c_thisClass.getName ();
	}
	
	@Override
	public final boolean supportsService (String a_serviceName) {
		return c_serviceNamesSet.contains (a_serviceName);
	}
	
	@Override
	public final String [] getSupportedServiceNames () {
		return ArrayFactory. <String>createArray (String.class, c_serviceNamesSet);
	}
}
