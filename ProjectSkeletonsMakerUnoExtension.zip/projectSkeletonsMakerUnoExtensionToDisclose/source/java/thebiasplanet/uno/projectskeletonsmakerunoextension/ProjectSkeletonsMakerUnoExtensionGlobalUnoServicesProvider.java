package thebiasplanet.uno.projectskeletonsmakerunoextension;

import java.util.Set;
import java.util.Map;
import java.util.HashMap;
import com.sun.star.lang.XSingleComponentFactory;
import com.sun.star.registry.XRegistryKey;
import thebiasplanet.unoutilities.serviceshandling.GlobalUnoServicesProviderUtility;

// # Change the class name
public class ProjectSkeletonsMakerUnoExtensionGlobalUnoServicesProvider {
	private static final Map <String, Map <Class <?>, Set <String>>> c_implementationClassNameToImplementationClassToServiceNamesMapMap = new HashMap <String, Map <Class <?>, Set <String>>> ();
	
	static {
		// # Add implementation classes START
		ProjectSkeletonsMakerUnoComponent.setThisClassToServicesProvider (c_implementationClassNameToImplementationClassToServiceNamesMapMap);
		// # Add implementation classes END
	}
	
	public static XSingleComponentFactory __getComponentFactory (String a_implementationName) {
		return GlobalUnoServicesProviderUtility.getSingleComponentFactory (c_implementationClassNameToImplementationClassToServiceNamesMapMap, a_implementationName);
	}
	
	public static boolean __writeRegistryServiceInfo (XRegistryKey a_registryKey) {
		return GlobalUnoServicesProviderUtility.writeServicesInformationToRegistry (c_implementationClassNameToImplementationClassToServiceNamesMapMap, a_registryKey);
	}
}
