package thebiasplanet.projectskeletonsmaker.filesmakers;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.io.StringReader;
import javax.xml.transform.TransformerException;
import thebiasplanet.coreutilities.constantsgroups.*;
import thebiasplanet.coreutilities.stringshandling.StringsHandler;
import thebiasplanet.coreutilities.xmldatahandling.XmlDataHandler;
import thebiasplanet.unoutilities.constantsgroups.*;
import thebiasplanet.projectskeletonsmaker.constantsgroups.*;
import thebiasplanet.projectskeletonsmaker.environments.ProjectSkeletonsMakerEnvironment;
import thebiasplanet.projectskeletonsmaker.environments.JavaUnoExtensionProjectEnvironment;
import thebiasplanet.projectskeletonsmaker.environments.UnoAdditionalDataTypesProjectEnvironmentInterface;

public class JavaUnoExtensionProjectFilesMaker {
	private static String buildUnoComponentConfiguration (Map.Entry <String,  List <List <String>>> a_unoComponentClassRelativeCoreNameToUnoInterfaceNamesAndUnoServiceRelativeCoreNamesMapEntry) {
		String l_unoComponentClassRelativeName = String.format ("%s%s", a_unoComponentClassRelativeCoreNameToUnoInterfaceNamesAndUnoServiceRelativeCoreNamesMapEntry.getKey (), ClassNameSuffixesConstantsGroup.c_unoComponentClassNameSuffix);
		List <List <String>> l_unoInterfaceNamesAndUnoServiceRelativeCoreNames = a_unoComponentClassRelativeCoreNameToUnoInterfaceNamesAndUnoServiceRelativeCoreNamesMapEntry.getValue ();
		List <String> l_unoInterfaceNames = l_unoInterfaceNamesAndUnoServiceRelativeCoreNames.get (0);
		List <String> l_unoServiceRelativeCoreNames = l_unoInterfaceNamesAndUnoServiceRelativeCoreNames.get (1);
		String l_unoInterfaceNamesConfiguration = null;
		String l_unoInterfaceRelativeNamesConfiguration = null;
		if (l_unoInterfaceNames != null) {
			StringBuffer l_unoInterfaceNamesConfigurationBuffer = new StringBuffer ();
			StringBuffer l_unoInterfaceRelativeNamesConfigurationBuffer = new StringBuffer ();
			for (String l_unoInterfaceName: l_unoInterfaceNames) {
				l_unoInterfaceNamesConfigurationBuffer.append (String.format (ConfigurationXmlExpressionsConstantsGroup.c_unoInterfaceNameConfigurationFormat, l_unoInterfaceName));
				l_unoInterfaceRelativeNamesConfigurationBuffer.append (String.format (ConfigurationXmlExpressionsConstantsGroup.c_unoInterfaceRelativeNameConfigurationFormat, StringsHandler.getClassOrInterfaceRelativeName (l_unoInterfaceName)));
			}
			if (l_unoInterfaceNames.size () > 0) {
				l_unoInterfaceNamesConfiguration = String.format (ConfigurationXmlExpressionsConstantsGroup.c_unoInterfaceNamesConfigurationFormat, l_unoInterfaceNamesConfigurationBuffer.toString ());
				l_unoInterfaceRelativeNamesConfiguration = String.format (ConfigurationXmlExpressionsConstantsGroup.c_unoInterfaceRelativeNamesConfigurationFormat, l_unoInterfaceRelativeNamesConfigurationBuffer.toString ());
			}
			else {
				l_unoInterfaceNamesConfiguration = GeneralConstantsConstantsGroup.c_emptySpace;
				l_unoInterfaceRelativeNamesConfiguration = GeneralConstantsConstantsGroup.c_emptySpace;
			}
		}
		else {
			l_unoInterfaceNamesConfiguration = GeneralConstantsConstantsGroup.c_emptySpace;
			l_unoInterfaceRelativeNamesConfiguration = GeneralConstantsConstantsGroup.c_emptySpace;
		}
		String l_unoServiceRelativeNamesConfiguration = null;
		if (l_unoServiceRelativeCoreNames != null) {
			StringBuffer l_unoServiceRelativeNamesConfigurationBuffer = new StringBuffer ();
			for (String l_unoServiceRelativeCoreName: l_unoServiceRelativeCoreNames) {
				l_unoServiceRelativeNamesConfigurationBuffer.append (String.format (ConfigurationXmlExpressionsConstantsGroup.c_unoServiceRelativeNameConfigurationFormat, String.format ("%s%s", l_unoServiceRelativeCoreName, UnoServiceNameSuffixesConstantsGroup.c_unoServiceNameSuffix)));
			}
			if (l_unoServiceRelativeCoreNames.size () > 0) {
				l_unoServiceRelativeNamesConfiguration = String.format (ConfigurationXmlExpressionsConstantsGroup.c_unoServiceRelativeNamesConfigurationFormat, l_unoServiceRelativeNamesConfigurationBuffer.toString ());
			}
			else {
				l_unoServiceRelativeNamesConfiguration = GeneralConstantsConstantsGroup.c_emptySpace;
			}
		}
		else {
			l_unoServiceRelativeNamesConfiguration = GeneralConstantsConstantsGroup.c_emptySpace;
		}
		String l_unoComponentConfiguration = String.format (ConfigurationXmlExpressionsConstantsGroup.c_unoComponentConfigurationFormat, String.format (ConfigurationXmlExpressionsConstantsGroup.c_unoComponentClassRelativeNameConfigurationFormat, l_unoComponentClassRelativeName), l_unoInterfaceNamesConfiguration, l_unoInterfaceRelativeNamesConfiguration,  l_unoServiceRelativeNamesConfiguration);
		return l_unoComponentConfiguration;
	}
	
	private static String buildUnoComponentsConfiguration (LinkedHashMap <String, List <List <String>>> a_unoComponentClassRelativeCoreNameToUnoInterfaceNamesAndUnoServiceRelativeCoreNamesMap) {
		StringBuffer l_unoComponentsConfigurationBuffer = new StringBuffer ();
		for (Map.Entry <String, List <List <String>>> l_unoComponentClassRelativeCoreNameToUnoInterfaceNamesAndUnoServiceRelativeCoreNamesMapEntry: a_unoComponentClassRelativeCoreNameToUnoInterfaceNamesAndUnoServiceRelativeCoreNamesMap.entrySet ()) {
			l_unoComponentsConfigurationBuffer.append (buildUnoComponentConfiguration (l_unoComponentClassRelativeCoreNameToUnoInterfaceNamesAndUnoServiceRelativeCoreNamesMapEntry));
		}
		String l_unoComponentsConfiguration = l_unoComponentsConfiguration = String.format (ConfigurationXmlExpressionsConstantsGroup.c_unoComponentsConfigurationFormat, l_unoComponentsConfigurationBuffer.toString ());
		return l_unoComponentsConfiguration;
	}
	
	public static void makeJarManifestAdditionFile (JavaUnoExtensionProjectEnvironment a_projectEnvironment) throws FileNotFoundException, IOException, UnsupportedEncodingException, TransformerException {
		String l_styleSheetFilePath = String.format (LiteralExpressionsConstantsGroup.c_filePathFormat, ProjectSkeletonsMakerEnvironment.getStyleSheetsDirectoryPath (), FileNamesConstantsGroup.c_jarManifestAdditionFileStyleSheetFileName);
		String l_targetFilePath =  String.format (LiteralExpressionsConstantsGroup.c_filePathFormat, String.format (LiteralExpressionsConstantsGroup.c_directoryPathFormat, a_projectEnvironment.getProjectDirectoryPath (), DirectoryRelativePathsConstantsGroup.c_resourceDirectoryRelativePath), FileNamesConstantsGroup.c_jarManifestAdditionFileName);
		String l_globalUnoServicesProviderClassRelativeName = String.format ("%s%s", StringsHandler.getUpperCaseBeginnigString (a_projectEnvironment.getProjectName ()), ClassNameSuffixesConstantsGroup.c_unoGlobalServicesProviderClassNameSuffix);
		String l_javaPackageNameConfiguration = String.format (ConfigurationXmlExpressionsConstantsGroup.c_javaPackageNameConfigurationFormat, a_projectEnvironment.getUnoComponentsPackageName ());
		String l_globalUnoServicesProviderClassRelativeNameConfiguration = String.format (ConfigurationXmlExpressionsConstantsGroup.c_globalUnoServicesProviderClassRelativeNameConfigurationFormat, l_globalUnoServicesProviderClassRelativeName);
		String l_rootConfiguration = String.format (ConfigurationXmlExpressionsConstantsGroup.c_rootConfigurationFormat, String.format ("%s%s", l_javaPackageNameConfiguration, l_globalUnoServicesProviderClassRelativeNameConfiguration));
		XmlDataHandler.transform (new StringReader (l_rootConfiguration), l_styleSheetFilePath, l_targetFilePath, null, true);
	}
	
	public static void makeUnoExtensionManifestFile (JavaUnoExtensionProjectEnvironment a_projectEnvironment) throws FileNotFoundException, IOException, UnsupportedEncodingException, TransformerException {
		String l_styleSheetFilePath = String.format (LiteralExpressionsConstantsGroup.c_filePathFormat, ProjectSkeletonsMakerEnvironment.getStyleSheetsDirectoryPath (), FileNamesConstantsGroup.c_unoExtensionManifestFileStyleSheetFileName);
		String l_targetFilePath =  String.format (LiteralExpressionsConstantsGroup.c_filePathFormat, String.format (LiteralExpressionsConstantsGroup.c_directoryPathFormat, a_projectEnvironment.getProjectDirectoryPath (), DirectoryRelativePathsConstantsGroup.c_resourceDirectoryRelativePath), FileNamesConstantsGroup.c_unoExtensionManifestFileName);
		String l_unoComponentsSettingFileName = String.format (LiteralExpressionsConstantsGroup.c_fileNameFormat, a_projectEnvironment.getTargetName (), UnoFileNameSuffixesConstantsGroup.c_unoComponentsSettingFileNameSuffix);
		String l_unoComponentsSettingFileNameConfiguration = String.format (ConfigurationXmlExpressionsConstantsGroup.c_unoComponentsSettingFileNameConfigurationFormat, l_unoComponentsSettingFileName);
		String l_unoDataTypesMergedRegistryFileName = null;
		String l_unoDataTypesMergedRegistryFileNameConfiguration = null;
		if (a_projectEnvironment instanceof UnoAdditionalDataTypesProjectEnvironmentInterface) {
			l_unoDataTypesMergedRegistryFileName = String.format (LiteralExpressionsConstantsGroup.c_fileNameFormat, a_projectEnvironment.getTargetName (), UnoFileNameSuffixesConstantsGroup.c_unoDataTypesMergedRegistryFileNameSuffix);
			l_unoDataTypesMergedRegistryFileNameConfiguration = String.format (ConfigurationXmlExpressionsConstantsGroup.c_unoDataTypesMergedRegistryFileNameConfigurationFormat, l_unoDataTypesMergedRegistryFileName);
		}
		else {
			l_unoDataTypesMergedRegistryFileNameConfiguration = GeneralConstantsConstantsGroup.c_emptySpace;
		}
		String l_rootConfiguration = String.format (ConfigurationXmlExpressionsConstantsGroup.c_rootConfigurationFormat, String.format ("%s%s", l_unoComponentsSettingFileNameConfiguration, l_unoDataTypesMergedRegistryFileNameConfiguration));
		XmlDataHandler.transform (new StringReader (l_rootConfiguration), l_styleSheetFilePath, l_targetFilePath, null, true);
	}
	
	public static void makeUnoComponentsSettingFile (JavaUnoExtensionProjectEnvironment a_projectEnvironment, LinkedHashMap <String,List <List <String>>> a_unoComponentClassRelativeCoreNameToUnoServiceRelativeCoreNamesMap) throws FileNotFoundException, IOException, UnsupportedEncodingException, TransformerException {
		String l_styleSheetFilePath = String.format (LiteralExpressionsConstantsGroup.c_filePathFormat, ProjectSkeletonsMakerEnvironment.getStyleSheetsDirectoryPath (), FileNamesConstantsGroup.c_unoComponentsSettingFileStyleSheetFileName);
		String l_targetFilePath =  String.format (LiteralExpressionsConstantsGroup.c_filePathFormat, String.format (LiteralExpressionsConstantsGroup.c_directoryPathFormat, a_projectEnvironment.getProjectDirectoryPath (), DirectoryRelativePathsConstantsGroup.c_resourceDirectoryRelativePath), String.format (LiteralExpressionsConstantsGroup.c_fileNameFormat, a_projectEnvironment.getTargetName (), UnoFileNameSuffixesConstantsGroup.c_unoComponentsSettingFileNameSuffix));
		String l_jarFileName = String.format (LiteralExpressionsConstantsGroup.c_fileNameFormat, a_projectEnvironment.getTargetName (), FileNameSuffixesConstantsGroup.c_jarFileNameSuffix);
		String l_jarFileNameConfiguration = String.format (ConfigurationXmlExpressionsConstantsGroup.c_jarFileNameConfigurationFormat, l_jarFileName);
		String l_javaPackageNameConfiguration = String.format (ConfigurationXmlExpressionsConstantsGroup.c_javaPackageNameConfigurationFormat, a_projectEnvironment.getUnoComponentsPackageName ());
		String l_unoComponentsConfiguration = buildUnoComponentsConfiguration (a_unoComponentClassRelativeCoreNameToUnoServiceRelativeCoreNamesMap);
		String l_rootConfiguration = String.format (ConfigurationXmlExpressionsConstantsGroup.c_rootConfigurationFormat, String.format ("%s%s%s", l_jarFileNameConfiguration, l_javaPackageNameConfiguration, l_unoComponentsConfiguration));
		XmlDataHandler.transform (new StringReader (l_rootConfiguration), l_styleSheetFilePath, l_targetFilePath, null, true);
	}
	
	public static void makeGlobalUnoServicesProviderSourceFile (JavaUnoExtensionProjectEnvironment a_projectEnvironment, LinkedHashMap <String, List <List <String>>> a_unoComponentClassRelativeCoreNameToUnoServiceRelativeCoreNamesMap) throws FileNotFoundException, IOException, UnsupportedEncodingException, TransformerException {
		String l_styleSheetFilePath = String.format (LiteralExpressionsConstantsGroup.c_filePathFormat, ProjectSkeletonsMakerEnvironment.getStyleSheetsDirectoryPath (), FileNamesConstantsGroup.c_unoGlobalServicesProviderSourceFileStyleSheetFileName);
		String l_globalUnoServicesProviderClassRelativeName = String.format ("%s%s", StringsHandler.getUpperCaseBeginnigString (a_projectEnvironment.getProjectName ()), ClassNameSuffixesConstantsGroup.c_unoGlobalServicesProviderClassNameSuffix);
		String l_globalUnoServicesProviderClassName = String.format (LiteralExpressionsConstantsGroup.c_javaClassNameFormat, a_projectEnvironment.getUnoComponentsPackageName (), l_globalUnoServicesProviderClassRelativeName);
		String l_targetFilePath =  String.format (LiteralExpressionsConstantsGroup.c_filePathFormat, String.format (LiteralExpressionsConstantsGroup.c_directoryPathFormat, a_projectEnvironment.getProjectDirectoryPath (), DirectoryRelativePathsConstantsGroup.c_javaDirectoryRelativePath), String.format (LiteralExpressionsConstantsGroup.c_fileNameFormat, l_globalUnoServicesProviderClassName.replaceAll (RegularExpressionsConstantsGroup.c_javaPackageDelimiterRegularExpression.pattern (), LiteralExpressionsConstantsGroup.c_directoryDelimiter), FileNameSuffixesConstantsGroup.c_javaFileNameSuffix));
		String l_javaPackageNameConfiguration = String.format (ConfigurationXmlExpressionsConstantsGroup.c_javaPackageNameConfigurationFormat, a_projectEnvironment.getUnoComponentsPackageName ());
		String l_globalUnoServicesProviderClassRelativeNameConfiguration = String.format (ConfigurationXmlExpressionsConstantsGroup.c_globalUnoServicesProviderClassRelativeNameConfigurationFormat, l_globalUnoServicesProviderClassRelativeName);
		String l_unoComponentsConfiguration = buildUnoComponentsConfiguration (a_unoComponentClassRelativeCoreNameToUnoServiceRelativeCoreNamesMap);
		String l_rootConfiguration = String.format (ConfigurationXmlExpressionsConstantsGroup.c_rootConfigurationFormat, String.format ("%s%s%s", l_javaPackageNameConfiguration, l_globalUnoServicesProviderClassRelativeNameConfiguration, l_unoComponentsConfiguration));
		XmlDataHandler.transform (new StringReader (l_rootConfiguration), l_styleSheetFilePath, l_targetFilePath, null, true);
	}
	
	public static void makeUnoComponentSourceFiles (JavaUnoExtensionProjectEnvironment a_projectEnvironment, LinkedHashMap <String, List <List <String>>> a_unoComponentClassRelativeCoreNameToUnoInterfaceNamesAndUnoServiceRelativeCoreNamesMap) throws FileNotFoundException, IOException, UnsupportedEncodingException, TransformerException {
		String l_styleSheetFilePath = String.format (LiteralExpressionsConstantsGroup.c_filePathFormat, ProjectSkeletonsMakerEnvironment.getStyleSheetsDirectoryPath (), FileNamesConstantsGroup.c_unoComponentSourceFileStyleSheetFileName);
		for (Map.Entry <String,  List <List <String>>> l_unoComponentClassRelativeCoreNameToUnoInterfaceNamesAndUnoServiceRelativeCoreNamesMapEntry: a_unoComponentClassRelativeCoreNameToUnoInterfaceNamesAndUnoServiceRelativeCoreNamesMap.entrySet ()) {
			String l_unoComponentClassRelativeName = String.format ("%s%s", l_unoComponentClassRelativeCoreNameToUnoInterfaceNamesAndUnoServiceRelativeCoreNamesMapEntry.getKey (), ClassNameSuffixesConstantsGroup.c_unoComponentClassNameSuffix) ;
			String l_unoComponentClassName = String.format (LiteralExpressionsConstantsGroup.c_javaClassNameFormat, a_projectEnvironment.getUnoComponentsPackageName (), l_unoComponentClassRelativeName);
			String l_targetFilePath =  String.format (LiteralExpressionsConstantsGroup.c_filePathFormat, String.format (LiteralExpressionsConstantsGroup.c_directoryPathFormat, a_projectEnvironment.getProjectDirectoryPath (), DirectoryRelativePathsConstantsGroup.c_javaDirectoryRelativePath), String.format (LiteralExpressionsConstantsGroup.c_fileNameFormat, l_unoComponentClassName.replaceAll (RegularExpressionsConstantsGroup.c_javaPackageDelimiterRegularExpression.pattern (), LiteralExpressionsConstantsGroup.c_directoryDelimiter), FileNameSuffixesConstantsGroup.c_javaFileNameSuffix));
			String l_javaPackageNameConfiguration = String.format (ConfigurationXmlExpressionsConstantsGroup.c_javaPackageNameConfigurationFormat, a_projectEnvironment.getUnoComponentsPackageName ());
			String l_unoComponentConfiguration = buildUnoComponentConfiguration (l_unoComponentClassRelativeCoreNameToUnoInterfaceNamesAndUnoServiceRelativeCoreNamesMapEntry);
			String l_rootConfiguration = String.format (ConfigurationXmlExpressionsConstantsGroup.c_rootConfigurationFormat, String.format ("%s%s", l_javaPackageNameConfiguration, l_unoComponentConfiguration));
			XmlDataHandler.transform (new StringReader (l_rootConfiguration), l_styleSheetFilePath, l_targetFilePath, null, false);
		}
	}
}
