package thebiasplanet.projectskeletonsmaker.filesmakers;

import java.util.List;
import java.util.regex.Matcher;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.io.StringReader;
import javax.xml.transform.TransformerException;
import thebiasplanet.coreutilities.constantsgroups.*;
import thebiasplanet.coreutilities.stringshandling.StringsHandler;
import thebiasplanet.coreutilities.xmldatahandling.XmlDataHandler;
import thebiasplanet.unoutilities.constantsgroups.*;
import thebiasplanet.projectskeletonsmaker.constantsgroups.*;
import thebiasplanet.projectskeletonsmaker.environments.ProjectSkeletonsMakerEnvironment;
import thebiasplanet.projectskeletonsmaker.environments.ProjectEnvironment;
import thebiasplanet.projectskeletonsmaker.environments.JavaProjectEnvironment;

public class ProjectFilesMaker {
	private static String getAntPath (String a_pathExpression) {
		List <String> l_terms = StringsHandler.getAddedTerms (a_pathExpression);
		StringBuffer l_antPathBuffer = new StringBuffer ();
		for (String l_term: l_terms) {
			Matcher l_doubleQuotedTermMatcher = RegularExpressionsConstantsGroup.c_doubleQuotedTermRegularExpression.matcher (l_term);
			if (l_doubleQuotedTermMatcher.find ()) {
				l_antPathBuffer.append (l_doubleQuotedTermMatcher.group (1));
			}
			else {
				l_antPathBuffer.append (String.format (LiteralExpressionsConstantsGroup.c_propertyValueFormat, l_term));
			}
		}
		return l_antPathBuffer.toString ();
	}
	
	public static void makeGradleBuildScript (ProjectEnvironment a_projectEnvironment) throws FileNotFoundException, IOException, UnsupportedEncodingException, TransformerException {
		String l_styleSheetFilePath = String.format (LiteralExpressionsConstantsGroup.c_filePathFormat, ProjectSkeletonsMakerEnvironment.getStyleSheetsDirectoryPath (), FileNamesConstantsGroup.c_gradleBuildScriptStyleSheetFileName);
		String l_targetFilePath =  String.format (LiteralExpressionsConstantsGroup.c_filePathFormat, a_projectEnvironment.getProjectDirectoryPath (), FileNamesConstantsGroup.c_gradleBuildScriptName);
		String l_targetNameConfiguration = String.format (ConfigurationXmlExpressionsConstantsGroup.c_targetNameConfigurationFormat, a_projectEnvironment.getTargetName ());
		String l_defaultTaskNameConfiguration = String.format (ConfigurationXmlExpressionsConstantsGroup.c_defaultTaskNameConfigurationFormat, a_projectEnvironment.getDefaultTaskName ());
		String l_includedJarFilePathExpressionsConfiguration = null;
		String l_otherClassesPathExpressionsConfiguration = null;
		if (a_projectEnvironment instanceof JavaProjectEnvironment) {
			JavaProjectEnvironment l_javaProjectEnvironment = (JavaProjectEnvironment) a_projectEnvironment;
			StringBuffer l_includedJarFilePathExpressionsConfigurationBuffer = new StringBuffer ();
			for (String l_includedJarFilePathExpression: l_javaProjectEnvironment.getIncludedJarFilePathExpressions ()) {
				l_includedJarFilePathExpressionsConfigurationBuffer.append (String.format (ConfigurationXmlExpressionsConstantsGroup.c_includedJarFilePathExpressionConfigurationFormat, l_includedJarFilePathExpression));
			}
			l_includedJarFilePathExpressionsConfiguration = String.format (ConfigurationXmlExpressionsConstantsGroup.c_includedJarFilePathExpressionsConfigurationFormat, l_includedJarFilePathExpressionsConfigurationBuffer.toString ());
			StringBuffer l_otherClassesPathExpressionsConfigurationBuffer = new StringBuffer ();
			for (String l_otherClassesPathExpression: l_javaProjectEnvironment.getOtherClassesPathExpressions ()) {
				l_otherClassesPathExpressionsConfigurationBuffer.append (String.format (ConfigurationXmlExpressionsConstantsGroup.c_otherClassesPathExpressionConfigurationFormat, l_otherClassesPathExpression));
			}
			l_otherClassesPathExpressionsConfiguration = String.format (ConfigurationXmlExpressionsConstantsGroup.c_otherClassesPathExpressionsConfigurationFormat, l_otherClassesPathExpressionsConfigurationBuffer.toString ());
		}
		else {
			l_includedJarFilePathExpressionsConfiguration = "";
			l_otherClassesPathExpressionsConfiguration = "";
		}
		String l_referencedProjectDirectoryPathExpressionsConfiguration = null;
		StringBuffer l_referencedProjectDirectoryPathExpressionsConfigurationBuffer = new StringBuffer ();
		for (String l_referencedProjectDirectoryPathExpression: a_projectEnvironment.getReferencedProjectDirectoryPathExpressions ()) {
			l_referencedProjectDirectoryPathExpressionsConfigurationBuffer.append (String.format (ConfigurationXmlExpressionsConstantsGroup.c_referencedProjectDirectoryPathExpressionConfigurationFormat, l_referencedProjectDirectoryPathExpression));
		}
		l_referencedProjectDirectoryPathExpressionsConfiguration = String.format (ConfigurationXmlExpressionsConstantsGroup.c_referencedProjectDirectoryPathExpressionsConfigurationFormat, l_referencedProjectDirectoryPathExpressionsConfigurationBuffer.toString ());
		String l_rootConfiguration = String.format (ConfigurationXmlExpressionsConstantsGroup.c_rootConfigurationFormat, String.format ("%s%s%s%s%s", l_targetNameConfiguration, l_defaultTaskNameConfiguration, l_includedJarFilePathExpressionsConfiguration, l_otherClassesPathExpressionsConfiguration, l_referencedProjectDirectoryPathExpressionsConfiguration));
		XmlDataHandler.transform (new StringReader (l_rootConfiguration), l_styleSheetFilePath, l_targetFilePath, null, true);
	}
	
	public static void makeAntBuildFile (ProjectEnvironment a_projectEnvironment) throws FileNotFoundException, IOException, UnsupportedEncodingException, TransformerException {
		String l_styleSheetFilePath = String.format (LiteralExpressionsConstantsGroup.c_filePathFormat, ProjectSkeletonsMakerEnvironment.getStyleSheetsDirectoryPath (), FileNamesConstantsGroup.c_antBuildFileStyleSheetFileName);
		String l_targetFilePath =  String.format (LiteralExpressionsConstantsGroup.c_filePathFormat, a_projectEnvironment.getProjectDirectoryPath (), FileNamesConstantsGroup.c_antBuildFileName);
		String l_targetNameConfiguration = String.format (ConfigurationXmlExpressionsConstantsGroup.c_targetNameConfigurationFormat, a_projectEnvironment.getTargetName ());
		String l_defaultTaskNameConfiguration = String.format (ConfigurationXmlExpressionsConstantsGroup.c_defaultTaskNameConfigurationFormat, a_projectEnvironment.getDefaultTaskName ());
		String l_includedJarFilePathExpressionsConfiguration = null;
		String l_otherClassesPathExpressionsConfiguration = null;
		if (a_projectEnvironment instanceof JavaProjectEnvironment) {
			JavaProjectEnvironment l_javaProjectEnvironment = (JavaProjectEnvironment) a_projectEnvironment;
			StringBuffer l_includedJarFilePathExpressionsConfigurationBuffer = new StringBuffer ();
			for (String l_includedJarFilePathExpression: l_javaProjectEnvironment.getIncludedJarFilePathExpressions ()) {
				l_includedJarFilePathExpressionsConfigurationBuffer.append (String.format (ConfigurationXmlExpressionsConstantsGroup.c_includedJarFilePathExpressionConfigurationFormat, getAntPath (l_includedJarFilePathExpression)));
			}
			l_includedJarFilePathExpressionsConfiguration = String.format (ConfigurationXmlExpressionsConstantsGroup.c_includedJarFilePathExpressionsConfigurationFormat, l_includedJarFilePathExpressionsConfigurationBuffer.toString ());
			StringBuffer l_otherClassesPathExpressionsConfigurationBuffer = new StringBuffer ();
			for (String l_otherClassesPathExpression: l_javaProjectEnvironment.getOtherClassesPathExpressions ()) {
				l_otherClassesPathExpressionsConfigurationBuffer.append (String.format (ConfigurationXmlExpressionsConstantsGroup.c_otherClassesPathExpressionConfigurationFormat, getAntPath (l_otherClassesPathExpression)));
			}
			l_otherClassesPathExpressionsConfiguration = String.format (ConfigurationXmlExpressionsConstantsGroup.c_otherClassesPathExpressionsConfigurationFormat, l_otherClassesPathExpressionsConfigurationBuffer.toString ());
		}
		else {
			l_includedJarFilePathExpressionsConfiguration = "";
			l_otherClassesPathExpressionsConfiguration = "";
		}
		String l_rootConfiguration = String.format (ConfigurationXmlExpressionsConstantsGroup.c_rootConfigurationFormat, String.format ("%s%s%s%s", l_targetNameConfiguration, l_defaultTaskNameConfiguration, l_includedJarFilePathExpressionsConfiguration, l_otherClassesPathExpressionsConfiguration));
		XmlDataHandler.transform (new StringReader (l_rootConfiguration), l_styleSheetFilePath, l_targetFilePath, null, true);
	}
	
	public static void makeJarManifestAdditionFile (ProjectEnvironment a_projectEnvironment) throws FileNotFoundException, IOException, UnsupportedEncodingException, TransformerException {
		String l_styleSheetFilePath = String.format (LiteralExpressionsConstantsGroup.c_filePathFormat, ProjectSkeletonsMakerEnvironment.getStyleSheetsDirectoryPath (), FileNamesConstantsGroup.c_jarManifestAdditionFileStyleSheetFileName);
		String l_targetFilePath =  String.format (LiteralExpressionsConstantsGroup.c_filePathFormat, String.format (LiteralExpressionsConstantsGroup.c_directoryPathFormat, a_projectEnvironment.getProjectDirectoryPath (), DirectoryRelativePathsConstantsGroup.c_resourceDirectoryRelativePath), FileNamesConstantsGroup.c_jarManifestAdditionFileName);
		String l_rootConfiguration = String.format (ConfigurationXmlExpressionsConstantsGroup.c_rootConfigurationFormat, GeneralConstantsConstantsGroup.c_emptySpace);
		XmlDataHandler.transform (new StringReader (l_rootConfiguration), l_styleSheetFilePath, l_targetFilePath, null, true);
	}
}
