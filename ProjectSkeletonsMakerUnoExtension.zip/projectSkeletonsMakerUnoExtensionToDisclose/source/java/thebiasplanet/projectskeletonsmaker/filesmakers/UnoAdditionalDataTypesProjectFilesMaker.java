package thebiasplanet.projectskeletonsmaker.filesmakers;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.io.StringReader;
import javax.xml.transform.TransformerException;
import thebiasplanet.coreutilities.constantsgroups.*;
import thebiasplanet.coreutilities.stringshandling.StringsHandler;
import thebiasplanet.coreutilities.xmldatahandling.XmlDataHandler;
import thebiasplanet.unoutilities.constantsgroups.*;
import thebiasplanet.projectskeletonsmaker.constantsgroups.*;
import thebiasplanet.projectskeletonsmaker.environments.ProjectSkeletonsMakerEnvironment;
import thebiasplanet.projectskeletonsmaker.environments.UnoAdditionalDataTypesProjectEnvironmentInterface;

public class UnoAdditionalDataTypesProjectFilesMaker {
	private static String buildUnoInterfaceConfiguration (String a_moduleName, Map.Entry <String,  List <String>> a_unoInterfaceRelativeCoreNameToSuperUnoInterfaceNamesMapEntry) {
		String l_unoInterfaceRelativeName = String.format ("%s%s", InterfaceNamePrefixesConstantsGroup.c_unoInterfaceNamePrefix, a_unoInterfaceRelativeCoreNameToSuperUnoInterfaceNamesMapEntry.getKey ());
		String l_unoInterfaceName = String.format (LiteralExpressionsConstantsGroup.c_javaClassNameFormat, a_moduleName, l_unoInterfaceRelativeName);
		List <String> l_superUnoInterfaceNames = a_unoInterfaceRelativeCoreNameToSuperUnoInterfaceNamesMapEntry.getValue ();
		String l_superUnoInterfaceDelimitedByColonsNamesConfiguration = null;
		String l_superUnoInterfaceFileQuotedNamesConfiguration = null;
		if (l_superUnoInterfaceNames != null) {
			StringBuffer l_superUnoInterfaceDelimitedByColonsNamesConfigurationBuffer = new StringBuffer ();
			StringBuffer l_superUnoInterfaceFileQuotedNamesConfigurationBuffer = new StringBuffer ();
			for (String l_superUnoInterfaceName: l_superUnoInterfaceNames) {
				l_superUnoInterfaceDelimitedByColonsNamesConfigurationBuffer.append (String.format (ConfigurationXmlExpressionsConstantsGroup.c_superUnoInterfaceDelimitedByColonsNameConfigurationFormat, l_superUnoInterfaceName.replaceAll (RegularExpressionsConstantsGroup.c_javaPackageDelimiterRegularExpression.pattern (), UnoLiteralExpressionsConstantsGroup.c_moduleDlimiter)));
				l_superUnoInterfaceFileQuotedNamesConfigurationBuffer.append (String.format (ConfigurationXmlExpressionsConstantsGroup.c_superUnoInterfaceSourceFileQuotedRelativePathConfigurationFormat, XmlDataHandler.getEscapedXmlText (String.format (l_superUnoInterfaceName.startsWith (UnoModuleNamesConstantsGroup.c_standardBasemoduleName) ? LiteralExpressionsConstantsGroup.c_quotedByAngleBracketsFormat : LiteralExpressionsConstantsGroup.c_quotedByDoubleQuotationsFormat, String.format (UnoLiteralExpressionsConstantsGroup.c_unoIdlFileNameFormat, l_superUnoInterfaceName.replaceAll (RegularExpressionsConstantsGroup.c_javaPackageDelimiterRegularExpression.pattern (), LiteralExpressionsConstantsGroup.c_directoryDelimiter))))));
			}
			if (l_superUnoInterfaceNames.size () > 0) {
				l_superUnoInterfaceDelimitedByColonsNamesConfiguration = String.format (ConfigurationXmlExpressionsConstantsGroup.c_superUnoInterfaceDelimitedByColonsNamesConfigurationFormat, l_superUnoInterfaceDelimitedByColonsNamesConfigurationBuffer.toString ());
				l_superUnoInterfaceFileQuotedNamesConfiguration = String.format (ConfigurationXmlExpressionsConstantsGroup.c_superUnoInterfaceSourceFileQuotedRelativePathsConfigurationFormat, l_superUnoInterfaceFileQuotedNamesConfigurationBuffer.toString ());
			}
			else {
				l_superUnoInterfaceDelimitedByColonsNamesConfiguration = GeneralConstantsConstantsGroup.c_emptySpace;
				l_superUnoInterfaceFileQuotedNamesConfiguration = GeneralConstantsConstantsGroup.c_emptySpace;
			}
		}
		else {
			l_superUnoInterfaceDelimitedByColonsNamesConfiguration = GeneralConstantsConstantsGroup.c_emptySpace;
			l_superUnoInterfaceFileQuotedNamesConfiguration = GeneralConstantsConstantsGroup.c_emptySpace;
		}
		String l_unoInterfaceDefinitionNameConfigulation = String.format (ConfigurationXmlExpressionsConstantsGroup.c_unoInterfaceDefinitionNameConfigurationFormat, String.format (LiteralExpressionsConstantsGroup.c_definitionNameFormat, l_unoInterfaceName.replaceAll (RegularExpressionsConstantsGroup.c_javaPackageDelimiterRegularExpression.pattern (), LiteralExpressionsConstantsGroup.c_nameElementDelimiter)));
		String l_unoModuleBeginningExpressionConfigulation = String.format (ConfigurationXmlExpressionsConstantsGroup.c_unoModuleBeginningExpressionConfigulationFormat, StringsHandler.getElementsReplacedString (a_moduleName, LiteralExpressionsConstantsGroup.c_javaPackageDelimiter, UnoLiteralExpressionsConstantsGroup.c_unoModuleBeginningRelativeExpressionFormat));
		String l_unoModuleEndExpressionConfigulation = String.format (ConfigurationXmlExpressionsConstantsGroup.c_unoModuleEndExpressionConfigulationFormat, StringsHandler.getElementsReplacedString (a_moduleName, LiteralExpressionsConstantsGroup.c_javaPackageDelimiter, UnoLiteralExpressionsConstantsGroup.c_unoModuleEndRelativeExpressionFormat));
		String l_unoInterfaceConfiguration = String.format (ConfigurationXmlExpressionsConstantsGroup.c_unoInterfaceConfigurationFormat, String.format (ConfigurationXmlExpressionsConstantsGroup.c_unoInterfaceRelativeNameConfigurationFormat, l_unoInterfaceRelativeName), l_unoModuleBeginningExpressionConfigulation, l_unoModuleEndExpressionConfigulation, l_superUnoInterfaceDelimitedByColonsNamesConfiguration, l_superUnoInterfaceFileQuotedNamesConfiguration, l_unoInterfaceDefinitionNameConfigulation);
		return l_unoInterfaceConfiguration;
	}
	
	private static String buildUnoServiceConfiguration (String a_moduleName, Map.Entry <String,  String> a_unoServiceRelativeCoreNameToReturnTypeUnoInterfaceNameMapEntry) {
		String l_unoServiceRelativeName = String.format ("%s%s", a_unoServiceRelativeCoreNameToReturnTypeUnoInterfaceNameMapEntry.getKey (), UnoServiceNameSuffixesConstantsGroup.c_unoServiceNameSuffix);
		String l_unoServiceName = String.format (LiteralExpressionsConstantsGroup.c_javaClassNameFormat, a_moduleName, l_unoServiceRelativeName);
		String l_returnTypeUnoInterfaceName = a_unoServiceRelativeCoreNameToReturnTypeUnoInterfaceNameMapEntry.getValue ();
		String l_returnTypeUnoInterfaceDelimitedByColonsNameConfiguration = null;
		String l_returnTypeUnoInterfaceFileQuotedNameConfiguration = null;
		if (l_returnTypeUnoInterfaceName != null) {
			l_returnTypeUnoInterfaceDelimitedByColonsNameConfiguration = String.format (ConfigurationXmlExpressionsConstantsGroup.c_returnTypeUnoInterfaceDelimitedByColonsNameConfigurationFormat, l_returnTypeUnoInterfaceName.replaceAll (RegularExpressionsConstantsGroup.c_javaPackageDelimiterRegularExpression.pattern (), UnoLiteralExpressionsConstantsGroup.c_moduleDlimiter));
			l_returnTypeUnoInterfaceFileQuotedNameConfiguration = String.format (ConfigurationXmlExpressionsConstantsGroup.c_returnTypeUnoInterfaceSourceFileQuotedRelativePathConfigurationFormat, XmlDataHandler.getEscapedXmlText (String.format (l_returnTypeUnoInterfaceName.startsWith (UnoModuleNamesConstantsGroup.c_standardBasemoduleName) ? LiteralExpressionsConstantsGroup.c_quotedByAngleBracketsFormat : LiteralExpressionsConstantsGroup.c_quotedByDoubleQuotationsFormat, String.format (UnoLiteralExpressionsConstantsGroup.c_unoIdlFileNameFormat, l_returnTypeUnoInterfaceName.replaceAll (RegularExpressionsConstantsGroup.c_javaPackageDelimiterRegularExpression.pattern (), LiteralExpressionsConstantsGroup.c_directoryDelimiter)))));
		}
		else {
			l_returnTypeUnoInterfaceDelimitedByColonsNameConfiguration = GeneralConstantsConstantsGroup.c_emptySpace;
			l_returnTypeUnoInterfaceFileQuotedNameConfiguration = GeneralConstantsConstantsGroup.c_emptySpace;
		}
		String l_unoServiceSpecificServiceInstancesFactoryDefinitionNameConfigulation = String.format (ConfigurationXmlExpressionsConstantsGroup.c_unoServiceSpecificServiceInstancesFactoryDefinitionNameConfigurationFormat, String.format (LiteralExpressionsConstantsGroup.c_definitionNameFormat, l_unoServiceName.replaceAll (RegularExpressionsConstantsGroup.c_javaPackageDelimiterRegularExpression.pattern (), LiteralExpressionsConstantsGroup.c_nameElementDelimiter)));
		String l_unoModuleBeginningExpressionConfigulation = String.format (ConfigurationXmlExpressionsConstantsGroup.c_unoModuleBeginningExpressionConfigulationFormat, StringsHandler.getElementsReplacedString (a_moduleName, LiteralExpressionsConstantsGroup.c_javaPackageDelimiter, UnoLiteralExpressionsConstantsGroup.c_unoModuleBeginningRelativeExpressionFormat));
		String l_unoModuleEndExpressionConfigulation = String.format (ConfigurationXmlExpressionsConstantsGroup.c_unoModuleEndExpressionConfigulationFormat, StringsHandler.getElementsReplacedString (a_moduleName, LiteralExpressionsConstantsGroup.c_javaPackageDelimiter, UnoLiteralExpressionsConstantsGroup.c_unoModuleEndRelativeExpressionFormat));
		String l_unoServiceConfiguration = String.format (ConfigurationXmlExpressionsConstantsGroup.c_unoServiceConfigurationFormat, String.format (ConfigurationXmlExpressionsConstantsGroup.c_unoServiceRelativeNameConfigurationFormat, l_unoServiceRelativeName), l_unoModuleBeginningExpressionConfigulation, l_unoModuleEndExpressionConfigulation, l_returnTypeUnoInterfaceDelimitedByColonsNameConfiguration, l_returnTypeUnoInterfaceFileQuotedNameConfiguration, l_unoServiceSpecificServiceInstancesFactoryDefinitionNameConfigulation);
		return l_unoServiceConfiguration;
	}
	
	public static void makeUnoInterfaceSourceFiles (UnoAdditionalDataTypesProjectEnvironmentInterface a_projectEnvironment, LinkedHashMap <String, LinkedHashMap <String, List <String>>>  a_unoModuleNameToUnoInterfaceRelativeCoreNameToSuperUnoInterfaceNamesMapMap) throws FileNotFoundException, IOException, UnsupportedEncodingException, TransformerException {
		String l_styleSheetFilePath = String.format (LiteralExpressionsConstantsGroup.c_filePathFormat, ProjectSkeletonsMakerEnvironment.getStyleSheetsDirectoryPath (), FileNamesConstantsGroup.c_unoInterfaceSourceFileStyleSheetFileName);
		for (Map.Entry <String, LinkedHashMap <String, List <String>>> l_unoModuleNameToUnoInterfaceRelativeCoreNameToSuperUnoInterfaceNamesMapMapEntry: a_unoModuleNameToUnoInterfaceRelativeCoreNameToSuperUnoInterfaceNamesMapMap.entrySet ()) {
			String l_moduleName = l_unoModuleNameToUnoInterfaceRelativeCoreNameToSuperUnoInterfaceNamesMapMapEntry.getKey ();
			for (Map.Entry <String,  List <String>> l_unoInterfaceRelativeCoreNameToSuperUnoInterfaceNamesMapEntry: l_unoModuleNameToUnoInterfaceRelativeCoreNameToSuperUnoInterfaceNamesMapMapEntry.getValue ().entrySet ()) {
				String l_unoInterfaceRelativeName = String.format ("%s%s", InterfaceNamePrefixesConstantsGroup.c_unoInterfaceNamePrefix, l_unoInterfaceRelativeCoreNameToSuperUnoInterfaceNamesMapEntry.getKey ()) ;
				String l_unoInterfaceName = String.format (LiteralExpressionsConstantsGroup.c_javaClassNameFormat, l_moduleName, l_unoInterfaceRelativeName);
				String l_targetFilePath =  String.format (LiteralExpressionsConstantsGroup.c_filePathFormat, String.format (LiteralExpressionsConstantsGroup.c_directoryPathFormat, a_projectEnvironment.getProjectDirectoryPath (), DirectoryRelativePathsConstantsGroup.c_unoIdlDirectoryRelativePath), String.format (LiteralExpressionsConstantsGroup.c_fileNameFormat, l_unoInterfaceName.replaceAll (RegularExpressionsConstantsGroup.c_javaPackageDelimiterRegularExpression.pattern (), LiteralExpressionsConstantsGroup.c_directoryDelimiter), UnoFileNameSuffixesConstantsGroup.c_unoIdlFileNameSuffix));
				String l_unoInterfaceConfiguration = buildUnoInterfaceConfiguration (l_moduleName, l_unoInterfaceRelativeCoreNameToSuperUnoInterfaceNamesMapEntry);
				String l_rootConfiguration = String.format (ConfigurationXmlExpressionsConstantsGroup.c_rootConfigurationFormat, String.format ("%s", l_unoInterfaceConfiguration));
				XmlDataHandler.transform (new StringReader (l_rootConfiguration), l_styleSheetFilePath, l_targetFilePath, null, false);
			}
		}
	}
	
	public static void makeUnoServiceSpecificServiceInstancesFactorySourceFiles (UnoAdditionalDataTypesProjectEnvironmentInterface a_projectEnvironment, LinkedHashMap <String, LinkedHashMap <String, String>>  a_unoModuleNameToUnoServiceRelativeCoreNameToReturnTypeUnoInterfaceNameMapMap) throws FileNotFoundException, IOException, UnsupportedEncodingException, TransformerException {
		String l_styleSheetFilePath = String.format (LiteralExpressionsConstantsGroup.c_filePathFormat, ProjectSkeletonsMakerEnvironment.getStyleSheetsDirectoryPath (), FileNamesConstantsGroup.c_unoServiceSpecificServiceInstancesFactorySourceFileStyleSheetFileName);
		for (Map.Entry <String, LinkedHashMap <String, String>> l_unoModuleNameToUnoServiceRelativeCoreNameToReturnTypeUnoInterfaceNameMapMapEntry: a_unoModuleNameToUnoServiceRelativeCoreNameToReturnTypeUnoInterfaceNameMapMap.entrySet ()) {
			String l_moduleName = l_unoModuleNameToUnoServiceRelativeCoreNameToReturnTypeUnoInterfaceNameMapMapEntry.getKey ();
			for (Map.Entry <String,  String> l_unoServiceRelativeCoreNameToReturnTypeUnoInterfaceNameMapEntry: l_unoModuleNameToUnoServiceRelativeCoreNameToReturnTypeUnoInterfaceNameMapMapEntry.getValue ().entrySet ()) {
				String l_unoServiceRelativeName = String.format ("%s%s", l_unoServiceRelativeCoreNameToReturnTypeUnoInterfaceNameMapEntry.getKey (), UnoServiceNameSuffixesConstantsGroup.c_unoServiceNameSuffix);
				String l_unoServiceName = String.format (LiteralExpressionsConstantsGroup.c_javaClassNameFormat, l_moduleName, l_unoServiceRelativeName);
				String l_targetFilePath =  String.format (LiteralExpressionsConstantsGroup.c_filePathFormat, String.format (LiteralExpressionsConstantsGroup.c_directoryPathFormat, a_projectEnvironment.getProjectDirectoryPath (), DirectoryRelativePathsConstantsGroup.c_unoIdlDirectoryRelativePath), String.format (LiteralExpressionsConstantsGroup.c_fileNameFormat, l_unoServiceName.replaceAll (RegularExpressionsConstantsGroup.c_javaPackageDelimiterRegularExpression.pattern (), LiteralExpressionsConstantsGroup.c_directoryDelimiter), UnoFileNameSuffixesConstantsGroup.c_unoIdlFileNameSuffix));
				String l_unoServiceConfiguration = buildUnoServiceConfiguration (l_moduleName, l_unoServiceRelativeCoreNameToReturnTypeUnoInterfaceNameMapEntry);
				String l_rootConfiguration = String.format (ConfigurationXmlExpressionsConstantsGroup.c_rootConfigurationFormat, String.format ("%s", l_unoServiceConfiguration));
				XmlDataHandler.transform (new StringReader (l_rootConfiguration), l_styleSheetFilePath, l_targetFilePath, null, false);
			}
		}
	}
}
