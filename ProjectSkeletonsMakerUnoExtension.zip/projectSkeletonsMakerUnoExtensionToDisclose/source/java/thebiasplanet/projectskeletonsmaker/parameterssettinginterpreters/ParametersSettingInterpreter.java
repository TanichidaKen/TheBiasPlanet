package thebiasplanet.projectskeletonsmaker.parameterssettinginterpreters;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import com.sun.star.uno.XComponentContext;
import thebiasplanet.coreutilities.constantsgroups.*;
import thebiasplanet.unoutilities.constantsgroups.*;
import thebiasplanet.unoutilities.documentshandling.spreadsheetsdocumentshandling.UnoSpreadSheet;
import thebiasplanet.unoutilities.documentshandling.spreadsheetsdocumentshandling.UnoSpreadSheetCell;
import thebiasplanet.projectskeletonsmaker.environments.ProjectEnvironment;
import thebiasplanet.projectskeletonsmaker.environments.UnoAdditionalDataTypesProjectEnvironment;
import thebiasplanet.projectskeletonsmaker.environments.JavaUnoExtensionProjectEnvironment;
import thebiasplanet.projectskeletonsmaker.environments.JavaUnoExtensionWithUnoAdditionalDataTypesProjectEnvironment;
import thebiasplanet.projectskeletonsmaker.constantsgroups.*;

public class ParametersSettingInterpreter {
	private String i_baseDirectoryPath;
	private ProjectEnvironment i_projectEnvironment;
	private LinkedHashMap <String, List <List <String>>> i_unoComponentClassRelativeCoreNameToUnoInterfaceNamesAndUnoServiceRelativeCoreNamesMap;
	private LinkedHashMap <String, LinkedHashMap <String, List <String>>>  i_unoModuleNameToUnoInterfaceRelativeCoreNameToSuperUnoInterfaceNamesMapMap;
	private LinkedHashMap <String, LinkedHashMap <String, String>>  i_unoModuleNameToUnoServiceRelativeCoreNameToReturnTypeUnoInterfaceNameMapMap;
	
	public ParametersSettingInterpreter (String a_baseDirectoryPath) {
		i_baseDirectoryPath = a_baseDirectoryPath;
		i_projectEnvironment = null;
		i_unoComponentClassRelativeCoreNameToUnoInterfaceNamesAndUnoServiceRelativeCoreNamesMap = null;
		i_unoModuleNameToUnoInterfaceRelativeCoreNameToSuperUnoInterfaceNamesMapMap = null;
		i_unoModuleNameToUnoServiceRelativeCoreNameToReturnTypeUnoInterfaceNameMapMap = null;
	}
	
	// return: the project type
	@SuppressWarnings("unchecked")
	public void interpret (XComponentContext a_componentContextInXComponentContext) throws Exception {
		UnoSpreadSheet l_currentUnoSpreadSheet = UnoSpreadSheet.getCurrentSpreadSheet (a_componentContextInXComponentContext);
		boolean l_isInParameterCaptionRow = false;
		String l_parameterGroupName = null;
		String l_projectName = null;
		String l_projectTypeName = null;
		String l_targetName = null;
		ArrayList <String> l_includedJarFilePathExpressions = null;
		ArrayList <String> l_otherClassesPathExpressions = null;
		ArrayList <String> l_referencedProjectDirectoryPathExpressions = null;
		String l_unoComponentsPackageName = null;
		UnoSpreadSheetCell l_nextColumn0Cell = l_currentUnoSpreadSheet.getSpreadSheetCell (GeneralConstantsConstantsGroup.c_iterationStartingNumber, GeneralConstantsConstantsGroup.c_iterationStartingNumber);
		while (true) {
			if (l_nextColumn0Cell.getBackgroundColor () == UnoPixelValuesConstantsGroup.c_parameterCaptionBackgroundPixelValue) {
				if (!l_isInParameterCaptionRow) {
					l_parameterGroupName = (String) l_nextColumn0Cell.getValue ();
					if (l_parameterGroupName.equals (SettingSheetControlCaptionsConstantsGroup.c_endControlCaption)) {
						break;
					}
				}
				l_isInParameterCaptionRow = true;
				l_nextColumn0Cell = l_nextColumn0Cell.getDownCell ();
				continue;
			}
			else {
				if (l_parameterGroupName.equals (SettingSheetControlCaptionsConstantsGroup.c_projectTypeNameControlCaption)) {
					l_projectTypeName = (String) l_nextColumn0Cell.getValue ();
				}
				else if (l_parameterGroupName.equals (SettingSheetControlCaptionsConstantsGroup.c_targetNameControlCaption)) {
					l_targetName = (String) l_nextColumn0Cell.getValue ();
				}
				else if (l_parameterGroupName.equals (SettingSheetControlCaptionsConstantsGroup.c_includedJarFilePathExpressionsControlCaption)) {
					l_includedJarFilePathExpressions = new ArrayList <String> ();
					l_currentUnoSpreadSheet. <String>buildList (l_nextColumn0Cell, l_includedJarFilePathExpressions, true, GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger);
				}
				else if (l_parameterGroupName.equals (SettingSheetControlCaptionsConstantsGroup.c_otherClassesPathExpressionsControlCaption)) {
					l_otherClassesPathExpressions = new ArrayList <String> ();
					l_currentUnoSpreadSheet. <String>buildList (l_nextColumn0Cell, l_otherClassesPathExpressions, true, GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger);
				}
				else if (l_parameterGroupName.equals (SettingSheetControlCaptionsConstantsGroup.c_referencedProjectDirectoryPathExpressionsControlCaption)) {
					l_referencedProjectDirectoryPathExpressions = new ArrayList <String> ();
					l_currentUnoSpreadSheet. <String>buildList (l_nextColumn0Cell, l_referencedProjectDirectoryPathExpressions, true, GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger);
				}
				else if (l_parameterGroupName.equals (SettingSheetControlCaptionsConstantsGroup.c_unoComponentsPackageNameControlCaption)) {
					l_unoComponentsPackageName = (String) l_nextColumn0Cell.getValue ();
				}
				else if (l_parameterGroupName.equals (SettingSheetControlCaptionsConstantsGroup.c_unoComponentsControlCaption)) {
					i_unoComponentClassRelativeCoreNameToUnoInterfaceNamesAndUnoServiceRelativeCoreNamesMap = new LinkedHashMap <String, List <List <String>>> ();
					l_currentUnoSpreadSheet. <String>buildObjectToListsMap (l_nextColumn0Cell, i_unoComponentClassRelativeCoreNameToUnoInterfaceNamesAndUnoServiceRelativeCoreNamesMap, GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger);
				}
				else if (l_parameterGroupName.equals (SettingSheetControlCaptionsConstantsGroup.c_unoInterfacesControlCaption)) {
					i_unoModuleNameToUnoInterfaceRelativeCoreNameToSuperUnoInterfaceNamesMapMap = new LinkedHashMap <String, LinkedHashMap <String, List <String>>> ();
					l_currentUnoSpreadSheet. <String, LinkedHashMap <String, List <String>>>buildCascadeMap (l_nextColumn0Cell, i_unoModuleNameToUnoInterfaceRelativeCoreNameToSuperUnoInterfaceNamesMapMap, GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger, true);
				}
				else if (l_parameterGroupName.equals (SettingSheetControlCaptionsConstantsGroup.c_globalUnoServiceSpecificServiceInstancesFactoriesControlCaption)) {
					i_unoModuleNameToUnoServiceRelativeCoreNameToReturnTypeUnoInterfaceNameMapMap = new LinkedHashMap <String, LinkedHashMap <String, String>> ();
					l_currentUnoSpreadSheet. <String, LinkedHashMap <String, String>>buildCascadeMap (l_nextColumn0Cell, i_unoModuleNameToUnoServiceRelativeCoreNameToReturnTypeUnoInterfaceNameMapMap, GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger, false);
				}
				l_isInParameterCaptionRow = false;
				while (true) {
					l_nextColumn0Cell = l_nextColumn0Cell.getDownCell ();
					if (l_nextColumn0Cell.getBackgroundColor () == UnoPixelValuesConstantsGroup.c_parameterCaptionBackgroundPixelValue) {
						break;
					}
				}
			}
		}
		l_projectName = l_currentUnoSpreadSheet.getSpreadSheetName ();
		if (l_projectTypeName.equals (ProjectTypeNamesConstantsGroup.c_unoExtensionWithUnoAdditionalDataTypesProjectTypeName)) {
			i_projectEnvironment = new JavaUnoExtensionWithUnoAdditionalDataTypesProjectEnvironment (i_baseDirectoryPath, l_projectName, l_targetName, l_unoComponentsPackageName, l_includedJarFilePathExpressions,l_otherClassesPathExpressions, l_referencedProjectDirectoryPathExpressions);
		}
		else if (l_projectTypeName.equals (ProjectTypeNamesConstantsGroup.c_unoExtensionProjectTypeName)) {
			i_projectEnvironment = new JavaUnoExtensionProjectEnvironment (i_baseDirectoryPath, l_projectName, l_targetName, l_unoComponentsPackageName, l_includedJarFilePathExpressions,l_otherClassesPathExpressions, l_referencedProjectDirectoryPathExpressions);
		}
		else if (l_projectTypeName.equals (ProjectTypeNamesConstantsGroup.c_unoAdditionalDataTypesProjectTypeName)) {
			i_projectEnvironment = new UnoAdditionalDataTypesProjectEnvironment (i_baseDirectoryPath, l_projectName, l_targetName, l_referencedProjectDirectoryPathExpressions);
		}
	}
	
	public ProjectEnvironment getProjectEnvironment () {
		return i_projectEnvironment;
	}
	
	public LinkedHashMap <String, List <List <String>>> getUnoComponentClassRelativeCoreNameToUnoInterfaceNamesAndUnoServiceRelativeCoreNamesMap () {
		return i_unoComponentClassRelativeCoreNameToUnoInterfaceNamesAndUnoServiceRelativeCoreNamesMap;
	}
	
	public LinkedHashMap <String, LinkedHashMap <String, List <String>>> getUnoModuleNameToUnoInterfaceRelativeCoreNameToSuperUnoInterfaceNamesMapMap () {
		return i_unoModuleNameToUnoInterfaceRelativeCoreNameToSuperUnoInterfaceNamesMapMap;
	}
	
	public LinkedHashMap <String, LinkedHashMap <String, String>>  getUnoModuleNameToUnoServiceRelativeCoreNameToReturnTypeUnoInterfaceNameMapMap () {
		return i_unoModuleNameToUnoServiceRelativeCoreNameToReturnTypeUnoInterfaceNameMapMap;
	}
}
