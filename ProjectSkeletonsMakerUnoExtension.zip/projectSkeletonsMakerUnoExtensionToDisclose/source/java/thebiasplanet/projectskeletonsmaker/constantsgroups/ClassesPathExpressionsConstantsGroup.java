package thebiasplanet.projectskeletonsmaker.constantsgroups;

import java.util.ArrayList;
import thebiasplanet.coreutilities.collectionshandling.ListFactory;

public interface ClassesPathExpressionsConstantsGroup {
	ArrayList <String> c_unoStandardClassesPathExpressions = ListFactory. <String>createArrayList ("LIBREOFFICE_CLASSES_BASE_DIRECTORY_NAME + \"/unoil.jar\"", "LIBREOFFICE_CLASSES_BASE_DIRECTORY_NAME + \"/jurt.jar\"", "LIBREOFFICE_CLASSES_BASE_DIRECTORY_NAME + \"/ridl.jar\"", "LIBREOFFICE_CLASSES_BASE_DIRECTORY_NAME + \"/juh.jar\"");
}
