package thebiasplanet.projectskeletonsmaker.constantsgroups;

public interface TaskNamesConstantsGroup {
	String c_registerUnoExtensionTaskName = "registerUnoExtension";
	String c_makeJarTaskName = "makeJar";
}
