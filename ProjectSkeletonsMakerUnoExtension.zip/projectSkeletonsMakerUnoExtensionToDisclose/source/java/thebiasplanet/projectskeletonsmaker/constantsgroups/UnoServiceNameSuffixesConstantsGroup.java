package thebiasplanet.projectskeletonsmaker.constantsgroups;

public interface UnoServiceNameSuffixesConstantsGroup {
	String c_unoServiceNameSuffix = "UnoService";
}
