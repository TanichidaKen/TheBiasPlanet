package thebiasplanet.projectskeletonsmaker.constantsgroups;

public interface DirectoryRelativePathsConstantsGroup {
	String c_sourceDirectoryRelativePath = "source";
	String c_resourceDirectoryRelativePath = String.format ("%s/%s", c_sourceDirectoryRelativePath, "resource");
	String c_javaDirectoryRelativePath = String.format ("%s/%s", c_sourceDirectoryRelativePath, "java");
	String c_unoIdlDirectoryRelativePath = String.format ("%s/%s", c_sourceDirectoryRelativePath, "unoIdl");
	String c_intermediateDirectoryRelativePath = "intermediate";
}
