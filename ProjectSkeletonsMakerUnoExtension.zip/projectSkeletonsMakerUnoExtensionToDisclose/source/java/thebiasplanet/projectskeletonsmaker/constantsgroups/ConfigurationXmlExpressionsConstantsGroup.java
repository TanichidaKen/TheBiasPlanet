package thebiasplanet.projectskeletonsmaker.constantsgroups;

import thebiasplanet.coreutilities.constantsgroups.*;

public interface ConfigurationXmlExpressionsConstantsGroup {
	String c_rootConfigurationFormat = String.format ("%s%s", XmlExpressionsConstantsGroup.c_xml1_0Declaration, "<root>%s</root>");
	String c_targetNameConfigurationFormat = "<targetName>%s</targetName>";
	String c_defaultTaskNameConfigurationFormat = "<defaultTaskName>%s</defaultTaskName>";
	String c_includedJarFilePathExpressionsConfigurationFormat = "<includedJarFilePathExpressions>%s</includedJarFilePathExpressions>";
	String c_includedJarFilePathExpressionConfigurationFormat = "<includedJarFilePathExpression>%s</includedJarFilePathExpression>";
	String c_otherClassesPathExpressionsConfigurationFormat = "<otherClassesPathExpressions>%s</otherClassesPathExpressions>";
	String c_otherClassesPathExpressionConfigurationFormat = "<otherClassesPathExpression>%s</otherClassesPathExpression>";
	String c_referencedProjectDirectoryPathExpressionsConfigurationFormat = "<referencedProjectDirectoryPathExpressions>%s</referencedProjectDirectoryPathExpressions>";
	String c_referencedProjectDirectoryPathExpressionConfigurationFormat = "<referencedProjectDirectoryPathExpression>%s</referencedProjectDirectoryPathExpression>";
	String c_javaPackageNameConfigurationFormat = "<javaPackageName>%s</javaPackageName>";
	String c_globalUnoServicesProviderClassRelativeNameConfigurationFormat = "<globalUnoServicesProviderClassRelativeName>%s</globalUnoServicesProviderClassRelativeName>";
	String c_unoComponentsSettingFileNameConfigurationFormat = "<unoComponentsSettingFileName>%s</unoComponentsSettingFileName>";
	String c_unoDataTypesMergedRegistryFileNameConfigurationFormat = "<unoDataTypesMergedRegistryFileName>%s</unoDataTypesMergedRegistryFileName>";
	String c_jarFileNameConfigurationFormat = "<jarFileName>%s</jarFileName>";
	String c_unoComponentsConfigurationFormat = "<unoComponents>%s</unoComponents>";
	// unoComponentClassRelativeName, unoServiceRelativeNames, unoInterfaceNames, unoInterfaceRelativeNames
	String c_unoComponentConfigurationFormat = "<unoComponent>%s%s%s%s</unoComponent>";
	String c_unoComponentClassRelativeNameConfigurationFormat = "<unoComponentClassRelativeName>%s</unoComponentClassRelativeName>";
	String c_unoServiceRelativeNamesConfigurationFormat = "<unoServiceRelativeNames>%s</unoServiceRelativeNames>";
	String c_unoServiceRelativeNameConfigurationFormat = "<unoServiceRelativeName>%s</unoServiceRelativeName>";
	String c_unoInterfaceNamesConfigurationFormat = "<unoInterfaceNames>%s</unoInterfaceNames>";
	String c_unoInterfaceNameConfigurationFormat = "<unoInterfaceName>%s</unoInterfaceName>";
	String c_unoInterfaceRelativeNamesConfigurationFormat = "<unoInterfaceRelativeNames>%s</unoInterfaceRelativeNames>";
	String c_unoInterfaceRelativeNameConfigurationFormat = "<unoInterfaceRelativeName>%s</unoInterfaceRelativeName>";
	// unoInterfaceRelativeName, unoModuleBeginningRelativeExpression, unoModuleEndRelativeExpression, superUnoInterfaceDelimitedByColonsNames, superUnoInterfaceSourceFileQuotedRelativePaths, unoInterfaceDefinitionName
	String c_unoInterfaceConfigurationFormat = "<unoInterface>%s%s%s%s%s%s</unoInterface>";
	String c_superUnoInterfaceDelimitedByColonsNamesConfigurationFormat = "<superUnoInterfaceDelimitedByColonsNames>%s</superUnoInterfaceDelimitedByColonsNames>";
	String c_superUnoInterfaceDelimitedByColonsNameConfigurationFormat = "<superUnoInterfaceDelimitedByColonsName>%s</superUnoInterfaceDelimitedByColonsName>";
	String c_superUnoInterfaceSourceFileQuotedRelativePathsConfigurationFormat = "<superUnoInterfaceSourceFileQuotedRelativePaths>%s</superUnoInterfaceSourceFileQuotedRelativePaths>";
	String c_superUnoInterfaceSourceFileQuotedRelativePathConfigurationFormat = "<superUnoInterfaceSourceFileQuotedRelativePath>%s</superUnoInterfaceSourceFileQuotedRelativePath>";
	String c_unoModuleBeginningExpressionConfigulationFormat = "<unoModuleBeginningExpression>%s</unoModuleBeginningExpression>";
	String c_unoModuleEndExpressionConfigulationFormat = "<unoModuleEndExpression>%s</unoModuleEndExpression>";
	String c_unoInterfaceDefinitionNameConfigurationFormat = "<unoInterfaceDefinitionName>%s</unoInterfaceDefinitionName>";
	// unoServiceRelativeName, unoModuleBeginningRelativeExpression, unoModuleEndRelativeExpression, returnTypeUnoInterfaceDelimitedByColonsName, returnTypeUnoInterfaceSourceFileQuotedRelativePath, unoServiceSpecificServiceInstancesFactoryDefinitionName
	String c_unoServiceConfigurationFormat = "<unoService>%s%s%s%s%s%s</unoService>";
	String c_returnTypeUnoInterfaceDelimitedByColonsNameConfigurationFormat = "<returnTypeUnoInterfaceDelimitedByColonsName>%s</returnTypeUnoInterfaceDelimitedByColonsName>";
	String c_returnTypeUnoInterfaceSourceFileQuotedRelativePathConfigurationFormat = 
	"<returnTypeUnoInterfaceSourceFileQuotedRelativePath>%s</returnTypeUnoInterfaceSourceFileQuotedRelativePath>";
	String c_unoServiceSpecificServiceInstancesFactoryDefinitionNameConfigurationFormat = "<unoServiceSpecificServiceInstancesFactoryDefinitionName>%s</unoServiceSpecificServiceInstancesFactoryDefinitionName>";
}
