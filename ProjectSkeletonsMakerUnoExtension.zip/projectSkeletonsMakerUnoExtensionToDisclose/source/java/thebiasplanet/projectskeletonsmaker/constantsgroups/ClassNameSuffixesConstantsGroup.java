package thebiasplanet.projectskeletonsmaker.constantsgroups;

public interface ClassNameSuffixesConstantsGroup {
	String c_unoGlobalServicesProviderClassNameSuffix = "GlobalUnoServicesProvider";
	String c_unoComponentClassNameSuffix = "UnoComponent";
}
