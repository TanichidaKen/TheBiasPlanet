package thebiasplanet.projectskeletonsmaker.constantsgroups;

public interface InterfaceNamePrefixesConstantsGroup {
	String c_unoInterfaceNamePrefix = "X";
}
