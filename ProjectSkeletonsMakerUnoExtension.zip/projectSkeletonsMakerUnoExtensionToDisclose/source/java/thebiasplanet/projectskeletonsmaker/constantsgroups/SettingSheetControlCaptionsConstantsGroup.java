package thebiasplanet.projectskeletonsmaker.constantsgroups;

public interface SettingSheetControlCaptionsConstantsGroup {
	String c_projectTypeNameControlCaption = "Project Type Name";
	String c_targetNameControlCaption = "Target Name";
	String c_includedJarFilePathExpressionsControlCaption = "Included Jar File Path Expressions";
	String c_otherClassesPathExpressionsControlCaption = "Other Classes Path Expressions";
	String c_referencedProjectDirectoryPathExpressionsControlCaption = "Referenced Project Directory Path Expressions";
	String c_unoComponentsPackageNameControlCaption = "UNO Components Package Name";
	String c_unoComponentsControlCaption = "UNO Components";
	String c_unoInterfacesControlCaption = "UNO Interfaces";
	String c_globalUnoServiceSpecificServiceInstancesFactoriesControlCaption = "'Global UNO Service'-Specific Service Instances Factories";
	String c_endControlCaption = "End";
}
