package thebiasplanet.projectskeletonsmaker.constantsgroups;

public interface ProjectTypeNamesConstantsGroup {
	String c_unoExtensionWithUnoAdditionalDataTypesProjectTypeName = "UNO extension with UNO additional data types";
	String c_unoExtensionProjectTypeName = "UNO extension";
	String c_unoAdditionalDataTypesProjectTypeName = "UNO additional data types";
}
