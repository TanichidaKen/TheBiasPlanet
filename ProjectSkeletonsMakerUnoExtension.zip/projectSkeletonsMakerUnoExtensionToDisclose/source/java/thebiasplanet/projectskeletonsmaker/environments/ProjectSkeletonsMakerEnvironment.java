package thebiasplanet.projectskeletonsmaker.environments;


public class ProjectSkeletonsMakerEnvironment {
	private static String s_styleSheetsDirectoryPath;
	
	public static void setStyleSheetsDirectoryPath (String a_styleSheetsDirectoryPath) {
		s_styleSheetsDirectoryPath = a_styleSheetsDirectoryPath;
	}
	
	public static String getStyleSheetsDirectoryPath () {
		return s_styleSheetsDirectoryPath;
	}
}
