package thebiasplanet.projectskeletonsmaker.environments;

import java.util.List;
import thebiasplanet.coreutilities.constantsgroups.*;

public class ProjectEnvironment implements ProjectEnvironmentInterface {
	private String i_baseDirectoryPath;
	private String i_projectName;
	private String i_targetName;
	private String i_defaultTaskName;
	private List <String> i_referencedProjectDirectoryPathExpressions;
	
	public ProjectEnvironment (String a_baseDirectoryPath, String a_projectName, String a_targetName, String a_defaultTaskName, List <String> a_referencedProjectDirectoryPathExpressions) {
		i_baseDirectoryPath = a_baseDirectoryPath;
		i_projectName = a_projectName;
		i_targetName = a_targetName;
		i_defaultTaskName = a_defaultTaskName;
		i_referencedProjectDirectoryPathExpressions = a_referencedProjectDirectoryPathExpressions;
	}
	
	@Override
	public String getBaseDirectoryPath () {
		return i_baseDirectoryPath;
	}
	
	@Override
	public String getProjectName () {
		return i_projectName;
	}
	
	@Override
	public String getProjectDirectoryPath () {
		return String.format (LiteralExpressionsConstantsGroup.c_directoryPathFormat, i_baseDirectoryPath, i_projectName);
	}
	
	@Override
	public String getTargetName () {
		return i_targetName;
	}
	
	@Override
	public String getDefaultTaskName () {
		return i_defaultTaskName;
	}
	
	@Override
	public List <String> getReferencedProjectDirectoryPathExpressions () {
		return i_referencedProjectDirectoryPathExpressions;
	}
}
