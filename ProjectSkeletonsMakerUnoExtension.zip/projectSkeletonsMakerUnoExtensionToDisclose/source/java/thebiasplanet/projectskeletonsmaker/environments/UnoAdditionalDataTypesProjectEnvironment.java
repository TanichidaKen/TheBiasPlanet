package thebiasplanet.projectskeletonsmaker.environments;

import java.util.List;
import thebiasplanet.projectskeletonsmaker.constantsgroups.*;

public class UnoAdditionalDataTypesProjectEnvironment extends ProjectEnvironment implements UnoAdditionalDataTypesProjectEnvironmentInterface {
	public UnoAdditionalDataTypesProjectEnvironment (String a_baseDirectoryPath, String a_projectName, String a_targetName, List <String> a_referencedProjectDirectoryPathExpression) {
		super (a_baseDirectoryPath, a_projectName, a_targetName, TaskNamesConstantsGroup.c_makeJarTaskName, a_referencedProjectDirectoryPathExpression);
	}
}
