package thebiasplanet.projectskeletonsmaker.environments;

import java.util.List;

public interface ProjectEnvironmentInterface {
	public String getBaseDirectoryPath ();
	
	public String getProjectName ();
	
	public String getProjectDirectoryPath ();
	
	public String getTargetName ();
	
	public String getDefaultTaskName ();
	
	public List <String> getReferencedProjectDirectoryPathExpressions ();
}
