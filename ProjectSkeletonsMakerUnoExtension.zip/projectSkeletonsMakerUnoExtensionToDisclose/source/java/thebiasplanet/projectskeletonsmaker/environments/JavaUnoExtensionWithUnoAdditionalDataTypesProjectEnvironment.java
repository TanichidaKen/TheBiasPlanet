package thebiasplanet.projectskeletonsmaker.environments;

import java.util.List;

public class JavaUnoExtensionWithUnoAdditionalDataTypesProjectEnvironment extends JavaUnoExtensionProjectEnvironment implements UnoAdditionalDataTypesProjectEnvironmentInterface {
	public JavaUnoExtensionWithUnoAdditionalDataTypesProjectEnvironment (String a_baseDirectoryPath, String a_projectName, String a_targetName, String a_unoComponentsPackageName, List <String> a_includedJarFilePathExpressions, List <String> a_otherClassesPathExpressions, List <String> a_referencedProjectDirectoryPathExpressions) {
		super (a_baseDirectoryPath, a_projectName, a_targetName, a_unoComponentsPackageName, a_includedJarFilePathExpressions, a_otherClassesPathExpressions, a_referencedProjectDirectoryPathExpressions);
	}
}
