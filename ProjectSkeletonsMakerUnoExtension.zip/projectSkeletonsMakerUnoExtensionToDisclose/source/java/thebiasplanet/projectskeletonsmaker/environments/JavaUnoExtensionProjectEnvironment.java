package thebiasplanet.projectskeletonsmaker.environments;

import java.util.List;
import thebiasplanet.coreutilities.collectionshandling.ListFactory;
import thebiasplanet.projectskeletonsmaker.constantsgroups.*;

public class JavaUnoExtensionProjectEnvironment extends JavaProjectEnvironment {
	private String i_unoComponentsPackageName;
	
	public JavaUnoExtensionProjectEnvironment (String a_baseDirectoryPath, String a_projectName, String a_targetName, String a_unoComponentsPackageName, List <String> a_includedJarFilePathExpressions, List <String> a_otherClassesPathExpressions, List <String> a_referencedProjectDirectoryPathExpressions) {
		super (a_baseDirectoryPath, a_projectName, a_targetName, TaskNamesConstantsGroup.c_registerUnoExtensionTaskName, a_includedJarFilePathExpressions, ListFactory. <String>createArrayListExpandingItems (a_otherClassesPathExpressions, ClassesPathExpressionsConstantsGroup.c_unoStandardClassesPathExpressions), a_referencedProjectDirectoryPathExpressions);
		i_unoComponentsPackageName = a_unoComponentsPackageName;
	}
	
	public String getUnoComponentsPackageName () {
		return i_unoComponentsPackageName;
	}
}
