package thebiasplanet.projectskeletonsmaker.environments;

import java.util.List;

public class JavaProjectEnvironment extends ProjectEnvironment {
	private List <String> i_includedJarFilePathExpressions;
	private List <String> i_otherClassesPathExpressions;
	
	public JavaProjectEnvironment (String a_baseDirectoryPath, String a_projectName, String a_targetName, String a_defaultTaskName, List <String> a_includedJarFilePathExpressions, List <String> a_otherClassesPathExpressions, List <String> a_referencedProjectDirectoryPathExpressions) {
		super (a_baseDirectoryPath, a_projectName, a_targetName, a_defaultTaskName, a_referencedProjectDirectoryPathExpressions);
		i_includedJarFilePathExpressions = a_includedJarFilePathExpressions;
		i_otherClassesPathExpressions = a_otherClassesPathExpressions;
	}
	
	public List <String> getIncludedJarFilePathExpressions () {
		return i_includedJarFilePathExpressions;
	}
	
	public List <String> getOtherClassesPathExpressions () {
		return i_otherClassesPathExpressions;
	}
}
