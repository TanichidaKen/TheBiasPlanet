package thebiasplanet.coreutilities.constantsgroups;

public interface LiteralExpressionsConstantsGroup {
	String c_colonDelimiter = ": ";
	String c_commaDelimiter = ", ";
	String c_directoryDelimiter = "/";
	String c_javaPackageDelimiter = ".";
	String c_fileNameElementDelimiter = ".";
	String c_nameElementDelimiter = "_";
	String c_integerDefaultFormat = "%d";
	String c_doubleDefaultFormat = "%f";
	String c_booleanDefaultFormat = "%b";
	String c_directoryPathFormat = String.format ("%%s%s%%s", c_directoryDelimiter);
	String c_filePathFormat = String.format ("%%s%s%%s", c_directoryDelimiter);
	String c_fileNameFormat = String.format ("%%s%s%%s", c_fileNameElementDelimiter);
	String c_javaClassNameFormat = String.format ("%%s%s%%s", c_javaPackageDelimiter);
	String c_styleSheetFileNameFormat = String.format ("%%s%s%s", c_fileNameElementDelimiter, FileNameSuffixesConstantsGroup.c_styleSheetFileNameSuffix);
	String c_javaFileNameFormat = String.format ("%%s%s%s", c_fileNameElementDelimiter, FileNameSuffixesConstantsGroup.c_javaFileNameSuffix);
	String c_quotedByDoubleQuotationsFormat = "\"%s\"";
	String c_quotedByAngleBracketsFormat = "<%s>";
	String c_definitionNameFormat = String.format ("%1$s%1$s%%s%1$s%1$s", c_nameElementDelimiter);
	String c_plus = "+";
	String c_propertyValueFormat = "${%s}";
}
