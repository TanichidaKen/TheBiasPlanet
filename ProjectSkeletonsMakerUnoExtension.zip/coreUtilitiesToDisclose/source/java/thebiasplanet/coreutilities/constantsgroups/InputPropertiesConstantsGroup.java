package thebiasplanet.coreutilities.constantsgroups;

public interface InputPropertiesConstantsGroup {
	int c_noMoreData = -1;
	int c_noDataRetrieved = 0;
	int c_lengthNotSet = -1;
	int c_lengthNotRead = 0;
}
