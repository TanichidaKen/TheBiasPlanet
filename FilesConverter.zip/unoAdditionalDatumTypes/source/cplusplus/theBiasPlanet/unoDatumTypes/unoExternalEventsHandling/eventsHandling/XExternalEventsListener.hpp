#ifndef INCLUDED_THEBIASPLANET_UNODATUMTYPES_UNOEXTERNALEVENTSHANDLING_EVENTSHANDLING_XEXTERNALEVENTSLISTENER_HPP
#define INCLUDED_THEBIASPLANET_UNODATUMTYPES_UNOEXTERNALEVENTSHANDLING_EVENTSHANDLING_XEXTERNALEVENTSLISTENER_HPP

#include "sal/config.h"

#include "theBiasPlanet/unoDatumTypes/unoExternalEventsHandling/eventsHandling/XExternalEventsListener.hdl"

#include "com/sun/star/uno/XInterface.hpp"
#include "theBiasPlanet/unoDatumTypes/unoExternalEventsHandling/events/XExternalEvent.hpp"
#include "com/sun/star/uno/Reference.hxx"
#include "com/sun/star/uno/Type.hxx"
#include "cppu/unotype.hxx"

namespace theBiasPlanet { namespace unoDatumTypes { namespace unoExternalEventsHandling { namespace eventsHandling {

inline ::css::uno::Type const & cppu_detail_getUnoType(SAL_UNUSED_PARAMETER ::theBiasPlanet::unoDatumTypes::unoExternalEventsHandling::eventsHandling::XExternalEventsListener const *) {
    static typelib_TypeDescriptionReference * the_type = 0;
    if ( !the_type )
    {
        typelib_static_mi_interface_type_init( &the_type, "theBiasPlanet.unoDatumTypes.unoExternalEventsHandling.eventsHandling.XExternalEventsListener", 0, 0 );
    }
    return * reinterpret_cast< ::css::uno::Type * >( &the_type );
}

} } } }

SAL_DEPRECATED("use cppu::UnoType") inline ::css::uno::Type const & SAL_CALL getCppuType(SAL_UNUSED_PARAMETER ::css::uno::Reference< ::theBiasPlanet::unoDatumTypes::unoExternalEventsHandling::eventsHandling::XExternalEventsListener > const *) {
    return ::cppu::UnoType< ::css::uno::Reference< ::theBiasPlanet::unoDatumTypes::unoExternalEventsHandling::eventsHandling::XExternalEventsListener > >::get();
}

::css::uno::Type const & ::theBiasPlanet::unoDatumTypes::unoExternalEventsHandling::eventsHandling::XExternalEventsListener::static_type(SAL_UNUSED_PARAMETER void *) {
    return ::cppu::UnoType< ::theBiasPlanet::unoDatumTypes::unoExternalEventsHandling::eventsHandling::XExternalEventsListener >::get();
}

#endif // INCLUDED_THEBIASPLANET_UNODATUMTYPES_UNOEXTERNALEVENTSHANDLING_EVENTSHANDLING_XEXTERNALEVENTSLISTENER_HPP
