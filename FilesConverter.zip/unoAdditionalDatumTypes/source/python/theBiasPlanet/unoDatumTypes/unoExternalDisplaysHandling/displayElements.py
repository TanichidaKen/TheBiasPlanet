from abc import ABCMeta
from theBiasPlanet.unoDatumTypes.unoExternalEventsHandling.eventsHandling import XExternalEventsBroadcaster

class XExternalFrame (XExternalEventsBroadcaster, metaclass=ABCMeta):
	def setLocation (a_this: "XExternalFrame", a_xCoordinate: int, a_yCoordinate: int) -> None:
		None
	
	def show (a_this: "XExternalFrame") -> None:
		None
	
	def sendToFront (a_this: "XExternalFrame") -> None:
		None
	
	def hide (a_this: "XExternalFrame") -> None:
		None
	
	def close (a_this: "XExternalFrame") -> None:
		None

