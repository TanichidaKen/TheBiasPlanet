from typing import Iterator
from typing import List
from typing import Match
from typing import Optional
from typing import Pattern
import os
import re
from theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup import GeneralConstantsConstantsGroup

class StringHandler:
	c_environmentVariableRegularExpression: Pattern = re.compile ("\\$\\{(.*?)\\}")
	
	@staticmethod
	def unNullify (a_originalString: Optional [str]) -> str:
		if a_originalString is not None:
			return a_originalString
		else:
			return ""
	
	@staticmethod
	def effectuateEnvironmentVariables (a_originalString: str) -> str:
		l_targetStringBuilder: List [str] = []
		l_environmentVariableMatchersIterator: Iterator = StringHandler.c_environmentVariableRegularExpression.finditer (a_originalString)
		l_environmentVariableMatcher: Match [str]
		l_currentCharacterIndex: int = GeneralConstantsConstantsGroup.c_iterationStartingNumber
		for l_environmentVariableMatcher in l_environmentVariableMatchersIterator:
			l_targetStringBuilder.append (a_originalString [l_currentCharacterIndex: l_environmentVariableMatcher.start (GeneralConstantsConstantsGroup.c_iterationStartingNumber)])
			l_targetStringBuilder.append (StringHandler.unNullify (os.getenv (l_environmentVariableMatcher.group (GeneralConstantsConstantsGroup.c_iterationStartingNumber + 1))))
			l_currentCharacterIndex = l_environmentVariableMatcher.end (GeneralConstantsConstantsGroup.c_iterationStartingNumber)
		l_targetStringBuilder.append (a_originalString [l_currentCharacterIndex:])
		return "".join (l_targetStringBuilder)

