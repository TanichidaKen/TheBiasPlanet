
class EncodingNamesConstantsGroup:
	c_utf8EncodingName: str = "UTF-8"

