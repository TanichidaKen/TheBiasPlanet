from collections import OrderedDict
from theBiasPlanet.coreUtilities.constantsGroups.FileNameSuffixesConstantsGroup import FileNameSuffixesConstantsGroup

class GeneralConstantsConstantsGroup:
	c_maximumBytesLengthPerUtf8Character: int = 4
	c_numberOfAlphabets: int = 26
	c_anyUnspecifiedInteger: int = -1
	c_anyUnspecifiedFloat: float = -1.0
	c_anyUnspecifiedCharacter: int = 0 # char
	c_iterationStartingNumber: int = 0
	c_normalResult: int = 0
	c_emptyString: str = ""
	c_radixPointCharacter: str = '.' # char
	c_thousandsDelimiter: str = ',' # char
	c_escapingCharacter: str = '\\' # char
	c_newLineCharacter: str = '\n' # char
	c_carriageReturnCharacter: str = '\r' # char
	c_tabCharacter: str = '\t' #char
	c_semicolonCharacter: str = ';' # char
	c_utfBomCharacter: str = '\uFEFF' # char
	c_lessThanCharacter: str = '<' # char
	c_greaterThanCharacter: str = '>' # char
	c_ampersandCharacter: str = '&' # char
	c_doubleQuotationMarkCharacter: str = '\"' # char
	c_apostropheCharacter: str = '\'' # char
	c_argumentsDelimiter: str = ' ' # char
	c_colonDelimiter: str = ": "
	c_commaDelimiter: str = ", "
	c_linuxDirectoriesDelimiter: str = '/' # char
	c_windowsDirectoriesDelimiter: str = '\\' # char
	c_javaPackagesDelimiter: str = '.' # char
	c_fileNameElementsDelimiter: str = '.' # char
	c_nameElementsDelimiter: str = '_' # char
	c_linuxPathsDelimiter: str = ':' # char
	c_windowsPathsDelimiter: str = ';' # char
	c_integerDefaultFormat: str = "{:d}"
	c_doubleDefaultFormat: str = "{:f}"
	c_booleanDefaultFormat: str = "{}"
	c_globExpressionFormat: str = "glob:{:s}"
	c_commandSwitchOrFlagStarter: str = "-"
	c_linuxDirectoryPathFormat: str = "{{0}}{0:s}{{1}}".format (c_linuxDirectoriesDelimiter)
	c_windowsDirectoryPathFormat: str = "{{0}}{0:s}{{1}}".format (c_windowsDirectoriesDelimiter)
	c_linuxFilePathFormat: str = "{{0}}{0}{{1}}".format (c_linuxDirectoriesDelimiter)
	c_windowsFilePathFormat: str = "{{0}}{0}{{1}}".format (c_windowsDirectoriesDelimiter)
	c_fileNameFormat: str = "{{:s}}{:s}{{:s}}".format (c_fileNameElementsDelimiter)
	c_javaClassNameFormat: str = "{{0}}{0:s}{{1}}".format (c_javaPackagesDelimiter)
	c_styleSheetFileNameFormat: str = "{{0}}{0:s}{1:s}".format (c_fileNameElementsDelimiter, FileNameSuffixesConstantsGroup.c_styleSheetFileNameSuffix)
	c_javaFileNameFormat: str = "{{0}}{0:s}{1:s}".format (c_fileNameElementsDelimiter, FileNameSuffixesConstantsGroup.c_javaFileNameSuffix)
	c_quotedByDoubleQuotationsFormat: str = "\"{0}\""
	c_quotedByAngleBracketsFormat: str = "<{0}>"
	c_definitionNameFormat: str = "{0:s}{0:s}{{0}}{0:s}{0:s}".format (c_nameElementsDelimiter)
	c_plus: str = "+"
	c_propertyValueFormat: str = "${{{0}}}"
	c_alphabetToAlphabetIndexMap: "OrderedDict [str, int]" = OrderedDict ([('A', 0), ('B', 1), ('C', 2), ('D', 3), ('E', 4), ('F', 5), ('G', 6), ('H', 7), ('I', 8), ('J', 9), ('K', 10), ('L', 11), ('M', 12), ('N', 13), ('O', 14), ('P', 15), ('Q', 16), ('R', 17), ('S', 18), ('T', 19), ('U', 20), ('V', 21), ('W', 22), ('X', 23), ('Y', 24), ('Z', 25)])
	c_alphabetIndexToAlphabetMap: "OrderedDict [int, str]" = OrderedDict ([(0, 'A'), (1, 'B'), (2, 'C'), (3, 'D'), (4, 'E'), (5, 'F'), (6, 'G'), (7, 'H'), (8, 'I'), (9, 'J'), (10, 'K'), (11, 'L'), (12, 'M'), (13, 'N'), (14, 'O'), (15, 'P'), (16, 'Q'), (17, 'R'), (18, 'S'), (19, 'T'), (20, 'U'), (21, 'V'), (22, 'W'), (23, 'X'), (24, 'Y'), (25, 'Z')])

