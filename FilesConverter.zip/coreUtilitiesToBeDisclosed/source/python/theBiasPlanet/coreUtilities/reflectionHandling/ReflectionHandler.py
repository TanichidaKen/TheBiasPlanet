from collections import OrderedDict
import inspect
import types
from typing import List
from typing import Optional
from typing import Tuple
from typing import Type
from typing import TypeVar

class ReflectionHandler:
	@staticmethod
	def getFieldNamesAndValues (a_class: type, a_instance: Optional [object], a_assignableClassesOfFields: Optional [List [type]], a_notAssignableClassesOfFields: Optional [List [type]], a_recursive: bool) -> "OrderedDict [str, object]":
		l_fieldNameToValueMap: "OrderedDict [str, object]" = OrderedDict ()
		
		def isAssignable (a_field: object, a_assignableClassesOfFields: Optional [List [type]]) -> bool:
			if not (a_assignableClassesOfFields is None):
				for l_assignableClassesOfField in a_assignableClassesOfFields:
					if isinstance (a_field, l_assignableClassesOfField):
						return True
				return False
			else:
				return True
		
		def isNotAssignable (a_field: object, a_notAssignableClassesOfFields: Optional [List [type]]) -> bool:
			if not (a_notAssignableClassesOfFields is None):
				for l_notAssignableClassesOfFields in a_notAssignableClassesOfFields:
					if not isinstance (a_field, l_notAssignableClassesOfFields):
						return True
				return False
			else:
				return True
		
		l_fieldNameToValueMap.update (filter (lambda a_element: not a_element [0].startswith ("_") and not isinstance (a_element [1], classmethod) and not isinstance (a_element [1], staticmethod) and not isinstance (a_element [1], types.FunctionType) and isAssignable (a_element [1], a_assignableClassesOfFields) and isNotAssignable (a_element [1], a_notAssignableClassesOfFields), a_class.__dict__.items ()))
		if (not a_instance is None):
			l_fieldNameToValueMap.update (filter (lambda a_element: not a_element [0].startswith ("_") and not isinstance (a_element [1], classmethod) and not isinstance (a_element [1], staticmethod) and not isinstance (a_element [1], types.FunctionType) and isAssignable (a_element [1], a_assignableClassesOfFields) and isNotAssignable (a_element [1], a_notAssignableClassesOfFields), a_instance.__dict__.items ()))
		if (a_recursive):
			l_superClassFieldNameToValueMap: Optional ["OrderedDict [str, object]"] = None
			l_superClasses: Tuple [type, ...] = inspect.getmro (a_class)
			for l_superClass in l_superClasses:
				if (l_superClass == a_class):
					continue
				l_superClassFieldNameToValueMap = ReflectionHandler.getFieldNamesAndValues (l_superClass, None, a_assignableClassesOfFields, a_notAssignableClassesOfFields, False);
				l_superClassFieldNameToValueMap.update (l_fieldNameToValueMap) 
				l_fieldNameToValueMap = l_superClassFieldNameToValueMap
		return l_fieldNameToValueMap

