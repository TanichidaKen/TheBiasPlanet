from typing import cast
from typing import List
from typing import Type
from typing import TypeVar
from typing import Union
from collections import Sequence

T = TypeVar ("T")

class ListsFactory:
	@staticmethod
	def createList (a_type0: Type [T], *a_items: T) -> List [T]:
		l_list: List [T] = []
		if not (a_items is None):
			l_item: object
			for l_item in a_items:
				l_list.append (cast (T, l_item))
		return l_list;
	
	@staticmethod
	def createListExpandingItems (a_type0: Type [T], *a_items: Union [T, "Sequence [T]"]) -> List [T]:
		l_list:List [T] = []
		if not (a_items is None):
			l_item: Union [T, "Sequence [T]"]
			for l_item in a_items:
				if isinstance (l_item, Sequence):
					l_element: T
					for l_element in l_item:
						l_list.append (cast (T, l_element))
				else:
					l_list.append (cast (T, l_item))
		return l_list;
	
	@staticmethod
	def createSignedBytesList (a_bytes: bytes) -> List [int]:
		l_list:List [int] = []
		for l_item in a_bytes:
			l_list.append (l_item if l_item < 128 else l_item - 256)
		return l_list

