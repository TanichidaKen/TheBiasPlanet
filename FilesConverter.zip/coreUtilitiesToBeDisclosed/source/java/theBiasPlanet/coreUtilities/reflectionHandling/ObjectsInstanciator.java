package theBiasPlanet.coreUtilities.reflectionHandling;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.helpers.DefaultHandler;
import theBiasPlanet.coreUtilities.collections.NavigableLinkedHashMap;
import theBiasPlanet.coreUtilities.constantsGroups.*;

public class ObjectsInstanciator {
	private SAXParser i_xmlParser = null;
	private ObjectsInstanciationConfigurationXmlParseHandler i_objectsInstanciationConfigurationXmlParseHandler = null;
	
	private class ObjectsInstanciationConfigurationXmlParseHandler extends DefaultHandler {
		private NavigableLinkedHashMap <String, Object> i_objectNameToObjectMap = null;
		private String i_objectName = null;
		private String i_className = null;
		private ArrayList <Class <?>> i_argumentTypes = null;
		private ArrayList <Object> i_argumentValues = null;
		private String i_argumentTypeName = null;
		private boolean i_isInObjectNameElement = false;
		private boolean i_isInClassNameElement = false;
		private boolean i_isInArgumentClassNameElement = false;
		private boolean i_isInArgumentValueElement = false;
		private StringBuilder i_elementValueBuilder = null;
		
		public NavigableLinkedHashMap <String, Object> getObjectNameToObjectMap () {
			return i_objectNameToObjectMap;
		}
		
		@Override
		public void startDocument () throws SAXException {
			i_elementValueBuilder = new StringBuilder ();
		}
		
		@Override
		public void endDocument () throws SAXException {
		}
		
		@Override
		public void startElement (String a_namespaceUri,String a_localName, String a_qualifiedName, Attributes a_attributes) throws SAXException {
			if (a_qualifiedName.equals ("objectName")) {
				i_isInObjectNameElement = true;
			}
			else if (a_qualifiedName.equals ("className")) {
				i_isInClassNameElement = true;
			}
			else if (a_qualifiedName.equals ("argumentTypeName")) {
				i_isInArgumentClassNameElement = true;
			}
			else if (a_qualifiedName.equals ("argumentValue")) {
				i_isInArgumentValueElement = true;
			}
			i_elementValueBuilder.delete (GeneralConstantsConstantsGroup.c_iterationStartingNumber, i_elementValueBuilder.length ());
		}
		
		@Override
		public void endElement (String a_namespaceUri, String a_localName, String a_qualifiedName) throws SAXException {
			try {
				if (i_isInObjectNameElement) {
					i_objectName = i_elementValueBuilder.toString ();
					i_isInObjectNameElement = false;
				}
				else if (i_isInClassNameElement) {
					i_className = i_elementValueBuilder.toString ();
					i_isInClassNameElement = false;
				}
				else if (i_isInArgumentClassNameElement) {
					i_argumentTypeName = i_elementValueBuilder.toString ();
					i_argumentTypes.add (ReflectionHandler.getClass (null, i_argumentTypeName, false));
					i_isInArgumentClassNameElement = false;
				}
				else if (i_isInArgumentValueElement) {
					i_argumentValues.add (ReflectionHandler.getPrimitiveWrappedDatum (null, i_argumentTypeName, i_elementValueBuilder.toString ()));
					i_argumentTypeName = null;
					i_isInArgumentValueElement = false;
				}
				if (a_qualifiedName.equals ("object")) {
					i_objectNameToObjectMap.put (i_objectName, ReflectionHandler.createInstance (null, i_className, i_argumentTypes, i_argumentValues));
					i_objectName = null;
					i_className = null;
					i_argumentTypes = null;
					i_argumentValues = null;
				}
			}
			catch (ClassNotFoundException | NoSuchMethodException | InstantiationException | IllegalAccessException | InvocationTargetException l_exception) {
				throw new SAXException (l_exception);
			}
		}
		
		@Override
		public void characters (char[] a_characters, int a_start, int a_length) throws SAXException {
			if (i_isInObjectNameElement) {
				i_elementValueBuilder.append (a_characters, a_start, a_length);
			}
		}
	}
	
	public ObjectsInstanciator () throws ParserConfigurationException, SAXNotRecognizedException, SAXException {
		SAXParserFactory l_saxParserFactory = SAXParserFactory.newInstance ();
		l_saxParserFactory.setFeature ("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
       	i_xmlParser = l_saxParserFactory.newSAXParser ();
		i_objectsInstanciationConfigurationXmlParseHandler = new ObjectsInstanciationConfigurationXmlParseHandler ();
	}
	
	public NavigableLinkedHashMap <String, Object> instanciateObjects (String a_configurationFilePath) throws FileNotFoundException, IOException, SAXException {
		i_xmlParser.parse (new FileInputStream (new File (a_configurationFilePath)), i_objectsInstanciationConfigurationXmlParseHandler);
		return i_objectsInstanciationConfigurationXmlParseHandler.getObjectNameToObjectMap();
	}
}

