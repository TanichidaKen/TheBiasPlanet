package theBiasPlanet.coreUtilities.displaysHandling;

import javax.swing.text.StyledEditorKit;
import javax.swing.text.ViewFactory;

public class LinesWrappedEditorPaneStyledEditorKit extends StyledEditorKit {
	ViewFactory i_linesWrappedViewsFactory;
	
	public LinesWrappedEditorPaneStyledEditorKit () {
		i_linesWrappedViewsFactory = new LinesWrappedEditorPaneViewsFactory ();
	}
	
	@Override
	protected void finalize () {
	}
	
	@Override
	public ViewFactory getViewFactory () {
		return i_linesWrappedViewsFactory;
	}
}

