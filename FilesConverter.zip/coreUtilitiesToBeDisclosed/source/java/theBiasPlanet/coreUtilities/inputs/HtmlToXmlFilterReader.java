package theBiasPlanet.coreUtilities.inputs;

import java.io.IOException;
import java.io.Reader;
import theBiasPlanet.coreUtilities.constantsGroups.DefaultValuesConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.HtmlExpressionsConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.InputPropertiesConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.XmlExpressionsConstantsGroup;
import theBiasPlanet.coreUtilities.inputsHandling.BufferOverflowedException;

public class HtmlToXmlFilterReader extends PushableReader {
	static final private int c_bufferSize = DefaultValuesConstantsGroup.c_smallBufferSize;
	static final private String c_defaultXmlDeclaration = XmlExpressionsConstantsGroup.c_xml1_0Declaration;
	final private char [] i_inMethodBuffer = new char [c_bufferSize];
	// -1: initial, 0: in the xml declaration, 1: to read the document type, 2: in the document type declaration, 3: to read the 'html' opening tag,  4: in the 'html' opening tag, 5: after the 'html' opening tag
	private int i_currentState = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
	private int i_namespaceOpenerMatchedCharactersIndex = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
	
	public HtmlToXmlFilterReader (Reader a_underlyingReader) {
		super (a_underlyingReader, c_bufferSize);
	}
	
	@Override
	public int read (char [] a_characters, int a_offset, int a_length) throws IOException {
		boolean l_currentPartExistsInOriginalData = false;
		int l_toReadLength = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		int l_readLength = InputPropertiesConstantsGroup.c_lengthNotRead;
		int l_readFunctionReturn = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		String l_readData = null;
		if (i_currentState == GeneralConstantsConstantsGroup.c_unspecifiedInteger) {
			try {
				skipWhiteSpacesAndHtmlComments ();
			}
			catch (BufferOverflowedException l_exception) {
				throw new IOException (l_exception);
			}
			i_currentState ++;
			l_toReadLength = XmlExpressionsConstantsGroup.c_xmlDeclarationOpener.length ();
			l_readFunctionReturn = super.readFixedLengthData (i_inMethodBuffer, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_toReadLength);
			if (l_readFunctionReturn == InputPropertiesConstantsGroup.c_noMoreData) {
				return l_readFunctionReturn;
			}
			l_readLength += l_readFunctionReturn;
			if (l_readLength == l_toReadLength) {
				l_readData = new String (i_inMethodBuffer, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength);
				if (XmlExpressionsConstantsGroup.c_xmlDeclarationOpener.equals (l_readData)) {
					l_currentPartExistsInOriginalData = true;
				}
				else {
					l_currentPartExistsInOriginalData = false;
				}
			}
			else {
				l_currentPartExistsInOriginalData = false;
			}
			try {
				super.pushData (i_inMethodBuffer, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength);
			}
			catch (BufferOverflowedException l_exception) {
				throw new IOException (l_exception);
			}
			if (!l_currentPartExistsInOriginalData) {
				try {
					super.pushData (c_defaultXmlDeclaration.toCharArray (), GeneralConstantsConstantsGroup.c_iterationStartNumber, c_defaultXmlDeclaration.length ());
				}
				catch (BufferOverflowedException l_exception) {
					throw new IOException (l_exception);
				}
			}
		}
		if (i_currentState == 1) {
			i_currentState ++;
			try {
				skipWhiteSpacesAndHtmlComments ();
			}
			catch (BufferOverflowedException l_exception) {
				throw new IOException (l_exception);
			}
			l_toReadLength = XmlExpressionsConstantsGroup.c_xhtmlDocumentTypeDeclarationOpener.length ();
			l_readFunctionReturn = super.readFixedLengthData (i_inMethodBuffer, l_readLength, l_toReadLength);
			if (l_readFunctionReturn == InputPropertiesConstantsGroup.c_noMoreData) {
				return l_readFunctionReturn;
			}
			l_readLength += l_toReadLength;
			if (l_readLength == l_toReadLength) {
				l_readData = new String (i_inMethodBuffer, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength);
				if (XmlExpressionsConstantsGroup.c_xhtmlDocumentTypeDeclarationOpener.equals (l_readData.toUpperCase ())) {
					l_currentPartExistsInOriginalData = true;
				}
				else {
					l_currentPartExistsInOriginalData = false;
				}
			}
			else {
				l_currentPartExistsInOriginalData = false;
			}
			if (l_currentPartExistsInOriginalData) {
				l_readLength = InputPropertiesConstantsGroup.c_lengthNotRead;
				l_toReadLength = 1;
				while ((l_readFunctionReturn = super.readFixedLengthData (i_inMethodBuffer, l_readLength, l_toReadLength)) != InputPropertiesConstantsGroup.c_noMoreData) {
					l_readLength += l_readFunctionReturn;
					if (i_inMethodBuffer [l_readLength - 1] == XmlExpressionsConstantsGroup.c_tagEndCharacter) {
						break;
					}
				}
			}
			else {
				try {
					super.pushData (i_inMethodBuffer, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength);
				}
				catch (BufferOverflowedException l_exception) {
					throw new IOException (l_exception);
				}
			}
			try {
				super.pushData (XmlExpressionsConstantsGroup.c_xhtml1_0DocumentTypeDeclaration.toCharArray (), GeneralConstantsConstantsGroup.c_iterationStartNumber, XmlExpressionsConstantsGroup.c_xhtml1_0DocumentTypeDeclaration.length ());
			}
			catch (BufferOverflowedException l_exception) {
				throw new IOException (l_exception);
			}
		}
		if (i_currentState == 3) {
			i_currentState ++;
			try {
				skipWhiteSpacesAndHtmlComments ();
			}
			catch (BufferOverflowedException l_exception) {
				throw new IOException (l_exception);
			}
			l_toReadLength = HtmlExpressionsConstantsGroup.c_htmlTagOpener.length ();
			l_readFunctionReturn = super.readFixedLengthData (i_inMethodBuffer, l_readLength, l_toReadLength);
			if (l_readFunctionReturn == InputPropertiesConstantsGroup.c_noMoreData) {
				return l_readFunctionReturn;
			}
			l_readLength += l_toReadLength;
			if (l_readLength == l_toReadLength) {
				l_readData = new String (i_inMethodBuffer, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength);
				if (HtmlExpressionsConstantsGroup.c_htmlTagOpener.equals (l_readData.toLowerCase ())) {
					l_currentPartExistsInOriginalData = true;
				}
				else {
					l_currentPartExistsInOriginalData = false;
				}
			}
			else {
				l_currentPartExistsInOriginalData = false;
			}
			if (!l_currentPartExistsInOriginalData) {
				return InputPropertiesConstantsGroup.c_noMoreData;
			}
			try {
				super.pushData (i_inMethodBuffer, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readLength);
			}
			catch (BufferOverflowedException l_exception) {
				throw new IOException (l_exception);
			}
		}
		if (i_currentState == 0 || i_currentState == 2) {
			l_readLength = InputPropertiesConstantsGroup.c_lengthNotRead;
			l_toReadLength = 1;
			while ((l_readFunctionReturn = super.readFixedLengthData (a_characters, a_offset + l_readLength, l_toReadLength)) != InputPropertiesConstantsGroup.c_noMoreData) {
				l_readLength += l_toReadLength;
				if (l_readLength == a_length) {
					break;
				}
				if (a_characters [a_offset + l_readLength - 1] == XmlExpressionsConstantsGroup.c_tagEndCharacter) {
					i_currentState ++;
					break;
				}
			}
			return l_readLength;
		}
		if (i_currentState == 4) {
			l_readLength = InputPropertiesConstantsGroup.c_lengthNotRead;
			l_toReadLength = 1;
			while ((l_readFunctionReturn = super.readFixedLengthData (a_characters, a_offset + l_readLength, l_toReadLength)) != InputPropertiesConstantsGroup.c_noMoreData) {
				l_readLength += l_toReadLength;
				if (i_namespaceOpenerMatchedCharactersIndex < XmlExpressionsConstantsGroup.c_xhtmlNamespaceOpener.length () - 1) {
					if (a_characters [a_offset + l_readLength - 1] == XmlExpressionsConstantsGroup.c_xhtmlNamespace.charAt (i_namespaceOpenerMatchedCharactersIndex + 1)) {
						i_namespaceOpenerMatchedCharactersIndex ++;
					}
					else {
						if (i_namespaceOpenerMatchedCharactersIndex == XmlExpressionsConstantsGroup.c_xhtmlNamespaceOpener.length () - 2 && (a_characters [a_offset + l_readLength - 1] == GeneralConstantsConstantsGroup.c_spaceCharacter || a_characters [a_offset + l_readLength - 1] == GeneralConstantsConstantsGroup.c_tabCharacter || a_characters [a_offset + l_readLength - 1] == GeneralConstantsConstantsGroup.c_newLineCharacter || a_characters [a_offset + l_readLength - 1] == GeneralConstantsConstantsGroup.c_carriageReturnCharacter)) {
						}
						else {
							i_namespaceOpenerMatchedCharactersIndex = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
							if (a_characters [a_offset + l_readLength - 1] == XmlExpressionsConstantsGroup.c_xhtmlNamespace.charAt (i_namespaceOpenerMatchedCharactersIndex + 1)) {
								i_namespaceOpenerMatchedCharactersIndex ++;
							}
						}
					}
				}
				if (a_characters [a_offset + l_readLength - 1] == XmlExpressionsConstantsGroup.c_tagEndCharacter) {
					if (i_namespaceOpenerMatchedCharactersIndex < XmlExpressionsConstantsGroup.c_xhtmlNamespaceOpener.length () - 1) {
						try {
							super.pushData (a_characters, a_offset + l_readLength - 1, l_readFunctionReturn);
							super.pushData (XmlExpressionsConstantsGroup.c_xhtmlNamespace.toCharArray () , GeneralConstantsConstantsGroup.c_iterationStartNumber, XmlExpressionsConstantsGroup.c_xhtmlNamespace.length ());
							super.pushData (GeneralConstantsConstantsGroup.c_spaceCharacter);
						}
						catch (BufferOverflowedException l_exception) {
							throw new IOException (l_exception);
						}
						l_readFunctionReturn = super.readFixedLengthData (a_characters, a_offset + l_readLength - 1, l_toReadLength);
					}
					else {
						i_currentState ++;
						break;
					}
				}
				if (l_readLength == a_length) {
					break;
				}
			}
			return l_readLength;
		}
		if (i_currentState == 5) {
			return super.read (a_characters, a_offset, a_length);
		}
		return InputPropertiesConstantsGroup.c_noMoreData;
	}
		
	public int read() throws IOException {
		char [] l_buffer = new char [1];
		read (l_buffer, 0, 1);
		return (int) l_buffer [0];
	}
	
	public int skipWhiteSpacesAndHtmlComments () throws IOException, BufferOverflowedException {
		return super.skipWhiteSpacesAndFromThroughAreas (XmlExpressionsConstantsGroup.c_commentOpener, XmlExpressionsConstantsGroup.c_commentCloser);
	}
}

