package theBiasPlanet.coreUtilities.displayElements;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.geom.Rectangle2D;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.border.MatteBorder;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.Element;
import javax.swing.text.JTextComponent;
import javax.swing.text.Utilities;
import theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.JTextComponentPropertyNamesConstantsGroup;
import theBiasPlanet.coreUtilities.messagingHandling.Publisher;

public class TextLineNumbersPanel extends JPanel implements CaretListener, DocumentListener, PropertyChangeListener, ComponentListener {
	private static final int c_borderLeftAndRightMargin = GeneralConstantsConstantsGroup.c_iterationStartNumber;
	private static final Color c_borderColor = Color.GRAY;
	private static final Color c_notCurrentLinesForegroundColor = Color.BLACK;
	private static final Color c_currentLineForegroundColor = Color.RED;
	private static final int c_defaultMinimumDisplayedNumberOfDigits = 3;
	private Font i_panelFont;
	private FontMetrics i_panelFontMetrics;
	private JTextComponent i_textComponent;
	private int i_minimumDisplayedNumberOfDigits = c_defaultMinimumDisplayedNumberOfDigits;
	private int i_displayedNumberOfDigits = 0;
	private Document i_textDocument;
	private	Element i_textDocumentRootElement;
	private Insets i_panelInsets;
	private int i_latestCurrentLineIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
	
	public TextLineNumbersPanel (JTextComponent a_textComponent, int a_minimumDisplayedNumberOfDigits) {
		i_textComponent = a_textComponent;
		i_panelFont = i_textComponent.getFont ();
		setFont (i_panelFont);
		i_panelFontMetrics = getFontMetrics (i_panelFont);
		setBorder (new MatteBorder (GeneralConstantsConstantsGroup.c_iterationStartNumber, c_borderLeftAndRightMargin, GeneralConstantsConstantsGroup.c_iterationStartNumber, c_borderLeftAndRightMargin, c_borderColor));
		i_minimumDisplayedNumberOfDigits = a_minimumDisplayedNumberOfDigits;
		i_panelInsets = getInsets ();
		i_textDocument = i_textComponent.getDocument ();
		i_textDocumentRootElement = i_textDocument.getDefaultRootElement ();
		i_textDocument.addDocumentListener (this);
		i_textComponent.addCaretListener (this);
		i_textComponent.addPropertyChangeListener (JTextComponentPropertyNamesConstantsGroup.c_font, this);
		i_textComponent.addComponentListener (this);
		setWidth ();
	}
	
	public TextLineNumbersPanel (JTextComponent a_textComponent) {
		this (a_textComponent, c_defaultMinimumDisplayedNumberOfDigits);
	}
	
	@Override
	protected void finalize () {
	}
	
	private void setWidth () {
		int l_numberOfLines = i_textDocumentRootElement.getElementCount ();
		int l_maximumNumberOfDigits = Math.max ((int) Math.log10(l_numberOfLines) + 1, i_minimumDisplayedNumberOfDigits);
		if (i_displayedNumberOfDigits != l_maximumNumberOfDigits) {
			i_displayedNumberOfDigits = l_maximumNumberOfDigits;
			int l_numberWidth = i_panelFontMetrics.charWidth ('0') * i_displayedNumberOfDigits;
			int l_panelWidth = i_panelInsets.left + i_panelInsets.right + l_numberWidth;
			Dimension l_panelSize = getPreferredSize ();
			l_panelSize.setSize (l_panelWidth, i_textComponent.getHeight ());
			setPreferredSize (l_panelSize);
			setSize (l_panelSize);
		}
	}
	
	@Override
	public void paintComponent (Graphics a_graphics) {
		super.paintComponent (a_graphics);
		int l_availableWidthForLineNumber = getSize ().width - i_panelInsets.left - i_panelInsets.right;
		Rectangle l_clippedBounds = a_graphics.getClipBounds ();
		int l_startRowOffset = i_textComponent.viewToModel2D (new Point (GeneralConstantsConstantsGroup.c_iterationStartNumber, l_clippedBounds.y));
		int l_endRowOffset = i_textComponent.viewToModel2D (new Point (GeneralConstantsConstantsGroup.c_iterationStartNumber, l_clippedBounds.y + l_clippedBounds.height));
		int l_iteratedRowOffset = l_startRowOffset;
		while (l_iteratedRowOffset <= l_endRowOffset) {
			try {
				if (isCurrentLine (l_iteratedRowOffset)) {
					a_graphics.setColor (c_currentLineForegroundColor);
				}
				else {
					a_graphics.setColor (c_notCurrentLinesForegroundColor);
				}
				String l_lineNumberString = getTextLineNumberString (l_iteratedRowOffset);
				int l_lineNumberStringWidth = i_panelFontMetrics.stringWidth (l_lineNumberString);
				int l_drawX = getOffsetX (l_availableWidthForLineNumber, l_lineNumberStringWidth) + i_panelInsets.left;
				int l_drawY = getOffsetY (l_iteratedRowOffset);
				a_graphics.drawString (l_lineNumberString, l_drawX, l_drawY);
				l_iteratedRowOffset = Utilities.getRowEnd (i_textComponent, l_iteratedRowOffset) + 1;
			}
			catch(Exception l_exception) {
				Publisher.show (l_exception.toString ());
				break;
			}
		}
	}
	
	private boolean isCurrentLine (int a_lineOffset) {
		int l_caretOffset = i_textComponent.getCaretPosition ();
		if (i_textDocumentRootElement.getElementIndex (a_lineOffset) == i_textDocumentRootElement.getElementIndex (l_caretOffset)) {
			return true;
		}
		else {
			return false;
		}
	}
	
	// a_rowOffset may not be the offset of the line if the row is a latter part of a wrapped line
	protected String getTextLineNumberString (int a_rowOffset) {
		int l_textDocumentElementIndex = i_textDocumentRootElement.getElementIndex (a_rowOffset);
		Element l_textLine = i_textDocumentRootElement.getElement  (l_textDocumentElementIndex);
		if (l_textLine.getStartOffset () == a_rowOffset) {
			return String.valueOf (l_textDocumentElementIndex + 1);
		}
		else {
			// wrapped row
			return GeneralConstantsConstantsGroup.c_emptyString;
		}
	}
	
	private int getOffsetX (int a_availableWidthForLineNumber, int a_lineNumberStringWidth) {
		return a_availableWidthForLineNumber - a_lineNumberStringWidth;
	}
	
	private int getOffsetY (int a_rowOffset) throws BadLocationException {
		Rectangle2D l_rowHeadRectangle = i_textComponent.modelToView2D (a_rowOffset);
		int l_panelRowHeight = i_panelFontMetrics.getHeight ();
		int l_drawY = (int) (l_rowHeadRectangle.getY () + l_rowHeadRectangle.getHeight ());
		int l_stringDescent = i_panelFontMetrics.getDescent ();
		return l_drawY - l_stringDescent;
	}
	
	@Override
	public void caretUpdate (CaretEvent a_caretEvent) {
		int l_caretOffset = i_textComponent.getCaretPosition ();
		int l_currentLineIndex = i_textDocumentRootElement.getElementIndex (l_caretOffset);
		if (i_latestCurrentLineIndex != l_currentLineIndex) {
			repaint ();
			i_latestCurrentLineIndex = l_currentLineIndex;
		}
	}
	
	@Override
	public void changedUpdate (DocumentEvent a_documentEvent) {
		documentChanged ();
	}
	
	@Override
	public void insertUpdate (DocumentEvent a_documentEvent) {
		documentChanged ();
	}
	
	@Override
	public void removeUpdate (DocumentEvent a_documentEvent) {
		documentChanged ();
	}
	
	private void documentChanged () {
		SwingUtilities.invokeLater (new Runnable () {
			@Override
			public void run ()
			{
				setWidth ();
				repaint ();
			}
		});
	}
	
	@Override
	public void propertyChange (PropertyChangeEvent a_propertyChangeEvent) {
		if (a_propertyChangeEvent.getNewValue () instanceof Font) {
			repaint ();
		}
	}
	
	public void componentResized (ComponentEvent a_componentEvent) {
		Dimension l_panelSize = getPreferredSize ();
		l_panelSize.setSize (l_panelSize.getWidth (), i_textComponent.getHeight ());
		setPreferredSize (l_panelSize);
		setSize (l_panelSize);
    }
	
	public void componentHidden (ComponentEvent a_componentEvent) {
	}
	
	public void componentMoved (ComponentEvent a_componentEvent) {
	}
	
	public void componentShown (ComponentEvent a_componentEvent) {
	}
}

