package theBiasPlanet.coreUtilities.constantsGroups;

public interface FxStyleClassesConstantsGroup {
	String c_pane = "pane";
	String c_basePane = "basePane";
	String c_dialogPane = "dialogPane";
	String c_visibleBorderLinesPane = "visibleBorderLinesPane";
	String c_invisibleBorderLinesPane = "invisibleBorderLinesPane";
}

