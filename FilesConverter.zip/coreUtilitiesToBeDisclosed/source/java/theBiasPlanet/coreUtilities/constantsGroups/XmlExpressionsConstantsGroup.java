package theBiasPlanet.coreUtilities.constantsGroups;

public interface XmlExpressionsConstantsGroup {
	String c_xml1_0Declaration = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
	String c_lessThanXmlExpression = "&lt;";
	String c_greaterThanXmlExpression = "&gt;";
	String c_ampersandXmlExpression = "&amp;";
	String c_doubleQuotationMarkXmlExpression = "&quot;";
	String c_apostropheXmlExpression = "&apos;";
}

