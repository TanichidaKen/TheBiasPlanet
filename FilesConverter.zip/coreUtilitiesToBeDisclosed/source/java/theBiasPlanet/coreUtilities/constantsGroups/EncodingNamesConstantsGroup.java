package theBiasPlanet.coreUtilities.constantsGroups;

public interface EncodingNamesConstantsGroup {
	String c_utf8EncodingName = "UTF-8";
	String c_utf16EncodingName = "UTF-16BE";
	String c_utf16LittleEndianEncodingName = "UTF-16LE";
	String c_utf8InputStreamReaderReturningEncodingName = "UTF8";
	String c_utf16InputStreamReaderReturningEncodingName = "UTF16";
}

