package theBiasPlanet.coreUtilities.constantsGroups;

public interface MimeTypesConstantsGroup {
	String c_textPlain = "text/plain";
}

