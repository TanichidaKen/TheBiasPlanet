package theBiasPlanet.coreUtilities.constantsGroups;

import java.nio.file.Path;
import java.nio.file.Paths;

public interface CommandPathsConstantsGroup {
	Path c_nmCommandAbsolutePath = Paths.get ("/usr/bin/nm");
}

