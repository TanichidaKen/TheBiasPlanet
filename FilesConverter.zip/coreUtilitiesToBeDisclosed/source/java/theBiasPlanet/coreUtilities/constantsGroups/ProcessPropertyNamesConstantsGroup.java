package theBiasPlanet.coreUtilities.constantsGroups;

public interface ProcessPropertyNamesConstantsGroup {
	String c_styleSheetUrl = "styleSheetUrl";
}

