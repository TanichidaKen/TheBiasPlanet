package theBiasPlanet.coreUtilities.constantsGroups;

public interface UserInterfaceComponentCaptionsConstantsGroup {
	String c_generalFullFormat = "%%s%%%ds";
	String c_generalAbrreviatedFormat = "%s...";
	String c_disconnect = "Disconnect";
	String c_connect = "Connect";
	String c_accept = "Accept";
	String c_suspend = "Suspend";
	String c_replace = "Replace";
	String c_cancel = "Cancel";
	String c_search = "Search";
	String c_replaceAndSearch = "Replace and Search";
	String c_undo = "Undo";
	String c_redo = "Redo";
	String c_cut = "Cut";
	String c_copy = "Copy";
	String c_paste = "Paste";
	String c_open = "Open";
	String c_chooseFile = "...";
	String c_selectAll = "Select All";
	String c_cellConnectedFormat = "Row index: %d, Column index: %d";
	String c_cellNotConnected = "No Cell Is Connected";
}

