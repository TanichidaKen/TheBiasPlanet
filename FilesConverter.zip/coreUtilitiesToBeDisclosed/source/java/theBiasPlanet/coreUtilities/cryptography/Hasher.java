package theBiasPlanet.coreUtilities.cryptography;

import java.security.NoSuchAlgorithmException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class Hasher {
	private static final String c_sha1HashingAlgorismName = "SHA-1";
	private static final String c_sha256HashingAlgorismName = "SHA-256";
	private static final String c_pbkdf2HashingAlgorismName = "PBKDF2WithHmacSHA1";
	private static final String c_sha1RandomDatumGenerationAlgorismName = "SHA1PRNG";
	private static MessageDigest s_sha1MessageDigester;
	private static MessageDigest s_sha256MessageDigester;
	private static SecretKeyFactory s_pbkdf2SecretKeysFactory;
	private static SecureRandom s_sha1RandomDatumGenerator;
	
	static {
		try {
			s_sha1MessageDigester = MessageDigest.getInstance (c_sha1HashingAlgorismName);
			s_sha256MessageDigester = MessageDigest.getInstance (c_sha256HashingAlgorismName);
			s_pbkdf2SecretKeysFactory = SecretKeyFactory.getInstance (c_pbkdf2HashingAlgorismName);
  			s_sha1RandomDatumGenerator = SecureRandom.getInstance (c_sha1RandomDatumGenerationAlgorismName);
		}
		catch (NoSuchAlgorithmException l_exception) {
		}
	}
	
	public static byte [] createSalt (int a_numberOfBytes) {
		byte[] l_saltBytesArray = new byte [a_numberOfBytes];
		s_sha1RandomDatumGenerator.nextBytes (l_saltBytesArray);
		return l_saltBytesArray;
	}
	
	public static byte [] hashInSha1 (byte [] a_originalDatumBytesArray, byte [] a_saltBytesArray) {
		s_sha1MessageDigester.update (a_saltBytesArray);
		return s_sha1MessageDigester.digest (a_originalDatumBytesArray);
	}
	
	public static byte [] hashInSha256 (byte [] a_originalDatumBytesArray, byte [] a_saltBytesArray) {
		s_sha256MessageDigester.update (a_saltBytesArray);
		return s_sha256MessageDigester.digest (a_originalDatumBytesArray);
	}
	
	public static byte [] hashInPbkdf2 (String a_originalDatum, byte [] a_saltBytesArray, int a_numberOfIteration, int a_keyLength) throws InvalidKeySpecException {
		PBEKeySpec l_pbeKeySpecification = new PBEKeySpec (a_originalDatum.toCharArray (), a_saltBytesArray, a_numberOfIteration, a_keyLength * 8);
		return s_pbkdf2SecretKeysFactory.generateSecret (l_pbeKeySpecification).getEncoded ();
	}
}

