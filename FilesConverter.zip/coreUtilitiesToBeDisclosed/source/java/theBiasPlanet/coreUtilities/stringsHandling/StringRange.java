package theBiasPlanet.coreUtilities.stringsHandling;

public class StringRange {
	private int startOffset = -1;
	private int endOffset = -1;
	
	public StringRange (int p_startOffset, int p_endOffset) {
		startOffset = p_startOffset;
		endOffset = p_endOffset;
	}
	
	public int getStartOffset () {
		return startOffset;
	}
	
	public int getEndOffset () {
		return endOffset;
	}
}

