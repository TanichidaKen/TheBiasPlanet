package theBiasPlanet.coreUtilities.stringsHandling;

import theBiasPlanet.coreUtilities.constantsGroups.*;

public class StringTokenizer {
	private String [] i_tokens = null;
	private int i_numberOfTokens = GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger;
	private int i_currentIndex = GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger;
	
	public StringTokenizer (String a_targetString, String a_delimitersRegularExpression) {
		if (a_targetString != null) {
			i_tokens = a_targetString.split (a_delimitersRegularExpression);
			i_numberOfTokens = i_tokens.length;
			i_currentIndex = GeneralConstantsConstantsGroup.c_iterationStartingNumber;
		}
	}
	
	public int countTokens () {
		return i_numberOfTokens - i_currentIndex;
	}
	
	public boolean hasMoreTokens () {
		return i_currentIndex < i_numberOfTokens;
	}
	
	public String nextToken () {
		i_currentIndex ++;
		return i_tokens [i_currentIndex - 1];
	}
}

