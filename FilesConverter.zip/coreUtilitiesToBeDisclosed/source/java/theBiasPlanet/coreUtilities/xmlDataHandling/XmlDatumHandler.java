package theBiasPlanet.coreUtilities.xmlDataHandling;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.NamedNodeMap;
import theBiasPlanet.coreUtilities.constantsGroups.*;

public final class XmlDatumHandler {
	private XmlDatumHandler () {
	}
	
	// To get the map of a first tier node attribute (only the first attribute is ) value to second tier node attribute values.
	// The root node isn't counted as a tier.
	public static HashMap <String, List <String>> get2TierAttributeValues (String a_xmlFileUrl) throws IOException, ParserConfigurationException, SAXException {
		HashMap <String, List <String>> l_attributesMap = new HashMap <String, List <String>> ();
		DocumentBuilderFactory l_documentBuilderFactory = DocumentBuilderFactory.newInstance ();
		DocumentBuilder l_documentBuilder = l_documentBuilderFactory.newDocumentBuilder ();
		Document l_document = l_documentBuilder.parse (a_xmlFileUrl);
		Element l_rootElement = l_document.getDocumentElement ();
		NodeList l_rootChildNodes = l_rootElement.getChildNodes ();
		if (l_rootChildNodes == null) {
			return l_attributesMap;
		}
		for (int l_i = 0; l_i < l_rootChildNodes.getLength (); l_i++) {
			Node l_rootChildNode = l_rootChildNodes.item (l_i);
			if (l_rootChildNode.getNodeType () == Node.ELEMENT_NODE) {
				String l_key = null;
				List <String> l_value = new ArrayList <String> ();
				NamedNodeMap l_rootChildNodeAttributes =  l_rootChildNode.getAttributes ();
				if (l_rootChildNodeAttributes == null) {
					continue;
				}
				Node l_rootChildNodeAttribute = l_rootChildNodeAttributes.item (0);
				l_key = l_rootChildNodeAttribute.getTextContent ();
				NodeList l_rootGrandChildNodes = l_rootChildNode.getChildNodes ();
				if (l_rootGrandChildNodes != null) {
					for (int l_j = 0; l_j < l_rootGrandChildNodes.getLength (); l_j++) {
						Node l_rootGrandChildNode = l_rootGrandChildNodes.item (l_j);
						if (l_rootGrandChildNode.getNodeType () == Node.ELEMENT_NODE) {
							String l_rootGrandChildNodeAttributeText = null;
							NamedNodeMap l_rootGrandChildNodeAttributes =  l_rootGrandChildNode.getAttributes ();
							if (l_rootGrandChildNodeAttributes == null) {
								continue;
							}
							Node l_rootGrandChildNodeAttribute = l_rootGrandChildNodeAttributes.item (0);
							l_rootGrandChildNodeAttributeText = l_rootGrandChildNodeAttribute.getTextContent ();
							l_value.add (l_rootGrandChildNodeAttributeText);
						}
					}
				}
				l_attributesMap.put (l_key, l_value);
			}
		}
		return l_attributesMap;	
	}
}

