namespace theBiasPlanet {
	namespace coreUtilities {
		namespace inputs {
			using System;
			using System.IO;
			using System.Text;
			using System.Threading.Tasks;
			using theBiasPlanet.coreUtilities.constantsGroups;
			using theBiasPlanet.coreUtilities.inputsHandling;
			
			// Note that C# 'Read*' returns 0, not -1, when there is no more datum.
			public class PushableReader: TextReader {
				TextReader i_underlyingReader;
				private Int32 i_bufferSize;
				private Char [] i_buffer;
				private Int32 i_characterStartIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
				private Int32 i_characterUntilIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
				private Char [] i_inMethodBuffer = new Char [1];
				
				public PushableReader (TextReader a_underlyingReader, Int32 a_bufferSize): base () {
					i_underlyingReader = a_underlyingReader;
					i_bufferSize = a_bufferSize;
					i_buffer = new Char [i_bufferSize];
				}
				
				private Int32 readFromBuffer (Char [] a_characters, Int32 a_offset, Int32 a_length) {
					Int32 l_readLength = 0;
					Int32 l_toReadLength = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
					if (i_characterStartIndex == GeneralConstantsConstantsGroup.c_iterationStartNumber && i_characterUntilIndex == GeneralConstantsConstantsGroup.c_iterationStartNumber) {
					}
					else if (i_characterUntilIndex > i_characterStartIndex) {
						l_toReadLength = Math.Min (a_length, i_characterUntilIndex - i_characterStartIndex);
						Array.Copy (i_buffer, i_characterStartIndex, a_characters, a_offset, l_toReadLength);
						l_readLength += l_toReadLength;
						i_characterStartIndex += l_toReadLength;
						if (i_characterStartIndex == i_characterUntilIndex) {
							i_characterStartIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
							i_characterUntilIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
						}
					}
					else {
						l_toReadLength = Math.Min (a_length, i_bufferSize - i_characterStartIndex);
						Array.Copy (i_buffer, i_characterStartIndex, a_characters, a_offset, l_toReadLength);
						l_readLength += l_toReadLength;
						i_characterStartIndex += l_toReadLength;
						if (i_characterStartIndex == i_bufferSize) {
							i_characterStartIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
							if (l_readLength < a_length) {
								l_toReadLength = Math.Min (a_length - l_readLength, i_characterUntilIndex - i_characterStartIndex);
								Array.Copy (i_buffer, i_characterStartIndex, a_characters, a_offset + l_readLength, l_toReadLength);
								l_readLength += l_toReadLength;
								i_characterStartIndex += l_toReadLength;
								if (i_characterStartIndex == i_characterUntilIndex) {
									i_characterStartIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
									i_characterUntilIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
								}
							}
						}
					}
					return l_readLength;
				}
				
				public override void Close () {
					i_underlyingReader.Close ();
					i_characterStartIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
					i_characterUntilIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
				}
				
				// ??? CreateObjRef(Type)
				
				protected override void Dispose (Boolean a_managedResourcesAreDisposed) {
					//i_underlyingReader.Dispose (a_managedResourcesAreDisposed);
					if (a_managedResourcesAreDisposed) {
						i_characterStartIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
						i_characterUntilIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
					}
				}
				
				public override Int32 Peek () {
					if (i_characterStartIndex == GeneralConstantsConstantsGroup.c_iterationStartNumber && i_characterUntilIndex == GeneralConstantsConstantsGroup.c_iterationStartNumber) {
						return i_underlyingReader.Peek ();
					}
					else {
						return (Int32) (i_buffer [i_characterStartIndex]);
					}
				}
				
				public override Int32 Read () {
					Int32 l_readFunctionReturn = Read (i_inMethodBuffer, GeneralConstantsConstantsGroup.c_iterationStartNumber, 1);
					if (l_readFunctionReturn == 0) {
						return GeneralConstantsConstantsGroup.c_unspecifiedInteger;
					}
					else {
						return i_inMethodBuffer [GeneralConstantsConstantsGroup.c_iterationStartNumber];
					}
				}
				
				public override Int32 Read (Char [] a_characters, Int32 a_offset, Int32 a_length) {
					Int32 l_readLength = 0;
					l_readLength = readFromBuffer (a_characters, a_offset, a_length);
					if (l_readLength < a_length) {
						Int32 l_readFunctionReturn = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
						l_readFunctionReturn = i_underlyingReader.Read (a_characters, a_offset + l_readLength, a_length - l_readLength);
						if (l_readFunctionReturn != 0) {
							l_readLength += l_readFunctionReturn;
						}
						else {
							/*
							if (l_readLength == 0) {
								l_readLength = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
							}
							*/
						}
					}
					return l_readLength;
				}
				
				/* Span (since C# 7.3) isn't supported by mono yet
				public override Int32 Read (Span <Char> a_span) {
					Int32 l_spanLength = a_span.Length;
					Char [] l_characters = new Char [l_memoryLength];
					Int32 l_readLength = Read (l_characters, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_spanLength);
					for (Int32 l_characterIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber; l_characterIndex < l_readLength; l_characterIndex ++) {
						a_span.Item [l_characterIndex] = l_characters [l_characterIndex];
					}
					return l_readLength;
				}
				*/
				
				public override Task <Int32> ReadAsync (Char [] a_characters, Int32 a_offset, Int32 a_length) {
					Task <Int32> l_asynchronousOperation = Task <Int32>.Run ( () => {
						Int32 l_readLength = Read (a_characters, a_offset, a_length);
						return l_readLength;
					} );
					return l_asynchronousOperation;
				}
				
				/* Memory (since C# 7.3) isn't supported by mono yet
				public override ValueTask <Int32> ReadAsync (Memory <Char> a_memory, CancellationToken a_cancellationToken = null) {
					Task <Int32> l_asynchronousOperation = Task <Int32>.Run ( () => {
						Int32 l_memoryLength = a_memory.Length;
						Char [] l_characters = new Char [l_memoryLength];
						Int32 l_readLength = Read (l_characters, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_memoryLength);
						for (Int32 l_characterIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber; l_characterIndex < l_readLength; l_characterIndex ++) {
							a_memory.Item [l_characterIndex] = l_characters [l_characterIndex];
						}
						return l_readLength;
					}, a_cancellationToken);
					return new ValueTask <Int32> (l_asynchronousOperation);
				}
				*/
				
				public override Int32 ReadBlock (Char [] a_characters, Int32 a_offset, Int32 a_length) {
					Int32 l_readLength = 0;
					l_readLength = readFromBuffer (a_characters, a_offset, a_length);
					if (l_readLength < a_length) {
						Int32 l_readFunctionReturn = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
						while ((l_readFunctionReturn = i_underlyingReader.Read (a_characters, a_offset + l_readLength, a_length - l_readLength)) != 0) {
							l_readLength += l_readFunctionReturn;
							if (l_readLength == a_length) {
								break;
							}
						}
					}
					/*
					if (l_readLength == 0 && a_length > 0) {
						l_readLength = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
					}
					*/
					return l_readLength;
				}
				
				/* Span (since C# 7.3) isn't supported by mono yet
				public override Int32 ReadBlock (Span <Char> a_span) {
					Int32 l_spanLength = a_span.Length;
					Char [] l_characters = new Char [l_memoryLength];
					Int32 l_readLength = ReadBlock (l_characters, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_spanLength);
					for (Int32 l_characterIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber; l_characterIndex < l_readLength; l_characterIndex ++) {
						a_span.Item [l_characterIndex] = l_characters [l_characterIndex];
					}
					return l_readLength;
				}
				*/
				
				public override Task <Int32> ReadBlockAsync (Char [] a_characters, Int32 a_offset, Int32 a_length) {
					Task <Int32> l_asynchronousOperation = Task <Int32>.Run ( () => {
						Int32 l_readLength = ReadBlock (a_characters, a_offset, a_length);
						return l_readLength;
					} );
					return l_asynchronousOperation;
				}
				
				/* Memory (since C# 7.3) isn't supported by mono yet
				public override ValueTask <Int32> ReadBlockAsync (Memory <Char> a_memory, CancellationToken a_cancellationToken = null) {
					Task <Int32> l_asynchronousOperation = Task <Int32>.Run ( () => {
						Int32 l_memoryLength = a_memory.Length;
						Char [] l_characters = new Char [l_memoryLength];
						Int32 l_readLength = ReadBlock (l_characters, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_memoryLength);
						for (Int32 l_characterIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber; l_characterIndex < l_readLength; l_characterIndex ++) {
							a_memory.Item [l_characterIndex] = l_characters [l_characterIndex];
						}
						return l_readLength;
					}, a_cancellationToken);
					return new ValueTask <Int32> (l_asynchronousOperation);
				}
				*/
				
				public override String ReadLine () {
					StringBuilder l_stringBuilder = new StringBuilder ();
					Int32 l_readFunctionReturn = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
					while (true) {
						l_readFunctionReturn = Read ();
						if (l_readFunctionReturn == GeneralConstantsConstantsGroup.c_unspecifiedInteger) {
							break;
						}
						else {
							if (l_readFunctionReturn == (Int32) GeneralConstantsConstantsGroup.c_newLineCharacter) {
								break;
							}
							if (l_readFunctionReturn == (Int32) GeneralConstantsConstantsGroup.c_carriageReturnCharacter) {
								l_readFunctionReturn = Read ();
								if (l_readFunctionReturn == GeneralConstantsConstantsGroup.c_unspecifiedInteger) {
									break;
								}
								else {
									if (l_readFunctionReturn == (Int32) GeneralConstantsConstantsGroup.c_newLineCharacter) {
										break;
									}
									else {
										pushData ( (Char) l_readFunctionReturn);
										break;
									}
								}
							}
						}
						l_stringBuilder.Append ( (Char) l_readFunctionReturn);
					}
					return l_stringBuilder.ToString ();
				}
				
				public override Task <String> ReadLineAsync () {
					Task <String> l_asynchronousOperation = Task <String>.Run ( () => {
						String l_string = ReadLine ();
						return l_string;
					} );
					return l_asynchronousOperation;

				}
				
				public override String ReadToEnd () {
					StringBuilder l_stringBuilder = new StringBuilder ();
					Char [] l_characters = new Char [i_bufferSize];
					Int32 l_readFunctionReturn = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
					while (true) {
						l_readFunctionReturn = ReadBlock (l_characters, GeneralConstantsConstantsGroup.c_iterationStartNumber, i_bufferSize);
						if (l_readFunctionReturn == GeneralConstantsConstantsGroup.c_unspecifiedInteger) {
							break;
						}
						l_stringBuilder.Append (l_characters, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readFunctionReturn);
					}
					return l_stringBuilder.ToString ();
				}
				
				public override Task <String> ReadToEndAsync () {
					Task <String> l_asynchronousOperation = Task <String>.Run ( () => {
						String l_string = ReadToEnd ();
						return l_string;
					} );
					return l_asynchronousOperation;
				}
				
				public virtual void pushData (Char [] a_characters, Int32 a_offset, Int32 a_length) {
					Int32 l_toPushLength = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
					Int32 l_pushedLength = 0;
					if (a_length<= 0) {
						return;
					}
					if (i_characterStartIndex == i_characterUntilIndex && i_characterStartIndex == 0) {
						l_toPushLength = Math.Min (i_bufferSize, a_length);
						if (l_toPushLength > 0) {
							Array.Copy (a_characters, a_offset, i_buffer, i_characterStartIndex, l_toPushLength);
							l_pushedLength += l_toPushLength;
							i_characterUntilIndex += l_pushedLength;
						}
					}
					else if (i_characterUntilIndex > i_characterStartIndex) {
						l_toPushLength = Math.Min (i_characterStartIndex, a_length);
						if (l_toPushLength > 0) {
							Array.Copy (a_characters, a_offset, i_buffer, i_characterStartIndex - l_toPushLength, l_toPushLength);
							l_pushedLength += l_toPushLength;
							i_characterStartIndex -= l_pushedLength;
						}
						if (l_pushedLength < a_length) {
							l_toPushLength = Math.Min (i_bufferSize - i_characterUntilIndex, a_length - l_pushedLength);
							if (l_toPushLength > 0) {
								Array.Copy (a_characters, a_offset + l_pushedLength, i_buffer, i_bufferSize - l_toPushLength, l_toPushLength);
								l_pushedLength += l_toPushLength;
								i_characterStartIndex = i_bufferSize - l_pushedLength;
							}
						}
					}
					else {
						l_toPushLength = Math.Min (i_characterStartIndex - i_characterUntilIndex, a_length);
						if (l_toPushLength > 0) {
							Array.Copy (a_characters, a_offset, i_buffer, i_characterStartIndex - l_toPushLength, l_toPushLength);
							l_pushedLength += l_toPushLength;
							i_characterStartIndex -= l_pushedLength;
						}
					}
					if (l_pushedLength < a_length) {
						throw new BufferOverflowedException (null);
					}
				}
				
				public virtual void pushData (Char a_character) {
					i_inMethodBuffer [GeneralConstantsConstantsGroup.c_iterationStartNumber] = a_character;
					pushData (i_inMethodBuffer, GeneralConstantsConstantsGroup.c_iterationStartNumber, 1);
				}
				
				// return: the number of skipped white spaces
				public virtual Int32 skipWhiteSpaces () {
					Int32 l_toReadLength = 1;
					Int32 l_readLength = 0;
					Int32 l_readFunctionReturn = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
					while ((l_readFunctionReturn = ReadBlock (i_inMethodBuffer, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_toReadLength)) != GeneralConstantsConstantsGroup.c_unspecifiedInteger) {
						if (i_inMethodBuffer [GeneralConstantsConstantsGroup.c_iterationStartNumber] != GeneralConstantsConstantsGroup.c_spaceCharacter && i_inMethodBuffer [GeneralConstantsConstantsGroup.c_iterationStartNumber] != GeneralConstantsConstantsGroup.c_tabCharacter && i_inMethodBuffer [GeneralConstantsConstantsGroup.c_iterationStartNumber] != GeneralConstantsConstantsGroup.c_newLineCharacter && i_inMethodBuffer [GeneralConstantsConstantsGroup.c_iterationStartNumber] != GeneralConstantsConstantsGroup.c_carriageReturnCharacter) {
							pushData (i_inMethodBuffer, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readFunctionReturn);
							break;
						}
						l_readLength += l_readFunctionReturn;
					}
					return l_readLength;
				}
				
				// return: the number of skipped characters
				public Int32 skipThrough (String a_throughString) {
					Int32 l_toReadLength = 1;
					Int32 l_readLength = 0;
					Int32 l_readFunctionReturn = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
					Int32 l_throughStringLength = a_throughString.Length;
					Int32 l_throughStringMatchedCharactersIndex = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
					while ((l_readFunctionReturn = ReadBlock (i_inMethodBuffer, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_toReadLength)) != GeneralConstantsConstantsGroup.c_unspecifiedInteger) {
						l_readLength += l_readFunctionReturn;
						if (l_readFunctionReturn < l_toReadLength) {
							return l_readLength;
						}
						if (i_inMethodBuffer [GeneralConstantsConstantsGroup.c_iterationStartNumber] == a_throughString [l_throughStringMatchedCharactersIndex + 1]) {
							l_throughStringMatchedCharactersIndex ++;
						}
						else {
							l_throughStringMatchedCharactersIndex = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
							if (i_inMethodBuffer [GeneralConstantsConstantsGroup.c_iterationStartNumber] == a_throughString [l_throughStringMatchedCharactersIndex + 1]) {
								l_throughStringMatchedCharactersIndex ++;
							}
						}
						if (l_throughStringMatchedCharactersIndex == l_throughStringLength - 1) {
							return l_readLength;
						}
					}
					return l_readLength;
				}
				
				// return: the number of skipped characters
				public Int32 skipWhiteSpacesAndFromThroughAreas (String a_fromString, String a_throughString) {
					Int32 l_fromStringLength = a_fromString.Length;
					Int32 l_toReadLength = l_fromStringLength;
					Int32 l_readLength = 0;
					Int32 l_readFunctionReturn = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
					String l_readData = null;
					Boolean l_skipFinished = false;
					Char [] l_inMethodBuffer = new Char [l_fromStringLength];
					while (true) {
						l_readLength += skipWhiteSpaces ();
						l_readFunctionReturn = ReadBlock (l_inMethodBuffer, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_toReadLength);
						if (l_readFunctionReturn == GeneralConstantsConstantsGroup.c_unspecifiedInteger) {
							l_skipFinished = true;
						}
						else {
							if (l_readFunctionReturn == l_toReadLength) {
								l_readData = new String (l_inMethodBuffer, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readFunctionReturn);
								if (a_fromString == l_readData) {
									l_readLength += l_readFunctionReturn;
									l_readLength += skipThrough (a_throughString);
								}
								else {
									l_skipFinished = true;
								}
							}
							else {
								l_skipFinished = true;
							}
						}
						if (l_skipFinished) {
							if (l_readFunctionReturn > 0) {
								pushData (l_inMethodBuffer, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readFunctionReturn);
							}
							return l_readLength;
						}
					}
				}
			}
		}
	}
}


