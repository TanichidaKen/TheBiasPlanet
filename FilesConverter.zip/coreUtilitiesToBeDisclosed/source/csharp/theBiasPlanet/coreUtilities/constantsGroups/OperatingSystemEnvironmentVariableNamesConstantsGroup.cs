namespace theBiasPlanet {
	namespace coreUtilities {
		namespace constantsGroups {
			using System;
			
			public static class OperatingSystemEnvironmentVariableNamesConstantsGroup {
				public const String c_path = "PATH";
			}
		}
	}
}

