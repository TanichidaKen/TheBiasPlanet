namespace theBiasPlanet {
	namespace coreUtilities {
		namespace constantsGroups {
			using System;
			
			public static class FileNameSuffixesConstantsGroup {
				public const String c_xmlFileNameSuffix = "xml";
				public const String c_styleSheetFileNameSuffix = "xslt";
				public const String c_jarFileNameSuffix = "jar";
				public const String c_javaFileNameSuffix = "java";
				public const String c_saveFileNameSuffix = "save";
			}
		}
	}
}

