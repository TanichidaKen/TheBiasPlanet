namespace theBiasPlanet {
	namespace coreUtilities {
		namespace constantsGroups {
			using System;
			
			public static class DefaultValuesConstantsGroup {
					public const Int32 c_smallBufferSize = 1024;
					public const Int32 c_largeBufferSize = 102400;
					public const Int32 c_smallestBufferSize = 1;
			}
		}
	}
}

