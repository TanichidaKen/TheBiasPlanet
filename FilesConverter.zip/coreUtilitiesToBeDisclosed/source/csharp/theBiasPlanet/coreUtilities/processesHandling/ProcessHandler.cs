namespace theBiasPlanet {
	namespace coreUtilities {
		namespace processesHandling {
			using System;
			using System.Collections.Generic;
			using System.Diagnostics;
			using System.IO;
			using System.Text;
			using System.Threading;
			using theBiasPlanet.coreUtilities.constantsGroups;
			using theBiasPlanet.coreUtilities.stringsHandling;
			
			public class ProcessHandler {
				public class StandardInputAndOutputs {
					private Process i_processBuilder = null;
					private StreamWriter i_standardInputOutputStream = null;
					private StreamReader i_standardOutputInputStream = null;
					private StreamReader i_standardErrorOutputInputStream = null;
					private Thread i_relayStandardInputSubThread = null;
					private Thread i_printStandardOutputSubThread = null;
					private Thread i_printStandardErrorOutputSubThread = null;
					private bool i_thereWereStandardInputContents = false;
					private bool i_thereWereStandardOutputContents = false;
					private bool i_thereWereStandardErrorOutputContents = false;
					
					public StandardInputAndOutputs (Process a_processBuilder) {
						i_processBuilder = a_processBuilder;
						i_standardInputOutputStream = i_processBuilder.StandardInput;
						i_standardOutputInputStream = i_processBuilder.StandardOutput;
						i_standardErrorOutputInputStream = i_processBuilder.StandardError;
					}
					
					public StreamWriter getStandardInputOutputStream () {
						return i_standardInputOutputStream;
					}
					
					public StreamReader getStandardOutputInputStream () {
						return i_standardOutputInputStream;
					}
					
					public StreamReader getStandardErrorOutputInputStream () {
						return i_standardErrorOutputInputStream;
					}
					
					public void relayStandardInputAsynchronously () {
						i_relayStandardInputSubThread = new Thread (() => {
							try {
								StreamWriter l_processStandardInputWriter = i_standardInputOutputStream;
								TextReader l_standardInputReader = Console.In;
								char [] l_standardInputData = new char [DefaultValuesConstantsGroup.c_smallBufferSize];
								int l_standardInputDataLength = 0;
								while ((l_standardInputDataLength = l_standardInputReader.Read (l_standardInputData, GeneralConstantsConstantsGroup.c_iterationStartingNumber, DefaultValuesConstantsGroup.c_smallBufferSize)) != 0) {
									for (int l_characterIndex = 0; l_characterIndex < l_standardInputDataLength; l_characterIndex ++) {
										i_thereWereStandardInputContents = true;
										l_processStandardInputWriter.Write (l_standardInputData [l_characterIndex]);
										l_processStandardInputWriter.Flush ();
									}
								}
							}
							catch (ThreadAbortException l_exception) {
							}
							catch (IOException l_exception) {
								Console.Error.WriteLine (String.Format ("### A standard input error: {0}.", l_exception));
							}
							Console.Error.Flush ();
						});
						i_relayStandardInputSubThread.Start ();
					}
					
					public void printStandardOutputAsynchronously () {
						i_printStandardOutputSubThread = new Thread (() => {
							try {
								StreamReader l_standardOutputReader = i_standardOutputInputStream;
								char [] l_standardOutputData = new char [DefaultValuesConstantsGroup.c_smallBufferSize];
								int l_standardOutputDataLength = 0;
								while ((l_standardOutputDataLength = l_standardOutputReader.Read (l_standardOutputData, GeneralConstantsConstantsGroup.c_iterationStartingNumber, DefaultValuesConstantsGroup.c_smallBufferSize)) != 0) {
									for (int l_characterIndex = 0; l_characterIndex < l_standardOutputDataLength; l_characterIndex ++) {
										i_thereWereStandardOutputContents = true;
										Console.Out.Write (l_standardOutputData [l_characterIndex]);
										Console.Out.Flush ();
									}
								}
							}
							catch (IOException l_exception) {
								Console.Error.WriteLine (String.Format ("### A child process standard output error: {0}.", l_exception));
							}
							Console.Out.Flush ();
						});
						i_printStandardOutputSubThread.Start ();
					}
					
					public void printStandardErrorOutputAsynchronously () {
						i_printStandardErrorOutputSubThread = new Thread (() => {
							try {
								StreamReader l_standardErrorOutputReader = i_standardErrorOutputInputStream;
								char [] l_standardErrorOutputData = new char [DefaultValuesConstantsGroup.c_smallBufferSize];
								int l_standardErrorOutputDataLength = 0;
								while ((l_standardErrorOutputDataLength = l_standardErrorOutputReader.Read (l_standardErrorOutputData, GeneralConstantsConstantsGroup.c_iterationStartingNumber, DefaultValuesConstantsGroup.c_smallBufferSize)) != 0) {
									for (int l_characterIndex = 0; l_characterIndex < l_standardErrorOutputDataLength; l_characterIndex ++) {
										i_thereWereStandardErrorOutputContents = true;
										Console.Out.Write (l_standardErrorOutputData [l_characterIndex]);
										Console.Out.Flush ();
									}
								}
							}
							catch (IOException l_exception) {
								Console.Error.WriteLine (String.Format ("### A child process standard error output error: {0}.", l_exception));
							}
							Console.Out.Flush ();
						});
						i_printStandardErrorOutputSubThread.Start ();
					}
					
					public String getStandardOutputNextLine () {
						try {
							if (!(i_standardOutputInputStream.EndOfStream)) {
								i_thereWereStandardOutputContents = true;
								return i_standardOutputInputStream.ReadLine ();
							}
							else {
								i_standardOutputInputStream.Close ();
								return null;
							}
						}
						catch (Exception l_exception) {
							Console.Error.WriteLine ("The standard output couldn't be scanned.");
							i_standardOutputInputStream.Close ();
							return null;
						}
					}
					
					public String getStandardErrorOutputNextLine () {
						try {
							if (!(i_standardErrorOutputInputStream.EndOfStream)) {
								i_thereWereStandardErrorOutputContents = true;
								return i_standardErrorOutputInputStream.ReadLine ();
							}
							else {
								i_standardErrorOutputInputStream.Close ();
								return null;
							}
						}
						catch (Exception l_exception) {
							Console.Error.WriteLine ("The standard error output couldn't be scanned.");
							i_standardErrorOutputInputStream.Close ();
							return null;
						}
					}
					
					public bool thereWereStandardInputContents () {
						return i_thereWereStandardInputContents;
					}
					
					public bool thereWereStandardOutputContents () {
						return i_thereWereStandardOutputContents;
					}
					
					public bool thereWereStandardErrorOutputContents () {
						return i_thereWereStandardErrorOutputContents;
					}
					
					public int waitUntillFinish () {
						if (i_printStandardErrorOutputSubThread != null) {
							i_printStandardErrorOutputSubThread.Join ();
						}
						if (i_printStandardOutputSubThread != null) {
							i_printStandardOutputSubThread.Join ();
						}
						i_processBuilder.WaitForExit ();
						int l_processReturn = i_processBuilder.ExitCode;
						if (i_relayStandardInputSubThread != null) {
							i_relayStandardInputSubThread.Abort ();
						}
						return l_processReturn;
					}
				}
				
				public static int execute (String a_workingDirectoryPath, List <String> a_commandAndArguments, bool a_waitsUntilFinish) {
					Process l_processBuilder = new Process ();
					l_processBuilder.StartInfo.UseShellExecute = false;
					l_processBuilder.StartInfo.FileName = a_commandAndArguments [GeneralConstantsConstantsGroup.c_iterationStartingNumber];
					l_processBuilder.StartInfo.CreateNoWindow = true;
					bool l_elementIsCommand = true;
					bool l_elementIsFirstArgument = false;
					StringBuilder l_argumentsStringBuilder = new StringBuilder ();
					foreach (String l_commandOrArgument in a_commandAndArguments) {
						if (l_elementIsCommand) {
							l_elementIsCommand = false;
							l_elementIsFirstArgument = true;
						}
						else {
							if (l_elementIsFirstArgument) {
								l_elementIsFirstArgument = false;
							}
							else {
								l_argumentsStringBuilder.Append (" ");
							}
							l_argumentsStringBuilder.Append (StringHandler.getEscapedArgument (l_commandOrArgument));
						}
					}
					l_processBuilder.StartInfo.Arguments = l_argumentsStringBuilder.ToString ();
					l_processBuilder.StartInfo.RedirectStandardInput = true;
					l_processBuilder.StartInfo.RedirectStandardOutput = true;
					l_processBuilder.StartInfo.RedirectStandardError = true;
					if (a_workingDirectoryPath != null) {
						l_processBuilder.StartInfo.WorkingDirectory = a_workingDirectoryPath;
					}
					l_processBuilder.Start ();
					Thread l_printChildProcessStandardOutputSubThread = new Thread (() => {
						try {
							StreamReader l_childProcessStandardOutputReader = l_processBuilder.StandardOutput;
							char [] l_childProcessStandardOutputData = new char [DefaultValuesConstantsGroup.c_smallBufferSize];
							int l_childProcessStandardOutputDataLength = 0;
							while ((l_childProcessStandardOutputDataLength = l_childProcessStandardOutputReader.Read (l_childProcessStandardOutputData, GeneralConstantsConstantsGroup.c_iterationStartingNumber, DefaultValuesConstantsGroup.c_smallBufferSize)) != 0) {
								for (int l_characterIndex = 0; l_characterIndex < l_childProcessStandardOutputDataLength; l_characterIndex ++) {
									Console.Out.Write (l_childProcessStandardOutputData [l_characterIndex]);
									Console.Out.Flush ();
								}
							}
						}
						catch (IOException l_exception) {
							Console.Error.WriteLine (String.Format ("### A child process standard output error: {0}.", l_exception));
						}
						Console.Out.Flush ();
					});
					l_printChildProcessStandardOutputSubThread.Start ();
					Thread l_printChildProcessStandardErrorOutputSubThread = new Thread (() => {
						try {
							StreamReader l_childProcessStandardErrorOutputReader = l_processBuilder.StandardError;
							char [] l_childProcessStandardErrorOutputData = new char [DefaultValuesConstantsGroup.c_smallBufferSize];
							int l_childProcessStandardErrorOutputDataLength = 0;
							while ((l_childProcessStandardErrorOutputDataLength = l_childProcessStandardErrorOutputReader.Read (l_childProcessStandardErrorOutputData, GeneralConstantsConstantsGroup.c_iterationStartingNumber, DefaultValuesConstantsGroup.c_smallBufferSize)) != 0) {
								for (int l_characterIndex = 0; l_characterIndex < l_childProcessStandardErrorOutputDataLength; l_characterIndex ++) {
									Console.Out.Write (l_childProcessStandardErrorOutputData [l_characterIndex]);
									Console.Out.Flush ();
								}
							}
						}
						catch (IOException l_exception) {
							Console.Error.WriteLine (String.Format ("### A child process standard error output error: {0}.", l_exception));
						}
						Console.Out.Flush ();
					});
					l_printChildProcessStandardErrorOutputSubThread.Start ();
					Thread l_relayStandardInputSubThread = new Thread (() => {
						try {
							StreamWriter l_childProcessStandardInputWriter = l_processBuilder.StandardInput;
							TextReader l_standardInputReader = Console.In;
							char [] l_standardInputData = new char [DefaultValuesConstantsGroup.c_smallBufferSize];
							int l_standardInputDataLength = 0;
							while ((l_standardInputDataLength = l_standardInputReader.Read (l_standardInputData, GeneralConstantsConstantsGroup.c_iterationStartingNumber, DefaultValuesConstantsGroup.c_smallBufferSize)) != 0) {
								for (int l_characterIndex = 0; l_characterIndex < l_standardInputDataLength; l_characterIndex ++) {
									l_childProcessStandardInputWriter.Write (l_standardInputData [l_characterIndex]);
									l_childProcessStandardInputWriter.Flush ();
								}
							}
						}
						catch (ThreadAbortException l_exception) {
						}
						catch (IOException l_exception) {
							Console.Error.WriteLine (String.Format ("### A standard input error: {0}.", l_exception));
						}
						Console.Error.Flush ();
					});
					l_relayStandardInputSubThread.Start ();
					int l_childProcessReturn = 0;
					if (a_waitsUntilFinish) {
						l_printChildProcessStandardErrorOutputSubThread.Join ();
						l_printChildProcessStandardOutputSubThread.Join ();
						l_processBuilder.WaitForExit ();
						l_childProcessReturn = l_processBuilder.ExitCode;
						l_relayStandardInputSubThread.Abort ();
					}
					return l_childProcessReturn;
				}
				
				public static StandardInputAndOutputs executeAndReturnStandardInputAndOutputs (String a_workingDirectoryPath, List <String> a_commandAndArguments) {
					Process l_processBuilder = new Process ();
					l_processBuilder.StartInfo.UseShellExecute = false;
					l_processBuilder.StartInfo.FileName = a_commandAndArguments [GeneralConstantsConstantsGroup.c_iterationStartingNumber];
					l_processBuilder.StartInfo.CreateNoWindow = true;
					bool l_elementIsCommand = true;
					bool l_elementIsFirstArgument = false;
					StringBuilder l_argumentsStringBuilder = new StringBuilder ();
					foreach (String l_commandOrArgument in a_commandAndArguments) {
						if (l_elementIsCommand) {
							l_elementIsCommand = false;
							l_elementIsFirstArgument = true;
						}
						else {
							if (l_elementIsFirstArgument) {
								l_elementIsFirstArgument = false;
							}
							else {
								l_argumentsStringBuilder.Append (" ");
							}
							l_argumentsStringBuilder.Append (StringHandler.getEscapedArgument (l_commandOrArgument));
						}
					}
					l_processBuilder.StartInfo.Arguments = l_argumentsStringBuilder.ToString ();
					l_processBuilder.StartInfo.RedirectStandardInput = true;
					l_processBuilder.StartInfo.RedirectStandardOutput = true;
					l_processBuilder.StartInfo.RedirectStandardError = true;
					/*
					l_processBuilder.OutputDataReceived += (sender, args) => Console.Out.WriteLine("received output: {0}", args.Data);
					l_processBuilder.ErrorDataReceived += (sender, args) => Console.Out.WriteLine("received output: {0}", args.Data);
					*/
					if (a_workingDirectoryPath != null) {
						l_processBuilder.StartInfo.WorkingDirectory = a_workingDirectoryPath;
					}

					l_processBuilder.Start ();
					/*
					l_processBuilder.BeginOutputReadLine ();
					l_processBuilder.BeginErrorReadLine ();
					*/
					/*
					l_processBuilder.WaitForExit ();
					l_processBuilder.CancelOutputRead ();
					*/
					return new StandardInputAndOutputs (l_processBuilder);
				}
			}
		}
	}
}

