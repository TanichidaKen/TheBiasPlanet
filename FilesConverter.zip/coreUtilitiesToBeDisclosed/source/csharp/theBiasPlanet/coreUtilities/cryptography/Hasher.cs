namespace theBiasPlanet {
	namespace coreUtilities {
		namespace cryptography {
			using System;
			using System.Security.Cryptography;
			
			public sealed class Hasher {
				private static RNGCryptoServiceProvider s_randomNumberGenerator = new RNGCryptoServiceProvider ();
				
				public static byte [] createSalt (int a_numberOfBytes) {
					byte[] l_saltArray = new byte [a_numberOfBytes];
					s_randomNumberGenerator.GetBytes (l_saltArray);
					return l_saltArray;
				}
				
				public static byte [] hashInPbkdf2 (String a_originalDatum, byte [] a_saltArray, int a_numberOfIteration, int a_keyLength) {
					Rfc2898DeriveBytes l_pbkdf2SecretKeyGenerator = new Rfc2898DeriveBytes (a_originalDatum, a_saltArray, a_numberOfIteration);
					return l_pbkdf2SecretKeyGenerator.GetBytes (a_keyLength);
				}
			}
		}
	}
}

