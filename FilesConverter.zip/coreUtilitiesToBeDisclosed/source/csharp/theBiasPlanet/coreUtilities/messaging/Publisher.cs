namespace theBiasPlanet {
	namespace coreUtilities {
		namespace messaging {
			using System;
			using System.Diagnostics;
			using System.IO;
			using System.Reflection;
			using System.Text;
			using System.Threading;
			using System.Windows.Forms;
			
			public sealed class Publisher {
				private static readonly int c_processIdentification = Process.GetCurrentProcess ().Id;
				// 0: error, 1: error and warning, 2: error, warning, and normal, 3: error, warning, normal, and debug
				private static int s_loggingLevel = 0;
	
				private Publisher () {
				}
	
				public static int getLoggingLevel () {
					return s_loggingLevel;
				}
	
				public static void setLoggingLevel (int a_loggingLevel) {
					s_loggingLevel = a_loggingLevel;
				}
				
				public static String getMessage (String a_messageIngredient) {
					StringBuilder l_messageBuilder = new StringBuilder ("");
					StackTrace l_stackTrace = new StackTrace (false);
					StackFrame l_previousMethodStackTraceElement = null;
					bool l_pointsThisClass = false;
					foreach (StackFrame l_stackTraceElement in l_stackTrace.GetFrames ()) {
						if (l_stackTraceElement.GetMethod ().ReflectedType.Name.Equals (typeof (Publisher).Name)) {
							l_pointsThisClass = true;
						}
						else {
							if (l_pointsThisClass) {
								l_previousMethodStackTraceElement = l_stackTraceElement;
								break;
							}
						}
					}
					MethodBase l_callingMethod = l_previousMethodStackTraceElement.GetMethod ();
					l_messageBuilder.Append ("virtual machine name: ");
					l_messageBuilder.Append (c_processIdentification);
					l_messageBuilder.Append (", class name: ");
					l_messageBuilder.Append (l_callingMethod.ReflectedType.Name);
					l_messageBuilder.Append (", method name: ");
					l_messageBuilder.Append (l_callingMethod.Name);
					l_messageBuilder.Append (", thread id: ");
					l_messageBuilder.Append (Thread.CurrentThread.ManagedThreadId);
					l_messageBuilder.Append (", ");
					l_messageBuilder.Append (a_messageIngredient);
					return l_messageBuilder.ToString ();
				}
			
				public static String show (String a_messageIngredient) {
					String l_message = null;
					l_message = getMessage (a_messageIngredient);
					MessageBox.Show (null, l_message, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
					return l_message;
				}
				
				public static String logDebugInformation (String a_messageIngredient) {
					if (s_loggingLevel >= 3) {
						String l_message = getMessage (a_messageIngredient);
						Console.Out.WriteLine ("Debug  : " + l_message);
						return l_message;
					}
					else {
						return null;
					}
				}
				
				public static String logNormalInformation (String a_messageIngredient) {
					if (s_loggingLevel >= 2) {
						String l_message = getMessage (a_messageIngredient);
						Console.Out.WriteLine ("Normal : " + l_message);
						return l_message;
					}
					else {
						return null;
					}
				}
				
				public static String logWarningInformation (String a_messageIngredient) {
					if (s_loggingLevel >= 1) {
						String l_message = getMessage (a_messageIngredient);
						Console.Out.WriteLine ("Warning: " + l_message);
						return l_message;
					}
					else {
						return null;
					}
				}
				
				public static String logWarningInformation (Exception a_messageException) {
					if (s_loggingLevel >= 1) {
						return logWarningInformation (String.Format ("{0}: {1}",a_messageException.ToString (), a_messageException.StackTrace));
					}
					else {
						return null;
					}
				}
				
				public static String logErrorInformation (String a_messageIngredient) {
					if (s_loggingLevel >= 0) {
						String l_message = getMessage (a_messageIngredient);
						Console.Out.WriteLine ("Error  : " + l_message);
						return l_message;
					}
					else {
						return null;
					}
				}
				
				public static String logErrorInformation (Exception a_messageException) {
					if (s_loggingLevel >= 0) {
						return logErrorInformation (String.Format ("{0}: {1}",a_messageException.ToString (), a_messageException.StackTrace));
					}
					else {
						return null;
					}
				}
				
				public static void appendToFile (String a_fileName, String a_contents) {
					try {
						if (!File.Exists (a_fileName)) {
							File.Create (a_fileName);
						}
						StreamWriter l_streamWriter = File.AppendText (a_fileName);
						l_streamWriter.WriteLine (a_contents);
					}
					catch (IOException l_exception) {
						show (l_exception.ToString ());
					}
				}
			}
		}
	}
}

