namespace theBiasPlanet {
	namespace coreUtilities {
		namespace collectionsHandling {
			using System;
			using System.Collections;
			using System.Collections.Generic;
			//using theBiasPlanet.coreUtilities.constantsGroups;
			
			public static class ListsFactory {
				public static List <T> createList <T> (params Object [] a_items) {
					List <T> l_list = new List <T> ();
					if (a_items != null) {
						foreach (Object l_item in a_items) {
							l_list.Add ( (T) l_item);
						}
					}
					return l_list;
				}
				
				public static List <T> createListExpandingItems <T> (params Object [] a_items) {
					List <T> l_list = new List <T> ();
					if (a_items != null) {
						foreach (Object l_item in a_items) {
							if (l_item is ICollection) {
								foreach (Object l_element in (ICollection) l_item) {
									l_list.Add ( (T) l_element);
								}
							}
							else {
								l_list.Add ( (T) l_item);
							}
						}
					}
					return l_list;
				}
			}
		}
	}
}

