namespace theBiasPlanet {
	namespace coreUtilities {
		namespace collectionsHandling {
			using System;
			using System.Collections;
			using theBiasPlanet.coreUtilities.constantsGroups;
			
			public static class ArraysFactory {
				public static T [] createArray <T> (ICollection a_collection) {
					int l_size = 0;
					if (a_collection != null) {
						l_size = a_collection.Count;
					}
					T [] l_array = new T [l_size];
					if (l_size != 0) {
						a_collection.CopyTo (l_array, GeneralConstantsConstantsGroup.c_iterationStartingNumber);
					}
					else {
					}
					return l_array;
				}
			}
		}
	}
}

