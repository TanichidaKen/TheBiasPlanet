namespace theBiasPlanet {
	namespace coreUtilities {
		namespace stringsHandling {
			using System;
			using System.Text;
			using System.Text.RegularExpressions;
			using theBiasPlanet.coreUtilities.constantsGroups;
			
			public class StringHandler {
				private static readonly Regex c_environmentVariableRegularExpression = new Regex ("\\$\\{(.*?)\\}");
				public static String getEscapedArgument (String a_argument) {
					StringBuilder l_escapedArgumentStringBuilder = new StringBuilder ();
					l_escapedArgumentStringBuilder.Append ("\"");
					l_escapedArgumentStringBuilder.Append (a_argument.Replace ("\\", "\\\\").Replace("\"", "\\\""));
					l_escapedArgumentStringBuilder.Append ("\"");
					return l_escapedArgumentStringBuilder.ToString ();
					
				}
				
				public static String unNullify (String a_originalString) {
					if (a_originalString != null) {
						return a_originalString;
					}
					else {
						return "";
					}
				}
				
				public static String effectuateEnvironmentVariables (String a_originalString) {
					StringBuilder l_targetStringBuilder = new StringBuilder ();
					MatchCollection l_environmentVariableMatchers = c_environmentVariableRegularExpression.Matches (a_originalString);
					int l_currentCharacterIndex = GeneralConstantsConstantsGroup.c_iterationStartingNumber;
					Group l_environmentVariableMatcherGroup0 = null; 
					foreach (Match l_environmentVariableMatcher in l_environmentVariableMatchers) {
						l_environmentVariableMatcherGroup0 = l_environmentVariableMatcher.Groups [GeneralConstantsConstantsGroup.c_iterationStartingNumber];
						l_targetStringBuilder.Append (a_originalString.Substring (l_currentCharacterIndex, l_environmentVariableMatcherGroup0.Index));
					   	l_targetStringBuilder.Append (StringHandler.unNullify (Environment.GetEnvironmentVariable (l_environmentVariableMatcher.Groups [GeneralConstantsConstantsGroup.c_iterationStartingNumber + 1].Value)));
						l_currentCharacterIndex = l_environmentVariableMatcherGroup0.Index + l_environmentVariableMatcherGroup0.Length;
					}
					l_targetStringBuilder.Append (a_originalString.Substring (l_currentCharacterIndex));
					return l_targetStringBuilder.ToString ();
				}
			}
		}
	}
}

