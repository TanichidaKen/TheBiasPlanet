namespace theBiasPlanet {
	namespace coreUtilities {
		namespace stringsHandling {
			using System;
			using System.Text;
			
			public class StringHandler {
				public static String getEscapedArgument (String a_argument) {
					StringBuilder l_escapedArgumentStringBuilder = new StringBuilder ();
					l_escapedArgumentStringBuilder.Append ("\"");
					l_escapedArgumentStringBuilder.Append (a_argument.Replace ("\\", "\\\\").Replace("\"", "\\\""));
					l_escapedArgumentStringBuilder.Append ("\"");
					return l_escapedArgumentStringBuilder.ToString ();
					
				}
			}
		}
	}
}

