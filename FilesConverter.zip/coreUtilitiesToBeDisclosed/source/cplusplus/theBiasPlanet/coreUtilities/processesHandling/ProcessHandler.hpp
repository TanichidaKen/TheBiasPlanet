#ifndef __theBiasPlanet_coreUtilities_processesHandling_ProcessHandler_hpp__
	#define __theBiasPlanet_coreUtilities_processesHandling_ProcessHandler_hpp__
#ifdef GCC
	#include <iostream>
	#include <list>
	#include <optional>
	#include <string>
	#include <thread>
	#include <ext/stdio_filebuf.h>
	#include "theBiasPlanet/coreUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	using namespace ::__gnu_cxx;
	
	namespace theBiasPlanet {
		namespace coreUtilities {
			namespace processesHandling {
				class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ ProcessHandler {
					public:
						class StandardInputAndOutputs {
							private:
								pid_t i_processIdentification;
								bool i_processIsInterrupted;
								stdio_filebuf <char> i_childProcessStandardInputBuffer;
								ostream i_standardInputOutputStream;
								stdio_filebuf <char> i_childProcessStandardOutputBuffer;
								istream i_standardOutputInputStream;
								stdio_filebuf <char> i_childProcessStandardErrorOutputBuffer;
								istream i_standardErrorOutputInputStream;
								thread i_relayStandardInputSubThread;
								thread i_printStandardOutputSubThread;
								thread i_printStandardErrorOutputSubThread;
								bool i_thereWereStandardInputContents;
								bool i_thereWereStandardOutputContents;
								bool i_thereWereStandardErrorOutputContents;
								static int const c_standardInputPollingIntervalInMilliSeconds;
							public:
								StandardInputAndOutputs (pid_t a_processIdentification, int const & a_standardInputOutputFileDescription, int const & a_standardOutputInputFileDescription, int const & a_standardErrorOutputInputFileDescription);
								ostream * getStandardInputOutputStream ();
								istream * getStandardOutputInputStream ();
								istream * getStandardErrorOutputInputStream ();
								void relayStandardInputAsynchronously ();
								void printStandardOutputAsynchronously ();
								void printStandardErrorOutputAsynchronously ();
								optional <string> getStandardOutputNextLine ();
								optional <string> getStandardErrorOutputNextLine ();
								bool thereWereStandardInputContents ();
								bool thereWereStandardOutputContents ();
								bool thereWereStandardErrorOutputContents ();
								int waitUntillFinish ();
						};
						static int execute (string const & a_workingDirectoryPath, list <string> const & a_commandAndArguments, bool const & a_waitsUntilFinish);
						static StandardInputAndOutputs executeAndReturnStandardInputAndOutputs (string const & a_workingDirectoryPath, list <string> const & a_commandAndArguments);
				};
			}
		}
	}
#else
#endif
#endif

