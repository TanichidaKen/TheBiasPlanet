#include "theBiasPlanet/coreUtilities/locksHandling/Locker.hpp"

namespace theBiasPlanet {
	namespace coreUtilities {
		namespace locksHandling {
			Locker::Locker (mutex * a_mutex) : i_mutex (a_mutex) {
				i_mutex->lock ();
			}
			
			Locker::~Locker () {
				i_mutex->unlock ();
			}
		}
	}
}

