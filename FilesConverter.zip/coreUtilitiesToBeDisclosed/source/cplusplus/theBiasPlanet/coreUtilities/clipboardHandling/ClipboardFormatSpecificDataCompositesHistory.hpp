#ifndef __theBiasPlanet_coreUtilities_clipboardHandling_ClipboardFormatSpecificDataCompositesHistory_hpp__
	#define __theBiasPlanet_coreUtilities_clipboardHandling_ClipboardFormatSpecificDataCompositesHistory_hpp__
	
	#include "theBiasPlanet/coreUtilities/clipboardHandling/ClipboardFormatSpecificDataComposite.hpp"
	#include "theBiasPlanet/coreUtilities/collections/NavigableLinkedMap.hpp"
	#include "theBiasPlanet/coreUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::theBiasPlanet::coreUtilities::collections;
	
	namespace theBiasPlanet {
		namespace coreUtilities {
			namespace clipboardHandling {
				class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ ClipboardFormatSpecificDataCompositesHistory {
					private:
						NavigableLinkedMap <string const, ClipboardFormatSpecificDataComposite const *> i_dataCompositeKeyToDataCompositeMap;
					public:
						ClipboardFormatSpecificDataCompositesHistory ();
						virtual ~ClipboardFormatSpecificDataCompositesHistory ();
						ClipboardFormatSpecificDataCompositesHistory (ClipboardFormatSpecificDataCompositesHistory const & a_copiedObject) = delete; // because the data are not meant to be shared by multiple instances
						virtual ClipboardFormatSpecificDataCompositesHistory & operator = (ClipboardFormatSpecificDataCompositesHistory const & a_assignedFromObject) = delete; // because the data are not meant to be shared by multiple instances
						virtual bool addDataComposite (string const & a_dataCompositeKey, ClipboardFormatSpecificDataComposite const * const a_dataComposite);
						virtual bool removeDataComposite (string const & a_dataCompositeKey);
						virtual ClipboardFormatSpecificDataComposite const * const getDataComposite (string const & a_dataCompositeKey);
				};
			}
		}
	}
#endif

