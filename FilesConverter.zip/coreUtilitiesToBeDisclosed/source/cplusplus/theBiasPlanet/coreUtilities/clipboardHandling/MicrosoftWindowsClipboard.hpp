#ifndef GCC
	#ifndef __theBiasPlanet_coreUtilities_clipboardHandling_MicrosoftWindowsClipboard_hpp__
		#define __theBiasPlanet_coreUtilities_clipboardHandling_MicrosoftWindowsClipboard_hpp__
		
		#include "theBiasPlanet/coreUtilities/clipboardHandling/ClipboardFormatSpecificDataComposite.hpp"
		#include "theBiasPlanet/coreUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
		
		namespace theBiasPlanet {
			namespace coreUtilities {
				namespace clipboardHandling {
					class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ MicrosoftWindowsClipboard {
						private:
						public:
							static bool openClipboard ();
							static bool closeClipboard ();
							static bool clearClipboard ();
							static ClipboardFormatSpecificDataComposite * const getFormatSpecificDataComposite ();
							static bool setFormatSpecificDataComposite (ClipboardFormatSpecificDataComposite const * const a_formatSpecificDataComposite);
					};
				}
			}
		}
	#endif
#endif

