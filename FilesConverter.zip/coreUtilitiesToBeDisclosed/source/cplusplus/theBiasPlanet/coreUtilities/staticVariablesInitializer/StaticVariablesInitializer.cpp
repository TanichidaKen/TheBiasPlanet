#include "theBiasPlanet/coreUtilities/constantsGroups/DefaultValuesConstantsGroup.hpp"
#include "theBiasPlanet/coreUtilities/constantsGroups/FileNameSuffixesConstantsGroup.hpp"
#include "theBiasPlanet/coreUtilities/constantsGroups/GeneralConstantsConstantsGroup.hpp"
#include "theBiasPlanet/coreUtilities/constantsGroups/RegularExpressionsConstantsGroup.hpp"
#include "theBiasPlanet/coreUtilities/cryptography/Hasher.hpp"
#include "theBiasPlanet/coreUtilities/messaging/Publisher.hpp"
#include "theBiasPlanet/coreUtilities/performanceMeasuring/PerformanceMeasurer.hpp"
#include "theBiasPlanet/coreUtilities/processesHandling/ProcessHandler.hpp"
#ifdef GCC
	#include <sys/types.h>
	#include <unistd.h>
#else
	#include <process.h>
#endif
#include "theBiasPlanet/coreUtilities/stringsHandling/StringHandler.hpp"

using namespace ::theBiasPlanet::coreUtilities::stringsHandling;

namespace theBiasPlanet {
	namespace coreUtilities {
		namespace constantsGroups {
			int const DefaultValuesConstantsGroup::c_smallBufferSize (1024);
			int const DefaultValuesConstantsGroup::c_largeBufferSize (102400);
			int const DefaultValuesConstantsGroup::c_smallestBufferSize (1);
			string const FileNameSuffixesConstantsGroup::c_xmlFileNameSuffix ("xml");
			string const FileNameSuffixesConstantsGroup::c_styleSheetFileNameSuffix ("xslt");
			string const FileNameSuffixesConstantsGroup::c_jarFileNameSuffix ("jar");
			string const FileNameSuffixesConstantsGroup::c_javaFileNameSuffix ("java");
			string const FileNameSuffixesConstantsGroup::c_saveFileNameSuffix ("save");
			int const GeneralConstantsConstantsGroup::GeneralConstantsConstantsGroup::c_maximumBytesLengthPerUtf8Character = 4;
			int const GeneralConstantsConstantsGroup::c_numberOfAlphabets = 26;
			int const GeneralConstantsConstantsGroup::c_anyUnspecifiedInteger = -1;
			float const GeneralConstantsConstantsGroup::c_anyUnspecifiedFloat = -1.0f;
			char const GeneralConstantsConstantsGroup::c_anyUnspecifiedCharacter = (char) 0;
			int const GeneralConstantsConstantsGroup::c_iterationStartingNumber = 0;
			int const GeneralConstantsConstantsGroup::c_normalResult = 0;
			string const GeneralConstantsConstantsGroup::c_emptyString ("");
			char const GeneralConstantsConstantsGroup::c_radixPointCharacter = '.';
			char const GeneralConstantsConstantsGroup::c_thousandsDelimiter = ',';
			char const GeneralConstantsConstantsGroup::c_escapingCharacter = '\\';
			char const GeneralConstantsConstantsGroup::c_newLineCharacter = '\n';
			char const GeneralConstantsConstantsGroup::c_carriageReturnCharacter = '\r';
			char const GeneralConstantsConstantsGroup::c_tabCharacter = '\t';
			char const GeneralConstantsConstantsGroup::c_semicolonCharacter = ';';
			string const GeneralConstantsConstantsGroup::c_utfBomCharacter = "\uFEFF";
			char const GeneralConstantsConstantsGroup::c_lessThanCharacter = '<';
			char const GeneralConstantsConstantsGroup::c_greaterThanCharacter = '>';
			char const GeneralConstantsConstantsGroup::c_ampersandCharacter = '&';
			char const GeneralConstantsConstantsGroup::c_doubleQuotationMarkCharacter = '\"';
			char const GeneralConstantsConstantsGroup::c_apostropheCharacter = '\'';
			char const GeneralConstantsConstantsGroup::c_argumentsDelimiter = ' ';
			string const GeneralConstantsConstantsGroup::c_colonDelimiter = ": ";
			string const GeneralConstantsConstantsGroup::c_commaDelimiter = ", ";
			char const GeneralConstantsConstantsGroup::c_linuxDirectoriesDelimiter = '/';
			char const GeneralConstantsConstantsGroup::c_windowsDirectoriesDelimiter = '\\';
			char const GeneralConstantsConstantsGroup::c_javaPackagesDelimiter = '.';
			char const GeneralConstantsConstantsGroup::c_fileNameElementsDelimiter = '.';
			char const GeneralConstantsConstantsGroup::c_nameElementsDelimiter = '_';
			char const GeneralConstantsConstantsGroup::c_linuxPathsDelimiter = ':';
			char const GeneralConstantsConstantsGroup::c_windowsPathsDelimiter = ';';
			string const GeneralConstantsConstantsGroup::c_integerDefaultFormat = "%d";
			string const GeneralConstantsConstantsGroup::c_doubleDefaultFormat = "%f";
			string const GeneralConstantsConstantsGroup::c_booleanDefaultFormat = "%b";
			string const GeneralConstantsConstantsGroup::c_globExpressionFormat = "glob:%s";
			string const GeneralConstantsConstantsGroup::c_commandSwitchOrFlagStarter = "-";
			string const GeneralConstantsConstantsGroup::c_linuxDirectoryPathFormat = StringHandler::format (string ("%%s%s%%s"), GeneralConstantsConstantsGroup::c_linuxDirectoriesDelimiter);
			string const GeneralConstantsConstantsGroup::c_windowsDirectoryPathFormat = StringHandler::format (string ("%%s%s%%s"), GeneralConstantsConstantsGroup::c_windowsDirectoriesDelimiter);
			string const GeneralConstantsConstantsGroup::c_linuxFilePathFormat = StringHandler::format (string ("%%s%s%%s"), GeneralConstantsConstantsGroup::c_linuxDirectoriesDelimiter);
			string const GeneralConstantsConstantsGroup::c_windowsFilePathFormat = StringHandler::format (string ("%%s%s%%s"), GeneralConstantsConstantsGroup::c_windowsDirectoriesDelimiter);
			string const GeneralConstantsConstantsGroup::c_fileNameFormat = StringHandler::format (string ("%%s%s%%s"), GeneralConstantsConstantsGroup::c_fileNameElementsDelimiter);
			string const GeneralConstantsConstantsGroup::c_javaClassNameFormat = StringHandler::format (string ("%%s%s%%s"), GeneralConstantsConstantsGroup::c_javaPackagesDelimiter);
			string const GeneralConstantsConstantsGroup::c_styleSheetFileNameFormat = StringHandler::format (string ("%%s%s%s"), GeneralConstantsConstantsGroup::c_fileNameElementsDelimiter, FileNameSuffixesConstantsGroup::c_styleSheetFileNameSuffix);
			string const GeneralConstantsConstantsGroup::c_javaFileNameFormat = StringHandler::format (string ("%%s%s%s"), GeneralConstantsConstantsGroup::c_fileNameElementsDelimiter, FileNameSuffixesConstantsGroup::c_javaFileNameSuffix);
			string const GeneralConstantsConstantsGroup::c_quotedByDoubleQuotationsFormat = "\"%s\"";
			string const GeneralConstantsConstantsGroup::c_quotedByAngleBracketsFormat = "<%s>";
			string const GeneralConstantsConstantsGroup::c_definitionNameFormat = StringHandler::format ("%1$s%1$s%%s%1$s%1$s", GeneralConstantsConstantsGroup::c_nameElementsDelimiter);
			string const GeneralConstantsConstantsGroup::c_plus = "+";
			string const GeneralConstantsConstantsGroup::c_propertyValueFormat = "${%s}";
			NavigableLinkedMap <char, int> const GeneralConstantsConstantsGroup::c_alphabetToAlphabetIndexMap { {'A', 0}, {'B', 1}, {'C', 2}, {'D', 3}, {'E', 4}, {'F', 5}, {'G', 6}, {'H', 7}, {'I', 8}, {'J', 9}, {'K', 10}, {'L', 11}, {'M', 12}, {'N', 13}, {'O', 14}, {'P', 15}, {'Q', 16}, {'R', 17}, {'S', 18}, {'T', 19}, {'U', 20}, {'V', 21}, {'W', 22}, {'X', 23}, {'Y', 24}, {'Z', 25}};
			NavigableLinkedMap <int, char> const GeneralConstantsConstantsGroup::c_alphabetIndexToAlphabetMap { {0, 'A'}, {1, 'B'}, {2, 'C'}, {3, 'D'}, {4, 'E'}, {5, 'F'}, {6, 'G'}, {7, 'H'}, {8, 'I'}, {9, 'J'}, {10, 'K'}, {11, 'L'}, {12, 'M'}, {13, 'N'}, {14, 'O'}, {15, 'P'}, {16, 'Q'}, {17, 'R'}, {18, 'S'}, {19, 'T'}, {20, 'U'}, {21, 'V'}, {22, 'W'}, {23, 'X'}, {24, 'Y'}, {25, 'Z'}};
			regex const RegularExpressionsConstantsGroup::c_cProgramTraceOutputLineRegularExpression ("(#.*: )(.*)\\((.*)\\+0x(.*)\\) \\[(.*)\\] (.*)");
			regex const RegularExpressionsConstantsGroup::c_nmOutputLineRegularExpression ("(.*) (.*) (.*)");
			regex const RegularExpressionsConstantsGroup::c_addr2lineOutputSecondLineRegularExpression ("(.*):(.*)");
			regex const RegularExpressionsConstantsGroup::c_numbersRegularExpression ("^(\\d*|\\d{1,3}(,\\d{3})*)(\\.\\d+)?([eE][-+]?\\d+)?$");
			regex const RegularExpressionsConstantsGroup::c_javaPackageDelimiterRegularExpression ("\\.");
			regex const RegularExpressionsConstantsGroup::c_windowsDirectoryDelimiterRegularExpression ("\\\\");
			regex const RegularExpressionsConstantsGroup::c_wordRegularExpression ("(\\w+)");
			regex const RegularExpressionsConstantsGroup::c_termRegularExpression ("(\\S+)");
			regex const RegularExpressionsConstantsGroup::c_doubleQuotedTermRegularExpression ("\"(\\S+)\"");
		}
		namespace cryptography {
			random_device Hasher::s_seedGenerator;
			mt19937 Hasher::s_randomNumberGenerator (s_seedGenerator ());
		}
		namespace messaging  {
#ifdef GCC
			int const Publisher::c_processIdentification = getpid ();
#else
			int const Publisher::c_processIdentification = _getpid ();
#endif
			int Publisher::s_loggingLevel = 0;
		}
		namespace performanceMeasuring {
			steady_clock::time_point PerformanceMeasurer::s_startTime;
		}
		namespace processesHandling {
#ifdef GCC
			int const ProcessHandler::StandardInputAndOutputs::c_standardInputPollingIntervalInMilliSeconds = 1000;
#endif
		}
		namespace stringsHandling {
#ifdef GCC
			wstring_convert <codecvt_utf8_utf16 <char16_t>, char16_t> StringHandler::c_wstringConverter;
#else
			wstring_convert <codecvt_utf8_utf16 <wchar_t>, wchar_t> StringHandler::c_wstringConverter;
#endif
			regex const StringHandler::c_environmentVariableRegularExpression ("\\$\\{(.*?)\\}");
		}
	}
}

