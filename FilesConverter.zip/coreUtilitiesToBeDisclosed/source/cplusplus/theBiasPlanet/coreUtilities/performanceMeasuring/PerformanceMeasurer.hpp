#ifndef __theBiasPlanet_coreUtilities_performanceMeasuring_PerformanceMeasurer_hpp__
	#define __theBiasPlanet_coreUtilities_performanceMeasuring_PerformanceMeasurer_hpp__
	
	#include <chrono>
	#include "theBiasPlanet/coreUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std::chrono;
	
	namespace theBiasPlanet {
		namespace coreUtilities {
			namespace performanceMeasuring {
				class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ PerformanceMeasurer {
					private:
						static steady_clock::time_point s_startTime;
					public:
						static void setStartTime ();
						static steady_clock::rep getElapseTimeInNanoSeconds ();
						static steady_clock::rep getElapseTimeInMicroSeconds ();
				};
			}
		}
	}
#endif

