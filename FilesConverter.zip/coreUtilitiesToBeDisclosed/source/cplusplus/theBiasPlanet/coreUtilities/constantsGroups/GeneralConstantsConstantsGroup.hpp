#ifndef __theBiasPlanet_coreUtilities_constantsGroups_GeneralConstantsConstantsGroup_hpp__
	#define __theBiasPlanet_coreUtilities_constantsGroups_GeneralConstantsConstantsGroup_hpp__

	#include <string>
	#include "theBiasPlanet/coreUtilities/collections/NavigableLinkedMap.hpp"
	#include "theBiasPlanet/coreUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	using namespace ::theBiasPlanet::coreUtilities::collections;
	
	namespace theBiasPlanet {
		namespace coreUtilities {
			namespace constantsGroups {
				class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ GeneralConstantsConstantsGroup {
					public:
						static int const c_maximumBytesLengthPerUtf8Character;
						static int const c_numberOfAlphabets;
						static int const c_anyUnspecifiedInteger;
						static float const c_anyUnspecifiedFloat;
						static char const c_anyUnspecifiedCharacter;
						static int const c_iterationStartingNumber;
						static int const c_normalResult;
						static string const c_emptyString;
						static char const c_radixPointCharacter;
						static char const c_thousandsDelimiter;
						static char const c_escapingCharacter;
						static char const c_newLineCharacter;
						static char const c_carriageReturnCharacter;
						static char const c_tabCharacter;
						static char const c_semicolonCharacter;
						static string const c_utfBomCharacter;
						static char const c_lessThanCharacter;
						static char const c_greaterThanCharacter;
						static char const c_ampersandCharacter;
						static char const c_doubleQuotationMarkCharacter;
						static char const c_apostropheCharacter;
						static char const c_argumentsDelimiter;
						static string const c_colonDelimiter;
						static string const c_commaDelimiter;
						static char const c_linuxDirectoriesDelimiter;
						static char const c_windowsDirectoriesDelimiter;
						static char const c_javaPackagesDelimiter;
						static char const c_fileNameElementsDelimiter;
						static char const c_nameElementsDelimiter;
						static char const c_linuxPathsDelimiter;
						static char const c_windowsPathsDelimiter;
						static char const c_dataCommentLineStarter;
						static string const c_integerDefaultFormat;
						static string const c_doubleDefaultFormat;
						static string const c_booleanDefaultFormat;
						static string const c_globExpressionFormat;
						static string const c_commandSwitchOrFlagStarter;
						static string const c_linuxDirectoryPathFormat;
						static string const c_windowsDirectoryPathFormat;
						static string const c_linuxFilePathFormat;
						static string const c_windowsFilePathFormat;
						static string const c_fileNameFormat;
						static string const c_javaClassNameFormat;
						static string const c_styleSheetFileNameFormat;
						static string const c_javaFileNameFormat;
						static string const c_quotedByDoubleQuotationsFormat;
						static string const c_quotedByAngleBracketsFormat;
						static string const c_definitionNameFormat;
						static string const c_plus;
						static string const c_propertyValueFormat;
						static NavigableLinkedMap <char, int> const c_alphabetToAlphabetIndexMap;
						static NavigableLinkedMap <int, char> const c_alphabetIndexToAlphabetMap;
				};
			}
		}
	}
#endif

