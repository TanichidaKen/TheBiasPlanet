#ifndef __theBiasPlanet_coreUtilities_constantsGroups_EncodingNamesConstantsGroup_hpp__
	#define __theBiasPlanet_coreUtilities_constantsGroups_EncodingNamesConstantsGroup_hpp__

	#include <string>
	#include "theBiasPlanet/coreUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	
	namespace theBiasPlanet {
		namespace coreUtilities {
			namespace constantsGroups {
				class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ EncodingNamesConstantsGroup {
					public:
						static string const c_utf8EncodingName;
						static string const c_utf8InputStreamReaderReturningEncodingName;
				};
			}
		}
	}
#endif

