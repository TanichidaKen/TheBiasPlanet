#include "theBiasPlanet/coreUtilities/cryptography/Hasher.hpp"
#include <algorithm>
#include <openssl/evp.h>
#include <openssl/hmac.h>
#include <openssl/sha.h>

namespace theBiasPlanet {
	namespace coreUtilities {
		namespace cryptography {
			bool Hasher::createSalt (unsigned char * const a_saltArray, int const & a_numberOfBytes) {
				mt19937::result_type l_randomNumber;
				int l_randomNumberBytesLength = sizeof (mt19937::result_type);
				for (int l_numberOfFilledBytes = 0; l_numberOfFilledBytes < a_numberOfBytes; l_numberOfFilledBytes += l_randomNumberBytesLength) {
					l_randomNumber = s_randomNumberGenerator ();
					copy (static_cast <unsigned char const *> (static_cast <void const *> (&l_randomNumber)), static_cast <unsigned char const *> (static_cast <void const *> (&l_randomNumber)) + min (a_numberOfBytes - l_numberOfFilledBytes, l_randomNumberBytesLength), a_saltArray + l_numberOfFilledBytes);
				}
				return true;
			}
			
			bool Hasher::hashInPbkdf2 (unsigned char * const a_hashArray, string const & a_originalDatum, unsigned char const * const a_saltArray, int const & a_saltLength, int const & a_numberOfIteration, int const & a_keyLength) {
				return PKCS5_PBKDF2_HMAC_SHA1 (a_originalDatum.c_str (), a_originalDatum.length (), a_saltArray, a_saltLength, a_numberOfIteration, a_keyLength, a_hashArray) != 0 ? true: false;
			}
		}
	}
}

