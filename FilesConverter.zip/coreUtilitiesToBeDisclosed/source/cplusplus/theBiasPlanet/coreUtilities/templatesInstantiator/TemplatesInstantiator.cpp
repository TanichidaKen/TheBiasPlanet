#include <iostream>
#include <regex>
#include <string>
#ifdef __theBiasPlanet_coreUtilities__
	#include "theBiasPlanet/coreUtilities/collectionsHandling/ArraysFactory.tpp"
	#include "theBiasPlanet/coreUtilities/collectionsHandling/ListsFactory.tpp"
	#include "theBiasPlanet/coreUtilities/stringsHandling/StringHandler.tpp"
	#include "theBiasPlanet/coreUtilities/collections/NavigableLinkedMap.tpp"
	#include "theBiasPlanet/coreUtilities/constantsGroups/BaseEnumerableConstantsGroup.tpp"
#else
	#include "theBiasPlanet/coreUtilities/collectionsHandling/ArraysFactory.hpp"
	#include "theBiasPlanet/coreUtilities/collectionsHandling/ListsFactory.hpp"
	#include "theBiasPlanet/coreUtilities/stringsHandling/StringHandler.hpp"
	#include "theBiasPlanet/coreUtilities/collections/NavigableLinkedMap.hpp"
	#include "theBiasPlanet/coreUtilities/constantsGroups/BaseEnumerableConstantsGroup.hpp"
#endif
#include "theBiasPlanet/coreUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"

using namespace ::std;
using namespace ::theBiasPlanet::coreUtilities::collections;
using namespace ::theBiasPlanet::coreUtilities::collectionsHandling;
using namespace ::theBiasPlanet::coreUtilities::constantsGroups;
using namespace ::theBiasPlanet::coreUtilities::stringsHandling;

template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ string * ArraysFactory::createArray <string> (string * a_targetArray, list <string> const & a_list);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ list <string> ListsFactory::createList <string> (string const & a_currentElement);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ list <string> ListsFactory::createList <string, string> (string const & a_currentElement, string const & a_remainingElement0);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ list <string> ListsFactory::createList <string, string, string, string, string> (string const & a_currentElement, string const & a_remainingElement0, string const & a_remainingElement1, string const & a_remainingElement2, string const & a_remainingElement3);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ ostringstream * StringHandler::format <int, double, string> (ostringstream * const a_resultStream, istringstream * const a_formatStream, int const & a_currentItem, double const & a_remainderItem0, string const & a_remainderItem1);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ ostringstream * StringHandler::format <string> (ostringstream * const a_resultStream, istringstream * const a_formatStream, string const & a_currentItem);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ string StringHandler::format <string> (string const & a_formatString, string const & a_currentItem);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ string StringHandler::format <char> (string const & a_formatString, char const & a_currentItem);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ string StringHandler::format <short> (string const & a_formatString, short const & a_currentItem);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ string StringHandler::format <char, string> (string const & a_formatString, char const & a_currentItem, string const & a_remainderItem0);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ string StringHandler::format <string, int, string> (string const & a_formatString, string const & a_currentItem, int const & a_remainderItem0, string const & a_remainderItem1);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ string StringHandler::format <string, string, string, string, string, string, string> (string const & a_formatString, string const & a_currentItem, string const & a_remainderItem0, string const & a_remainderItem1, string const & a_remainderItem2, string const & a_remainderItem3, string const & a_remainderItem4, string const & a_remainderItem5);
template class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ NavigableLinkedMap <string, int>;
template class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ NavigableLinkedMap <string, string>;
template class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ NavigableLinkedMap <char, int>;
template class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ NavigableLinkedMap <int, char>;
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ pair <NavigableLinkedMap <string, int>::iterator, bool> NavigableLinkedMap <string, int>::emplace <string, int> (string && a_argument0, int && a_argument1);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ NavigableLinkedMap <string, int>::iterator NavigableLinkedMap <string, int>::emplace_hint <string, int> (NavigableLinkedMap <string, int>::const_iterator a_position, string && a_argument0, int && a_argument1);
template __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ NavigableLinkedMap <string, int>::NavigableLinkedMap (NavigableLinkedMap <string, int>::iterator a_iteratorPointedAtFirstElement, NavigableLinkedMap <string, int>::iterator a_iteratorPointedAtLastElementNotIncluded, NavigableLinkedMap <string, int>::key_compare const & a_keysComparer);
template class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ BaseEnumerableConstantsGroup <string>;

/*
namespace theBiasPlanet {
	namespace coreUtilities {
		namespace templatesInstantiator {
			void  TemplatesInstantiator::instantiateTemplates () {
				//string l_stringsArray [2];
				//ArraysFactory::createArray (l_stringsArray ,ListsFactory::createList (string (""), string ("")));
				//ListsFactory::createList (string (""));
				//ListsFactory::createList (string (""), string (""));
				//ostringstream l_resultStream;
				//istringstream l_formatStream;
				//StringHandler::format (&l_resultStream, &l_formatStream, 0, 0.0, string (""));
				//StringHandler::format (&l_resultStream, &l_formatStream, string (""));
				//StringHandler::format (string (""), string (""));
				//StringHandler::format (string (""), 'A');
				//StringHandler::format (string (""), 'A', string (""));
				//string l_string ("");
				//NavigableLinkedMap <string, int> l_navigableLinkedMap11;
				// NavigableLinkedMap <string, int> l_navigableLinkedMap12 (l_navigableLinkedMap11.begin (), l_navigableLinkedMap11.end ());
				//NavigableLinkedMap <string, int> l_navigableLinkedMap13 ( { {string ("aaa"), 1}, {string ("bbb"), 2}, {string ("ccc"), 3}, {string ("ddd"), 4}});
				//NavigableLinkedMap <string, int> l_navigableLinkedMap14 (l_navigableLinkedMap11);
				//l_navigableLinkedMap14.emplace (string ("bbb"), 2);
				//l_navigableLinkedMap14.emplace_hint (l_navigableLinkedMap14.begin (), string ("bbb"), 2);
				//l_navigableLinkedMap14.value_comp () (NavigableLinkedMap <string, int>::value_type (string ("ccc"), 3), NavigableLinkedMap <string, int>::value_type (string ("bbb"), 2));
				//NavigableLinkedMap <string, string> l_navigableLinkedMap21;
				//NavigableLinkedMap <string, string> l_navigableLinkedMap22 ( { {string ("aaa"), string ("bbb")}});
				//NavigableLinkedMap <string, string> l_navigableLinkedMap23 ( { {string ("aaa"), string ("bbb")}, {string ("ccc"), string ("ddd")}, {string ("eee"), string ("fff")}, {string ("ggg"), string ("hhh")}});
				//NavigableLinkedMap <string, string> l_navigableLinkedMap24 (l_navigableLinkedMap21);
				//NavigableLinkedMap <char, int> l_navigableLinkedMap31 { {'A', 0}, {'B', 1}, {'C', 2}, {'D', 3}, {'E', 4}, {'F', 5}, {'G', 6}, {'H', 7}, {'I', 8}, {'J', 9}, {'K', 10}, {'L', 11}, {'M', 12}, {'N', 13}, {'O', 14}, {'P', 15}, {'Q', 16}, {'R', 17}, {'S', 18}, {'T', 19}, {'U', 20}, {'V', 21}, {'W', 22}, {'X', 23}, {'Y', 24}, {'Z', 25}};
				//NavigableLinkedMap <int, char> l_navigableLinkedMap41 { {0, 'A'}, {1, 'B'}, {2, 'C'}, {3, 'D'}, {4, 'E'}, {5, 'F'}, {6, 'G'}, {7, 'H'}, {8, 'I'}, {9, 'J'}, {10, 'K'}, {11, 'L'}, {12, 'M'}, {13, 'N'}, {14, 'O'}, {15, 'P'}, {16, 'Q'}, {17, 'R'}, {18, 'S'}, {19, 'T'}, {20, 'U'}, {21, 'V'}, {22, 'W'}, {23, 'X'}, {24, 'Y'}, {25, 'Z'}};
				//NavigableLinkedMap <string, int>::iterator l_navigableLinkedMap11Iterator = l_navigableLinkedMap11.begin ();
				//NavigableLinkedMap <string, string>::iterator l_navigableLinkedMap21Iterator = l_navigableLinkedMap21.begin ();
				//BaseEnumerableConstantsGroup <string> l_baseEnumerableConstantsGroup1 (NavigableLinkedMap <string, string> {});
				//BaseEnumerableConstantsGroup <string> l_baseEnumerableConstantsGroup2 { { {string ("aaa"), string ("bbb")}, {string ("ccc"), string ("ddd")}}};
				//l_baseEnumerableConstantsGroup1.getNames (); 
				//l_baseEnumerableConstantsGroup1.getValues (); 
			}
		}
	}
}
*/

