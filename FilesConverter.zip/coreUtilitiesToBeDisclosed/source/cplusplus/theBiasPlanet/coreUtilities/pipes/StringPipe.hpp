#ifndef __theBiasPlanet_coreUtilities_pipes_StringPipe_hpp__
	#define __theBiasPlanet_coreUtilities_pipes_StringPipe_hpp__
	
	#include <iostream>
	#include <string>
	#include "theBiasPlanet/coreUtilities/pipes/ObjectsPipe.hpp"
	#include "theBiasPlanet/coreUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	
	namespace theBiasPlanet {
		namespace coreUtilities {
			namespace pipes {
				class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ StringPipe: public ObjectsPipe <char> {
					public:
						StringPipe (int const & a_bufferSize, bool const & a_notificationIsDelayed);
						virtual ~StringPipe ();
						virtual void writeWholeString (istream * a_reader);
						virtual string readString (int a_maximumLength, long a_timeOutPeriodInMilliseconds = -1);
						virtual string readStringLine (int a_maximumLength, long a_timeOutPeriodInMilliseconds = -1);
						virtual string readWholeString ();
				};
			}
		}
	}
#endif

