#include "theBiasPlanet/coreUtilities/inputs/HaltableStandardInputReader.hpp"
#include "theBiasPlanet/coreUtilities/constantsGroups/DefaultValuesConstantsGroup.hpp"

namespace theBiasPlanet {
	namespace coreUtilities {
		namespace inputs  {
			HaltableStandardInputReader::HaltableStandardInputReader (): HaltableReader (&cin, DefaultValuesConstantsGroup::c_smallBufferSize) {
			}
			
			HaltableStandardInputReader::~HaltableStandardInputReader () {
			}
			
			HaltableStandardInputReader & HaltableStandardInputReader::getInstance () {
				if (s_singletonInstance == nullptr) {
					s_singletonInstance = new HaltableStandardInputReader ();
				}
				return *s_singletonInstance;
			}
		}
	}
}

