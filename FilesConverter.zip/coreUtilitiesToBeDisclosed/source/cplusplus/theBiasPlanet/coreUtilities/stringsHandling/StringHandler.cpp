#include "theBiasPlanet/coreUtilities/stringsHandling/StringHandler.hpp"
#include <iomanip>
#include <iostream>
#include <locale>
#include "theBiasPlanet/coreUtilities/constantsGroups/GeneralConstantsConstantsGroup.hpp"

using namespace ::std;
using namespace ::theBiasPlanet::coreUtilities::constantsGroups;

namespace theBiasPlanet {
	namespace coreUtilities {
		namespace stringsHandling {
			u16string StringHandler::getUtf16String (string const & a_utf8String) {
#ifdef GCC
				return c_wstringConverter.from_bytes (a_utf8String.data ());
#else
				wstring l_wstring = c_wstringConverter.from_bytes (a_utf8String.data ());
				return u16string (l_wstring.begin (),  l_wstring.end ());
#endif
			}
			
			string StringHandler::getUtf8String (u16string const & a_utf16String) {
#ifdef GCC
				return c_wstringConverter.to_bytes (a_utf16String.data ());
#else
				return c_wstringConverter.to_bytes (wstring (a_utf16String.begin (), a_utf16String.end ()).data ());
#endif
			}
			
			ostringstream * StringHandler::format (ostringstream * a_resultStream, istringstream * a_formatStream) {
				if (a_formatStream != nullptr) {
					string l_remains;
					getline (*a_formatStream, l_remains);
					(*a_resultStream) << l_remains;
				}
				else {
				}
				return a_resultStream;
			}
			
			string & StringHandler::replaceAll (string * a_targetString, regex const & a_stringFragmentToBeReplacedRegularExpression, string const & a_stringFragmentThatReplaces) {
				string l_workingString;
				l_workingString.reserve (a_targetString->length ());
				int l_currentCharacterIndex = GeneralConstantsConstantsGroup::c_iterationStartingNumber;
				int l_stringFragmentToBeReplacedIndex = GeneralConstantsConstantsGroup::c_anyUnspecifiedInteger;
				smatch l_match;
				string::const_iterator l_targetStringIteratorAtBeginning (a_targetString->cbegin ());
				string::const_iterator l_targetStringIteratorAtCurrentCharacter (l_targetStringIteratorAtBeginning);
				string::const_iterator l_targetStringIteratorAtEnd (a_targetString->cend ());
				while (regex_search (l_targetStringIteratorAtCurrentCharacter, l_targetStringIteratorAtEnd, l_match, a_stringFragmentToBeReplacedRegularExpression)) {
					l_currentCharacterIndex = distance (l_targetStringIteratorAtBeginning, l_targetStringIteratorAtCurrentCharacter);
					l_stringFragmentToBeReplacedIndex = l_currentCharacterIndex + l_match.position (GeneralConstantsConstantsGroup::c_iterationStartingNumber);
					l_workingString.append (*a_targetString, l_currentCharacterIndex, l_stringFragmentToBeReplacedIndex - 1 - (l_currentCharacterIndex - 1));
					l_workingString += a_stringFragmentThatReplaces;
					l_targetStringIteratorAtCurrentCharacter = l_match.suffix ().first;
				}
				l_currentCharacterIndex = distance (l_targetStringIteratorAtBeginning, l_targetStringIteratorAtCurrentCharacter);
				l_workingString += a_targetString->substr (l_currentCharacterIndex);
				a_targetString->swap (l_workingString);
				return *a_targetString;
			}
			
			string StringHandler::getThousandsSeparatedLongString (long const & a_long) {
				ostringstream l_resultStream;
				l_resultStream.imbue (locale (""));
				l_resultStream << a_long;
				return l_resultStream.str ();
			}
			
			string StringHandler::getDateAndTimeString (time_t const & a_dateAndTime) {
    			tm const l_localDateAndTime = *(localtime (&a_dateAndTime));
    			ostringstream l_dateAndTimeExpressionStream;
    			l_dateAndTimeExpressionStream << put_time (&l_localDateAndTime, "%Y-%m-%dT%H:M:S");
				return l_dateAndTimeExpressionStream.str ();
			}
		}
	}
}

