#include "theBiasPlanet/coreUtilities/stringsHandling/StringTokenizer.hpp"

#include <iostream>
#include "theBiasPlanet/coreUtilities/constantsGroups/GeneralConstantsConstantsGroup.hpp"

using namespace ::std;
using namespace ::theBiasPlanet::coreUtilities::constantsGroups;

namespace theBiasPlanet {
	namespace coreUtilities {
		namespace stringsHandling {
			StringTokenizer::StringTokenizer (string const & a_targetString, string const a_delimiter) : i_originalStringStream (stringstream (a_targetString)), i_delimiter (a_delimiter) {
				optional <string> l_token = nullopt;
				while (true) {
					l_token = getNextToken ();
					if (l_token.has_value ()) {
						i_tokens.push_back (*l_token);
					}
					else {
						break;
					}
				}
				i_numberOfTokens = i_tokens.size ();
				i_tokensIterator = i_tokens.begin ();
				i_currentIndex = GeneralConstantsConstantsGroup::c_iterationStartingNumber;
			}
			
			optional <string> StringTokenizer::getNextToken () {
				string l_token ("");
				string l_tokenFragment;
				size_t const l_delimiterLength = i_delimiter.size ();
				char const l_delimiterLastCharacter = i_delimiter.back ();
				string const l_delimiterHeader = i_delimiter.substr (0, l_delimiterLength - 1);
				while (true) {
					if (getline (i_originalStringStream, l_tokenFragment, l_delimiterLastCharacter)) {
						l_token += l_tokenFragment;
						if (i_originalStringStream.eof ()) {
							return l_token;
						}
						else {
							if (l_delimiterLength > 1) {
								if (l_token.substr (l_token.size () - l_delimiterLength) == l_delimiterHeader) {
									return l_token;
								}
								else {
								}
							}
							else {
								return l_token;
							}
						}
					}
					else {
						return nullopt;
					}
				}
			}
			
			int StringTokenizer::countTokens () {
				return i_numberOfTokens - i_currentIndex;
			}
			
			bool StringTokenizer::hasMoreTokens () {
				return i_currentIndex < i_numberOfTokens;
			}
			
			optional <string> StringTokenizer::nextToken () {
				if (i_currentIndex < i_numberOfTokens) {
					if (i_currentIndex > GeneralConstantsConstantsGroup::c_iterationStartingNumber) {
						i_tokensIterator ++;
					}
					i_currentIndex ++;
					return *i_tokensIterator;
				}
				else {
					return nullopt;
				}
			}
		}
	}
}

