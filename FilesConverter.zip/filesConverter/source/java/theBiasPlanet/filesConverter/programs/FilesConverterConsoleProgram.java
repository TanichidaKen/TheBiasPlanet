package theBiasPlanet.filesConverter.programs;

import java.text.NumberFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Locale;
import com.sun.star.beans.PropertyValue;
import com.sun.star.container.XIndexAccess;
import com.sun.star.container.XNamed;
import com.sun.star.lang.XComponent;
import com.sun.star.sheet.XSpreadsheet;
import com.sun.star.sheet.XSpreadsheetDocument;
import com.sun.star.sheet.XSpreadsheets;
import com.sun.star.sheet.XSpreadsheetView;
import com.sun.star.uno.Any;
import com.sun.star.uno.UnoRuntime;
import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.coreUtilities.collectionsHandling.ListsFactory;
import theBiasPlanet.coreUtilities.messaging.Publisher;
import theBiasPlanet.coreUtilities.performanceMeasuring.PerformanceMeasurer;
import theBiasPlanet.unoUtilities.connectionsHandling.UnoConnection;
import theBiasPlanet.unoUtilities.connectionsHandling.UnoConnectionConnector;
import theBiasPlanet.unoUtilities.connectionsHandling.UnoObjectsContext;
import theBiasPlanet.unoUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.*;
import theBiasPlanet.unoUtilities.documentsHandling.UnoDocumentTailor;
import theBiasPlanet.unoUtilities.filesConverting.FilesConverter;
import theBiasPlanet.unoUtilities.programsHandling.UnoProcessEnvironment;
import theBiasPlanet.unoUtilities.propertiesHandling.UnoPropertiesHandler;

public class FilesConverterConsoleProgram {
	private static class UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor extends UnoDocumentTailor {
		private int i_targetSpreadSheetIndex;
		
		public UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor (UnoObjectsContext a_objectsContext, int a_targetSpreadSheetIndex) {
			super (a_objectsContext);
			i_targetSpreadSheetIndex = a_targetSpreadSheetIndex;
		}
		
		@Override
		public boolean tailor (XComponent a_unoDocumentInXComponent) {
			XSpreadsheetDocument l_spreadSheetsDocumentInXSpreadsheetDocument = (XSpreadsheetDocument) UnoRuntime.queryInterface (XSpreadsheetDocument.class, a_unoDocumentInXComponent);
			if (l_spreadSheetsDocumentInXSpreadsheetDocument == null) {
				Publisher.logErrorInformation ("The document is not any spread sheet.");
				return false;
			}
			else {
				XIndexAccess l_spreadSheetsInXIndexAccess = (XIndexAccess) UnoRuntime.queryInterface (XIndexAccess.class, l_spreadSheetsDocumentInXSpreadsheetDocument.getSheets ());
				try {
					XSpreadsheet l_spreadSheetInXSpreadsheet = (XSpreadsheet) (((Any) l_spreadSheetsInXIndexAccess.getByIndex (i_targetSpreadSheetIndex)).getObject ());
					XNamed l_spreadSheetInXNamed = (XNamed) UnoRuntime.queryInterface (XNamed.class, l_spreadSheetInXSpreadsheet);
					((XSpreadsheets) UnoRuntime.queryInterface (XSpreadsheets.class, l_spreadSheetsInXIndexAccess)).moveByName (l_spreadSheetInXNamed.getName (), (short) GeneralConstantsConstantsGroup.c_iterationStartingNumber);
					return true;
				}
				catch (Exception l_exception) {
					Publisher.logErrorInformation (l_exception);
					return false;
				}
			}
		}
	}
	
	public static void main (String [] a_argumentsArray) throws Exception {
		int l_resultStatus = -1;
		try {
			if (a_argumentsArray.length < 4) {
				throw new Exception ("The arguments have to be these.\nThe argument 1: the server URL like 'socket,host=localhost,port=2002,tcpNoDelay=1;urp;StarOffice.ComponentContext'\nThe argument 2: the URL of the file to be converted like 'file://${HOME}/myData/development/filesConverter/execution/FilesConverterTest.ods'\nThe argument 3: the URL of the target file  like 'file://${HOME}/myData/development/filesConverter/execution/FilesConverterTest.csv'\nThe argument 4: the filter name like 'Text - txt - csv (StarCalc)'\nThe argument 5 (optional): the converted-from file password\nThe argument 6 (valid only for the CSV filter, and optional): whether all the spread sheets are written ('true' or else)\nThe argument 7 (valid only for the CSV filter, and optional): the CSV file naming rule ('0' -> augmented by the sheet index, '1' -> augmented by the sheet name)\nThe argument 8 (valid only for the CSV filter, and optional): the items delimiter character code\nThe argument 9 (valid only for the CSV filter, and optional): the text item quotation character code\nThe argument 10 (valid only for the CSV filter, and optional): the encoding code\nThe argument 11 (valid only for the CSV filter, and optional): whether all the text items are quoted\nThe argument 12 (valid only for the CSV filter, and optional): whether the contents are exported as shown\nThe argument 13 (valid only for the CSV filter, and optional): whether the formula themselves are exported\nThe argument 14 (valid only for the CSV filter, and optional): whether the hidden sheets are written\n");
			}
			String l_unoServerUrl = a_argumentsArray [0];
			String l_convertedFileUrl = a_argumentsArray [1];
			String l_targetFileUrl = a_argumentsArray [2];
			String l_filterName = a_argumentsArray [3];
			String l_openingPassword = null;
			if (a_argumentsArray.length >= 5) {
				l_openingPassword = a_argumentsArray [4];
			}
			String l_title = "Test Title";
			String l_storingPassword = "TestPassword";
			Boolean l_overwrites = Boolean.valueOf (true);
			ArrayList <String> l_documentStoringFilterDataInPropertiesArrayPropertyNames = ListsFactory.createArrayList ();
			ArrayList <Object> l_documentStoringFilterDataInPropertiesArrayPropertyValues = ListsFactory.createArrayList ();
			boolean l_whetherAllSpreadSheetsAreWritten = false;
			int l_targetFileNamingRule = 0;
			int l_csvItemsDelimiterCharacterCode = Character.codePointAt ("\t", 0);
			int l_csvTextItemQuotationCharacterCode = Character.codePointAt ("\"", 0);
			int l_csvCharactersEncodingCode = UnoCharactersEncodingCodesConstantsGroup.c_utf8; // 76: UTF-8, 65535: UCS-2, 65534: UCS-4, 11: US-ASCII, 69: EUC_JP, 64: SHIFT_JIS
			boolean l_csvWhetherAllTextItemsAreQuoted = true;
			boolean l_csvWhetherContentsAreExportedAsShown = true;
			boolean l_csvWhetherFormulaeThemselvesAreExported = false;
			boolean l_whetherHiddenSpreadSheetsAreWritten = false;
			if (l_filterName.equals (UnoFileStoringFilterNamesConstantsGroup.c_csvFileFilterName)) {
				if (a_argumentsArray.length >= 6) {
					if (a_argumentsArray [5].equals ("true")) {
						l_whetherAllSpreadSheetsAreWritten = true;
					}
					if (a_argumentsArray.length >= 7) {
						l_targetFileNamingRule = Integer.parseInt (a_argumentsArray [6]);
						if (a_argumentsArray.length >= 8) {
							l_csvItemsDelimiterCharacterCode = Integer.parseInt (a_argumentsArray [7]);
							if (a_argumentsArray.length >= 9) {
								l_csvTextItemQuotationCharacterCode = Integer.parseInt (a_argumentsArray [8]);
								if (a_argumentsArray.length >= 10) {
									l_csvCharactersEncodingCode = Integer.parseInt (a_argumentsArray [9]);
									if (a_argumentsArray.length >= 11) {
										if (a_argumentsArray [10].equals ("true")) {
											l_csvWhetherAllTextItemsAreQuoted = true;
										}
										if (a_argumentsArray.length >= 12) {
											if (a_argumentsArray [11].equals ("true")) {
												l_csvWhetherContentsAreExportedAsShown = true;
											}
											if (a_argumentsArray.length >= 13) {
												if (a_argumentsArray [12].equals ("true")) {
													l_csvWhetherFormulaeThemselvesAreExported = true;
												}
												if (a_argumentsArray.length >= 14) {
													if (a_argumentsArray [13].equals ("true")) {
														l_whetherHiddenSpreadSheetsAreWritten = true;
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			String l_documentStoringFilterDataInStringValue = "";
			PropertyValue [] l_documentStoringPropertiesArray = null;
			if (!l_whetherAllSpreadSheetsAreWritten) {
				ArrayList <String> l_documentStoringPropertyNames = ListsFactory.createArrayList (
					UnoDocumentStoringEnumerablePropertyNamesSet.c_filterName_string,
					UnoDocumentStoringEnumerablePropertyNamesSet.c_filterData_any,
					UnoDocumentStoringEnumerablePropertyNamesSet.c_filterData_string,
					UnoDocumentStoringEnumerablePropertyNamesSet.c_title_string,
					UnoDocumentStoringEnumerablePropertyNamesSet.c_password_string,
					UnoDocumentStoringEnumerablePropertyNamesSet.c_overwrites_boolen
				);
				ArrayList <Object> l_documentStoringPropertyValues = ListsFactory.createArrayList (
					l_filterName,
					UnoPropertiesHandler.buildPropertiesArray (l_documentStoringFilterDataInPropertiesArrayPropertyNames, l_documentStoringFilterDataInPropertiesArrayPropertyValues),
					l_documentStoringFilterDataInStringValue,
					l_title,
					l_storingPassword,
					l_overwrites
				);
				l_documentStoringPropertiesArray = UnoPropertiesHandler.buildPropertiesArray (l_documentStoringPropertyNames, l_documentStoringPropertyValues);
			}
			else {
				l_documentStoringPropertiesArray = FilesConverter.createCsvFileStoringPropertiesArray (l_csvItemsDelimiterCharacterCode, l_csvTextItemQuotationCharacterCode, l_csvCharactersEncodingCode, l_csvWhetherAllTextItemsAreQuoted, l_csvWhetherContentsAreExportedAsShown, l_csvWhetherFormulaeThemselvesAreExported);
			}
			UnoProcessEnvironment l_localUnoProcessEnvironment = new UnoProcessEnvironment (LocalDateTime.now ().toString (), null);
			UnoConnectionConnector l_unoConnectionConnector = new UnoConnectionConnector (l_localUnoProcessEnvironment.getLocalObjectsContext ());
			UnoConnection l_unoConnection = l_unoConnectionConnector.connect (l_unoServerUrl, null);
			UnoObjectsContext l_remoteUnoObjectsContext = l_unoConnection.getRemoteObjectsContext ();
			FilesConverter l_filesConverter = new FilesConverter (l_remoteUnoObjectsContext);
			UnoDocumentTailor l_unoDocumentTailor = null;
			PerformanceMeasurer.setStartTime ();
			boolean l_whetherConversionHasSucceeded = false;
			if (!l_whetherAllSpreadSheetsAreWritten) {
				if (l_filterName.equals (UnoFileStoringFilterNamesConstantsGroup.c_csvFileFilterName)) {
					l_unoDocumentTailor = new UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor (l_remoteUnoObjectsContext, 1);
				}
				l_whetherConversionHasSucceeded = l_filesConverter.convertFile (l_convertedFileUrl, l_openingPassword, l_targetFileUrl, l_documentStoringPropertiesArray, l_unoDocumentTailor);
			}
			else {
				l_whetherConversionHasSucceeded = l_filesConverter.convertSpreadSheetsDocumentFileToCsvFiles (l_convertedFileUrl, l_openingPassword, l_targetFileUrl, l_documentStoringPropertiesArray, l_unoDocumentTailor, l_targetFileNamingRule, l_whetherHiddenSpreadSheetsAreWritten);
			}
			if (l_whetherConversionHasSucceeded) {
				System.out.println (String.format ("### The elapsed time is %s ns", NumberFormat.getNumberInstance (Locale.US).format (PerformanceMeasurer.getElapseTimeInNanoSeconds ())));
				l_resultStatus = 0;
			}
			else {
			}
			l_unoConnection.disconnect ();
		}
		catch (Exception l_exception) {
			Publisher.logErrorInformation (l_exception);
			System.exit (l_resultStatus);
		}
		System.exit (l_resultStatus);
	}
}

