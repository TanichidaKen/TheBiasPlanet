package theBiasPlanet.filesConverter.programs;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.text.NumberFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Locale;
import java.util.HashMap;
import com.sun.star.beans.NamedValue;
import com.sun.star.beans.PropertyValue;
import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.coreUtilities.collectionsHandling.ListsFactory;
import theBiasPlanet.coreUtilities.collectionsHandling.MapsFactory;
import theBiasPlanet.coreUtilities.cryptography.Hasher;
import theBiasPlanet.coreUtilities.messaging.Publisher;
import theBiasPlanet.coreUtilities.performanceMeasuring.PerformanceMeasurer;
import theBiasPlanet.coreUtilities.stringsHandling.StringTokenizer;
import theBiasPlanet.coreUtilities.stringsHandling.StringHandler;
import theBiasPlanet.unoUtilities.connectionsHandling.UnoConnection;
import theBiasPlanet.unoUtilities.connectionsHandling.UnoConnectionConnector;
import theBiasPlanet.unoUtilities.connectionsHandling.UnoObjectsContext;
import theBiasPlanet.unoUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.*;
import theBiasPlanet.unoUtilities.cryptography.MicrosoftPasswordsHasher;
import theBiasPlanet.unoUtilities.documentsHandling.UnoDocumentTailor;
import theBiasPlanet.unoUtilities.documentsHandling.UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor;
import theBiasPlanet.unoUtilities.documentsHandling.UnoTextDocumentSetPageSizesTailor;
import theBiasPlanet.unoUtilities.filesConverting.FilesConverter;
import theBiasPlanet.unoUtilities.nameValuePairsHandling.UnoNameValuePairsHandler;
import theBiasPlanet.unoUtilities.programsHandling.UnoProcessEnvironment;
import theBiasPlanet.unoUtilities.propertiesHandling.UnoPropertiesHandler;

public class FilesConverterConsoleProgram {
	public static void main (String [] a_argumentsArray) throws Exception {
		int l_resultStatus = -1;
		try {
			if (a_argumentsArray.length < 2) {
				throw new Exception ("The arguments have to be these.\nThe argument 1: the server URL like 'socket,host=localhost,port=2002,tcpNoDelay=1;urp;StarOffice.ComponentContext'\nThe argument 2: the path of the conversion orders CSV file\n");
			}
			String l_unoServerUrl = a_argumentsArray [0];
			String l_conversionOrdersFilePath = a_argumentsArray [1];
			int l_conversionOrderIndex =  GeneralConstantsConstantsGroup.c_iterationStartingNumber;
			String l_conversionOrder = null;
			StringBuilder l_failedConversionOrderIndicesStringBuilder = new StringBuilder ();
			Boolean l_overwrites = Boolean.valueOf (true);
			String l_convertedFileUrl = null;
			String l_targetFileUrl = null;
			String l_filterName = null;
			String l_openingPassword = null;
			String l_title = null;
			String l_encryptingPassword = null;
			ArrayList <String> l_encryptionDatumNames = ListsFactory. <String>createArrayList ("OOXPassword");
			ArrayList <Object> l_encryptionDatumValues = null;
			NamedValue [] l_encryptionDatumArray = null;
			String l_editingPassword = null;
			ArrayList <String> l_editingPasswordInformationPropertyNames = ListsFactory. <String>createArrayList ("algorithm-name", "salt", "iteration-count", "hash");
			int l_saltLength = 16;
			byte [] l_salt = Hasher.createSalt (l_saltLength);
			int l_numberOfIterationForHashing = 100000;
			int l_editingPasswordHashLength = 16;
			byte [] l_editingPasswordHash = null;
			ArrayList <Object> l_editingPasswordInformationPropertyValues = null;
			PropertyValue [] l_editingPasswordInformationArray = null;
			int l_editingPasswordMicrosoftHash = GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger;
			Object l_editingPasswordInformation = null;
			ArrayList <String> l_documentStoringFilterDataInPropertiesArrayPropertyNames = null;
			ArrayList <Object> l_documentStoringFilterDataInPropertiesArrayPropertyValues = null;
			String l_documentStoringFilterDataInStringValue = null;
			PropertyValue [] l_documentStoringPropertiesArray = null;
			String l_unoDocumentTailorName = null;
			UnoDocumentTailor l_unoDocumentTailor = null;
			boolean l_allSpreadSheetsAreWritten = false;
			int l_targetFileNamingRule = 0;
			//int l_csvItemsDelimiterCharacterCode = Character.codePointAt ("\t", 0);
			int l_csvItemsDelimiterCharacterCode = Character.codePointAt (",", 0);
			int l_csvTextItemQuotationCharacterCode = Character.codePointAt ("\"", 0);
			int l_csvCharactersEncodingCode = UnoCharactersEncodingCodesConstantsGroup.c_utf8; // 76: UTF-8, 65535: UCS-2, 65534: UCS-4, 11: US-ASCII, 69: EUC_JP, 64: SHIFT_JIS
			//boolean l_csvAllTextItemsAreQuoted = true;
			boolean l_csvAllTextItemsAreQuoted = false;
			//boolean l_csvContentsAreExportedAsShown = true;
			boolean l_csvContentsAreExportedAsShown = false;
			boolean l_csvFormulaeThemselvesAreExported = false;
			boolean l_hiddenSpreadSheetsAreWritten = false;
			UnoProcessEnvironment l_localUnoProcessEnvironment = new UnoProcessEnvironment (LocalDateTime.now ().toString (), null);
			UnoConnectionConnector l_unoConnectionConnector = new UnoConnectionConnector (l_localUnoProcessEnvironment.getLocalObjectsContext ());
			UnoConnection l_unoConnection = l_unoConnectionConnector.connect (l_unoServerUrl, null);
			UnoObjectsContext l_remoteUnoObjectsContext = l_unoConnection.getRemoteObjectsContext ();
			FilesConverter l_filesConverter = new FilesConverter (l_remoteUnoObjectsContext);
			HashMap <String, UnoDocumentTailor> l_unoDocumentTailorNameToUnoDocumentTailorMap = MapsFactory. <String, UnoDocumentTailor>createLinkedHashMap ("UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor_1", new UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor (l_remoteUnoObjectsContext, 1), "UnoTextDocumentSetPageSizesTailor_a4Landscape", new UnoTextDocumentSetPageSizesTailor (l_remoteUnoObjectsContext, UnoSizesConstantsGroup.c_a4Landscape));
			PerformanceMeasurer.setStartTime ();
			BufferedReader l_conversionOrdersFileReader = new BufferedReader (new InputStreamReader (new FileInputStream (new File (l_conversionOrdersFilePath)), EncodingNamesConstantsGroup.c_utf8EncodingName));
			String l_conversionOrderToken = null;
			boolean l_conversionHasSucceeded = false;
			while (true) {
				l_conversionHasSucceeded = false;
				l_conversionOrder = l_conversionOrdersFileReader.readLine ();
				if (l_conversionOrder == null) {
					break;
				}
				else {
					StringTokenizer l_conversionOrderTokenizer = new StringTokenizer (l_conversionOrder, String.valueOf (GeneralConstantsConstantsGroup.c_tabCharacter));
					if (l_conversionOrderTokenizer.countTokens () < 3) {
						Publisher.logErrorInformation (String.format ("The conversion order has to have at least these properties for the %d index order.\nThe property 1: the URL of the file to be converted like 'file://${HOME}/myData/development/filesConverter/execution/FilesConverterTest.ods'\nThe property 2: the URL of the target file  like 'file://${HOME}/myData/development/filesConverter/execution/FilesConverterTest.csv'\nThe property 3: the filter name like 'Text - txt - csv (StarCalc)'\n", l_conversionOrderIndex));
					}
					else {
						l_convertedFileUrl = StringHandler.effectuateEnvironmentVariables (l_conversionOrderTokenizer.nextToken ());
						l_targetFileUrl = StringHandler.effectuateEnvironmentVariables (l_conversionOrderTokenizer.nextToken ());
						l_filterName = l_conversionOrderTokenizer.nextToken ();
						l_openingPassword = null;
						l_title = null;
						l_encryptingPassword = null;
						l_encryptionDatumValues = null;
						l_encryptionDatumArray = null;
						l_editingPassword = null;
						l_editingPasswordHash = null;
						l_editingPasswordInformationPropertyValues = null;
						l_editingPasswordInformationArray = null;
						l_editingPasswordInformation = null;
						l_editingPasswordMicrosoftHash = GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger;
						l_documentStoringFilterDataInPropertiesArrayPropertyNames = ListsFactory. <String>createArrayList ();
						l_documentStoringFilterDataInPropertiesArrayPropertyValues = ListsFactory. <Object>createArrayList ();
						l_documentStoringFilterDataInStringValue = null;
						l_documentStoringPropertiesArray = null;
						l_unoDocumentTailorName = null;
						l_unoDocumentTailor = null;
						l_allSpreadSheetsAreWritten = false;
						l_targetFileNamingRule = 0;
						//l_csvItemsDelimiterCharacterCode = Character.codePointAt ("\t", 0);
						l_csvItemsDelimiterCharacterCode = Character.codePointAt (",", 0);
						l_csvTextItemQuotationCharacterCode = Character.codePointAt ("\"", 0);
						l_csvCharactersEncodingCode = UnoCharactersEncodingCodesConstantsGroup.c_utf8; // 76: UTF-8, 65535: UCS-2, 65534: UCS-4, 11: US-ASCII, 69: EUC_JP, 64: SHIFT_JIS
						//l_csvAllTextItemsAreQuoted = true;
						l_csvAllTextItemsAreQuoted = false;
						//l_csvContentsAreExportedAsShown = true;
						l_csvContentsAreExportedAsShown = false;
						l_csvFormulaeThemselvesAreExported = false;
						l_hiddenSpreadSheetsAreWritten = false;
						// "The conversion order properties have to be these for the %d index order.\nThe property 4 (optional): the converted-from file password\nThe property 5 (optional): the UNO document tailor name\n"
						if (l_conversionOrderTokenizer.hasMoreTokens ()) {
							l_openingPassword = l_conversionOrderTokenizer.nextToken ();
							if (l_openingPassword.equals ("")) {
								l_openingPassword = null;
							}
							if (l_conversionOrderTokenizer.hasMoreTokens ()) {
								l_unoDocumentTailorName = l_conversionOrderTokenizer.nextToken ();
								if (!l_unoDocumentTailorName.equals ("")) {
									l_unoDocumentTailor = l_unoDocumentTailorNameToUnoDocumentTailorMap.get (l_unoDocumentTailorName);
								}
							}
						}
						if (!(l_filterName.equals (UnoFileStoringFilterNamesConstantsGroup.c_csvFileFilterName))) {
							// "The conversion order properties have to be these for the %d index order.\nThe property 6 (optional): the document title\nThe property 7 (optional): the encrypting password\nThe property 8 (optional): the editing password\n"
							if (l_conversionOrderTokenizer.hasMoreTokens ()) {
								l_title = l_conversionOrderTokenizer.nextToken ();
								if (l_title.equals ("")) {
									l_title = null;
								}
								if (l_conversionOrderTokenizer.hasMoreTokens ()) {
									l_encryptingPassword = l_conversionOrderTokenizer.nextToken ();
									if (l_encryptingPassword.equals ("")) {
										l_encryptingPassword = null;
									}
									else {
										if (l_filterName.equals (UnoFileStoringFilterNamesConstantsGroup.c_microsoftWord2007XmlFilterName) || l_filterName.equals (UnoFileStoringFilterNamesConstantsGroup.c_microsoftExcel2007XmlFilterName)) {
											l_encryptionDatumValues = ListsFactory. <Object>createArrayList (l_encryptingPassword);
											l_encryptionDatumArray = UnoNameValuePairsHandler.buildNameValuePairsArray (l_encryptionDatumNames, l_encryptionDatumValues);
											l_encryptingPassword = null;
										}
									}
									if (l_conversionOrderTokenizer.hasMoreTokens ()) {
										l_editingPassword = l_conversionOrderTokenizer.nextToken ();
										if (!(l_editingPassword.equals (""))) {
											if (!l_filterName.equals (UnoFileStoringFilterNamesConstantsGroup.c_microsoftWord2007XmlFilterName) && !l_filterName.equals (UnoFileStoringFilterNamesConstantsGroup.c_microsoftWord97FileFilterName) && !l_filterName.equals (UnoFileStoringFilterNamesConstantsGroup.c_microsoftExcel2007XmlFilterName) && !l_filterName.equals (UnoFileStoringFilterNamesConstantsGroup.c_microsoftExcel97FilterName)) {
												l_editingPasswordHash = Hasher.hashInPbkdf2 (l_editingPassword, l_salt, l_numberOfIterationForHashing, l_editingPasswordHashLength);
												l_editingPasswordInformationPropertyValues = ListsFactory. <Object>createArrayList ("PBKDF2", l_salt, l_numberOfIterationForHashing, l_editingPasswordHash);
												l_editingPasswordInformationArray = UnoPropertiesHandler.buildPropertiesArray (l_editingPasswordInformationPropertyNames, l_editingPasswordInformationPropertyValues);
												l_editingPasswordInformation = l_editingPasswordInformationArray;
											}
											else {
												if (l_filterName.equals (UnoFileStoringFilterNamesConstantsGroup.c_microsoftWord2007XmlFilterName) || l_filterName.equals (UnoFileStoringFilterNamesConstantsGroup.c_microsoftWord97FileFilterName) || l_filterName.equals (UnoFileStoringFilterNamesConstantsGroup.c_microsoftExcel2007XmlFilterName)) {
													l_editingPasswordMicrosoftHash = MicrosoftPasswordsHasher.hashIn32bits (l_editingPassword);
												}
												else {
													l_editingPasswordMicrosoftHash = MicrosoftPasswordsHasher.hashIn16bits (l_editingPassword);
												}
												l_editingPasswordInformation = Integer.valueOf (l_editingPasswordMicrosoftHash);
											}
										}
									}
								}
								/*
								l_documentStoringFilterDataInPropertiesArrayPropertyNames = ListsFactory. <String>createArrayList ();
								l_documentStoringFilterDataInPropertiesArrayPropertyValues = ListsFactory. <Object>createArrayList ();
								l_documentStoringFilterDataInStringValue = null;
								*/
							}
							ArrayList <String> l_documentStoringPropertyNames = ListsFactory. <String>createArrayList (
								UnoDocumentStoringEnumerablePropertyNamesSet.c_filterName_string,
								UnoDocumentStoringEnumerablePropertyNamesSet.c_filterData_any,
								UnoDocumentStoringEnumerablePropertyNamesSet.c_filterData_string,
								UnoDocumentStoringEnumerablePropertyNamesSet.c_title_string,
								UnoDocumentStoringEnumerablePropertyNamesSet.c_encryptionData_NamedValuesSequence,
								UnoDocumentStoringEnumerablePropertyNamesSet.c_password_string,
								UnoDocumentStoringEnumerablePropertyNamesSet.c_editingPasswordInformation_any,
								UnoDocumentStoringEnumerablePropertyNamesSet.c_overwrites_boolen
							);
							ArrayList <Object> l_documentStoringPropertyValues = ListsFactory. <Object>createArrayList (
								l_filterName,
								UnoPropertiesHandler.buildPropertiesArray (l_documentStoringFilterDataInPropertiesArrayPropertyNames, l_documentStoringFilterDataInPropertiesArrayPropertyValues),
								l_documentStoringFilterDataInStringValue,
								l_title,
								l_encryptionDatumArray,
								l_encryptingPassword,
								l_editingPasswordInformation,
								l_overwrites
							);
							l_documentStoringPropertiesArray = UnoPropertiesHandler.buildPropertiesArray (l_documentStoringPropertyNames, l_documentStoringPropertyValues);
						}
						else {
							// "The conversion order properties have to be these for the %d index order.\nThe property 6 (optional): the converted-from file password\nThe property 7 (valid only for the CSV filter, and optional): whether all the spread sheets are written ('true' or else)\nThe property 8 (valid only for the CSV filter, and optional): the CSV file naming rule ('0' -&gt; augmented by the sheet index, '1' -&gt; augmented by the sheet name)\nThe property 9 (valid only for the CSV filter, and optional): the items delimiter character code\nThe property 10 (valid only for the CSV filter, and optional): the text item quotation character code\nThe property 11 (valid only for the CSV filter, and optional): the encoding code\nThe property 12 (valid only for the CSV filter, and optional): whether all the text items are quoted\nThe property 13 (valid only for the CSV filter, and optional): whether the contents are exported as shown\nThe property 14 (valid only for the CSV filter, and optional): whether the formula themselves are exported\nThe property 15 (valid only for the CSV filter, and optional): whether the hidden sheets are written\n", l_conversionOrderIndex));
							if (l_conversionOrderTokenizer.hasMoreTokens ()) {
								if (l_conversionOrderTokenizer.nextToken ().equals ("true")) {
									l_allSpreadSheetsAreWritten = true;
								}
								if (l_conversionOrderTokenizer.hasMoreTokens ()) {
									l_conversionOrderToken = l_conversionOrderTokenizer.nextToken ();
									if (!l_conversionOrderToken.equals ("")) {
										l_targetFileNamingRule = Integer.parseInt (l_conversionOrderToken);
									}
									if (l_conversionOrderTokenizer.hasMoreTokens ()) {
										l_conversionOrderToken = l_conversionOrderTokenizer.nextToken ();
										if (!l_conversionOrderToken.equals ("")) {
											l_csvItemsDelimiterCharacterCode = Integer.parseInt (l_conversionOrderToken);
										}
										if (l_conversionOrderTokenizer.hasMoreTokens ()) {
											l_conversionOrderToken = l_conversionOrderTokenizer.nextToken ();
											if (!l_conversionOrderToken.equals ("")) {
												l_csvTextItemQuotationCharacterCode = Integer.parseInt (l_conversionOrderToken);
											}
											if (l_conversionOrderTokenizer.hasMoreTokens ()) {
												l_conversionOrderToken = l_conversionOrderTokenizer.nextToken ();
												if (!l_conversionOrderToken.equals ("")) {
													l_csvCharactersEncodingCode = Integer.parseInt (l_conversionOrderToken);
												}
												if (l_conversionOrderTokenizer.hasMoreTokens ()) {
													if (l_conversionOrderTokenizer.nextToken ().equals ("true")) {
														l_csvAllTextItemsAreQuoted = true;
													}
													if (l_conversionOrderTokenizer.hasMoreTokens ()) {
														if (l_conversionOrderTokenizer.nextToken ().equals ("true")) {
															l_csvContentsAreExportedAsShown = true;
														}
														if (l_conversionOrderTokenizer.hasMoreTokens ()) {
															if (l_conversionOrderTokenizer.nextToken ().equals ("true")) {
																l_csvFormulaeThemselvesAreExported = true;
															}
															if (l_conversionOrderTokenizer.hasMoreTokens ()) {
																if (l_conversionOrderTokenizer.nextToken ().equals ("true")) {
																	l_hiddenSpreadSheetsAreWritten = true;
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
							l_documentStoringPropertiesArray = FilesConverter.createCsvFileStoringPropertiesArray (l_csvItemsDelimiterCharacterCode, l_csvTextItemQuotationCharacterCode, l_csvCharactersEncodingCode, l_csvAllTextItemsAreQuoted, l_csvContentsAreExportedAsShown, l_csvFormulaeThemselvesAreExported);
						}
					}
					if (!l_allSpreadSheetsAreWritten) {
						l_conversionHasSucceeded = l_filesConverter.convertFile (l_convertedFileUrl, l_openingPassword, l_targetFileUrl, l_documentStoringPropertiesArray, l_unoDocumentTailor);
					}
					else {
						l_conversionHasSucceeded = l_filesConverter.convertSpreadSheetsDocumentFileToCsvFiles (l_convertedFileUrl, l_openingPassword, l_targetFileUrl, l_documentStoringPropertiesArray, l_unoDocumentTailor, l_targetFileNamingRule, l_hiddenSpreadSheetsAreWritten);
					}
				}
				if (!l_conversionHasSucceeded) {
					if (l_failedConversionOrderIndicesStringBuilder.length () == 0) {
					}
					else {
				   	 l_failedConversionOrderIndicesStringBuilder.append (",");
					}
					l_failedConversionOrderIndicesStringBuilder.append (String.format ("%d", l_conversionOrderIndex));
				}
				l_conversionOrderIndex ++;
			}
			l_conversionOrdersFileReader.close ();
			System.out.println (String.format ("### The elapsed time is %s ns", NumberFormat.getNumberInstance (Locale.US).format (PerformanceMeasurer.getElapseTimeInNanoSeconds ())));
			l_resultStatus = 0;
			l_unoConnection.disconnect ();
		}
		catch (Exception l_exception) {
			Publisher.logErrorInformation (l_exception);
			System.exit (l_resultStatus);
		}
		System.exit (l_resultStatus);
	}
}

