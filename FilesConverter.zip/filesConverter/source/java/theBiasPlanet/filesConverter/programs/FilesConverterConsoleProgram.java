package theBiasPlanet.filesConverter.programs;

import java.text.NumberFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Locale;
import com.sun.star.beans.PropertyValue;
import com.sun.star.container.XIndexAccess;
import com.sun.star.container.XNamed;
import com.sun.star.lang.XComponent;
import com.sun.star.sheet.XSpreadsheet;
import com.sun.star.sheet.XSpreadsheetDocument;
import com.sun.star.sheet.XSpreadsheets;
import com.sun.star.sheet.XSpreadsheetView;
import com.sun.star.uno.Any;
import com.sun.star.uno.UnoRuntime;
import theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup;
import theBiasPlanet.coreUtilities.collectionsHandling.ListsFactory;
import theBiasPlanet.coreUtilities.messaging.Publisher;
import theBiasPlanet.coreUtilities.performanceMeasuring.PerformanceMeasurer;
import theBiasPlanet.unoUtilities.connectionsHandling.UnoConnection;
import theBiasPlanet.unoUtilities.connectionsHandling.UnoConnectionConnector;
import theBiasPlanet.unoUtilities.connectionsHandling.UnoObjectsContext;
import theBiasPlanet.unoUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.*;
import theBiasPlanet.unoUtilities.documentsHandling.UnoDocumentTailor;
import theBiasPlanet.unoUtilities.filesConverting.FilesConverter;
import theBiasPlanet.unoUtilities.programsHandling.UnoProcessEnvironment;
import theBiasPlanet.unoUtilities.propertiesHandling.UnoPropertiesHandler;

public class FilesConverterConsoleProgram {
	private static class UnoSpreadSheetsDocumentTailor extends UnoDocumentTailor {
		private int i_targetSpreadSheetIndex;
		
		public UnoSpreadSheetsDocumentTailor (UnoObjectsContext a_objectsContext, int a_targetSpreadSheetIndex) {
			super (a_objectsContext);
			i_targetSpreadSheetIndex = a_targetSpreadSheetIndex;
		}
		
		@Override
		public boolean tailor (XComponent a_unoDocumentInXComponent) {
			XSpreadsheetDocument l_spreadSheetsDocumentInXSpreadsheetDocument = (XSpreadsheetDocument) UnoRuntime.queryInterface (XSpreadsheetDocument.class, a_unoDocumentInXComponent);
			if (l_spreadSheetsDocumentInXSpreadsheetDocument == null) {
				Publisher.logErrorInformation ("The document is not any spread sheet.");
				return false;
			}
			else {
				XIndexAccess l_spreadSheetsInXIndexAccess = (XIndexAccess) UnoRuntime.queryInterface (XIndexAccess.class, l_spreadSheetsDocumentInXSpreadsheetDocument.getSheets ());
				try {
					XSpreadsheet l_spreadSheetInXSpreadsheet = (XSpreadsheet) (((Any) l_spreadSheetsInXIndexAccess.getByIndex (i_targetSpreadSheetIndex)).getObject ());
					XNamed l_spreadSheetInXNamed = (XNamed) UnoRuntime.queryInterface (XNamed.class, l_spreadSheetInXSpreadsheet);
					((XSpreadsheets) UnoRuntime.queryInterface (XSpreadsheets.class, l_spreadSheetsInXIndexAccess)).moveByName (l_spreadSheetInXNamed.getName (), (short) GeneralConstantsConstantsGroup.c_iterationStartingNumber);
					return true;
				}
				catch (Exception l_exception) {
					Publisher.logErrorInformation (l_exception);
					return false;
				}
			}
		}
	}
	
	public static void main (String [] a_arguments) throws Exception {
		int l_resultStatus = -1;
		try {
			if (a_arguments.length != 4) {
				throw new Exception ("The arguments have to be these.\nThe argument 1: the server URL like 'socket,host=localhost,port=2002,tcpNoDelay=1;urp;StarOffice.ComponentContext'\nThe argument 2: the URL of the file to be converted like 'file://${HOME}/myData/development/filesConverter/execution/FilesConverterTest.ods'\nThe argument 3: the URL of the target file  like 'file://${HOME}/myData/development/filesConverter/execution/FilesConverterTest.csv'\nThe argument 4: the filter name like 'Text - txt - csv (StarCalc)'");
			}
			String l_unoServerUrl = a_arguments [0];
			String l_convertedFileUrl = a_arguments [1];
			String l_targetFileUrl = a_arguments [2];
			String l_filterName = a_arguments [3];
			String l_title = "Test Title";
			String l_password = "TestPassword";
			Boolean l_overwrites = Boolean.valueOf (true);
			ArrayList <String> l_documentStoringFilterSpecificPropertyNames = ListsFactory.createArrayList ();
			ArrayList <Object> l_documentStoringFilterSpecificPropertyValues = ListsFactory.createArrayList ();
			ArrayList <String> l_documentStoringFiltersCommonPropertyNames = ListsFactory.createArrayList (
				UnoDocumentStoringEnumerablePropertyNamesSet.c_filterName_String,
				UnoDocumentStoringEnumerablePropertyNamesSet.c_filterData_Object,
				UnoDocumentStoringEnumerablePropertyNamesSet.c_title_String,
				UnoDocumentStoringEnumerablePropertyNamesSet.c_password_String,
				UnoDocumentStoringEnumerablePropertyNamesSet.c_overwrites_Boolen
			);
			ArrayList <Object> l_documentStoringFiltersCommonPropertyValues = ListsFactory.createArrayList (
				l_filterName,
				UnoPropertiesHandler.buildPropertiesArray (l_documentStoringFilterSpecificPropertyNames, l_documentStoringFilterSpecificPropertyValues),
				l_title,
				l_password,
				l_overwrites
			);
			PropertyValue [] l_documentStoringPropertiesArray = UnoPropertiesHandler.buildPropertiesArray (l_documentStoringFiltersCommonPropertyNames, l_documentStoringFiltersCommonPropertyValues);
			UnoProcessEnvironment l_localUnoProcessEnvironment = new UnoProcessEnvironment (LocalDateTime.now ().toString (), null);
			UnoConnectionConnector l_unoConnectionConnector = new UnoConnectionConnector (l_localUnoProcessEnvironment.getLocalObjectsContext ());
			UnoConnection l_unoConnection = l_unoConnectionConnector.connect (l_unoServerUrl, null);
			UnoObjectsContext l_remoteUnoObjectsContext = l_unoConnection.getRemoteObjectsContext ();
			FilesConverter l_filesConverter = new FilesConverter (l_remoteUnoObjectsContext);
			UnoDocumentTailor l_unoDocumentTailor = new UnoSpreadSheetsDocumentTailor (l_remoteUnoObjectsContext, 1);
			PerformanceMeasurer.setStartTime ();
			if (l_filesConverter.convertFile (l_convertedFileUrl, l_targetFileUrl, l_documentStoringPropertiesArray, l_unoDocumentTailor)) {
				System.out.println (String.format ("### The elapsed time is %s ns", NumberFormat.getNumberInstance (Locale.US).format (PerformanceMeasurer.getElapseTimeInNanoSeconds ())));
				l_resultStatus = 0;
			}
			else {
			}
			l_unoConnection.disconnect ();
		}
		catch (Exception l_exception) {
			Publisher.logErrorInformation (l_exception);
			System.exit (l_resultStatus);
		}
		System.exit (l_resultStatus);
	}
}

