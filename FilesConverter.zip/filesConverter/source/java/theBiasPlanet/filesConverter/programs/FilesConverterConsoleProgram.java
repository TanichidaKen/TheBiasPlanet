package theBiasPlanet.filesConverter.programs;

import java.text.NumberFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Locale;
import com.sun.star.beans.PropertyValue;
import theBiasPlanet.coreUtilities.collectionsHandling.ListsFactory;
import theBiasPlanet.coreUtilities.messaging.Publisher;
import theBiasPlanet.coreUtilities.performanceMeasuring.PerformanceMeasurer;
import theBiasPlanet.unoUtilities.connectionsHandling.UnoConnection;
import theBiasPlanet.unoUtilities.connectionsHandling.UnoConnectionConnector;
import theBiasPlanet.unoUtilities.connectionsHandling.UnoObjectsContext;
import theBiasPlanet.unoUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.*;
import theBiasPlanet.unoUtilities.filesConverting.FilesConverter;
import theBiasPlanet.unoUtilities.programsHandling.UnoProcessEnvironment;
import theBiasPlanet.unoUtilities.propertiesHandling.UnoPropertiesHandler;

public class FilesConverterConsoleProgram {
	
	public static void main (String [] a_arguments) throws Exception {
		int l_resultStatus = -1;
		try {
			if (a_arguments.length != 4) {
				throw new Exception ("The arguments have to be these.\nThe argument 1: the server URL like 'socket,host=localhost,port=2002,tcpNoDelay=1;urp;StarOffice.ComponentContext'\nThe argument 2: the URL of the file to be converted like 'file://${HOME}/myData/development/filesConverter/execution/FilesConverterTest.odt'\nThe argument 3: the URL of the target file  like 'file://${HOME}/myData/development/filesConverter/execution/FilesConverterTest.doc'\nThe argument 4: the filter name like 'MS Word 97'");
			}
			String l_unoServerUrl = a_arguments [0];
			String l_convertedFileUrl = a_arguments [1];
			String l_targetFileUrl = a_arguments [2];
			String l_filterName = a_arguments [3];
			String l_title = "Test Title";
			String l_password = "TestPassword";
			Boolean l_overwrites = Boolean.valueOf (true);
			ArrayList <String> l_documentStoringFilterSpecificPropertyNames = ListsFactory.createArrayList ();
			ArrayList <Object> l_documentStoringFilterSpecificPropertyValues = ListsFactory.createArrayList ();
			ArrayList <String> l_documentStoringFiltersCommonPropertyNames = ListsFactory.createArrayList (
				UnoDocumentStoringEnumerablePropertyNamesSet.c_filterName_String,
				UnoDocumentStoringEnumerablePropertyNamesSet.c_filterData_Object,
				UnoDocumentStoringEnumerablePropertyNamesSet.c_title_String,
				UnoDocumentStoringEnumerablePropertyNamesSet.c_password_String,
				UnoDocumentStoringEnumerablePropertyNamesSet.c_overwrites_Boolen
			);
			ArrayList <Object> l_documentStoringFiltersCommonPropertyValues = ListsFactory.createArrayList (
				l_filterName,
				UnoPropertiesHandler.buildPropertiesArray (l_documentStoringFilterSpecificPropertyNames, l_documentStoringFilterSpecificPropertyValues),
				l_title,
				l_password,
				l_overwrites
			);
			PropertyValue [] l_documentStoringPropertiesArray = UnoPropertiesHandler.buildPropertiesArray (l_documentStoringFiltersCommonPropertyNames, l_documentStoringFiltersCommonPropertyValues);
			UnoProcessEnvironment l_localUnoProcessEnvironment = new UnoProcessEnvironment (LocalDateTime.now ().toString (), null);
			UnoConnectionConnector l_unoConnectionConnector = new UnoConnectionConnector (l_localUnoProcessEnvironment.getLocalObjectsContext ());
			UnoConnection l_unoConnection = l_unoConnectionConnector.connect (l_unoServerUrl, null);
			UnoObjectsContext l_remoteUnoObjectsContext = l_unoConnection.getRemoteObjectsContext ();
			FilesConverter l_filesConverter = new FilesConverter (l_remoteUnoObjectsContext);
			PerformanceMeasurer.setStartTime ();
			if (l_filesConverter.convertFile (l_convertedFileUrl, l_targetFileUrl, l_documentStoringPropertiesArray)) {
				System.out.println (String.format ("### The elapsed time is %s ns", NumberFormat.getNumberInstance (Locale.US).format (PerformanceMeasurer.getElapseTimeInNanoSeconds ())));
				l_resultStatus = 0;
			}
			l_unoConnection.disconnect ();
		}
		catch (Exception l_exception) {
			Publisher.logErrorInformation (l_exception);
			System.exit (l_resultStatus);
		}
		System.exit (l_resultStatus);
	}
}

