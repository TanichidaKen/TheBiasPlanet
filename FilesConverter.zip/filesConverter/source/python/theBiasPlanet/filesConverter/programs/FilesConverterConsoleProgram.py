from datetime import datetime
import sys
from typing import cast
from typing import List
from typing import Optional
import uno
from com.sun.star.beans import PropertyValue
from com.sun.star.container import XIndexAccess
from com.sun.star.container import XNamed
from com.sun.star.lang import XComponent
from com.sun.star.sheet import XSpreadsheet
from com.sun.star.sheet import XSpreadsheetDocument
from com.sun.star.sheet import XSpreadsheets
from com.sun.star.sheet import XSpreadsheetView
from uno import Any
from  theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup import GeneralConstantsConstantsGroup
from theBiasPlanet.coreUtilities.collectionsHandling.ListsFactory import ListsFactory
from theBiasPlanet.coreUtilities.messaging.Publisher import Publisher
from theBiasPlanet.coreUtilities.performanceMeasuring.PerformanceMeasurer import PerformanceMeasurer
from theBiasPlanet.unoUtilities.connectionsHandling.UnoConnection import UnoConnection
from theBiasPlanet.unoUtilities.connectionsHandling.UnoConnectionConnector import UnoConnectionConnector
from theBiasPlanet.unoUtilities.connectionsHandling.UnoObjectsContext import UnoObjectsContext
from theBiasPlanet.unoUtilities.constantsGroups.UnoCharactersEncodingCodesConstantsGroup import UnoCharactersEncodingCodesConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.UnoFileStoringFilterNamesConstantsGroup import UnoFileStoringFilterNamesConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.UnoDocumentStoringEnumerablePropertyNamesSet import UnoDocumentStoringEnumerablePropertyNamesSet
from theBiasPlanet.unoUtilities.documentsHandling.UnoDocumentTailor import UnoDocumentTailor 
from theBiasPlanet.unoUtilities.filesConverting.FilesConverter import FilesConverter 
from theBiasPlanet.unoUtilities.programsHandling.UnoProcessEnvironment import UnoProcessEnvironment
from theBiasPlanet.unoUtilities.propertiesHandling.UnoPropertiesHandler import UnoPropertiesHandler

class FilesConverterConsoleProgram:
	class UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor (UnoDocumentTailor):
		def __init__ (a_this: "FilesConverterConsoleProgram.UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor", a_objectsContext: "UnoObjectsContext", a_targetSpreadSheetIndex: int) -> None:
			a_this.i_targetSpreadSheetIndex: int
			
			UnoDocumentTailor.__init__ (a_this, a_objectsContext)
			a_this.i_targetSpreadSheetIndex = a_targetSpreadSheetIndex
		
		def tailor (a_this: "FilesConverterConsoleProgram.UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor", a_unoDocumentInXComponent: XComponent) -> bool:
			l_spreadSheetsDocumentInXSpreadsheetDocument: XSpreadsheetDocument = cast (XSpreadsheetDocument, a_unoDocumentInXComponent)
			if l_spreadSheetsDocumentInXSpreadsheetDocument is None:
				Publisher.logErrorInformation ("The document is not any spread sheet.")
				return False
			else:
				l_spreadSheetsInXIndexAccess: XIndexAccess = cast (XIndexAccess, l_spreadSheetsDocumentInXSpreadsheetDocument.getSheets ())
				try:
					l_spreadSheetInXSpreadsheet: XSpreadsheet = cast (XSpreadsheet, (l_spreadSheetsInXIndexAccess.getByIndex (a_this.i_targetSpreadSheetIndex)))
					l_spreadSheetInXNamed: XNamed = cast (XNamed, l_spreadSheetInXSpreadsheet)
					(cast (XSpreadsheets, l_spreadSheetsInXIndexAccess)).moveByName (l_spreadSheetInXNamed.getName (), GeneralConstantsConstantsGroup.c_iterationStartingNumber)
					return True
				except (Exception) as l_exception:
					Publisher.logErrorInformation (l_exception)
					return False
	
	@staticmethod
	def main (a_arguments: List [str]) -> None:
		l_resultStatus: int = -1
		try:
			if (len (a_arguments) < 5):
				raise Exception ("The arguments have to be these.\nThe argument 1: the server URL like 'socket,host=localhost,port=2002,tcpNoDelay=1;urp;StarOffice.ComponentContext'\nThe argument 2: the URL of the file to be converted like 'file://${HOME}/myData/development/filesConverter/execution/FilesConverterTest.ods'\nThe argument 3: the URL of the target file  like 'file://${HOME}/myData/development/filesConverter/execution/FilesConverterTest.csv'\nThe argument 4: the filter name like 'Text - txt - csv (StarCalc)'\nThe argument 5 (optional): the converted-from file password\nThe argument 6 (valid only for the CSV filter, and optional): whether all the spread sheets are written ('true' or else)\nThe argument 7 (valid only for the CSV filter, and optional): the CSV file naming rule ('0' -> augmented by the sheet index, '1' -> augmented by the sheet name)\nThe argument 8 (valid only for the CSV filter, and optional): the items delimiter character code\nThe argument 9 (valid only for the CSV filter, and optional): the text item quotation character code\nThe argument 10 (valid only for the CSV filter, and optional): the encoding code\nThe argument 11 (valid only for the CSV filter, and optional): whether all the text items are quoted\nThe argument 12 (valid only for the CSV filter, and optional): whether the contents are exported as shown\nThe argument 13 (valid only for the CSV filter, and optional): whether the formula themselves are exported\nThe argument 14 (valid only for the CSV filter, and optional): whether the hidden sheets are written\n")
			l_unoServerUrl: str = a_arguments [1]
			l_convertedFileUrl: str = a_arguments [2]
			l_targetFileUrl: str = a_arguments [3]
			l_filterName: str = a_arguments [4]
			l_openingPassword: Optional [str] = None
			if len (a_arguments) >= 5:
				l_openingPassword = a_arguments [4]
			l_title: str = "Test Title"
			l_storingPassword: str = "TestPassword"
			l_overwrites: bool = True
			l_documentStoringFilterDataInPropertiesPropertyNames: List [str] = []
			l_documentStoringFilterDataInPropertiesPropertyValues: List [object]  = []
			l_whetherAllSpreadSheetsAreWritten: bool = False
			l_targetFileNamingRule:int = 0
			l_csvItemsDelimiterCharacterCode: int = ord ('\t')
			l_csvTextItemQuotationCharacterCode: int = ord ('"')
			l_csvCharactersEncodingCode: int = UnoCharactersEncodingCodesConstantsGroup.c_utf8 # 76: UTF-8, 65535: UCS-2, 65534: UCS-4, 11: US-ASCII, 69: EUC_JP, 64: SHIFT_JIS
			l_csvWhetherAllTextItemsAreQuoted: bool = True
			l_csvWhetherContentsAreExportedAsShown: bool = True
			l_csvWhetherFormulaeThemselvesAreExported: bool = False
			l_whetherHiddenSpreadSheetsAreWritten: bool = False
			if l_filterName == UnoFileStoringFilterNamesConstantsGroup.c_csvFileFilterName:
				if len (a_arguments) >= 7:
					if a_arguments [6] == "true":
						l_whetherAllSpreadSheetsAreWritten = True
						if len (a_arguments) >= 8:
							l_targetFileNamingRule = int (a_arguments [7])
							if len (a_arguments) >= 9:
								l_csvItemsDelimiterCharacterCode = int (a_arguments [8])
								if len (a_arguments) >= 10:
									l_csvTextItemQuotationCharacterCode = int (a_arguments [9])
									if len (a_arguments) >= 11:
										l_csvCharactersEncodingCode = int (a_arguments [10])
										if len (a_arguments) >= 12:
											if a_arguments [11] == "true":
												l_csvWhetherAllTextItemsAreQuoted = True
												if len (a_arguments) >= 13:
													if a_arguments [12] == "true":
														l_csvWhetherContentsAreExportedAsShown = True
														if len (a_arguments) >= 14:
															if a_arguments [13] == "true":
																l_csvWhetherFormulaeThemselvesAreExported = True
																if len (a_arguments) >= 15:
																	if a_arguments [14] == "true":
																		l_whetherHiddenSpreadSheetsAreWritten = True
			l_documentStoringFilterDataInStringValue: str = ""
			l_documentStoringProperties: Optional [List [PropertyValue]] = None
			if not l_whetherAllSpreadSheetsAreWritten:
				l_documentStoringPropertyNames: List [str] = ListsFactory.createList (
					str,
					UnoDocumentStoringEnumerablePropertyNamesSet.c_filterName_string,
					UnoDocumentStoringEnumerablePropertyNamesSet.c_filterData_any,
					UnoDocumentStoringEnumerablePropertyNamesSet.c_filterData_string,
					UnoDocumentStoringEnumerablePropertyNamesSet.c_title_string,
					UnoDocumentStoringEnumerablePropertyNamesSet.c_password_string,
					UnoDocumentStoringEnumerablePropertyNamesSet.c_overwrites_boolen
				)
				l_documentStoringPropertyValues: List [object] = ListsFactory.createList (
					object,
					l_filterName,
					UnoPropertiesHandler.buildProperties (l_documentStoringFilterDataInPropertiesPropertyNames, l_documentStoringFilterDataInPropertiesPropertyValues),
					l_documentStoringFilterDataInStringValue,
					l_title,
					l_storingPassword,
					l_overwrites
				)
				l_documentStoringProperties = UnoPropertiesHandler.buildProperties (l_documentStoringPropertyNames, l_documentStoringPropertyValues)
			else:
				l_documentStoringProperties = FilesConverter.createCsvFileStoringProperties (l_csvItemsDelimiterCharacterCode, l_csvTextItemQuotationCharacterCode, l_csvCharactersEncodingCode, l_csvWhetherAllTextItemsAreQuoted, l_csvWhetherContentsAreExportedAsShown, l_csvWhetherFormulaeThemselvesAreExported)
			l_localUnoProcessEnvironment: "UnoProcessEnvironment" = UnoProcessEnvironment (str (datetime.now ()), None)
			l_unoConnectionConnector: "UnoConnectionConnector" = UnoConnectionConnector (l_localUnoProcessEnvironment.getLocalObjectsContext ())
			l_unoConnection: "UnoConnection" = l_unoConnectionConnector.connect (l_unoServerUrl, None)
			l_remoteUnoObjectsContext: "Optional [UnoObjectsContext]" = l_unoConnection.getRemoteObjectsContext ()
			if not (l_remoteUnoObjectsContext is None):
				l_filesConverter: "FilesConverter" = FilesConverter (l_remoteUnoObjectsContext)
				l_unoDocumentTailor: "Optional [UnoDocumentTailor]" = None
				PerformanceMeasurer.setStartTime ()
				l_whetherConversionHasSucceeded: bool = False
				if not l_whetherAllSpreadSheetsAreWritten:
					if l_filterName == UnoFileStoringFilterNamesConstantsGroup.c_csvFileFilterName:
						l_unoDocumentTailor = FilesConverterConsoleProgram.UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor (l_remoteUnoObjectsContext, 1)
					l_whetherConversionHasSucceeded = l_filesConverter.convertFile (l_convertedFileUrl, l_openingPassword, l_targetFileUrl, l_documentStoringProperties, l_unoDocumentTailor)
				else:
					l_whetherConversionHasSucceeded = l_filesConverter.convertSpreadSheetsDocumentFileToCsvFiles (l_convertedFileUrl, l_openingPassword, l_targetFileUrl, l_documentStoringProperties, l_unoDocumentTailor, l_targetFileNamingRule, l_whetherHiddenSpreadSheetsAreWritten)
				if l_whetherConversionHasSucceeded:
					sys.stdout.write ("### The elapsed time is {0:,d} ns\n".format (PerformanceMeasurer.getElapseTimeInNanoSeconds ()))
					l_resultStatus = 0
				else:
					None
				l_unoConnection.disconnect ()
		except (Exception) as l_exception:
			Publisher.logErrorInformation (l_exception)
			sys.exit (l_resultStatus)
		sys.exit (l_resultStatus)

if __name__ == "__main__":
	FilesConverterConsoleProgram.main (sys.argv)

