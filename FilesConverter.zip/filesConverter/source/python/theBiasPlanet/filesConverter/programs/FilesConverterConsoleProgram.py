from datetime import datetime
import sys
from typing import cast
from typing import Dict
from typing import List
from typing import Optional
from typing import TextIO
import uno
from com.sun.star.beans import PropertyValue
from uno import Any
from  theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup import GeneralConstantsConstantsGroup
from theBiasPlanet.coreUtilities.collectionsHandling.ListsFactory import ListsFactory
from theBiasPlanet.coreUtilities.collectionsHandling.MapsFactory import MapsFactory
from theBiasPlanet.coreUtilities.cryptography.Hasher import Hasher
from theBiasPlanet.coreUtilities.dataConverting.DatumConverter import DatumConverter
from theBiasPlanet.coreUtilities.messaging.Publisher import Publisher
from theBiasPlanet.coreUtilities.performanceMeasuring.PerformanceMeasurer import PerformanceMeasurer
from theBiasPlanet.coreUtilities.stringsHandling.StringHandler import StringHandler
from theBiasPlanet.coreUtilities.stringsHandling.StringTokenizer import StringTokenizer
from theBiasPlanet.unoUtilities.connectionsHandling.UnoConnection import UnoConnection
from theBiasPlanet.unoUtilities.connectionsHandling.UnoConnectionConnector import UnoConnectionConnector
from theBiasPlanet.unoUtilities.connectionsHandling.UnoObjectsContext import UnoObjectsContext
from theBiasPlanet.unoUtilities.constantsGroups.UnoCharactersEncodingCodesConstantsGroup import UnoCharactersEncodingCodesConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.UnoDatumTypeNamesConstantsGroup import UnoDatumTypeNamesConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.UnoFileStoringFilterNamesConstantsGroup import UnoFileStoringFilterNamesConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.UnoDocumentStoringEnumerablePropertyNamesSet import UnoDocumentStoringEnumerablePropertyNamesSet
from theBiasPlanet.unoUtilities.cryptography.MicrosoftPasswordsHasher import MicrosoftPasswordsHasher
from theBiasPlanet.unoUtilities.documentsHandling.UnoDocumentTailor import UnoDocumentTailor
from theBiasPlanet.unoUtilities.documentsHandling.UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor import UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor
from theBiasPlanet.unoUtilities.filesConverting.FilesConverter import FilesConverter
from theBiasPlanet.unoUtilities.programsHandling.UnoProcessEnvironment import UnoProcessEnvironment
from theBiasPlanet.unoUtilities.propertiesHandling.UnoPropertiesHandler import UnoPropertiesHandler
from theBiasPlanet.unoUtilities.unoDataHandling.UnoDatumConverter import UnoDatumConverter

class FilesConverterConsoleProgram:
	@staticmethod
	def main (a_arguments: List [str]) -> None:
		l_resultStatus: int = -1
		try:
			if (len (a_arguments) < 3):
				raise Exception ("The arguments have to be these.\nThe argument 1: the server URL like 'socket,host=localhost,port=2002,tcpNoDelay=1;urp;StarOffice.ComponentContext'\nThe argument 2: the path of the conversion orders CSV file\n")
			l_unoServerUrl: str = a_arguments [1]
			l_conversionOrdersFilePath: str = a_arguments [2]
			l_conversionOrderIndex: int =  GeneralConstantsConstantsGroup.c_iterationStartingNumber
			l_conversionOrder: Optional [str] = None
			l_failedConversionOrderIndicesStringBuilder: List [str] = [];
			l_overwrites: bool = True
			l_convertedFileUrl: Optional [str] = None
			l_targetFileUrl: Optional [str] = None
			l_filterName: Optional [str] = None
			l_openingPassword: Optional [str] = None
			l_title: Optional [str] = None
			l_encryptingPassword: Optional [str] = None
			l_editingPassword: Optional [str] = None
			l_editingPasswordInformationPropertyNames: List [str]  = ListsFactory.createList (str, "algorithm-name", "salt", "iteration-count", "hash")
			l_saltLength: int = 16
			l_salt: bytes = Hasher.createSalt (l_saltLength)
			l_numberOfIterationForHashing: int = 100000
			l_editingPasswordHashLength: int = 16
			l_editingPasswordHash: Optional [bytes] = None
			l_editingPasswordInformationPropertyValues: Optional [List [object]] = None
			l_editingPasswordInformationList: Optional [List [PropertyValue]] = None
			l_editingPasswordMicrosoftHash: int = GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger;
			l_editingPasswordInformation: Any = None
			l_documentStoringFilterDataInPropertiesPropertyNames: List [str] = []
			l_documentStoringFilterDataInPropertiesPropertyValues: List [object]  = []
			l_documentStoringFilterDataInStringValue: Optional [str] = None
			l_documentStoringProperties: Optional [List [PropertyValue]] = None
			l_unoDocumentTailorName: Optional [str] = None
			l_unoDocumentTailor: "Optional [UnoDocumentTailor]" = None
			l_allSpreadSheetsAreWritten: bool = False
			l_targetFileNamingRule:int = 0
			#l_csvItemsDelimiterCharacterCode: int = ord ('\t')
			l_csvItemsDelimiterCharacterCode: int = ord (',')
			l_csvTextItemQuotationCharacterCode: int = ord ('"')
			l_csvCharactersEncodingCode: int = UnoCharactersEncodingCodesConstantsGroup.c_utf8 # 76: UTF-8, 65535: UCS-2, 65534: UCS-4, 11: US-ASCII, 69: EUC_JP, 64: SHIFT_JIS
			#l_csvAllTextItemsAreQuoted: bool = True
			l_csvAllTextItemsAreQuoted: bool = False
			#l_csvContentsAreExportedAsShown: bool = True
			l_csvContentsAreExportedAsShown: bool = False
			l_csvFormulaeThemselvesAreExported: bool = False
			l_hiddenSpreadSheetsAreWritten: bool = False
			l_localUnoProcessEnvironment: "UnoProcessEnvironment" = UnoProcessEnvironment (str (datetime.now ()), None)
			l_unoConnectionConnector: "UnoConnectionConnector" = UnoConnectionConnector (l_localUnoProcessEnvironment.getLocalObjectsContext ())
			l_unoConnection: "UnoConnection" = l_unoConnectionConnector.connect (l_unoServerUrl, None)
			l_remoteUnoObjectsContext: "Optional [UnoObjectsContext]" = l_unoConnection.getRemoteObjectsContext ()
			if not (l_remoteUnoObjectsContext is None):
				l_filesConverter: "FilesConverter" = FilesConverter (l_remoteUnoObjectsContext)
				l_unoDocumentTailorNameToUnoDocumentTailorMap: Dict [str, "UnoDocumentTailor"] = MapsFactory.createOrderedMap (str, UnoDocumentTailor, "UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor_1", UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor (l_remoteUnoObjectsContext, 1))
				PerformanceMeasurer.setStartTime ()
				l_conversionOrdersFile: TextIO = open (l_conversionOrdersFilePath, "r")
				l_conversionOrderToken: Optional [str] = None
				l_conversionHasSucceeded: bool = False
				while True:
					l_conversionHasSucceeded = False
					l_conversionOrder = l_conversionOrdersFile.readline ()
					if l_conversionOrder == "":
						break
					else:
						l_conversionOrder = l_conversionOrder.rstrip (GeneralConstantsConstantsGroup.c_newLineCharacter)
						l_conversionOrderTokenizer: StringTokenizer = StringTokenizer (l_conversionOrder, GeneralConstantsConstantsGroup.c_tabCharacter)
						if l_conversionOrderTokenizer.countTokens () < 3:
							Publisher.logErrorInformation ("The conversion order has to have at least these properties for the {0:d} index order.\nThe property 1: the URL of the file to be converted like 'file://${{HOME}}/myData/development/filesConverter/execution/FilesConverterTest.ods'\nThe property 2: the URL of the target file  like 'file://${{HOME}}/myData/development/filesConverter/execution/FilesConverterTest.csv'\nThe property 3: the filter name like 'Text - txt - csv (StarCalc)'\n".format (l_conversionOrderIndex))
						else:
							l_convertedFileUrl = l_conversionOrderTokenizer.nextToken ()
							if l_convertedFileUrl is not None:
								l_convertedFileUrl = StringHandler.effectuateEnvironmentVariables (l_convertedFileUrl)
							l_targetFileUrl = l_conversionOrderTokenizer.nextToken ()
							if l_targetFileUrl  is not None:
								l_targetFileUrl = StringHandler.effectuateEnvironmentVariables (l_targetFileUrl)
							l_filterName = l_conversionOrderTokenizer.nextToken ()
							l_openingPassword = None
							l_title = None
							l_encryptingPassword = None
							l_editingPassword = None
							l_editingPasswordHash = None
							l_editingPasswordInformationPropertyValues = None
							l_editingPasswordInformationList = None
							l_editingPasswordInformation = None
							l_documentStoringFilterDataInPropertiesPropertyNames = []
							l_documentStoringFilterDataInPropertiesPropertyValues = []
							l_documentStoringFilterDataInStringValue = None
							l_documentStoringPropertiesArray = None
							l_unoDocumentTailorName = None
							l_unoDocumentTailor = None
							l_allSpreadSheetsAreWritten = False
							l_targetFileNamingRule = 0
							#l_csvItemsDelimiterCharacterCode = ord ('\t')
							l_csvItemsDelimiterCharacterCode = ord (',')
							l_csvTextItemQuotationCharacterCode = ord ('"')
							l_csvCharactersEncodingCode = UnoCharactersEncodingCodesConstantsGroup.c_utf8; # 76: UTF-8, 65535: UCS-2, 65534: UCS-4, 11: US-ASCII, 69: EUC_JP, 64: SHIFT_JIS
							#l_csvAllTextItemsAreQuoted = True
							l_csvAllTextItemsAreQuoted = False
							#l_csvContentsAreExportedAsShown = True
							l_csvContentsAreExportedAsShown = False
							l_csvFormulaeThemselvesAreExported = False
							l_hiddenSpreadSheetsAreWritten = False
							# "The conversion order properties have to be these for the %d index order.\nThe property 4 (optional): the converted-from file password\nThe property 5 (optional): the UNO document tailor name\n"
							if l_conversionOrderTokenizer.hasMoreTokens ():
								l_openingPassword = l_conversionOrderTokenizer.nextToken ()
								if l_openingPassword == "":
									l_openingPassword = None
								if l_conversionOrderTokenizer.hasMoreTokens ():
									l_unoDocumentTailorName = l_conversionOrderTokenizer.nextToken ()
									if not (l_unoDocumentTailorName is None or l_unoDocumentTailorName == ""):
										try:
											l_unoDocumentTailor = l_unoDocumentTailorNameToUnoDocumentTailorMap [l_unoDocumentTailorName]
										except (Exception) as l_exception:
											None
							if l_filterName != UnoFileStoringFilterNamesConstantsGroup.c_csvFileFilterName:
								# "The conversion order properties have to be these for the %d index order.\nThe property 6 (optional): the document title\nThe property 7 (optional): the encrypting password\nThe property 8 (optional): the editing password\n"
								if l_conversionOrderTokenizer.hasMoreTokens ():
									l_title = l_conversionOrderTokenizer.nextToken ()
									if l_title == "":
										l_title = None
									if l_conversionOrderTokenizer.hasMoreTokens ():
										l_encryptingPassword = l_conversionOrderTokenizer.nextToken ()
										if l_encryptingPassword == "":
											l_encryptingPassword = None
										if l_conversionOrderTokenizer.hasMoreTokens ():
											l_editingPassword = l_conversionOrderTokenizer.nextToken ()
											if not (l_editingPassword is None or l_editingPassword == ""):
												if l_filterName != UnoFileStoringFilterNamesConstantsGroup.c_microsoftWord2007XmlFilterName and l_filterName != UnoFileStoringFilterNamesConstantsGroup.c_microsoftWord97FileFilterName and l_filterName != UnoFileStoringFilterNamesConstantsGroup.c_microsoftExcel2007XmlFilterName and l_filterName != UnoFileStoringFilterNamesConstantsGroup.c_microsoftExcel97FilterName:
													l_editingPasswordHash = Hasher.hashInPbkdf2 (l_editingPassword, l_salt, l_numberOfIterationForHashing, l_editingPasswordHashLength)
													l_editingPasswordInformationPropertyValues = ListsFactory.createList (object, "PBKDF2", UnoDatumConverter.getAny (ListsFactory.createSignedBytesList (l_salt), "{0:s}{1:s}".format (UnoDatumTypeNamesConstantsGroup.c_sequenceTypeNamePrefix, UnoDatumTypeNamesConstantsGroup.c_byteTypeName)), l_numberOfIterationForHashing, UnoDatumConverter.getAny (ListsFactory.createSignedBytesList (l_editingPasswordHash), "{0:s}{1:s}".format (UnoDatumTypeNamesConstantsGroup.c_sequenceTypeNamePrefix, UnoDatumTypeNamesConstantsGroup.c_byteTypeName)))
													l_editingPasswordInformationList = UnoPropertiesHandler.buildProperties (l_editingPasswordInformationPropertyNames, l_editingPasswordInformationPropertyValues)
													l_editingPasswordInformation = UnoDatumConverter.getAny (l_editingPasswordInformationList, "{0:s}{1:s}".format (UnoDatumTypeNamesConstantsGroup.c_sequenceTypeNamePrefix, "com.sun.star.beans.PropertyValue"))
												else:
													if l_filterName == UnoFileStoringFilterNamesConstantsGroup.c_microsoftWord2007XmlFilterName or l_filterName == UnoFileStoringFilterNamesConstantsGroup.c_microsoftWord97FileFilterName or l_filterName == UnoFileStoringFilterNamesConstantsGroup.c_microsoftExcel2007XmlFilterName:
														l_editingPasswordMicrosoftHash = MicrosoftPasswordsHasher.hashIn32bits (l_editingPassword)
														l_editingPasswordInformation = UnoDatumConverter.getAny (DatumConverter.getSignedInteger (l_editingPasswordMicrosoftHash), "long")
													else:
														l_editingPasswordMicrosoftHash = MicrosoftPasswordsHasher.hashIn16bits (l_editingPassword)
														l_editingPasswordInformation = UnoDatumConverter.getAny (DatumConverter.getSignedShort (l_editingPasswordMicrosoftHash), "long")
									"""
									l_documentStoringFilterDataInPropertiesPropertyNames = []
									l_documentStoringFilterDataInPropertiesPropertyValues = []
									l_documentStoringFilterDataInStringValue = None
									"""
								l_documentStoringPropertyNames: List [str] = ListsFactory.createList (
									str,
									UnoDocumentStoringEnumerablePropertyNamesSet.c_filterName_string,
									UnoDocumentStoringEnumerablePropertyNamesSet.c_filterData_any,
									UnoDocumentStoringEnumerablePropertyNamesSet.c_filterData_string,
									UnoDocumentStoringEnumerablePropertyNamesSet.c_title_string,
									UnoDocumentStoringEnumerablePropertyNamesSet.c_password_string,
									UnoDocumentStoringEnumerablePropertyNamesSet.c_editingPasswordInformation_any,
									UnoDocumentStoringEnumerablePropertyNamesSet.c_overwrites_boolen
								)
								l_documentStoringPropertyValues: List [object] = ListsFactory.createList (
									object,
									l_filterName,
									UnoDatumConverter.getAny (UnoPropertiesHandler.buildProperties (l_documentStoringFilterDataInPropertiesPropertyNames, l_documentStoringFilterDataInPropertiesPropertyValues), "{0:s}{1:s}".format (UnoDatumTypeNamesConstantsGroup.c_sequenceTypeNamePrefix, "com.sun.star.beans.PropertyValue")),
									l_documentStoringFilterDataInStringValue,
									l_title,
									l_encryptingPassword,
									l_editingPasswordInformation,
									l_overwrites
								)
								l_documentStoringProperties = UnoPropertiesHandler.buildProperties (l_documentStoringPropertyNames, l_documentStoringPropertyValues)
							else:
								# "The conversion order properties have to be these for the %d index order.\nThe property 6 (optional): the converted-from file password\nThe property 7 (valid only for the CSV filter, and optional): whether all the spread sheets are written ('true' or else)\nThe property 8 (valid only for the CSV filter, and optional): the CSV file naming rule ('0' -&gt; augmented by the sheet index, '1' -&gt; augmented by the sheet name)\nThe property 9 (valid only for the CSV filter, and optional): the items delimiter character code\nThe property 10 (valid only for the CSV filter, and optional): the text item quotation character code\nThe property 11 (valid only for the CSV filter, and optional): the encoding code\nThe property 12 (valid only for the CSV filter, and optional): whether all the text items are quoted\nThe property 13 (valid only for the CSV filter, and optional): whether the contents are exported as shown\nThe property 14 (valid only for the CSV filter, and optional): whether the formula themselves are exported\nThe property 15 (valid only for the CSV filter, and optional): whether the hidden sheets are written\n", l_conversionOrderIndex));
								if l_conversionOrderTokenizer.hasMoreTokens ():
									if l_conversionOrderTokenizer.nextToken () == "true":
										l_allSpreadSheetsAreWritten = True
									if l_conversionOrderTokenizer.hasMoreTokens ():
										l_conversionOrderToken = l_conversionOrderTokenizer.nextToken ()
										if not (l_conversionOrderToken is None or l_conversionOrderToken == ""):
											l_targetFileNamingRule = int (l_conversionOrderToken)
										if l_conversionOrderTokenizer.hasMoreTokens ():
											l_conversionOrderToken = l_conversionOrderTokenizer.nextToken ()
											if not (l_conversionOrderToken is None or l_conversionOrderToken == ""):
												l_csvItemsDelimiterCharacterCode = int (l_conversionOrderToken)
											if l_conversionOrderTokenizer.hasMoreTokens ():
												l_conversionOrderToken = l_conversionOrderTokenizer.nextToken ()
												if not (l_conversionOrderToken is None or l_conversionOrderToken == ""):
													l_csvTextItemQuotationCharacterCode = int (l_conversionOrderToken)
												if l_conversionOrderTokenizer.hasMoreTokens ():
													l_conversionOrderToken = l_conversionOrderTokenizer.nextToken ()
													if not (l_conversionOrderToken is None or l_conversionOrderToken == ""):
														l_csvCharactersEncodingCode = int (l_conversionOrderToken)
													if l_conversionOrderTokenizer.hasMoreTokens ():
														if l_conversionOrderTokenizer.nextToken () == "true":
															l_csvAllTextItemsAreQuoted = True
														if l_conversionOrderTokenizer.hasMoreTokens ():
															if l_conversionOrderTokenizer.nextToken () == "true":
																l_csvContentsAreExportedAsShown = True
															if l_conversionOrderTokenizer.hasMoreTokens ():
																if l_conversionOrderTokenizer.nextToken () == "true":
																	l_csvFormulaeThemselvesAreExported = True
																if l_conversionOrderTokenizer.hasMoreTokens ():
																	if l_conversionOrderTokenizer.nextToken () == "true":
																		l_hiddenSpreadSheetsAreWritten = True
								l_documentStoringProperties = FilesConverter.createCsvFileStoringProperties (l_csvItemsDelimiterCharacterCode, l_csvTextItemQuotationCharacterCode, l_csvCharactersEncodingCode, l_csvAllTextItemsAreQuoted, l_csvContentsAreExportedAsShown, l_csvFormulaeThemselvesAreExported)
						if not l_allSpreadSheetsAreWritten:
							if not (l_documentStoringProperties is None):
								if not (l_convertedFileUrl is None) and not (l_targetFileUrl is None):
									l_conversionHasSucceeded = l_filesConverter.convertFile (l_convertedFileUrl, l_openingPassword, l_targetFileUrl, l_documentStoringProperties, l_unoDocumentTailor)
						else:
							if not (l_convertedFileUrl is None) and not (l_targetFileUrl is None):
								l_conversionHasSucceeded = l_filesConverter.convertSpreadSheetsDocumentFileToCsvFiles (l_convertedFileUrl, l_openingPassword, l_targetFileUrl, l_documentStoringProperties, l_unoDocumentTailor, l_targetFileNamingRule, l_hiddenSpreadSheetsAreWritten)
					if not l_conversionHasSucceeded:
						if len (l_failedConversionOrderIndicesStringBuilder) == 0:
							None
						else:
				   	 		l_failedConversionOrderIndicesStringBuilder.append (",")
						l_failedConversionOrderIndicesStringBuilder.append ("{0:d}".format (l_conversionOrderIndex))
					l_conversionOrderIndex = l_conversionOrderIndex + 1
				l_conversionOrdersFile.close ()
				sys.stdout.write ("### The elapsed time is {0:,d} ns\n".format (PerformanceMeasurer.getElapseTimeInNanoSeconds ()))
				l_resultStatus = 0
				l_unoConnection.disconnect ()
		except (Exception) as l_exception:
			Publisher.logErrorInformation (l_exception)
			sys.exit (l_resultStatus)
		sys.exit (l_resultStatus)

if __name__ == "__main__":
	FilesConverterConsoleProgram.main (sys.argv)

