#include "theBiasPlanet/filesConverter/programs/FilesConverterConsoleProgram.hpp"
#include <ctime>
#include <iostream>
#include <exception>
#include <locale>
#include <optional>
#include <string>
#include <com/sun/star/container/XNamed.hpp>
#include <com/sun/star/sheet/XSpreadsheet.hpp>
#include <com/sun/star/sheet/XSpreadsheetDocument.hpp>
#include <com/sun/star/sheet/XSpreadsheets.hpp>
#include <com/sun/star/sheet/XSpreadsheetView.hpp>
#include <com/sun/star/uno/Any.hxx>
#include <com/sun/star/uno/Exception.hpp>
#include <com/sun/star/uno/Reference.hxx>
#include "theBiasPlanet/coreUtilities/collectionsHandling/ListsFactory.hpp"
#include "theBiasPlanet/coreUtilities/constantsGroups/GeneralConstantsConstantsGroup.hpp"
#include "theBiasPlanet/coreUtilities/messaging/Publisher.hpp"
#include "theBiasPlanet/coreUtilities/performanceMeasuring/PerformanceMeasurer.hpp"
#include "theBiasPlanet/unoUtilities/connectionsHandling/UnoConnection.hpp"
#include "theBiasPlanet/unoUtilities/connectionsHandling/UnoConnectionConnector.hpp"
#include "theBiasPlanet/unoUtilities/connectionsHandling/UnoObjectsContext.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/UnoDocumentStoringEnumerablePropertyNamesSet.hpp"
#include "theBiasPlanet/unoUtilities/filesConverting/FilesConverter.hpp"
#include "theBiasPlanet/unoUtilities/programsHandling/UnoProcessEnvironment.hpp"
#include "theBiasPlanet/unoUtilities/propertiesHandling/UnoPropertiesHandler.hpp"
#include "theBiasPlanet/unoUtilities/stringsHandling/UnoExtendedStringHandler.hpp"

using namespace ::std;
using namespace ::com::sun::star::container;
using namespace ::com::sun::star::sheet;
using namespace ::com::sun::star::uno;
using namespace ::theBiasPlanet::coreUtilities::collectionsHandling;
using namespace ::theBiasPlanet::coreUtilities::constantsGroups;
using namespace ::theBiasPlanet::coreUtilities::messaging;
using namespace ::theBiasPlanet::coreUtilities::performanceMeasuring;
using namespace ::theBiasPlanet::unoUtilities::connectionsHandling;
using namespace ::theBiasPlanet::unoUtilities::constantsGroups::propertyNamesSets;
using namespace ::theBiasPlanet::unoUtilities::filesConverting;
using namespace ::theBiasPlanet::unoUtilities::programsHandling;
using namespace ::theBiasPlanet::unoUtilities::propertiesHandling;
using namespace ::theBiasPlanet::unoUtilities::stringsHandling;

namespace theBiasPlanet {
	namespace filesConverter {
		namespace programs {
			FilesConverterConsoleProgram::UnoSpreadSheetsDocumentTailor::UnoSpreadSheetsDocumentTailor (Reference <UnoObjectsContext> a_unoObjectsContext, int a_targetSpreadSheetIndex) : UnoDocumentTailor (a_unoObjectsContext), i_targetSpreadSheetIndex (a_targetSpreadSheetIndex) {
			}
			
			bool FilesConverterConsoleProgram::UnoSpreadSheetsDocumentTailor::tailor (Reference <XComponent> a_unoDocumentInXComponent) {
				Reference <XSpreadsheetDocument> l_spreadSheetsDocumentInXSpreadsheetDocument (a_unoDocumentInXComponent, UNO_QUERY);
				if (!(l_spreadSheetsDocumentInXSpreadsheetDocument.is ())) {
					Publisher::logErrorInformation (string ("The document is not any spread sheet."));
					return false;
				}
				else {
					Reference <XIndexAccess> l_spreadSheetsInXIndexAccess (l_spreadSheetsDocumentInXSpreadsheetDocument->getSheets (), UNO_QUERY);
					try {
						Reference <XSpreadsheet> l_spreadSheetInXSpreadsheet (*((Reference <XSpreadsheet> *) ((l_spreadSheetsInXIndexAccess->getByIndex (i_targetSpreadSheetIndex)).getValue ())));
						Reference <XNamed> l_spreadSheetInXNamed (l_spreadSheetInXSpreadsheet, UNO_QUERY);
						(Reference <XSpreadsheets> (l_spreadSheetsInXIndexAccess, UNO_QUERY))->moveByName (l_spreadSheetInXNamed->getName (), (short) GeneralConstantsConstantsGroup::c_iterationStartingNumber);
						return true;
					}
					catch (Exception l_exception) {
						Publisher::logErrorInformation (UnoExtendedStringHandler::getString (l_exception.Message));
						return false;
					}
				}
				return true;
			}
			
			int FilesConverterConsoleProgram::main (int const & a_argumentsNumber, char const * const a_arguments []) {
				int l_resultStatus = -1;
				try {
					if (a_argumentsNumber != 5) {
						throw runtime_error ("The arguments have to be these.\nThe argument 1: the server URL like 'socket,host=localhost,port=2002,tcpNoDelay=1;urp;StarOffice.ComponentContext'\nThe argument 2: the URL of the file to be converted like 'file://${HOME}/myData/development/filesConverter/execution/FilesConverterTest.ods'\nThe argument 3: the URL of the target file  like 'file://${HOME}/myData/development/filesConverter/execution/FilesConverterTest.csv'\nThe argument 4: the filter name like 'Text - txt - csv (StarCalc)'");
					}
					string l_unoServerUrl = string (a_arguments [1]);
					string l_convertedFileUrl = string (a_arguments [2]);
					string l_targetFileUrl = string (a_arguments [3]);
					string l_filterName = string (a_arguments [4]);
					string l_title ("Test Title");
					string l_password = ("TestPassword");
					bool l_overwrites = true;
					list <string> l_documentStoringFilterSpecificPropertyNames;
					list <Any> l_documentStoringFilterSpecificPropertyValues;
					list <string> l_documentStoringFiltersCommonPropertyNames (ListsFactory::createList <string> (
						UnoDocumentStoringEnumerablePropertyNamesSet::c_filterName_String,
						UnoDocumentStoringEnumerablePropertyNamesSet::c_filterData_Object,
						UnoDocumentStoringEnumerablePropertyNamesSet::c_title_String,
						UnoDocumentStoringEnumerablePropertyNamesSet::c_password_String,
						UnoDocumentStoringEnumerablePropertyNamesSet::c_overwrites_Boolen
					));
					list <Any> l_documentStoringFiltersCommonPropertyValues = ListsFactory::createList <Any> (
						Any (UnoExtendedStringHandler::getOustring (l_filterName)),
						Any (UnoPropertiesHandler::buildPropertiesSequence (l_documentStoringFilterSpecificPropertyNames, l_documentStoringFilterSpecificPropertyValues)),
						Any (UnoExtendedStringHandler::getOustring (l_title)),
						Any (UnoExtendedStringHandler::getOustring (l_password)),
						Any (l_overwrites)
					);
					Sequence <PropertyValue> l_documentStoringPropertiesSequence = UnoPropertiesHandler::buildPropertiesSequence (l_documentStoringFiltersCommonPropertyNames, l_documentStoringFiltersCommonPropertyValues);
					UnoProcessEnvironment l_localUnoProcessEnvironment = UnoProcessEnvironment (StringHandler::getDateAndTimeString (time (nullptr)));
					UnoConnectionConnector l_unoConnectionConnector = UnoConnectionConnector (l_localUnoProcessEnvironment.getLocalObjectsContext ());
					Reference <UnoConnection> l_unoConnection = l_unoConnectionConnector.connect (l_unoServerUrl , nullopt);
					Reference <UnoObjectsContext> l_remoteUnoObjectsContext = l_unoConnection->getRemoteObjectsContext ();
					FilesConverter l_filesConverter (l_remoteUnoObjectsContext);
					UnoSpreadSheetsDocumentTailor l_unoDocumentTailor (UnoSpreadSheetsDocumentTailor (l_remoteUnoObjectsContext, 1));
					PerformanceMeasurer::setStartTime ();
					if (l_filesConverter.convertFile (l_convertedFileUrl, l_targetFileUrl, l_documentStoringPropertiesSequence, &l_unoDocumentTailor)) {
						cout << StringHandler::format ("### The elapsed time is %s ns.", StringHandler::getThousandsSeparatedLongString (PerformanceMeasurer::getElapseTimeInNanoSeconds ())) <<  endl << flush;
						l_resultStatus = 0;
					}
					else {
					}
					l_unoConnection->disconnect ();
				}
				catch (Exception & l_exception) {
					Publisher::logErrorInformation (UnoExtendedStringHandler::getString (l_exception.Message));
					exit (l_resultStatus);
				}
				catch (exception & l_exception) {
					Publisher::logErrorInformation (l_exception);
					exit (l_resultStatus);
				}
				exit (l_resultStatus);
			}
		}
	}
}

