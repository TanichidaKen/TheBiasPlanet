#include "theBiasPlanet/filesConverter/programs/FilesConverterConsoleProgram.hpp"
#include <ctime>
#include <iostream>
#include <exception>
#include <fstream>
#include <locale>
#include <map>
#include <optional>
#include <string>
#include <com/sun/star/uno/Any.hxx>
#include <com/sun/star/uno/Exception.hpp>
#include <com/sun/star/uno/Reference.hxx>
#include "theBiasPlanet/coreUtilities/collectionsHandling/ListsFactory.hpp"
#include "theBiasPlanet/coreUtilities/constantsGroups/GeneralConstantsConstantsGroup.hpp"
#include "theBiasPlanet/coreUtilities/cryptography/Hasher.hpp"
#include "theBiasPlanet/coreUtilities/messaging/Publisher.hpp"
#include "theBiasPlanet/coreUtilities/performanceMeasuring/PerformanceMeasurer.hpp"
#include "theBiasPlanet/coreUtilities/stringsHandling/StringHandler.hpp"
#include "theBiasPlanet/coreUtilities/stringsHandling/StringTokenizer.hpp"
#include "theBiasPlanet/unoUtilities/connectionsHandling/UnoConnection.hpp"
#include "theBiasPlanet/unoUtilities/connectionsHandling/UnoConnectionConnector.hpp"
#include "theBiasPlanet/unoUtilities/connectionsHandling/UnoObjectsContext.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/UnoCharactersEncodingCodesConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/UnoFileStoringFilterNamesConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/UnoDocumentStoringEnumerablePropertyNamesSet.hpp"
#include "theBiasPlanet/unoUtilities/documentsHandling/UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor.hpp"
#include "theBiasPlanet/unoUtilities/cryptography/MicrosoftPasswordsHasher.hpp"
#include "theBiasPlanet/unoUtilities/filesConverting/FilesConverter.hpp"
#include "theBiasPlanet/unoUtilities/programsHandling/UnoProcessEnvironment.hpp"
#include "theBiasPlanet/unoUtilities/propertiesHandling/UnoPropertiesHandler.hpp"
#include "theBiasPlanet/unoUtilities/stringsHandling/UnoExtendedStringHandler.hpp"
#include "theBiasPlanet/unoUtilities/unoDataHandling/UnoDatumConverter.hpp"

using namespace ::std;
using namespace ::com::sun::star::container;
using namespace ::com::sun::star::uno;
using namespace ::theBiasPlanet::coreUtilities::collectionsHandling;
using namespace ::theBiasPlanet::coreUtilities::constantsGroups;
using namespace ::theBiasPlanet::coreUtilities::cryptography;
using namespace ::theBiasPlanet::coreUtilities::messaging;
using namespace ::theBiasPlanet::coreUtilities::performanceMeasuring;
using namespace ::theBiasPlanet::coreUtilities::stringsHandling;
using namespace ::theBiasPlanet::unoUtilities::connectionsHandling;
using namespace ::theBiasPlanet::unoUtilities::constantsGroups;
using namespace ::theBiasPlanet::unoUtilities::constantsGroups::propertyNamesSets;
using namespace ::theBiasPlanet::unoUtilities::cryptography;
using namespace ::theBiasPlanet::unoUtilities::documentsHandling;
using namespace ::theBiasPlanet::unoUtilities::filesConverting;
using namespace ::theBiasPlanet::unoUtilities::programsHandling;
using namespace ::theBiasPlanet::unoUtilities::propertiesHandling;
using namespace ::theBiasPlanet::unoUtilities::stringsHandling;
using namespace ::theBiasPlanet::unoUtilities::unoDataHandling;

namespace theBiasPlanet {
	namespace filesConverter {
		namespace programs {
			int FilesConverterConsoleProgram::main (int const & a_argumentsNumber, char const * const a_argumentsArray []) {
				int l_resultStatus = -1;
				try {
					if (a_argumentsNumber < 3) {
						throw runtime_error ("The arguments have to be these.\nThe argument 1: the server URL like 'socket,host=localhost,port=2002,tcpNoDelay=1;urp;StarOffice.ComponentContext'\nThe argument 2: the path of the conversion orders CSV file\n");
					}
					string l_unoServerUrl = string (a_argumentsArray [1]);
					string l_conversionOrdersFilePath = string (a_argumentsArray [2]);
					int l_conversionOrderIndex =  GeneralConstantsConstantsGroup::c_iterationStartingNumber;
					string l_conversionOrder ("");
					string l_failedConversionOrderIndices ("");
					bool l_overwrites = true;
					string l_convertedFileUrl ("");
					string l_targetFileUrl ("");
					string l_filterName ("");
					optional <string> l_openingPassword = nullopt;
					optional <string> l_title = nullopt;
					optional <string> l_encryptingPassword = nullopt;
					optional <string> l_editingPassword = nullopt;
					list <string> l_editingPasswordInformationPropertyNames = ListsFactory::createList <string> (string ("algorithm-name"), string ("salt"), string ("iteration-count"), string ("hash"));
					int const l_saltLength = 16;
					unsigned char l_salt [l_saltLength];
					Hasher::createSalt (l_salt, l_saltLength);
					int const l_numberOfIterationForHashing = 100000;
					int const l_editingPasswordHashLength = 16;
					unsigned char l_editingPasswordHash [l_editingPasswordHashLength];
					list <Any> l_editingPasswordInformationPropertyValues;
					Sequence <PropertyValue> l_editingPasswordInformationSequence;
					long l_editingPasswordMicrosoftHash = GeneralConstantsConstantsGroup::c_anyUnspecifiedInteger;
					Any l_editingPasswordInformation;
					list <string> l_documentStoringFilterDataInPropertiesSequencePropertyNames;
					list <Any> l_documentStoringFilterDataInPropertiesSequencePropertyValues;
					optional <string> l_documentStoringFilterDataInStringValue = nullopt;
					Sequence <PropertyValue> l_documentStoringPropertiesSequence;
					optional <string> l_unoDocumentTailorName = nullopt;
					UnoDocumentTailor const * l_unoDocumentTailor = nullptr;
					bool l_allSpreadSheetsAreWritten = false;
					int l_targetFileNamingRule = 0;
					//int l_csvItemsDelimiterCharacterCode = '\t';
					int l_csvItemsDelimiterCharacterCode = ',';
					int l_csvTextItemQuotationCharacterCode = '"';
					int l_csvCharactersEncodingCode = UnoCharactersEncodingCodesConstantsGroup::c_utf8; // 76: UTF-8, 65535: UCS-2, 65534: UCS-4, 11: US-ASCII, 69: EUC_JP, 64: SHIFT_JIS
					//bool l_csvAllTextItemsAreQuoted = true;
					bool l_csvAllTextItemsAreQuoted = false;
					//bool l_csvContentsAreExportedAsShown = true;
					bool l_csvContentsAreExportedAsShown = false;
					bool l_csvFormulaeThemselvesAreExported = false;
					bool l_hiddenSpreadSheetsAreWritten = false;
					UnoProcessEnvironment l_localUnoProcessEnvironment = UnoProcessEnvironment (StringHandler::getDateAndTimeString (time (nullptr)));
					UnoConnectionConnector l_unoConnectionConnector = UnoConnectionConnector (l_localUnoProcessEnvironment.getLocalObjectsContext ());
					Reference <UnoConnection> l_unoConnection = l_unoConnectionConnector.connect (l_unoServerUrl , nullopt);
					Reference <UnoObjectsContext> l_remoteUnoObjectsContext = l_unoConnection->getRemoteObjectsContext ();
					FilesConverter l_filesConverter (l_remoteUnoObjectsContext);
					map <string const, UnoDocumentTailor const *> l_unoDocumentTailorNameToUnoDocumentTailorMap = { {string ("UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor_1"), new UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor (l_remoteUnoObjectsContext, 1)}};
					PerformanceMeasurer::setStartTime ();
					ifstream l_conversionOrdersFile;
					l_conversionOrdersFile.open (l_conversionOrdersFilePath, ios::in);
					optional <string> l_conversionOrderToken = nullopt;
					bool l_conversionHasSucceeded = false;
					while (true) {
						l_conversionHasSucceeded = false;
						if (!getline (l_conversionOrdersFile, l_conversionOrder)) {
							break;
						}
						else {
							StringTokenizer l_conversionOrderTokenizer (l_conversionOrder, string (1, GeneralConstantsConstantsGroup::c_tabCharacter));
							if (l_conversionOrderTokenizer.countTokens () < 3) {
								Publisher::logErrorInformation (StringHandler::format (string ("The conversion order has to have at least these properties for the %d index order.\nThe property 1: the URL of the file to be converted like 'file://${HOME}/myData/development/filesConverter/execution/FilesConverterTest.ods'\nThe property 2: the URL of the target file  like 'file://${HOME}/myData/development/filesConverter/execution/FilesConverterTest.csv'\nThe property 3: the filter name like 'Text - txt - csv (StarCalc)'\n"), l_conversionOrderIndex));
							}	
							else {
								l_convertedFileUrl = StringHandler::effectuateEnvironmentVariables (*(l_conversionOrderTokenizer.nextToken ()));
								if (l_convertedFileUrl [GeneralConstantsConstantsGroup::c_iterationStartingNumber] == GeneralConstantsConstantsGroup::c_dataCommentLineStarter) {
									continue;
								}
								l_targetFileUrl = StringHandler::effectuateEnvironmentVariables (*(l_conversionOrderTokenizer.nextToken ()));
								l_filterName = *(l_conversionOrderTokenizer.nextToken ());
								l_openingPassword = nullopt;
								l_title = nullopt;
								l_encryptingPassword = nullopt;
								l_editingPassword = nullopt;
								/*
								l_editingPasswordHash = null;
								*/
								l_editingPasswordInformationPropertyValues = ListsFactory::createList <Any> ();
								l_editingPasswordInformationSequence = Sequence <PropertyValue> ();
								l_editingPasswordInformation = Any ();
								l_documentStoringFilterDataInPropertiesSequencePropertyNames = ListsFactory::createList <string> ();
								l_documentStoringFilterDataInPropertiesSequencePropertyValues = ListsFactory::createList <Any> ();
								l_documentStoringFilterDataInStringValue = nullopt;
								l_documentStoringPropertiesSequence = Sequence <PropertyValue> ();
								l_unoDocumentTailorName = nullopt;
								l_unoDocumentTailor = nullptr;
								l_allSpreadSheetsAreWritten = false;
								l_targetFileNamingRule = 0;
								//l_csvItemsDelimiterCharacterCode = '\t';
								l_csvItemsDelimiterCharacterCode = ',';
								l_csvTextItemQuotationCharacterCode = '"';
								l_csvCharactersEncodingCode = UnoCharactersEncodingCodesConstantsGroup::c_utf8; // 76: UTF-8, 65535: UCS-2, 65534: UCS-4, 11: US-ASCII, 69: EUC_JP, 64: SHIFT_JIS
								//l_csvAllTextItemsAreQuoted = true;
								l_csvAllTextItemsAreQuoted = false;
								//l_csvContentsAreExportedAsShown = true;
								l_csvContentsAreExportedAsShown = false;
								l_csvFormulaeThemselvesAreExported = false;
								l_hiddenSpreadSheetsAreWritten = false;
								// "The conversion order properties have to be these for the %d index order.\nThe property 4 (optional): the converted-from file password\nThe property 5 (optional): the UNO document tailor name\n"
								if (l_conversionOrderTokenizer.hasMoreTokens ()) {
									l_openingPassword = l_conversionOrderTokenizer.nextToken ();
									if (*l_openingPassword == GeneralConstantsConstantsGroup::c_emptyString) {
										l_openingPassword = nullopt;
									}
									if (l_conversionOrderTokenizer.hasMoreTokens ()) {
										l_unoDocumentTailorName = l_conversionOrderTokenizer.nextToken ();
										if (!(*l_unoDocumentTailorName == GeneralConstantsConstantsGroup::c_emptyString)) {
											try {
												l_unoDocumentTailor = l_unoDocumentTailorNameToUnoDocumentTailorMap.at (*l_unoDocumentTailorName);
											}
											catch (exception & l_exception) {
											}
										}
									}
								}
								if (!(l_filterName == UnoFileStoringFilterNamesConstantsGroup::c_csvFileFilterName)) {
									// "The conversion order properties have to be these for the %d index order.\nThe property 6 (optional): the document title\nThe property 7 (optional): the encrypting password\nThe property 8 (optional): the editing password\n"
									if (l_conversionOrderTokenizer.hasMoreTokens ()) {
										l_title = l_conversionOrderTokenizer.nextToken ();
										if (*l_title == GeneralConstantsConstantsGroup::c_emptyString) {
											l_title = nullopt;
										}
										if (l_conversionOrderTokenizer.hasMoreTokens ()) {
											l_encryptingPassword = l_conversionOrderTokenizer.nextToken ();
											if (*l_encryptingPassword == GeneralConstantsConstantsGroup::c_emptyString) {
												l_encryptingPassword = nullopt;
											}
											if (l_conversionOrderTokenizer.hasMoreTokens ()) {
												l_editingPassword = l_conversionOrderTokenizer.nextToken ();
												if (!(*l_editingPassword == GeneralConstantsConstantsGroup::c_emptyString)) {
													if (l_filterName != UnoFileStoringFilterNamesConstantsGroup::c_microsoftWord2007XmlFilterName && l_filterName != UnoFileStoringFilterNamesConstantsGroup::c_microsoftWord97FileFilterName && l_filterName != UnoFileStoringFilterNamesConstantsGroup::c_microsoftExcel2007XmlFilterName && l_filterName != UnoFileStoringFilterNamesConstantsGroup::c_microsoftExcel97FilterName) {
														
														
														Hasher::hashInPbkdf2 (l_editingPasswordHash, *l_editingPassword, l_salt, l_saltLength, l_numberOfIterationForHashing, l_editingPasswordHashLength);
														l_editingPasswordInformationPropertyValues = ListsFactory::createList <Any> (UnoDatumConverter::convertToUnoAnyDatum (string ("PBKDF2")), UnoDatumConverter::convertToUnoAnyDatum <unsigned char, sal_Int8> (l_salt, l_saltLength), UnoDatumConverter::convertToUnoAnyDatum ( (long) l_numberOfIterationForHashing), UnoDatumConverter::convertToUnoAnyDatum <unsigned char, sal_Int8> (l_editingPasswordHash, l_editingPasswordHashLength));
														l_editingPasswordInformationSequence = UnoPropertiesHandler::buildPropertiesSequence (l_editingPasswordInformationPropertyNames, l_editingPasswordInformationPropertyValues);
														l_editingPasswordInformation = UnoDatumConverter::convertToUnoAnyDatum <Sequence <PropertyValue>> (l_editingPasswordInformationSequence);
													}
													else {
														if (l_filterName == UnoFileStoringFilterNamesConstantsGroup::c_microsoftWord2007XmlFilterName || l_filterName == UnoFileStoringFilterNamesConstantsGroup::c_microsoftWord97FileFilterName || l_filterName == UnoFileStoringFilterNamesConstantsGroup::c_microsoftExcel2007XmlFilterName) {
															l_editingPasswordMicrosoftHash = MicrosoftPasswordsHasher::hashIn32bits (*l_editingPassword);
														}
														else {
															l_editingPasswordMicrosoftHash = MicrosoftPasswordsHasher::hashIn16bits (*l_editingPassword);
														}
														l_editingPasswordInformation = UnoDatumConverter::convertToUnoAnyDatum <long> (l_editingPasswordMicrosoftHash);
													}
												}
											}
										}
										/*
										l_documentStoringFilterDataInPropertiesSequencePropertyNames = ListsFactory::createList <string> ();
										l_documentStoringFilterDataInPropertiesSequencePropertyValues = ListsFactory::createList <Any> ();
										l_documentStoringFilterDataInStringValue = nullopt;
										*/
									}
									list <string> l_documentStoringPropertyNames (ListsFactory::createList <string> (
										UnoDocumentStoringEnumerablePropertyNamesSet::c_filterName_string,
										UnoDocumentStoringEnumerablePropertyNamesSet::c_filterData_any,
										UnoDocumentStoringEnumerablePropertyNamesSet::c_filterData_string,
										UnoDocumentStoringEnumerablePropertyNamesSet::c_title_string,
										UnoDocumentStoringEnumerablePropertyNamesSet::c_password_string,
										UnoDocumentStoringEnumerablePropertyNamesSet::c_editingPasswordInformation_any,
										UnoDocumentStoringEnumerablePropertyNamesSet::c_overwrites_boolen
									));
									list <Any> l_documentStoringPropertyValues = ListsFactory::createList <Any> (
										UnoDatumConverter::convertToUnoAnyDatum (l_filterName),
										UnoDatumConverter::convertToUnoAnyDatum (UnoPropertiesHandler::buildPropertiesSequence (l_documentStoringFilterDataInPropertiesSequencePropertyNames, l_documentStoringFilterDataInPropertiesSequencePropertyValues)),
										UnoDatumConverter::convertToUnoAnyDatum (l_documentStoringFilterDataInStringValue),
										UnoDatumConverter::convertToUnoAnyDatum (l_title),
										UnoDatumConverter::convertToUnoAnyDatum (l_encryptingPassword),
										l_editingPasswordInformation,
										UnoDatumConverter::convertToUnoAnyDatum (l_overwrites)
									);
									l_documentStoringPropertiesSequence = UnoPropertiesHandler::buildPropertiesSequence (l_documentStoringPropertyNames, l_documentStoringPropertyValues);
								}
								else {
									// "The conversion order properties have to be these for the %d index order.\nThe property 6 (optional): the converted-from file password\nThe property 7 (valid only for the CSV filter, and optional): whether all the spread sheets are written ('true' or else)\nThe property 8 (valid only for the CSV filter, and optional): the CSV file naming rule ('0' -&gt; augmented by the sheet index, '1' -&gt; augmented by the sheet name)\nThe property 9 (valid only for the CSV filter, and optional): the items delimiter character code\nThe property 10 (valid only for the CSV filter, and optional): the text item quotation character code\nThe property 11 (valid only for the CSV filter, and optional): the encoding code\nThe property 12 (valid only for the CSV filter, and optional): whether all the text items are quoted\nThe property 13 (valid only for the CSV filter, and optional): whether the contents are exported as shown\nThe property 14 (valid only for the CSV filter, and optional): whether the formula themselves are exported\nThe property 15 (valid only for the CSV filter, and optional): whether the hidden sheets are written\n", l_conversionOrderIndex));
									if (l_conversionOrderTokenizer.hasMoreTokens ()) {
										if (l_conversionOrderTokenizer.nextToken () == string ("true")) {
											l_allSpreadSheetsAreWritten = true;
										}
										if (l_conversionOrderTokenizer.hasMoreTokens ()) {
											l_conversionOrderToken = l_conversionOrderTokenizer.nextToken ();
											if (l_conversionOrderToken != GeneralConstantsConstantsGroup::c_emptyString) {
												l_targetFileNamingRule = stoi (*(l_conversionOrderToken));
											}
											if (l_conversionOrderTokenizer.hasMoreTokens ()) {
												l_conversionOrderToken = l_conversionOrderTokenizer.nextToken ();
												if (l_conversionOrderToken != GeneralConstantsConstantsGroup::c_emptyString) {
													l_csvItemsDelimiterCharacterCode = stoi (*(l_conversionOrderToken));
												}
												if (l_conversionOrderTokenizer.hasMoreTokens ()) {
													l_conversionOrderToken = l_conversionOrderTokenizer.nextToken ();
													if (l_conversionOrderToken != GeneralConstantsConstantsGroup::c_emptyString) {
														l_csvTextItemQuotationCharacterCode = stoi (*(l_conversionOrderToken));
													}
													if (l_conversionOrderTokenizer.hasMoreTokens ()) {
														l_conversionOrderToken = l_conversionOrderTokenizer.nextToken ();
														if (l_conversionOrderToken != GeneralConstantsConstantsGroup::c_emptyString) {
															l_csvCharactersEncodingCode = stoi (*(l_conversionOrderToken));
														}
														if (l_conversionOrderTokenizer.hasMoreTokens ()) {
															if (*(l_conversionOrderTokenizer.nextToken ()) == string ("true")) {
																l_csvAllTextItemsAreQuoted = true;
															}
															if (l_conversionOrderTokenizer.hasMoreTokens ()) {
																if (*(l_conversionOrderTokenizer.nextToken ()) == string ("true")) {
																	l_csvContentsAreExportedAsShown = true;
																}
																if (l_conversionOrderTokenizer.hasMoreTokens ()) {
																	if (*(l_conversionOrderTokenizer.nextToken ()) == string ("true")) {
																		l_csvFormulaeThemselvesAreExported = true;
																	}
																	if (l_conversionOrderTokenizer.hasMoreTokens ()) {
																		if (*(l_conversionOrderTokenizer.nextToken ()) == string ("true")) {
																			l_hiddenSpreadSheetsAreWritten = true;
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
									l_documentStoringPropertiesSequence = FilesConverter::createCsvFileStoringPropertiesSequence (l_csvItemsDelimiterCharacterCode, l_csvTextItemQuotationCharacterCode, l_csvCharactersEncodingCode, l_csvAllTextItemsAreQuoted, l_csvContentsAreExportedAsShown, l_csvFormulaeThemselvesAreExported);
								}
							}
							if (!l_allSpreadSheetsAreWritten) {
								l_conversionHasSucceeded = l_filesConverter.convertFile (l_convertedFileUrl, l_encryptingPassword, l_targetFileUrl, l_documentStoringPropertiesSequence, l_unoDocumentTailor);
							}
							else {
								l_conversionHasSucceeded = l_filesConverter.convertSpreadSheetsDocumentFileToCsvFiles (l_convertedFileUrl, l_encryptingPassword, l_targetFileUrl, l_documentStoringPropertiesSequence, l_unoDocumentTailor, l_targetFileNamingRule, l_hiddenSpreadSheetsAreWritten);
							}
						}
						if (!l_conversionHasSucceeded) {
							if (l_failedConversionOrderIndices.length () == 0) {
							}
							else {
						   	 l_failedConversionOrderIndices.append (",");
							}
							l_failedConversionOrderIndices.append (StringHandler::format ("%d", l_conversionOrderIndex));
						}
						l_conversionOrderIndex ++;
					}
					for (pair <string const, UnoDocumentTailor const *> const & l_unoDocumentTailorNameToUnoDocumentTailorMapEntry : l_unoDocumentTailorNameToUnoDocumentTailorMap) {
						delete l_unoDocumentTailorNameToUnoDocumentTailorMapEntry.second;
					}
					l_conversionOrdersFile.close ();
					cout << StringHandler::format ("### The elapsed time is %s ns.", StringHandler::getThousandsSeparatedLongString (PerformanceMeasurer::getElapseTimeInNanoSeconds ())) <<  endl << flush;
					l_resultStatus = 0;
					l_unoConnection->disconnect ();
				}
				catch (Exception & l_exception) {
					Publisher::logErrorInformation (UnoExtendedStringHandler::getString (l_exception.Message));
					exit (l_resultStatus);
				}
				catch (exception & l_exception) {
					Publisher::logErrorInformation (l_exception);
					exit (l_resultStatus);
				}
				exit (l_resultStatus);
			}
		}
	}
}

