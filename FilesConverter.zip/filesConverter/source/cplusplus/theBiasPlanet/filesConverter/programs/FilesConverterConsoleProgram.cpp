#include "theBiasPlanet/filesConverter/programs/FilesConverterConsoleProgram.hpp"
#include <ctime>
#include <iostream>
#include <exception>
#include <locale>
#include <optional>
#include <string>
#include <com/sun/star/uno/Any.hxx>
#include <com/sun/star/uno/Reference.hxx>
#include "theBiasPlanet/coreUtilities/collectionsHandling/ListsFactory.hpp"
#include "theBiasPlanet/coreUtilities/messaging/Publisher.hpp"
#include "theBiasPlanet/coreUtilities/performanceMeasuring/PerformanceMeasurer.hpp"
#include "theBiasPlanet/unoUtilities/connectionsHandling/UnoConnection.hpp"
#include "theBiasPlanet/unoUtilities/connectionsHandling/UnoConnectionConnector.hpp"
#include "theBiasPlanet/unoUtilities/connectionsHandling/UnoObjectsContext.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/UnoDocumentStoringEnumerablePropertyNamesSet.hpp"
#include "theBiasPlanet/unoUtilities/filesConverting/FilesConverter.hpp"
#include "theBiasPlanet/unoUtilities/programsHandling/UnoProcessEnvironment.hpp"
#include "theBiasPlanet/unoUtilities/propertiesHandling/UnoPropertiesHandler.hpp"
#include "theBiasPlanet/unoUtilities/stringsHandling/UnoExtendedStringHandler.hpp"

using namespace ::std;
using namespace ::com::sun::star::uno;
using namespace ::theBiasPlanet::coreUtilities::collectionsHandling;
using namespace ::theBiasPlanet::coreUtilities::messaging;
using namespace ::theBiasPlanet::coreUtilities::performanceMeasuring;
using namespace ::theBiasPlanet::unoUtilities::connectionsHandling;
using namespace ::theBiasPlanet::unoUtilities::constantsGroups::propertyNamesSets;
using namespace ::theBiasPlanet::unoUtilities::filesConverting;
using namespace ::theBiasPlanet::unoUtilities::programsHandling;
using namespace ::theBiasPlanet::unoUtilities::propertiesHandling;
using namespace ::theBiasPlanet::unoUtilities::stringsHandling;

namespace theBiasPlanet {
	namespace filesConverter {
		namespace programs {
			int FilesConverterConsoleProgram::main (int const & a_argumentsNumber, char const * const a_arguments []) {
				try {
					if (a_argumentsNumber != 5) {
						throw runtime_error ("The arguments have to be these.\nThe argument 1: the server URL like 'socket,host=localhost,port=2002,tcpNoDelay=1;urp;StarOffice.ComponentContext'\nThe argument 2: the URL of the file to be converted like 'file://${HOME}/myData/development/filesConverter/execution/FilesConverterTest.odt'\nThe argument 3: the URL of the target file  like 'file://${HOME}/myData/development/filesConverter/execution/FilesConverterTest.doc'\nThe argument 4: the filter name like 'MS Word 97'");
					}
					string l_unoServerUrl = string (a_arguments [1]);
					string l_convertedFileUrl = string (a_arguments [2]);
					string l_targetFileUrl = string (a_arguments [3]);
					string l_filterName = string (a_arguments [4]);
					string l_title ("Test Title");
					string l_password = ("TestPassword");
					bool l_overwrites = true;
					list <string> l_documentStoringFilterSpecificPropertyNames;
					list <Any> l_documentStoringFilterSpecificPropertyValues;
					list <string> l_documentStoringFiltersCommonPropertyNames (ListsFactory::createList <string> (
						UnoDocumentStoringEnumerablePropertyNamesSet::c_filterName_String,
						UnoDocumentStoringEnumerablePropertyNamesSet::c_filterData_Object,
						UnoDocumentStoringEnumerablePropertyNamesSet::c_title_String,
						UnoDocumentStoringEnumerablePropertyNamesSet::c_password_String,
						UnoDocumentStoringEnumerablePropertyNamesSet::c_overwrites_Boolen
					));
					list <Any> l_documentStoringFiltersCommonPropertyValues = ListsFactory::createList <Any> (
						Any (UnoExtendedStringHandler::getOustring (l_filterName)),
						Any (UnoPropertiesHandler::buildPropertiesSequence (l_documentStoringFilterSpecificPropertyNames, l_documentStoringFilterSpecificPropertyValues)),
						Any (UnoExtendedStringHandler::getOustring (l_title)),
						Any (UnoExtendedStringHandler::getOustring (l_password)),
						Any (l_overwrites)
					);
					Sequence <PropertyValue> l_documentStoringPropertiesSequence = UnoPropertiesHandler::buildPropertiesSequence (l_documentStoringFiltersCommonPropertyNames, l_documentStoringFiltersCommonPropertyValues);
					UnoProcessEnvironment l_localUnoProcessEnvironment = UnoProcessEnvironment (StringHandler::getDateAndTimeString (time (nullptr)));
					UnoConnectionConnector l_unoConnectionConnector = UnoConnectionConnector (l_localUnoProcessEnvironment.getLocalObjectsContext ());
					Reference <UnoConnection> l_unoConnection = l_unoConnectionConnector.connect (l_unoServerUrl , nullopt);
					Reference <UnoObjectsContext> l_remoteUnoObjectsContext = l_unoConnection->getRemoteObjectsContext ();
					FilesConverter l_filesConverter (l_remoteUnoObjectsContext);
					PerformanceMeasurer::setStartTime ();
					l_filesConverter.convertFile (l_convertedFileUrl, l_targetFileUrl, l_documentStoringPropertiesSequence);
					cout << StringHandler::format ("### The elapsed time is %s ns.", StringHandler::getThousandsSeparatedLongString (PerformanceMeasurer::getElapseTimeInNanoSeconds ())) <<  endl << flush;
					l_unoConnection->disconnect ();
				}
				catch (exception & l_exception) {
					Publisher::logErrorInformation (l_exception);
					exit (1);
				}
				exit (0);
			}
		}
	}
}

