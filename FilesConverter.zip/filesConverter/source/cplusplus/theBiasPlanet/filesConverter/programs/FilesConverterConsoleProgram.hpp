#ifndef __theBiasPlanet_filesConverter_programs_FilesConverterConsoleProgram_hpp__
#define __theBiasPlanet_filesConverter_programs_FilesConverterConsoleProgram_hpp__

namespace theBiasPlanet {
	namespace filesConverter {
		namespace programs {
			class FilesConverterConsoleProgram {
				public:
					static int main (int const & a_argumentsNumber, char const * const a_arguments []);
			};
		}
	}
}

#endif

