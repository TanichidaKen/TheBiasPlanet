namespace theBiasPlanet {
	namespace filesConverter {
		namespace programs {
			using System;
			using System.Collections.Generic;
			using System.IO;
			using System.Text;
			using uno;
			using unoidl.com.sun.star.beans;
			using theBiasPlanet.coreUtilities.collectionsHandling;
			using theBiasPlanet.coreUtilities.constantsGroups;
			using theBiasPlanet.coreUtilities.cryptography;
			using theBiasPlanet.coreUtilities.messaging;
			using theBiasPlanet.coreUtilities.programsHandling;
			using theBiasPlanet.coreUtilities.performanceMeasuring;
			using theBiasPlanet.coreUtilities.stringsHandling;
			using theBiasPlanet.unoUtilities.connectionsHandling;
			using theBiasPlanet.unoUtilities.constantsGroups;
			using theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;
			using theBiasPlanet.unoUtilities.documentsHandling;
			using theBiasPlanet.unoUtilities.filesConverting;
			using theBiasPlanet.unoUtilities.programsHandling;
			using theBiasPlanet.unoUtilities.propertiesHandling;
			using theBiasPlanet.unoUtilities.unoDataHandling;
			
			public class FilesConverterConsoleProgram {
				static void Main (String [] a_argumentsArray) {
					int l_resultStatus = -1;
					try {
						if (a_argumentsArray.Length < 2) {
							throw new Exception ("The arguments have to be these.\nThe argument 1: the server URL like 'socket,host=localhost,port=2002,tcpNoDelay=1;urp;StarOffice.ComponentContext'\nThe argument 2: the path of the conversion orders CSV file\n");
						}
						String l_unoServerUrl = a_argumentsArray [0];
						String l_conversionOrdersFilePath = a_argumentsArray [1];
						int l_conversionOrderIndex =  GeneralConstantsConstantsGroup.c_iterationStartingNumber;
						String l_conversionOrder = null;
						StringBuilder l_failedConversionOrderIndicesStringBuilder = new StringBuilder ();
						bool l_overwrites = true;
						String l_convertedFileUrl = null;
						String l_targetFileUrl = null;
						String l_filterName = null;
						String l_openingPassword = null;
						String l_title = null;
						String l_encryptingPassword = null;
						String l_editingPassword = null;
						List <String> l_editingPasswordInformationPropertyNames = ListsFactory.createList <String> ("algorithm-name", "salt", "iteration-count", "hash");
						int l_saltLength = 16;
						byte [] l_salt = Hasher.createSalt (l_saltLength);
						int l_numberOfIterationForHashing = 100000;
						int l_editingPasswordHashLength = 16;
						byte [] l_editingPasswordHash = null;
						List <Any> l_editingPasswordInformationPropertyValues = null;
						PropertyValue [] l_editingPasswordInformationArray = null;
						List <String> l_documentStoringFilterDataInPropertiesArrayPropertyNames = ListsFactory.createList <String> ();
						List <Any> l_documentStoringFilterDataInPropertiesArrayPropertyValues = ListsFactory.createList <Any> ();
						String l_documentStoringFilterDataInStringValue = null;
						PropertyValue [] l_documentStoringPropertiesArray = null;
						String l_unoDocumentTailorName = null;
						UnoDocumentTailor l_unoDocumentTailor = null;
						bool l_allSpreadSheetsAreWritten = false;
						int l_targetFileNamingRule = 0;
						//int l_csvItemsDelimiterCharacterCode = (int) '\t';
						int l_csvItemsDelimiterCharacterCode = (int) ',';
						int l_csvTextItemQuotationCharacterCode = (int) '\"';
						int l_csvCharactersEncodingCode = UnoCharactersEncodingCodesConstantsGroup.c_utf8; // 76: UTF-8, 65535: UCS-2, 65534: UCS-4, 11: US-ASCII, 69: EUC_JP, 64: SHIFT_JIS
						//bool l_csvAllTextItemsAreQuoted = true;
						bool l_csvAllTextItemsAreQuoted = false;
						//bool l_csvContentsAreExportedAsShown = true;
						bool l_csvContentsAreExportedAsShown = false;
						bool l_csvFormulaeThemselvesAreExported = false;
						bool l_hiddenSpreadSheetsAreWritten = false;
						UnoProcessEnvironment l_localUnoProcessEnvironment = new UnoProcessEnvironment (DateTime.Now.ToString (), null);
						ProcessEnvironment.windowsSocketStartup ();
						UnoConnectionConnector l_unoConnectionConnector = new UnoConnectionConnector (l_localUnoProcessEnvironment.getLocalObjectsContext ());
						UnoConnection l_unoConnection = l_unoConnectionConnector.connect (l_unoServerUrl, null);
						UnoObjectsContext l_remoteUnoObjectsContext = l_unoConnection.getRemoteObjectsContext ();
						FilesConverter l_filesConverter = new FilesConverter (l_remoteUnoObjectsContext);
						IDictionary <String, UnoDocumentTailor> l_unoDocumentTailorNameToUnoDocumentTailorMap = MapsFactory.createNavigableLinkedHashMap <String, UnoDocumentTailor> ("UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor_1", new UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor (l_remoteUnoObjectsContext, 1));
						PerformanceMeasurer.setStartTime ();

						StreamReader l_conversionOrdersFileReader = new StreamReader (l_conversionOrdersFilePath);
						String l_conversionOrderToken = null;
						bool l_conversionHasSucceeded = false;
						while (true) {
							l_conversionHasSucceeded = false;
							l_conversionOrder = l_conversionOrdersFileReader.ReadLine ();
							if (l_conversionOrder == null) {
								break;
							}
							else {
								StringTokenizer l_conversionOrderTokenizer = new StringTokenizer (l_conversionOrder, new String (GeneralConstantsConstantsGroup.c_tabCharacter, 1));
								if (l_conversionOrderTokenizer.countTokens () < 3) {
									Publisher.logErrorInformation (String.Format ("The conversion order has to have at least these properties for the {0:d} index order.\nThe property 1: the URL of the file to be converted like 'file://${HOME}/myData/development/filesConverter/execution/FilesConverterTest.ods'\nThe property 2: the URL of the target file  like 'file://${HOME}/myData/development/filesConverter/execution/FilesConverterTest.csv'\nThe property 3: the filter name like 'Text - txt - csv (StarCalc)'\n", l_conversionOrderIndex));
								}	
								else {
									l_convertedFileUrl = StringHandler.effectuateEnvironmentVariables (l_conversionOrderTokenizer.nextToken ());
									l_targetFileUrl = StringHandler.effectuateEnvironmentVariables (l_conversionOrderTokenizer.nextToken ());
									l_filterName = l_conversionOrderTokenizer.nextToken ();
									l_openingPassword = null;
									l_title = null;
									l_encryptingPassword = null;
									l_editingPassword = null;
									l_editingPasswordHash = null;
									l_editingPasswordInformationPropertyValues = null;
									l_editingPasswordInformationArray = null;
									l_documentStoringFilterDataInPropertiesArrayPropertyNames = ListsFactory.createList <String> ();
									l_documentStoringFilterDataInPropertiesArrayPropertyValues = ListsFactory.createList <Any> ();
									l_documentStoringFilterDataInStringValue = null;
									l_documentStoringPropertiesArray = null;
									l_unoDocumentTailorName = null;
									l_unoDocumentTailor = null;
									l_allSpreadSheetsAreWritten = false;
									l_targetFileNamingRule = 0;
									//l_csvItemsDelimiterCharacterCode = (int) '\t';
									l_csvItemsDelimiterCharacterCode = (int) ',';
									l_csvTextItemQuotationCharacterCode = (int) '\"';
									l_csvCharactersEncodingCode = UnoCharactersEncodingCodesConstantsGroup.c_utf8; // 76: UTF-8, 65535: UCS-2, 65534: UCS-4, 11: US-ASCII, 69: EUC_JP, 64: SHIFT_JIS
									//l_csvAllTextItemsAreQuoted = true;
									l_csvAllTextItemsAreQuoted = false;
									//l_csvContentsAreExportedAsShown = true;
									l_csvContentsAreExportedAsShown = false;
									l_csvFormulaeThemselvesAreExported = false;
									l_hiddenSpreadSheetsAreWritten = false;
									// "The conversion order properties have to be these for the %d index order.\nThe property 4 (optional): the converted-from file password\nThe property 5 (optional): the UNO document tailor name\n"
									if (l_conversionOrderTokenizer.hasMoreTokens ()) {
										l_openingPassword = l_conversionOrderTokenizer.nextToken ();
										if (l_openingPassword == "") {
											l_openingPassword = null;
										}
										if (l_conversionOrderTokenizer.hasMoreTokens ()) {
											l_unoDocumentTailorName = l_conversionOrderTokenizer.nextToken ();
											if (!(l_unoDocumentTailorName == "")) {
												try {
													l_unoDocumentTailor = l_unoDocumentTailorNameToUnoDocumentTailorMap [l_unoDocumentTailorName];
												}
												catch (Exception l_exception) {
												}
											}
										}
									}
									if (!(l_filterName == UnoFileStoringFilterNamesConstantsGroup.c_csvFileFilterName)) {
										// "The conversion order properties have to be these for the %d index order.\nThe property 6 (optional): the document title\nThe property 7 (optional): the encrypting password\nThe property 8 (optional): the editing password\n"
										if (l_conversionOrderTokenizer.hasMoreTokens ()) {
											l_title = l_conversionOrderTokenizer.nextToken ();
											if (l_title == "") {
												l_title = null;
											}
											if (l_conversionOrderTokenizer.hasMoreTokens ()) {
												l_encryptingPassword = l_conversionOrderTokenizer.nextToken ();
												if (l_encryptingPassword == "") {
													l_encryptingPassword = null;
												}
												if (l_conversionOrderTokenizer.hasMoreTokens ()) {
													l_editingPassword = l_conversionOrderTokenizer.nextToken ();
													if (!(l_editingPassword == "")) {
														l_editingPasswordHash = Hasher.hashInPbkdf2 (l_editingPassword, l_salt, l_numberOfIterationForHashing, l_editingPasswordHashLength);
														l_editingPasswordInformationPropertyValues = ListsFactory.createList <Any> (UnoDatumConverter.getAny ("PBKDF2"), UnoDatumConverter.getAny (l_salt), UnoDatumConverter.getAny (l_numberOfIterationForHashing), UnoDatumConverter.getAny (l_editingPasswordHash));
														l_editingPasswordInformationArray = UnoPropertiesHandler.buildPropertiesArray (l_editingPasswordInformationPropertyNames, l_editingPasswordInformationPropertyValues);
													}
												}
											}
											/*
											l_documentStoringFilterDataInPropertiesArrayPropertyNames = ListsFactory. <String>createArrayList ();
											l_documentStoringFilterDataInPropertiesArrayPropertyValues = ListsFactory. <Object>createArrayList ();
											l_documentStoringFilterDataInStringValue = null;
											*/
										}
										List <String> l_documentStoringPropertyNames = ListsFactory.createList <String> (
											UnoDocumentStoringEnumerablePropertyNamesSet.c_filterName_string,
											UnoDocumentStoringEnumerablePropertyNamesSet.c_filterData_any,
											UnoDocumentStoringEnumerablePropertyNamesSet.c_filterData_string,
											UnoDocumentStoringEnumerablePropertyNamesSet.c_title_string,
											UnoDocumentStoringEnumerablePropertyNamesSet.c_password_string,
											UnoDocumentStoringEnumerablePropertyNamesSet.c_editingPasswordInformation_any,
											UnoDocumentStoringEnumerablePropertyNamesSet.c_overwrites_boolen
										);
										List <Any> l_documentStoringPropertyValues = ListsFactory.createList <Any> (
											UnoDatumConverter.getAny (l_filterName),
											UnoDatumConverter.getAny (UnoPropertiesHandler.buildPropertiesArray (l_documentStoringFilterDataInPropertiesArrayPropertyNames, l_documentStoringFilterDataInPropertiesArrayPropertyValues)),
											UnoDatumConverter.getAny (l_documentStoringFilterDataInStringValue),
											UnoDatumConverter.getAny (l_title),
											UnoDatumConverter.getAny (l_encryptingPassword),
											UnoDatumConverter.getAny (l_editingPasswordInformationArray),
											UnoDatumConverter.getAny (l_overwrites)
										);
										l_documentStoringPropertiesArray = UnoPropertiesHandler.buildPropertiesArray (l_documentStoringPropertyNames, l_documentStoringPropertyValues);
									}
									else {
										// "The conversion order properties have to be these for the %d index order.\nThe property 6 (optional): the converted-from file password\nThe property 7 (valid only for the CSV filter, and optional): whether all the spread sheets are written ('true' or else)\nThe property 8 (valid only for the CSV filter, and optional): the CSV file naming rule ('0' -&gt; augmented by the sheet index, '1' -&gt; augmented by the sheet name)\nThe property 9 (valid only for the CSV filter, and optional): the items delimiter character code\nThe property 10 (valid only for the CSV filter, and optional): the text item quotation character code\nThe property 11 (valid only for the CSV filter, and optional): the encoding code\nThe property 12 (valid only for the CSV filter, and optional): whether all the text items are quoted\nThe property 13 (valid only for the CSV filter, and optional): whether the contents are exported as shown\nThe property 14 (valid only for the CSV filter, and optional): whether the formula themselves are exported\nThe property 15 (valid only for the CSV filter, and optional): whether the hidden sheets are written\n", l_conversionOrderIndex));
										if (l_conversionOrderTokenizer.hasMoreTokens ()) {
											if (l_conversionOrderTokenizer.nextToken () == "true") {
												l_allSpreadSheetsAreWritten = true;
											}
											if (l_conversionOrderTokenizer.hasMoreTokens ()) {
												l_conversionOrderToken = l_conversionOrderTokenizer.nextToken ();
												if (l_conversionOrderToken != "") {
													l_targetFileNamingRule = int.Parse (l_conversionOrderToken);
												}
												if (l_conversionOrderTokenizer.hasMoreTokens ()) {
													l_conversionOrderToken = l_conversionOrderTokenizer.nextToken ();
													if (l_conversionOrderToken != "") {
														l_csvItemsDelimiterCharacterCode = int.Parse (l_conversionOrderToken);
													}
													if (l_conversionOrderTokenizer.hasMoreTokens ()) {
														l_conversionOrderToken = l_conversionOrderTokenizer.nextToken ();
														if (l_conversionOrderToken != "") {
															l_csvTextItemQuotationCharacterCode = int.Parse (l_conversionOrderToken);
														}
														if (l_conversionOrderTokenizer.hasMoreTokens ()) {
															l_conversionOrderToken = l_conversionOrderTokenizer.nextToken ();
															if (l_conversionOrderToken != "") {
																l_csvCharactersEncodingCode = int.Parse (l_conversionOrderToken);
															}
															if (l_conversionOrderTokenizer.hasMoreTokens ()) {
																if (l_conversionOrderTokenizer.nextToken () == "true") {
																	l_csvAllTextItemsAreQuoted = true;
																}
																if (l_conversionOrderTokenizer.hasMoreTokens ()) {
																	if (l_conversionOrderTokenizer.nextToken () == "true") {
																		l_csvContentsAreExportedAsShown = true;
																	}
																	if (l_conversionOrderTokenizer.hasMoreTokens ()) {
																		if (l_conversionOrderTokenizer.nextToken () == "true") {
																			l_csvFormulaeThemselvesAreExported = true;
																		}
																		if (l_conversionOrderTokenizer.hasMoreTokens ()) {
																			if (l_conversionOrderTokenizer.nextToken () == "true") {
																				l_hiddenSpreadSheetsAreWritten = true;
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
										l_documentStoringPropertiesArray = FilesConverter.createCsvFileStoringPropertiesArray (l_csvItemsDelimiterCharacterCode, l_csvTextItemQuotationCharacterCode, l_csvCharactersEncodingCode, l_csvAllTextItemsAreQuoted, l_csvContentsAreExportedAsShown, l_csvFormulaeThemselvesAreExported);
									}
								}
								if (!l_allSpreadSheetsAreWritten) {
									l_conversionHasSucceeded = l_filesConverter.convertFile (l_convertedFileUrl, l_openingPassword, l_targetFileUrl, l_documentStoringPropertiesArray, l_unoDocumentTailor);
								}
								else {
									l_conversionHasSucceeded = l_filesConverter.convertSpreadSheetsDocumentFileToCsvFiles (l_convertedFileUrl, l_openingPassword, l_targetFileUrl, l_documentStoringPropertiesArray, l_unoDocumentTailor, l_targetFileNamingRule, l_hiddenSpreadSheetsAreWritten);
								}
							}
							if (!l_conversionHasSucceeded) {
								if (l_failedConversionOrderIndicesStringBuilder.Length == 0) {
								}
								else {
							   	 	l_failedConversionOrderIndicesStringBuilder.Append (",");
								}
								l_failedConversionOrderIndicesStringBuilder.Append (String.Format ("{0:d}", l_conversionOrderIndex));
							}
							l_conversionOrderIndex ++;
						}
						l_conversionOrdersFileReader.Close ();
						Console.Out.WriteLine (String.Format ("### The elapsed time is {0:n0} ns", PerformanceMeasurer.getElapseTimeInNanoSeconds ()));
						l_resultStatus = 0;
						l_unoConnection.disconnect ();
						ProcessEnvironment.windowsSocketCleanup ();
					}
					catch (Exception l_exception) {
						Publisher.logErrorInformation (l_exception);
						Environment.Exit (l_resultStatus);
					}
					Environment.Exit (l_resultStatus);
				}
			}
		}
	}
}

