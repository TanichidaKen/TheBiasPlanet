namespace theBiasPlanet {
	namespace filesConverter {
		namespace programs {
			using System;
			using System.Collections.Generic;
			using uno;
			using unoidl.com.sun.star.beans;
			using unoidl.com.sun.star.container;
			using unoidl.com.sun.star.frame;
			using unoidl.com.sun.star.lang;
			using unoidl.com.sun.star.sheet;
			using theBiasPlanet.coreUtilities.collectionsHandling;
			using theBiasPlanet.coreUtilities.constantsGroups;
			using theBiasPlanet.coreUtilities.messaging;
			using theBiasPlanet.coreUtilities.programsHandling;
			using theBiasPlanet.coreUtilities.performanceMeasuring;
			using theBiasPlanet.unoUtilities.connectionsHandling;
			using theBiasPlanet.unoUtilities.constantsGroups;
			using theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;
			using theBiasPlanet.unoUtilities.documentsHandling;
			using theBiasPlanet.unoUtilities.filesConverting;
			using theBiasPlanet.unoUtilities.programsHandling;
			using theBiasPlanet.unoUtilities.propertiesHandling;
			
			public class FilesConverterConsoleProgram {
				private class UnoSpreadSheetsDocumentTailor : UnoDocumentTailor {
					private int i_targetSpreadSheetIndex;
					
					public UnoSpreadSheetsDocumentTailor (UnoObjectsContext a_objectsContext, int a_targetSpreadSheetIndex) : base (a_objectsContext) {
						i_targetSpreadSheetIndex = a_targetSpreadSheetIndex;
					}
					
					public override bool tailor (XComponent a_unoDocumentInXComponent) {
						XSpreadsheetDocument l_spreadSheetsDocumentInXSpreadsheetDocument = (XSpreadsheetDocument) a_unoDocumentInXComponent;
						if (l_spreadSheetsDocumentInXSpreadsheetDocument == null) {
							Publisher.logErrorInformation ("The document is not any spread sheet.");
							return false;
						}
						else {
							XIndexAccess l_spreadSheetsInXIndexAccess = (XIndexAccess) l_spreadSheetsDocumentInXSpreadsheetDocument.getSheets ();
							try {
								XSpreadsheet l_spreadSheetInXSpreadsheet = (XSpreadsheet) (((Any) l_spreadSheetsInXIndexAccess.getByIndex (i_targetSpreadSheetIndex)).Value);
								XNamed l_spreadSheetInXNamed = (XNamed) l_spreadSheetInXSpreadsheet;
								((XSpreadsheets) l_spreadSheetsInXIndexAccess).moveByName (l_spreadSheetInXNamed.getName (), (short) GeneralConstantsConstantsGroup.c_iterationStartingNumber);
								return true;
							}
							catch (Exception l_exception) {
								Publisher.logErrorInformation (l_exception);
								return false;
							}
						}
					}
				}
				
				static void Main (String [] a_argumentsArray) {
					int l_resultStatus = -1;
					try {
						if (a_argumentsArray.Length != 4) {
							throw new Exception ("The arguments have to be these.\nThe argument 1: the server URL like 'socket,host=localhost,port=2002,tcpNoDelay=1;urp;StarOffice.ComponentContext'\nThe argument 2: the URL of the file to be converted like 'file://${HOME}/myData/development/filesConverter/execution/FilesConverterTest.ods'\nThe argument 3: the URL of the target file  like 'file://${HOME}/myData/development/filesConverter/execution/FilesConverterTest.csv'\nThe argument 4: the filter name like 'Text - txt - csv (StarCalc)'");
						}
						String l_unoServerUrl = a_argumentsArray [0];
						String l_convertedFileUrl = a_argumentsArray [1];
						String l_targetFileUrl = a_argumentsArray [2];
						String l_filterName = a_argumentsArray [3];
						String l_title = "Test Title";
						String l_password = "TestPassword";
						bool l_overwrites = true;
						List <String> l_documentStoringFilterSpecificPropertyNames = ListsFactory.createList <String> ();
						List <Object> l_documentStoringFilterSpecificPropertyValues = ListsFactory.createList <Object> ();
						List <String> l_documentStoringFiltersCommonPropertyNames = ListsFactory.createList <String> (
							UnoDocumentStoringEnumerablePropertyNamesSet.c_filterName_String,
							UnoDocumentStoringEnumerablePropertyNamesSet.c_filterData_Object,
							UnoDocumentStoringEnumerablePropertyNamesSet.c_title_String,
							UnoDocumentStoringEnumerablePropertyNamesSet.c_password_String,
							UnoDocumentStoringEnumerablePropertyNamesSet.c_overwrites_Boolen
						);
						List <Object> l_documentStoringFiltersCommonPropertyValues = ListsFactory.createList <Object> (
							l_filterName,
							UnoPropertiesHandler.buildPropertiesArray (l_documentStoringFilterSpecificPropertyNames, l_documentStoringFilterSpecificPropertyValues),
							l_title,
							l_password,
							l_overwrites
						);
						PropertyValue [] l_documentStoringPropertiesArray = UnoPropertiesHandler.buildPropertiesArray (l_documentStoringFiltersCommonPropertyNames, l_documentStoringFiltersCommonPropertyValues);
						UnoProcessEnvironment l_localUnoProcessEnvironment = new UnoProcessEnvironment (DateTime.Now.ToString (), null);
						ProcessEnvironment.windowsSocketStartup ();
						UnoConnectionConnector l_unoConnectionConnector = new UnoConnectionConnector (l_localUnoProcessEnvironment.getLocalObjectsContext ());
						UnoConnection l_unoConnection = l_unoConnectionConnector.connect (l_unoServerUrl, null);
						UnoObjectsContext l_remoteUnoObjectsContext = l_unoConnection.getRemoteObjectsContext ();
						FilesConverter l_filesConverter = new FilesConverter (l_remoteUnoObjectsContext);
						UnoDocumentTailor l_unoDocumentTailor = new UnoSpreadSheetsDocumentTailor (l_remoteUnoObjectsContext, 1);
						PerformanceMeasurer.setStartTime ();
						if (l_filesConverter.convertFile (l_convertedFileUrl, l_targetFileUrl, l_documentStoringPropertiesArray, l_unoDocumentTailor)) {
							Console.Out.WriteLine (String.Format ("### The elapsed time is {0:n0} ns", PerformanceMeasurer.getElapseTimeInNanoSeconds ()));
							l_resultStatus = 0;
						}
						l_unoConnection.disconnect ();
						ProcessEnvironment.windowsSocketCleanup ();
					}
					catch (Exception l_exception) {
						Publisher.logErrorInformation (l_exception);
						Environment.Exit (l_resultStatus);
					}
					Environment.Exit (l_resultStatus);
				}
			}
		}
	}
}

