from com.sun.star.beans import PropertyValue

class UnoProperty (PropertyValue):
	def __init__ (a_this: "UnoProperty", a_name: str, a_value: object) -> None:
		PropertyValue.__init__ (a_this, Name=a_name, Value=a_value)

