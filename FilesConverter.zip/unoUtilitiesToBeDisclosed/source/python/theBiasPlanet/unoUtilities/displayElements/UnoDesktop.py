from typing import List
from typing import cast
import os
import re
import urllib.parse
import uno
from com.sun.star.container import NoSuchElementException
from com.sun.star.container import XEnumeration
from com.sun.star.frame import FrameSearchFlag
from com.sun.star.frame import XComponentLoader
from com.sun.star.frame import XDispatchProvider
from com.sun.star.frame import XFrame
from com.sun.star.frame import XModel
from com.sun.star.frame import XStorable2
from com.sun.star.frame import XSynchronousDispatch
from com.sun.star.lang import WrappedTargetException
from com.sun.star.lang import XComponent
from com.sun.star.uno import XInterface
from theBiasPlanet.coreUtilities.collectionsHandling.ListsFactory import ListsFactory
from theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup import GeneralConstantsConstantsGroup
from theBiasPlanet.coreUtilities.constantsGroups.RegularExpressionsConstantsGroup import RegularExpressionsConstantsGroup
from theBiasPlanet.coreUtilities.stringsHandling.StringHandler import StringHandler
from theBiasPlanet.unoUtilities.constantsGroups.UnoGeneralConstantsConstantsGroup import UnoGeneralConstantsConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.UnoServiceNamesConstantsGroup import UnoServiceNamesConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.UnoSingletonNamesConstantsGroup import UnoSingletonNamesConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.UnoSpecialFrameNamesConstantsGroup import UnoSpecialFrameNamesConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.UnoDocumentOpeningEnumerablePropertyNamesSet import UnoDocumentOpeningEnumerablePropertyNamesSet
from theBiasPlanet.unoUtilities.displayElements.UnoFrame import UnoFrame
from theBiasPlanet.unoUtilities.inspectionsHandling.UnoInterfaceNotImplementedException import UnoInterfaceNotImplementedException
from theBiasPlanet.unoUtilities.pointers.UnoObjectPointer import UnoObjectPointer
from theBiasPlanet.unoUtilities.propertiesHandling.UnoPropertiesHandler import UnoPropertiesHandler
from theBiasPlanet.unoUtilities.unoDataHandling.UnoDatumConverter import UnoDatumConverter
from theBiasPlanet.unoUtilities.unoObjectsContexts.RemoteUnoObjectsContextInterface import RemoteUnoObjectsContextInterface

class UnoDesktop (UnoFrame):
	@staticmethod
	def getInstance (a_remoteUnoObjectsContext: "RemoteUnoObjectsContextInterface") -> "UnoDesktop":
		return	UnoDesktop (a_remoteUnoObjectsContext)
	
	def __init__ (a_this: "UnoDesktop", a_remoteUnoObjectsContext: "RemoteUnoObjectsContextInterface") -> None:
		a_this.i_fileOpeningDispatcher: "UnoObjectPointer [XSynchronousDispatch]"
		
		super ().__init__ (a_remoteUnoObjectsContext, UnoObjectPointer (XFrame, cast (XFrame, UnoDatumConverter.getObject (a_remoteUnoObjectsContext.getValueByName (UnoGeneralConstantsConstantsGroup.c_singletonUrlFormat.format (UnoSingletonNamesConstantsGroup.c_com_sun_star_frame_theDesktop))))))
		a_this.i_fileOpeningDispatcher = UnoObjectPointer (XSynchronousDispatch, a_this.i_underlyingUnoObject.getAddress ().queryDispatch (UnoDatumConverter.getUrlInURL ("file:///"), UnoSpecialFrameNamesConstantsGroup.c_new, GeneralConstantsConstantsGroup.c_unspecifiedInteger))
	
	def __del__ (a_this: "UnoDesktop") -> None:
		None
	
	def getChildObjects (a_this: "UnoDesktop") -> List ["UnoObjectPointer [XComponent]"]:
		l_childObjects: List ["UnoObjectPointer [XComponent]"] = []
		l_childObjectsIterator: "UnoObjectPointer [XEnumeration]" = UnoObjectPointer (XEnumeration, a_this.i_underlyingUnoObject.getAddress ().getComponents ().createEnumeration ())
		l_childObject: "UnoObjectPointer [XComponent]" = None
		while l_childObjectsIterator.getAddress ().hasMoreElements ():
			try:
				l_childObject = UnoObjectPointer (XComponent, cast (XComponent, l_childObjectsIterator.getAddress ().nextElement ()))
				if not l_childObject.isEmpty ():
					l_childObjects.append (l_childObject)
			except (NoSuchElementException, WrappedTargetException) as l_exception:
				# Practically, never would happen
				break
		return l_childObjects
	
	def loadUnoDocument (a_this: "UnoDesktop", a_url: str, a_password: str, a_unoDocumentIsHidden: bool) -> "UnoObjectPointer [XModel]":
		return UnoObjectPointer (XModel, a_this.i_underlyingUnoObject.getAddress ().loadComponentFromURL (re.sub (RegularExpressionsConstantsGroup.c_windowsDirectoryDelimiterRegularExpression, GeneralConstantsConstantsGroup.c_linuxDirectoriesDelimiter, a_url), UnoSpecialFrameNamesConstantsGroup.c_new, FrameSearchFlag.CREATE, UnoPropertiesHandler.buildProperties (UnoDocumentOpeningEnumerablePropertyNamesSet.c_instance.getValues (), ListsFactory.createList (object, False, a_unoDocumentIsHidden, False, a_unoDocumentIsHidden, a_password if not (a_password is None) else ""))))
	 
	def getCurrentDocument (a_this: "UnoDesktop") -> "UnoObjectPointer [XModel]":
		return UnoObjectPointer (XModel, a_this.i_underlyingUnoObject.getAddress ().getCurrentComponent ())
	
	def getDocument (a_this: "UnoDesktop", a_fileName: str) -> "UnoObjectPointer [XModel]":
		l_unoComponents: "UnoObjectPointer [XEnumeration]" = UnoObjectPointer (XEnumeration, a_this.i_underlyingUnoObject.getAddress ().getComponents ().createEnumeration ())
		while l_unoComponents.getAddress ().hasMoreElements ():
			l_unoComponent: "UnoObjectPointer [XStorable2]" = None
			try:
				l_unoComponent = UnoObjectPointer (XStorable2, cast (XInterface, UnoDatumConverter.getObject (l_unoComponents.getAddress ().nextElement ())))
			except (NoSuchElementException, WrappedTargetException) as l_exception:
				# Practically, never would happen
				break
			if l_unoComponent.isEmpty ():
				continue
			try:
				l_documentLocationString: str = l_unoComponent.getAddress ().getLocation ()
				if l_documentLocationString is not None and (l_documentLocationString.startswith ("http://") or l_documentLocationString.startswith ("https://")):
					try:
						if urllib.parse.urlparse (l_documentLocationString).path == a_fileName:
							try:
								return UnoObjectPointer.getUnoObjectPointer (XModel, XStorable2, l_unoComponent)
							except (UnoInterfaceNotImplementedException) as l_exception:
								None
					except (Exception) as l_exception:
						None
				else:
					if StringHandler.getFilePath (l_documentLocationString) == a_fileName:
						return UnoObjectPointer.getUnoObjectPointer (XModel, XStorable2, l_unoComponent)
			# The possibility is that 'getLocation' returned null.
			except (Exception) as l_exception:
				continue
		return None
	
	def getFileOpeningDispatcher (a_this: "UnoDesktop") -> "UnoObjectPointer [XSynchronousDispatch]":
		return a_this.i_fileOpeningDispatcher

