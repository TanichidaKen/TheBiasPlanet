from typing import List

from theBiasPlanet.coreUtilities.constantsGroups.EncodingNamesConstantsGroup import EncodingNamesConstantsGroup
from theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup import GeneralConstantsConstantsGroup

class MicrosoftPasswordsHasher:
	c_numberOfInitializationCodes: int = 15
	c_initializationCodes: List [int] = [0xE1F0, 0x1D0F, 0xCC9C, 0x84C0, 0x110C, 0x0E10, 0xF1CE, 0x313E, 0x1872, 0xE139, 0xD40F, 0x84F9, 0x280C, 0xA96A, 0x4EC3]
	c_numberOfEncryptionMatrixColumns: int = 7
	c_encryptionMatrix: List [List [int]] = [
		[ 0xAEFC, 0x4DD9, 0x9BB2, 0x2745, 0x4E8A, 0x9D14, 0x2A09],
		[ 0x7B61, 0xF6C2, 0xFDA5, 0xEB6B, 0xC6F7, 0x9DCF, 0x2BBF],
		[ 0x4563, 0x8AC6, 0x05AD, 0x0B5A, 0x16B4, 0x2D68, 0x5AD0],
		[ 0x0375, 0x06EA, 0x0DD4, 0x1BA8, 0x3750, 0x6EA0, 0xDD40],
		[ 0xD849, 0xA0B3, 0x5147, 0xA28E, 0x553D, 0xAA7A, 0x44D5],
		[ 0x6F45, 0xDE8A, 0xAD35, 0x4A4B, 0x9496, 0x390D, 0x721A],
		[ 0xEB23, 0xC667, 0x9CEF, 0x29FF, 0x53FE, 0xA7FC, 0x5FD9],
		[ 0x47D3, 0x8FA6, 0x8FA6, 0x1EDA, 0x3DB4, 0x7B68, 0xF6D0],
		[ 0xB861, 0x60E3, 0xC1C6, 0x93AD, 0x377B, 0x6EF6, 0xDDEC],
		[ 0x45A0, 0x8B40, 0x06A1, 0x0D42, 0x1A84, 0x3508, 0x6A10],
		[ 0xAA51, 0x4483, 0x8906, 0x022D, 0x045A, 0x08B4, 0x1168],
		[ 0x76B4, 0xED68, 0xCAF1, 0x85C3, 0x1BA7, 0x374E, 0x6E9C],
		[ 0x3730, 0x6E60, 0xDCC0, 0xA9A1, 0x4363, 0x86C6, 0x1DAD],
		[ 0x3331, 0x6662, 0xCCC4, 0x89A9, 0x0373, 0x06E6, 0x0DCC],
		[ 0x1021, 0x2042, 0x4084, 0x8108, 0x1231, 0x2462, 0x48C4]
	]
	
	@staticmethod
	def hashIn32bits (a_originalDatum: str) -> int:
		l_hash: int = 0
		l_originalDatumLength: int = len (a_originalDatum)
		if l_originalDatumLength > 0:
			if l_originalDatumLength > MicrosoftPasswordsHasher.c_numberOfInitializationCodes:
		   		l_originalDatumLength = MicrosoftPasswordsHasher.c_numberOfInitializationCodes
			l_highHash: int = MicrosoftPasswordsHasher.c_initializationCodes [l_originalDatumLength - 1]
			l_lowHash: int = 0
			l_character: int = 0x0000
			l_byte: int = 0x00
			l_highByte: int = 0x00
			l_lowByte: int = 0x00
			l_characterIndex: int = GeneralConstantsConstantsGroup.c_iterationStartingNumber
			for l_characterIndex in range (GeneralConstantsConstantsGroup.c_iterationStartingNumber, l_originalDatumLength, 1):
				l_character = ord (a_originalDatum [l_characterIndex])
				l_highByte = (l_character >> 8)
				l_lowByte = (l_character & 0xFF)
				l_byte = l_lowByte if l_lowByte != 0x00 else l_highByte
				l_matrixcolumnIndex: int = GeneralConstantsConstantsGroup.c_iterationStartingNumber
				for l_matrixcolumnIndex in range (GeneralConstantsConstantsGroup.c_iterationStartingNumber, MicrosoftPasswordsHasher.c_numberOfEncryptionMatrixColumns, 1):
					if (l_byte & (1 << l_matrixcolumnIndex)) != 0:
						l_highHash = (l_highHash ^ MicrosoftPasswordsHasher.c_encryptionMatrix [MicrosoftPasswordsHasher.c_numberOfInitializationCodes - l_originalDatumLength + l_characterIndex] [l_matrixcolumnIndex])
				l_character = ord (a_originalDatum [l_originalDatumLength -1 - l_characterIndex])
				l_highByte = (l_character >> 8)
				l_lowByte = (l_character & 0xFF)
				l_byte = l_lowByte if l_lowByte != 0x00 else l_highByte
				l_lowHash = ( ( (l_lowHash >> 14) & 0x0001 ) | ( (l_lowHash << 1) & 0x7FFF)) ^ l_byte
			l_lowHash =  ( ( (l_lowHash >> 14) & 0x0001) | ( (l_lowHash << 1) & 0x7FFF)) ^ l_originalDatumLength ^ 0xCE4B
			l_hash = (l_highHash << 16) | l_lowHash
		return l_hash
	
	@staticmethod
	def hashIn16bits (a_originalDatum: str) -> int:
		l_hash: int = 0
		l_originalDatumUtf8BytesArray: bytes = b''
		try:
			l_originalDatumUtf8BytesArray = a_originalDatum.encode (EncodingNamesConstantsGroup.c_utf8EncodingName)
		except (Exception) as l_exception:
			# Is supposed to never happen.
			None
		l_originalDatumUtf8BytesArrayLength: int = len (l_originalDatumUtf8BytesArray)
		if l_originalDatumUtf8BytesArrayLength <= GeneralConstantsConstantsGroup.c_shortMaximumValue:
			l_byteIndex: int = GeneralConstantsConstantsGroup.c_iterationStartingNumber
			for l_byteIndex in range (l_originalDatumUtf8BytesArrayLength - 1, GeneralConstantsConstantsGroup.c_iterationStartingNumber - 1, -1):
				l_hash = ( (l_hash >> 14) & 0x01) | ( (l_hash << 1) & 0x7FFF)
				l_hash ^= l_originalDatumUtf8BytesArray [l_byteIndex]
			l_hash = ( (l_hash >> 14) & 0x01) | ( (l_hash << 1) & 0x7FFF)
			l_hash ^= (0x8000 | (ord ('N') << 8) | ord ('K'))
			l_hash ^= l_originalDatumUtf8BytesArrayLength
		return l_hash

