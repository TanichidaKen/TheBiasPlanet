import sys
from typing import cast
from typing import List
from com.sun.star.frame import DispatchResultEvent
from com.sun.star.frame import DispatchResultState
from com.sun.star.frame import FeatureStateEvent
from theBiasPlanet.unoUtilities.unoDataHandling.UnoDatumConverter import UnoDatumConverter

class UnoDispatchResult:
	def __init__ (a_this: "UnoDispatchResult") -> None:
		a_this.i_finalStatus: int
		a_this.i_dispatchResult: object
		a_this.i_relatedInformation: List [object]
		
		a_this.i_finalStatus = DispatchResultState.FAILURE
		a_this.i_dispatchResult = None
		a_this.i_relatedInformation = []
	
	def getDispatchResult (a_this: "UnoDispatchResult") -> object:
		return a_this.i_dispatchResult
	
	def setDispatchResult (a_this: "UnoDispatchResult", a_dispatchResultEvent: DispatchResultEvent) -> None:
		if not (a_dispatchResultEvent is None):
			a_this.i_finalStatus = a_dispatchResultEvent.State
			a_this.i_dispatchResult = UnoDatumConverter.getObject (a_dispatchResultEvent.Result);
		else:
			a_this.i_dispatchResult = None
	
	def getRelatedInformation (a_this: "UnoDispatchResult") -> List [object]:
		return a_this.i_relatedInformation
	
	def addRelatedInformationPiece (a_this: "UnoDispatchResult", a_featureStateEvent: FeatureStateEvent) -> None:
		if not (a_featureStateEvent is None):
			a_this.i_relatedInformation.append (a_featureStateEvent.State)
		else:
			a_this.i_relatedInformation.append (None)
	
	def toString (a_this: "UnoDispatchResult") -> str:
		l_stringFlagmentsList: List [str] = []
		l_stringFlagmentsList.append ("State = ")
		l_stringFlagmentsList.append ("{0:d}".format (a_this.i_finalStatus))
		l_stringFlagmentsList.append (", Result = ")
		if not (a_this.i_dispatchResult is None):
			l_stringFlagmentsList.append (str (a_this.i_dispatchResult))
		else:
			l_stringFlagmentsList.append ("null")
		l_stringFlagmentsList.append (", Related information = ")
		l_isInFirstIterationOfRelatedInformationPieces:bool  = True
		l_relatedInformationPiece: object 
		for l_relatedInformationPiece in a_this.i_relatedInformation:
			if not l_isInFirstIterationOfRelatedInformationPieces:
				l_stringFlagmentsList.append (", ")
			else:
				l_isInFirstIterationOfRelatedInformationPieces = False
			if not (l_relatedInformationPiece is None):
				l_stringFlagmentsList.append (str (type (l_relatedInformationPiece)))
				l_stringFlagmentsList.append (": ")
				if isinstance (l_relatedInformationPiece, List):
					l_relatedInformationPieceInList: List [object] = cast (List [object], l_relatedInformationPiece)
					l_stringFlagmentsList.append ("[")
					l_numberOfRelatedInformationPieceElements: int = len (l_relatedInformationPieceInList)
					l_relatedInformationPieceElement: object = None
					l_relatedInformationPieceElementIndex: int 
					for l_relatedInformationPieceElementIndex in range (l_numberOfRelatedInformationPieceElements):
						if l_relatedInformationPieceElementIndex == 0:
							None
						else:
							l_stringFlagmentsList.append (", ")
						l_relatedInformationPieceElement = l_relatedInformationPieceInList [l_relatedInformationPieceElementIndex]
						l_stringFlagmentsList.append (str (l_relatedInformationPieceElement))
					l_stringFlagmentsList.append ("]")
				else:
					l_stringFlagmentsList.append (str (l_relatedInformationPiece))
			else:
				l_stringFlagmentsList.append ("null")
		return "".join (l_stringFlagmentsList)

