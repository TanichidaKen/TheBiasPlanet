from typing import cast
from typing import List
from typing import Optional
import uno
from com.sun.star.beans import PropertyValue
from com.sun.star.frame import XDispatchProvider
from com.sun.star.frame import XDispatchResultListener
from com.sun.star.frame import XFrame
from com.sun.star.frame import XNotifyingDispatch
from com.sun.star.frame import XStatusListener
from com.sun.star.util import URL as com_sun_star_util_URL
from theBiasPlanet.coreUtilities.collectionsHandling.ListsFactory import ListsFactory
from theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup import GeneralConstantsConstantsGroup
from theBiasPlanet.unoUtilities.connectionsHandling.UnoObjectsContext import UnoObjectsContext
from theBiasPlanet.unoUtilities.constantsGroups.UnoDispatchSlotsConstantsGroup import UnoDispatchSlotsConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.UnoSpecialFrameNamesConstantsGroup import UnoSpecialFrameNamesConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.UnoDispatchCommandsCommonArgumentEnumerablePropertyNamesSet import UnoDispatchCommandsCommonArgumentEnumerablePropertyNamesSet
from theBiasPlanet.unoUtilities.propertiesHandling.UnoPropertiesHandler import UnoPropertiesHandler

class UnoDispatcher:
	@staticmethod
	def dispatch (a_unoObjectsContext: "UnoObjectsContext", a_unoFrameInXFrame: XFrame, a_dispatchResultListener: XDispatchResultListener, a_dispatchRelatedInformationListener: XStatusListener, a_dispatchSlot: "UnoDispatchSlotsConstantsGroup.BaseDispatchSlot", a_argumentValues: Optional [List [object]]) -> bool:
		l_dispatchArgumentPropertiesArray: Optional [List [PropertyValue]] = None
		if not (a_dispatchSlot.c_argumentPropertyNamesSet is None) and not (a_argumentValues is None):
			l_dispatchArgumentProperties = UnoPropertiesHandler.buildProperties (ListsFactory.createListExpandingItems (str, UnoDispatchCommandsCommonArgumentEnumerablePropertyNamesSet.c_instance.getValues (), a_dispatchSlot.c_argumentPropertyNamesSet.getValues ()), ListsFactory.createListExpandingItems (object, True, a_argumentValues))
		else:
			l_dispatchArgumentProperties = UnoPropertiesHandler.buildProperties (UnoDispatchCommandsCommonArgumentEnumerablePropertyNamesSet.c_instance.getValues (), ListsFactory.createList (object, True))
		l_urlInURL: com_sun_star_util_URL  = a_unoObjectsContext.createUrlInURL (a_dispatchSlot.c_url)
		l_unoFrameInXDispatchProvider: XDispatchProvider = cast (XDispatchProvider, a_unoFrameInXFrame)
		l_dispatcherInXNotifyingDispatch: XNotifyingDispatch = cast (XNotifyingDispatch, l_unoFrameInXDispatchProvider.queryDispatch (l_urlInURL, UnoSpecialFrameNamesConstantsGroup.c_self, GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger))
		if not (l_dispatcherInXNotifyingDispatch is None):
			l_dispatcherInXNotifyingDispatch.addStatusListener (a_dispatchRelatedInformationListener, l_urlInURL)
			l_dispatcherInXNotifyingDispatch.dispatchWithNotification (l_urlInURL, l_dispatchArgumentProperties, a_dispatchResultListener)
			l_dispatcherInXNotifyingDispatch.removeStatusListener (a_dispatchRelatedInformationListener, l_urlInURL)
			return True
		else:
			return False

