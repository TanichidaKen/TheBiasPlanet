from typing import Iterator
from typing import List
from typing import Optional
from typing import Type
from typing import TypeVar
import uno
from uno import Any
from com.sun.star.beans import NamedValue
from theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup import GeneralConstantsConstantsGroup
from theBiasPlanet.unoUtilities.nameValuePair.UnoNameValuePair import UnoNameValuePair
from theBiasPlanet.unoUtilities.unoDataHandling.UnoDatumConverter import UnoDatumConverter

class UnoNameValuePairsHandler:
	@staticmethod
	def buildNameValuePairs (a_names: List [str], a_values: List [object]) -> Optional [List [NamedValue]]:
		if (a_names is None or a_values is None):
			return None
		else:
			l_nameValuePairs: List [NamedValue] = []
			l_valuesIterator: Iterator [object] = iter (a_values)
			l_name: str
			l_value: object
			for l_name in a_names:
				l_value = next (l_valuesIterator)
				if not (l_value is None):
					l_nameValuePairs.append (UnoNameValuePair (l_name, l_value))
			return l_nameValuePairs

