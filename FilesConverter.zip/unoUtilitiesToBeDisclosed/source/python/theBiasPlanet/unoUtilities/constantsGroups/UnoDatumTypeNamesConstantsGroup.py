
class UnoDatumTypeNamesConstantsGroup:
	# Refer to cppu/source/typelib/typelib.cxx
	c_typeTypeName: str = "type"
	c_voidTypeName: str = "void"
	c_booleanTypeName: str = "boolean"
	c_charTypeName: str = "char"
	c_byteTypeName: str = "byte"
	c_stringTypeName: str = "string"
	c_shortTypeName: str = "short"
	c_unsignedShortTypeName: str = "unsigned short"
	c_longTypeName: str = "long"
	c_unsignedLongTypeName: str = "unsigned long"
	c_hyperTypeName: str = "hyper"
	c_unsignedHyperTypeName: str = "unsigned hyper"
	c_floatTypeName: str = "float"
	c_doubleTypeName: str = "double"
	c_anyTypeName: str = "any"
	c_sequenceTypeNamePrefix: str = "[]" # A full type name is, for example, []string
	# As for UNO interface types, ':@', ',', ':' are used somehow.
