from typing import Optional
from theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup import BaseEnumerableConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.Uno_uno_BasicIDEAppearEnumerablePropertyNamesSet import Uno_uno_BasicIDEAppearEnumerablePropertyNamesSet
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.Uno_uno_GoToCellEnumerablePropertyNamesSet import Uno_uno_GoToCellEnumerablePropertyNamesSet
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.Uno_uno_PasteEnumerablePropertyNamesSet import Uno_uno_PasteEnumerablePropertyNamesSet
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet import Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet

class UnoDispatchSlotsConstantsGroup:
	# Base class for all the constants in this group
	class BaseDispatchSlot:
		def __init__ (a_this: "UnoDispatchSlotsConstantsGroup.BaseDispatchSlot", a_url: str, a_argumentPropertyNamesSet: "Optional [BaseEnumerableConstantsGroup [str]]"):
			a_this.c_url: str
			a_this.c_argumentPropertyNamesSet: "Optional [BaseEnumerableConstantsGroup [str]]"
			
			a_this.c_url = a_url
			a_this.c_argumentPropertyNamesSet = a_argumentPropertyNamesSet
	c__uno_BasicIDEAppear: "BaseDispatchSlot" = BaseDispatchSlot (".uno:BasicIDEAppear", Uno_uno_BasicIDEAppearEnumerablePropertyNamesSet.c_instance)
	c__uno_CompileBasic: "BaseDispatchSlot" = BaseDispatchSlot (".uno:CompileBasic", None)
	c__uno_GoToCell: "BaseDispatchSlot" = BaseDispatchSlot (".uno:GoToCell", Uno_uno_GoToCellEnumerablePropertyNamesSet.c_instance)
	c__uno_Paste: "BaseDispatchSlot" = BaseDispatchSlot (".uno:Paste", Uno_uno_PasteEnumerablePropertyNamesSet.c_instance)
	c__uno_SelectAll: "BaseDispatchSlot" = BaseDispatchSlot (".uno:SelectAll", None)
	c__uno_StyleNewByExample: "BaseDispatchSlot" = BaseDispatchSlot (".uno:StyleNewByExample", Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet.c_instance)

