
class UnoSingletonNamesConstantsGroup:
	c_com_sun_star_frame_theDesktop: str = "com.sun.star.frame.theDesktop"
	c_com_sun_star_frame_theGlobalEventBroadcaster: str = "com.sun.star.frame.theGlobalEventBroadcaster"

