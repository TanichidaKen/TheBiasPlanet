
class UnoSpecialFrameNamesConstantsGroup:
	c_new: str = "_blank"
	c_default: str = "_default"
	c_self: str = "_self"
	c_parent: str = "_parent"
	c_top: str = "_top"
	c_specialSub: str = "_beamer"

