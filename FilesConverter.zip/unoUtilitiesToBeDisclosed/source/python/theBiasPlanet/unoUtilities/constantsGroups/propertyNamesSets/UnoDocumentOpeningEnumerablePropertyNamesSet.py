from theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup import BaseEnumerableConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.UnoPropertyNamesSet import UnoPropertyNamesSet

class UnoDocumentOpeningEnumerablePropertyNamesSet (BaseEnumerableConstantsGroup [str], UnoPropertyNamesSet):
	c_readOnly_Boolean: str = "ReadOnly"
	c_hidden_Boolean: str = "Hidden"
	c_openNewView_Boolean: str = "OpenNewView"
	c_silent_Boolean: str = "Silent"
	c_password_string: str = "Password"
	
	def __init__ (a_this: "UnoDocumentOpeningEnumerablePropertyNamesSet") -> None:
		BaseEnumerableConstantsGroup.__init__ (a_this, str)
	
	c_instance: "UnoDocumentOpeningEnumerablePropertyNamesSet"

UnoDocumentOpeningEnumerablePropertyNamesSet.c_instance = UnoDocumentOpeningEnumerablePropertyNamesSet ()

