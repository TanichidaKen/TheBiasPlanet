
class UnoObjectsContextPropertyNamesSet:
	c_identification_string: str = "identification"

