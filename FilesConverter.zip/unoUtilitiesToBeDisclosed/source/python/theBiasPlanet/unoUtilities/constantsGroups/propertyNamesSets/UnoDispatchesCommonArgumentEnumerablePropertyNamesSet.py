from theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup import BaseEnumerableConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.UnoPropertyNamesSet import UnoPropertyNamesSet

class UnoDispatchesCommonArgumentEnumerablePropertyNamesSet (BaseEnumerableConstantsGroup [str], UnoPropertyNamesSet):
	c_synchronousMode_Boolean: str = "SynchronMode"
	c_instance: "UnoDispatchesCommonArgumentEnumerablePropertyNamesSet"
	
	def __init__ (a_this: "UnoDispatchesCommonArgumentEnumerablePropertyNamesSet") -> None:
		BaseEnumerableConstantsGroup.__init__ (a_this, str)

UnoDispatchesCommonArgumentEnumerablePropertyNamesSet.c_instance = UnoDispatchesCommonArgumentEnumerablePropertyNamesSet ()

