from abc import ABCMeta

class UnoPropertyNamesSet (metaclass=ABCMeta):
	None

