
class UnoSpreadSheetPropertyNamesSet:
	c_whetherIsVisible_boolean: str = "IsVisible"
	c_pageStyle: str = "PageStyle"

