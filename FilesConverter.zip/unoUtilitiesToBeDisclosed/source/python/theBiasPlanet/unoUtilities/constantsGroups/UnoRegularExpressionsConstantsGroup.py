from typing import Pattern
import re

class UnoRegularExpressionsConstantsGroup:
	c_urlRegularExpression: Pattern  = re.compile ("(.*:)(.*)")

