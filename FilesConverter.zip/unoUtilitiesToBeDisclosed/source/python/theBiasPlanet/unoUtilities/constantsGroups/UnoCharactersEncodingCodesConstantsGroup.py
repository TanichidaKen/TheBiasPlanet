
class UnoCharactersEncodingCodesConstantsGroup:
	c_utf8: int = 76
	c_ucs2: int = 65535
	c_ucs4: int = 65534
	c_usAscii: int = 11
	c_eucJp: int = 69
	c_shiftJis: int = 64

