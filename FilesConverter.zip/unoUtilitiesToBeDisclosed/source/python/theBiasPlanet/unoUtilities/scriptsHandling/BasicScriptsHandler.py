from typing import cast
from typing import List
from typing import Optional
from typing import Tuple
import os.path
import threading
from threading import Lock
import xml.sax
from xml.sax.handler import ContentHandler
from xml.sax.xmlreader import AttributesNSImpl
from xml.sax.xmlreader import InputSource
from xml.sax.xmlreader import XMLReader
import pyperclip
import uno
from com.sun.star.frame import DispatchResultEvent
from com.sun.star.frame import FeatureStateEvent
from com.sun.star.frame import XDispatchProvider
from com.sun.star.frame import XDispatchResultListener
from com.sun.star.lang import XComponent
from com.sun.star.lang import XServiceInfo
from com.sun.star.script.browse import XBrowseNode
from com.sun.star.script.provider import XScript
from com.sun.star.script.provider import XScriptProvider;
from theBiasPlanet.coreUtilities.collectionsHandling.ListsFactory import ListsFactory
from theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup import GeneralConstantsConstantsGroup
from theBiasPlanet.coreUtilities.messagingHandling.Publisher import Publisher
from theBiasPlanet.unoUtilities.constantsGroups.UnoDispatchSlotsConstantsGroup import UnoDispatchSlotsConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.UnoGeneralConstantsConstantsGroup import UnoGeneralConstantsConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.UnoMacroLocationNamesConstantsGroup import UnoMacroLocationNamesConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.UnoServiceNamesConstantsGroup import UnoServiceNamesConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.UnoObjectsContextPropertyNamesSet import UnoObjectsContextPropertyNamesSet
from theBiasPlanet.unoUtilities.dispatchingHandling.UnoDispatchResultAndRelatedInformation import UnoDispatchResultAndRelatedInformation
from theBiasPlanet.unoUtilities.displayElements.UnoDesktop import UnoDesktop
from theBiasPlanet.unoUtilities.displayElements.UnoFrame import UnoFrame
from theBiasPlanet.unoUtilities.inspectionsHandling.UnoComponentInspector import UnoComponentInspector
from theBiasPlanet.unoUtilities.pointers.UnoObjectPointer import UnoObjectPointer
from theBiasPlanet.unoUtilities.unoDataHandling.UnoDatumConverter import UnoDatumConverter
from theBiasPlanet.unoUtilities.unoObjectsContexts.RemoteUnoObjectsContextInterface import RemoteUnoObjectsContextInterface

class BasicScriptsHandler:
	class BasicSourceXmlParseHandler (ContentHandler):
		def __init__ (a_this: "BasicScriptsHandler.BasicSourceXmlParseHandler") -> None:
			a_this.i_basicModuleName: Optional [str]
			a_this.i_basicCodeBuilder: Optional [List [str]]
			a_this.i_isInBasicCodeElement: bool
			
			a_this.i_basicModuleName = None
			a_this.i_basicCodeBuilder = None
			a_this.i_isInBasicCodeElement = False
		
		def getBasicModuleName (a_this: "BasicScriptsHandler.BasicSourceXmlParseHandler") -> Optional [str]:
			return a_this.i_basicModuleName
		
		def getBasicCode (a_this: "BasicScriptsHandler.BasicSourceXmlParseHandler") -> str:
			if not (a_this.i_basicCodeBuilder is None):
				return "".join (a_this.i_basicCodeBuilder)
			else:
				return ""
		
		def startDocument (a_this: "BasicScriptsHandler.BasicSourceXmlParseHandler") -> None:
			a_this.i_isInBasicCodeElement = False
		
		def endDocument(a_this: "BasicScriptsHandler.BasicSourceXmlParseHandler") -> None:
			None
		
		def startElementNS (a_this: "BasicScriptsHandler.BasicSourceXmlParseHandler", a_namespaceUriAndLocalName: Tuple [str, str], a_qualifiedName: str, a_attributes: AttributesNSImpl) -> None:
			#if a_qualifiedName == "script:module":
			if a_namespaceUriAndLocalName [1] == "module":
				a_this.i_isInBasicCodeElement = True
				a_this.i_basicModuleName = a_attributes.getValueByQName ("script:name")
				a_this.i_basicCodeBuilder = []
		
		def endElementNS (a_this: "BasicScriptsHandler.BasicSourceXmlParseHandler", a_namespaceUriAndLocalName: Tuple [str, str], a_qualifiedName: str) -> None:
			None
		
		def characters (a_this: "BasicScriptsHandler.BasicSourceXmlParseHandler", a_contents: str) -> None:
			if a_this.i_isInBasicCodeElement:
				if a_this.i_basicCodeBuilder is not None:
					a_this.i_basicCodeBuilder.append (a_contents)
	
	def __init__ (a_this: "BasicScriptsHandler", a_remoteUnoObjectsContext: "RemoteUnoObjectsContextInterface", a_basicSourceBasePath: Optional [str]) -> None:
		a_this.i_remoteUnoObjectsContext: "RemoteUnoObjectsContextInterface"
		a_this.i_lock: Lock
		a_this.i_unoDesktop: "UnoDesktop"
		a_this.i_macroHandlersProvider: "UnoObjectPointer [XScriptProvider]"
		a_this.i_basicSourceBasePath: Optional [str]
		a_this.i_xmlParser: XMLReader
		a_this.i_basicSourceXmlParseHandler: "BasicScriptsHandler.BasicSourceXmlParseHandler"
		
		a_this.i_remoteUnoObjectsContext = a_remoteUnoObjectsContext
		a_this.i_lock = threading.Lock ()
		a_this.i_unoDesktop = cast (UnoDesktop, a_this.i_remoteUnoObjectsContext.getLocalPropertyValue (UnoObjectsContextPropertyNamesSet.c_unoDesktopSingleton_string))
		a_this.i_macroHandlersProvider = a_this.i_remoteUnoObjectsContext.getUnoServiceInstance (XScriptProvider, UnoServiceNamesConstantsGroup.c_com_sun_star_script_provider_MasterScriptProvider, None)
		a_this.i_basicSourceBasePath = a_basicSourceBasePath
		if a_this.i_basicSourceBasePath is not None:
			a_this.i_xmlParser = xml.sax.make_parser ()
			a_this.i_xmlParser.setFeature (xml.sax.handler.feature_namespaces, True)
			#a_this.i_xmlParser.setFeature (xml.sax.handler.feature_namespace_prefixes, True)
			a_this.i_basicSourceXmlParseHandler = BasicScriptsHandler.BasicSourceXmlParseHandler ()
			a_this.i_xmlParser.setContentHandler (a_this.i_basicSourceXmlParseHandler)
	
	def invokeMacro (a_this: "BasicScriptsHandler", a_macroProgrammingLanguageName: str, a_macroLocationName: str, a_macroPathString: str, a_macroArguments: List [object], a_macroOutputArgumentIndices: List [int], a_macroOutputArguments: List [object]) -> object:
		if not a_macroLocationName == UnoMacroLocationNamesConstantsGroup.c_userInPlace and not a_macroLocationName == UnoMacroLocationNamesConstantsGroup.c_userInExtension and not a_macroLocationName == UnoMacroLocationNamesConstantsGroup.c_applicationInPlace and not a_macroLocationName == UnoMacroLocationNamesConstantsGroup.c_applicationInExtension:
			raise Exception ("The macro location name is invalid");
		l_macroUrl: str = UnoGeneralConstantsConstantsGroup.c_macroUrlFormat.format (a_macroPathString, a_macroProgrammingLanguageName, a_macroLocationName)
		l_macroHandler: "UnoObjectPointer [XScript]" = UnoObjectPointer (XScript, a_this.i_macroHandlersProvider.getAddress ().getScript (l_macroUrl))
		l_macroReturnAndOutputArgumentIndicesAndOutputArgyumrnts: List [object] = l_macroHandler.getAddress ().invoke (a_macroArguments, a_macroOutputArgumentIndices, a_macroOutputArguments)
		return l_macroReturnAndOutputArgumentIndicesAndOutputArgyumrnts [GeneralConstantsConstantsGroup.c_iterationStartNumber]
	
	def compileUserBasicScript (a_this: "BasicScriptsHandler", a_libraryName: Optional [str], a_moduleName: Optional [str]) -> bool:
		l_resultStatus: bool  = False
		l_libraryHasBeenFound: bool = False
		l_moduleHasBeenFound: bool = False
		l_scriptsProviderForBasic: "UnoObjectPointer [XBrowseNode]" = a_this.i_remoteUnoObjectsContext.getUnoServiceInstance (XBrowseNode, UnoServiceNamesConstantsGroup.c_com_sun_star_script_provider_ScriptProviderForBasic, ListsFactory.createList (object, "user"))
		l_libraryNodes: List ["UnoObjectPointer [XBrowseNode]"] = UnoDatumConverter.getUnoObjects (XBrowseNode, l_scriptsProviderForBasic.getAddress ().getChildNodes ())
		l_libraryName: Optional [str] = None
		l_libraryNode: Optional ["UnoObjectPointer [XBrowseNode]"] = None
		for l_libraryNode in l_libraryNodes:
			l_libraryName = l_libraryNode.getAddress ().getName ()
			if a_libraryName is None or a_libraryName == l_libraryName:
				l_moduleNodes: List ["UnoObjectPointer [XBrowseNode]"] = UnoDatumConverter.getUnoObjects (XBrowseNode, l_libraryNode.getAddress ().getChildNodes ())
				l_moduleName: Optional [str] = None
				l_moduleNode: "UnoObjectPointer [XBrowseNode]"
				for l_moduleNode in l_moduleNodes:
					l_moduleName = l_moduleNode.getAddress ().getName ()
					if a_moduleName is None or a_moduleName == l_moduleName:
						l_resultStatus = a_this.compileBasicScript ("application", l_libraryName, l_moduleName)
						if not l_resultStatus:
							break
						if a_moduleName is not None:
							l_moduleHasBeenFound = True
							break
				if a_libraryName is not None:
					if a_moduleName is not None and not l_moduleHasBeenFound:
						Publisher.logWarningInformation ("The module has not been loaded into the Office instance for {0:s}.{1:s}; maybe the Office instance has to be restarted.".format (a_libraryName, a_moduleName))
					l_libraryHasBeenFound = True
					break
		if a_libraryName is not None and not l_libraryHasBeenFound:
			Publisher.logWarningInformation ("The library has not been loaded into the Office instance for {0:s}; maybe the Office instance has to be restarted.".format (a_libraryName))
		return l_resultStatus
	
	def compileBasicScript (a_this: "BasicScriptsHandler", a_containerName: str, a_libraryName: str, a_moduleName: str) -> bool:
		l_resultStatus: bool = False
		l_unoDispatchResult: "Optional [UnoDispatchResultAndRelatedInformation]" = a_this.i_unoDesktop.fulfill (UnoDispatchSlotsConstantsGroup.c__uno_BasicIDEAppear, ListsFactory.createList (object, a_containerName, a_libraryName, a_moduleName, "Module", 1, 0, 0))
		l_unoObjects: List ["UnoObjectPointer [XComponent]"] = a_this.i_unoDesktop.getChildObjects ()
		l_basicIdeFrame: "UnoFrame" = None
		l_unoObject: "UnoObjectPointer [XComponent]" = None
		for l_unoObject in l_unoObjects:
			if UnoComponentInspector.implementsUnoType (l_unoObject.getAddress (), "com.sun.star.lang.XServiceInfo"):
				if l_unoObject.getAddress ().supportsService (UnoServiceNamesConstantsGroup.c_com_sun_star_script_BasicIDE):
					l_basicIdeFrame = UnoFrame (a_this.i_remoteUnoObjectsContext, l_unoObject.getAddress ().getCurrentController ().getFrame ())
					break
		l_unoDispatchResultAndRelatedInformation: "UnoDispatchResultAndRelatedInformation " = None
		if l_basicIdeFrame is not None:
			try:
				a_this.i_lock.acquire ()
				l_basicSourceFilePath: str = "{0:s}/{1:s}/{2:s}.xba".format (a_this.i_basicSourceBasePath, a_libraryName, a_moduleName)
				if os.path.isfile (l_basicSourceFilePath):
					a_this.i_xmlParser.parse (InputSource (l_basicSourceFilePath))
					if (a_moduleName == a_this.i_basicSourceXmlParseHandler.getBasicModuleName ()):
						l_previousClipboardContents: str = pyperclip.paste ()
						pyperclip.copy (a_this.i_basicSourceXmlParseHandler.getBasicCode ())
						l_unoDispatchResultAndRelatedInformation = l_basicIdeFrame.fulfill (UnoDispatchSlotsConstantsGroup.c__uno_SelectAll, None)
						l_unoDispatchResultAndRelatedInformation = l_basicIdeFrame.fulfill (UnoDispatchSlotsConstantsGroup.c__uno_Paste, ListsFactory.createList (object, 0))
						pyperclip.copy (l_previousClipboardContents)
						l_unoDispatchResultAndRelatedInformation = l_basicIdeFrame.fulfill (UnoDispatchSlotsConstantsGroup.c__uno_CompileBasic, None)
					else:
						Publisher.logWarningInformation ("The module name specified in the module file is invalid for {0:s}.{1:s}.{2:s}.".format (a_containerName, a_libraryName, a_moduleName))
				else:
					Publisher.logWarningInformation ("There is no source file for {0:s}.{1:s}.{2:s} under the Basic source base.".format (a_containerName, a_libraryName, a_moduleName))
			finally:
				a_this.i_lock.release ()
		return True if l_unoDispatchResultAndRelatedInformation is not None else False

