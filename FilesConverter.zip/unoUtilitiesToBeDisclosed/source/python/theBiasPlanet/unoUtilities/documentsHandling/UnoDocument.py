import re
import threading
from threading import Lock
from typing import cast
from typing import List
from typing import Optional
from com.sun.star.beans import PropertyValue
from com.sun.star.document import XDocumentEventBroadcaster
from com.sun.star.document import XEventBroadcaster
from com.sun.star.frame import DispatchResultEvent
from com.sun.star.frame import FeatureStateEvent
from com.sun.star.frame import FrameSearchFlag
from com.sun.star.frame import XComponentLoader
from com.sun.star.frame import XController
from com.sun.star.frame import XDesktop2
from com.sun.star.frame import XDispatchProvider
from com.sun.star.frame import XDispatchResultListener
from com.sun.star.frame import XFrame
from com.sun.star.frame import XModel
from com.sun.star.frame import XNotifyingDispatch
from com.sun.star.frame import XStatusListener
from com.sun.star.frame import XStorable2
from com.sun.star.lang import EventObject as com_sun_star_lang_EventObject
from com.sun.star.lang import XComponent
from com.sun.star.util import URL as com_sun_star_util_URL
from com.sun.star.util import XCloseable
import uno
from unohelper import Base as UnoBase
from theBiasPlanet.coreUtilities.collectionsHandling.ListsFactory import ListsFactory
from theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup import GeneralConstantsConstantsGroup
from theBiasPlanet.coreUtilities.constantsGroups.RegularExpressionsConstantsGroup import RegularExpressionsConstantsGroup
from theBiasPlanet.unoUtilities.connectionsHandling.UnoObjectsContext import UnoObjectsContext
from theBiasPlanet.unoUtilities.constantsGroups.UnoDispatchSlotsConstantsGroup import UnoDispatchSlotsConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.UnoMessagesConstantsGroup import UnoMessagesConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.UnoServiceNamesConstantsGroup import UnoServiceNamesConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.UnoSpecialFrameNamesConstantsGroup import UnoSpecialFrameNamesConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.UnoDispatchCommandsCommonArgumentEnumerablePropertyNamesSet import UnoDispatchCommandsCommonArgumentEnumerablePropertyNamesSet
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.UnoDocumentOpeningEnumerablePropertyNamesSet import UnoDocumentOpeningEnumerablePropertyNamesSet
from theBiasPlanet.unoUtilities.dispatching.UnoDispatchResult import UnoDispatchResult
from theBiasPlanet.unoUtilities.propertiesHandling.UnoPropertiesHandler import UnoPropertiesHandler

class UnoDocument (UnoBase, XDispatchResultListener, XStatusListener):
	def __init__ (a_this: "UnoDocument", a_unoObjectsContext: "UnoObjectsContext", a_unoDocumentInXComponent: XComponent) -> None:
		a_this.i_lock: Lock
		a_this.i_unoObjectsContext: "UnoObjectsContext"
		a_this.i_unoDocumentInXModel: XModel
		a_this.i_unoDocumentInXStorable2: XStorable2
		a_this.i_unoDocumentInXDocumentEventBroadcaster: XDocumentEventBroadcaster
		a_this.i_unoDocumentInXEventBroadcaster: XEventBroadcaster
		a_this.i_controllerInXController: XController
		a_this.i_frameInXFrame: XFrame
		a_this.i_frameInXDispatchProvider: XDispatchProvider
		a_this.i_dispatchResult: "Optional [UnoDispatchResult]"
		
		if (a_unoObjectsContext is None):
			raise Exception (UnoMessagesConstantsGroup.c_unoObjectsContextNotSpecified)
		a_this.i_lock = threading.Lock ()
		a_this.i_unoObjectsContext = a_unoObjectsContext
		if (a_unoDocumentInXComponent is None):
			raise Exception (UnoMessagesConstantsGroup.c_unoDocumentNotSpecified)
		a_this.i_unoDocumentInXModel = cast (XModel, a_unoDocumentInXComponent)
		a_this.i_unoDocumentInXStorable2 = cast (XStorable2, a_this.i_unoDocumentInXModel)
		a_this.i_unoDocumentInXDocumentEventBroadcaster = cast (XDocumentEventBroadcaster, a_this.i_unoDocumentInXModel)
		a_this.i_unoDocumentInXEventBroadcaster = cast (XEventBroadcaster, a_this.i_unoDocumentInXModel)
		a_this.i_controllerInXController = cast (XController, a_this.i_unoDocumentInXModel.getCurrentController ())
		a_this.i_frameInXFrame = a_this.i_controllerInXController.getFrame ()
		a_this.i_frameInXDispatchProvider = cast (XDispatchProvider, a_this.i_frameInXFrame)
		a_this.i_dispatchResult = None
	
	@staticmethod
	def createUnoDocumentOrOpenUnoDocumentFile (a_unoObjectsContext: "UnoObjectsContext", a_fileUrl: str, a_password: Optional [str], a_hiddenly: bool) -> XComponent:
		l_desktopInXComponentLoader: XComponentLoader = cast (XComponentLoader, a_unoObjectsContext.getServiceInstance (UnoServiceNamesConstantsGroup.c_com_sun_star_frame_Desktop, None))
		return l_desktopInXComponentLoader.loadComponentFromURL (re.sub (RegularExpressionsConstantsGroup.c_windowsDirectoryDelimiterRegularExpression, GeneralConstantsConstantsGroup.c_linuxDirectoriesDelimiter, a_fileUrl), UnoSpecialFrameNamesConstantsGroup.c_new, FrameSearchFlag.CREATE, UnoPropertiesHandler.buildProperties (UnoDocumentOpeningEnumerablePropertyNamesSet.c_instance.getValues (), ListsFactory.createList (object, False, a_hiddenly, False, a_hiddenly, a_hiddenly, a_password if not (a_password is None) else "")))
				
	@staticmethod
	def getCurrentUnoDocument (a_unoObjectsContext: "UnoObjectsContext") -> XComponent:
		l_desktopInXDesktop2: XDesktop2 = cast (XDesktop2, a_unoObjectsContext.getServiceInstance (UnoServiceNamesConstantsGroup.c_com_sun_star_frame_Desktop, None))
		return l_desktopInXDesktop2.getCurrentComponent ()
	
	def getObjectsContext (a_this: "UnoDocument") -> UnoObjectsContext:
		return a_this.i_unoObjectsContext
	
	def close (a_this: "UnoDocument") -> None:
		l_unoDocumentInXCloseable:XCloseable = cast (XCloseable, a_this.i_unoDocumentInXStorable2)
		l_unoDocumentInXCloseable.close (False);
	
	def dispatch (a_this: "UnoDocument", a_dispatchSlot: "UnoDispatchSlotsConstantsGroup.BaseDispatchSlot", a_argumentValues: Optional [List [object]]) -> Optional ["UnoDispatchResult"]:
		l_dispatchArgumentPropertiesArray: Optional [List [PropertyValue]] = None
		if not (a_dispatchSlot.c_argumentPropertyNamesSet is None) and not (a_argumentValues is None):
			l_dispatchArgumentProperties = UnoPropertiesHandler.buildProperties (ListsFactory.createListExpandingItems (str, UnoDispatchCommandsCommonArgumentEnumerablePropertyNamesSet.c_instance.getValues (), a_dispatchSlot.c_argumentPropertyNamesSet.getValues ()), ListsFactory.createListExpandingItems (object, True, a_argumentValues))
		else:
			l_dispatchArgumentProperties = UnoPropertiesHandler.buildProperties (UnoDispatchCommandsCommonArgumentEnumerablePropertyNamesSet.c_instance.getValues (), ListsFactory.createList (object, True))
		l_urlInURL: com_sun_star_util_URL  = a_this.i_unoObjectsContext.createUrlInURL (a_dispatchSlot.c_url)
		l_dispatcherInXNotifyingDispatch: XNotifyingDispatch = cast (XNotifyingDispatch, a_this.i_frameInXDispatchProvider.queryDispatch (l_urlInURL, UnoSpecialFrameNamesConstantsGroup.c_self, GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger))
		if not (l_dispatcherInXNotifyingDispatch is None):
			try:
				a_this.i_lock.acquire ()
				a_this.i_dispatchResult = UnoDispatchResult ()
				l_dispatcherInXNotifyingDispatch.addStatusListener (a_this, l_urlInURL)
				l_dispatcherInXNotifyingDispatch.dispatchWithNotification (l_urlInURL, l_dispatchArgumentProperties, a_this)
				l_dispatcherInXNotifyingDispatch.removeStatusListener (a_this, l_urlInURL)
				return a_this.i_dispatchResult
			finally:
				a_this.i_lock.release ()
		else:
			return None
	
	def dispatchFinished (a_this: "UnoDocument", a_dispatchResultEvent: "DispatchResultEvent") -> None:
		if not (a_this.i_dispatchResult is None):
			a_this.i_dispatchResult.setDispatchResult (a_dispatchResultEvent)
	
	def statusChanged (a_this: "UnoDocument", a_featureStateEvent: FeatureStateEvent) -> None:
		if not (a_this.i_dispatchResult is None):
			a_this.i_dispatchResult.addRelatedInformationPiece (a_featureStateEvent)
	
	def disposing (a_this: "UnoDocument", a_source: com_sun_star_lang_EventObject) -> None:
		None

