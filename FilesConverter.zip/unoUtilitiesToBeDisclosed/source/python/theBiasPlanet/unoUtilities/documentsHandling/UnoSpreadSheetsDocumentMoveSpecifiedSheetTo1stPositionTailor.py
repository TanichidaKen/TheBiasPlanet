from typing import cast
from com.sun.star.container import XIndexAccess
from com.sun.star.container import XNamed
from com.sun.star.lang import XComponent
from com.sun.star.sheet import XSpreadsheet
from com.sun.star.sheet import XSpreadsheetDocument
from com.sun.star.sheet import XSpreadsheets
from  theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup import GeneralConstantsConstantsGroup
from theBiasPlanet.coreUtilities.messaging.Publisher import Publisher
from theBiasPlanet.unoUtilities.connectionsHandling.UnoObjectsContext import UnoObjectsContext
from theBiasPlanet.unoUtilities.documentsHandling.UnoDocumentTailor import UnoDocumentTailor 

class UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor (UnoDocumentTailor):
	def __init__ (a_this: "UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor", a_objectsContext: "UnoObjectsContext", a_targetSpreadSheetIndex: int) -> None:
		a_this.i_targetSpreadSheetIndex: int
		
		UnoDocumentTailor.__init__ (a_this, a_objectsContext)
		a_this.i_targetSpreadSheetIndex = a_targetSpreadSheetIndex
	
	def tailor (a_this: "UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor", a_unoDocumentInXComponent: XComponent) -> bool:
		l_spreadSheetsDocumentInXSpreadsheetDocument: XSpreadsheetDocument = cast (XSpreadsheetDocument, a_unoDocumentInXComponent)
		if l_spreadSheetsDocumentInXSpreadsheetDocument is None:
			Publisher.logErrorInformation ("The document is not any spread sheet.")
			return False
		else:
			l_spreadSheetsInXIndexAccess: XIndexAccess = cast (XIndexAccess, l_spreadSheetsDocumentInXSpreadsheetDocument.getSheets ())
			try:
				l_spreadSheetInXSpreadsheet: XSpreadsheet = cast (XSpreadsheet, (l_spreadSheetsInXIndexAccess.getByIndex (a_this.i_targetSpreadSheetIndex)))
				l_spreadSheetInXNamed: XNamed = cast (XNamed, l_spreadSheetInXSpreadsheet)
				(cast (XSpreadsheets, l_spreadSheetsInXIndexAccess)).moveByName (l_spreadSheetInXNamed.getName (), GeneralConstantsConstantsGroup.c_iterationStartingNumber)
				return True
			except (Exception) as l_exception:
				Publisher.logErrorInformation (l_exception)
				return False

