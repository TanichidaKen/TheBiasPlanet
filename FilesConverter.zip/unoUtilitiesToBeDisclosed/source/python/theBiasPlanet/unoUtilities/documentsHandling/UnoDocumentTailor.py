from com.sun.star.lang import XComponent
from theBiasPlanet.unoUtilities.connectionsHandling.UnoObjectsContext import UnoObjectsContext

class UnoDocumentTailor:
	def __init__ (a_this: "UnoDocumentTailor", a_unoObjectsContext: "UnoObjectsContext"):
		a_this.i_unoObjectsContext: "UnoObjectsContext"
		
		a_this.i_unoObjectsContext = a_unoObjectsContext
	
	def tailor (a_this: "UnoDocumentTailor", a_unoDocumentInXComponent: XComponent) -> bool:
		return True

