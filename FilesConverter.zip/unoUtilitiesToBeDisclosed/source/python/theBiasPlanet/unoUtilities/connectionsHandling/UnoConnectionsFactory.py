from abc import ABCMeta
from sys import stdout
from typing import cast
from typing import Dict
from typing import List
from typing import Optional
import uno
from uno import Any
from unohelper import Base as UnoBase
from com.sun.star.bridge import BridgeExistsException
from com.sun.star.bridge import XBridge
from com.sun.star.bridge import XBridgeFactory
from com.sun.star.bridge import XInstanceProvider
from com.sun.star.connection import XConnection
from com.sun.star.uno import Exception as com_sun_star_uno_Exception
from com.sun.star.uno import XComponentContext
from theBiasPlanet.coreUtilities.stringsHandling.StringTokenizer import StringTokenizer
from theBiasPlanet.unoUtilities.connectionsHandling.UnoConnectionEventsListener import UnoConnectionEventsListener
from theBiasPlanet.unoUtilities.connectionsHandling.UnoConnection import UnoConnection
from theBiasPlanet.unoUtilities.connectionsHandling.UnoObjectsContext import UnoObjectsContext
from theBiasPlanet.unoUtilities.constantsGroups.UnoDefaultValuesConstantsGroup import UnoDefaultValuesConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.UnoMessagesConstantsGroup import UnoMessagesConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.UnoServiceNamesConstantsGroup import UnoServiceNamesConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.UnoObjectsContextPropertyNamesSet import UnoObjectsContextPropertyNamesSet
from theBiasPlanet.unoUtilities.unoDataHandling.UnoDatumConverter import UnoDatumConverter

class UnoConnectionsFactory (metaclass=ABCMeta):
	class InitialUnoObjectsProvider (UnoBase, XInstanceProvider):
		def __init__ (a_this: "UnoConnectionsFactory.InitialUnoObjectsProvider", a_localObjectsContext: UnoObjectsContext) -> None:
			a_this.i_localObjectsContext: UnoObjectsContext
			
			a_this.i_localObjectsContext = a_localObjectsContext
		
		def getInstance (a_this: "UnoConnectionsFactory.InitialUnoObjectsProvider", a_initialUnoObjectName: str) -> object:
			if (UnoDefaultValuesConstantsGroup.c_initiallyOfferedUnoObjectName == a_initialUnoObjectName):
				return a_this.i_localObjectsContext
			else:
				return None
	
	def __init__ (a_this: "UnoConnectionsFactory", a_localObjectsContext: UnoObjectsContext) -> None:
		a_this.i_localObjectsContext: UnoObjectsContext
		a_this.i_bridgesFactoryInXBridgeFactory: XBridgeFactory
		
		a_this.i_localObjectsContext = a_localObjectsContext
	
	def initialize (a_this: "UnoConnectionsFactory") -> None:
		a_this.i_bridgesFactoryInXBridgeFactory = cast (XBridgeFactory, a_this.i_localObjectsContext.getServiceInstance (UnoServiceNamesConstantsGroup.c_com_sun_star_bridge_BridgeFactory, None))
	
	def setupConnection (a_this: "UnoConnectionsFactory", a_connectionInXConnection: XConnection, a_urlTokenizer: StringTokenizer, a_connectionIdentification: str, a_eventListeners: Optional [List [UnoConnectionEventsListener]]) -> UnoConnection:
		l_bridgeInXBridge: XBridge = None
		try:
			l_bridgeInXBridge = a_this.i_bridgesFactoryInXBridgeFactory.createBridge ("", a_urlTokenizer.nextToken (), a_connectionInXConnection, UnoConnectionsFactory.InitialUnoObjectsProvider (a_this.i_localObjectsContext))
		except (BridgeExistsException) as l_exception:
			# This can't happen
			stdout.write (str (l_exception) + "\n")
		l_remoteObjectsContextInXInterface: object =  l_bridgeInXBridge.getInstance (a_urlTokenizer.nextToken ())
		if (l_remoteObjectsContextInXInterface is None):
			raise com_sun_star_uno_Exception (UnoMessagesConstantsGroup.c_remoteInstanceNotProvided, None)
		#l_unoObjectsContextExtraNameToValueMap:Dict [str, object] = Dict [str, object] ()
		l_unoObjectsContextExtraNameToValueMap:Dict [str, object] = dict ()
		l_unoObjectsContextExtraNameToValueMap.update ({UnoObjectsContextPropertyNamesSet.c_identification_string: UnoDatumConverter.getAny ("{0:s}: {1:s}".format (a_connectionInXConnection.getDescription (), a_connectionIdentification))})
		l_unoConnection:UnoConnection  = UnoConnection (cast (XComponentContext, l_remoteObjectsContextInXInterface), l_unoObjectsContextExtraNameToValueMap, l_bridgeInXBridge, a_eventListeners)
		return l_unoConnection

