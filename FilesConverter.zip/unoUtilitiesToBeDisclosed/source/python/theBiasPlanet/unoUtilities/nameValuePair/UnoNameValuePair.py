from com.sun.star.beans import NamedValue

class UnoNameValuePair (NamedValue):
	def __init__ (a_this: "UnoNameValuePair", a_name: str, a_value: object) -> None:
		NamedValue.__init__ (a_this, Name=a_name, Value=a_value)

