namespace theBiasPlanet {
	namespace unoUtilities {
		namespace connectionsHandling {
			using System;
			using System.Collections.Generic;
			using uno;
			using unoidl.com.sun.star.frame;
			using unoidl.com.sun.star.lang;
			using unoidl.com.sun.star.uno;
			using unoidl.com.sun.star.util;
			using theBiasPlanet.coreUtilities.constantsGroups;
			using theBiasPlanet.unoUtilities.constantsGroups;
			using theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;
			using theBiasPlanet.unoUtilities.servicesHandling;
			
			public class UnoObjectsContext : XComponentContext {
				private XComponentContext i_originalObjectsContextInXComponentContext;
				private Dictionary <String, Any> i_extraNameToValueMap;
				private XDesktop2 i_unoDesktopInXDesktop2;
				private XDispatchProvider i_unoDesktopInXDispatchProvider;
				private XURLTransformer i_urlTransformerInXURLTransformer;
				private XSynchronousDispatch i_fileOpeningUnoDispatcherInXSynchronousDispatch;
				
				public UnoObjectsContext (XComponentContext a_originalObjectsContextInXComponentContext, Dictionary <String, Any> a_extraNameToValueMap) {
					if (a_originalObjectsContextInXComponentContext == null) {
						//throw new unoidl.com.sun.star.uno.Exception (UnoMessagesConstantsGroup.c_objectsContextNotSpecified);
						throw new System.Exception (UnoMessagesConstantsGroup.c_objectsContextNotSpecified);
					}
					i_originalObjectsContextInXComponentContext = a_originalObjectsContextInXComponentContext;
					i_extraNameToValueMap = a_extraNameToValueMap;
					i_unoDesktopInXDesktop2 = null;
					i_unoDesktopInXDispatchProvider = null;
					i_urlTransformerInXURLTransformer = null;
					i_fileOpeningUnoDispatcherInXSynchronousDispatch = null;
				}
				
				public Any getValueByName (String a_name) {
					if (i_extraNameToValueMap != null && i_extraNameToValueMap.ContainsKey (a_name)) {
						return i_extraNameToValueMap [a_name];
					}
					return i_originalObjectsContextInXComponentContext.getValueByName (a_name);
				}
				
				public XMultiComponentFactory getServiceManager () {
					return i_originalObjectsContextInXComponentContext.getServiceManager ();
				}
				
				public bool isFromSameOrigin (UnoObjectsContext a_unoObjectsContext) {
					if ((a_unoObjectsContext ==  null) || !(i_extraNameToValueMap.ContainsKey (UnoObjectsContextPropertyNamesConstantsGroup.c_identification))) {
						return false;
					}
					if (i_extraNameToValueMap [UnoObjectsContextPropertyNamesConstantsGroup.c_identification].Equals (a_unoObjectsContext.getValueByName (UnoObjectsContextPropertyNamesConstantsGroup.c_identification))) {
						return true;
					}
					else {
						return false;
					}
				}
				
				public Object getServiceInstance (String a_serviceName, List <Object> a_arguments) {
					return UnoServiceHandler.getServiceInstance (this, a_serviceName, a_arguments);
				}
				
				public XDesktop2 getUnoDesktopInXDesktop2 () {
					if (i_unoDesktopInXDesktop2 == null) {
						i_unoDesktopInXDesktop2 = (XDesktop2) getServiceInstance (UnoServiceNamesConstantsGroup.c_com_sun_star_frame_Desktop, null);
					}
					else {
					}
					return i_unoDesktopInXDesktop2;
				}
				
				public XDispatchProvider getUnoDesktopInXDispatchProvider () {
					if (i_unoDesktopInXDispatchProvider == null) {
						if (i_unoDesktopInXDesktop2 == null) {
							getUnoDesktopInXDesktop2 ();
						}
						else {
						}
						i_unoDesktopInXDispatchProvider = (XDispatchProvider) i_unoDesktopInXDesktop2;
					}
					else {
					}
					return i_unoDesktopInXDispatchProvider;
				}
				
				public XSynchronousDispatch getFileOpeningUnoDispatcherInXSynchronousDispatch () {
					if (i_fileOpeningUnoDispatcherInXSynchronousDispatch == null) {
						i_fileOpeningUnoDispatcherInXSynchronousDispatch = (XSynchronousDispatch) getUnoDesktopInXDispatchProvider ().queryDispatch (createUrlInURL ("file:///"), UnoSpecialFrameNamesConstantsGroup.c_new, GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger);
					}
					return i_fileOpeningUnoDispatcherInXSynchronousDispatch;
				}
				
				public unoidl.com.sun.star.util.URL createUrlInURL (String a_url) {
					if (i_urlTransformerInXURLTransformer == null) {
						i_urlTransformerInXURLTransformer = (XURLTransformer) getServiceInstance (UnoServiceNamesConstantsGroup.c_com_sun_star_util_URLTransformer, null);
					}
					unoidl.com.sun.star.util.URL l_urlInURL = new unoidl.com.sun.star.util.URL ();
					l_urlInURL.Complete = a_url;
					i_urlTransformerInXURLTransformer.parseStrict (ref l_urlInURL);
					return l_urlInURL;
				}
			}
		}
	}
}

