namespace theBiasPlanet {
	namespace unoUtilities {
		namespace connectionsHandling {
			using System;
			using unoidl.com.sun.star.lang;
			
			public interface UnoConnectionEventsListener : XEventListener {
				void connected (EventObject a_event);
	
				void disconnected (EventObject a_event);
			}
		}
	}
}

