namespace theBiasPlanet {
	namespace unoUtilities {
		namespace nameValuePairsHandling {
			using System;
			using System.Collections.Generic;
			using uno;
			using unoidl.com.sun.star.beans;
			using theBiasPlanet.coreUtilities.constantsGroups;
			using theBiasPlanet.unoUtilities.nameValuePair;
			
			public class UnoNameValuePairsHandler {
				public static NamedValue [] buildNameValuePairsArray (List <String> a_names, List <Any> a_values) {
					if (a_names == null || a_values == null) {
						return null;
					}
					else {
						List <String> l_names = new List <String> ();
						List <Any> l_values = new List <Any> ();
						IEnumerator <Any> l_valuesIterator = a_values.GetEnumerator ();
						Any l_value;
						foreach (String l_name in a_names) {
							l_valuesIterator.MoveNext ();
							l_value = l_valuesIterator.Current;
							if (l_value.hasValue ()) {
								l_names.Add (l_name);
								l_values.Add (l_value);
							}
						}
						NamedValue [] l_nameValuePairsArray = new NamedValue [l_names.Count];
						l_valuesIterator = l_values.GetEnumerator ();
						int l_nameValuePairIndex = GeneralConstantsConstantsGroup.c_iterationStartingNumber;
						foreach (String l_name in l_names) {
							l_valuesIterator.MoveNext ();
							l_nameValuePairsArray [l_nameValuePairIndex] = new UnoNameValuePair (l_name, l_valuesIterator.Current);
							l_nameValuePairIndex ++;
						}
						return l_nameValuePairsArray;
					}
				}
			}
		}
	}
}


