namespace theBiasPlanet {
	namespace unoUtilities {
		namespace cryptography {
			using System;
			using System.Text;
			using theBiasPlanet.coreUtilities.constantsGroups;
			
			public class MicrosoftPasswordsHasher {
				private const int c_numberOfInitializationCodes = 15;
				private static readonly ushort [] c_initializationCodes = new ushort [] {(ushort) 0xE1F0, (ushort) 0x1D0F, (ushort) 0xCC9C, (ushort) 0x84C0, (ushort) 0x110C, (ushort) 0x0E10, (ushort) 0xF1CE, (ushort) 0x313E, (ushort) 0x1872, (ushort) 0xE139, (ushort) 0xD40F, (ushort) 0x84F9, (ushort) 0x280C, (ushort) 0xA96A, (ushort) 0x4EC3};
				private const int c_numberOfEncryptionMatrixColumns = 7;
				private static readonly ushort [, ] c_encryptionMatrix = new ushort [, ] {
					{ (ushort) 0xAEFC, (ushort) 0x4DD9, (ushort) 0x9BB2, (ushort) 0x2745, (ushort) 0x4E8A, (ushort) 0x9D14, (ushort) 0x2A09},
					{ (ushort) 0x7B61, (ushort) 0xF6C2, (ushort) 0xFDA5, (ushort) 0xEB6B, (ushort) 0xC6F7, (ushort) 0x9DCF, (ushort) 0x2BBF},
					{ (ushort) 0x4563, (ushort) 0x8AC6, (ushort) 0x05AD, (ushort) 0x0B5A, (ushort) 0x16B4, (ushort) 0x2D68, (ushort) 0x5AD0},
					{ (ushort) 0x0375, (ushort) 0x06EA, (ushort) 0x0DD4, (ushort) 0x1BA8, (ushort) 0x3750, (ushort) 0x6EA0, (ushort) 0xDD40},
					{ (ushort) 0xD849, (ushort) 0xA0B3, (ushort) 0x5147, (ushort) 0xA28E, (ushort) 0x553D, (ushort) 0xAA7A, (ushort) 0x44D5},
					{ (ushort) 0x6F45, (ushort) 0xDE8A, (ushort) 0xAD35, (ushort) 0x4A4B, (ushort) 0x9496, (ushort) 0x390D, (ushort) 0x721A},
					{ (ushort) 0xEB23, (ushort) 0xC667, (ushort) 0x9CEF, (ushort) 0x29FF, (ushort) 0x53FE, (ushort) 0xA7FC, (ushort) 0x5FD9},
					{ (ushort) 0x47D3, (ushort) 0x8FA6, (ushort) 0x8FA6, (ushort) 0x1EDA, (ushort) 0x3DB4, (ushort) 0x7B68, (ushort) 0xF6D0},
					{ (ushort) 0xB861, (ushort) 0x60E3, (ushort) 0xC1C6, (ushort) 0x93AD, (ushort) 0x377B, (ushort) 0x6EF6, (ushort) 0xDDEC},
					{ (ushort) 0x45A0, (ushort) 0x8B40, (ushort) 0x06A1, (ushort) 0x0D42, (ushort) 0x1A84, (ushort) 0x3508, (ushort) 0x6A10},
					{ (ushort) 0xAA51, (ushort) 0x4483, (ushort) 0x8906, (ushort) 0x022D, (ushort) 0x045A, (ushort) 0x08B4, (ushort) 0x1168},
					{ (ushort) 0x76B4, (ushort) 0xED68, (ushort) 0xCAF1, (ushort) 0x85C3, (ushort) 0x1BA7, (ushort) 0x374E, (ushort) 0x6E9C},
					{ (ushort) 0x3730, (ushort) 0x6E60, (ushort) 0xDCC0, (ushort) 0xA9A1, (ushort) 0x4363, (ushort) 0x86C6, (ushort) 0x1DAD},
					{ (ushort) 0x3331, (ushort) 0x6662, (ushort) 0xCCC4, (ushort) 0x89A9, (ushort) 0x0373, (ushort) 0x06E6, (ushort) 0x0DCC},
					{ (ushort) 0x1021, (ushort) 0x2042, (ushort) 0x4084, (ushort) 0x8108, (ushort) 0x1231, (ushort) 0x2462, (ushort) 0x48C4}
				};
				
				public static int hashIn32bits (String a_originalDatum) {
					uint l_hash = 0;
					int l_originalDatumLength = a_originalDatum.Length;
					if (l_originalDatumLength > 0) {
						if (l_originalDatumLength > c_numberOfInitializationCodes) {
					   		l_originalDatumLength = c_numberOfInitializationCodes;
						}
						ushort l_highHash = c_initializationCodes [l_originalDatumLength - 1];
						ushort l_lowHash = 0;
						char l_character = (char) 0x0000;
						byte l_byte = 0x00;
						byte l_highByte = 0x00;
						byte l_lowByte = 0x00;
						for (int l_characterIndex = GeneralConstantsConstantsGroup.c_iterationStartingNumber; l_characterIndex < l_originalDatumLength; l_characterIndex ++) {
							l_character = a_originalDatum [l_characterIndex];
							l_highByte = (byte) (l_character >> 8);
							l_lowByte = (byte) (l_character & 0xFF);
							l_byte = l_lowByte != 0x00 ? l_lowByte : l_highByte;
							for (int l_matrixcolumnIndex = GeneralConstantsConstantsGroup.c_iterationStartingNumber; l_matrixcolumnIndex < c_numberOfInitializationCodes; l_matrixcolumnIndex ++) {
								if ((l_byte & (1 << l_matrixcolumnIndex)) != 0) {
									l_highHash = (ushort) (l_highHash ^ c_encryptionMatrix [c_numberOfInitializationCodes - l_originalDatumLength + l_characterIndex, l_matrixcolumnIndex]);
								}
							}
							l_character = a_originalDatum [l_originalDatumLength -1 - l_characterIndex];
							l_highByte = (byte) (l_character >> 8);
							l_lowByte = (byte) (l_character & 0xFF);
							l_byte = l_lowByte != 0x00 ? l_lowByte : l_highByte;
							l_lowHash = (ushort) (( ( (l_lowHash >> 14) & 0x0001 ) | ( (l_lowHash << 1) & 0x7FFF)) ^ l_byte);
						}
						l_lowHash =  (ushort) (( ( (l_lowHash >> 14) & 0x0001) | ( (l_lowHash << 1) & 0x7FFF)) ^ l_originalDatumLength ^ 0xCE4B);
						l_hash = (uint) ((l_highHash << 16) | l_lowHash);
					}
					return (int) l_hash;
				}
				
				public static short hashIn16bits (String a_originalDatum) {
					ushort l_hash = 0;
					byte [] l_originalDatumUtf8BytesArray = null;
					try {
						l_originalDatumUtf8BytesArray = Encoding.UTF8.GetBytes (a_originalDatum);
					}
					catch (Exception l_exception) {
						// Is supposed to never happen.
					}
					int l_originalDatumUtf8BytesArrayLength = l_originalDatumUtf8BytesArray.Length;
					if (l_originalDatumUtf8BytesArrayLength <= Int16.MaxValue) {
						for (int l_byteIndex = l_originalDatumUtf8BytesArrayLength - 1; l_byteIndex >= GeneralConstantsConstantsGroup.c_iterationStartingNumber; l_byteIndex --) {
							l_hash = (ushort) (( (l_hash >> 14) & 0x01) | ( (l_hash << 1) & 0x7FFF));
							l_hash ^= l_originalDatumUtf8BytesArray [l_byteIndex];
						}
						l_hash = (ushort) (( (l_hash >> 14) & 0x01) | ( (l_hash << 1) & 0x7FFF));
						l_hash ^= (0x8000 | ('N' << 8) | 'K');
						l_hash ^= (ushort) l_originalDatumUtf8BytesArrayLength;
					}
					return (short)l_hash;
				}
			}
		}
	}
}

