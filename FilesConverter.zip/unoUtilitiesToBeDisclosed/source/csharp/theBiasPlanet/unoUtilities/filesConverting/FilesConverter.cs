namespace theBiasPlanet {
	namespace unoUtilities {
		namespace filesConverting {
			using System;
			using System.Collections.Generic;
			using uno;
			using unoidl.com.sun.star.beans;
			using unoidl.com.sun.star.container;
			using unoidl.com.sun.star.frame;
			using unoidl.com.sun.star.lang;
			using unoidl.com.sun.star.sheet;
			using unoidl.com.sun.star.util;
			using theBiasPlanet.coreUtilities.collectionsHandling;
			using theBiasPlanet.coreUtilities.constantsGroups;
			using theBiasPlanet.coreUtilities.messaging;
			using theBiasPlanet.unoUtilities.connectionsHandling;
			using theBiasPlanet.unoUtilities.constantsGroups;
			using theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;
			using theBiasPlanet.unoUtilities.documentsHandling;
			using theBiasPlanet.unoUtilities.propertiesHandling;
			using theBiasPlanet.unoUtilities.unoDataHandling;
			
			public class FilesConverter {
				private static readonly String c_csvFormatStringFormat = "{0:d},{1:d},{2:d},1,,0,{3:s},false,{4:s},{5:s},false"; // the CSV items delimiter character code (can be specified like 'Character.codePointAt ("\t", 0)'), the CSV text items quotation character code (can be specified like 'Character.codePointAt ("\"", 0)'), the encoding code (76 -> UTF-8, 65535 -> UCS-2, 65534 -> UCS-4, 11 -> US-ASCII, 69 -> EUC_JP, 64 -> SHIFT_JIS), whether all the text items are quoted, whether the contents are exported as shown, whether the formula themselves are exported
				private UnoObjectsContext i_remoteUnoObjectsContext = null;
				private XSynchronousDispatch i_fileOpeningUnoDispatcherInXSynchronousDispatch;
				
				public FilesConverter (UnoObjectsContext a_remoteUnoObjectsContext) {
					i_remoteUnoObjectsContext = a_remoteUnoObjectsContext;
					i_fileOpeningUnoDispatcherInXSynchronousDispatch = i_remoteUnoObjectsContext.getFileOpeningUnoDispatcherInXSynchronousDispatch ();
				}
				
				public bool convertFile (String a_convertedFileUrl, String a_convertedFilePassword, String a_targetFileUrl, PropertyValue [] a_documentStoringPropertiesArray, UnoDocumentTailor a_unoDocumentTailor) {
					unoidl.com.sun.star.util.URL l_convertedFileUrlInURL = i_remoteUnoObjectsContext.createUrlInURL (a_convertedFileUrl);
					PropertyValue [] l_unoDocumentOpeningPropertiesArray = UnoPropertiesHandler.buildPropertiesArray (UnoDocumentOpeningEnumerablePropertyNamesSet.c_instance.getValues (), ListsFactory.createList <Any> (UnoDatumConverter.getAny (true), UnoDatumConverter.getAny (true), UnoDatumConverter.getAny (true), UnoDatumConverter.getAny (true), UnoDatumConverter.getAny (a_convertedFilePassword != null ? a_convertedFilePassword: "")));
					Any l_convertedUnoDocumentInAny = (Any) i_fileOpeningUnoDispatcherInXSynchronousDispatch.dispatchWithReturnValue (l_convertedFileUrlInURL, l_unoDocumentOpeningPropertiesArray);
					bool l_hasSucceeded = false;
					if (l_convertedUnoDocumentInAny.hasValue ()) {
						XComponent l_convertedUnoDocumentInXComponent = (XComponent) l_convertedUnoDocumentInAny.Value;
						try {
							if (a_unoDocumentTailor != null) {
								a_unoDocumentTailor.tailor (l_convertedUnoDocumentInXComponent);
							}
							XStorable2 l_convertedUnoDocumentInXStorable2 = (XStorable2) l_convertedUnoDocumentInXComponent;
							l_convertedUnoDocumentInXStorable2.storeToURL (a_targetFileUrl, a_documentStoringPropertiesArray);
							l_hasSucceeded = true;
						}
						catch (Exception l_exception) {
							throw l_exception;
						}
						XCloseable l_convertedUnoDocumentInXCloseable = (XCloseable) l_convertedUnoDocumentInXComponent;
						l_convertedUnoDocumentInXCloseable.close (false); 
					}
					else {
					}
					return l_hasSucceeded;
				}
				
				public static PropertyValue [] createCsvFileStoringPropertiesArray (int a_itemsDelimiterCharacterCode, int a_textItemQuotationCharacterCode, int a_charactersEncodingCode, bool a_whetherAllTextItemsAreQuoted, bool a_whetherContentsAreExportedAsShown, bool a_whetherFormulaThemselvesAreExported) {
					List <String> l_documentStoringPropertyNames = ListsFactory.createList <String> (
						UnoDocumentStoringEnumerablePropertyNamesSet.c_filterName_string,
						UnoDocumentStoringEnumerablePropertyNamesSet.c_filterData_string,
						UnoDocumentStoringEnumerablePropertyNamesSet.c_overwrites_boolen
					);
					List <Any> l_documentStoringPropertyValues = ListsFactory.createList <Any> (
						UnoDatumConverter.getAny (UnoFileStoringFilterNamesConstantsGroup.c_csvFileFilterName),
						UnoDatumConverter.getAny (String.Format (c_csvFormatStringFormat, a_itemsDelimiterCharacterCode, a_textItemQuotationCharacterCode, a_charactersEncodingCode, a_whetherAllTextItemsAreQuoted.ToString ().ToLower (), a_whetherContentsAreExportedAsShown.ToString ().ToLower (), a_whetherFormulaThemselvesAreExported.ToString ().ToLower ())),
						UnoDatumConverter.getAny (true)
					);
					return UnoPropertiesHandler.buildPropertiesArray (l_documentStoringPropertyNames, l_documentStoringPropertyValues);
				}
				
				// a_targetFileNamingRule: 0 -> augmented by the sheet index, 1 -> augmented by the sheet name
				public bool convertSpreadSheetsDocumentFileToCsvFiles (String a_convertedFileUrl, String a_convertedFilePassword, String a_targetFileUrlBase, PropertyValue [] a_documentStoringPropertiesArray, UnoDocumentTailor a_unoDocumentTailor, int a_targetFileNamingRule, bool a_hiddenSpreadSheetsAreWritten) {
					unoidl.com.sun.star.util.URL l_convertedFileUrlInURL = i_remoteUnoObjectsContext.createUrlInURL (a_convertedFileUrl);
					PropertyValue [] l_unoDocumentOpeningPropertiesArray = UnoPropertiesHandler.buildPropertiesArray (UnoDocumentOpeningEnumerablePropertyNamesSet.c_instance.getValues (), ListsFactory.createList <Any> (UnoDatumConverter.getAny (true), UnoDatumConverter.getAny (true), UnoDatumConverter.getAny (true), UnoDatumConverter.getAny (true), UnoDatumConverter.getAny (a_convertedFilePassword != null ? a_convertedFilePassword: "")));
					Any l_convertedUnoDocumentInAny = (Any) i_fileOpeningUnoDispatcherInXSynchronousDispatch.dispatchWithReturnValue (l_convertedFileUrlInURL, l_unoDocumentOpeningPropertiesArray);
					bool l_hasSucceeded = false;
					if (l_convertedUnoDocumentInAny.hasValue ()) {
						XComponent l_convertedUnoDocumentInXComponent = (XComponent) l_convertedUnoDocumentInAny.Value;
						try {
							if (a_unoDocumentTailor != null) {
								a_unoDocumentTailor.tailor (l_convertedUnoDocumentInXComponent);
							}
							XSpreadsheetDocument l_spreadSheetsDocumentInXSpreadsheetDocument = (XSpreadsheetDocument) l_convertedUnoDocumentInXComponent;
							if (l_spreadSheetsDocumentInXSpreadsheetDocument == null) {
								Publisher.logErrorInformation ("The document is not any spread sheet.");
								return false;
							}
							else {
								XStorable2 l_convertedUnoDocumentInXStorable2 = (XStorable2) l_convertedUnoDocumentInXComponent;
								XSpreadsheets2 l_spreadSheetsInXSpreadsheets2 = (XSpreadsheets2) l_spreadSheetsDocumentInXSpreadsheetDocument.getSheets ();
								XIndexAccess l_spreadSheetsInXIndexAccess = (XIndexAccess) l_spreadSheetsInXSpreadsheets2;
								int l_numberOfSheets = l_spreadSheetsInXIndexAccess.getCount ();
								XNamed l_spreadSheetInXNamed = null;
								XPropertySet l_spreadSheetInXPropertySet = null;
								String l_targetFileNameAugmentation = null;
								int l_lastPeriodPositionInTargetFileUrlBase = a_targetFileUrlBase.LastIndexOf (".");
								String l_augmentedTargetFileUrl = null;
								bool l_whetherSheetIsVisible = false;
								for (int l_sheetIndex = GeneralConstantsConstantsGroup.c_iterationStartingNumber; l_sheetIndex < l_numberOfSheets; l_sheetIndex ++) {
									l_spreadSheetInXNamed = (XNamed) ((Any) l_spreadSheetsInXIndexAccess.getByIndex (l_sheetIndex)).Value;
									if (a_hiddenSpreadSheetsAreWritten) {
									}
									else {
										l_spreadSheetInXPropertySet = (XPropertySet) l_spreadSheetInXNamed;
										l_whetherSheetIsVisible = (bool) UnoDatumConverter.getObject (l_spreadSheetInXPropertySet.getPropertyValue (UnoSpreadSheetPropertyNamesSet.c_whetherIsVisible_boolean)); 
										if (!l_whetherSheetIsVisible) {
											continue;
										}
									}
									if (a_targetFileNamingRule == 0) {
										l_targetFileNameAugmentation = String.Format ("{0}", l_sheetIndex);
									}
									else {
										l_targetFileNameAugmentation = l_spreadSheetInXNamed.getName (); 
									}
									if (l_lastPeriodPositionInTargetFileUrlBase >= GeneralConstantsConstantsGroup.c_iterationStartingNumber) {
										l_augmentedTargetFileUrl = String.Format ("{0}_{1}{2}", a_targetFileUrlBase.Substring (GeneralConstantsConstantsGroup.c_iterationStartingNumber, l_lastPeriodPositionInTargetFileUrlBase), l_targetFileNameAugmentation, a_targetFileUrlBase.Substring (l_lastPeriodPositionInTargetFileUrlBase));
									}
									else {
										l_augmentedTargetFileUrl = String.Format ("{0}_{1}", a_targetFileUrlBase, l_targetFileNameAugmentation);
									}
									if (l_sheetIndex != GeneralConstantsConstantsGroup.c_iterationStartingNumber) {
										l_spreadSheetsInXSpreadsheets2.moveByName (l_spreadSheetInXNamed.getName (), (short) GeneralConstantsConstantsGroup.c_iterationStartingNumber);
									}
									l_convertedUnoDocumentInXStorable2.storeToURL (l_augmentedTargetFileUrl, a_documentStoringPropertiesArray);
								}
								l_hasSucceeded = true;
							}
						}
						catch (Exception l_exception) {
							throw l_exception;
						}
						XCloseable l_convertedUnoDocumentInXCloseable = (XCloseable) l_convertedUnoDocumentInXComponent;
						l_convertedUnoDocumentInXCloseable.close (false); 
					}
					else {
					}
					return l_hasSucceeded;
				}
			}
		}
	}
}

