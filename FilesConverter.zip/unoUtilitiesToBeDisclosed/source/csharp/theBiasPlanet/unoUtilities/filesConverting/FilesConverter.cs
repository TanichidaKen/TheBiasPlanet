namespace theBiasPlanet {
	namespace unoUtilities {
		namespace filesConverting {
			using System;
			using uno;
			using unoidl.com.sun.star.beans;
			using unoidl.com.sun.star.frame;
			using unoidl.com.sun.star.lang;
			using unoidl.com.sun.star.util;
			using theBiasPlanet.coreUtilities.collectionsHandling;
			using theBiasPlanet.unoUtilities.connectionsHandling;
			using theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;
			using theBiasPlanet.unoUtilities.documentsHandling;
			using theBiasPlanet.unoUtilities.propertiesHandling;
			
			public class FilesConverter {
				private UnoObjectsContext i_remoteUnoObjectsContext = null;
				private readonly PropertyValue [] i_unoDocumentOpeningPropertiesArray;
				private XSynchronousDispatch i_fileOpeningUnoDispatcherInXSynchronousDispatch;
				
				public FilesConverter (UnoObjectsContext a_remoteUnoObjectsContext) {
					i_remoteUnoObjectsContext = a_remoteUnoObjectsContext;
					i_unoDocumentOpeningPropertiesArray = UnoPropertiesHandler.buildPropertiesArray (UnoDocumentOpeningEnumerablePropertyNamesSet.c_instance.getValues (), ListsFactory.createList <Object> (true, true, true, true));
					i_fileOpeningUnoDispatcherInXSynchronousDispatch = i_remoteUnoObjectsContext.getFileOpeningUnoDispatcherInXSynchronousDispatch ();
				}
				
				public bool convertFile (String a_convertedFileUrl, String a_targetFileUrl, PropertyValue [] a_documentStoringPropertiesArray, UnoDocumentTailor a_unoDocumentTailor) {
					unoidl.com.sun.star.util.URL l_convertedFileUrlInURL = i_remoteUnoObjectsContext.createUrlInURL (a_convertedFileUrl);
					Any l_convertedUnoDocumentInAny = (Any) i_fileOpeningUnoDispatcherInXSynchronousDispatch.dispatchWithReturnValue (l_convertedFileUrlInURL, i_unoDocumentOpeningPropertiesArray);
					bool l_hasSucceeded = false;
					if (l_convertedUnoDocumentInAny.hasValue ()) {
						XComponent l_convertedUnoDocumentInXComponent = (XComponent) l_convertedUnoDocumentInAny.Value;
						try {
							if (a_unoDocumentTailor != null) {
								a_unoDocumentTailor.tailor (l_convertedUnoDocumentInXComponent);
							}
							XStorable2 l_convertedUnoDocumentInXStorable2 = (XStorable2) l_convertedUnoDocumentInXComponent;
							l_convertedUnoDocumentInXStorable2.storeToURL (a_targetFileUrl, a_documentStoringPropertiesArray);
							l_hasSucceeded = true;
						}
						catch (Exception l_exception) {
							throw l_exception;
						}
						XCloseable l_convertedUnoDocumentInXCloseable = (XCloseable) l_convertedUnoDocumentInXComponent;
						l_convertedUnoDocumentInXCloseable.close (false); 
					}
					else {
					}
					return l_hasSucceeded;
				}
			}
		}
	}
}

