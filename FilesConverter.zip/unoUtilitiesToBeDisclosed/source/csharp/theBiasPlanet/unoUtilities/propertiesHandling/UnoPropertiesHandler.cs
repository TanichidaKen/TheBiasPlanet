namespace theBiasPlanet {
	namespace unoUtilities {
		namespace propertiesHandling {
			using System;
			using System.Collections.Generic;
			using uno;
			using unoidl.com.sun.star.beans;
			using theBiasPlanet.coreUtilities.constantsGroups;
			using theBiasPlanet.unoUtilities.property;
			
			public class UnoPropertiesHandler {
				public static PropertyValue [] buildPropertiesArray (List <String> a_propertyNames, List <Any> a_propertyValues) {
					if (a_propertyNames == null || a_propertyValues == null) {
						return null;
					}
					else {
						List <String> l_propertyNames = new List <String> ();
						List <Any> l_propertyValues = new List <Any> ();
						IEnumerator <Any> l_propertyValuesIterator = a_propertyValues.GetEnumerator ();
						Any l_propertyValue;
						foreach (String l_propertyName in a_propertyNames) {
							l_propertyValuesIterator.MoveNext ();
							l_propertyValue = l_propertyValuesIterator.Current;
							if (l_propertyValue.hasValue ()) {
								l_propertyNames.Add (l_propertyName);
								l_propertyValues.Add (l_propertyValue);
							}
						}
						PropertyValue [] l_propertiesArray = new PropertyValue [l_propertyNames.Count];
						l_propertyValuesIterator = l_propertyValues.GetEnumerator ();
						int l_propertyIndex = GeneralConstantsConstantsGroup.c_iterationStartingNumber;
						foreach (String l_propertyName in l_propertyNames) {
							l_propertyValuesIterator.MoveNext ();
							l_propertiesArray [l_propertyIndex] = new UnoProperty (l_propertyName, l_propertyValuesIterator.Current);
							l_propertyIndex ++;
						}
						return l_propertiesArray;
					}
				}
			}
		}
	}
}

