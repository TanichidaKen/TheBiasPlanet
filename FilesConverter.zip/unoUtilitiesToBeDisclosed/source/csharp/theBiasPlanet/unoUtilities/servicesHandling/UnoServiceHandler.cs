namespace theBiasPlanet {
	namespace unoUtilities {
		namespace servicesHandling {
			using System;
			using System.Collections.Generic;
			using uno;
			using theBiasPlanet.coreUtilities.collectionsHandling;
			using theBiasPlanet.unoUtilities.connectionsHandling;
			
			public class UnoServiceHandler {
				private UnoServiceHandler () {
				}
				
				public static Object getServiceInstance (UnoObjectsContext a_objectsContext, String a_serviceName, List <Object> a_arguments) {
					Object l_serviceInstance = null;
					Object l_targetProxy = null;
					if (a_arguments == null) {
						l_serviceInstance = a_objectsContext.getServiceManager ().createInstanceWithContext (a_serviceName, a_objectsContext);
					}
					else {
						l_serviceInstance = a_objectsContext.getServiceManager ().createInstanceWithArgumentsAndContext (a_serviceName, ArraysFactory.createArray  <Any> (a_arguments), a_objectsContext);
					}
					if (l_serviceInstance != null) {
						l_targetProxy =  l_serviceInstance;
					}
					return l_targetProxy;
				}
			}
		}
	}
}

