namespace theBiasPlanet {
	namespace unoUtilities {
		namespace property {
			using System;
			using uno;
			using unoidl.com.sun.star.beans;
			
			public class UnoProperty : PropertyValue {
				public UnoProperty (String a_name, Any a_value) {
					Name = a_name;
					Value = a_value;
				}
			}
		}
	}
}

