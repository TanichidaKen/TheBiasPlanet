namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			using System;
			using theBiasPlanet.coreUtilities.constantsGroups;
			using theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;
			
			public static class UnoDispatchSlotsConstantsGroup {
				public static readonly BaseDispatchSlot c__uno_StyleNewByExample = new BaseDispatchSlot (".uno:StyleNewByExample", Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet.c_instance);
				public static readonly BaseDispatchSlot c__uno_GoToCell = new BaseDispatchSlot (".uno:GoToCell", Uno_uno_GoToCellEnumerablePropertyNamesSet.c_instance);
				
				// Base class for all the constants in this group
				public class BaseDispatchSlot {
					public readonly String c_url;
					public readonly BaseEnumerableConstantsGroup <String> c_argumentPropertyNamesSet;
					
					public BaseDispatchSlot (String a_url, BaseEnumerableConstantsGroup <String> a_argumentPropertyNamesSet) {
						c_url = a_url;
						c_argumentPropertyNamesSet = a_argumentPropertyNamesSet;
					}
				}
			}
		}
	}
}

