namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			using System;
			
			public static class UnoFileNameSuffixesConstantsGroup {
				public const String c_unoIdlFileNameSuffix = "idl";
				public const String c_unoDataTypesMergedRegistryFileNameSuffix = "rdb";
			}
		}
	}
}

