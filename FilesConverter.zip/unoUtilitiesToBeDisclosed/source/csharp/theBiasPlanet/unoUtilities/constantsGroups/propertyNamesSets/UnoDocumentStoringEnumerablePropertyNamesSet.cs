namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			namespace propertyNamesSets {
				using System;
				using theBiasPlanet.coreUtilities.constantsGroups;
				
				public class UnoDocumentStoringEnumerablePropertyNamesSet : BaseEnumerableConstantsGroup <String>, UnoPropertyNamesSet  {
					public const String c_filterName_String = "FilterName";
					public const String c_filterData_Object = "FilterData"; // supposed to be, but not necessarily, a sequence of 'com.sun.star.beans.PropertyValue'
					public const String c_isTemplate_Boolean = "AsTemplate";
					public const String c_authorName_String = "Author";
					public const String c_title_String = "DocumentTitle";
					public const String c_password_String = "Password";
					public const String c_charactersSet_String = "CharacterSet";
					public const String c_version_Short = "Version";
					public const String c_versionDescription_String = "Comment";
					public const String c_overwrites_Boolen = "Overwrite";
					public const String c_documentTypeSpecificData_Object = "ComponentData"; // supposed to be, but not necessarily, a sequence of com.sun.star.beans.NamedValue
					public readonly UnoDocumentStoringEnumerablePropertyNamesSet c_instance = new UnoDocumentStoringEnumerablePropertyNamesSet ();
					
					private UnoDocumentStoringEnumerablePropertyNamesSet () {
					}
				}
			}
		}
	}
}

