namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			using System;
			
			public static class UnoDocumentEventNamesConstantsGroup {
				public const String c_documentDatumLoaded = "OnLoadFinished";
				public const String c_titleChanged = "OnTitleChanged";
				public const String c_focused = "OnFocus";
				public const String c_viewCreated = "OnViewCreated";
				public const String c_pagesCountChanged = "OnPageCountChange";
				public const String c_frameDatumLoaded = "OnLoad";
				public const String c_layouted = "OnLayoutFinished";
				public const String c_preparingViewClosing = "OnPrepareViewClosing";
				public const String c_preparingFrameUnloading = "OnPrepareUnload";
				public const String c_viewClosed = "OnViewClosed";
				public const String c_frameUnloaded = "OnUnload";
				public const String c_unfocused = "OnUnfocus";
			}
		}
	}
}

