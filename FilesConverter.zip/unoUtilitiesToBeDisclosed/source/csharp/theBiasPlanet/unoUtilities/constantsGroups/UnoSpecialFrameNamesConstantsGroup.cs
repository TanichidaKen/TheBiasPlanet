namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			using System;
			
			public static class UnoSpecialFrameNamesConstantsGroup {
				public const String c_new = "_blank";
				public const String c_default = "_default";
				public const String c_self = "_self";
				public const String c_parent = "_parent";
				public const String c_top = "_top";
				public const String c_specialSub = "_beamer";
			}
		}
	}
}

