namespace theBiasPlanet {
	namespace unoUtilities {
		namespace documentsHandling {
			using System;
			using uno;
			using unoidl.com.sun.star.container;
			using unoidl.com.sun.star.lang;
			using unoidl.com.sun.star.sheet;
			using theBiasPlanet.coreUtilities.constantsGroups;
			using theBiasPlanet.coreUtilities.messaging;
			using theBiasPlanet.unoUtilities.connectionsHandling;
			
			public class UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor : UnoDocumentTailor {
				private int i_targetSpreadSheetIndex;
				
				public UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor (UnoObjectsContext a_objectsContext, int a_targetSpreadSheetIndex) : base (a_objectsContext) {
					i_targetSpreadSheetIndex = a_targetSpreadSheetIndex;
				}
				
				public override bool tailor (XComponent a_unoDocumentInXComponent) {
					XSpreadsheetDocument l_spreadSheetsDocumentInXSpreadsheetDocument = (XSpreadsheetDocument) a_unoDocumentInXComponent;
					if (l_spreadSheetsDocumentInXSpreadsheetDocument == null) {
						Publisher.logErrorInformation ("The document is not any spread sheet.");
						return false;
					}
					else {
						XIndexAccess l_spreadSheetsInXIndexAccess = (XIndexAccess) l_spreadSheetsDocumentInXSpreadsheetDocument.getSheets ();
						try {
							XSpreadsheet l_spreadSheetInXSpreadsheet = (XSpreadsheet) (((Any) l_spreadSheetsInXIndexAccess.getByIndex (i_targetSpreadSheetIndex)).Value);
							XNamed l_spreadSheetInXNamed = (XNamed) l_spreadSheetInXSpreadsheet;
							((XSpreadsheets) l_spreadSheetsInXIndexAccess).moveByName (l_spreadSheetInXNamed.getName (), (short) GeneralConstantsConstantsGroup.c_iterationStartingNumber);
							return true;
						}
						catch (Exception l_exception) {
							Publisher.logErrorInformation (l_exception);
							return false;
						}
					}
				}
			}
		}
	}
}

