namespace theBiasPlanet {
	namespace unoUtilities {
		namespace documentsHandling {
			namespace textDocumentsHandling {
				using System;
				using unoidl.com.sun.star.lang;
				using unoidl.com.sun.star.text;
				using theBiasPlanet.unoUtilities.connectionsHandling;
				using theBiasPlanet.unoUtilities.constantsGroups;
				
				public class UnoTextDocument : UnoDocument {
					private XTextDocument i_textDocumentInXTextDocument;
					private XTextViewCursorSupplier i_controllerInXTextViewCursorSupplier;
					public UnoTextDocument (UnoObjectsContext a_objectsContext, XComponent a_textDocumentInXComponent) : base (a_objectsContext, a_textDocumentInXComponent) {
						i_textDocumentInXTextDocument = (XTextDocument) a_textDocumentInXComponent;
						if (i_textDocumentInXTextDocument == null) {
							throw new Exception (UnoMessagesConstantsGroup.c_isNotTextDocument);
						}
						i_controllerInXTextViewCursorSupplier = (XTextViewCursorSupplier) i_controllerInXController;
					}
					
					public static UnoTextDocument createTextDocument (UnoObjectsContext a_objectsContext, bool a_hiddenly) {
						return new UnoTextDocument (a_objectsContext, UnoDocument.createUnoDocumentOrOpenUnoDocumentFile (a_objectsContext, UnoSpecialFileUrlsConstantsGroup.c_writerNewDocument, a_hiddenly));
					}
					
					public static UnoTextDocument openTextDocumentFile (UnoObjectsContext a_objectsContext, String a_fileUrl, bool a_hiddenly) {
						return new UnoTextDocument (a_objectsContext, UnoDocument.createUnoDocumentOrOpenUnoDocumentFile (a_objectsContext, a_fileUrl, a_hiddenly));
					}
					
					public static UnoTextDocument getCurrentTextDocument (UnoObjectsContext a_objectsContext) {
						return new UnoTextDocument (a_objectsContext, getCurrentUnoDocument (a_objectsContext));
					}
					
					public XTextViewCursor getViewCursor () {
						return i_controllerInXTextViewCursorSupplier.getViewCursor ();
					}
				}
			}
		}
	}
}

