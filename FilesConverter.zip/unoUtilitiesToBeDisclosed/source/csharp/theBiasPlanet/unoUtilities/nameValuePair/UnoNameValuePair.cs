namespace theBiasPlanet {
	namespace unoUtilities {
		namespace nameValuePair {
			using System;
			using uno;
			using unoidl.com.sun.star.beans;
			
			public class UnoNameValuePair : NamedValue {
				public UnoNameValuePair (String a_name, Any a_value) {
					Name = a_name;
					Value = a_value;
				}
			}
		}
	}
}

