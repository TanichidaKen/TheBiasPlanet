#ifndef __theBiasPlanet_unoUtilities_property_UnoProperty_hpp__
	#define __theBiasPlanet_unoUtilities_property_UnoProperty_hpp__
	
	#include <string>
	#include <com/sun/star/beans/PropertyValue.hpp>
	#include <com/sun/star/uno/Any.h>
	#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	using namespace ::com::sun::star::beans;
	using namespace ::com::sun::star::uno;
	
	namespace theBiasPlanet {
		namespace unoUtilities {
			namespace property {
				class __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ UnoProperty : public PropertyValue {
					public:
						UnoProperty (string a_name, Any a_value);
				};
			}
		}
	}
#endif


