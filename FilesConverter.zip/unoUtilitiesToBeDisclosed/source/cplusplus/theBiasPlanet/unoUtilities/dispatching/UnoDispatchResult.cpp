#include "theBiasPlanet/unoUtilities/dispatching/UnoDispatchResult.hpp"
#include <iomanip>
#include <iostream>
#include <com/sun/star/frame/DispatchResultState.hpp>
#include <com/sun/star/uno/Type.h>
#include <rtl/ustring.hxx>
#include "theBiasPlanet/coreUtilities/stringsHandling/StringHandler.hpp"
#include "theBiasPlanet/unoUtilities/unoDataHandling/UnoDatumConverter.hpp"
#include "theBiasPlanet/unoUtilities/stringsHandling/UnoExtendedStringHandler.hpp"

using namespace ::std;
using namespace ::rtl;
using namespace ::com::sun::star::frame;
using namespace ::theBiasPlanet::coreUtilities::stringsHandling;
using namespace ::theBiasPlanet::unoUtilities::stringsHandling;
using namespace ::theBiasPlanet::unoUtilities::unoDataHandling;

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace dispatching {
			UnoDispatchResult::UnoDispatchResult () : i_finalStatus (DispatchResultState::FAILURE), i_dispatchResult (), i_relatedInformation () {
			}
			
			Any UnoDispatchResult::getDispatchResult () {
				return i_dispatchResult;
			}
			
			void UnoDispatchResult::setDispatchResult (DispatchResultEvent const & a_dispatchResultEvent) {
				i_finalStatus = a_dispatchResultEvent.State;
				i_dispatchResult = a_dispatchResultEvent.Result;
			}
			
			list <Any> UnoDispatchResult::getRelatedInformation () {
				return i_relatedInformation;
			}
			
			void UnoDispatchResult::addRelatedInformationPiece (FeatureStateEvent const & a_featureStateEvent) {
				i_relatedInformation.push_back (a_featureStateEvent.State);
			}
			
			string UnoDispatchResult::toString () {
				ostringstream l_resultStream;
				l_resultStream << string ("State = ");
				l_resultStream << StringHandler::format (string ("%d"), i_finalStatus);
				l_resultStream << string (", Result = ");
				if (i_dispatchResult.hasValue ()) {
					l_resultStream << UnoDatumConverter::convertToNonUnoDatum (i_dispatchResult);
				}
				else {
					l_resultStream << string ("null");
				}
				l_resultStream << string (", Related information = ");
				bool l_isInFirstIterationOfRelatedInformationPieces = true;
				for (Any const l_relatedInformationPiece: i_relatedInformation) {
					if (!l_isInFirstIterationOfRelatedInformationPieces) {
						l_resultStream << string (", ");
					}
					else {
						l_isInFirstIterationOfRelatedInformationPieces = false;
					}
					if (l_relatedInformationPiece.hasValue ()) {
						l_resultStream <<  UnoExtendedStringHandler::getString (l_relatedInformationPiece.getValueTypeName ());
						l_resultStream << string (": ");
						l_resultStream << UnoDatumConverter::convertToNonUnoDatum (l_relatedInformationPiece);
					}
					else {
						l_resultStream << string ("null");
					}
				}
				return l_resultStream.str ();
			}
		}
	}
}

