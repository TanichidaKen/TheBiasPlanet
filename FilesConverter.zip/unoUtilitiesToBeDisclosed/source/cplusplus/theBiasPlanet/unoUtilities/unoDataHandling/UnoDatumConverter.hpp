#ifndef __theBiasPlanet_unoUtilities_unoDataHandling_UnoDatumConverter_hpp__
	#define __theBiasPlanet_unoUtilities_unoDataHandling_UnoDatumConverter_hpp__
	
	#include <cstddef>
	#include <list>
	#include <optional>
	#include <string>
	#include <com/sun/star/uno/Any.hxx>
	#include <com/sun/star/uno/Sequence.hxx>
	#include <com/sun/star/uno/Type.hxx>
	#include <cppu/unotype.hxx>
	#include <rtl/ustring.hxx>
	#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	using namespace ::com::sun::star::uno;
	using namespace ::rtl;
	
	namespace theBiasPlanet {
		namespace unoUtilities {
			namespace unoDataHandling {
				class __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ UnoDatumConverter {
					public:
						static bool convertToNonUnoDatum (sal_Bool const & a_unoDatum);
						static unsigned char convertToNonUnoDatum (sal_Int8 const & a_unoDatum);
						static short convertToNonUnoDatum (sal_Int16 const & a_unoDatum);
						static long convertToNonUnoDatum (sal_Int32 const & a_unoDatum);
						static long long convertToNonUnoDatum (sal_Int64 const & a_unoDatum);
						static float convertToNonUnoDatum (float const & a_unoDatum);
						static double convertToNonUnoDatum (double const & a_unoDatum);
						static char convertToNonUnoDatum (sal_Unicode const & a_unoDatum);
						static string convertToNonUnoDatum (OUString const & a_unoDatum);
						static string convertToNonUnoDatum (Type const & a_unoDatum);
						static string convertToNonUnoDatum (Any const & a_unoDatum);
						static bool convertToBool (Any const & a_unoDatum);
						static unsigned char convertToUnsignedChar (Any const & a_unoDatum);
						static short convertToShort (Any const & a_unoDatum);
						static long convertToLong (Any const & a_unoDatum);
						static long long convertToLongLong (Any const & a_unoDatum);
						static float convertToFloat (Any const & a_unoDatum);
						static double convertToDouble (Any const & a_unoDatum);
						static char convertToChar (Any const & a_unoDatum);
						static string convertToString (Any const & a_unoDatum);
						static string convertToTypeString (Any const & a_unoDatum);
						static list <bool> convertToBoolList (Any const & a_unoDatum);
						static list <unsigned char> convertToUnsignedCharList (Any const & a_unoDatum);
						static list <short> convertToShortList (Any const & a_unoDatum);
						static list <long> convertToLongList (Any const & a_unoDatum);
						static list <long long> convertToLongLongList (Any const & a_unoDatum);
						static list <float> convertToFloatList (Any const & a_unoDatum);
						static list <double> convertToDoubleList (Any const & a_unoDatum);
						static list <char> convertToCharList (Any const & a_unoDatum);
						static list <string> convertToStringList (Any const & a_unoDatum);
						static list <string> convertToTypeStringList (Any const & a_unoDatum);
						template <typename T, typename U> static list <U> convertToNonUnoDatum (Sequence <T> const & a_unoDatum);
						template <typename T> static T convertToNonUnoDatum (T const & a_unoDatum);
						static sal_Bool convertToUnoDatum (bool const & a_nonUnoDatum);
						static sal_Int8 convertToUnoDatum (unsigned char const & a_nonUnoDatum);
						static sal_Int16 convertToUnoDatum (short const & a_nonUnoDatum);
						static sal_Int32 convertToUnoDatum (long const & a_nonUnoDatum);
						static sal_Int64  convertToUnoDatum (long long const & a_nonUnoDatum);
						static float convertToUnoDatum (float const & a_nonUnoDatum);
						static double convertToUnoDatum (double const & a_nonUnoDatum);
						static sal_Unicode convertToUnoDatum (char const & a_nonUnoDatum);
						static OUString convertToUnoDatum (string  const & a_nonUnoDatum);
						template <typename T, typename U> static Sequence <U> convertToUnoDatum (list <T> const & a_nonUnoDatum);
						template <typename T, typename U> static Sequence <U> convertToUnoDatum (T const * a_nonUnoDatum, int const & a_arrayLength);
						template <typename T> static T convertToUnoDatum (T const & a_nonUnoDatum);
						template <typename T> static Any convertToUnoAnyDatum (T const & a_nonUnoDatum);
						template <typename T, typename U> static Any convertToUnoAnyDatum (T const * a_array, int const & a_arrayLength);
						template <typename T> static Any convertToUnoAnyDatum (optional <T> const & a_nonUnoDatum);
				};
			}
		}
	}
#endif

