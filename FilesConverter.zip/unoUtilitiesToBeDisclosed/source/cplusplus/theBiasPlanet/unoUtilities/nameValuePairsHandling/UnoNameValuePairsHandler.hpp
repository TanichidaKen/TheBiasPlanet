#ifndef __theBiasPlanet_unoUtilities_nameValuePairsHandling_UnoNameValuePairsHandler_hpp__
	#define __theBiasPlanet_unoUtilities_nameValuePairsHandling_UnoNameValuePairsHandler_hpp__
	
	#include <list>
	#include <string>
	#include <com/sun/star/beans/NamedValue.hpp>
	#include <com/sun/star/uno/Any.h>
	#include <com/sun/star/uno/Sequence.hxx>
	#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	using namespace ::com::sun::star::beans;
	using namespace ::com::sun::star::uno;
	
	namespace theBiasPlanet {
		namespace unoUtilities {
			namespace nameValuePairsHandling {
				class __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ UnoNameValuePairsHandler {
					public:
						static Sequence <NamedValue> buildNameValuePairsSequence (list <string> const & a_names, list <Any> const & a_values);
				};
			}
		}
	}
#endif

