#include "theBiasPlanet/unoUtilities/nameValuePairsHandling/UnoNameValuePairsHandler.hpp"
#include "theBiasPlanet/coreUtilities/constantsGroups/GeneralConstantsConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/nameValuePair/UnoNameValuePair.hpp"
#include "theBiasPlanet/unoUtilities/stringsHandling/UnoExtendedStringHandler.hpp"

using namespace ::theBiasPlanet::coreUtilities::constantsGroups;
using namespace ::theBiasPlanet::unoUtilities::nameValuePair;
using namespace ::theBiasPlanet::unoUtilities::stringsHandling;

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace nameValuePairsHandling {
			Sequence <NamedValue> UnoNameValuePairsHandler::buildNameValuePairsSequence (list <string> const & a_names, list <Any> const & a_values) {
				list <string> l_names;
				list <Any> l_values;
				list <Any>::const_iterator l_valuesIterator = a_values.begin ();
				Any l_value;
				for (string l_name: a_names) {
					l_value = *l_valuesIterator;
					if (l_value.hasValue ()) {
						l_names.push_back (l_name);
						l_values.push_back (l_value);
					}
				}
				Sequence <NamedValue> l_nameValuePairsSequence (l_names.size ());
				l_valuesIterator = l_values.begin ();
				int l_nameValuePairIndex = GeneralConstantsConstantsGroup::c_iterationStartingNumber;
				for (string l_name: l_names) {
					l_nameValuePairsSequence [l_nameValuePairIndex] = UnoNameValuePair (l_name, *l_valuesIterator);
					l_valuesIterator ++;
					l_nameValuePairIndex ++;
				}
				return l_nameValuePairsSequence;
			}
		}
	}
}

