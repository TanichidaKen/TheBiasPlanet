#include "theBiasPlanet/unoUtilities/constantsGroups/UnoMessagesConstantsGroup.hpp"

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			string const UnoMessagesConstantsGroup::c_remoteInstanceNotProvided = "The server didn't provide the remote instance.";
			string const UnoMessagesConstantsGroup::c_cellNotString = "The cell isn't a string value cell.";
			string const UnoMessagesConstantsGroup::c_unoDocumentNotSpecified = "The UNO document isn't specified.";
			string const UnoMessagesConstantsGroup::c_isNotSpreadSheetsDocument = "The specified UNO component is not a spread sheets document.";
			string const UnoMessagesConstantsGroup::c_isNotTextDocument = "The specified UNO component is not a text document.";
			string const UnoMessagesConstantsGroup::c_spreadSheetsDocumentNotSpecified = "The spread sheets document isn't specified.";
			string const UnoMessagesConstantsGroup::c_spreadSheetNotSpecified = "The spread sheet isn't specified.";
			string const UnoMessagesConstantsGroup::c_objectsContextNotCreated = "Couldn't create the component context.";
			string const UnoMessagesConstantsGroup::c_objectsContextNotSpecified = "The component context isn't specified.";
			string const UnoMessagesConstantsGroup::c_noCurrentSpreadSheetCell = "there is no current spread sheet cell.";
		}
	}
}

