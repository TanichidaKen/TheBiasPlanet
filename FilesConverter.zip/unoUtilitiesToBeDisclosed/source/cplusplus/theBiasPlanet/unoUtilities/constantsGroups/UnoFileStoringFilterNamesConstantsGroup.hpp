#ifndef __theBiasPlanet_unoUtilities_constantsGroups_UnoFileStoringFilterNamesConstantsGroup_hpp__
	#define __theBiasPlanet_unoUtilities_constantsGroups_UnoFileStoringFilterNamesConstantsGroup_hpp__
	
	#include <string>
	#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	
	namespace theBiasPlanet {
		namespace unoUtilities {
			namespace constantsGroups {
				class __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ UnoFileStoringFilterNamesConstantsGroup {
					public:
						static string const c_openDocumentWordProcessingFilterName;
						static string const c_openDocumentSpreadsheetsFilterName;
						static string const c_openDocumentPresentationsFilterName;
						static string const c_microsoftWord97FileFilterName;
						static string const c_microsoftWord2007XmlFilterName;
						static string const c_microsoftExcel97FilterName;
						static string const c_microsoftExcel2007XmlFilterName;
						static string const c_microsoftPowerPoint97FilterName;
						static string const c_microsoftPowerPoint2007XmlFilterName;
						static string const c_csvFileFilterName;
				};
			}
		}
	}
#endif


