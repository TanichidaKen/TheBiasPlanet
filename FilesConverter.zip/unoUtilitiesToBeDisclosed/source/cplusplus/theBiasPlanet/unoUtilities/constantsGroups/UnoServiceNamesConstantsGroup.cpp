#include "theBiasPlanet/unoUtilities/constantsGroups/UnoServiceNamesConstantsGroup.hpp"

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			string const UnoServiceNamesConstantsGroup::c_com_sun_star_frame_Desktop = "com.sun.star.frame.Desktop";
			string const UnoServiceNamesConstantsGroup::c_com_sun_star_frame_DispatchHelper = "com.sun.star.frame.DispatchHelper";
			string const UnoServiceNamesConstantsGroup::c_com_sun_star_xml_crypto_SecurityEnvironment = "com.sun.star.xml.crypto.SecurityEnvironment";
			string const UnoServiceNamesConstantsGroup::c_com_sun_star_bridge_BridgeFactory = "com.sun.star.bridge.BridgeFactory";
			string const UnoServiceNamesConstantsGroup::c_com_sun_star_connection_Connector = "com.sun.star.connection.Connector";
			string const UnoServiceNamesConstantsGroup::c_com_sun_star_connection_Acceptor = "com.sun.star.connection.Acceptor";
			string const UnoServiceNamesConstantsGroup::c_com_sun_star_util_URLTransformer = "com.sun.star.util.URLTransformer";
		}
	}
}

