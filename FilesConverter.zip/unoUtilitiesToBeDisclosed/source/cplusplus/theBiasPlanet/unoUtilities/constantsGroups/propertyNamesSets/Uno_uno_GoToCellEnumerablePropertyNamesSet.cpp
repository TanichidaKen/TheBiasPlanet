#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/Uno_uno_GoToCellEnumerablePropertyNamesSet.hpp"

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			namespace propertyNamesSets {
				Uno_uno_GoToCellEnumerablePropertyNamesSet::Uno_uno_GoToCellEnumerablePropertyNamesSet () : BaseEnumerableConstantsGroup <string> ( { {"c_destinationPoint_string", c_destinationPoint_string}})  {
				}
			}
		}
	}
}

