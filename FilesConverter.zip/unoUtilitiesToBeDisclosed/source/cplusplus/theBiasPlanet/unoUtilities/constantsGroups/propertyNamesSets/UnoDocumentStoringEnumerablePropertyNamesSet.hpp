#ifndef __theBiasPlanet_unoUtilities_constantsGroups_propertyNamesSets_UnoDocumentStoringEnumerablePropertyNamesSet_hpp__
	#define __theBiasPlanet_unoUtilities_constantsGroups_propertyNamesSets_UnoDocumentStoringEnumerablePropertyNamesSet_hpp__
	
	#include "theBiasPlanet/coreUtilities/constantsGroups/BaseEnumerableConstantsGroup.hpp"
	#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/UnoPropertyNamesSet.hpp"
	#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::theBiasPlanet::coreUtilities::constantsGroups;
	
	namespace theBiasPlanet {
		namespace unoUtilities {
			namespace constantsGroups {
				namespace propertyNamesSets {
					class __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ UnoDocumentStoringEnumerablePropertyNamesSet : public BaseEnumerableConstantsGroup <string>, public UnoPropertyNamesSet {
						private:
							UnoDocumentStoringEnumerablePropertyNamesSet ();
						public:
							static string const c_filterName_string;
							static string const c_filterData_any; // a sequence of parameter name-value sets
							static string const c_filterData_string; // Some filters take this property while some other filters take the above property.
							static string const c_isTemplate_boolean;
							static string const c_authorName_string;
							static string const c_title_string;
							static string const c_encryptionData_NamedValuesSequence;
							static string const c_password_string;
							static string const c_charactersSet_string;
							static string const c_version_short;
							static string const c_versionDescription_string;
							static string const c_overwrites_boolen;
							static string const c_documentTypeSpecificData_any;
							static string const c_editingPasswordInformation_any;
							static UnoDocumentStoringEnumerablePropertyNamesSet const c_instance;
					};
				}
			}
		}
	}
#endif

