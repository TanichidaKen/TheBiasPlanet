#ifndef __theBiasPlanet_unoUtilities_constantsGroups_propertyNamesSets_Uno_uno_GoToCellEnumerablePropertyNamesSet_hpp__
	#define __theBiasPlanet_unoUtilities_constantsGroups_propertyNamesSets_Uno_uno_GoToCellEnumerablePropertyNamesSet_hpp__
	
	#include "theBiasPlanet/coreUtilities/constantsGroups/BaseEnumerableConstantsGroup.hpp"
	#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/UnoPropertyNamesSet.hpp"
	#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::theBiasPlanet::coreUtilities::constantsGroups;
	
	namespace theBiasPlanet {
		namespace unoUtilities {
			namespace constantsGroups {
				namespace propertyNamesSets {
					class __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ Uno_uno_GoToCellEnumerablePropertyNamesSet : public BaseEnumerableConstantsGroup <string>, public UnoPropertyNamesSet {
						private:
							Uno_uno_GoToCellEnumerablePropertyNamesSet ();
						public:
							static string const c_destinationPoint_string;
							static Uno_uno_GoToCellEnumerablePropertyNamesSet const c_instance;
					};
				}
			}
		}
	}
#endif

