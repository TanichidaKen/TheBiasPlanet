#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/UnoObjectsContextPropertyNamesConstantsGroup.hpp"

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			namespace propertyNamesSets {
				string const UnoObjectsContextPropertyNamesConstantsGroup::c_identification = "identification";
			}
		}
	}
}

