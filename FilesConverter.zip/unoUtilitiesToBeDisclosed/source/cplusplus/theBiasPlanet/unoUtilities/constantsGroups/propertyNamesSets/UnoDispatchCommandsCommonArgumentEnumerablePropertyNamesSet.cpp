#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/UnoDispatchCommandsCommonArgumentEnumerablePropertyNamesSet.hpp"

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			namespace propertyNamesSets {
				UnoDispatchCommandsCommonArgumentEnumerablePropertyNamesSet::UnoDispatchCommandsCommonArgumentEnumerablePropertyNamesSet () : BaseEnumerableConstantsGroup <string> ({ {"c_synchronousMode_boolean", c_synchronousMode_boolean}})  {
				}
			}
		}
	}
}

