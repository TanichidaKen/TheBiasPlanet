#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet.hpp"

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			namespace propertyNamesSets {
				Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet::Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet () : BaseEnumerableConstantsGroup <string> ( { {"c_styleName_string", c_styleName_string}, {"c_styleFamilyKey_short", c_styleFamilyKey_short}})  {
				}
			}
		}
	}
}

