#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/UnoDocumentStoringEnumerablePropertyNamesSet.hpp"

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			namespace propertyNamesSets {
				UnoDocumentStoringEnumerablePropertyNamesSet::UnoDocumentStoringEnumerablePropertyNamesSet () : BaseEnumerableConstantsGroup <string> ( { {"c_filterName_string", c_filterName_string}, {"c_filterData_any", c_filterData_any}, {"c_filterData_string", c_filterData_string}, {"c_isTemplate_boolean", c_isTemplate_boolean}, {"c_authorName_string", c_authorName_string}, {"c_title_string", c_title_string}, {"c_encryptionData_NamedValuesSequence", c_encryptionData_NamedValuesSequence}, {"c_password_string", c_password_string}, {"c_charactersSet_string", c_charactersSet_string}, {"c_version_short", c_version_short}, {"c_versionDescription_string", c_versionDescription_string}, {"c_overwrites_boolen", c_overwrites_boolen}, {"c_documentTypeSpecificData_any", c_documentTypeSpecificData_any}, {"c_editingPasswordInformation_any", c_editingPasswordInformation_any}}) {
				}
			}
		}
	}
}

