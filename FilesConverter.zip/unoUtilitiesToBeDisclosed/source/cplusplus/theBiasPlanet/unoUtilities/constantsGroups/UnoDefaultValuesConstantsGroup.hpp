#ifndef __theBiasPlanet_unoUtilities_constantsGroups_UnoDefaultValuesConstantsGroup_hpp__
	#define __theBiasPlanet_unoUtilities_constantsGroups_UnoDefaultValuesConstantsGroup_hpp__
	
	#include <string>
	#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	
	namespace theBiasPlanet {
		namespace unoUtilities {
			namespace constantsGroups {
				class __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ UnoDefaultValuesConstantsGroup {
					public:
						static string const c_customDefaultStyleName;
						static string const c_initiallyOfferedUnoObjectName;
				};
			}
		}
	}
#endif

