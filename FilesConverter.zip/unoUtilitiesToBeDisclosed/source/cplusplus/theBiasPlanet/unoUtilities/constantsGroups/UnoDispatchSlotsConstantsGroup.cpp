#include "theBiasPlanet/unoUtilities/constantsGroups/UnoDispatchSlotsConstantsGroup.hpp"

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			UnoDispatchSlotsConstantsGroup::BaseDispatchSlot::BaseDispatchSlot (string a_url, optional <BaseEnumerableConstantsGroup <string>> a_argumentPropertyNamesSet) : c_url (a_url), c_argumentPropertyNamesSet (a_argumentPropertyNamesSet) {
			}
		}
	}
}

