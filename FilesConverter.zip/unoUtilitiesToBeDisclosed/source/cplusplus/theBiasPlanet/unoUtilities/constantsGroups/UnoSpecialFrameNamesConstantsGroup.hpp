#ifndef __theBiasPlanet_unoUtilities_constantsGroups_UnoSpecialFrameNamesConstantsGroup_hpp__
	#define __theBiasPlanet_unoUtilities_constantsGroups_UnoSpecialFrameNamesConstantsGroup_hpp__
	
	#include <string>
	#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	
	namespace theBiasPlanet {
		namespace unoUtilities {
			namespace constantsGroups {
				class __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ UnoSpecialFrameNamesConstantsGroup {
					public:
						static string const c_new;
						static string const c_default;
						static string const c_self;
						static string const c_parent;
						static string const c_top;
						static string const c_specialSub;
				};
			}
		}
	}
#endif

