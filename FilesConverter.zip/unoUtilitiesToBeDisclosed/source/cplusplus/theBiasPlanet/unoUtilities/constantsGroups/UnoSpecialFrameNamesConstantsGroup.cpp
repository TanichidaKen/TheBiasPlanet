#include "theBiasPlanet/unoUtilities/constantsGroups/UnoSpecialFrameNamesConstantsGroup.hpp"

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
					string const UnoSpecialFrameNamesConstantsGroup::c_new = "_blank";
					string const UnoSpecialFrameNamesConstantsGroup::c_default = "_default";
					string const UnoSpecialFrameNamesConstantsGroup::c_self = "_self";
					string const UnoSpecialFrameNamesConstantsGroup::c_parent = "_parent";
					string const UnoSpecialFrameNamesConstantsGroup::c_top = "_top";
					string const UnoSpecialFrameNamesConstantsGroup::c_specialSub = "_beamer";
		}
	}
}

