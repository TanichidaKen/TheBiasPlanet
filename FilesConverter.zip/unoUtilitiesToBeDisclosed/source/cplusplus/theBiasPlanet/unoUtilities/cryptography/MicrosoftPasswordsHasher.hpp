#ifndef __theBiasPlanet_unoUtilities_cryptography_MicrosoftPasswordsHasher_hpp__
	#define __theBiasPlanet_unoUtilities_cryptography_MicrosoftPasswordsHasher_hpp__
	
	#include <string>
	#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	
	namespace theBiasPlanet {
		namespace unoUtilities {
			namespace cryptography {
				class __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ MicrosoftPasswordsHasher {
					private:
						static int const c_numberOfInitializationCodes;
						static unsigned short const c_initializationCodes [];
						static int const c_numberOfEncryptionMatrixColumns = 7;
						static unsigned short const c_encryptionMatrix [] [c_numberOfEncryptionMatrixColumns];
					public:
						static long hashIn32bits (string const & a_originalDatum);
						static short hashIn16bits (string const & a_originalDatum);
				};
			}
		}
	}
#endif


