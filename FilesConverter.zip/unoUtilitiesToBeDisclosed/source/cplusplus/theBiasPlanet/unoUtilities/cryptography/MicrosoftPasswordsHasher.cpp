#include "theBiasPlanet/unoUtilities/cryptography/MicrosoftPasswordsHasher.hpp"
#include <limits>
#include "theBiasPlanet/coreUtilities/constantsGroups/GeneralConstantsConstantsGroup.hpp"
#include "theBiasPlanet/coreUtilities/stringsHandling/StringHandler.hpp"

using namespace ::theBiasPlanet::coreUtilities::constantsGroups;
using namespace ::theBiasPlanet::coreUtilities::stringsHandling;

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace cryptography {
			long MicrosoftPasswordsHasher::hashIn32bits (string const & a_originalDatum) {
				unsigned long l_hash = 0;
				u16string l_originalDatumInUtf16 = StringHandler::getUtf16String (a_originalDatum);
				int l_originalDatumLength = l_originalDatumInUtf16.length ();
				if (l_originalDatumLength > 0) {
					if (l_originalDatumLength > c_numberOfInitializationCodes) {
		  		 		l_originalDatumLength = c_numberOfInitializationCodes;
					}
					unsigned short l_highHash = c_initializationCodes [l_originalDatumLength - 1];
					unsigned short l_lowHash = 0;
					unsigned short l_character = 0x0000;
					unsigned char l_byte = 0x00;
					unsigned char l_highByte = 0x00;
					unsigned char l_lowByte = 0x00;
					for (int l_characterIndex = GeneralConstantsConstantsGroup::c_iterationStartingNumber; l_characterIndex < l_originalDatumLength; l_characterIndex ++) {
						l_character = l_originalDatumInUtf16 [l_characterIndex];
						l_highByte = (unsigned char) (l_character >> 8);
						l_lowByte = (unsigned char) (l_character & 0xFF);
						l_byte = l_lowByte != 0x00 ? l_lowByte : l_highByte;
						for (int l_matrixcolumnIndex = GeneralConstantsConstantsGroup::c_iterationStartingNumber; l_matrixcolumnIndex < c_numberOfEncryptionMatrixColumns; l_matrixcolumnIndex ++) {
							if ((l_byte & (1 << l_matrixcolumnIndex)) != 0) {
								l_highHash = (unsigned short) (l_highHash ^ c_encryptionMatrix [c_numberOfInitializationCodes - l_originalDatumLength + l_characterIndex] [l_matrixcolumnIndex]);
							}
						}
						l_character = l_originalDatumInUtf16 [l_originalDatumLength -1 - l_characterIndex];
						l_highByte = (unsigned char) (l_character >> 8);
						l_lowByte = (unsigned char) (l_character & 0xFF);
						l_byte = l_lowByte != 0x00 ? l_lowByte : l_highByte;
						l_lowHash = ( ( (l_lowHash >> 14) & 0x0001 ) | ( (l_lowHash << 1) & 0x7FFF)) ^ l_byte;
					}
					l_lowHash =  ( ( (l_lowHash >> 14) & 0x0001) | ( (l_lowHash << 1) & 0x7FFF)) ^ l_originalDatumLength ^ 0xCE4B;
					l_hash = (l_highHash << 16) | l_lowHash;
				}
				return (long) l_hash;
			}
			
			short MicrosoftPasswordsHasher::hashIn16bits (string const & a_originalDatum) {
				unsigned short l_hash = 0;
				int l_originalDatumLength = a_originalDatum.length ();
				if (l_originalDatumLength <= numeric_limits <short>::max ()) {
					for (int l_byteIndex = l_originalDatumLength - 1; l_byteIndex >= GeneralConstantsConstantsGroup::c_iterationStartingNumber; l_byteIndex --) {
						l_hash = ( (l_hash >> 14) & 0x01) | ( (l_hash << 1) & 0x7FFF);
						l_hash ^= a_originalDatum [l_byteIndex];
					}
					l_hash = ( (l_hash >> 14) & 0x01) | ( (l_hash << 1) & 0x7FFF);
					l_hash ^= (0x8000 | ('N' << 8) | 'K');
					l_hash ^= l_originalDatumLength;
				}
				return (short) l_hash;
			}
		}
	}
}

