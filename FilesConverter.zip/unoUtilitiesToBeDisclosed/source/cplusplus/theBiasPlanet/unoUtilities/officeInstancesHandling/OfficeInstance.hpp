#ifndef __theBiasPlanet_unoUtilities_officeInstancesHandling_OfficeInstance_hpp__
	#define __theBiasPlanet_unoUtilities_officeInstancesHandling_OfficeInstance_hpp__
	
	#include <com/sun/star/document/DocumentEvent.hpp>
	#include <com/sun/star/document/XDocumentEventListener.hpp>
	#include <com/sun/star/frame/XController.hpp>
	#include <com/sun/star/frame/XDesktop2.hpp>
	#include <com/sun/star/frame/XFrame.hpp>
	#include <com/sun/star/frame/XModel.hpp>
	#include <com/sun/star/frame/XGlobalEventBroadcaster.hpp>
	#include <com/sun/star/frame/XTerminateListener.hpp>
	#include <com/sun/star/lang/EventObject.hpp>
	#include <com/sun/star/uno/Reference.hxx>
	#include <cppuhelper/compbase2.hxx>
	#include <osl/mutex.hxx>
	#include "theBiasPlanet/unoUtilities/connectionsHandling/UnoObjectsContext.hpp"
	#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	using namespace ::com::sun::star::document;
	using namespace ::com::sun::star::frame;
	using namespace ::com::sun::star::lang;
	using namespace ::com::sun::star::uno;
	using namespace ::cppu;
	using namespace ::osl;
	using namespace ::theBiasPlanet::unoUtilities::connectionsHandling;
	
	namespace theBiasPlanet {
		namespace unoUtilities {
			namespace officeInstancesHandling {
				class __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ OfficeInstance : public WeakComponentImplHelper2 <XTerminateListener, XDocumentEventListener> {
					protected:
						Mutex i_mutex;
						Reference <UnoObjectsContext> i_unoObjectsContext;
						Reference <XDesktop2> i_unoDesktopInXDesktop2;
						Reference <XGlobalEventBroadcaster> i_unoGlobalEventsBroadcasterInXGlobalEventBroadcaster;
					public:
						OfficeInstance (Reference <UnoObjectsContext> a_unoObjectsContext);
						~OfficeInstance ();
						virtual void SAL_CALL queryTermination (::com::sun::star::lang::EventObject const & a_event) override;
						virtual void SAL_CALL notifyTermination (::com::sun::star::lang::EventObject const & a_event) override;
						virtual void SAL_CALL disposing (::com::sun::star::lang::EventObject const & a_event) override;
						virtual void SAL_CALL documentEventOccured (DocumentEvent const & a_event) override final;
						virtual bool shutDown ();
				};
			}
		}
	}
#endif

