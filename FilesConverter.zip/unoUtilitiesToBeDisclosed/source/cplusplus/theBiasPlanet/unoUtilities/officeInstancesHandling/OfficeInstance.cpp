#include "theBiasPlanet/unoUtilities/officeInstancesHandling/OfficeInstance.hpp"
#include <iostream>
#include <optional>
#include <thread>
#include <com/sun/star/container/NoSuchElementException.hpp>
#include <com/sun/star/container/XEnumeration.hpp>
#include <com/sun/star/frame/TerminationVetoException.hpp>
#include <com/sun/star/frame/theGlobalEventBroadcaster.hpp>
#include <com/sun/star/lang/WrappedTargetException.hpp>
#include <com/sun/star/lang/XComponent.hpp>
#include <com/sun/star/util/CloseVetoException.hpp>
#include <com/sun/star/util/XCloseable.hpp>
#include "theBiasPlanet/coreUtilities/messaging/Publisher.hpp"
#include "theBiasPlanet/coreUtilities/stringsHandling/StringHandler.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/UnoDocumentEventNamesConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/UnoServiceNamesConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/stringsHandling/UnoExtendedStringHandler.hpp"

using namespace ::com::sun::star::frame;
using namespace ::com::sun::star::lang;
using namespace ::com::sun::star::uno;
using namespace ::com::sun::star::util;
using namespace ::theBiasPlanet::coreUtilities::messaging;
using namespace ::theBiasPlanet::coreUtilities::stringsHandling;
using namespace ::theBiasPlanet::unoUtilities::constantsGroups;
using namespace ::theBiasPlanet::unoUtilities::stringsHandling;

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace officeInstancesHandling {
			OfficeInstance::OfficeInstance (Reference <UnoObjectsContext> a_unoObjectsContext) : WeakComponentImplHelper2 (i_mutex), i_unoObjectsContext (a_unoObjectsContext), i_unoDesktopInXDesktop2 (i_unoObjectsContext->getServiceInstance <XDesktop2> (UnoServiceNamesConstantsGroup::c_com_sun_star_frame_Desktop, nullopt)), i_unoGlobalEventsBroadcasterInXGlobalEventBroadcaster (theGlobalEventBroadcaster::get (i_unoObjectsContext)) {
				i_unoDesktopInXDesktop2->addTerminateListener (Reference <XTerminateListener> (this)); 
				i_unoGlobalEventsBroadcasterInXGlobalEventBroadcaster->addDocumentEventListener (Reference <XDocumentEventListener> (this)); 
			}
			
			OfficeInstance::~OfficeInstance  () {
			}
			
			void OfficeInstance::queryTermination (::com::sun::star::lang::EventObject const & a_event) {
				Publisher::logNormalInformation (string ("### The termination of the office instance is queried."));
				throw TerminationVetoException ();
			}
			
			void OfficeInstance::notifyTermination (::com::sun::star::lang::EventObject const &  a_event) {
				Publisher::logNormalInformation (string ("### The termination of the office instance is notified."));
			}
			
			void OfficeInstance::disposing (::com::sun::star::lang::EventObject const & a_event) {
			}
			
			void OfficeInstance::documentEventOccured (DocumentEvent const & a_event) {
				if (UnoExtendedStringHandler::getString (a_event.EventName) == UnoDocumentEventNamesConstantsGroup::c_documentDatumLoaded) {
				}
				Publisher::logNormalInformation (StringHandler::format (string ("### A document opened event has occurred: %s."), UnoExtendedStringHandler::getString (a_event.EventName)));
			}
			
			bool OfficeInstance::shutDown () {
				i_unoGlobalEventsBroadcasterInXGlobalEventBroadcaster->removeDocumentEventListener (Reference <XDocumentEventListener> (this)); 
				i_unoDesktopInXDesktop2->removeTerminateListener (Reference <XTerminateListener> (this)); 
				while (!(i_unoDesktopInXDesktop2->terminate ())) {
					Publisher::logNormalInformation (string ("### The termination of the office instance has been vetoed."));
				}
				Publisher::logNormalInformation (string ("### The termination of the office instance has been accomplished."));
				return true;
			}
		}
	}
}

