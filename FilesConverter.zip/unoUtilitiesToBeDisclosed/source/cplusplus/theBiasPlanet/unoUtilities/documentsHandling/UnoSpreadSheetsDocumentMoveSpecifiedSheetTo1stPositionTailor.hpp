#ifndef __theBiasPlanet_unoUtilities_documentsHandling_UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor_hpp__
	#define __theBiasPlanet_unoUtilities_documentsHandling_UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor_hpp__
	
	#include "theBiasPlanet/unoUtilities/connectionsHandling/UnoObjectsContext.hpp"
	#include "theBiasPlanet/unoUtilities/documentsHandling/UnoDocumentTailor.hpp"
	#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::theBiasPlanet::unoUtilities::connectionsHandling;
	
	namespace theBiasPlanet {
		namespace unoUtilities {
			namespace documentsHandling {
				class __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor : public UnoDocumentTailor {
					private:
						int i_targetSpreadSheetIndex;
					public:
						UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor (Reference <UnoObjectsContext> a_unoObjectsContext, int a_targetSpreadSheetIndex);
						UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor (UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor const & a_copiedObject);
						virtual ~UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor ();
						virtual bool tailor (Reference <XComponent> a_unoDocumentInXComponent) const override;
				};
			}
		}
	}
#endif

