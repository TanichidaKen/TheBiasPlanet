#include "theBiasPlanet/unoUtilities/documentsHandling/UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor.hpp"
#include <com/sun/star/container/XNamed.hpp>
#include <com/sun/star/sheet/XSpreadsheet.hpp>
#include <com/sun/star/sheet/XSpreadsheetDocument.hpp>
#include <com/sun/star/sheet/XSpreadsheets.hpp>
#include "theBiasPlanet/coreUtilities/constantsGroups/GeneralConstantsConstantsGroup.hpp"
#include "theBiasPlanet/coreUtilities/messaging/Publisher.hpp"
#include "theBiasPlanet/unoUtilities/stringsHandling/UnoExtendedStringHandler.hpp"

using namespace ::com::sun::star::container;
using namespace ::com::sun::star::sheet;
using namespace ::theBiasPlanet::coreUtilities::constantsGroups;
using namespace ::theBiasPlanet::coreUtilities::messaging;
using namespace ::theBiasPlanet::unoUtilities::stringsHandling;

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace documentsHandling {
			UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor::UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor (Reference <UnoObjectsContext> a_unoObjectsContext, int a_targetSpreadSheetIndex) : UnoDocumentTailor (a_unoObjectsContext), i_targetSpreadSheetIndex (a_targetSpreadSheetIndex) {
			}
			
			UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor::UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor (UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor const & a_copiedObject) : UnoDocumentTailor (a_copiedObject) {
			}
			
			UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor::~UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor () {
			}
			
			bool UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor::tailor (Reference <XComponent> a_unoDocumentInXComponent) const {
				Reference <XSpreadsheetDocument> l_spreadSheetsDocumentInXSpreadsheetDocument (a_unoDocumentInXComponent, UNO_QUERY);
				if (!(l_spreadSheetsDocumentInXSpreadsheetDocument.is ())) {
					Publisher::logErrorInformation (string ("The document is not any spread sheet."));
					return false;
				}
				else {
					Reference <XIndexAccess> l_spreadSheetsInXIndexAccess (l_spreadSheetsDocumentInXSpreadsheetDocument->getSheets (), UNO_QUERY);
					try {
						Reference <XSpreadsheet> l_spreadSheetInXSpreadsheet (*((Reference <XSpreadsheet> *) ((l_spreadSheetsInXIndexAccess->getByIndex (i_targetSpreadSheetIndex)).getValue ())));
						Reference <XNamed> l_spreadSheetInXNamed (l_spreadSheetInXSpreadsheet, UNO_QUERY);
						(Reference <XSpreadsheets> (l_spreadSheetsInXIndexAccess, UNO_QUERY))->moveByName (l_spreadSheetInXNamed->getName (), (short) GeneralConstantsConstantsGroup::c_iterationStartingNumber);
						return true;
					}
					catch (Exception l_exception) {
						Publisher::logErrorInformation (UnoExtendedStringHandler::getString (l_exception.Message));
						return false;
					}
				}
			}
		}
	}
}

