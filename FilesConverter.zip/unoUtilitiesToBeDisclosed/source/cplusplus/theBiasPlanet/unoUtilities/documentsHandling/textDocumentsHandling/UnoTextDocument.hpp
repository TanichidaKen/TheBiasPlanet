#ifndef __theBiasPlanet_unoUtilities_documentsHandling_textDocumentsHandling_UnoTextDocument_hpp__
	#define __theBiasPlanet_unoUtilities_documentsHandling_textDocumentsHandling_UnoTextDocument_hpp__
	
	#include <com/sun/star/text/XText.hpp>
	#include <com/sun/star/text/XTextDocument.hpp>
	#include <com/sun/star/text/XTextViewCursorSupplier.hpp>
	#include "theBiasPlanet/unoUtilities/documentsHandling/UnoDocument.hpp"
	#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::com::sun::star::text;
	
	namespace theBiasPlanet {
		namespace unoUtilities {
			namespace documentsHandling {
				namespace textDocumentsHandling {
					class __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ UnoTextDocument : public UnoDocument {
						private:
							Reference <XTextDocument> i_textDocumentInXTextDocument;
							Reference <XTextViewCursorSupplier> i_controllerInXTextViewCursorSupplier;
							Reference <XTextViewCursor> i_viewCursorInXTextViewCursor;
							Reference <XText> i_textInXText;
						public:
							static Reference <UnoTextDocument> createTextDocument (Reference <UnoObjectsContext> a_objectsContext, bool a_hiddenly);
							static Reference <UnoTextDocument> openTextDocumentFile (Reference <UnoObjectsContext> a_objectsContext, string const & a_fileUrl, bool a_hiddenly);
							static Reference <UnoTextDocument> getCurrentTextDocument (Reference <UnoObjectsContext> a_objectsContext);
							UnoTextDocument (Reference <UnoObjectsContext> a_objectsContext, Reference <XComponent> a_textDocumentInXComponent);
							virtual Reference <XTextViewCursor> getViewCursor ();
							virtual bool insertText (string a_text);
					};
				}
			}
		}
	}
#endif

