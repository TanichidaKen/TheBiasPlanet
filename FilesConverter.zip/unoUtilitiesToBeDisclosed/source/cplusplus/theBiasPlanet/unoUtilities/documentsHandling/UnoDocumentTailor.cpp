#include "theBiasPlanet/unoUtilities/documentsHandling/UnoDocumentTailor.hpp"

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace documentsHandling {
			UnoDocumentTailor::UnoDocumentTailor (Reference <UnoObjectsContext> a_unoObjectsContext) : i_unoObjectsContext (a_unoObjectsContext) {
			}
			
			UnoDocumentTailor::~UnoDocumentTailor () {
			}
			
			bool UnoDocumentTailor::tailor (Reference <XComponent> a_unoDocumentInXComponent) const {
				return true;
			}
		}
	}
}

