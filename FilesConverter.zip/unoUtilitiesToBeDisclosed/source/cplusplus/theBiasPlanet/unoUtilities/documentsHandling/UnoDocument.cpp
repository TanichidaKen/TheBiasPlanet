#include "theBiasPlanet/unoUtilities/documentsHandling/UnoDocument.hpp"
#include <optional>
#include <com/sun/star/frame/FrameSearchFlag.hpp>
#include <com/sun/star/frame/XComponentLoader.hpp>
#include <com/sun/star/frame/XDesktop2.hpp>
#include <com/sun/star/frame/XNotifyingDispatch.hpp>
#include <com/sun/star/util/XCloseable.hpp>
#include "theBiasPlanet/coreUtilities/collectionsHandling/ArraysFactory.hpp"
#include "theBiasPlanet/coreUtilities/collectionsHandling/ListsFactory.hpp"
#include "theBiasPlanet/coreUtilities/constantsGroups/GeneralConstantsConstantsGroup.hpp"
#include "theBiasPlanet/coreUtilities/constantsGroups/RegularExpressionsConstantsGroup.hpp"
#include "theBiasPlanet/coreUtilities/locksHandling/Locker.hpp"
#include "theBiasPlanet/coreUtilities/messaging/Publisher.hpp"
#include "theBiasPlanet/unoUtilities/collectionsHandling/UnoSequenceHandler.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/UnoMessagesConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/UnoServiceNamesConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/UnoSpecialFrameNamesConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/UnoDispatchCommandsCommonArgumentEnumerablePropertyNamesSet.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/UnoDocumentOpeningEnumerablePropertyNamesSet.hpp"
#include "theBiasPlanet/unoUtilities/propertiesHandling/UnoPropertiesHandler.hpp"
#include "theBiasPlanet/unoUtilities/stringsHandling/UnoExtendedStringHandler.hpp"

using namespace ::com::sun::star::frame;
using namespace ::theBiasPlanet::coreUtilities::collectionsHandling;
using namespace ::theBiasPlanet::coreUtilities::locksHandling;
using namespace ::theBiasPlanet::coreUtilities::messaging;
using namespace ::theBiasPlanet::unoUtilities::collectionsHandling;
using namespace ::theBiasPlanet::unoUtilities::constantsGroups;
using namespace ::theBiasPlanet::unoUtilities::constantsGroups::propertyNamesSets;
using namespace ::theBiasPlanet::unoUtilities::propertiesHandling;
using namespace ::theBiasPlanet::unoUtilities::stringsHandling;

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace documentsHandling {
			/*
			Reference <XComponent> UnoDocument::createUnoDocumentOrOpenUnoDocumentFile (Reference <UnoObjectsContext> a_unoObjectsContext, string const & a_fileUrl, bool const & a_hiddenly) {
			}
			*/
			
			Reference <XComponent> UnoDocument::getCurrentUnoDocument (Reference <UnoObjectsContext> a_unoObjectsContext) {
				Reference <XDesktop2> l_desktopInXDesktop2 = a_unoObjectsContext->getServiceInstance <XDesktop2> (UnoServiceNamesConstantsGroup::c_com_sun_star_frame_Desktop, nullopt);
				return l_desktopInXDesktop2->getCurrentComponent ();
			}
			/*
			
			Reference <XComponent> UnoDocument::getUnoDocument (Reference <UnoObjectsContext> a_unoObjectsContext, string const & a_fileName) {
			}
			*/
			Reference <XComponent> UnoDocument::createUnoDocumentOrOpenUnoDocumentFile (Reference <UnoObjectsContext> a_unoObjectsContext, string const & a_fileUrl, optional <string> const & a_password, bool const & a_hiddenly) {
				Reference <XComponentLoader> l_desktopInXComponentLoader = a_unoObjectsContext->getServiceInstance <XComponentLoader> (UnoServiceNamesConstantsGroup::c_com_sun_star_frame_Desktop, nullopt);
				string l_convertedFileUrl (a_fileUrl);
				return l_desktopInXComponentLoader->loadComponentFromURL (UnoExtendedStringHandler::getOustring (StringHandler::replaceAll (&l_convertedFileUrl, RegularExpressionsConstantsGroup::c_windowsDirectoryDelimiterRegularExpression, string (1, GeneralConstantsConstantsGroup::c_linuxDirectoriesDelimiter))), UnoExtendedStringHandler::getOustring (UnoSpecialFrameNamesConstantsGroup::c_new), FrameSearchFlag::CREATE, UnoPropertiesHandler::buildPropertiesSequence (UnoDocumentOpeningEnumerablePropertyNamesSet::c_instance.getValues (), ListsFactory::createList <Any, Any, Any, Any, Any> (Any (false), Any (a_hiddenly), Any (false), Any (a_hiddenly), Any (UnoExtendedStringHandler::getOustring (a_password.has_value () ? *a_password : GeneralConstantsConstantsGroup::c_emptyString)))));
			}
			
			UnoDocument::UnoDocument (Reference <UnoObjectsContext> a_unoObjectsContext, Reference <XComponent> a_unoDocumentInXComponent) : WeakComponentImplHelper2 (i_mutex), i_unoObjectsContext (a_unoObjectsContext), i_unoDocumentInXModel (Reference <XModel> (a_unoDocumentInXComponent, UNO_QUERY)), i_unoDocumentInXStorable2 (Reference <XStorable2> (i_unoDocumentInXModel, UNO_QUERY)), i_controllerInXController (Reference <XController> (i_unoDocumentInXModel->getCurrentController (), UNO_QUERY)), i_dispatchResult (nullptr) {
				if (a_unoObjectsContext.get () == nullptr) {
					throw Exception (UnoExtendedStringHandler::getOustring (UnoMessagesConstantsGroup::c_unoObjectsContextNotSpecified), *this);
				}
				if (a_unoDocumentInXComponent.get () == nullptr) {
					throw Exception (UnoExtendedStringHandler::getOustring (UnoMessagesConstantsGroup::c_unoDocumentNotSpecified), *this);
				}
				i_frameInXFrame = i_controllerInXController->getFrame ();
				i_frameInXDispatchProvider = Reference <XDispatchProvider> (i_frameInXFrame, UNO_QUERY);
			}
			
			UnoDocument::~UnoDocument () {
				if (i_dispatchResult != nullptr) {
					delete i_dispatchResult;
					i_dispatchResult = nullptr;
				}
			}
			
			Reference <UnoObjectsContext> UnoDocument::getObjectsContext () {
				return i_unoObjectsContext;
			}
			
			void UnoDocument::close () {
				Reference <XCloseable> l_unoDocumentInXCloseable = Reference <XCloseable> (i_unoDocumentInXStorable2, UNO_QUERY);
				l_unoDocumentInXCloseable->close (false); 
			}
			
			/*
			Reference <XModel> UnoDocument::getUnoDocumentinXModel () {
			}
			
			Reference <XDispatchProvider> UnoDocument::getFrameInXDispatchProvider () {
			}
			
			void UnoDocument::store () {
			}
			
			void UnoDocument::storeAtUrl (string const & a_fileUrl) {
			}
			
			void UnoDocument::storeAtUrl (string const & a_fileUrl, string const & a_filterName, Any const & a_filterData) {
			}
			
			string UnoDocument::getLocationUrl () {
			}
			
			void UnoDocument::addDocumentEventsListener (Reference <XDocumentEventListener> a_eventListener) {
			}
			
			void UnoDocument::removeDocumentEventsListener (Reference <XDocumentEventListener> a_eventListener) {
			}
			
			void UnoDocument::addEventsListener (Reference <XEventListener> a_eventListener) {
			}
			
			void UnoDocument::removeEventsListener (Reference <XEventListener> a_eventListener) {
			}
			*/
			
			optional <UnoDispatchResult> UnoDocument::dispatch (UnoDispatchSlotsConstantsGroup::BaseDispatchSlot const & a_dispatchSlot, optional <list <Any>> const & a_argumentValues) {
				Sequence <PropertyValue> l_dispatchArgumentPropertiesSequence;
				if (a_dispatchSlot.c_argumentPropertyNamesSet.has_value () && a_argumentValues.has_value ()) {
					l_dispatchArgumentPropertiesSequence = UnoPropertiesHandler::buildPropertiesSequence (ListsFactory::createListExpandingItems <string> (UnoDispatchCommandsCommonArgumentEnumerablePropertyNamesSet::c_instance.getValues (), a_dispatchSlot.c_argumentPropertyNamesSet->getValues ()), ListsFactory::createListExpandingItems <Any> (Any (true), *a_argumentValues));
				}
				else {
					l_dispatchArgumentPropertiesSequence = UnoPropertiesHandler::buildPropertiesSequence (UnoDispatchCommandsCommonArgumentEnumerablePropertyNamesSet::c_instance.getValues (), ListsFactory::createList <Any> (Any (true)));
				}
				::com::sun::star::util::URL l_urlInURL = i_unoObjectsContext->createUrlInURL (a_dispatchSlot.c_url);
				Reference <XNotifyingDispatch> l_dispatcherInXNotifyingDispatch (i_frameInXDispatchProvider->queryDispatch (l_urlInURL, UnoExtendedStringHandler::getOustring (UnoSpecialFrameNamesConstantsGroup::c_self), (short) GeneralConstantsConstantsGroup::c_anyUnspecifiedInteger), UNO_QUERY);
				if (l_dispatcherInXNotifyingDispatch.is ()) {
					Locker l_locker (&i_standardMutex);
					if (i_dispatchResult != nullptr) {
						delete i_dispatchResult;
						i_dispatchResult = nullptr;
					}
					i_dispatchResult = new UnoDispatchResult ();
					l_dispatcherInXNotifyingDispatch->addStatusListener (this, l_urlInURL);
					l_dispatcherInXNotifyingDispatch->dispatchWithNotification (l_urlInURL, l_dispatchArgumentPropertiesSequence, this);
					l_dispatcherInXNotifyingDispatch->removeStatusListener (this, l_urlInURL);
					return optional <UnoDispatchResult> (*i_dispatchResult);
				}
				else {
					return optional <UnoDispatchResult> ();
				}
			}
			
			void UnoDocument::dispatchFinished (DispatchResultEvent const & a_dispatchResultEvent) {
				i_dispatchResult->setDispatchResult (a_dispatchResultEvent);
			}
			
			void UnoDocument::statusChanged (FeatureStateEvent const & a_featureStateEvent) {
				i_dispatchResult->addRelatedInformationPiece (a_featureStateEvent);
			}
			
			void UnoDocument::disposing (::com::sun::star::lang::EventObject const & a_source) {
			}
		}
	}
}

