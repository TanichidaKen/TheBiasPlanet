#include "theBiasPlanet/unoUtilities/filesConverting/FilesConverter.hpp"
#include <optional>
#include <com/sun/star/beans/XPropertySet.hpp>
#include <com/sun/star/container/XIndexAccess.hpp>
#include <com/sun/star/container/XNamed.hpp>
#include <com/sun/star/frame/XStorable2.hpp>
#include <com/sun/star/sheet/XSpreadsheetDocument.hpp>
#include <com/sun/star/sheet/XSpreadsheets2.hpp>
#include <com/sun/star/frame/XSynchronousDispatch.hpp>
#include <com/sun/star/uno/Exception.hpp>
#include <com/sun/star/util/XCloseable.hpp>
#include "theBiasPlanet/coreUtilities/collectionsHandling/ListsFactory.hpp"
#include "theBiasPlanet/coreUtilities/constantsGroups/GeneralConstantsConstantsGroup.hpp"
#include "theBiasPlanet/coreUtilities/messaging/Publisher.hpp"
#include "theBiasPlanet/coreUtilities/stringsHandling/StringHandler.hpp"
#include "theBiasPlanet/unoUtilities/collectionsHandling/UnoSequenceHandler.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/UnoFileStoringFilterNamesConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/UnoDocumentOpeningEnumerablePropertyNamesSet.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/UnoDocumentStoringEnumerablePropertyNamesSet.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/UnoSpreadSheetPropertyNamesSet.hpp"
#include "theBiasPlanet/unoUtilities/propertiesHandling/UnoPropertiesHandler.hpp"
#include "theBiasPlanet/unoUtilities/stringsHandling/UnoExtendedStringHandler.hpp"
#include "theBiasPlanet/unoUtilities/unoDataHandling/UnoDatumConverter.hpp"

using namespace ::com::sun::star::container;
using namespace ::com::sun::star::sheet;
using namespace ::theBiasPlanet::coreUtilities::collectionsHandling;
using namespace ::theBiasPlanet::coreUtilities::constantsGroups;
using namespace ::theBiasPlanet::coreUtilities::messaging;
using namespace ::theBiasPlanet::coreUtilities::stringsHandling;
using namespace ::theBiasPlanet::unoUtilities::collectionsHandling;
using namespace ::theBiasPlanet::unoUtilities::constantsGroups;
using namespace ::theBiasPlanet::unoUtilities::constantsGroups::propertyNamesSets;
using namespace ::theBiasPlanet::unoUtilities::propertiesHandling;
using namespace ::theBiasPlanet::unoUtilities::stringsHandling;
using namespace ::theBiasPlanet::unoUtilities::unoDataHandling;

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace filesConverting {
			FilesConverter::FilesConverter (Reference <UnoObjectsContext> a_remoteUnoObjectsContext) : i_remoteUnoObjectsContext (a_remoteUnoObjectsContext), i_fileOpeningUnoDispatcherInXSynchronousDispatch (i_remoteUnoObjectsContext->getFileOpeningUnoDispatcherInXSynchronousDispatch ()) {
			}
			
			FilesConverter::~FilesConverter () {
			}
			
			bool FilesConverter::convertFile (string const & a_convertedFileUrl, optional <string> const & a_convertedFilePassword, string const & a_targetFileUrl, Sequence <PropertyValue> const & a_documentStoringPropertiesSequence, UnoDocumentTailor const * a_unoDocumentTailor) {
				::com::sun::star::util::URL l_convertedFileUrlInURL = i_remoteUnoObjectsContext->createUrlInURL (a_convertedFileUrl);
				Sequence <PropertyValue> l_unoDocumentOpeningPropertiesSequence (UnoPropertiesHandler::buildPropertiesSequence (UnoDocumentOpeningEnumerablePropertyNamesSet::c_instance.getValues (), ListsFactory::createList <Any, Any, Any, Any, Any> (Any (true), Any (true), Any (true), Any (true), Any (UnoExtendedStringHandler::getOustring (a_convertedFilePassword.has_value () ? *a_convertedFilePassword : GeneralConstantsConstantsGroup::c_emptyString)))));
				Any l_convertedUnoDocumentInAny = i_fileOpeningUnoDispatcherInXSynchronousDispatch->dispatchWithReturnValue (l_convertedFileUrlInURL, l_unoDocumentOpeningPropertiesSequence);
				bool l_hasSucceeded = false;
				if (l_convertedUnoDocumentInAny.hasValue ()) {
					Reference <XComponent> l_convertedUnoDocumentInXComponent = * ((Reference <XComponent> *) (l_convertedUnoDocumentInAny.getValue ()));
					try {
						if (a_unoDocumentTailor != nullptr) {
							a_unoDocumentTailor->tailor (l_convertedUnoDocumentInXComponent);
						}
						Reference <XStorable2> l_convertedUnoDocumentInXStorable2 = Reference <XStorable2> (l_convertedUnoDocumentInXComponent, UNO_QUERY);
						l_convertedUnoDocumentInXStorable2->storeToURL (UnoExtendedStringHandler::getOustring (a_targetFileUrl), a_documentStoringPropertiesSequence);
						l_hasSucceeded = true;
					}
					catch (Exception & l_exception) {
						Publisher::logErrorInformation (UnoExtendedStringHandler::getString (l_exception.Message));
					}
					catch (...) {
						throw new runtime_error (string ("An exception has occurred."));
					}
					Reference <XCloseable> l_convertedUnoDocumentInXCloseable = Reference <XCloseable> (l_convertedUnoDocumentInXComponent, UNO_QUERY);
					l_convertedUnoDocumentInXCloseable->close (false); 
				}
				else {
				}
				return l_hasSucceeded;
			}
			
			Sequence <PropertyValue> FilesConverter::createCsvFileStoringPropertiesSequence (int const & a_itemsDelimiterCharacterCode, int const & a_textItemQuotationCharacterCode, int const & a_charactersEncodingCode, bool const & a_whetherAllTextItemsAreQuoted, bool const & a_whetherContentsAreExportedAsShown, bool const & a_whetherFormulaThemselvesAreExported) {
				list <string> l_documentStoringPropertyNames = ListsFactory::createList <string> (
					UnoDocumentStoringEnumerablePropertyNamesSet::c_filterName_string,
					UnoDocumentStoringEnumerablePropertyNamesSet::c_filterData_string,
					UnoDocumentStoringEnumerablePropertyNamesSet::c_overwrites_boolen
				);
				list <Any> l_documentStoringPropertyValues = ListsFactory::createList <Any> (
					Any (UnoExtendedStringHandler::getOustring (UnoFileStoringFilterNamesConstantsGroup::c_csvFileFilterName)),
					Any (UnoExtendedStringHandler::getOustring (StringHandler::format (c_csvFormatStringFormat, a_itemsDelimiterCharacterCode, a_textItemQuotationCharacterCode, a_charactersEncodingCode, a_whetherAllTextItemsAreQuoted, a_whetherContentsAreExportedAsShown, a_whetherFormulaThemselvesAreExported))),
					Any (true)
				);
				return UnoPropertiesHandler::buildPropertiesSequence (l_documentStoringPropertyNames, l_documentStoringPropertyValues);
			}
			
			bool FilesConverter::convertSpreadSheetsDocumentFileToCsvFiles (string const & a_convertedFileUrl, optional <string> const & a_convertedFilePassword, string const & a_targetFileUrlBase, Sequence <PropertyValue> const & a_documentStoringPropertiesSequence, UnoDocumentTailor const * a_unoDocumentTailor, int const & a_targetFileNamingRule, bool const & a_hiddenSpreadSheetsAreWritten) {
				::com::sun::star::util::URL l_convertedFileUrlInURL = i_remoteUnoObjectsContext->createUrlInURL (a_convertedFileUrl);
				Sequence <PropertyValue> l_unoDocumentOpeningPropertiesSequence (UnoPropertiesHandler::buildPropertiesSequence (UnoDocumentOpeningEnumerablePropertyNamesSet::c_instance.getValues (), ListsFactory::createList <Any, Any, Any, Any, Any> (Any (true), Any (true), Any (true), Any (true), Any (UnoExtendedStringHandler::getOustring (a_convertedFilePassword.has_value () ? *a_convertedFilePassword : GeneralConstantsConstantsGroup::c_emptyString)))));
				Any l_convertedUnoDocumentInAny = i_fileOpeningUnoDispatcherInXSynchronousDispatch->dispatchWithReturnValue (l_convertedFileUrlInURL, l_unoDocumentOpeningPropertiesSequence);
				bool l_hasSucceeded = false;
				if (l_convertedUnoDocumentInAny.hasValue ()) {
					Reference <XComponent> l_convertedUnoDocumentInXComponent = * ((Reference <XComponent> *) (l_convertedUnoDocumentInAny.getValue ()));
					try {
						if (a_unoDocumentTailor != nullptr) {
							a_unoDocumentTailor->tailor (l_convertedUnoDocumentInXComponent);
						}
						Reference <XSpreadsheetDocument> l_spreadSheetsDocumentInXSpreadsheetDocument (l_convertedUnoDocumentInXComponent, UNO_QUERY);
						if (!(l_spreadSheetsDocumentInXSpreadsheetDocument.is ())) {
							Publisher::logErrorInformation ("The document is not any spread sheet.");
							return false;
						}
						else {
							Reference <XStorable2> l_convertedUnoDocumentInXStorable2 (l_convertedUnoDocumentInXComponent, UNO_QUERY);
							Reference <XSpreadsheets2> l_spreadSheetsInXSpreadsheets2 (l_spreadSheetsDocumentInXSpreadsheetDocument->getSheets (), UNO_QUERY);
							Reference <XIndexAccess> l_spreadSheetsInXIndexAccess (l_spreadSheetsInXSpreadsheets2, UNO_QUERY);
							int l_numberOfSheets = l_spreadSheetsInXIndexAccess->getCount ();
							Reference <XNamed> l_spreadSheetInXNamed;
							Reference <XPropertySet> l_spreadSheetInXPropertySet;
							string l_targetFileNameAugmentation;
							int l_lastPeriodPositionInTargetFileUrlBase = a_targetFileUrlBase.rfind (".");
							string l_augmentedTargetFileUrl;
							bool l_whetherSheetIsVisible = false;
							for (int l_sheetIndex = GeneralConstantsConstantsGroup::c_iterationStartingNumber; l_sheetIndex < l_numberOfSheets; l_sheetIndex ++) {
								l_spreadSheetInXNamed = Reference <XNamed> (*((Reference <XNamed> *) l_spreadSheetsInXIndexAccess->getByIndex (l_sheetIndex).getValue ()), UNO_QUERY);
								if (a_hiddenSpreadSheetsAreWritten) {
								}
								else {
									l_spreadSheetInXPropertySet = Reference <XPropertySet> (l_spreadSheetInXNamed, UNO_QUERY);
									l_whetherSheetIsVisible = UnoDatumConverter::convertToBool (l_spreadSheetInXPropertySet->getPropertyValue (UnoExtendedStringHandler::getOustring (UnoSpreadSheetPropertyNamesSet::c_whetherIsVisible_boolean))); 
									if (!l_whetherSheetIsVisible) {
										continue;
									}
								}
								if (a_targetFileNamingRule == 0) {
									l_targetFileNameAugmentation = StringHandler::format ("%d", l_sheetIndex);
								}
								else {
									l_targetFileNameAugmentation = UnoExtendedStringHandler::getString (l_spreadSheetInXNamed->getName ());
								}
								if (l_lastPeriodPositionInTargetFileUrlBase >= GeneralConstantsConstantsGroup::c_iterationStartingNumber) {
									l_augmentedTargetFileUrl = StringHandler::format ("%s_%s%s", a_targetFileUrlBase.substr (GeneralConstantsConstantsGroup::c_iterationStartingNumber, l_lastPeriodPositionInTargetFileUrlBase), l_targetFileNameAugmentation, a_targetFileUrlBase.substr (l_lastPeriodPositionInTargetFileUrlBase));
								}
								else {
									l_augmentedTargetFileUrl = StringHandler::format ("%s_%s", a_targetFileUrlBase, l_targetFileNameAugmentation);
								}
								l_spreadSheetsInXSpreadsheets2->moveByName (l_spreadSheetInXNamed->getName (), (short) GeneralConstantsConstantsGroup::c_iterationStartingNumber);
								l_convertedUnoDocumentInXStorable2->storeToURL (UnoExtendedStringHandler::getOustring (l_augmentedTargetFileUrl), a_documentStoringPropertiesSequence);
							}
							l_hasSucceeded = true;
						}
					}
					catch (Exception & l_exception) {
						Publisher::logErrorInformation (UnoExtendedStringHandler::getString (l_exception.Message));
						throw l_exception;
					}
					catch (...) {
						throw new runtime_error (string ("An exception has occurred."));
					}
					Reference <XCloseable> l_convertedUnoDocumentInXCloseable = Reference <XCloseable> (l_convertedUnoDocumentInXComponent, UNO_QUERY);
					l_convertedUnoDocumentInXCloseable->close (false); 
				}
				else {
				}
				return l_hasSucceeded;
			}
		}
	}
}

