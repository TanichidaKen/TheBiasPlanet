#include "theBiasPlanet/unoUtilities/filesConverting/FilesConverter.hpp"
#include <com/sun/star/frame/XStorable2.hpp>
#include <com/sun/star/frame/XSynchronousDispatch.hpp>
#include <com/sun/star/util/XCloseable.hpp>
#include "theBiasPlanet/coreUtilities/collectionsHandling/ListsFactory.hpp"
#include "theBiasPlanet/unoUtilities/collectionsHandling/UnoSequenceHandler.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/UnoDocumentOpeningEnumerablePropertyNamesSet.hpp"
#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/UnoDocumentStoringEnumerablePropertyNamesSet.hpp"
#include "theBiasPlanet/unoUtilities/propertiesHandling/UnoPropertiesHandler.hpp"
#include "theBiasPlanet/unoUtilities/stringsHandling/UnoExtendedStringHandler.hpp"
#include "theBiasPlanet/unoUtilities/unoDataHandling/UnoDatumConverter.hpp"

using namespace ::theBiasPlanet::coreUtilities::collectionsHandling;
using namespace ::theBiasPlanet::unoUtilities::collectionsHandling;
using namespace ::theBiasPlanet::unoUtilities::constantsGroups;
using namespace ::theBiasPlanet::unoUtilities::constantsGroups::propertyNamesSets;
using namespace ::theBiasPlanet::unoUtilities::propertiesHandling;
using namespace ::theBiasPlanet::unoUtilities::stringsHandling;
using namespace ::theBiasPlanet::unoUtilities::unoDataHandling;

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace filesConverting {
			FilesConverter::FilesConverter (Reference <UnoObjectsContext> a_remoteUnoObjectsContext) : i_remoteUnoObjectsContext (a_remoteUnoObjectsContext), i_unoDocumentOpeningPropertiesSequence (UnoPropertiesHandler::buildPropertiesSequence (UnoDocumentOpeningEnumerablePropertyNamesSet::c_instance.getValues (), ListsFactory::createList <Any, Any, Any, Any> (Any (true), Any (true), Any (true), Any (true)))), i_fileOpeningUnoDispatcherInXSynchronousDispatch (i_remoteUnoObjectsContext->getFileOpeningUnoDispatcherInXSynchronousDispatch ()) {
			}
			
			FilesConverter::~FilesConverter () {
			}
			
			bool FilesConverter::convertFile (string const & a_convertedFileUrl, string const & a_targetFileUrl, Sequence <PropertyValue> & a_documentStoringPropertiesSequence) {
				::com::sun::star::util::URL l_convertedFileUrlInURL = i_remoteUnoObjectsContext->createUrlInURL (a_convertedFileUrl);
				Any l_convertedUnoDocumentInAny = i_fileOpeningUnoDispatcherInXSynchronousDispatch->dispatchWithReturnValue (l_convertedFileUrlInURL, i_unoDocumentOpeningPropertiesSequence);
				bool l_hasSucceeded = false;
				if (l_convertedUnoDocumentInAny.hasValue ()) {
					Reference <XComponent> l_convertedUnoDocumentInXComponent = * ((Reference <XComponent> *) (l_convertedUnoDocumentInAny.getValue ()));
					Reference <XStorable2> l_convertedUnoDocumentInXStorable2 = Reference <XStorable2> (l_convertedUnoDocumentInXComponent, UNO_QUERY);
					try {
						l_convertedUnoDocumentInXStorable2->storeToURL (UnoExtendedStringHandler::getOustring (a_targetFileUrl), a_documentStoringPropertiesSequence);
						l_hasSucceeded = true;
					}
					catch (...) {
					}
					Reference <XCloseable> l_convertedUnoDocumentInXCloseable = Reference <XCloseable> (l_convertedUnoDocumentInXComponent, UNO_QUERY);
					l_convertedUnoDocumentInXCloseable->close (false); 
				}
				else {
				}
				return l_hasSucceeded;
			}
		}
	}
}

