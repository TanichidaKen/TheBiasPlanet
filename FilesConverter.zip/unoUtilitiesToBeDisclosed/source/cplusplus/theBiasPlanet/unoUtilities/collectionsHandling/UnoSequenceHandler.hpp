#ifndef __theBiasPlanet_unoUtilities_collectionsHandling_UnoSequenceHandler_hpp__
	#define __theBiasPlanet_unoUtilities_collectionsHandling_UnoSequenceHandler_hpp__
	
	#include <list>
	#include <set>
	#include <com/sun/star/uno/Sequence.hxx>
	#include <cppu/unotype.hxx>
	#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	using namespace ::com::sun::star::uno;
	
	namespace theBiasPlanet {
		namespace unoUtilities {
			namespace collectionsHandling {
				class __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ UnoSequenceHandler {
					public:
						template <typename T, typename U> static Sequence <U> * fillSequence (Sequence <U> * a_sequence, list <T> const & a_list);
						template <typename T, typename U> static Sequence <U> * fillSequence (Sequence <U> * a_sequence, set <T> const & a_set);
						template <typename T, typename U> static list <U> * fillList (list <U> * a_list, Sequence <T> const & a_sequence);
						template <typename T> static string toString (Sequence <T> const & a_sequence);
				};
			}
		}
	}
#endif

