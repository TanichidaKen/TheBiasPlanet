#ifndef __theBiasPlanet_unoUtilities_propertiesHandling_UnoPropertiesHandler_hpp__
	#define __theBiasPlanet_unoUtilities_propertiesHandling_UnoPropertiesHandler_hpp__
	
	#include <list>
	#include <string>
	#include <com/sun/star/beans/PropertyValue.hpp>
	#include <com/sun/star/uno/Any.h>
	#include <com/sun/star/uno/Sequence.hxx>
	#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	using namespace ::com::sun::star::beans;
	using namespace ::com::sun::star::uno;
	
	namespace theBiasPlanet {
		namespace unoUtilities {
			namespace propertiesHandling {
				class __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ UnoPropertiesHandler {
					public:
						static Sequence <PropertyValue> buildPropertiesSequence (list <string> const & a_propertyNames, list <Any> const & a_propertyValues);
				};
			}
		}
	}
#endif

