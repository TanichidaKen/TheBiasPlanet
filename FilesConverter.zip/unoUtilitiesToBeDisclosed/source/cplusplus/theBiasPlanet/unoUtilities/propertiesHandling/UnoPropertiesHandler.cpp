#include "theBiasPlanet/unoUtilities/propertiesHandling/UnoPropertiesHandler.hpp"
#include "theBiasPlanet/coreUtilities/constantsGroups/GeneralConstantsConstantsGroup.hpp"
#include "theBiasPlanet/unoUtilities/property/UnoProperty.hpp"
#include "theBiasPlanet/unoUtilities/stringsHandling/UnoExtendedStringHandler.hpp"

using namespace ::theBiasPlanet::coreUtilities::constantsGroups;
using namespace ::theBiasPlanet::unoUtilities::property;
using namespace ::theBiasPlanet::unoUtilities::stringsHandling;

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace propertiesHandling {
			Sequence <PropertyValue> UnoPropertiesHandler::buildPropertiesSequence (list <string> a_propertyNames, list <Any> a_propertyValues) {
				Sequence <PropertyValue> l_propertiesSequence (a_propertyNames.size ());
				list <Any>::iterator a_propertyValuesIterator = a_propertyValues.begin ();
				int l_propertyIndex = GeneralConstantsConstantsGroup::c_iterationStartingNumber;
				for (string l_propertyName: a_propertyNames) {
					l_propertiesSequence [l_propertyIndex] = UnoProperty (l_propertyName, *a_propertyValuesIterator);
					a_propertyValuesIterator ++;
					l_propertyIndex ++;
				}
				return l_propertiesSequence;
			}
		}
	}
}

