#ifndef __theBiasPlanet_unoUtilities_nameValuePair_UnoNameValuePair_hpp__
	#define __theBiasPlanet_unoUtilities_nameValuePair_UnoNameValuePair_hpp__
	
	#include <string>
	#include <com/sun/star/beans/NamedValue.hpp>
	#include <com/sun/star/uno/Any.h>
	#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	using namespace ::com::sun::star::beans;
	using namespace ::com::sun::star::uno;
	
	namespace theBiasPlanet {
		namespace unoUtilities {
			namespace nameValuePair {
				class __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ UnoNameValuePair : public NamedValue {
					public:
						UnoNameValuePair (string a_name, Any a_value);
				};
			}
		}
	}
#endif

