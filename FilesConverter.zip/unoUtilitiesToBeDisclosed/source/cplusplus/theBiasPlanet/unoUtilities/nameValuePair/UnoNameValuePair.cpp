#include "theBiasPlanet/unoUtilities/nameValuePair/UnoNameValuePair.hpp"
#include "theBiasPlanet/unoUtilities/stringsHandling/UnoExtendedStringHandler.hpp"

using namespace ::theBiasPlanet::unoUtilities::stringsHandling;

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace nameValuePair {
			UnoNameValuePair::UnoNameValuePair (string a_name, Any a_value) {
				Name = UnoExtendedStringHandler::getOustring (a_name);
				Value = a_value;
			}
		}
	}
}

