#ifndef __theBiasPlanet_unoUtilities_connectionsHandling_UnoObjectsContext_hpp__
	#define __theBiasPlanet_unoUtilities_connectionsHandling_UnoObjectsContext_hpp__
	
	#include <list>
	#include <map>
	#include <optional>
	#include <string>
	#include <com/sun/star/frame/XDesktop2.hpp>
	#include <com/sun/star/frame/XDispatchProvider.hpp>
	#include <com/sun/star/frame/XSynchronousDispatch.hpp>
	#include <com/sun/star/lang/XMultiComponentFactory.hpp>
	#include <com/sun/star/uno/Any.h>
	#include <com/sun/star/uno/Type.h>
	#include <com/sun/star/uno/Reference.hxx>
	#include <com/sun/star/uno/XComponentContext.hpp>
	#include <com/sun/star/util/URL.hpp>
	#include <com/sun/star/util/XURLTransformer.hpp>
	#include <cppuhelper/compbase1.hxx>
	#include <osl/mutex.hxx>
	#include <rtl/ustring.hxx>
	#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	using namespace ::com::sun::star::container;
	using namespace ::com::sun::star::frame;
	using namespace ::com::sun::star::lang;
	using namespace ::com::sun::star::uno;
	using namespace ::com::sun::star::util;
	using namespace ::cppu;
	using namespace ::osl;
	using namespace ::rtl;
	
	namespace theBiasPlanet {
		namespace unoUtilities {
			namespace connectionsHandling {
				class __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ UnoObjectsContext : public WeakComponentImplHelper1 <XComponentContext> {
					private:
						Mutex i_mutex;
						Reference <XComponentContext> i_originalObjectsContextInXComponentContext;
						optional <map <string, Any>> i_extraNameToValueMap;
						Reference <XDesktop2> i_unoDesktopInXDesktop2;
						Reference <XDispatchProvider> i_unoDesktopInXDispatchProvider;
						Reference <XURLTransformer> i_urlTransformerInXURLTransformer;
						Reference <XSynchronousDispatch> i_fileOpeningUnoDispatcherInXSynchronousDispatch;
					public:
						UnoObjectsContext (Reference <XComponentContext> a_originalObjectsContextInXComponentContext, optional <map <string, Any>> a_extraNameToValueMap);
						virtual ~UnoObjectsContext ();
						virtual Any SAL_CALL getValueByName (OUString const & a_name) override;
						virtual Reference <XMultiComponentFactory> SAL_CALL getServiceManager () override;
						virtual bool SAL_CALL isFromSameOrigin (Reference <UnoObjectsContext> a_unoObjectsContext);
						// This cannot be made virtual because of the sucky C++ specifications
						template <typename T> Reference <T> getServiceInstance (string const & a_serviceName, optional <list <Any>> const & a_arguments);
						virtual Reference <XDesktop2> getUnoDesktopInXDesktop2 ();
						virtual Reference <XDispatchProvider> getUnoDesktopInXDispatchProvider ();
						virtual Reference <XSynchronousDispatch> getFileOpeningUnoDispatcherInXSynchronousDispatch ();
						virtual ::com::sun::star::util::URL createUrlInURL (string a_url);
				};
			}
		}
	}
#endif

