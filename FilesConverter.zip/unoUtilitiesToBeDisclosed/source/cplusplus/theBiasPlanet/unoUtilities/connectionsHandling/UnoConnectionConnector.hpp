#ifndef __theBiasPlanet_unoUtilities_connectionsHandling_UnoConnectionConnector_hpp__
	#define __theBiasPlanet_unoUtilities_connectionsHandling_UnoConnectionConnector_hpp__
	
	#include <list>
	#include "theBiasPlanet/unoUtilities/connectionsHandling/UnoConnection.hpp"
	#include "theBiasPlanet/unoUtilities/connectionsHandling/UnoConnectionEventsListener.hpp"
	#include "theBiasPlanet/unoUtilities/connectionsHandling/UnoConnectionsFactory.hpp"
	#include "theBiasPlanet/unoUtilities/connectionsHandling/UnoObjectsContext.hpp"
	#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	
	namespace theBiasPlanet {
		namespace unoUtilities {
			namespace connectionsHandling {
				class __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ UnoConnectionConnector : public UnoConnectionsFactory {
					public:
						UnoConnectionConnector (Reference <UnoObjectsContext> a_localObjectsContext);
						virtual Reference <UnoConnection> connect (string const & a_url, optional <list <UnoConnectionEventsListener *> const> const a_eventListeners) final;
				};
			}
		}
	}
#endif

