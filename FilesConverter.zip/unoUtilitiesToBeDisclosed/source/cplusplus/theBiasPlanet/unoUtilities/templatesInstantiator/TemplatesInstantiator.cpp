#include <optional>
#include <string>
#include <com/sun/star/beans/PropertyValue.hpp>
#include <com/sun/star/bridge/XBridgeFactory.hpp>
#include <com/sun/star/connection/XConnector.hpp>
#include <com/sun/star/frame/XComponentLoader.hpp>
#include <com/sun/star/frame/XDesktop2.hpp>
#include <com/sun/star/frame/XDispatchProvider.hpp>
#include <com/sun/star/uno/Any.h>
#include <com/sun/star/uno/Type.hxx>
#include <com/sun/star/uno/Reference.hxx>
#include <com/sun/star/util/XURLTransformer.hpp>
#include <cppu/unotype.hxx>
#include <rtl/ustring.hxx>
#include "theBiasPlanet/unoUtilities/connectionsHandling/UnoObjectsContext.hpp"
#ifdef __theBiasPlanet_unoUtilities__
#include "theBiasPlanet/unoUtilities/collectionsHandling/UnoSequenceHandler.tpp"
#include "theBiasPlanet/unoUtilities/connectionsHandling/UnoObjectsContext.tpp"
#include "theBiasPlanet/unoUtilities/servicesHandling/UnoServiceHandler.tpp"
#include "theBiasPlanet/unoUtilities/unoDataHandling/UnoDatumConverter.tpp"
#else
#include "theBiasPlanet/unoUtilities/collectionsHandling/UnoSequenceHandler.hpp"
#include "theBiasPlanet/unoUtilities/connectionsHandling/UnoObjectsContext.hpp"
#include "theBiasPlanet/unoUtilities/servicesHandling/UnoServiceHandler.hpp"
#include "theBiasPlanet/unoUtilities/unoDataHandling/UnoDatumConverter.hpp"
#endif
#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"

using namespace ::com::sun::star::beans;
using namespace ::com::sun::star::bridge;
using namespace ::com::sun::star::connection;
using namespace ::com::sun::star::frame;
using namespace ::com::sun::star::uno;
using namespace ::com::sun::star::util;
using namespace ::rtl;
using namespace ::theBiasPlanet::unoUtilities::collectionsHandling;
using namespace ::theBiasPlanet::unoUtilities::servicesHandling;
using namespace ::theBiasPlanet::unoUtilities::unoDataHandling;

template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ list <bool> UnoDatumConverter::convertToNonUnoDatum <sal_Bool, bool> (Sequence <sal_Bool> const & a_unoDatum);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ list <unsigned char> UnoDatumConverter::convertToNonUnoDatum <sal_Int8, unsigned char> (Sequence <sal_Int8> const & a_unoDatum);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ list <short> UnoDatumConverter::convertToNonUnoDatum <sal_Int16, short> (Sequence <sal_Int16> const & a_unoDatum);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ list <long> UnoDatumConverter::convertToNonUnoDatum <sal_Int32, long> (Sequence <sal_Int32> const & a_unoDatum);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ list <long long> UnoDatumConverter::convertToNonUnoDatum <sal_Int64, long long> (Sequence <sal_Int64> const & a_unoDatum);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ list <float> UnoDatumConverter::convertToNonUnoDatum <float, float> (Sequence <float> const & a_unoDatum);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ list <double> UnoDatumConverter::convertToNonUnoDatum <double, double> (Sequence <double> const & a_unoDatum);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ list <char> UnoDatumConverter::convertToNonUnoDatum <sal_Unicode, char> (Sequence <sal_Unicode> const & a_unoDatum);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ list <string> UnoDatumConverter::convertToNonUnoDatum <OUString, string> (Sequence <OUString> const & a_unoDatum);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ list <string> UnoDatumConverter::convertToNonUnoDatum <Type, string> (Sequence <Type> const & a_unoDatum);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ Any UnoDatumConverter::convertToUnoDatum <Any> (Any const & a_unoDatum);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ Any UnoDatumConverter::convertToUnoAnyDatum <bool> (bool const & a_unoDatum);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ Any UnoDatumConverter::convertToUnoAnyDatum <bool> (optional <bool> const & a_unoDatum);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ Any UnoDatumConverter::convertToUnoAnyDatum <string> (string const & a_unoDatum);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ Any UnoDatumConverter::convertToUnoAnyDatum <string> (optional <string> const & a_unoDatum);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ Any UnoDatumConverter::convertToUnoAnyDatum <Sequence <PropertyValue>> (Sequence <PropertyValue> const & a_unoDatum);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ Any UnoDatumConverter::convertToUnoAnyDatum <Sequence <PropertyValue>> (optional <Sequence <PropertyValue>> const & a_unoDatum);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ Sequence <Any> * UnoSequenceHandler::fillSequence <Any, Any> (Sequence <Any> * a_sequence, list <Any> const & a_list);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ Sequence <PropertyValue> * UnoSequenceHandler::fillSequence <PropertyValue, PropertyValue> (Sequence <PropertyValue> * a_sequence, list <PropertyValue> const & a_list);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ Sequence <OUString> * UnoSequenceHandler::fillSequence <string, OUString> (Sequence <OUString> * a_sequence, set <string> const & a_set);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ string UnoSequenceHandler::toString <sal_Bool> (Sequence <sal_Bool> const & a_sequence);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ string UnoSequenceHandler::toString <sal_Int8> (Sequence <sal_Int8> const & a_sequence);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ string UnoSequenceHandler::toString <sal_Int16> (Sequence <sal_Int16> const & a_sequence);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ string UnoSequenceHandler::toString <sal_Int32> (Sequence <sal_Int32> const & a_sequence);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ string UnoSequenceHandler::toString <sal_Int64> (Sequence <sal_Int64> const & a_sequence);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ string UnoSequenceHandler::toString <float> (Sequence <float> const & a_sequence);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ string UnoSequenceHandler::toString <double> (Sequence <double> const & a_sequence);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ string UnoSequenceHandler::toString <sal_Unicode> (Sequence <sal_Unicode> const & a_sequence);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ string UnoSequenceHandler::toString <OUString> (Sequence <OUString> const & a_sequence);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ string UnoSequenceHandler::toString <Type> (Sequence <Type> const & a_sequence);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ string UnoSequenceHandler::toString <Any> (Sequence <Any> const & a_sequence);
/*
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ Reference <XBridgeFactory> UnoServiceHandler::getServiceInstance <XBridgeFactory> (Reference <UnoObjectsContext> a_unoObjectsContext, string const & a_serviceName, optional <list <Any>> const & a_arguments);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ Reference <XConnector> UnoServiceHandler::getServiceInstance <XConnector> (Reference <UnoObjectsContext> a_unoObjectsContext, string const & a_serviceName, optional <list <Any>> const & a_arguments);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ Reference <XComponentLoader> UnoServiceHandler::getServiceInstance <XComponentLoader> (Reference <UnoObjectsContext> a_unoObjectsContext, string const & a_serviceName, optional <list <Any>> const & a_arguments);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ Reference <XDesktop2> UnoServiceHandler::getServiceInstance <XDesktop2> (Reference <UnoObjectsContext> a_unoObjectsContext, string const & a_serviceName, optional <list <Any>> const & a_arguments);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ Reference <XDispatchProvider> UnoServiceHandler::getServiceInstance <XDispatchProvider> (Reference <UnoObjectsContext> a_unoObjectsContext, string const & a_serviceName, optional <list <Any>> const & a_arguments);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ Reference <XURLTransformer> UnoServiceHandler::getServiceInstance <XURLTransformer> (Reference <UnoObjectsContext> a_unoObjectsContext, string const & a_serviceName, optional <list <Any>> const & a_arguments);
*/
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ Reference <XBridgeFactory> UnoObjectsContext::getServiceInstance <XBridgeFactory> (string const & a_serviceName, optional <list <Any>> const & a_arguments);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ Reference <XConnector> UnoObjectsContext::getServiceInstance <XConnector> (string const & a_serviceName, optional <list <Any>> const & a_arguments);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ Reference <XComponentLoader> UnoObjectsContext::getServiceInstance <XComponentLoader> (string const & a_serviceName, optional <list <Any>> const & a_arguments);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ Reference <XDesktop2> UnoObjectsContext::getServiceInstance <XDesktop2> (string const & a_serviceName, optional <list <Any>> const & a_arguments);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ Reference <XDispatchProvider> UnoObjectsContext::getServiceInstance <XDispatchProvider> (string const & a_serviceName, optional <list <Any>> const & a_arguments);
template __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ Reference <XURLTransformer> UnoObjectsContext::getServiceInstance <XURLTransformer> (string const & a_serviceName, optional <list <Any>> const & a_arguments);

/*
namespace theBiasPlanet {
	namespace unoUtilities {
		namespace templatesInstantiator {
			void  TemplatesInstantiator::instantiateTemplates () {
				//Reference <UnoObjectsContext> l_unoObjectsContext;
				//UnoServiceHandler::getServiceInstance <XBridgeFactory> (l_unoObjectsContext, GeneralConstantsConstantsGroup::c_emptyString);
				//UnoServiceHandler::getServiceInstance <XConnector> (l_unoObjectsContext, GeneralConstantsConstantsGroup::c_emptyString);
				//UnoServiceHandler::getServiceInstance <XComponentLoader> (l_unoObjectsContext, GeneralConstantsConstantsGroup::c_emptyString);
				//UnoServiceHandler::getServiceInstance <XDesktop2> (l_unoObjectsContext, GeneralConstantsConstantsGroup::c_emptyString);
			}
		}
	}
}
*/

