package theBiasPlanet.unoUtilities.displaysHandling;

import java.util.Arrays;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import com.sun.star.lang.EventObject;
import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.coreUtilities.messaging.CustomizedAlert;
import theBiasPlanet.unoUtilities.connectionsHandling.UnoConnection;
import theBiasPlanet.unoUtilities.connectionsHandling.UnoConnectionConnector;
import theBiasPlanet.unoUtilities.programsHandling.UnoFxProcessEnvironment;

public class UnoConnectionConnectorScene extends UnoConnectionBaseScene {
	private static final String c_defaultTitle;
	private static final int c_defaultWidth;
	private static final int c_defaultHeight;
	private Button i_connectButton = null;
	private UnoConnectionConnector i_unoConnectionConnector = null;
	private boolean i_connecting = false;
	protected UnoConnection i_unoConnection = null;
	
	static {
		c_defaultTitle = "Uno Connection Connector Frame";
		c_defaultWidth = 700;
		c_defaultHeight = 100;
	}
	
	public UnoConnectionConnectorScene (String a_title, int a_width, int a_height) throws com.sun.star.uno.Exception {
		super (a_title, a_width, a_height);
		i_unoConnectionConnector = new UnoConnectionConnector (UnoFxProcessEnvironment.s_currentEnvironment.getUnoEnvironment ().getLocalObjectsContext ());
		i_connectButton = new Button (UserInterfaceComponentCaptionsConstantsGroup.c_connect);
		i_connectButton.setOnAction(
			(a_event) -> {
				connectActionPerformed(a_event);
			}
		);
		i_commandsPane.add (i_connectButton, 0, 0);
		i_disconnectButton.setOnAction (
			(a_event) -> {
				disconnectActionPerformed(a_event);
			}
		);
		i_commandsPane.add(i_disconnectButton, 1, 0);
		setStatusDisplay ();
	}
	
	public UnoConnectionConnectorScene () throws com.sun.star.uno.Exception {
		this (c_defaultTitle, c_defaultWidth, c_defaultHeight);
	}
	
	private void connectActionPerformed(ActionEvent a_event) {
		try {
			Thread l_subThread = new Thread (() -> {
				try {
					i_unoConnectionConnector.connect (i_urlTextField.getText (), Arrays.asList (this));
				}
				catch (com.sun.star.uno.Exception l_exception) {
					l_exception.printStackTrace ();
					showAlert (CustomizedAlert.AlertType.ERROR, l_exception.toString ());
				}
				finally {
					i_connecting = false;
					setStatusDisplay ();
				}
			});
			i_connecting = true;
			setStatusDisplay (MessagesConstantsGroup.c_connecting);
			l_subThread.start ();
		}
		catch (java.lang.Exception l_exception) {
			showAlert (CustomizedAlert.AlertType.ERROR, l_exception.toString ());
		}
	}
	
	private void disconnectActionPerformed (ActionEvent a_event) {
		if (i_unoConnection != null) {
			i_unoConnection.disconnect ();
		}
	}
	
	private void setStatusDisplay () {
		Platform.runLater(() -> {
			if (i_unoConnection == null) {
				i_statusLabel.setText (MessagesConstantsGroup.c_notConnected);
				i_disconnectButton.setDisable (true);
			}
			else {
				i_statusLabel.setText (MessagesConstantsGroup.c_connected);
				i_disconnectButton.setDisable (false);
			}
			i_connectButton.setDisable (!(!i_connecting && (i_unoConnection == null)));
			i_urlTextField.setDisable (!(!i_connecting && (i_unoConnection == null)));
		});
	}
	
	private void setStatusDisplay (String a_statusMessage) {
		setStatusDisplay ();
		Platform.runLater(() -> {
			i_statusLabel.setText (a_statusMessage);
		});
	}
	
	@Override
	public void connected (EventObject a_event) {
		i_unoConnection = (UnoConnection) a_event.Source;
		setStatusDisplay ();
	}
	
	@Override
	public void disconnected(EventObject a_event) {
		i_unoConnection = null;
		setStatusDisplay ();
	}
	
	@Override
	protected void close () {
		disconnectActionPerformed (null);
		super.close ();
	}
}

