package theBiasPlanet.unoUtilities.pointers;

import java.util.ArrayList;
import java.util.Map;
import com.sun.star.beans.Property;
import com.sun.star.beans.UnknownPropertyException;
import com.sun.star.beans.XPropertySet;
import com.sun.star.beans.XPropertySetInfo;
import com.sun.star.lang.WrappedTargetException;
import com.sun.star.uno.UnoRuntime;
import com.sun.star.uno.XInterface;
import theBiasPlanet.coreUtilities.collections.NavigableLinkedHashMap;
import theBiasPlanet.coreUtilities.constantsGroups.WarningNamesConstantsGroup;
import theBiasPlanet.coreUtilities.messagingHandling.Publisher;
import theBiasPlanet.coreUtilities.stringsHandling.StringHandler;
import theBiasPlanet.unoUtilities.inspectionsHandling.UnoComponentInspector;
import theBiasPlanet.unoUtilities.inspectionsHandling.UnoInterfaceNotImplementedException;

public class UnoObjectPointer <T extends XInterface> {
	private T i_primaryAddress = null;
	private NavigableLinkedHashMap <String, XInterface> i_unoInterfaceNameToAddressMap = new NavigableLinkedHashMap <String, XInterface> ();
	private static String c_unoObjectsInformationDumpFilePathString = null;
	
	public static void setUnoObjectsInformationDumpFilePathString (String a_unoObjectsInformationDumpFilePathString) {
		c_unoObjectsInformationDumpFilePathString = a_unoObjectsInformationDumpFilePathString;
	}
	
	public UnoObjectPointer () {
	}
	
	public UnoObjectPointer (T a_primaryAddress) {
		i_primaryAddress = a_primaryAddress;
		if (i_primaryAddress != null && c_unoObjectsInformationDumpFilePathString != null) {
			try {
				Publisher.appendToFile (c_unoObjectsInformationDumpFilePathString, String.format ("### %s -> %s", i_primaryAddress.toString (), String.join (", ", getUnoTypeNames ())));
				StringBuilder l_propertyNameValuePairsStringBuilder = new StringBuilder ();
				NavigableLinkedHashMap <String, Object> l_propertyNameToValueMap = getPropertyNameToValueMap ();
				boolean l_is1stItem = true;
				for (Map.Entry <String, Object> l_propertyNameToValueMapEntry: l_propertyNameToValueMap.entrySet ()) {
					if (l_is1stItem) {
						l_is1stItem = false;
					}
					else {
						l_propertyNameValuePairsStringBuilder.append (", ");
					}
					l_propertyNameValuePairsStringBuilder.append (l_propertyNameToValueMapEntry.getKey ());
					l_propertyNameValuePairsStringBuilder.append (": ");
					l_propertyNameValuePairsStringBuilder.append (l_propertyNameToValueMapEntry.getValue ());
				}
				Publisher.appendToFile (c_unoObjectsInformationDumpFilePathString, String.format ("### %s -> %s", i_primaryAddress.toString (), l_propertyNameValuePairsStringBuilder.toString ()));
			}
			catch (UnoInterfaceNotImplementedException | WrappedTargetException l_exception) {
				Publisher.appendToFile (c_unoObjectsInformationDumpFilePathString, String.format ("### %s -> %s", i_primaryAddress.toString (), l_exception.toString ()));
			}
		}
	}
	
	public <U extends XInterface> UnoObjectPointer (U a_sourceAddress, Class <T> a_targetClass) {
		this ( (T) UnoRuntime.queryInterface (a_targetClass, a_sourceAddress));
	}
	
	public <U extends XInterface> UnoObjectPointer (UnoObjectPointer <U> a_sourcePointer, Class <T> a_targetClass) throws UnoInterfaceNotImplementedException {
		this (a_sourcePointer. <T>getAddress (a_targetClass));
		i_unoInterfaceNameToAddressMap = a_sourcePointer.i_unoInterfaceNameToAddressMap;
	}
	
	@Override
	public void finalize () {
		clear ();
	}
	
	public ArrayList <String> getUnoTypeNames () throws UnoInterfaceNotImplementedException {
		return UnoComponentInspector.getUnoTypeNames (i_primaryAddress);
	}
	
	public NavigableLinkedHashMap <String, Object> getPropertyNameToValueMap () throws UnoInterfaceNotImplementedException, WrappedTargetException {
		return UnoComponentInspector.getPropertyNameToValueMap (i_primaryAddress);
	}
	
	public boolean isEmpty () {
		return i_primaryAddress == null;
	}
	
	public void setPrimaryAddress (T a_primaryAddress) {
		clear ();
		i_primaryAddress = a_primaryAddress;
	}
	
	public void clear () {
		if (i_primaryAddress != null) {
			i_primaryAddress = null;
			i_unoInterfaceNameToAddressMap = new NavigableLinkedHashMap <String, XInterface> ();
		}
	}
	
	public T getAddress () {
		return i_primaryAddress;
	}
	
	@SuppressWarnings (WarningNamesConstantsGroup.c_notChecked)
	public <U extends XInterface> U getAddress (Class <U> a_targetClass) {
		U l_address = null;
		String l_unoInterfaceName = a_targetClass.getName ();
		l_address = (U) i_unoInterfaceNameToAddressMap.get (l_unoInterfaceName);
		if (l_address == null) {
			l_address = (U) UnoRuntime.queryInterface (a_targetClass, i_primaryAddress);
			if (l_address != null) {
				i_unoInterfaceNameToAddressMap.put (l_unoInterfaceName, l_address);
			}
			else {
			}
		}
		return l_address;
	}
}

