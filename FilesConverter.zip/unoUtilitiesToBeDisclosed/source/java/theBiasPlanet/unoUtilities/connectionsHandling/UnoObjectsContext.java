package theBiasPlanet.unoUtilities.connectionsHandling;

import java.util.List;
import java.util.Map;
import com.sun.star.frame.XDesktop2;
import com.sun.star.frame.XDispatchProvider;
import com.sun.star.frame.XSynchronousDispatch;
import com.sun.star.lang.XMultiComponentFactory;
import com.sun.star.security.XCertificate;
import com.sun.star.xml.crypto.XSEInitializer;
import com.sun.star.xml.crypto.XSecurityEnvironment;
import com.sun.star.xml.crypto.XXMLSecurityContext;
import com.sun.star.uno.UnoRuntime;
import com.sun.star.uno.XComponentContext;
import com.sun.star.util.XURLTransformer;
import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.coreUtilities.stringsHandling.StringHandler;
import theBiasPlanet.unoUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.*;
import theBiasPlanet.unoUtilities.servicesHandling.UnoServiceHandler;

public class UnoObjectsContext implements XComponentContext {
	private XComponentContext i_originalObjectsContextInXComponentContext;
	private Map <String, Object> i_extraNameToValueMap;
	private XDesktop2 i_unoDesktopInXDesktop2;
	private XDispatchProvider i_unoDesktopInXDispatchProvider;
	private XURLTransformer i_urlTransformerInXURLTransformer;
	private XSynchronousDispatch i_fileOpeningUnoDispatcherInXSynchronousDispatch;
	private XSecurityEnvironment i_gnupgSecurityEnvironmentInXSecurityEnvironment;
	private XSecurityEnvironment i_networkSecurityServicesSecurityEnvironmentInXSecurityEnvironment;
	
	public UnoObjectsContext (XComponentContext a_originalObjectsContextInXComponentContext, Map <String, Object> a_extraNameToValueMap) throws com.sun.star.uno.Exception {
		if (a_originalObjectsContextInXComponentContext == null) {
			throw new com.sun.star.uno.Exception (UnoMessagesConstantsGroup.c_unoObjectsContextNotSpecified);
		}
		i_originalObjectsContextInXComponentContext = a_originalObjectsContextInXComponentContext;
		i_extraNameToValueMap = a_extraNameToValueMap;
		i_unoDesktopInXDesktop2 = null;
		i_unoDesktopInXDispatchProvider = null;
		i_urlTransformerInXURLTransformer = null;
		i_fileOpeningUnoDispatcherInXSynchronousDispatch = null;
	}
	
	@Override
	public final Object getValueByName (String a_name) {
		if (i_extraNameToValueMap != null && i_extraNameToValueMap.containsKey (a_name)) {
			return i_extraNameToValueMap.get (a_name);
		}
		return i_originalObjectsContextInXComponentContext.getValueByName (a_name);
	}
	
	@Override
	public final XMultiComponentFactory getServiceManager () {
		return i_originalObjectsContextInXComponentContext.getServiceManager ();
	}
	
	public final boolean isFromSameOrigin (UnoObjectsContext a_unoObjectsContext) {
		if ((a_unoObjectsContext ==  null) || (i_extraNameToValueMap.get (UnoObjectsContextPropertyNamesSet.c_identification_string) == null)) {
			return false;
		}
		if (i_extraNameToValueMap.get (UnoObjectsContextPropertyNamesSet.c_identification_string).equals (a_unoObjectsContext.getValueByName (UnoObjectsContextPropertyNamesSet.c_identification_string))) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public Object getServiceInstance (String a_serviceName, Class a_targetClass, List <Object> a_arguments) throws com.sun.star.uno.Exception {
		return UnoServiceHandler.getServiceInstance (this, a_serviceName, a_targetClass, a_arguments);
	}
	
	public XDesktop2 getUnoDesktopInXDesktop2 () throws Exception {
		if (i_unoDesktopInXDesktop2 == null) {
			i_unoDesktopInXDesktop2 = (XDesktop2) getServiceInstance (UnoServiceNamesConstantsGroup.c_com_sun_star_frame_Desktop, XDesktop2.class, null);
		}
		else {
		}
		return i_unoDesktopInXDesktop2;
	}
	
	public XDispatchProvider getUnoDesktopInXDispatchProvider () throws Exception {
		if (i_unoDesktopInXDispatchProvider == null) {
			if (i_unoDesktopInXDesktop2 == null) {
				getUnoDesktopInXDesktop2 ();
			}
			else {
			}
			i_unoDesktopInXDispatchProvider = (XDispatchProvider) UnoRuntime.queryInterface (XDispatchProvider.class, i_unoDesktopInXDesktop2);
		}
		else {
		}
		return i_unoDesktopInXDispatchProvider;
	}
	
	public XSynchronousDispatch getFileOpeningUnoDispatcherInXSynchronousDispatch () throws Exception {
		if (i_fileOpeningUnoDispatcherInXSynchronousDispatch == null) {
			i_fileOpeningUnoDispatcherInXSynchronousDispatch = UnoRuntime.queryInterface (XSynchronousDispatch.class, getUnoDesktopInXDispatchProvider ().queryDispatch (createUrlInURL ("file:///"), UnoSpecialFrameNamesConstantsGroup.c_new, GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger));
		}
		return i_fileOpeningUnoDispatcherInXSynchronousDispatch;
	}
	
	public com.sun.star.util.URL createUrlInURL (String a_url) throws Exception {
		if (!StringHandler.validateAsUrl (a_url)) {
			return null;
		}
		if (i_urlTransformerInXURLTransformer == null) {
			i_urlTransformerInXURLTransformer = (XURLTransformer) getServiceInstance (UnoServiceNamesConstantsGroup.c_com_sun_star_util_URLTransformer, XURLTransformer.class, null);
		}
		com.sun.star.util.URL [] l_urlInURLArray = new com.sun.star.util.URL [1];
		l_urlInURLArray [GeneralConstantsConstantsGroup.c_iterationStartingNumber] = new com.sun.star.util.URL ();
		l_urlInURLArray [GeneralConstantsConstantsGroup.c_iterationStartingNumber].Complete = a_url;
		i_urlTransformerInXURLTransformer.parseStrict (l_urlInURLArray);
		return l_urlInURLArray [GeneralConstantsConstantsGroup.c_iterationStartingNumber];
	}
	
	private XCertificate selectCertificateFromCertificatesArray (XCertificate [] a_certificatesArrayInXCertificate, String a_certificateIssuerName, byte [] a_certificateSerialNumber) {
		if (a_certificatesArrayInXCertificate != null) {
			for (XCertificate l_certificateInXCertificate: a_certificatesArrayInXCertificate) {
				if (a_certificateIssuerName.equals (l_certificateInXCertificate.getIssuerName ())) {
					if (a_certificateSerialNumber == null) {
						return l_certificateInXCertificate;
					}
					else {
						byte [] l_certificateSerialNumber = l_certificateInXCertificate.getSerialNumber ();
						if (a_certificateSerialNumber.length == l_certificateSerialNumber.length) {
							int l_certificateSerialNumberByteIndex = GeneralConstantsConstantsGroup.c_iterationStartingNumber;
							for (byte l_certificateSerialNumberByte: l_certificateSerialNumber) {
								if (a_certificateSerialNumber [l_certificateSerialNumberByteIndex] != l_certificateSerialNumberByte) {
									break;
								}
								l_certificateSerialNumberByteIndex ++;
							}
							if (l_certificateSerialNumberByteIndex == l_certificateSerialNumber.length) {
								return l_certificateInXCertificate;
							}
						}
					}
				}
			}
		}
		return null;
	}
	
	public XCertificate getGnupgCertificateInXCertificate (String a_certificateIssuerName) throws Exception {
		if (i_gnupgSecurityEnvironmentInXSecurityEnvironment == null) {
			XSEInitializer l_gnupgSecurityEnvironmentInitializerInXSEInitializer = (XSEInitializer) getServiceInstance (UnoServiceNamesConstantsGroup.c_com_sun_star_xml_crypto_GPGSEInitializer, XSEInitializer.class, null);
			XXMLSecurityContext l_gnupgSecurityContextInXXMLSecurityContext = l_gnupgSecurityEnvironmentInitializerInXSEInitializer.createSecurityContext ("Gnupg"); 
			if (l_gnupgSecurityContextInXXMLSecurityContext.getSecurityEnvironmentNumber () > 0) {
				i_gnupgSecurityEnvironmentInXSecurityEnvironment = l_gnupgSecurityContextInXXMLSecurityContext.getSecurityEnvironmentByIndex (GeneralConstantsConstantsGroup.c_iterationStartingNumber);
			}
		}
		if (i_gnupgSecurityEnvironmentInXSecurityEnvironment != null) {
			XCertificate [] l_gnupgCertificatesArrayInXCertificate = i_gnupgSecurityEnvironmentInXSecurityEnvironment.getAllCertificates ();
			return selectCertificateFromCertificatesArray (l_gnupgCertificatesArrayInXCertificate, a_certificateIssuerName, null);
		}
		return null;
	}
	
	public XCertificate getNetworkSecurityServicesCertificateInXCertificate (String a_certificateIssuerName, byte [] a_certificateSerialNumber) throws Exception {
		if (i_networkSecurityServicesSecurityEnvironmentInXSecurityEnvironment == null) {
			XSEInitializer l_networkSecurityServicesSecurityEnvironmentInitializerInXSEInitializer = (XSEInitializer) getServiceInstance (UnoServiceNamesConstantsGroup.c_com_sun_star_xml_crypto_SEInitializer, XSEInitializer.class, null);
			XXMLSecurityContext l_networkSecurityServicesSecurityContextInXXMLSecurityContext = l_networkSecurityServicesSecurityEnvironmentInitializerInXSEInitializer.createSecurityContext ("NetworkSecurityServices"); 
			if (l_networkSecurityServicesSecurityContextInXXMLSecurityContext.getSecurityEnvironmentNumber () > 0) {
				i_networkSecurityServicesSecurityEnvironmentInXSecurityEnvironment = l_networkSecurityServicesSecurityContextInXXMLSecurityContext.getSecurityEnvironmentByIndex (GeneralConstantsConstantsGroup.c_iterationStartingNumber);
			}
		}
		if (i_networkSecurityServicesSecurityEnvironmentInXSecurityEnvironment != null) {
			XCertificate [] l_networkSecurityServicesCertificatesArrayInXCertificate = i_networkSecurityServicesSecurityEnvironmentInXSecurityEnvironment.getPersonalCertificates ();
			return selectCertificateFromCertificatesArray (l_networkSecurityServicesCertificatesArrayInXCertificate, a_certificateIssuerName, a_certificateSerialNumber);
		}
		return null;
	}
}

