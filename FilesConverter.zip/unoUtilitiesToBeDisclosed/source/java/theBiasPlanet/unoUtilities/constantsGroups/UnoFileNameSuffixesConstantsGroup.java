package theBiasPlanet.unoUtilities.constantsGroups;

public interface UnoFileNameSuffixesConstantsGroup {
	String c_unoIdlFileNameSuffix = "idl";
	String c_unoDataTypesMergedRegistryFileNameSuffix = "rdb";
}

