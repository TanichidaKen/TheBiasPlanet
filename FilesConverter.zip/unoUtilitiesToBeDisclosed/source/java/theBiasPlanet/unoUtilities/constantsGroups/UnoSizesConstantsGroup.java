package theBiasPlanet.unoUtilities.constantsGroups;

import com.sun.star.awt.Size;

public interface UnoSizesConstantsGroup {
	Size c_a3Landscape = new Size (42000, 29700);
	Size c_a3Portrait = new Size (29700, 42000);
	Size c_a4Landscape = new Size (29700, 21000);
	Size c_a4Portrait = new Size (21000, 29700);
	Size c_a5Landscape = new Size (21000, 14800);
	Size c_a5Portrait = new Size (14800, 21000);
	Size c_b4IsoLandscape = new Size (35300, 25000);
	Size c_b4IsoPortrait = new Size (25000, 35300);
	Size c_b4JisLandscape = new Size (36400, 25700);
	Size c_b4JisPortrait = new Size (25700, 36400);
	Size c_b5IsoLandscape = new Size (25000, 17600);
	Size c_b5IsoPortrait = new Size (17600, 25000);
	Size c_b5JisLandscape = new Size (25700, 18200);
	Size c_b5JisPortrait = new Size (18200, 25700);
	Size c_letterLandscape = new Size (27940, 21590);
	Size c_letterPortrait = new Size (21590, 27940);
}

