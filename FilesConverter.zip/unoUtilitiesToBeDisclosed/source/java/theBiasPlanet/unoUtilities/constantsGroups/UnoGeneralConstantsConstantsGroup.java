package theBiasPlanet.unoUtilities.constantsGroups;

public interface UnoGeneralConstantsConstantsGroup {
	String c_anyUnspecifiedString = "";
	char c_digitPlaceCharacter = '0';
	double c_numberExpressionModelNumber = 0.0;
	String c_cellPositionExpressionFormat = "$%s$%s";
	int c_rowIndexToRowPositionExpressionDifference = -1;
	String c_connectionUrlDelimiter = ";";
	String c_moduleDlimiter = "::";
	String c_unoServiceNameFormat = "%s.%s";
	String c_unoIdlFileNameFormat = String.format ("%%s.%s", UnoFileNameSuffixesConstantsGroup.c_unoIdlFileNameSuffix);
	String c_unoModuleBeginningRelativeExpressionFormat = "module %s {";
	String c_unoModuleEndRelativeExpressionFormat = "};";
}

