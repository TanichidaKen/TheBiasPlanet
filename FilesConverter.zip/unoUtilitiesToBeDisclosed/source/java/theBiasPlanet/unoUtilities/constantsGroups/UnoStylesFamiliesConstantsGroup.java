package theBiasPlanet.unoUtilities.constantsGroups;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.*;

// Interface because this is not enumerable
public interface UnoStylesFamiliesConstantsGroup {
	BaseStylesFamily c_pageStyles = new BaseStylesFamily ("PageStyles", (short) 0x08, UnoPageStyleEnumerablePropertyNamesSet.c_instance);
	BaseStylesFamily c_cellStyles = new BaseStylesFamily ("CellStyles", (short) 0x40, UnoSpreadSheetCellStyleEnumerablePropertyNamesSet.c_instance);
	BaseStylesFamily c_paragraphStyles = new BaseStylesFamily ("ParaStyles", (short) 0x02, null);
	BaseStylesFamily c_charStyles = new BaseStylesFamily ("CharStyles", (short) 0x01, null);
	BaseStylesFamily c_frameStyles = new BaseStylesFamily ("FrameStyles", (short) 0x04, null);
	BaseStylesFamily c_listStyles = new BaseStylesFamily ("PseudoStyles", (short) 0x10, null);
	
	// Base class for all the constants in this group
	static class BaseStylesFamily {
		public final String c_name;
		public final short c_key;
		public final BaseEnumerableConstantsGroup c_propertyNamesSet;
		
		BaseStylesFamily (String a_name, short a_key, BaseEnumerableConstantsGroup a_propertyNamesSet) {
			c_name = a_name;
			c_key = a_key;
			c_propertyNamesSet = a_propertyNamesSet;
		}
	}
}

