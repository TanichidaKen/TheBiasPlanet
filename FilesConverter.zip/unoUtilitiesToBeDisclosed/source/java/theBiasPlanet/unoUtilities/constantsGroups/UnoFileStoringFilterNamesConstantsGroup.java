package theBiasPlanet.unoUtilities.constantsGroups;

public interface UnoFileStoringFilterNamesConstantsGroup {
	String c_openDocumentWordProcessingFilterName = "writer8";
	String c_openDocumentSpreadsheetsFilterName = "calc8";
	String c_openDocumentPresentationsFilterName = "impress8";
	String c_microsoftWord97FileFilterName = "MS Word 97";
	String c_microsoftWord2007XmlFilterName = "MS Word 2007 XML";
	String c_microsoftExcel97FilterName = "MS Excel 97";
	String c_microsoftExcel2007XmlFilterName = "Calc MS Excel 2007 XML";
	String c_microsoftPowerPoint97FilterName = "MS PowerPoint 97";
	String c_microsoftPowerPoint2007XmlFilterName = "Impress MS PowerPoint 2007 XML";
	String c_csvFileFilterName = "Text - txt - csv (StarCalc)";
}

