package theBiasPlanet.unoUtilities.constantsGroups;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.*;

// Interface because this is not enumerable
public interface UnoDispatchSlotsConstantsGroup {
	BaseDispatchSlot c__uno_StyleNewByExample = new BaseDispatchSlot (".uno:StyleNewByExample", Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_GoToCell = new BaseDispatchSlot (".uno:GoToCell", Uno_uno_GoToCellEnumerablePropertyNamesSet.c_instance);
	// This slot is removed.
	BaseDispatchSlot c__uno_Cells = new BaseDispatchSlot (".uno:Cells", null);
	// This slot is removed.
	BaseDispatchSlot c__uno_Range = new BaseDispatchSlot (".uno:Range", Uno_uno_RangeEnumerablePropertyNamesSet.c_instance);
	// This slot is removed.
	BaseDispatchSlot c__uno_CellText = new BaseDispatchSlot (".uno:CellText", Uno_uno_CellTextEnumerablePropertyNamesSet.c_instance);
	// This slot is removed.
	BaseDispatchSlot c__uno_Selection = new BaseDispatchSlot (".uno:Selection", null);
	// This slot is removed.
	BaseDispatchSlot c__uno_ActiveCell = new BaseDispatchSlot (".uno:ActiveCell", null);
	// This slot is removed.
	BaseDispatchSlot c__uno_ActiveTable = new BaseDispatchSlot (".uno:ActiveTable", null);
	// This slot is removed.
	BaseDispatchSlot c__uno_Tables = new BaseDispatchSlot (".uno:Tables", null);
	// This slot is removed.
	BaseDispatchSlot c__uno_DataPilotTables = new BaseDispatchSlot (".uno:DataPilotTables", null);
	BaseDispatchSlot c__uno_Position = new BaseDispatchSlot (".uno:Position", null);
	BaseDispatchSlot c__uno_GoToCurrentCell = new BaseDispatchSlot (".uno:GoToCurrentCell", null);
	BaseDispatchSlot c__uno_StatusDocPos = new BaseDispatchSlot (".uno:StatusDocPos", null);
	BaseDispatchSlot c__uno_StatusSelectionMode = new BaseDispatchSlot (".uno:StatusSelectionMode", null);
	BaseDispatchSlot c__uno_StatusSelectionModeExp = new BaseDispatchSlot (".uno:StatusSelectionModeExp", null);
	BaseDispatchSlot c__uno_StatusSelectionModeExt = new BaseDispatchSlot (".uno:StatusSelectionModeExt", null);
	BaseDispatchSlot c__uno_StatusSelectionModeNorm = new BaseDispatchSlot (".uno:StatusSelectionModeNorm", null);
	BaseDispatchSlot c__uno_SelectData = new BaseDispatchSlot (".uno:SelectData", null);
	BaseDispatchSlot c__uno_SetInputMode = new BaseDispatchSlot (".uno:SetInputMode", null);
	BaseDispatchSlot c__uno_JumpToPreviousCell = new BaseDispatchSlot (".uno:JumpToPreviousCell", null);
	BaseDispatchSlot c__uno_DataSelect = new BaseDispatchSlot (".uno:DataSelect", null);
	BaseDispatchSlot c__uno_ExternalEdit = new BaseDispatchSlot (".uno:ExternalEdit", null);
	BaseDispatchSlot c__uno_PasteSpecial = new BaseDispatchSlot (".uno:PasteSpecial", Uno_uno_PasteSpecialEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_CompareDocuments = new BaseDispatchSlot (".uno:CompareDocuments", Uno_uno_CompareDocumentsEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_MergeDocuments = new BaseDispatchSlot (".uno:MergeDocuments", Uno_uno_MergeDocumentsEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_FontNameList = new BaseDispatchSlot (".uno:FontNameList", null);
	BaseDispatchSlot c__uno_Notebookbar = new BaseDispatchSlot (".uno:Notebookbar", Uno_uno_NotebookbarEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_GetColorTable = new BaseDispatchSlot (".uno:GetColorTable", null);
	BaseDispatchSlot c__uno_LanguageStatus = new BaseDispatchSlot (".uno:LanguageStatus", Uno_uno_LanguageStatusEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_TableCount = new BaseDispatchSlot (".uno:TableCount", null);
	BaseDispatchSlot c__uno_ScenarioManager = new BaseDispatchSlot (".uno:ScenarioManager", Uno_uno_ScenarioManagerEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_DeleteScenario = new BaseDispatchSlot (".uno:DeleteScenario", Uno_uno_DeleteScenarioEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_EditScenario = new BaseDispatchSlot (".uno:EditScenario", Uno_uno_EditScenarioEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_SelectScenario = new BaseDispatchSlot (".uno:SelectScenario", Uno_uno_SelectScenarioEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_StatusFunction = new BaseDispatchSlot (".uno:StatusFunction", null);
	BaseDispatchSlot c__uno_GoToObject = new BaseDispatchSlot (".uno:GoToObject", Uno_uno_GoToObjectEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_Name = new BaseDispatchSlot (".uno:Name", Uno_uno_NameEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_GoDown = new BaseDispatchSlot (".uno:GoDown", Uno_uno_GoDownEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_GoUp = new BaseDispatchSlot (".uno:GoUp", Uno_uno_GoUpEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_GoRight = new BaseDispatchSlot (".uno:GoRight", Uno_uno_GoRightEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_GoLeft = new BaseDispatchSlot (".uno:GoLeft", Uno_uno_GoLeftEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_GoDownBlock = new BaseDispatchSlot (".uno:GoDownBlock", Uno_uno_GoDownBlockEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_GoUpBlock = new BaseDispatchSlot (".uno:GoUpBlock", Uno_uno_GoUpBlockEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_GoRightBlock = new BaseDispatchSlot (".uno:GoRightBlock", Uno_uno_GoRightBlockEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_GoLeftBlock = new BaseDispatchSlot (".uno:GoLeftBlock", Uno_uno_GoLeftBlockEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_GoToStart = new BaseDispatchSlot (".uno:GoToStart", Uno_uno_GoToStartEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_GoToEndOfData = new BaseDispatchSlot (".uno:GoToEndOfData", Uno_uno_GoToEndOfDataEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_GoToStartSel = new BaseDispatchSlot (".uno:GoToStartSel", null);
	BaseDispatchSlot c__uno_GoToEndOfDataSel = new BaseDispatchSlot (".uno:GoToEndOfDataSel", null);
	BaseDispatchSlot c__uno_GoDownSel = new BaseDispatchSlot (".uno:GoDownSel", Uno_uno_GoDownSelEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_GoUpSel = new BaseDispatchSlot (".uno:GoUpSel", Uno_uno_GoUpSelEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_GoRightSel = new BaseDispatchSlot (".uno:GoRightSel", Uno_uno_GoRightSelEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_GoLeftSel = new BaseDispatchSlot (".uno:GoLeftSel", Uno_uno_GoLeftSelEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_GoToStartOfRow = new BaseDispatchSlot (".uno:GoToStartOfRow", Uno_uno_GoToStartOfRowEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_GoToStartOfRowSel = new BaseDispatchSlot (".uno:GoToStartOfRowSel", null);
	BaseDispatchSlot c__uno_GoToEndOfRow = new BaseDispatchSlot (".uno:GoToEndOfRow", Uno_uno_GoToEndOfRowEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_GoToEndOfRowSel = new BaseDispatchSlot (".uno:GoToEndOfRowSel", null);
	BaseDispatchSlot c__uno_GoDownBlockSel = new BaseDispatchSlot (".uno:GoDownBlockSel", Uno_uno_GoDownBlockSelEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_GoUpBlockSel = new BaseDispatchSlot (".uno:GoUpBlockSel", Uno_uno_GoUpBlockSelEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_GoRightBlockSel = new BaseDispatchSlot (".uno:GoRightBlockSel", Uno_uno_GoRightBlockSelEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_GoLeftBlockSel = new BaseDispatchSlot (".uno:GoLeftBlockSel", Uno_uno_GoLeftBlockSelEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_GoUpToStartOfData = new BaseDispatchSlot (".uno:GoUpToStartOfData", Uno_uno_GoUpToStartOfDataEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_GoUpToStartOfDataSel = new BaseDispatchSlot (".uno:GoUpToStartOfDataSel", Uno_uno_GoUpToStartOfDataSelEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_GoDownToEndOfData = new BaseDispatchSlot (".uno:GoDownToEndOfData", Uno_uno_GoDownToEndOfDataEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_GoDownToEndOfDataSel = new BaseDispatchSlot (".uno:GoDownToEndOfDataSel", Uno_uno_GoDownToEndOfDataSelEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_GoLeftToStartOfData = new BaseDispatchSlot (".uno:GoLeftToStartOfData", Uno_uno_GoLeftToStartOfDataEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_GoRightToEndOfData = new BaseDispatchSlot (".uno:GoRightToEndOfData", Uno_uno_GoRightToEndOfDataEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_GoLeftToStartOfDataSel = new BaseDispatchSlot (".uno:GoLeftToStartOfDataSel", Uno_uno_GoLeftToStartOfDataSelEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_GoRightToEndOfDataSel = new BaseDispatchSlot (".uno:GoRightToEndOfDataSel", Uno_uno_GoRightToEndOfDataSelEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_ClipboardFormatItems = new BaseDispatchSlot (".uno:ClipboardFormatItems", Uno_uno_ClipboardFormatItemsEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_PasteUnformatted = new BaseDispatchSlot (".uno:PasteUnformatted", null);
	BaseDispatchSlot c__uno_Paste = new BaseDispatchSlot (".uno:Paste", Uno_uno_PasteEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_PasteOnlyText = new BaseDispatchSlot (".uno:PasteOnlyText", null);
	BaseDispatchSlot c__uno_PasteOnlyFormula = new BaseDispatchSlot (".uno:PasteOnlyFormula", null);
	BaseDispatchSlot c__uno_PasteOnlyValue = new BaseDispatchSlot (".uno:PasteOnlyValue", null);
	BaseDispatchSlot c__uno_Cut = new BaseDispatchSlot (".uno:Cut", null);
	BaseDispatchSlot c__uno_Copy = new BaseDispatchSlot (".uno:Copy", null);
	BaseDispatchSlot c__uno_Delete = new BaseDispatchSlot (".uno:Delete", Uno_uno_DeleteEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_StateTableCell = new BaseDispatchSlot (".uno:StateTableCell", null);
	BaseDispatchSlot c__uno_ChangeCaseToUpper = new BaseDispatchSlot (".uno:ChangeCaseToUpper", null);
	BaseDispatchSlot c__uno_ChangeCaseToLower = new BaseDispatchSlot (".uno:ChangeCaseToLower", null);
	BaseDispatchSlot c__uno_ChangeCaseToHalfWidth = new BaseDispatchSlot (".uno:ChangeCaseToHalfWidth", null);
	BaseDispatchSlot c__uno_ChangeCaseToFullWidth = new BaseDispatchSlot (".uno:ChangeCaseToFullWidth", null);
	BaseDispatchSlot c__uno_ChangeCaseToHiragana = new BaseDispatchSlot (".uno:ChangeCaseToHiragana", null);
	BaseDispatchSlot c__uno_ChangeCaseToKatakana = new BaseDispatchSlot (".uno:ChangeCaseToKatakana", null);
	BaseDispatchSlot c__uno_HangulHanjaConversion = new BaseDispatchSlot (".uno:HangulHanjaConversion", null);
	BaseDispatchSlot c__uno_ChineseConversion = new BaseDispatchSlot (".uno:ChineseConversion", null);
	BaseDispatchSlot c__uno_ChangeCaseToSentenceCase = new BaseDispatchSlot (".uno:ChangeCaseToSentenceCase", null);
	BaseDispatchSlot c__uno_ChangeCaseToTitleCase = new BaseDispatchSlot (".uno:ChangeCaseToTitleCase", null);
	BaseDispatchSlot c__uno_ChangeCaseToToggleCase = new BaseDispatchSlot (".uno:ChangeCaseToToggleCase", null);
	BaseDispatchSlot c__uno_ChangeCaseRotateCase = new BaseDispatchSlot (".uno:ChangeCaseRotateCase", null);
	BaseDispatchSlot c__uno_StandardTextAttributes = new BaseDispatchSlot (".uno:StandardTextAttributes", null);
	BaseDispatchSlot c__uno_Text_Marquee = new BaseDispatchSlot (".uno:Text_Marquee", null);
	BaseDispatchSlot c__uno_ExecuteSearch = new BaseDispatchSlot (".uno:ExecuteSearch", Uno_uno_ExecuteSearchEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_SearchOptions = new BaseDispatchSlot (".uno:SearchOptions", null);
	BaseDispatchSlot c__uno_SearchProperties = new BaseDispatchSlot (".uno:SearchProperties", null);
	BaseDispatchSlot c__uno_Search = new BaseDispatchSlot (".uno:Search", Uno_uno_SearchEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_RepeatSearch = new BaseDispatchSlot (".uno:RepeatSearch", null);
	BaseDispatchSlot c__uno_SearchAll = new BaseDispatchSlot (".uno:SearchAll", Uno_uno_SearchAllEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_Replace = new BaseDispatchSlot (".uno:Replace", Uno_uno_ReplaceEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_ReplaceAll = new BaseDispatchSlot (".uno:ReplaceAll", Uno_uno_ReplaceAllEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_Grow = new BaseDispatchSlot (".uno:Grow", null);
	BaseDispatchSlot c__uno_Shrink = new BaseDispatchSlot (".uno:Shrink", null);
	BaseDispatchSlot c__uno_Calculate = new BaseDispatchSlot (".uno:Calculate", null);
	BaseDispatchSlot c__uno_CalculateHard = new BaseDispatchSlot (".uno:CalculateHard", null);
	BaseDispatchSlot c__uno_BasicIDEAppear = new BaseDispatchSlot (".uno:BasicIDEAppear", Uno_uno_BasicIDEAppearEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_CompileBasic = new BaseDispatchSlot (".uno:CompileBasic", null);
	BaseDispatchSlot c__uno_LoadBasic = new BaseDispatchSlot (".uno:LoadBasic", null);
	BaseDispatchSlot c__uno_UpdateAllModuleSources = new BaseDispatchSlot (".uno:UpdateAllModuleSources", null);
	BaseDispatchSlot c__uno_LibLoaded = new BaseDispatchSlot (".uno:LibLoaded", Uno_uno_LibLoadedEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_SelectAll = new BaseDispatchSlot (".uno:SelectAll", null);
	/*
	UpdateModuleSource
	UpdateAllModuleSources
	*/
	
	// Base class for all the constants in this group
	static class BaseDispatchSlot {
		public final String c_url;
		public final BaseEnumerableConstantsGroup <String> c_argumentPropertyNamesSet;
		
		BaseDispatchSlot (String a_url, BaseEnumerableConstantsGroup <String> a_argumentPropertyNamesSet) {
			c_url = a_url;
			c_argumentPropertyNamesSet = a_argumentPropertyNamesSet;
		}
	}
}

