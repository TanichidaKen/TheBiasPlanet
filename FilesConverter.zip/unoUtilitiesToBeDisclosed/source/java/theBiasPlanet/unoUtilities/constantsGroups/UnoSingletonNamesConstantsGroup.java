package theBiasPlanet.unoUtilities.constantsGroups;

// Interface because this is not enumerable
public interface UnoSingletonNamesConstantsGroup {
	String c_com_sun_star_frame_theDesktop = "com.sun.star.frame.theDesktop";
	String c_com_sun_star_frame_theGlobalEventBroadcaster = "com.sun.star.frame.theGlobalEventBroadcaster";
}

