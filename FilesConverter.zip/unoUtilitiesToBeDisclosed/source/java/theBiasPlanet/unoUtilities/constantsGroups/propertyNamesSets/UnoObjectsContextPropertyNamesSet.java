package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

public interface UnoObjectsContextPropertyNamesSet {
	String c_identification_string = "identification";
}

