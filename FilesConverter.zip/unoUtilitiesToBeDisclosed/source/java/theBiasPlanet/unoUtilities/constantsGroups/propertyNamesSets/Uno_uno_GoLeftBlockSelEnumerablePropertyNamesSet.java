package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_GoLeftBlockSelEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_numberOfPagesToGoLeftBy_short = "By";
	public static final Uno_uno_GoLeftBlockSelEnumerablePropertyNamesSet c_instance = new Uno_uno_GoLeftBlockSelEnumerablePropertyNamesSet ();
	
	private Uno_uno_GoLeftBlockSelEnumerablePropertyNamesSet () {
	}
}

