package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_NameEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_tableNewName_string = "Name";
	public static final String c_tableIndex_short = "Index"; // The index of the table (an item index (which starts from '1') under the 'Sheets' tree in the 'Navigator' window)
	public static final Uno_uno_NameEnumerablePropertyNamesSet c_instance = new Uno_uno_NameEnumerablePropertyNamesSet ();
	
	private Uno_uno_NameEnumerablePropertyNamesSet () {
	}
}

