package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_PasteEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_dummy_short = "AnchorType";
	public static final Uno_uno_PasteEnumerablePropertyNamesSet c_instance = new Uno_uno_PasteEnumerablePropertyNamesSet ();
	
	private Uno_uno_PasteEnumerablePropertyNamesSet () {
	}
}

