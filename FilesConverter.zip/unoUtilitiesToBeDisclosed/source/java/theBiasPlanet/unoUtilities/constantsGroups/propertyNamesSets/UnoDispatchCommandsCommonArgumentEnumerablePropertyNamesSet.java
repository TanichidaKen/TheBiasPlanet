package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class UnoDispatchCommandsCommonArgumentEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_synchronousMode_boolean = "SynchronMode";
	public static final UnoDispatchCommandsCommonArgumentEnumerablePropertyNamesSet c_instance = new UnoDispatchCommandsCommonArgumentEnumerablePropertyNamesSet ();
	
	private UnoDispatchCommandsCommonArgumentEnumerablePropertyNamesSet () {
	}
}

