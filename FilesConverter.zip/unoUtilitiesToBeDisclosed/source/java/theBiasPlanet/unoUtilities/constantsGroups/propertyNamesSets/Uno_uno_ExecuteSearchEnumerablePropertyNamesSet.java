package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_ExecuteSearchEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	// For some properties below, refer to 'srchitem.hxx' and 'https://api.libreoffice.org/docs/idl/ref/structcom_1_1sun_1_1star_1_1util_1_1SearchOptions.html'
	public static final String c_styleFamily_short = "SearchItem.StyleFamily"; // seems not be used
	public static final String c_searchedContents_short = "SearchItem.CellType"; // 0 -> formulas or non-formula values, 1 -> values, 2 -> comments
	public static final String c_searchDirection_boolean = "SearchItem.RowDirection"; // true -> row-wise, false -> column-wise
	public static final String c_whetherAllSheetsAreSearched_boolean = "SearchItem.AllTables"; // true -> search all the spread sheets, false -> only the current spread sheet is searched
	public static final String c_searchFilterd_boolean = "SearchItem.SearchFiltered"; // search also filtered out cells
	public static final String c_searchBackward_boolean = "SearchItem.Backward";
	public static final String c_cellStyleIsSearchedFor_boolean = "SearchItem.Pattern"; // search cell styles
	public static final String c_content_boolean = "SearchItem.Content"; // seems not be used; seems to mean about tagged formats like HTML
	public static final String c_stringsThatSoundLikeAreMatched_boolean = "SearchItem.AsianOptions"; // do "sounds-like" search
	public static final String c_algorithmType1_short = "SearchItem.AlgorithmType"; // Depricated; use 'c_algorithmType2_short' instead; 0 -> normal, 1 -> regular expression, 2 -> similarity
	public static final String c_searchFlags_long = "SearchItem.SearchFlags"; // Sum of these flags: 1 -> ALL_IGNORE_CASE (not supported), 16 -> NORM_WORD_ONLY -> search for only cells whose entire contents match the search expression, 256 -> REG_EXTENDED (deprecated and not supported by OOo), 1024 -> REG_NEWLINE (deprecated and not supported by OOo), 512 -> REG_NOSUB (deprecated and not supported by OOo), 2048 -> REG_NOT_BEGINOFLINE (for Calc, used for searching only selected cells), 4096 -> REG_NOT_ENDOFLINE (for Calc, seems not be used), ,65536 -> LEV_RELAXED (for similarity search (Weighted Levenshtein Distance search), if set, the search is also successful if the combined pool for insertions and deletions is below a doubled calculated limit and replacements are treated differently; additionally, swapped characters are counted as one replacement. From a user's point of view the relaxed WLD is an inclusive-OR of the arguments given, for example if allowed insertions=2 and allowed replacements=2, the search succeeds if 2 characters had been inserted and an additional replacement is needed to match. The relaxed algorithm may return false positives, but meets user expectation better; if not set, an exclusive-OR of the arguments given, for example if allowed insertions=2 and allowed replacements=2, the search fails if 2 characters had been inserted and an additional operation would be needed to match; depending on the weights it may also fail if 1 character was inserted and 1 character replaced and an additional operation would be needed to match. The strict algorithm may match less than expected from a first glance of the specified arguments, but does not return false positives., 1048576 -> WILD_MATCH_SELECTION Flag for glob search if entire selection must match the pattern. Refer to './target/workdir/UnoApiHeadersTarget/offapi/comprehensive/com/sun/star/util/SearchFlags.hdl' Refer to 'https://api.libreoffice.org/docs/idl/ref/namespacecom_1_1sun_1_1star_1_1util_1_1SearchFlags.html'
	public static final String c_searchedForString_string = "SearchItem.SearchString";
	public static final String c_replacedWithString_string = "SearchItem.ReplaceString";
	public static final String c_locale_com_sun_star_lang_Locale = "SearchItem.Locale"; // the locale for case insensitive judgment
	public static final String c_numberOfChangedCharactersToBeIgnored_long =  "SearchItem.ChangedChars";
	public static final String c_numberOfDeletedCharactersToBeIgnored_long = "SearchItem.DeletedChars";
	public static final String c_numberOfInsertedCharactersToBeIgnored_long = "SearchItem.InsertedChars";
	public static final String c_languageSpecificFlags_long =  "SearchItem.TransliterateFlags"; // Sum of these flags: 256 -> ignore the cases, 1024 -> ignore the character widths, 1073741824 ->  ignore diacritics. For more, refer to 'transliteration.hxx', 'target/workdir/UnoApiHeadersTarget/offapi/comprehensive/com/sun/star/i18n/TransliterationModules.hdl', 'TransliterationModulesExtra.hdl', 'https://api.libreoffice.org/docs/idl/ref/namespacecom_1_1sun_1_1star_1_1i18n.html#a9c57a33dd757352c82923f4c7f6cf93c', and 'https://api.libreoffice.org/docs/idl/ref/namespacecom_1_1sun_1_1star_1_1i18n_1_1TransliterationModulesExtra.html'
	public static final String c_commandType_short = "SearchItem.Command"; // 0 -> find, 1 -> find all, 2 -> replace, 3 -> replace all
	public static final String c_searchStartingPositionX_long = "SearchItem.SearchStartPointX"; // In twips
	public static final String c_searchStartingPositionY_long = "SearchItem.SearchStartPointY"; // In twips
	public static final String c_searchFormattedStrings_boolean = "SearchItem.SearchFormatted"; // search the formatted strings (for example, thousands separated), not the raw values
	public static final String c_algorithm2_short = "SearchItem.AlgorithmType2"; // 1 -> normal, 2 -> regular expression, 3 -> similarity, 4 -> glob expression
	public static final String c_quietly_boolean = "Quiet";
	
	public static final Uno_uno_ExecuteSearchEnumerablePropertyNamesSet c_instance = new Uno_uno_ExecuteSearchEnumerablePropertyNamesSet ();
	
	private Uno_uno_ExecuteSearchEnumerablePropertyNamesSet () {
	}
}

