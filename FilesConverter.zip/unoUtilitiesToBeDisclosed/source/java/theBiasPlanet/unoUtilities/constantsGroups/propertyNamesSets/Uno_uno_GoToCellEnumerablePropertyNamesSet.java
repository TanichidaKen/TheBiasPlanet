package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_GoToCellEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_destinationPoint_string = "ToPoint";
	public static final Uno_uno_GoToCellEnumerablePropertyNamesSet c_instance = new Uno_uno_GoToCellEnumerablePropertyNamesSet ();
	
	private Uno_uno_GoToCellEnumerablePropertyNamesSet () {
	}
}

