package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_DeleteStyleEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_styleName_string = "Param";
	public static final String c_styleFamilyKey_short = "Family";
	public static final Uno_uno_DeleteStyleEnumerablePropertyNamesSet c_instance = new Uno_uno_DeleteStyleEnumerablePropertyNamesSet ();
	
	private Uno_uno_DeleteStyleEnumerablePropertyNamesSet () {
	}
}

