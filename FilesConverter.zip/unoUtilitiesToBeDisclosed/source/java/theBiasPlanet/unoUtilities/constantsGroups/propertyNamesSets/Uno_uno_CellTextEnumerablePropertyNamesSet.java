package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_CellTextEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_columnIndex_short = "Column";
	public static final String c_rowIndex_int = "Row";
	public static final String c_tableIndex_short = "Table";
	public static final Uno_uno_CellTextEnumerablePropertyNamesSet c_instance = new Uno_uno_CellTextEnumerablePropertyNamesSet ();
	
	private Uno_uno_CellTextEnumerablePropertyNamesSet () {
	}
}

