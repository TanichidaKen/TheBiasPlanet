package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_GoToStartEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> {
	public static final String c_whetherTheCellsAreSelected_boolean = "Sel"; // Whether the command is in the changing-the-sells-selection mode
	public static final Uno_uno_GoToStartEnumerablePropertyNamesSet c_instance = new Uno_uno_GoToStartEnumerablePropertyNamesSet ();
	
	private Uno_uno_GoToStartEnumerablePropertyNamesSet () {
	}
}

