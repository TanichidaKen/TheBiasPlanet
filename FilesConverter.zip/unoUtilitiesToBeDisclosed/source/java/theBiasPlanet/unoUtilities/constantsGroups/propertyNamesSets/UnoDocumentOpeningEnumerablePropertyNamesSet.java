package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class UnoDocumentOpeningEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> {
	public static final String c_readOnly_boolean = "ReadOnly";
	public static final String c_hidden_boolean = "Hidden";
	public static final String c_openNewView_boolean = "OpenNewView";
	public static final String c_silent_boolean = "Silent";
	public static final String c_password_string = "Password";
	public static final UnoDocumentOpeningEnumerablePropertyNamesSet c_instance = new UnoDocumentOpeningEnumerablePropertyNamesSet ();
	
	private UnoDocumentOpeningEnumerablePropertyNamesSet () {
	}
}

