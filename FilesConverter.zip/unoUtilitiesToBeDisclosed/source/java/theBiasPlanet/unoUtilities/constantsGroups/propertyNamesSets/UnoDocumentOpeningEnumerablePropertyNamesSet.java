package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class UnoDocumentOpeningEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> {
	public static final String c_readOnly_Boolean = "ReadOnly";
	public static final String c_hidden_Boolean = "Hidden";
	public static final String c_openNewView_Boolean = "OpenNewView";
	public static final String c_silent_Boolean = "Silent";
	public static final UnoDocumentOpeningEnumerablePropertyNamesSet c_instance = new UnoDocumentOpeningEnumerablePropertyNamesSet ();
	
	private UnoDocumentOpeningEnumerablePropertyNamesSet () {
	}
}

