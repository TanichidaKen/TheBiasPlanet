package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class UnoDocumentStoringEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> {
	public static final String c_filterName_String = "FilterName";
	public static final String c_filterData_Object = "FilterData"; // supposed to be, but not necessarily, a sequence of 'com.sun.star.beans.PropertyValue'
	public static final String c_isTemplate_Boolean = "AsTemplate";
	public static final String c_authorName_String = "Author";
	public static final String c_title_String = "DocumentTitle";
	public static final String c_password_String = "Password";
	public static final String c_charactersSet_String = "CharacterSet";
	public static final String c_version_Short = "Version";
	public static final String c_versionDescription_String = "Comment";
	public static final String c_overwrites_Boolen = "Overwrite";
	public static final String c_documentTypeSpecificData_Object = "ComponentData"; // supposed to be, but not necessarily, a sequence of com.sun.star.beans.NamedValue
	public static final UnoDocumentStoringEnumerablePropertyNamesSet c_instance = new UnoDocumentStoringEnumerablePropertyNamesSet ();
	
	private UnoDocumentStoringEnumerablePropertyNamesSet () {
	}
}

