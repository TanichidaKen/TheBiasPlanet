package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class UnoDocumentStoringEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> {
	public static final String c_filterName_string = "FilterName";
	public static final String c_filterData_any = "FilterData"; // Some filters take this property while some other filters take the below property. Supposed to be, but not necessarily, a sequence of 'com.sun.star.beans.PropertyValue'
	public static final String c_filterData_string = "FilterOptions"; // Some filters take this property while some other filters take the above property.
	public static final String c_isTemplate_boolean = "AsTemplate";
	public static final String c_authorName_string = "Author";
	public static final String c_title_string = "DocumentTitle";
	public static final String c_encryptionData_NamedValuesSequence = "EncryptionData";
	public static final String c_password_string = "Password";
	public static final String c_charactersSet_string = "CharacterSet";
	public static final String c_version_short = "Version";
	public static final String c_versionDescription_string = "Comment";
	public static final String c_overwrites_boolen = "Overwrite";
	public static final String c_documentTypeSpecificData_any = "ComponentData"; // supposed to be, but not necessarily, a sequence of com.sun.star.beans.NamedValue
	public static final String c_editingPasswordInformation_any = "ModifyPasswordInfo";
	public static final UnoDocumentStoringEnumerablePropertyNamesSet c_instance = new UnoDocumentStoringEnumerablePropertyNamesSet ();
	
	private UnoDocumentStoringEnumerablePropertyNamesSet () {
	}
}

