package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

public interface UnoPdfExportingPropertyNamesSet extends UnoPropertyNamesSet {
	// General
	String c_pagesRange_string = "PageRange"; // "" -> all pages
	String c_printSelection_any = "Selection"; // the selection gotten by XSelectionSupplier.getSelection () of the controller of the document, or an arbitrary object
	String c_useLosslessCompression_boolean = "UseLosslessCompression"; // false -> use Jpeg compression
	String c_jpegQualityPercent_long = "Quality"; // 1 ~ 100
	String c_reduceImageResolution_boolean = "ReduceImageResolution";
	String c_maxImageResolutionDpi_long = "MaxImageResolution"; // 75, 150, 300, 600, or 1200
	String c_watermarkString_string = "Watermark";
	String c_embedOriginalDOcument_boolean = "IsAddStream"; // true -> embed the original document
	String c_pdfVersion_long = "SelectPdfVersion"; // 0 -> PDF 1.4, 1 -> PDF/A-1
	String c_useTaggedPdf_boolean = "UseTaggedPDF";
	String c_exportFormFields_boolean = "ExportFormFields";
	String c_formsType_long = "FormsType"; // 0 -> FDF, 1 -> PDF, 2 -> HTML, 3 -> XML
	String c_allowDuplicateFieldNames_boolean = " AllowDuplicateFieldNames";
	String c_exportBookmarks_boolean = "ExportBookmarks"; // Default: false
	String c_exportNotes_boolean = "ExportNotes"; // Default: false
	String c_skipEmptyPages_boolean = "IsSkipEmptyPages"; // Default: true
	String c_viewPdfAfterExport_boolean = "ViewPDFAfterExport"; // Default: false
	// Initial View
	String c_initialViewStyle_long = "InitialView"; // 0 -> pages only, 1 -> bookmarks and pages, 2-> thumbnails and pages
	String c_initialPage_long = "InitialPage";
	String c_initialMagnification_long = "Magnification"; // 0 -> default, 1 -> fit in window, 2 -> fit width, 3 -> fit visible
	String c_initialZoomFactorPercent_long = "Zoom";
	String c_initialPageLayoutStyle_long = "PageLayout"; // 0 -> default, 1 -> single page, 2 -> continuous, 3 -> continuous facing
	String c_firstPageOnLeft_boolean = "FirstPageOnLeft"; // valid when pageLayoutStyle is 3
	// User Interface
	String c_resizeWindowToInitialPage_boolean = "ResizeWindowToInitialPage";
	String c_centerWindowOnScreen_boolean = "CenterWindow";
	String c_openInFullScreenMode_boolean = "OpenInFullScreenMode";
	String c_displayPdfDocumentTitle_boolean = "DisplayPDFDocumentTitle";
	String c_useTransitionEffects_boolean = "UseTransitionEffects"; // Default: true
	String c_hideViewerMenubar_boolean = "HideViewerMenubar";
	String c_hideViewerToolbar_boolean = "HideViewerToolbar";
	String c_hideViewerWindowControls_boolean = "HideViewerWindowControls";
	String c_openedBookmarkLevels_long = "OpenBookmarkLevels"; // -1 -> all
	// Links
	String c_exportBookmarksAsNamedDestinations_boolean = " ExportBookmarksToPDFDestination";
	String c_convertDocumentReferencesToPdfTargets_boolean = "ConvertOOoTargetToPDFTarget";
	String c_exportLinksRelativeToFileSystem_boolean = "ExportLinksRelativeFsys";
	String c_crossDocumentsLinksViewer_long = "PDFViewSelection"; // 0 -> default mode, 1 -> open with a PDF reader application, 2 -> open with an integernet browser
	// Security
	String c_encryptFile_boolean = "EncryptFile";
	String c_documentOpeningPassword_string = "DocumentOpenPassword";
	String c_restrictActions_boolean = "RestrictPermissions";
	String c_restrictedActionsPassword_string = "PermissionPassword";
	String c_printingRestriction_long = "Printing"; // 0 -> not permitted, 1 -> low resolution, 2 -> high resolution
	String c_changingRestriction_long = "Changes"; // 0 -> not permitted, 1 -> inseting, deleting, and rotating pages, 2 -> filling in form fields, 3 -> commenting and filling in form fields, 4 -> any except extracting pages
	String c_enableCopyingOfContent_boolean = "EnableCopyingOfContent";
	String c_enableTextAccessForAccessibilityTools_boolean = "EnableTextAccessForAccessibilityTools";
	// Digital Signature
	String c_signPdf_boolean = "SignPDF";
	String c_signatureCertificate_com_sun_star_security_XCertificate = "SignatureCertificate";
	String c_signatureLocation_string = "SignatureLocation";
	String c_signatureReason_string = "SignatureReason";
	String c_signatureContactInformation_string = "SignatureContactInfo";
	String c_signaturePassword_string = "SignaturePassword";
	String c_signatureTimeStampAuthorityUrl_string = "SignatureTSA";
}

