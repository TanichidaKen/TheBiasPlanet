package theBiasPlanet.unoUtilities.constantsGroups;

public interface UnoCharactersEncodingCodesConstantsGroup {
	int c_utf8 = 76;
	int c_ucs2 = 65535;
	int c_ucs4 = 65534;
	int c_usAscii = 11;
	int c_eucJp = 69;
	int c_shiftJis = 64;
}

