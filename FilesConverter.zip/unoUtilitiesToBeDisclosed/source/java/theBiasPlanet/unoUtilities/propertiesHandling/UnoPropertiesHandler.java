package theBiasPlanet.unoUtilities.propertiesHandling;

import java.util.List;
import com.sun.star.beans.PropertyValue;
import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.property.UnoProperty;

public class UnoPropertiesHandler {
	public static PropertyValue [] buildPropertiesArray (List <String> a_propertyNames, List <Object> a_propertyValues) {
		PropertyValue [] l_propertiesArray = new PropertyValue [a_propertyNames.size ()];
		int l_propertyIndex = GeneralConstantsConstantsGroup.c_iterationStartingNumber;
		for (String l_propertyName: a_propertyNames) {
			l_propertiesArray [l_propertyIndex] = new UnoProperty (l_propertyName, a_propertyValues.get (l_propertyIndex));
			l_propertyIndex ++;
		}
		return l_propertiesArray;
	}
}

