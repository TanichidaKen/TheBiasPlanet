package theBiasPlanet.unoUtilities.dispatching;

import java.util.List;
import com.sun.star.beans.PropertyValue;
import com.sun.star.frame.XDispatchProvider;
import com.sun.star.frame.XDispatchResultListener;
import com.sun.star.frame.XFrame;
import com.sun.star.frame.XNotifyingDispatch;
import com.sun.star.frame.XStatusListener;
import com.sun.star.uno.UnoRuntime;
import theBiasPlanet.coreUtilities.collectionsHandling.ListsFactory;
import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.connectionsHandling.UnoObjectsContext;
import theBiasPlanet.unoUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.*;
import theBiasPlanet.unoUtilities.propertiesHandling.UnoPropertiesHandler;

public class UnoDispatcher {
	public static boolean dispatch (UnoObjectsContext a_unoObjectsContext, XFrame a_unoFrameInXFrame, XDispatchResultListener a_dispatchResultListener, XStatusListener a_dispatchRelatedInformationListener, UnoDispatchSlotsConstantsGroup.BaseDispatchSlot a_dispatchSlot, List <Object> a_argumentValues) throws Exception {
		PropertyValue [] l_dispatchArgumentPropertiesArray = null;
		if (a_dispatchSlot.c_argumentPropertyNamesSet != null && a_argumentValues != null) {
			l_dispatchArgumentPropertiesArray = UnoPropertiesHandler.buildPropertiesArray (ListsFactory. <String>createArrayListExpandingItems (UnoDispatchCommandsCommonArgumentEnumerablePropertyNamesSet.c_instance.getValues (), a_dispatchSlot.c_argumentPropertyNamesSet.getValues ()), ListsFactory. <Object>createArrayListExpandingItems (Boolean.valueOf (true), a_argumentValues));
		}
		else {
			l_dispatchArgumentPropertiesArray = UnoPropertiesHandler.buildPropertiesArray (UnoDispatchCommandsCommonArgumentEnumerablePropertyNamesSet.c_instance.getValues (), ListsFactory. <Object>createArrayList (Boolean.valueOf (true)));
		}
		com.sun.star.util.URL l_urlInURL = a_unoObjectsContext.createUrlInURL (a_dispatchSlot.c_url);
		XDispatchProvider l_unoFrameInXDispatchProvider = UnoRuntime.queryInterface (XDispatchProvider.class, a_unoFrameInXFrame);
		XNotifyingDispatch l_dispatcherInXNotifyingDispatch = UnoRuntime.queryInterface (XNotifyingDispatch.class, l_unoFrameInXDispatchProvider.queryDispatch (l_urlInURL, UnoSpecialFrameNamesConstantsGroup.c_self, GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger));
		if (l_dispatcherInXNotifyingDispatch != null) {
			l_dispatcherInXNotifyingDispatch.addStatusListener (a_dispatchRelatedInformationListener, l_urlInURL);
			l_dispatcherInXNotifyingDispatch.dispatchWithNotification (l_urlInURL, l_dispatchArgumentPropertiesArray, a_dispatchResultListener);
			l_dispatcherInXNotifyingDispatch.removeStatusListener (a_dispatchRelatedInformationListener, l_urlInURL);
			return true;
		}
		else {
			return false;
		}
	}
}

