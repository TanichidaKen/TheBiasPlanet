package theBiasPlanet.unoUtilities.dispatching;

import java.util.ArrayList;
import java.util.List;
import com.sun.star.frame.DispatchResultEvent;
import com.sun.star.frame.DispatchResultState;
import com.sun.star.frame.FeatureStateEvent;
import theBiasPlanet.unoUtilities.unoDataHandling.UnoDatumConverter;

public class UnoDispatchResult {
	private short i_finalStatus;
	private Object i_dispatchResult;
	private List <Object> i_relatedInformation;
	
	public UnoDispatchResult () {
		i_finalStatus = DispatchResultState.FAILURE;
		i_dispatchResult = null;
		i_relatedInformation = new ArrayList <Object> ();
	}
	
	public Object getDispatchResult () {
		return i_dispatchResult;
	}
	
	public void setDispatchResult (DispatchResultEvent a_dispatchResultEvent) {
		if (a_dispatchResultEvent != null) {
			i_finalStatus = a_dispatchResultEvent.State;
			i_dispatchResult = UnoDatumConverter.getObject (a_dispatchResultEvent.Result);
		}
		else {
			i_dispatchResult = null;
		}
	}
	
	public List <Object> getRelatedInformation () {
		return i_relatedInformation;
	}
	
	public void addRelatedInformationPiece (FeatureStateEvent a_featureStateEvent) {
		if (a_featureStateEvent != null) {
			if (a_featureStateEvent.State != null) {
				i_relatedInformation.add (UnoDatumConverter.getObject (a_featureStateEvent.State));
			}
			else {
				i_relatedInformation.add (null);
			}
		}
		else {
			i_relatedInformation.add (null);
		}
	}
	
	public String toString () {
		StringBuilder l_stringBuffer = new StringBuilder ();
		l_stringBuffer.append ("State = ");
		l_stringBuffer.append (String.format ("%d", i_finalStatus));
		l_stringBuffer.append (", Result = ");
		if (i_dispatchResult != null) {
			l_stringBuffer.append (i_dispatchResult.toString ());
		}
		else {
			l_stringBuffer.append ("null");
		}
		l_stringBuffer.append (", Related information = ");
		boolean l_isInFirstIterationOfRelatedInformationPieces = true;
		for (Object l_relatedInformationPiece: i_relatedInformation) {
			if (!l_isInFirstIterationOfRelatedInformationPieces) {
				l_stringBuffer.append (", ");
			}
			else {
				l_isInFirstIterationOfRelatedInformationPieces = false;
			}
			l_stringBuffer.append (UnoDatumConverter.toString (l_relatedInformationPiece));
		}
		return l_stringBuffer.toString ();
	}
}

