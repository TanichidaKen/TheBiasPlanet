package theBiasPlanet.unoUtilities.documentsHandling;

import java.util.ArrayList;
import com.sun.star.beans.PropertyValue;
import com.sun.star.beans.UnknownPropertyException;
import com.sun.star.beans.XPropertySet;
import com.sun.star.lang.WrappedTargetException;
import com.sun.star.lang.XComponent;
import com.sun.star.uno.UnoRuntime;
import theBiasPlanet.coreUtilities.collectionsHandling.ListsFactory;
import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.coreUtilities.cryptography.Hasher;
import theBiasPlanet.coreUtilities.messaging.Publisher;
import theBiasPlanet.coreUtilities.stringsHandling.StringHandler;
import theBiasPlanet.unoUtilities.connectionsHandling.UnoObjectsContext;
import theBiasPlanet.unoUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.*;
import theBiasPlanet.unoUtilities.cryptography.MicrosoftPasswordsHasher;
import theBiasPlanet.unoUtilities.propertiesHandling.UnoPropertiesHandler;

public class UnoOpenXmlDocumentSetEditingPasswordTailor extends UnoDocumentTailor {
	private String i_hashedEditingPasswordBase64String = null;
	private String i_saltBase64String = null;
	static private final int c_saltLength;
	static private final int c_numberOfHashingIteration;
	
	static {
		c_saltLength = 16;
		c_numberOfHashingIteration = 50000;
	}
	
	public UnoOpenXmlDocumentSetEditingPasswordTailor (UnoObjectsContext a_objectsContext, String a_editingPassword) {
		super (a_objectsContext);
		byte [] l_saltBytesArray = Hasher.createSalt (c_saltLength);
//l_saltBytesArray = new byte [] {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
		i_saltBase64String = StringHandler.getBase64String (l_saltBytesArray);
		i_hashedEditingPasswordBase64String = StringHandler.getBase64String (MicrosoftPasswordsHasher.hashHashWithSalt (MicrosoftPasswordsHasher.hashIn32bits (a_editingPassword), l_saltBytesArray, c_numberOfHashingIteration));
	}
	
	@Override
	public boolean tailor (XComponent a_unoDocumentInXComponent) {
		XPropertySet l_unoDocumentInXPropertySet = (XPropertySet) UnoRuntime.queryInterface (XPropertySet.class, a_unoDocumentInXComponent);
		if (l_unoDocumentInXPropertySet == null) {
			Publisher.logErrorInformation ("The document cannot have any property.");
			return false;
		}
		else {
			PropertyValue [] l_interoperationGrabBagPropertyValue = null;
			ArrayList <String> l_interoperationPropertyNames = ListsFactory. <String>createArrayList ();
			ArrayList <Object> l_interoperationPropertyValues = ListsFactory. <Object>createArrayList ();
			PropertyValue [] l_documentProtectionPropertyValue = null;
			int l_documentProtectionPropertyIndex = GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger;
			try {
				l_interoperationGrabBagPropertyValue = (PropertyValue []) l_unoDocumentInXPropertySet.getPropertyValue (UnoDocumentPropertyNamesSet.c_interoperationGrabBag_sequenceOfPropertyValues);
				int l_interoperationPropertyIndex = GeneralConstantsConstantsGroup.c_iterationStartingNumber;
				String l_interoperationPropertyName = null;
				Object l_interoperationPropertyValue = null;
				for (PropertyValue l_interoperationProperty : l_interoperationGrabBagPropertyValue) {
					l_interoperationPropertyName = l_interoperationProperty.Name;
					l_interoperationPropertyValue = l_interoperationProperty.Value;
					l_interoperationPropertyNames.add (l_interoperationPropertyName);
					l_interoperationPropertyValues.add (l_interoperationPropertyValue);
					if (l_interoperationPropertyName.equals (UnoInteroperationGrabBagPropertyNamesSet.c_documentProtection_sequenceOfPropertyValues)) {
						l_documentProtectionPropertyValue = (PropertyValue []) l_interoperationPropertyValue;
						l_documentProtectionPropertyIndex = l_interoperationPropertyIndex;
					}
					l_interoperationPropertyIndex ++;
				}
			}
			catch (UnknownPropertyException | WrappedTargetException l_exception) {
			}
			try {
				if (l_documentProtectionPropertyValue == null) {
					l_documentProtectionPropertyValue = new PropertyValue [10];
				}
				ArrayList <Object> l_documentProtectionPropertyValuePropertyValues = ListsFactory. <Object>createArrayList (UnoOpenXmlFileProtectionModesConstantsGroup.c_whole, Boolean.TRUE.toString (), Boolean.TRUE.toString (), UnoOpenXmlFileEncryptionProviderTypesConstantsGroup.c_rsaFull, UnoOpenXmlFileEncryptionAlgorithmClassesConstantsGroup.c_hash, UnoOpenXmlFileEncryptionAlgorithmTypesConstantsGroup.c_any, UnoOpenXmlFileHashingAlgorithmIdentificationsConstantsGroup.c_sha1, String.valueOf (c_numberOfHashingIteration), i_hashedEditingPasswordBase64String, i_saltBase64String);
				l_documentProtectionPropertyValue = UnoPropertiesHandler.buildPropertiesArray (UnoOpenXmlFileProtectionEnumerablePropertyNamesSet.c_instance.getValues (), l_documentProtectionPropertyValuePropertyValues);
				if (l_documentProtectionPropertyIndex != GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger) {
					l_interoperationGrabBagPropertyValue [l_documentProtectionPropertyIndex].Value = l_documentProtectionPropertyValue;
				}
				else {
					l_interoperationGrabBagPropertyValue = UnoPropertiesHandler.buildPropertiesArray (ListsFactory. <String>createArrayListExpandingItems (l_interoperationPropertyNames, UnoInteroperationGrabBagPropertyNamesSet.c_documentProtection_sequenceOfPropertyValues), ListsFactory. <Object>createArrayListExpandingItems (l_interoperationPropertyValues, l_documentProtectionPropertyValue));
				}
				l_unoDocumentInXPropertySet.setPropertyValue (UnoDocumentPropertyNamesSet.c_interoperationGrabBag_sequenceOfPropertyValues, l_interoperationGrabBagPropertyValue);
				return true;
			}
			catch (Exception l_exception) {
				Publisher.logErrorInformation (l_exception);
				return false;
			}
		}
	}
}

