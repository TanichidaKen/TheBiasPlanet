package theBiasPlanet.unoUtilities.documentsHandling;

import com.sun.star.beans.PropertyValue;
import com.sun.star.frame.FrameSearchFlag;
import com.sun.star.frame.XComponentLoader;
import com.sun.star.frame.XController;
import com.sun.star.frame.XDesktop2;
import com.sun.star.frame.XModel;
import com.sun.star.frame.XStorable2;
import com.sun.star.lang.XComponent;
import com.sun.star.uno.UnoRuntime;
import com.sun.star.util.CloseVetoException;
import com.sun.star.util.XCloseable;
import theBiasPlanet.coreUtilities.collectionsHandling.ListsFactory;
import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.connectionsHandling.UnoObjectsContext;
import theBiasPlanet.unoUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.*;
import theBiasPlanet.unoUtilities.propertiesHandling.UnoPropertiesHandler;

public class UnoDocument {
	protected UnoObjectsContext i_unoObjectsContext;
	protected XModel i_unoDocumentInXModel;
	protected XStorable2 i_unoDocumentInXStorable2;
	protected XController i_controllerInXController;
	
	public UnoDocument (UnoObjectsContext a_unoObjectsContext, XComponent a_unoDocumentInXComponent) throws Exception {
		if (a_unoObjectsContext == null) {
			throw new Exception (UnoMessagesConstantsGroup.c_unoObjectsContextNotSpecified);
		}
		i_unoObjectsContext = a_unoObjectsContext;
		if (a_unoDocumentInXComponent == null) {
			throw new Exception (UnoMessagesConstantsGroup.c_unoDocumentNotSpecified);
		}
		i_unoDocumentInXModel = (XModel) UnoRuntime.queryInterface (XModel.class, a_unoDocumentInXComponent);
		i_unoDocumentInXStorable2 = (XStorable2) UnoRuntime.queryInterface (XStorable2.class, i_unoDocumentInXModel);
		i_controllerInXController = (XController) UnoRuntime.queryInterface (XController.class, i_unoDocumentInXModel.getCurrentController ());
	}
	
	protected static XComponent createUnoDocumentOrOpenUnoDocumentFile (UnoObjectsContext a_unoObjectsContext, String a_fileUrl, boolean a_hiddenly) throws Exception, com.sun.star.io.IOException {
		XComponentLoader l_desktopInXComponentLoader = (XComponentLoader) a_unoObjectsContext.getServiceInstance (UnoServiceNamesConstantsGroup.c_com_sun_star_frame_Desktop, XComponentLoader.class, null);
		return l_desktopInXComponentLoader.loadComponentFromURL (a_fileUrl.replaceAll (RegularExpressionsConstantsGroup.c_windowsDirectoryDelimiterRegularExpression.pattern (), String.valueOf (GeneralConstantsConstantsGroup.c_linuxDirectoriesDelimiter)), UnoSpecialFrameNamesConstantsGroup.c_new, FrameSearchFlag.CREATE, UnoPropertiesHandler.buildPropertiesArray (UnoDocumentOpeningEnumerablePropertyNamesSet.c_instance.getValues (), ListsFactory. <Object>createArrayList (Boolean.valueOf (false), Boolean.valueOf (a_hiddenly), Boolean.valueOf (false), Boolean.valueOf (a_hiddenly))));
	}
	
	protected static XComponent getCurrentUnoDocument (UnoObjectsContext a_unoObjectsContext) throws Exception {
		XDesktop2 l_desktopInXDesktop2 = (XDesktop2) a_unoObjectsContext.getServiceInstance (UnoServiceNamesConstantsGroup.c_com_sun_star_frame_Desktop, XDesktop2.class, null);
		return l_desktopInXDesktop2.getCurrentComponent ();
	}
	
	public UnoObjectsContext getObjectsContext () {
		return i_unoObjectsContext;
	}
	
	public void close () throws CloseVetoException {
		XCloseable l_unoDocumentInXCloseable = (XCloseable) UnoRuntime.queryInterface (XCloseable.class, i_unoDocumentInXStorable2);
		l_unoDocumentInXCloseable.close (false); 
	}
}

