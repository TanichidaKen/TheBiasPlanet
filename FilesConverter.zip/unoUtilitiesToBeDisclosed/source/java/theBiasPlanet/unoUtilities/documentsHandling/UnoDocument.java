package theBiasPlanet.unoUtilities.documentsHandling;

import com.sun.star.beans.PropertyValue;
import com.sun.star.frame.FrameSearchFlag;
import com.sun.star.frame.XComponentLoader;
import com.sun.star.frame.XModel;
import com.sun.star.frame.XStorable2;
import com.sun.star.lang.XComponent;
import com.sun.star.uno.UnoRuntime;
import com.sun.star.util.CloseVetoException;
import com.sun.star.util.XCloseable;
import theBiasPlanet.coreUtilities.collectionsHandling.ListsFactory;
import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.connectionsHandling.UnoObjectsContext;
import theBiasPlanet.unoUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.*;
import theBiasPlanet.unoUtilities.propertiesHandling.UnoPropertiesHandler;

public class UnoDocument {
	protected UnoObjectsContext i_objectsContext;
	protected XModel i_unoDocumentInXModel;
	protected XStorable2 i_unoDocumentInXStorable2;
	
	public UnoDocument (UnoObjectsContext a_objectsContext, XComponent a_unoDocumentInXComponent) throws Exception {
		if (a_objectsContext == null) {
			throw new Exception (UnoMessagesConstantsGroup.c_objectsContextNotSpecified);
		}
		i_objectsContext = a_objectsContext;
		if (a_unoDocumentInXComponent == null) {
			throw new Exception (UnoMessagesConstantsGroup.c_unoDocumentNotSpecified);
		}
		i_unoDocumentInXModel = (XModel) UnoRuntime.queryInterface (XModel.class, a_unoDocumentInXComponent);
		i_unoDocumentInXStorable2 = (XStorable2) UnoRuntime.queryInterface (XStorable2.class, i_unoDocumentInXModel);
	}
	
	protected static XComponent createUnoDocumentOrOpenUnoDocumentFile (UnoObjectsContext a_objectsContext, String a_fileUrl, boolean a_hiddenly) throws Exception, com.sun.star.io.IOException {
		XComponentLoader l_desktopInXComponentLoader = (XComponentLoader) a_objectsContext.getServiceInstance (UnoServiceNamesConstantsGroup.c_com_sun_star_frame_Desktop, XComponentLoader.class, null);
		return l_desktopInXComponentLoader.loadComponentFromURL (a_fileUrl.replaceAll (RegularExpressionsConstantsGroup.c_windowsDirectoryDelimiterRegularExpression.pattern (), String.valueOf (GeneralConstantsConstantsGroup.c_linuxDirectoriesDelimiter)), UnoSpecialFrameNamesConstantsGroup.c_new, FrameSearchFlag.CREATE, UnoPropertiesHandler.buildPropertiesArray (UnoDocumentOpeningEnumerablePropertyNamesSet.c_instance.getValues (), ListsFactory. <Object>createArrayList (Boolean.valueOf (false), Boolean.valueOf (a_hiddenly), Boolean.valueOf (false), Boolean.valueOf (a_hiddenly))));
	}
	
	public UnoObjectsContext getObjectsContext () {
		return i_objectsContext;
	}
	
	public void close () throws CloseVetoException {
		XCloseable l_unoDocumentInXCloseable = (XCloseable) UnoRuntime.queryInterface (XCloseable.class, i_unoDocumentInXStorable2);
		l_unoDocumentInXCloseable.close (false); 
	}
}

