package theBiasPlanet.unoUtilities.documentsHandling;

import com.sun.star.container.XIndexAccess;
import com.sun.star.container.XNamed;
import com.sun.star.lang.XComponent;
import com.sun.star.sheet.XSpreadsheet;
import com.sun.star.sheet.XSpreadsheetDocument;
import com.sun.star.sheet.XSpreadsheets;
import com.sun.star.uno.Any;
import com.sun.star.uno.UnoRuntime;
import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.coreUtilities.messaging.Publisher;
import theBiasPlanet.unoUtilities.connectionsHandling.UnoObjectsContext;

public class UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor extends UnoDocumentTailor {
	private int i_targetSpreadSheetIndex;
	
	public UnoSpreadSheetsDocumentMoveSpecifiedSheetTo1stPositionTailor (UnoObjectsContext a_objectsContext, int a_targetSpreadSheetIndex) {
		super (a_objectsContext);
		i_targetSpreadSheetIndex = a_targetSpreadSheetIndex;
	}
	
	@Override
	public boolean tailor (XComponent a_unoDocumentInXComponent) {
		XSpreadsheetDocument l_spreadSheetsDocumentInXSpreadsheetDocument = (XSpreadsheetDocument) UnoRuntime.queryInterface (XSpreadsheetDocument.class, a_unoDocumentInXComponent);
		if (l_spreadSheetsDocumentInXSpreadsheetDocument == null) {
			Publisher.logErrorInformation ("The document is not any spread sheet.");
			return false;
		}
		else {
			XIndexAccess l_spreadSheetsInXIndexAccess = (XIndexAccess) UnoRuntime.queryInterface (XIndexAccess.class, l_spreadSheetsDocumentInXSpreadsheetDocument.getSheets ());
			try {
				XSpreadsheet l_spreadSheetInXSpreadsheet = (XSpreadsheet) (((Any) l_spreadSheetsInXIndexAccess.getByIndex (i_targetSpreadSheetIndex)).getObject ());
				XNamed l_spreadSheetInXNamed = (XNamed) UnoRuntime.queryInterface (XNamed.class, l_spreadSheetInXSpreadsheet);
				((XSpreadsheets) UnoRuntime.queryInterface (XSpreadsheets.class, l_spreadSheetsInXIndexAccess)).moveByName (l_spreadSheetInXNamed.getName (), (short) GeneralConstantsConstantsGroup.c_iterationStartingNumber);
				return true;
			}
			catch (Exception l_exception) {
				Publisher.logErrorInformation (l_exception);
				return false;
			}
		}
	}
}

