package theBiasPlanet.unoUtilities.documentsHandling;

import java.util.HashMap;
import java.util.HashSet;
import com.sun.star.beans.PropertyVetoException;
import com.sun.star.beans.UnknownPropertyException;
import com.sun.star.beans.XPropertySet;
import com.sun.star.container.NoSuchElementException;
import com.sun.star.container.XIndexAccess;
import com.sun.star.container.XNameContainer;
import com.sun.star.frame.XModel;
import com.sun.star.lang.IndexOutOfBoundsException;
import com.sun.star.lang.WrappedTargetException;
import com.sun.star.lang.XComponent;
import com.sun.star.style.XStyle;
import com.sun.star.style.XStyleFamiliesSupplier;
import com.sun.star.sheet.XSpreadsheetDocument;
import com.sun.star.sheet.XSpreadsheets2;
import com.sun.star.uno.AnyConverter;
import com.sun.star.uno.UnoRuntime;
import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.coreUtilities.messaging.Publisher;
import theBiasPlanet.unoUtilities.connectionsHandling.UnoObjectsContext;
import theBiasPlanet.unoUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.*;

public class UnoSpreadSheetsDocumentSetPageStylesTailor extends UnoDocumentTailor {
	private HashMap <String, Object> i_pageStylePropertyNameToPropertyValueMap = null;
	public UnoSpreadSheetsDocumentSetPageStylesTailor (UnoObjectsContext a_objectsContext, HashMap <String, Object> a_pageStylePropertyNameToPropertyValueMap) {
		super (a_objectsContext);
		i_pageStylePropertyNameToPropertyValueMap = a_pageStylePropertyNameToPropertyValueMap;
	}
	
	@Override
	public boolean tailor (XComponent a_unoDocumentInXComponent) {
		XSpreadsheetDocument l_unoSpreadSheetsDocumentInXSpreadsheetDocument = (XSpreadsheetDocument) UnoRuntime.queryInterface (XSpreadsheetDocument.class, a_unoDocumentInXComponent);
		if (l_unoSpreadSheetsDocumentInXSpreadsheetDocument == null) {
			Publisher.logErrorInformation ("The document is not any spread sheets document.");
			return false;
		}
		else {
			try {
				XModel l_unoSpreadSheetsDocumentInXModel = (XModel) UnoRuntime.queryInterface (XModel.class, l_unoSpreadSheetsDocumentInXSpreadsheetDocument);
				XStyleFamiliesSupplier l_unoSpreadSheetsDocumentInXStyleFamiliesSupplier = (XStyleFamiliesSupplier) UnoRuntime.queryInterface (XStyleFamiliesSupplier.class, l_unoSpreadSheetsDocumentInXSpreadsheetDocument);
				XNameContainer l_pageStylesInXNameContainer = (XNameContainer) AnyConverter.toObject (XNameContainer.class , l_unoSpreadSheetsDocumentInXStyleFamiliesSupplier.getStyleFamilies ().getByName (UnoStylesFamiliesConstantsGroup.c_pageStyles.c_name));
				String l_pageStyleName = null;
				HashSet <String> l_processedPageStyleNamesSet = new HashSet <String> ();
				XPropertySet l_pageStyleInXPropertySet = null;
				XSpreadsheets2 l_unoSpreadSheetsInXSpreadsheets2 = (XSpreadsheets2) UnoRuntime.queryInterface (XSpreadsheets2.class, l_unoSpreadSheetsDocumentInXSpreadsheetDocument.getSheets ());
				XIndexAccess l_unoSpreadSheetsInXIndexAccess = (XIndexAccess) UnoRuntime.queryInterface (XIndexAccess.class, l_unoSpreadSheetsInXSpreadsheets2);
				int l_numberOfSheets = l_unoSpreadSheetsInXIndexAccess.getCount ();
				XPropertySet l_unoSpreadSheetInXPropertySet = null;
				for (int l_sheetIndex = GeneralConstantsConstantsGroup.c_iterationStartingNumber; l_sheetIndex < l_numberOfSheets; l_sheetIndex ++) {
					l_unoSpreadSheetInXPropertySet = (XPropertySet) UnoRuntime.queryInterface (XPropertySet.class, l_unoSpreadSheetsInXIndexAccess.getByIndex (l_sheetIndex));
					l_pageStyleName = (String) l_unoSpreadSheetInXPropertySet.getPropertyValue (UnoSpreadSheetPropertyNamesSet.c_pageStyle);
					if (l_processedPageStyleNamesSet.contains (l_pageStyleName)) {
						continue;
					}
					else {
						l_pageStyleInXPropertySet = UnoRuntime.queryInterface (XPropertySet.class, AnyConverter.toObject (XStyle.class, l_pageStylesInXNameContainer.getByName (l_pageStyleName)));
						for (HashMap.Entry <String, Object> l_pageStylePropertyNameToPropertyValueMapEntry: i_pageStylePropertyNameToPropertyValueMap.entrySet ()) {
							l_pageStyleInXPropertySet.setPropertyValue (l_pageStylePropertyNameToPropertyValueMapEntry.getKey (), l_pageStylePropertyNameToPropertyValueMapEntry.getValue ());
						}
						l_processedPageStyleNamesSet.add (l_pageStyleName);
					}
				}
			}
			catch (NoSuchElementException | UnknownPropertyException | WrappedTargetException | PropertyVetoException | IndexOutOfBoundsException l_exception) {
				// Supposed not to happen.
			}
			return true;
		}
	}
}

