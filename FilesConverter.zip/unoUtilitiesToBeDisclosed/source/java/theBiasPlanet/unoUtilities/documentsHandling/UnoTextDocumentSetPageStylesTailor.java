package theBiasPlanet.unoUtilities.documentsHandling;

import java.util.HashMap;
import java.util.HashSet;
import com.sun.star.beans.PropertyVetoException;
import com.sun.star.beans.UnknownPropertyException;
import com.sun.star.beans.XPropertySet;
import com.sun.star.container.NoSuchElementException;
import com.sun.star.container.XNameContainer;
import com.sun.star.frame.XModel;
import com.sun.star.lang.WrappedTargetException;
import com.sun.star.lang.XComponent;
import com.sun.star.style.XStyle;
import com.sun.star.style.XStyleFamiliesSupplier;
import com.sun.star.text.XPageCursor;
import com.sun.star.text.XTextDocument;
import com.sun.star.text.XTextViewCursorSupplier;
import com.sun.star.uno.AnyConverter;
import com.sun.star.uno.UnoRuntime;
import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.coreUtilities.messaging.Publisher;
import theBiasPlanet.unoUtilities.connectionsHandling.UnoObjectsContext;
import theBiasPlanet.unoUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.*;

public class UnoTextDocumentSetPageStylesTailor extends UnoDocumentTailor {
	private HashMap <String, Object> i_pageStylePropertyNameToPropertyValueMap = null;
	
	public UnoTextDocumentSetPageStylesTailor (UnoObjectsContext a_objectsContext, HashMap <String, Object> a_pageStylePropertyNameToPropertyValueMap) {
		super (a_objectsContext);
		i_pageStylePropertyNameToPropertyValueMap = a_pageStylePropertyNameToPropertyValueMap;
	}
	
	@Override
	public boolean tailor (XComponent a_unoDocumentInXComponent) {
		XTextDocument l_unoTextDocumentInXTextDocument = (XTextDocument) UnoRuntime.queryInterface (XTextDocument.class, a_unoDocumentInXComponent);
		if (l_unoTextDocumentInXTextDocument == null) {
			Publisher.logErrorInformation ("The document is not any text document.");
			return false;
		}
		else {
			try {
				XModel l_unoTextDocumentInXModel = (XModel) UnoRuntime.queryInterface (XModel.class, l_unoTextDocumentInXTextDocument);
				XStyleFamiliesSupplier l_unoTextDocumentInXStyleFamiliesSupplier = (XStyleFamiliesSupplier) UnoRuntime.queryInterface (XStyleFamiliesSupplier.class, l_unoTextDocumentInXTextDocument);
				XNameContainer l_pageStylesInXNameContainer = (XNameContainer) AnyConverter.toObject (XNameContainer.class, l_unoTextDocumentInXStyleFamiliesSupplier.getStyleFamilies ().getByName (UnoStylesFamiliesConstantsGroup.c_pageStyles.c_name));
				XTextViewCursorSupplier l_controllerInXTextViewCursorSupplier = (XTextViewCursorSupplier) UnoRuntime.queryInterface (XTextViewCursorSupplier.class, l_unoTextDocumentInXModel.getCurrentController ());
				XPageCursor l_pageCursorInXPageCursor = (XPageCursor) UnoRuntime.queryInterface (XPageCursor.class, l_controllerInXTextViewCursorSupplier.getViewCursor ());
				XPropertySet l_pageCursorInXPropertySet = UnoRuntime.queryInterface (XPropertySet.class, l_pageCursorInXPageCursor);
				boolean l_pageIsValid = l_pageCursorInXPageCursor.jumpToPage ((short) (GeneralConstantsConstantsGroup.c_iterationStartingNumber + 1));
				String l_pageStyleName = null;
				HashSet <String> l_processedPageStyleNamesSet = new HashSet <String> ();
				XPropertySet l_pageStyleInXPropertySet = null;
				while (l_pageIsValid) {
					l_pageStyleName = (String) l_pageCursorInXPropertySet.getPropertyValue (UnoTextPageCursorPropertyNamesSet.c_pageStyleName_string);
					if (l_processedPageStyleNamesSet.contains (l_pageStyleName)) {
						continue;
					}
					else {
						l_pageStyleInXPropertySet = UnoRuntime.queryInterface (XPropertySet.class, AnyConverter.toObject (XStyle.class, l_pageStylesInXNameContainer.getByName (l_pageStyleName)));
						for (HashMap.Entry <String, Object> l_pageStylePropertyNameToPropertyValueMapEntry: i_pageStylePropertyNameToPropertyValueMap.entrySet ()) {
							l_pageStyleInXPropertySet.setPropertyValue (l_pageStylePropertyNameToPropertyValueMapEntry.getKey (), l_pageStylePropertyNameToPropertyValueMapEntry.getValue ());
						}
						l_processedPageStyleNamesSet.add (l_pageStyleName);
					}
					l_pageIsValid =  l_pageCursorInXPageCursor.jumpToNextPage ();
				}
			}
			catch (NoSuchElementException | UnknownPropertyException | WrappedTargetException | PropertyVetoException l_exception) {
				// Supposed not to happen.
			}
			return true;
		}
	}
}

