package theBiasPlanet.unoUtilities.unoDataHandling;

import java.lang.reflect.Array;
import com.sun.star.beans.PropertyValue;
import com.sun.star.frame.status.ClipboardFormats;
import com.sun.star.uno.Any;
import theBiasPlanet.coreUtilities.constantsGroups.*;

public class UnoDatumConverter {
	public static Object getObject (Object a_originalObject) {
		if (a_originalObject == null) {
			return null;
		}
		else {
			if (a_originalObject instanceof Any) {
				return ( (Any) a_originalObject).getObject ();
			}
			else {
				return a_originalObject;
			}
		}
	}
	
	public static String toString (Object a_originalObject) {
		if (a_originalObject == null) {
			return null;
		}
		else {
			Class l_class = a_originalObject.getClass ();
			String l_className = l_class.toString ();
			StringBuilder l_stringBuffer = new StringBuilder ();
			l_stringBuffer.append (l_className);
			l_stringBuffer.append (": ");
			if (l_class.isArray ()) {
				l_stringBuffer.append ("[");
				int l_numberOfElements = Array.getLength (a_originalObject);
				Object l_element = null;
				for (int l_elementIndex = GeneralConstantsConstantsGroup.c_iterationStartingNumber; l_elementIndex < l_numberOfElements ; l_elementIndex ++) {
					if (l_elementIndex == GeneralConstantsConstantsGroup.c_iterationStartingNumber) {
					}	
					else {
						l_stringBuffer.append (", ");
					}
					l_element = Array.get (a_originalObject, l_elementIndex);
					l_stringBuffer.append (toString (l_element));
				}
				l_stringBuffer.append ("]");
			}
			else {
				if (l_className.equals ("class com.sun.star.frame.status.ClipboardFormats")) {
					long [] l_formatIdentifications = ((ClipboardFormats) a_originalObject).Identifiers;
					String [] l_formatNames = ((ClipboardFormats) a_originalObject).Names;
					int l_formatIndex = GeneralConstantsConstantsGroup.c_iterationStartingNumber;
					for (long l_formatIdentification: l_formatIdentifications) {
						if (l_formatIndex == GeneralConstantsConstantsGroup.c_iterationStartingNumber) {
						}	
						else {
							l_stringBuffer.append (", ");
						}
						l_stringBuffer.append (String.format ("%d, \"%s\"", l_formatIdentification, l_formatNames [l_formatIndex]));
						l_formatIndex ++;
					}
				}
				if (l_className.equals ("class com.sun.star.beans.PropertyValue")) {
					PropertyValue l_propertyValue = (PropertyValue) a_originalObject;
					l_stringBuffer.append ("Name -> ");
					l_stringBuffer.append (l_propertyValue.Name);
					l_stringBuffer.append (", Value -> ");
					l_stringBuffer.append (UnoDatumConverter.toString (l_propertyValue.Value));
				}
				else {
					l_stringBuffer.append (a_originalObject.toString ());
				}
			}
			return l_stringBuffer.toString ();
		}
	}
}

