package theBiasPlanet.unoUtilities.cryptography;

import theBiasPlanet.coreUtilities.constantsGroups.*;

public class MicrosoftPasswordsHasher {
	private static final short [] c_initializationCodes = new short [] {(short) 0xE1F0, (short) 0x1D0F, (short) 0xCC9C, (short) 0x84C0, (short) 0x110C, (short) 0x0E10, (short) 0xF1CE, (short) 0x313E, (short) 0x1872, (short) 0xE139, (short) 0xD40F, (short) 0x84F9, (short) 0x280C, (short) 0xA96A, (short) 0x4EC3};
	private static final short [] [] c_encryptionMatrix = new short [] [] {
		{ (short) 0xAEFC, (short) 0x4DD9, (short) 0x9BB2, (short) 0x2745, (short) 0x4E8A, (short) 0x9D14, (short) 0x2A09},
		{ (short) 0x7B61, (short) 0xF6C2, (short) 0xFDA5, (short) 0xEB6B, (short) 0xC6F7, (short) 0x9DCF, (short) 0x2BBF},
		{ (short) 0x4563, (short) 0x8AC6, (short) 0x05AD, (short) 0x0B5A, (short) 0x16B4, (short) 0x2D68, (short) 0x5AD0},
		{ (short) 0x0375, (short) 0x06EA, (short) 0x0DD4, (short) 0x1BA8, (short) 0x3750, (short) 0x6EA0, (short) 0xDD40},
		{ (short) 0xD849, (short) 0xA0B3, (short) 0x5147, (short) 0xA28E, (short) 0x553D, (short) 0xAA7A, (short) 0x44D5},
		{ (short) 0x6F45, (short) 0xDE8A, (short) 0xAD35, (short) 0x4A4B, (short) 0x9496, (short) 0x390D, (short) 0x721A},
		{ (short) 0xEB23, (short) 0xC667, (short) 0x9CEF, (short) 0x29FF, (short) 0x53FE, (short) 0xA7FC, (short) 0x5FD9},
		{ (short) 0x47D3, (short) 0x8FA6, (short) 0x8FA6, (short) 0x1EDA, (short) 0x3DB4, (short) 0x7B68, (short) 0xF6D0},
		{ (short) 0xB861, (short) 0x60E3, (short) 0xC1C6, (short) 0x93AD, (short) 0x377B, (short) 0x6EF6, (short) 0xDDEC},
		{ (short) 0x45A0, (short) 0x8B40, (short) 0x06A1, (short) 0x0D42, (short) 0x1A84, (short) 0x3508, (short) 0x6A10},
		{ (short) 0xAA51, (short) 0x4483, (short) 0x8906, (short) 0x022D, (short) 0x045A, (short) 0x08B4, (short) 0x1168},
		{ (short) 0x76B4, (short) 0xED68, (short) 0xCAF1, (short) 0x85C3, (short) 0x1BA7, (short) 0x374E, (short) 0x6E9C},
		{ (short) 0x3730, (short) 0x6E60, (short) 0xDCC0, (short) 0xA9A1, (short) 0x4363, (short) 0x86C6, (short) 0x1DAD},
		{ (short) 0x3331, (short) 0x6662, (short) 0xCCC4, (short) 0x89A9, (short) 0x0373, (short) 0x06E6, (short) 0x0DCC},
		{ (short) 0x1021, (short) 0x2042, (short) 0x4084, (short) 0x8108, (short) 0x1231, (short) 0x2462, (short) 0x48C4}
	};
	
	public static int hashIn32bits (String a_originalDatum) {
		int l_hash = 0;
		int l_originalDatumLength = a_originalDatum.length ();
		if (l_originalDatumLength > 0) {
			if (l_originalDatumLength > 15) {
		   		l_originalDatumLength = 15;
			}
			int l_highHash = c_initializationCodes [l_originalDatumLength - 1];
			int l_lowHash = 0;
			char l_character = 0x0000;
			byte l_byte = 0x00;
			byte l_highByte = 0x00;
			byte l_lowByte = 0x00;
			for (int l_characterIndex = GeneralConstantsConstantsGroup.c_iterationStartingNumber; l_characterIndex < l_originalDatumLength; l_characterIndex ++) {
				l_character = a_originalDatum.charAt (l_characterIndex);
				l_highByte = (byte) (l_character >>> 8);
				l_lowByte = (byte) (l_character & 0xFF);
				l_byte = l_lowByte != 0x00 ? l_lowByte : l_highByte;
				for (int l_matrixcolumnIndex = GeneralConstantsConstantsGroup.c_iterationStartingNumber; l_matrixcolumnIndex < 7; l_matrixcolumnIndex ++) {
					if ((l_byte & (1 << l_matrixcolumnIndex)) != 0) {
						l_highHash = (short) (l_highHash ^ c_encryptionMatrix [15 - l_originalDatumLength + l_characterIndex] [l_matrixcolumnIndex]);
					}
				}
				l_character = a_originalDatum.charAt (l_originalDatumLength -1 - l_characterIndex);
				l_highByte = (byte) (l_character >>> 8);
				l_lowByte = (byte) (l_character & 0xFF);
				l_byte = l_lowByte != 0x00 ? l_lowByte : l_highByte;
				l_lowHash = ( ( (l_lowHash >>> 14) & 0x0001 ) | ( (l_lowHash << 1) & 0x7FFF)) ^ l_byte;
			}
			l_lowHash =  ( ( (l_lowHash >>> 14) & 0x0001) | ( (l_lowHash << 1) & 0x7FFF)) ^ l_originalDatumLength ^ 0xCE4B;
			l_hash = (l_highHash << 16) | l_lowHash;
		}
		return l_hash;
	}
	
	public static short hashIn16bits (String a_originalDatum) {
		int l_hash = 0;
		byte [] l_originalDatumUtf8BytesArray = null;
		try {
			l_originalDatumUtf8BytesArray = a_originalDatum.getBytes (EncodingNamesConstantsGroup.c_utf8EncodingName);
		}
		catch (Exception l_exception) {
			// Is supposed to never happen.
		}
		int l_originalDatumUtf8BytesArrayLength = l_originalDatumUtf8BytesArray.length;
		if (l_originalDatumUtf8BytesArrayLength <= Short.MAX_VALUE) {
			for (int l_byteIndex = l_originalDatumUtf8BytesArrayLength - 1; l_byteIndex >= GeneralConstantsConstantsGroup.c_iterationStartingNumber; l_byteIndex --) {
				l_hash = ( (l_hash >>> 14) & 0x01) | ( (l_hash << 1) & 0x7FFF);
				l_hash ^= l_originalDatumUtf8BytesArray [l_byteIndex];
			}
			l_hash = ( (l_hash >>> 14) & 0x01) | ( (l_hash << 1) & 0x7FFF);
			l_hash ^= (0x8000 | ('N' << 8) | 'K');
			l_hash ^= l_originalDatumUtf8BytesArrayLength;
		}
		return (short) l_hash;
	}
}

