package theBiasPlanet.unoUtilities.dispatchingHandling;

import java.util.ArrayList;
import java.util.List;
import com.sun.star.frame.DispatchResultEvent;
import com.sun.star.frame.DispatchResultState;
import com.sun.star.frame.FeatureStateEvent;
import theBiasPlanet.coreUtilities.stringsHandling.StringHandler;

public class UnoDispatchResultAndRelatedInformation {
	private short i_finalStatus;
	private Object i_result;
	private List <Object> i_relatedInformation;
	
	public UnoDispatchResultAndRelatedInformation () {
		i_finalStatus = DispatchResultState.FAILURE;
		i_result = null;
		i_relatedInformation = new ArrayList <Object> ();
	}
	
	public Object getResult () {
		return i_result;
	}
	
	public void setResult (DispatchResultEvent a_resultEvent) {
		if (a_resultEvent != null) {
			i_finalStatus = a_resultEvent.State;
			i_result = a_resultEvent.Result;
		}
		else {
			i_result = null;
		}
	}
	
	public List <Object> getRelatedInformation () {
		return i_relatedInformation;
	}
	
	public void addRelatedInformationPiece (FeatureStateEvent a_relatedInformationPieceEvent) {
		if (a_relatedInformationPieceEvent != null) {
			if (a_relatedInformationPieceEvent.State != null) {
				i_relatedInformation.add (a_relatedInformationPieceEvent.State);
			}
			else {
				i_relatedInformation.add (null);
			}
		}
		else {
			i_relatedInformation.add (null);
		}
	}
	
	public String toString () {
		StringBuilder l_stringBuilder = new StringBuilder ();
		l_stringBuilder.append ("State = ");
		l_stringBuilder.append (String.format ("%d", i_finalStatus));
		l_stringBuilder.append (", Result = ");
		if (i_result != null) {
			l_stringBuilder.append (StringHandler.getString (i_result));
		}
		else {
			l_stringBuilder.append ("null");
		}
		l_stringBuilder.append (", Related information = ");
		boolean l_isInFirstIterationOfRelatedInformationPieces = true;
		for (Object l_relatedInformationPiece: i_relatedInformation) {
			if (!l_isInFirstIterationOfRelatedInformationPieces) {
				l_stringBuilder.append (", ");
			}
			else {
				l_isInFirstIterationOfRelatedInformationPieces = false;
			}
			l_stringBuilder.append (StringHandler.getString (l_relatedInformationPiece));
		}
		return l_stringBuilder.toString ();
	}
}

