package theBiasPlanet.unoUtilities.nameValuePairsHandling;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import com.sun.star.beans.NamedValue;
import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.nameValuePair.UnoNameValuePair;

public class UnoNameValuePairsHandler {
	public static NamedValue [] buildNameValuePairsArray (List <String> a_names, List <Object> a_values) {
		if (a_names == null || a_values == null) {
			return null;
		}
		else {
			ArrayList <String> l_names = new ArrayList <String> ();
			ArrayList <Object> l_values = new ArrayList <Object> ();
			Iterator <Object> l_valuesIterator = a_values.iterator ();
			Object l_value = null;
			for (String l_name: a_names) {
				l_value = l_valuesIterator.next ();
				if (l_value != null) {
					l_names.add (l_name);
					l_values.add (l_value);
				}
			}
			NamedValue [] l_nameValuePairsArray = new NamedValue [a_names.size ()];
			l_valuesIterator = l_values.iterator ();
			int l_nameValuePairIndex = GeneralConstantsConstantsGroup.c_iterationStartingNumber;
			for (String l_name: l_names) {
				l_nameValuePairsArray [l_nameValuePairIndex] = new UnoNameValuePair (l_name, l_values.get (l_nameValuePairIndex));
				l_nameValuePairIndex ++;
			}
			return l_nameValuePairsArray;
		}
	}
}

