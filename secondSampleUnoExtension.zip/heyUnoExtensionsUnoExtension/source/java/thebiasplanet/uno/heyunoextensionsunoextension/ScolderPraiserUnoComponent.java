// # Change the package name
package thebiasplanet.uno.heyunoextensionsunoextension;

import java.util.Set;
import java.util.HashSet;
import java.util.Map;
import com.sun.star.lib.uno.helper.WeakBase;
import com.sun.star.lang.XServiceInfo;
import com.sun.star.lang.XInitialization;
import com.sun.star.uno.XComponentContext;
// # Add necessary classes and interfaces START
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import com.sun.star.lang.IllegalArgumentException;
import thebiasplanet.coreutilities.messaging.Publisher;
// # Add necessary classes and interfaces END

// # Change the class name
public class ScolderPraiserUnoComponent
		extends WeakBase
		implements XServiceInfo, XInitialization,
		// # Specify the UNO interface to implement
		XScolder, XPraiser {
	private static final Set <String> SERVICE_NAMES_SET = new HashSet <String> ();
	private static final Class thisClass = new Object () { }.getClass ().getEnclosingClass ();
	static {
		// # Add service names START
		SERVICE_NAMES_SET.add ("thebiasplanet.uno.heyunoextensionsunoextension.ScolderPraiserService");
		// # Add service names END
	}
	static final String [] SERVICE_NAMES_ARRAY = SERVICE_NAMES_SET.toArray (new String [SERVICE_NAMES_SET.size ()]);
	private XComponentContext componentContext = null;
	// # Add member variables START
	private String message = null;
	// # Add member variables END
	
	static void setThisClassToServicesProvider (Map <String, Object []> p_unoComponentClassNameToUnoComponentClassAndServiceNamesArrayMap) {
		p_unoComponentClassNameToUnoComponentClassAndServiceNamesArrayMap.put (thisClass.getName (), new Object [] {thisClass, SERVICE_NAMES_ARRAY});
	}
	
	// # Change the class name
	public ScolderPraiserUnoComponent (XComponentContext p_componentContext)
			throws IllegalArgumentException {
		componentContext = p_componentContext;
	}
	
	public final void initialize (java.lang.Object [] p_arguments)
			throws com.sun.star.uno.Exception {
		// # Write the initialization START
		if (p_arguments != null && p_arguments.length == 1) {
			if (p_arguments[0] instanceof String) {
				message = String.format ("%s (%d %s)", (String) p_arguments[0], System.identityHashCode (this), DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss").format (LocalDateTime.now()));
				if (message == null) {
					throw new IllegalArgumentException ("The first argument can't be null.");
				}
			}
			else {
				throw new IllegalArgumentException("The first argument must be a String instance.");
			}
		}
		else {
			throw new IllegalArgumentException("The number of arguments must be 1.");
		}
		// # Write the initialization END
	}
	
	// # Add methods of the implemented UNO interface START
	public String scold (String p_name)
			throws IllegalArgumentException {
		if (p_name == null) {
			throw new IllegalArgumentException ("The first argument can't be null.");
		}
		return String.format ("Don't do that! %s, %s!", message, p_name);
	}
	
	public String praise (String p_name)
			throws IllegalArgumentException {
		if (p_name == null) {
			throw new IllegalArgumentException ("The first argument can't be null.");
		}
		return Publisher.getMessage (String.format ("Wonderful! %s, %s!", message, p_name));
	}
	// # Add methods of the implemented UNO interface END
	
	// # Add other member methods START
	// # Add other member methods END
	
	public String getImplementationName () {
		return thisClass.getName ();
	}
	
	public final boolean supportsService (String p_serviceName) {
		return SERVICE_NAMES_SET.contains (p_serviceName);
	}
	
	public final String [] getSupportedServiceNames () {
		return SERVICE_NAMES_ARRAY;
	}
}
