// # Change the package name
package thebiasplanet.uno.heyunoextensionsunoextension;

import java.util.Set;
import java.util.HashSet;
import java.util.Map;
import java.util.HashMap;
import com.sun.star.lib.uno.helper.WeakBase;
import com.sun.star.lang.XServiceInfo;
import com.sun.star.lang.XInitialization;
import com.sun.star.uno.XComponentContext;
// # Add necessary classes and interfaces START
import com.sun.star.lang.IllegalArgumentException;
import thebiasplanet.unoutilities.connectionshandling.UnoComponentContext;
// # Add necessary classes and interfaces END

// # Change the class name
public class HeyUnoExtensionsUnoComponent
		extends WeakBase
		implements XServiceInfo, XInitialization,
		// # Specify the UNO interface to implement
		XHeyUnoExtensions {
	private static final Set <String> SERVICE_NAMES_SET = new HashSet <String> ();
	private static final Class thisClass = new Object () { }.getClass ().getEnclosingClass ();
	static {
		// # Add service names START
		SERVICE_NAMES_SET.add ("thebiasplanet.uno.heyunoextensionsunoextension.HeyUnoExtensionsService");
		// # Add service names END
	}
	static final String [] SERVICE_NAMES_ARRAY = SERVICE_NAMES_SET.toArray (new String [SERVICE_NAMES_SET.size ()]);
	private XComponentContext componentContext = null;
	// # Add member variables START
	private String message = null;
	private Map <String, Object> componentContextExtraNameValueMap = null;
	// # Add member variables END
	
	static void setThisClassToServicesProvider (Map <String, Object []> p_unoComponentClassNameToUnoComponentClassAndServiceNamesArrayMap) {
		p_unoComponentClassNameToUnoComponentClassAndServiceNamesArrayMap.put (thisClass.getName (), new Object [] {thisClass, SERVICE_NAMES_ARRAY});
	}
	
	// # Change the class name
	public HeyUnoExtensionsUnoComponent (XComponentContext p_componentContext)
			throws IllegalArgumentException {
		componentContextExtraNameValueMap = new HashMap <String, Object> ();
		try {
			componentContext = new UnoComponentContext (p_componentContext, componentContextExtraNameValueMap);
		}
		catch (com.sun.star.uno.Exception l_exception) {
		}
		componentContextExtraNameValueMap.put ("/singletons/thebiasplanet.uno.heyunoextensionsunoextension.ScolderPraiserServiceSingleton", ScolderPraiserService.create1 (componentContext, "Well"));
	}
	
	public final void initialize (java.lang.Object [] p_arguments)
			throws com.sun.star.uno.Exception {
		// # Write the initialization START
		if (p_arguments != null && p_arguments.length == 1) {
			if (p_arguments[0] instanceof String) {
				message = (String) p_arguments[0];
				if (message == null) {
					throw new IllegalArgumentException ("The first argument can't be null.");
				}
			}
			else {
				throw new IllegalArgumentException("The first argument must be a String instance.");
			}
		}
		else {
			throw new IllegalArgumentException("The number of arguments must be 1.");
		}
		// # Write the initialization END
	}
	
	// # Add methods of the implemented UNO interface START
	public String sayHey (String p_name)
			throws IllegalArgumentException {
		if (p_name == null) {
			throw new IllegalArgumentException ("The first argument can't be null.");
		}
		return String.format ("%s, %s!", message, p_name);
	}
	
	public XRanter getInnerRanter (String p_message)
			throws IllegalArgumentException {
		RanterUnoComponent l_innerRanter = new RanterUnoComponent (componentContext);
		try {
			l_innerRanter.initialize (new String [] {p_message});
		}
		catch (IllegalArgumentException l_exception) {
			throw l_exception;
		}
		catch (com.sun.star.uno.Exception l_exception) {
		}
		return l_innerRanter;
		
	}
	
	public XPraiser getInnerPraiser (String p_message)
			throws IllegalArgumentException {
		XScolder l_innerScolderPraiser1 = null;
		XPraiser l_innerScolderPraiser2 = null;
		try {
			l_innerScolderPraiser1 = ScolderPraiserService.create1 (componentContext, p_message);
			l_innerScolderPraiser2 = (XPraiser) l_innerScolderPraiser1;
		}
		catch (IllegalArgumentException l_exception) {
			throw l_exception;
		}
		return l_innerScolderPraiser2;
	}
	
	public XPraiser getSingletonInnerPraiser ()
			throws IllegalArgumentException {
		XScolder l_singletonInnerScolderPraiser1 = null;
		XPraiser l_singletonInnerScolderPraiser2 = null;
		try {
			l_singletonInnerScolderPraiser1 = ScolderPraiserServiceSingleton.get (componentContext);
			l_singletonInnerScolderPraiser2 = (XPraiser) l_singletonInnerScolderPraiser1;
		}
		catch (IllegalArgumentException l_exception) {
			throw l_exception;
		}
		return l_singletonInnerScolderPraiser2;
	}
	
	public XComponentContext getComponentContext (){
		return componentContext;
	}
	// # Add methods of the implemented UNO interface END
	
	// # Add other member methods START
	// # Add other member methods END
	
	public String getImplementationName () {
		return thisClass.getName ();
	}
	
	public final boolean supportsService (String p_serviceName) {
		return SERVICE_NAMES_SET.contains (p_serviceName);
	}
	
	public final String [] getSupportedServiceNames () {
		return SERVICE_NAMES_ARRAY;
	}
}
