// # Change the package name
package thebiasplanet.uno.heyunoextensionsunoextension;

import java.util.Set;
import java.util.HashSet;
import java.util.Map;
import com.sun.star.lib.uno.helper.WeakBase;
import com.sun.star.lang.XInitialization;
import com.sun.star.uno.XComponentContext;
// # Add necessary classes and interfaces START
import com.sun.star.lang.IllegalArgumentException;
// # Add necessary classes and interfaces END

// # Change the class name
public class RanterUnoComponent
		extends WeakBase
		implements XInitialization,
		// # Specify the UNO interface to implement
		XRanter {
	private static final Class thisClass = new Object () { }.getClass ().getEnclosingClass ();
	private XComponentContext componentContext = null;
	// # Add member variables START
	private String message = null;
	// # Add member variables END
	
	// # Change the class name
	public RanterUnoComponent (XComponentContext p_componentContext)
			throws IllegalArgumentException {
		componentContext = p_componentContext;
	}
	
	public final void initialize (java.lang.Object [] p_arguments)
			throws com.sun.star.uno.Exception {
		// # Write the initialization START
		if (p_arguments != null && p_arguments.length == 1) {
			if (p_arguments[0] instanceof String) {
				message = (String) p_arguments[0];
				if (message == null) {
					throw new IllegalArgumentException ("The first argument can't be null.");
				}
			}
			else {
				throw new IllegalArgumentException("The first argument must be a String instance.");
			}
		}
		else {
			throw new IllegalArgumentException("The number of arguments must be 1.");
		}
		// # Write the initialization END
	}
	
	// # Add methods of the implemented UNO interface START
	public String rant (String p_name)
			throws IllegalArgumentException {
		if (p_name == null) {
			throw new IllegalArgumentException ("The first argument can't be null.");
		}
		return String.format ("%s? No way! Go to hell, %s!", message, p_name);
	}
	// # Add methods of the implemented UNO interface END
	
	// # Add other member methods START
	// # Add other member methods END
}
