package thebiasplanet.unoutilities.connectionshandling;

import java.util.Map;
import com.sun.star.uno.XComponentContext;
import com.sun.star.lang.XMultiComponentFactory;

public class UnoComponentContext implements XComponentContext {
	private XComponentContext originalComponentContext = null;
	private Map <String, Object> extraNameValueMap = null;
	
	public UnoComponentContext (XComponentContext p_originalComponentContext, Map <String, Object> p_extraNameValueMap) throws com.sun.star.uno.Exception {
		if (p_originalComponentContext == null) {
			throw new com.sun.star.uno.Exception ("Original component context is required.");
		}
		originalComponentContext = p_originalComponentContext;
		extraNameValueMap = p_extraNameValueMap;
	}
	
	@Override
	public final Object getValueByName (String p_name) {
		if (extraNameValueMap != null && extraNameValueMap.containsKey (p_name)) {
			return extraNameValueMap.get (p_name);
		}
		return originalComponentContext.getValueByName (p_name);
	}
	
	@Override
	public final XMultiComponentFactory getServiceManager () {
		return originalComponentContext.getServiceManager ();
	}
	
	public final boolean isFromTheSameOrigin (UnoComponentContext p_unoComponentContext) {
		if ((p_unoComponentContext ==  null) || (extraNameValueMap.get ("identification") == null)) {
			return false;
		}
		if (extraNameValueMap.get ("identification").equals (p_unoComponentContext.getValueByName ("identification"))) {
			return true;
		}
		else {
			return false;
		}
	}
}
