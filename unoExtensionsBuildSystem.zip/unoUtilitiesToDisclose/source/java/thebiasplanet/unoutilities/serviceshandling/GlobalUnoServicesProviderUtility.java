package thebiasplanet.unoutilities.serviceshandling;

import java.util.Map;
import com.sun.star.lang.XSingleComponentFactory;
import com.sun.star.registry.XRegistryKey;
import com.sun.star.lib.uno.helper.Factory;

public class GlobalUnoServicesProviderUtility {
	public static XSingleComponentFactory getSingleComponentFactory (Map <String, Object []> p_implementationClassNameToImplementationClassAndServiceNamesArrayMap, String p_implementationName) {
		XSingleComponentFactory l_singleComponentFactory = null;
		Object [] l_implementationClassAndServiceNamesArray = p_implementationClassNameToImplementationClassAndServiceNamesArrayMap.get (p_implementationName);
		if (l_implementationClassAndServiceNamesArray != null) {
			@SuppressWarnings ("unchecked")
			String [] l_serviceNamesArray = (String []) l_implementationClassAndServiceNamesArray [1];
			l_singleComponentFactory = Factory.createComponentFactory ((Class) l_implementationClassAndServiceNamesArray [0], l_serviceNamesArray);
		}
		return l_singleComponentFactory;
	}
	
	public static boolean writeServicesInformationToRegistry (Map <String, Object []> p_implementationClassNameToImplementationClassAndServiceNamesArrayMap, XRegistryKey p_registryKey) {
		boolean l_returnStatus = false;
		for (Map.Entry <String, Object []> l_implementationClassNameToInplemetationClassAndServiceNamesArrayMapEntry: p_implementationClassNameToImplementationClassAndServiceNamesArrayMap.entrySet ()) {
			@SuppressWarnings("unchecked")
			String [] l_serviceNamesArray = (String []) l_implementationClassNameToInplemetationClassAndServiceNamesArrayMapEntry.getValue () [1];
			l_returnStatus = Factory.writeRegistryServiceInfo (l_implementationClassNameToInplemetationClassAndServiceNamesArrayMapEntry.getKey (), l_serviceNamesArray, p_registryKey);
			if (!l_returnStatus) {
				break;
			}
		}
		return l_returnStatus;
	}
}
