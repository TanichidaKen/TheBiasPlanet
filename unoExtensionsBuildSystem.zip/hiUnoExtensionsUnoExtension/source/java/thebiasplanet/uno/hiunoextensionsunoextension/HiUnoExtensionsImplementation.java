// # Change the package name
package thebiasplanet.uno.hiunoextensionsunoextension;

import java.util.Set;
import java.util.HashSet;
import java.util.Map;
import com.sun.star.lib.uno.helper.WeakBase;
import com.sun.star.lang.XServiceInfo;
import com.sun.star.lang.XInitialization;
import com.sun.star.uno.XComponentContext;
// # Add necessary classes and interfaces START
import com.sun.star.lang.IllegalArgumentException;
// # Add necessary classes and interfaces END

// # Change the class name
public class HiUnoExtensionsImplementation
		extends WeakBase
		implements XServiceInfo, XInitialization,
		// # Specify the UNO interface to implement
		XHiUnoExtensions {
	private static final Set <String> SERVICE_NAMES_SET = new HashSet <String> ();
	private static final Class thisClass = new Object () { }.getClass ().getEnclosingClass ();
	static {
		// # Add service names START
		SERVICE_NAMES_SET.add ("thebiasplanet.uno.hiunoextensionsunoextension.HiUnoExtensions");
		// # Add service names END
	}
	static final String [] SERVICE_NAMES_ARRAY = SERVICE_NAMES_SET.toArray (new String [SERVICE_NAMES_SET.size ()]);
	private XComponentContext componentContext = null;
	// # Add member variables START
	private String message = null;
	// # Add member variables END
	
	static void setThisClassToServicesProvider (Map <String, Object []> p_implementationClassNameToImplementationClassAndServiceNamesArrayMap) {
		p_implementationClassNameToImplementationClassAndServiceNamesArrayMap.put (thisClass.getName (), new Object [] {thisClass, SERVICE_NAMES_ARRAY});
	}
	
	// # Change the class name
	public HiUnoExtensionsImplementation (XComponentContext p_componentContext)
			throws IllegalArgumentException {
		componentContext = p_componentContext;
	}
	
	public final void initialize (java.lang.Object [] p_arguments)
			throws com.sun.star.uno.Exception {
		// # Write the initialization START
		if (p_arguments != null && p_arguments.length == 1) {
			if (p_arguments[0] instanceof String) {
				message = (String) p_arguments[0];
				if (message == null) {
					throw new IllegalArgumentException ("The first argument can't be null.");
				}
			}
			else {
				throw new IllegalArgumentException("The first argument must be a String instance.");
			}
		}
		else {
			throw new IllegalArgumentException("The number of arguments must be 1.");
		}
		// # Write the initialization END
	}
	
	// # Add methods of the implemented UNO interface START
	public String sayHi (String p_name)
			throws IllegalArgumentException {
		if (p_name == null) {
			throw new IllegalArgumentException ("The first argument can't be null.");
		}
		return String.format ("%s, %s!", message, p_name);
	}
	// # Add methods of the implemented UNO interface END
	
	// # Add other member methods START
	// # Add other member methods END
	
	public String getImplementationName () {
		return thisClass.getName ();
	}
	
	public final boolean supportsService (String p_serviceName) {
		return SERVICE_NAMES_SET.contains (p_serviceName);
	}
	
	public final String [] getSupportedServiceNames () {
		return SERVICE_NAMES_ARRAY;
	}
}
