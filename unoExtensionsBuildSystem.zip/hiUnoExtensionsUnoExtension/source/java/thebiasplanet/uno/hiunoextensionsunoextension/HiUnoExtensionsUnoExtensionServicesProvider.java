// # Change the package name
package thebiasplanet.uno.hiunoextensionsunoextension;

import java.util.Map;
import java.util.HashMap;
import com.sun.star.lang.XSingleComponentFactory;
import com.sun.star.registry.XRegistryKey;
import thebiasplanet.unoutilities.serviceshandling.UnoServicesProviderUtility;

// # Change the class name
public class HiUnoExtensionsUnoExtensionServicesProvider {
	private static final Map <String, Object []> IMPLEMENTATION_CLASS_NAME_TO_IMPLEMENTATION_CLASS_AND_SERVICE_NAMES_ARRAY_MAP = new HashMap <String, Object []> ();
	static {
		// # Add implementation classes START
		HiUnoExtensionsImplementation.setThisClassToServicesProvider (IMPLEMENTATION_CLASS_NAME_TO_IMPLEMENTATION_CLASS_AND_SERVICE_NAMES_ARRAY_MAP);
		// # Add implementation classes END
	}
	
	public static XSingleComponentFactory __getComponentFactory (String p_implementationName) {
		return UnoServicesProviderUtility.getSingleComponentFactory (IMPLEMENTATION_CLASS_NAME_TO_IMPLEMENTATION_CLASS_AND_SERVICE_NAMES_ARRAY_MAP, p_implementationName);
	}
	
	public static boolean __writeRegistryServiceInfo (XRegistryKey p_registryKey) {
		return UnoServicesProviderUtility.writeServicesInformationToRegistry (IMPLEMENTATION_CLASS_NAME_TO_IMPLEMENTATION_CLASS_AND_SERVICE_NAMES_ARRAY_MAP, p_registryKey);
	}
}
