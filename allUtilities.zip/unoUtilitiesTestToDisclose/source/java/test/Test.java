package test;

final class Test {
	private Test () {
	}
	
	public static void main (String [] a_arguments) throws Exception {
		test.unobatchclienttest1.Test1Test.test (a_arguments [0], a_arguments [1]);
	}
}
