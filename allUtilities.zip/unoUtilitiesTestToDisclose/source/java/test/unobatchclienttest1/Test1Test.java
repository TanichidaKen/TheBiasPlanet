package test.unobatchclienttest1;

import java.time.LocalDateTime;
import java.math.BigDecimal;
import com.sun.star.uno.XComponentContext;
import thebiasplanet.unoutilities.programshandling.UnoEnvironment;
import thebiasplanet.unoutilities.connectionshandling.UnoConnectionConnector;
import thebiasplanet.unoutilities.connectionshandling.UnoConnection;
import thebiasplanet.unoutilities.spreadsheetshandling.UnoSpreadSheetsDocument;
import thebiasplanet.unoutilities.spreadsheetshandling.UnoSpreadSheet;

final public class Test1Test {
	public static void test (String a_serverUrl, String a_spreadSheetsDocumentFileUrl) {
		UnoEnvironment l_unoEnvironment = null;
		UnoConnection l_unoConnection = null;
		try {
			l_unoEnvironment = new UnoEnvironment (null, LocalDateTime.now ().toString (), null);
			UnoConnectionConnector l_unoConnectionConnector = new UnoConnectionConnector (l_unoEnvironment.getLocalComponentContext ());
			l_unoConnection = l_unoConnectionConnector.connect (a_serverUrl, null);
			XComponentContext l_remoteComponentContextInXComponentContext = l_unoConnection.getRemoteComponentContextInXComponentContext ();
			UnoSpreadSheetsDocument l_spreadSheetsDocument = UnoSpreadSheetsDocument.openSpreadSheetsDocumentFile (l_remoteComponentContextInXComponentContext, a_spreadSheetsDocumentFileUrl, true);
			try {
				UnoSpreadSheet l_spreadSheet = l_spreadSheetsDocument.getSpreadSheet ("Sheet1");
				Object l_cellValue = l_spreadSheet.getSpreadSheetCell (0, 0).getValue ();
				System.out.println (String.format ("The cell value at the 0, 0 cell is %s.", l_cellValue.toString ()));
				l_spreadSheet.getSpreadSheetCell (1, 0).setValue (new BigDecimal ("12.340"));
				l_spreadSheetsDocument.store ();
			}
			catch (Exception l_exception) {
				System.out.println (l_exception.toString ());
			}
			finally {
				l_spreadSheetsDocument.close ();
			}
		}
		catch (Exception l_exception) {
			System.out.println (l_exception.toString ());
		}
		finally {
			if (l_unoConnection != null) {
				l_unoConnection.disconnect ();
			}
		}
	}
}
