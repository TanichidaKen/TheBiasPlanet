package thebiasplanet.unoutilities.constantsgroups;

// Interface because this is not enumerable
public interface UnoSpecialFileUrlsConstantsGroup {
	String c_calcNewDocument = "private:factory/scalc";
}
