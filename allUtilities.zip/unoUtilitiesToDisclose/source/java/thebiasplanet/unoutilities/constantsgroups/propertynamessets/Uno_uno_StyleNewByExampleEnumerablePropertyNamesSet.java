package thebiasplanet.unoutilities.constantsgroups.propertynamessets;

import thebiasplanet.coreutilities.constantsgroups.BaseEnumerableConstantsGroup;

public class Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements Uno_uno_StyleNewByExamplePropertyNamesSet {
	public static final Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet c_instance = new Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet ();
	
	private Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet () {
	}
}
