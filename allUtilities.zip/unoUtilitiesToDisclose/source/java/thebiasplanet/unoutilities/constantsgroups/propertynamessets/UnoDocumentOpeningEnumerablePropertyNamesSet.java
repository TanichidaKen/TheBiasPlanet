package thebiasplanet.unoutilities.constantsgroups.propertynamessets;

import thebiasplanet.coreutilities.constantsgroups.BaseEnumerableConstantsGroup;

public class UnoDocumentOpeningEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoDocumentOpeningPropertyNamesSet {
	public static final UnoDocumentOpeningEnumerablePropertyNamesSet c_instance = new UnoDocumentOpeningEnumerablePropertyNamesSet ();
	
	private UnoDocumentOpeningEnumerablePropertyNamesSet () {
	}
}
