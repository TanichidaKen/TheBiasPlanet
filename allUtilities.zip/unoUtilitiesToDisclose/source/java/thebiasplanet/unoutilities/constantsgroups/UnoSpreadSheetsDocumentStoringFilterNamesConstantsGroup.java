package thebiasplanet.unoutilities.constantsgroups;

public interface UnoSpreadSheetsDocumentStoringFilterNamesConstantsGroup {
	String c_dif = "DIF";
	String c_html = "HTML (StarCalc)";
	String c_openDocumentSpreadSheetFlatXml = "OpenDocument Spreadsheet Flat XML";
	String c_excel97 = "MS Excel 97";
	String c_excel97Template= "MS Excel 97 Vorlage/Template";
	String c_sylk = "SYLK";
	String c_text = "Text - txt - csv (StarCalc)";
	String c_dBase = "dBase";
	String c_calc8 = "calc8";
	String c_calc8Template = "calc8_template";
	String c_excel2007Xml = "Calc MS Excel 2007 XML";
	String c_excel2007VbaXml = "Calc MS Excel 2007 VBA XML";
	String c_officeOpenXml = "Calc Office Open XML";
}
