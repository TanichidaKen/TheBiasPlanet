package thebiasplanet.coreutilities.constantsgroups;

import java.util.regex.Pattern;

public interface RegularExpressionsConstantsGroup {
	Pattern c_cProgramTraceOutputLineRegularExpression = Pattern.compile ("(#.*: )(.*)\\((.*)\\+0x(.*)\\) \\[(.*)\\] (.*)");
	// nm is the name of a command
	Pattern c_nmOutputLineRegularExpression = Pattern.compile ("(.*) (.*) (.*)");
	// addr2line is the name of a command
	Pattern c_addr2lineOutputSecondLineRegularExpression = Pattern.compile ("(.*):(.*)");
	Pattern c_numbersRegularExpression = Pattern.compile ("^(\\d*|\\d{1,3}(,\\d{3})*)(\\.\\d+)?([eE][-+]?\\d+)?$");
}
