package thebiasplanet.coreutilities.reflectionshandling;

import java.util.List;
import java.util.LinkedHashMap;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

public class ReflectionHandler {
	// Fields are stored in the order of from the super class to the sub class and from the implemented interfaces to the implementing class.
	// Duplicate named fields are replaced by the sub class's.
	// If all the gotten fields are static, set a_instance to be null.
	public static LinkedHashMap <String, Object> getFieldNamesAndValues (Class <?> a_class, Object a_instance, boolean a_publicOnly, boolean a_setAccessible, List <Class <?>> a_assignableClassesOfFields, List <Class <?>> a_notAssignableClassesOfFields, boolean a_recursive) throws IllegalAccessException {
		LinkedHashMap <String, Object> l_fieldNameToValueMap = new LinkedHashMap <String, Object> ();
		if (a_recursive) {
			LinkedHashMap <String, Object> l_superClassOrImplementedInterfaceFieldNameToValueMap = null;
			Class<?> l_superClass = a_class.getSuperclass();
			if (l_superClass != null) {
				l_superClassOrImplementedInterfaceFieldNameToValueMap = getFieldNamesAndValues (l_superClass, a_instance, a_publicOnly, a_setAccessible, a_assignableClassesOfFields, a_notAssignableClassesOfFields, true);
				l_fieldNameToValueMap.putAll (l_superClassOrImplementedInterfaceFieldNameToValueMap);
			}
			Class<?>[] l_implementedInterfaces = null;
			l_implementedInterfaces = a_class.getInterfaces();
			for (Class<?> l_implementedInterface: l_implementedInterfaces) {
				l_superClassOrImplementedInterfaceFieldNameToValueMap = getFieldNamesAndValues (l_implementedInterface, null, a_publicOnly, a_setAccessible, a_assignableClassesOfFields, a_notAssignableClassesOfFields, true);
				l_fieldNameToValueMap.putAll (l_superClassOrImplementedInterfaceFieldNameToValueMap);
			}
		}
		Field [] l_fields = l_fields = a_class.getDeclaredFields ();
		FieldsLoop: for (Field l_field: l_fields) {
			int l_fieldModifiers = l_field.getModifiers ();
			if (a_publicOnly && !Modifier.isPublic (l_fieldModifiers)) {
				continue;
			}
			if (a_instance == null && !Modifier.isStatic (l_fieldModifiers)) {
				continue;
			}
			if (a_assignableClassesOfFields != null) {
				boolean l_assignable = false;
				for (Class <?> l_assignableClassOfFields: a_assignableClassesOfFields) {
					if (!l_assignableClassOfFields.isAssignableFrom (l_field.getType ())) {
						l_assignable = true;
						break;
					}
				}
				if (!l_assignable) {
					continue;
				}
			}
			if (a_notAssignableClassesOfFields != null) {
				for (Class <?> l_notAssignableClassOfFields: a_notAssignableClassesOfFields) {
					if (l_notAssignableClassOfFields.isAssignableFrom (l_field.getType ())) {
						continue FieldsLoop;
					}
				}
			}
			boolean l_isAccessible = l_field.isAccessible ();
			if (a_setAccessible && !l_isAccessible) {
				l_field.setAccessible (true);
			}
			l_fieldNameToValueMap.put (l_field.getName (), l_field.get (a_instance));
			if (a_setAccessible && !l_isAccessible) {
				l_field.setAccessible (l_isAccessible);
			}
		}
		return l_fieldNameToValueMap;
	}
}
