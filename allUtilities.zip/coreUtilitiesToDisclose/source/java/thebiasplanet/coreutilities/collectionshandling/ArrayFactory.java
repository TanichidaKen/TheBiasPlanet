package thebiasplanet.coreutilities.collectionshandling;

import java.util.Collection;
import java.lang.reflect.Array;

public class ArrayFactory {
	@SuppressWarnings("unchecked")
	public static <T> T [] createArray (Class <?> a_class, Collection <?> a_collection) {
		int l_size = 0;
		if (a_collection != null) {
			l_size = a_collection.size ();
		}
		T [] l_array = (T []) Array.newInstance (a_class, l_size);
		if (l_size != 0) {
			return (T []) a_collection.toArray (l_array);
		}
		else {
			return l_array;
		}
	}
}
