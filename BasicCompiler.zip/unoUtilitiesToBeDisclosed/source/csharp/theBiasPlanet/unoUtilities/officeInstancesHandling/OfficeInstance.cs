namespace theBiasPlanet {
	namespace unoUtilities {
		namespace officeInstancesHandling  {
			using System;
			using unoidl.com.sun.star.document;
			using unoidl.com.sun.star.frame;
			using unoidl.com.sun.star.lang;
			using unoidl.com.sun.star.uno;
			using theBiasPlanet.coreUtilities.messaging;
			using theBiasPlanet.unoUtilities.constantsGroups;
			using theBiasPlanet.unoUtilities.connectionsHandling;
			using theBiasPlanet.unoUtilities.unoDataHandling;
			
			public class OfficeInstance : XTerminateListener, XDocumentEventListener {
				protected UnoObjectsContext i_unoObjectsContext;
				protected XDesktop2 i_unoDesktopInXDesktop2;
				protected XGlobalEventBroadcaster i_unoGlobalEventsBroadcasterInXGlobalEventBroadcaster;
				
				public OfficeInstance (UnoObjectsContext a_unoObjectsContext) {
					i_unoObjectsContext = a_unoObjectsContext;
					i_unoDesktopInXDesktop2 = (XDesktop2) i_unoObjectsContext.getServiceInstance (UnoServiceNamesConstantsGroup.c_com_sun_star_frame_Desktop, null);
					//i_unoGlobalEventsBroadcasterInXGlobalEventBroadcaster = theGlobalEventBroadcaster.get (i_unoObjectsContext);
					i_unoGlobalEventsBroadcasterInXGlobalEventBroadcaster = (XGlobalEventBroadcaster) UnoDatumConverter.getObject (i_unoObjectsContext.getValueByName (UnoSingletonNamesConstantsGroup.c_com_sun_star_frame_theGlobalEventBroadcaster));
					i_unoDesktopInXDesktop2.addTerminateListener (this); 
					i_unoGlobalEventsBroadcasterInXGlobalEventBroadcaster.addDocumentEventListener (this); 
				}
				
				~OfficeInstance () {
				}
				
				public virtual void queryTermination (unoidl.com.sun.star.lang.EventObject a_event) {
					Publisher.logNormalInformation ("### The termination of the office instance is queried.");
					throw new TerminationVetoException ();
				}
				
				public virtual void notifyTermination (unoidl.com.sun.star.lang.EventObject a_event) {
					Publisher.logNormalInformation ("### The termination of the office instance is notified.");
				}
				
				public virtual void disposing (unoidl.com.sun.star.lang.EventObject a_event) {
				}
				
				public virtual void documentEventOccured (DocumentEvent a_event) {
					if (a_event.EventName.Equals (UnoDocumentEventNamesConstantsGroup.c_documentDatumLoaded)) {
					}
					Publisher.logNormalInformation (String.Format ("### A document opened event has occurred: {0}.", a_event.EventName));
				}
				
				public virtual bool shutDown () {
					i_unoGlobalEventsBroadcasterInXGlobalEventBroadcaster.removeDocumentEventListener (this); 
					i_unoDesktopInXDesktop2.removeTerminateListener (this); 
					while (!(i_unoDesktopInXDesktop2.terminate ())) {
						Publisher.logNormalInformation ("### The termination of the office instance has been vetoed.");
					}
					Publisher.logNormalInformation ("### The termination of the office instance has been accomplished.");
					return true;
				}
			}
		}
	}
}

