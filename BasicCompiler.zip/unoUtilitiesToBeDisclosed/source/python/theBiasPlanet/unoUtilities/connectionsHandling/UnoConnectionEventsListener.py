from abc import ABCMeta
from abc import abstractmethod
from com.sun.star.lang import EventObject

class UnoConnectionEventsListener (metaclass=ABCMeta):
	@abstractmethod
	def connected (a_this: "UnoConnectionEventsListener", a_event: EventObject) -> None:
		raise NotImplementedError ()
	
	@abstractmethod
	def disconnected (a_this: "UnoConnectionEventsListener", a_event: EventObject) -> None:
		raise NotImplementedError ()

