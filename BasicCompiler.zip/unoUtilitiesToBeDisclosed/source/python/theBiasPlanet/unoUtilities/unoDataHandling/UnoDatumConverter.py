from typing import cast
from typing import Optional
from uno import Any
from theBiasPlanet.unoUtilities.constantsGroups.UnoDatumTypeNamesConstantsGroup import UnoDatumTypeNamesConstantsGroup

class UnoDatumConverter:
	@staticmethod
	def getObject (a_originalObject: object) -> object:
		if a_originalObject is None:
			return None
		else:
			if isinstance (a_originalObject, Any):
				return cast (Any, a_originalObject).Value
			else:
				return a_originalObject
	
	"""
	a_typeString: Use theBiasPlanet.unoUtilities.constantsGroups.UnoDatumTypeNamesConstantsGroup
	"""
	@staticmethod
	def getAny (a_originalObject: object, a_typeString: Optional [str] = None) -> Any:
		if a_originalObject is None:
			return None
		else:
			if isinstance (a_originalObject, Any):
				return a_originalObject
			else:
				l_type: type = type (a_originalObject)
				l_typeString: str
				if a_typeString is None:
					if l_type == str:
						l_typeString = UnoDatumTypeNamesConstantsGroup.c_stringTypeName
					elif l_type == int:
						l_typeString = UnoDatumTypeNamesConstantsGroup.c_longTypeName
					elif l_type == bool:
						l_typeString = UnoDatumTypeNamesConstantsGroup.c_booleanTypeName
					elif l_type == float:
						l_typeString = UnoDatumTypeNamesConstantsGroup.c_floatTypeName
					elif l_type == list:
						l_typeString = UnoDatumTypeNamesConstantsGroup.c_sequenceTypeNamePrefix + "any"
					else:
						raise Exception ("The UNO datum type for '{0:s}' isn't implemented yet.".format (str (l_type)))
				else:
					l_typeString = a_typeString
				return Any (l_typeString, a_originalObject)

