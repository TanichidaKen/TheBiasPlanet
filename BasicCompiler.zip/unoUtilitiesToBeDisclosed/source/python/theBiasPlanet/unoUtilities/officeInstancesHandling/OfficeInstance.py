import os.path
import threading
from threading import Lock
from typing import cast
from typing import List
from typing import Optional
from typing import Tuple
import xml.sax
from xml.sax.handler import ContentHandler
from xml.sax.xmlreader import AttributesNSImpl
from xml.sax.xmlreader import InputSource
from xml.sax.xmlreader import XMLReader
#from wx import TheClipboard
import pyperclip
import uno
from com.sun.star.container import NoSuchElementException
from com.sun.star.container import XEnumeration
from com.sun.star.frame import DispatchResultEvent
from com.sun.star.frame import FeatureStateEvent
from com.sun.star.frame import XDesktop2
from com.sun.star.frame import XDispatchResultListener
from com.sun.star.frame import XFrame
from com.sun.star.frame import XModel2
from com.sun.star.frame import XStatusListener
from com.sun.star.lang import EventObject as com_sun_star_lang_EventObject
from com.sun.star.lang import WrappedTargetException
from com.sun.star.lang import XServiceInfo
from com.sun.star.script.browse import XBrowseNode
from unohelper import Base as UnoBase
from theBiasPlanet.coreUtilities.collectionsHandling.ListsFactory import ListsFactory
from theBiasPlanet.coreUtilities.messaging.Publisher import Publisher
from theBiasPlanet.unoUtilities.connectionsHandling.UnoObjectsContext import UnoObjectsContext
from theBiasPlanet.unoUtilities.constantsGroups.UnoDispatchSlotsConstantsGroup import UnoDispatchSlotsConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.UnoServiceNamesConstantsGroup import UnoServiceNamesConstantsGroup
from theBiasPlanet.unoUtilities.dispatching.UnoDispatcher import UnoDispatcher
from theBiasPlanet.unoUtilities.dispatching.UnoDispatchResult import UnoDispatchResult

import sys

class OfficeInstance (UnoBase, XDispatchResultListener, XStatusListener):
	class BasicSourceXmlParseHandler (ContentHandler):
		def __init__ (a_this: "OfficeInstance.BasicSourceXmlParseHandler") -> None:
			a_this.i_basicCodeBuilder: Optional [List [str]]
			a_this.i_isInBasicCodeElement: bool
			
			a_this.i_basicCodeBuilder = None;
			a_this.i_isInBasicCodeElement = False
		
		def getBasicCode (a_this: "OfficeInstance.BasicSourceXmlParseHandler") -> str:
			if not (a_this.i_basicCodeBuilder is None):
				return "".join (a_this.i_basicCodeBuilder)
			else:
				return ""
		
		def startDocument (a_this: "OfficeInstance.BasicSourceXmlParseHandler") -> None:
			a_this.i_isInBasicCodeElement = False
		
		def endDocument(a_this: "OfficeInstance.BasicSourceXmlParseHandler") -> None:
			None
		
		def startElementNS (a_this: "OfficeInstance.BasicSourceXmlParseHandler", a_namespaceUriAndLocalName: Tuple [str, str], a_qualifiedName: str, a_attributes: AttributesNSImpl) -> None:
			#if a_qualifiedName == "script:module":
			if a_namespaceUriAndLocalName [1] == "module":
				a_this.i_isInBasicCodeElement = True
				a_this.i_basicCodeBuilder = []
		
		def endElementNS (a_this: "OfficeInstance.BasicSourceXmlParseHandler", a_namespaceUriAndLocalName: Tuple [str, str], a_qualifiedName: str) -> None:
			None
		
		def characters (a_this: "OfficeInstance.BasicSourceXmlParseHandler", a_contents: str) -> None:
			if a_this.i_isInBasicCodeElement:
				if not (a_this.i_basicCodeBuilder is None):
					a_this.i_basicCodeBuilder.append (a_contents)
	
	def __init__ (a_this: "OfficeInstance", a_unoObjectsContext: "UnoObjectsContext", a_basicSourceBasePath: Optional [str]) -> None:
		a_this.i_lock: Lock
		a_this.i_unoObjectsContext: "UnoObjectsContext"
		a_this.i_desktopInXDesktop2: XDesktop2
		a_this.i_desktopInXFrame: XFrame 
		a_this.i_dispatchResult: "Optional [UnoDispatchResult]"
		a_this.i_basicSourceBasePath: Optional [str]
		a_this.i_xmlParser: XMLReader
		a_this.i_basicSourceXmlParseHandler: "OfficeInstance.BasicSourceXmlParseHandler"
		
		a_this.i_lock = threading.Lock ()
		a_this.i_unoObjectsContext = a_unoObjectsContext
		a_this.i_desktopInXDesktop2 = cast (XDesktop2, a_this.i_unoObjectsContext.getServiceInstance (UnoServiceNamesConstantsGroup.c_com_sun_star_frame_Desktop, None))
		a_this.i_desktopInXFrame = cast (XFrame, a_this.i_desktopInXDesktop2)
		a_this.i_dispatchResult = None
		a_this.i_basicSourceBasePath = a_basicSourceBasePath
		if not (a_this.i_basicSourceBasePath is None):
			a_this.i_xmlParser = xml.sax.make_parser ()
			a_this.i_xmlParser.setFeature (xml.sax.handler.feature_namespaces, True)
			#a_this.i_xmlParser.setFeature (xml.sax.handler.feature_namespace_prefixes, True)
			a_this.i_basicSourceXmlParseHandler = OfficeInstance.BasicSourceXmlParseHandler ()
			a_this.i_xmlParser.setContentHandler (a_this.i_basicSourceXmlParseHandler)
			#a_this.i_clipboard	= Toolkit.getDefaultToolkit ().getSystemClipboard ();
	
	def dispatch (a_this: "OfficeInstance", a_dispatchSlot: "UnoDispatchSlotsConstantsGroup.BaseDispatchSlot", a_argumentValues: Optional [List [object]]) -> "Optional [UnoDispatchResult]":
		try:
			a_this.i_lock.acquire ()
			a_this.i_dispatchResult = UnoDispatchResult ()
			if UnoDispatcher.dispatch (a_this.i_unoObjectsContext, a_this.i_desktopInXFrame, a_this, a_this, a_dispatchSlot, a_argumentValues):
				None
			else:
				a_this.i_dispatchResult = None
			return a_this.i_dispatchResult
		finally:
			a_this.i_lock.release ()
	
	def compileUserBasicScript (a_this: "OfficeInstance", a_libraryName: Optional [str]) -> bool:
		l_resultStatus: bool  = False
		l_scriptsProviderForBasicInXBrowseNode: XBrowseNode = cast (XBrowseNode, a_this.i_unoObjectsContext.getServiceInstance (UnoServiceNamesConstantsGroup.c_com_sun_star_script_provider_ScriptProviderForBasic, ListsFactory.createList (object, "user")))
		l_libraryNodesInXBrowseNodesArray: List [XBrowseNode]  = l_scriptsProviderForBasicInXBrowseNode.getChildNodes ()
		l_libraryName: Optional [str] = None
		l_libraryNodeInXBrowseNode: Optional [XBrowseNode] = None
		for l_libraryNodeInXBrowseNode in l_libraryNodesInXBrowseNodesArray:
			l_libraryName = l_libraryNodeInXBrowseNode.getName ()
			if a_libraryName is None or a_libraryName == l_libraryName:
				l_moduleNodesInXBrowseNodesArray: List [XBrowseNode] = l_libraryNodeInXBrowseNode.getChildNodes ()
				l_moduleNodeInXBrowseNode: XBrowseNode
				for l_moduleNodeInXBrowseNode in l_moduleNodesInXBrowseNodesArray:
					if not (l_libraryName is None):
						l_resultStatus = a_this.compileBasicScript ("application", l_libraryName, l_moduleNodeInXBrowseNode.getName ())
					if not l_resultStatus:
						break
				if not (a_libraryName is None):
					break
		return l_resultStatus
	
	def compileBasicScript (a_this: "OfficeInstance", a_containerName: str, a_libraryName: str, a_moduleName: str) -> bool:
		l_resultStatus: bool = False
		l_unoDispatchResult: "Optional [UnoDispatchResult]" = a_this.dispatch (UnoDispatchSlotsConstantsGroup.c__uno_BasicIDEAppear, ListsFactory.createList (object, a_containerName, a_libraryName, a_moduleName, "Module", 1, 0, 0))
		l_unoObjectsInXEnumeration: XEnumeration = a_this.i_desktopInXDesktop2.getComponents ().createEnumeration ()
		l_unoObjectInXServiceInfo: XServiceInfo = None
		l_basicIdeFrameInXFrame: XFrame = None
		while l_unoObjectsInXEnumeration.hasMoreElements ():
			try:
				l_unoObjectInXServiceInfo = cast (XServiceInfo, l_unoObjectsInXEnumeration.nextElement ())
				if not (l_unoObjectInXServiceInfo is None):
					if l_unoObjectInXServiceInfo.supportsService (UnoServiceNamesConstantsGroup.c_com_sun_star_script_BasicIDE):
						l_basicIdeFrameInXFrame = cast (XModel2, l_unoObjectInXServiceInfo).getCurrentController ().getFrame ()
						break
			except (NoSuchElementException, WrappedTargetException) as l_exception:
				# Practically, never would happen
				break
		if not (l_basicIdeFrameInXFrame is None):
			try:
				a_this.i_lock.acquire ()
				a_this.i_dispatchResult = UnoDispatchResult ()
				l_basicSourceFilePath: str = "{0:s}/{1:s}/{2:s}.xba".format (a_this.i_basicSourceBasePath, a_libraryName, a_moduleName)
				if os.path.isfile (l_basicSourceFilePath):
					a_this.i_xmlParser.parse (InputSource (l_basicSourceFilePath))
					l_previousClipboardContent: str = pyperclip.paste ()
					pyperclip.copy (a_this.i_basicSourceXmlParseHandler.getBasicCode ())
					l_resultStatus = UnoDispatcher.dispatch (a_this.i_unoObjectsContext, l_basicIdeFrameInXFrame, a_this, a_this, UnoDispatchSlotsConstantsGroup.c__uno_SelectAll, None)
					l_resultStatus = UnoDispatcher.dispatch (a_this.i_unoObjectsContext, l_basicIdeFrameInXFrame, a_this, a_this, UnoDispatchSlotsConstantsGroup.c__uno_Paste, ListsFactory.createList (object, 0))
					pyperclip.copy (l_previousClipboardContent)
				else:
					Publisher.logWarningInformation ("There is no source file for {0:s}.{1:s}.{2:s} under the Basic source base.".format (a_containerName, a_libraryName, a_moduleName))
				l_resultStatus = UnoDispatcher.dispatch (a_this.i_unoObjectsContext, l_basicIdeFrameInXFrame, a_this, a_this, UnoDispatchSlotsConstantsGroup.c__uno_CompileBasic, None)
				if l_resultStatus:
					None
				else:
					a_this.i_dispatchResult = None
			finally:
				a_this.i_lock.release ()
		return l_resultStatus
	
	def dispatchFinished (a_this: "OfficeInstance", a_dispatchResultEvent: "DispatchResultEvent") -> None:
		if not (a_this.i_dispatchResult is None):
			a_this.i_dispatchResult.setDispatchResult (a_dispatchResultEvent)
	
	def statusChanged (a_this: "OfficeInstance", a_featureStateEvent: FeatureStateEvent) -> None:
		if not (a_this.i_dispatchResult is None):
			a_this.i_dispatchResult.addRelatedInformationPiece (a_featureStateEvent)
	
	def disposing (a_this: "OfficeInstance", a_source: com_sun_star_lang_EventObject) -> None:
		None

