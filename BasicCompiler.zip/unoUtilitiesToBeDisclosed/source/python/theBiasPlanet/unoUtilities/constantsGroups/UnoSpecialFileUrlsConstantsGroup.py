
class UnoSpecialFileUrlsConstantsGroup:
	c_calcNewDocument: str = "private:factory/scalc"
	c_writerNewDocument: str = "private:factory/swriter"

