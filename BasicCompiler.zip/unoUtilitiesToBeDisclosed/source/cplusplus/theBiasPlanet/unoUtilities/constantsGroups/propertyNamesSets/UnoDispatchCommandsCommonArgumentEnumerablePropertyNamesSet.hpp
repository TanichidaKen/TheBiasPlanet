#ifndef __theBiasPlanet_unoUtilities_constantsGroups_propertyNamesSets_UnoDispatchCommandsCommonArgumentEnumerablePropertyNamesSet_hpp__
	#define __theBiasPlanet_unoUtilities_constantsGroups_propertyNamesSets_UnoDispatchCommandsCommonArgumentEnumerablePropertyNamesSet_hpp__
	
	#include "theBiasPlanet/coreUtilities/constantsGroups/BaseEnumerableConstantsGroup.hpp"
	#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/UnoPropertyNamesSet.hpp"
	#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::theBiasPlanet::coreUtilities::constantsGroups;
	
	namespace theBiasPlanet {
		namespace unoUtilities {
			namespace constantsGroups {
				namespace propertyNamesSets {
					class __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ UnoDispatchCommandsCommonArgumentEnumerablePropertyNamesSet : public BaseEnumerableConstantsGroup <string>, public UnoPropertyNamesSet {
						private:
							UnoDispatchCommandsCommonArgumentEnumerablePropertyNamesSet ();
						public:
							static string const c_synchronousMode_boolean;
							static UnoDispatchCommandsCommonArgumentEnumerablePropertyNamesSet const c_instance;
					};
				}
			}
		}
	}
#endif

