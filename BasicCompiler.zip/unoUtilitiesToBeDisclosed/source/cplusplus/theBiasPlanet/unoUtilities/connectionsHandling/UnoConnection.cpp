#include "theBiasPlanet/coreUtilities/messaging/Publisher.hpp"
#include "theBiasPlanet/unoUtilities/connectionsHandling/UnoConnection.hpp"
#include "theBiasPlanet/unoUtilities/stringsHandling/UnoExtendedStringHandler.hpp"

using namespace ::com::sun::star::uno;
using namespace ::theBiasPlanet::coreUtilities::messaging;
using namespace ::theBiasPlanet::unoUtilities::stringsHandling;

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace connectionsHandling {
			UnoConnection::UnoConnection (Reference <XComponentContext> const a_originalObjectsContextInXComponentContext, optional <map <string, Any>> const a_extraNameToValueMap, Reference <XBridge> const a_bridgeInXBridge, optional <list <UnoConnectionEventsListener *>> a_eventListeners) : WeakComponentImplHelper1 (i_mutex), i_remoteObjectsContext (Reference <UnoObjectsContext> (new UnoObjectsContext (a_originalObjectsContextInXComponentContext, a_extraNameToValueMap))), i_bridgeInXComponent (Reference <XComponent> (a_bridgeInXBridge, UNO_QUERY)), i_eventListeners (a_eventListeners) {
				i_bridgeInXComponent->addEventListener (Reference <XEventListener> (this));
				EventObject const l_event = EventObject (*this);
				if (i_eventListeners.has_value ()) {
					list <UnoConnectionEventsListener *>::iterator l_eventListenersIterator;
					for (l_eventListenersIterator = i_eventListeners->begin (); l_eventListenersIterator != i_eventListeners->end (); l_eventListenersIterator ++) {
						(*l_eventListenersIterator)->connected (l_event);
					}
				}
			}
			
			UnoConnection::~UnoConnection () {
			}
				
			Reference <UnoObjectsContext> UnoConnection::getRemoteObjectsContext () {
				return i_remoteObjectsContext;
			}
			
			void UnoConnection::disconnect () {
				if (i_bridgeInXComponent.get () != nullptr) {
					try {
						i_bridgeInXComponent->dispose ();
					}
					catch (Exception l_exception) {
						Publisher::logErrorInformation (StringHandler::format (string ("### UnoConnection::disconnect error: %s."), UnoExtendedStringHandler::getString (l_exception.Message)));
					}
					catch (exception l_exception) {
						Publisher::logErrorInformation (StringHandler::format (string ("### UnoConnection::disconnect error: %s."), string (l_exception.what ())));
					}
				}
			}
			
			void UnoConnection::disposing (EventObject const & a_event) {
				ostringstream l_messageStream;
				l_messageStream << a_event.Source.get ();
				string const l_message = l_messageStream.str ();
				Publisher::logNormalInformation (l_message);
				EventObject l_event (*this);
				if (i_eventListeners.has_value ()) {
					list <UnoConnectionEventsListener *>::iterator l_eventListenersIterator;
					for (l_eventListenersIterator = i_eventListeners->begin (); l_eventListenersIterator != i_eventListeners->end (); l_eventListenersIterator ++) {
						(*l_eventListenersIterator)->disconnected (l_event);
					}
				}
				i_remoteObjectsContext.clear ();
				i_bridgeInXComponent.clear ();
				i_eventListeners = nullopt;
			}
		}
	}
}

