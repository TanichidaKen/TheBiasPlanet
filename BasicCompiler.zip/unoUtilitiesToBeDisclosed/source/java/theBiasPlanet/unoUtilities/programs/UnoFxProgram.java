package theBiasPlanet.unoUtilities.programs;

import java.util.List;
import java.time.LocalDateTime;
import javafx.application.Application;
import javafx.stage.Stage;
import theBiasPlanet.coreUtilities.messaging.Publisher;
import theBiasPlanet.unoUtilities.displaysHandling.UnoConnectionAcceptorScene;
import theBiasPlanet.unoUtilities.displaysHandling.UnoConnectionBaseScene;
import theBiasPlanet.unoUtilities.displaysHandling.UnoConnectionConnectorScene;
import theBiasPlanet.unoUtilities.displaysHandling.UnoConnectionStage;
import theBiasPlanet.unoUtilities.programsHandling.UnoFxProcessEnvironment;

public class UnoFxProgram extends Application {
	protected static UnoConnectionBaseScene s_unoConnectionScene = null;
	
	public static void main (String [] a_arguments) throws Exception {
		Publisher.setLoggingLevel (3);
		if (a_arguments.length != 2) {
			throw new Exception ("The argument 1 and 2 must be the property file url and the server/client mode (0/1).");
		}
		new UnoFxProcessEnvironment (LocalDateTime.now ().toString (), a_arguments[0]);
		switch (a_arguments [1]) {
			case "0":
				s_unoConnectionScene = new UnoConnectionAcceptorScene ();
				break;
			case "1":
				s_unoConnectionScene = new UnoConnectionConnectorScene ();
				break;
			default:
				throw new Exception ("The server/client mode (0/1) is invalid.");
		}
		launch (a_arguments);
	}
	
	@Override
	final public void start(Stage a_defaultStage) throws Exception {
		a_defaultStage.close ();
		UnoConnectionStage l_unoConnectionStage = new UnoConnectionStage ();
		UnoFxProcessEnvironment.s_currentEnvironment.setMainStage (l_unoConnectionStage);
		List <String> l_arguments = getParameters ().getRaw ();
		l_unoConnectionStage.setUnoConnectionScene (s_unoConnectionScene);
		l_unoConnectionStage.show ();
	}
}

