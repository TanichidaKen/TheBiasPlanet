package theBiasPlanet.unoUtilities.officeInstancesHandling;

import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.awt.Toolkit;
import java.io.File;
import java.io.FileInputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
import com.sun.star.container.NoSuchElementException;
import com.sun.star.container.XEnumeration;
import com.sun.star.frame.DispatchResultEvent;
import com.sun.star.frame.FeatureStateEvent;
import com.sun.star.frame.XDesktop2;
import com.sun.star.frame.XDispatchResultListener;
import com.sun.star.frame.XFrame;
import com.sun.star.frame.XModel2;
import com.sun.star.frame.XStatusListener;
import com.sun.star.lang.EventObject;
import com.sun.star.lang.WrappedTargetException;
import com.sun.star.lang.XComponent;
import com.sun.star.lang.XServiceInfo;
import com.sun.star.script.browse.XBrowseNode;
import com.sun.star.uno.UnoRuntime;
import com.sun.star.util.CloseVetoException;
import com.sun.star.util.XCloseable;
import theBiasPlanet.coreUtilities.collectionsHandling.ListsFactory;
import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.coreUtilities.messaging.Publisher;
import theBiasPlanet.unoUtilities.connectionsHandling.UnoObjectsContext;
import theBiasPlanet.unoUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.*;
import theBiasPlanet.unoUtilities.dispatching.UnoDispatcher;
import theBiasPlanet.unoUtilities.dispatching.UnoDispatchResult;

public class OfficeInstance implements XDispatchResultListener, XStatusListener {
	protected UnoObjectsContext i_unoObjectsContext;
	protected XDesktop2 i_desktopInXDesktop2;
	protected XFrame i_desktopInXFrame;
	protected UnoDispatchResult i_dispatchResult;
	protected String i_basicSourceBasePath;
	protected SAXParser i_xmlParser;
	protected BasicSourceXmlParseHandler i_basicSourceXmlParseHandler;
	protected Clipboard i_clipboard;
	
	class BasicSourceXmlParseHandler extends DefaultHandler {
		StringBuilder i_basicCodeBuilder = null;
		boolean i_isInBasicCodeElement = false;
		
		public String getBasicCode () {
			return i_basicCodeBuilder.toString ();
		}
		
		@Override
		public void startDocument () throws SAXException {
			i_isInBasicCodeElement = false;
		}
		
		@Override
		public void endDocument () throws SAXException {
		}
		
		@Override
		public void startElement (String a_namespaceUri,String a_localName, String a_qualifiedName, Attributes a_attributes) throws SAXException {
			if (a_qualifiedName.equals ("script:module")) {
				i_isInBasicCodeElement = true;
				i_basicCodeBuilder = new StringBuilder ();
			}
		}
		
		@Override
		public void endElement (String a_namespaceUri, String a_localName, String a_qualifiedName) throws SAXException {
		}
		
		@Override
		public void characters (char[] a_characters, int a_start, int a_length) throws SAXException {
			if (i_isInBasicCodeElement) {
				i_basicCodeBuilder.append (a_characters, a_start, a_length);
			}
		}
	}
	
	public OfficeInstance (UnoObjectsContext a_unoObjectsContext, String a_basicSourceBasePath) throws Exception {
		i_unoObjectsContext = a_unoObjectsContext;
		i_desktopInXDesktop2 = (XDesktop2) i_unoObjectsContext.getServiceInstance (UnoServiceNamesConstantsGroup.c_com_sun_star_frame_Desktop, XDesktop2.class, null);
		i_desktopInXFrame = (XFrame) UnoRuntime.queryInterface (XFrame.class, i_desktopInXDesktop2);
		i_dispatchResult = null;
		i_basicSourceBasePath = a_basicSourceBasePath;
		if (i_basicSourceBasePath != null) {
			SAXParserFactory l_saxParserFactory = SAXParserFactory.newInstance ();
			l_saxParserFactory.setFeature ("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
        	i_xmlParser = l_saxParserFactory.newSAXParser ();
			i_basicSourceXmlParseHandler = new BasicSourceXmlParseHandler ();
			i_clipboard	= Toolkit.getDefaultToolkit ().getSystemClipboard ();
		}
	}
	
	public UnoDispatchResult dispatch (UnoDispatchSlotsConstantsGroup.BaseDispatchSlot a_dispatchSlot, List <Object> a_argumentValues) throws Exception {
		synchronized (this) {
			i_dispatchResult = new UnoDispatchResult ();
			if (UnoDispatcher.dispatch (i_unoObjectsContext, i_desktopInXFrame, this, this, a_dispatchSlot, a_argumentValues)) {
			}
			else {
				i_dispatchResult = null;
			}
			return i_dispatchResult;
		}
	}
	
	public boolean compileUserBasicScript (String a_libraryName) throws Exception {
		boolean l_resultStatus = false;
		XBrowseNode l_scriptsProviderForBasicInXBrowseNode = (XBrowseNode) i_unoObjectsContext.getServiceInstance (UnoServiceNamesConstantsGroup.c_com_sun_star_script_provider_ScriptProviderForBasic, XBrowseNode.class, ListsFactory. <Object>createArrayList ("user"));
		XBrowseNode [] l_libraryNodesInXBrowseNodesArray = l_scriptsProviderForBasicInXBrowseNode.getChildNodes ();
		String l_libraryName = null;
		for (XBrowseNode l_libraryNodeInXBrowseNode: l_libraryNodesInXBrowseNodesArray) {
			l_libraryName = l_libraryNodeInXBrowseNode.getName ();
			if (a_libraryName == null || a_libraryName.equals (l_libraryName)) {
				XBrowseNode [] l_moduleNodesInXBrowseNodesArray = l_libraryNodeInXBrowseNode.getChildNodes ();
				for (XBrowseNode l_moduleNodeInXBrowseNode: l_moduleNodesInXBrowseNodesArray) {
					l_resultStatus = compileBasicScript ("application", l_libraryName, l_moduleNodeInXBrowseNode.getName ());
					if (!l_resultStatus) {
						break;
					}
				}
				if (a_libraryName != null) {
					break;
				}
			}
		}
		return l_resultStatus;
	}
	
	public boolean compileBasicScript (String a_containerName, String a_libraryName, String a_moduleName) throws Exception {
		boolean l_resultStatus = false;
		UnoDispatchResult l_unoDispatchResult = dispatch (UnoDispatchSlotsConstantsGroup.c__uno_BasicIDEAppear, ListsFactory. <Object>createArrayList (a_containerName, a_libraryName, a_moduleName, "Module", 1, 0, 0));
		XEnumeration l_unoObjectsInXEnumeration = i_desktopInXDesktop2.getComponents ().createEnumeration ();
		XServiceInfo l_unoObjectInXServiceInfo = null;
		XFrame l_basicIdeFrameInXFrame = null;
		while (l_unoObjectsInXEnumeration.hasMoreElements ()) {
			try {
				l_unoObjectInXServiceInfo = (XServiceInfo) UnoRuntime.queryInterface (XServiceInfo.class, l_unoObjectsInXEnumeration.nextElement ());
				if (l_unoObjectInXServiceInfo != null) {
					if (l_unoObjectInXServiceInfo.supportsService (UnoServiceNamesConstantsGroup.c_com_sun_star_script_BasicIDE)) {
						l_basicIdeFrameInXFrame = ((XModel2) UnoRuntime.queryInterface (XModel2.class, l_unoObjectInXServiceInfo)).getCurrentController ().getFrame ();
						break;
					}
				}
			}
			catch (NoSuchElementException | WrappedTargetException l_exception) {
				// Practically, never would happen
				break;
			}
		}
		if (l_basicIdeFrameInXFrame != null) {
			synchronized (this) {
				i_dispatchResult = new UnoDispatchResult ();
				String l_basicSourceFilePath = String.format ("%s/%s/%s.xba", i_basicSourceBasePath, a_libraryName, a_moduleName);
				if (Files.exists (Paths.get (l_basicSourceFilePath))) {
					i_xmlParser.parse (new FileInputStream (new File (l_basicSourceFilePath)), i_basicSourceXmlParseHandler);
					Transferable l_previousClipboardContents = i_clipboard.getContents (null);
					StringSelection l_basicCodeTransferable = new StringSelection (i_basicSourceXmlParseHandler.getBasicCode ());
					i_clipboard.setContents (l_basicCodeTransferable, l_basicCodeTransferable);
					l_resultStatus = UnoDispatcher.dispatch (i_unoObjectsContext, l_basicIdeFrameInXFrame, this, this, UnoDispatchSlotsConstantsGroup.c__uno_SelectAll, null);
					l_resultStatus = UnoDispatcher.dispatch (i_unoObjectsContext, l_basicIdeFrameInXFrame, this, this, UnoDispatchSlotsConstantsGroup.c__uno_Paste, ListsFactory. <Object>createArrayList (Short.valueOf ((short) 0)));
					i_clipboard.setContents (l_previousClipboardContents, null);
				}
				else {
					Publisher.logWarningInformation (String.format ("There is no source file for %s.%s.%s under the Basic source base.", a_containerName, a_libraryName, a_moduleName));
				}
				l_resultStatus = UnoDispatcher.dispatch (i_unoObjectsContext, l_basicIdeFrameInXFrame, this, this, UnoDispatchSlotsConstantsGroup.c__uno_CompileBasic, null);
				if (l_resultStatus) {
				}
				else {
					i_dispatchResult = null;
				}
			}
		}
		return l_resultStatus;
	}
	
	public boolean terminate () {
		XEnumeration l_unoObjectsInXEnumeration = i_desktopInXDesktop2.getComponents ().createEnumeration ();
		while (l_unoObjectsInXEnumeration.hasMoreElements ()) {
			XCloseable l_unoObjectInXCloseable = null;
			try {
				l_unoObjectInXCloseable = (XCloseable) UnoRuntime.queryInterface (XCloseable.class, l_unoObjectsInXEnumeration.nextElement ());
			}
			catch (NoSuchElementException | WrappedTargetException l_exception) {
				// Practically, never would happen
				break;
			}
			if (l_unoObjectInXCloseable == null) {
				continue;
			}
			try {
				l_unoObjectInXCloseable.close (false);
			}
			catch (CloseVetoException l_exception) {
				((XComponent) UnoRuntime.queryInterface (XComponent.class, l_unoObjectInXCloseable)).dispose ();
			}
		}
		return i_desktopInXDesktop2.terminate ();
	}
	
	@Override
	public void dispatchFinished (DispatchResultEvent a_dispatchResultEvent) {
		i_dispatchResult.setDispatchResult (a_dispatchResultEvent);
	}
	
	@Override
	public void statusChanged (FeatureStateEvent a_relatedInformationPiece) {
		i_dispatchResult.addRelatedInformationPiece (a_relatedInformationPiece);
	}
	
	@Override
	public void disposing (EventObject a_eventSource) {
	}
}

