package theBiasPlanet.unoUtilities.programsHandling;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;
import theBiasPlanet.coreUtilities.programsHandling.FxProcessEnvironment;

public class UnoFxProcessEnvironment extends FxProcessEnvironment {
	public static UnoFxProcessEnvironment s_currentEnvironment;
	private UnoProcessEnvironment i_unoEnvironment = null;
	
	public UnoFxProcessEnvironment (String a_identification, String a_propertyFileUrl) throws FileNotFoundException, IOException, ParserConfigurationException, SAXException, ClassNotFoundException, NoSuchMethodException, InvocationTargetException, IllegalAccessException, com.sun.star.uno.Exception {
		super (a_identification, a_propertyFileUrl);
		i_unoEnvironment = new UnoProcessEnvironment (i_identification, i_properties.getProperty ("unoServicesSettingFileUrl"));
		s_currentEnvironment = this;
	}
	
	public final UnoProcessEnvironment getUnoEnvironment () {
		return i_unoEnvironment;
	}
}

