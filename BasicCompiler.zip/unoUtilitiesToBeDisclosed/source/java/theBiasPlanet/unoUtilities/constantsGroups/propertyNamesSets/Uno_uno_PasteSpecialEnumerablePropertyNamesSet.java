package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_PasteSpecialEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_formatKey_int = "Format";
	public static final Uno_uno_PasteSpecialEnumerablePropertyNamesSet c_instance = new Uno_uno_PasteSpecialEnumerablePropertyNamesSet ();
	
	private Uno_uno_PasteSpecialEnumerablePropertyNamesSet () {
	}
}

