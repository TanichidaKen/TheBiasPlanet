package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_ReplaceEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_searchedForString_string = "SearchString";
	public static final String c_replacedWithString_string = "ReplaceString";
	
	public static final Uno_uno_ReplaceEnumerablePropertyNamesSet c_instance = new Uno_uno_ReplaceEnumerablePropertyNamesSet ();
	
	private Uno_uno_ReplaceEnumerablePropertyNamesSet () {
	}
}

