package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_GoDownBlockSelEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_numberOfPagesToGoDownBy_short = "By";
	public static final Uno_uno_GoDownBlockSelEnumerablePropertyNamesSet c_instance = new Uno_uno_GoDownBlockSelEnumerablePropertyNamesSet ();
	
	private Uno_uno_GoDownBlockSelEnumerablePropertyNamesSet () {
	}
}

