package theBiasPlanet.unoUtilities.displaysHandling;

import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class UnoConnectionStage extends Stage {
	UnoConnectionBaseScene i_scene = null;
	
	public UnoConnectionStage () {
		super (StageStyle.DECORATED);
	 	setResizable (false);
	 	setOnCloseRequest (a_event -> {close ();});
	}
	
	public void setUnoConnectionScene (UnoConnectionBaseScene a_scene) {
		i_scene = a_scene;
		setScene (i_scene);
		setTitle (i_scene.getTitle ());
		sizeToScene ();
	}
	
	@Override
	public void close () {
		i_scene.close ();
	}
}

