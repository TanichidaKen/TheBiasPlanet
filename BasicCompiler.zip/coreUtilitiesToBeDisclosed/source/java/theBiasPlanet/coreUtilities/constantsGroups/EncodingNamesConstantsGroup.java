package theBiasPlanet.coreUtilities.constantsGroups;

public interface EncodingNamesConstantsGroup {
	String c_utf8EncodingName = "UTF-8";
	String c_utf8InputStreamReaderReturningEncodingName = "UTF8";
}

