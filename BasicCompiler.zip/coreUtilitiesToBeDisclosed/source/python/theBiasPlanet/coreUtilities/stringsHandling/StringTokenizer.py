from typing import Any
from typing import List
from typing import Optional
from re import split
from theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup import GeneralConstantsConstantsGroup

class StringTokenizer:
	def __init__ (a_this: Any, a_targetString: str, a_delimitersRegularExpression: str) -> None:
		i_tokens: Optional [List [str]] = None
		i_numberOfTokens: int = GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger
		i_currentIndex:int = GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger
		
		if (not (a_targetString is None)):
			a_this.i_tokens = split (a_delimitersRegularExpression, a_targetString)
			a_this.i_numberOfTokens = len (a_this.i_tokens)
			a_this.i_currentIndex = GeneralConstantsConstantsGroup.c_iterationStartingNumber
	
	def countTokens (a_this: Any) -> int:
		return a_this.i_numberOfTokens - a_this.i_currentIndex
	
	def hasMoreTokens (a_this: Any) -> bool:
		return a_this.i_currentIndex < a_this.i_numberOfTokens
	
	def nextToken (a_this: Any) -> str:
		a_this.i_currentIndex += 1
		return a_this.i_tokens [a_this.i_currentIndex - 1]

