from collections import OrderedDict
from typing import cast
from typing import Dict
from typing import Type
from typing import TypeVar
from typing import Union
from collections import Sequence

T = TypeVar ("T")
U = TypeVar ("U")

class MapsFactory:
	@staticmethod
	def createOrderedMap (a_type0: Type [T], a_type1: Type [U], *a_alternatelyKeyAndValue: Union [T, U]) -> "OrderedDict [T, U]":
		l_orderedMap: "OrderedDict [T, U]" = OrderedDict ()
		l_currentArgumentIsKey: bool = True
		l_key: T
		if not (a_alternatelyKeyAndValue is None):
			l_keyOrValue: Union [T, U]
			for l_keyOrValue in a_alternatelyKeyAndValue:
				if (l_currentArgumentIsKey):
					l_key = cast (T, l_keyOrValue)
					l_currentArgumentIsKey = False
				else:
					l_orderedMap.update ( {l_key: cast (U, l_keyOrValue)})
					l_currentArgumentIsKey = True
		else:
			None
		return l_orderedMap
	
	@staticmethod
	def createOrderedMapExpandingItems (a_type0: Type [T], a_type1: Type [U], *a_alternatelyKeyAndValueOrMaps: Union [T, U, Dict [T, U]]) -> "OrderedDict [T, U]":
		l_orderedMap: "OrderedDict [T, U]" = OrderedDict ()
		l_currentArgumentIsKey: bool = True
		l_key: T
		l_currentArgumentIsMap: bool = False
		if not (a_alternatelyKeyAndValueOrMaps is None):
			l_keyOrValueOrMap: Union [T, U, Dict [T, U]]
			for l_keyOrValueOrMap in a_alternatelyKeyAndValueOrMaps:
				l_currentArgumentIsMap = False
				if isinstance (l_keyOrValueOrMap, Dict):  
					l_currentArgumentIsMap = True
				if l_currentArgumentIsMap:
					l_map: Dict [T, U] = cast (Dict [T, U], l_keyOrValueOrMap)
					l_elementKey: T
					l_elementValue: U
					for (l_elementKey, l_elementValue) in l_map.items ():
						l_orderedMap.update ({l_elementKey: l_elementValue})
					l_currentArgumentIsKey = True
				else:
					if l_currentArgumentIsKey:
						l_key = cast (T, l_keyOrValueOrMap)
						l_currentArgumentIsKey = False
					else:
						l_orderedMap.update ({l_key: cast (U, l_keyOrValueOrMap)})
						l_currentArgumentIsKey = True
		else:
			None
		return l_orderedMap

