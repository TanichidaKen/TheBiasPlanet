namespace theBiasPlanet {
	namespace coreUtilities {
		namespace performanceMeasuring {
			using System;
			
			public sealed class PerformanceMeasurer {
				private static DateTime s_startTime;
				
				public static void setStartTime () {
					s_startTime = DateTime.Now;
				}
				
				public static long getElapseTimeInNanoSeconds () {
					return (long) ((DateTime.Now - s_startTime).TotalMilliseconds * 1000);
				}
				
				public static long getElapseTimeInMicroSeconds () {
					return (long) (DateTime.Now - s_startTime).TotalMilliseconds;
				}
			}
		}
	}
}

