package theBiasPlanet.basicCompiler.programs;

import java.time.LocalDateTime;
import java.util.Locale;
import theBiasPlanet.coreUtilities.constantsGroups.*;
import theBiasPlanet.coreUtilities.messaging.Publisher;
import theBiasPlanet.unoUtilities.connectionsHandling.UnoConnection;
import theBiasPlanet.unoUtilities.connectionsHandling.UnoConnectionConnector;
import theBiasPlanet.unoUtilities.connectionsHandling.UnoObjectsContext;
import theBiasPlanet.unoUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.officeInstancesHandling.OfficeInstance;
import theBiasPlanet.unoUtilities.programsHandling.UnoProcessEnvironment;

public class BasicCompilerConsoleProgram {
	public static void main (String [] a_argumentsArray) throws Exception {
		Publisher.setLoggingLevel (2);
		int l_resultStatus = -1;
		try {
			if (a_argumentsArray.length < 2) {
				throw new Exception ("The arguments have to be this.\nThe argument 1: the server url like 'socket,host=localhost,port=2002,tcpNoDelay=1;urp;StarOffice.ComponentContext'\nThe argument 2: the Basic source base path\nThe argument 3: the library name\nThe argument 5: the module name");
			}
			String l_unoServerUrl = a_argumentsArray [0];
			String l_basicSourceBasePath = a_argumentsArray [1];
			String l_libraryName = null;
			String l_moduleName = null;
			if (a_argumentsArray.length >= 3) {
				l_libraryName = a_argumentsArray [2];
				if (a_argumentsArray.length >= 4) {
					l_moduleName = a_argumentsArray [3];
				}
			}
			UnoProcessEnvironment l_localUnoProcessEnvironment = new UnoProcessEnvironment (LocalDateTime.now ().toString (), null);
			UnoConnectionConnector l_unoConnectionConnector = new UnoConnectionConnector (l_localUnoProcessEnvironment.getLocalObjectsContext ());
			UnoConnection l_unoConnection = l_unoConnectionConnector.connect (l_unoServerUrl, null);
			UnoObjectsContext l_remoteUnoObjectsContext = l_unoConnection.getRemoteObjectsContext ();
			OfficeInstance l_officeInstance = new OfficeInstance (l_remoteUnoObjectsContext, l_basicSourceBasePath);
			l_resultStatus = l_officeInstance.compileUserBasicScript (l_libraryName, l_moduleName) ? 0: -1;
			l_unoConnection.disconnect ();
		}
		catch (Exception l_exception) {
			Publisher.logErrorInformation (l_exception);
			System.exit (l_resultStatus);
		}
		System.exit (l_resultStatus);
	}
}

