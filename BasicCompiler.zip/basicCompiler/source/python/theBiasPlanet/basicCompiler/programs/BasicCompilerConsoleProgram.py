from datetime import datetime
import sys
from typing import List
from typing import Optional
import uno
from theBiasPlanet.coreUtilities.messaging.Publisher import Publisher
from theBiasPlanet.unoUtilities.connectionsHandling.UnoConnection import UnoConnection
from theBiasPlanet.unoUtilities.connectionsHandling.UnoConnectionConnector import UnoConnectionConnector
from theBiasPlanet.unoUtilities.connectionsHandling.UnoObjectsContext import UnoObjectsContext
from theBiasPlanet.unoUtilities.officeInstancesHandling.OfficeInstance import OfficeInstance
from theBiasPlanet.unoUtilities.programsHandling.UnoProcessEnvironment import UnoProcessEnvironment

class BasicCompilerConsoleProgram:
	@staticmethod
	def main (a_arguments: List [str]) -> None:
		Publisher.setLoggingLevel (2)
		l_resultStatus: int = -1
		try:
			if len (a_arguments) < 3:
				raise Exception ("The arguments have to be this.\nThe argument 1: the server url like 'socket,host=localhost,port=2002,tcpNoDelay=1;urp;StarOffice.ComponentContext'\nThe argument 2: the Basic source base path\nThe argument 3: the library name\nThe argument 5: the module name")
			l_unoServerUrl: str = a_arguments [1]
			l_basicSourceBasePath: str = a_arguments [2]
			l_containerName: str = "application"
			l_libraryName: Optional [str] = None
			l_moduleName: Optional [str] = None
			if len (a_arguments) >= 4:
				l_libraryName = a_arguments [3]
				if len (a_arguments) >= 5:
					l_moduleName = a_arguments [4]
			l_localUnoProcessEnvironment: "UnoProcessEnvironment" = UnoProcessEnvironment (str (datetime.now ()), None)
			l_unoConnectionConnector: "UnoConnectionConnector" = UnoConnectionConnector (l_localUnoProcessEnvironment.getLocalObjectsContext ())
			l_unoConnection: "UnoConnection" = l_unoConnectionConnector.connect (l_unoServerUrl, None)
			l_remoteUnoObjectsContext: "Optional [UnoObjectsContext]" = l_unoConnection.getRemoteObjectsContext ()
			if not (l_remoteUnoObjectsContext is None):
				l_officeInstance: "OfficeInstance" = OfficeInstance (l_remoteUnoObjectsContext, l_basicSourceBasePath)
				if not (l_moduleName is None):
					if not (l_libraryName is None):
						l_resultStatus = 0 if l_officeInstance.compileBasicScript (l_containerName, l_libraryName, l_moduleName) else -1
				else:
					l_resultStatus = 0 if l_officeInstance.compileUserBasicScript (l_libraryName) else -1
				l_unoConnection.disconnect ()
		except (Exception) as l_exception:
			Publisher.logErrorInformation (l_exception)
			sys.exit (l_resultStatus)
		sys.exit (l_resultStatus)

if __name__ == "__main__":
	BasicCompilerConsoleProgram.main (sys.argv)

