#ifndef __theBiasPlanet_unoUtilities_filesConverting_FilesConverter_hpp__
	#define __theBiasPlanet_unoUtilities_filesConverting_FilesConverter_hpp__
	
	#include <optional>
	#include <com/sun/star/beans/PropertyValue.hpp>
	#include <com/sun/star/uno/Any.hxx>
	#include <com/sun/star/uno/Reference.hxx>
	#include <com/sun/star/uno/Sequence.hxx>
	#include <com/sun/star/util/URL.hpp>
	#include "theBiasPlanet/unoUtilities/connectionsHandling/UnoObjectsContext.hpp"
	#include "theBiasPlanet/unoUtilities/documentsHandling/UnoDocumentTailor.hpp"
	#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	using namespace ::com::sun::star::beans;
	using namespace ::com::sun::star::frame;
	using namespace ::com::sun::star::uno;
	using namespace ::com::sun::star::util;
	using namespace ::rtl;
	using namespace ::theBiasPlanet::unoUtilities::connectionsHandling;
	using namespace ::theBiasPlanet::unoUtilities::documentsHandling;
	
	namespace theBiasPlanet {
		namespace unoUtilities {
			namespace filesConverting {
				class __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ FilesConverter {
					private:
						Reference <UnoObjectsContext> i_remoteUnoObjectsContext;
						Sequence <PropertyValue> i_unoDocumentOpeningPropertiesSequence;
						Reference <XSynchronousDispatch> i_fileOpeningUnoDispatcherInXSynchronousDispatch;
					public:
						FilesConverter (Reference <UnoObjectsContext> a_remoteUnoObjectsContext);
						~FilesConverter  ();
						virtual bool convertFile (string const & a_convertedFileUrl, string const & a_targetFileUrl, Sequence <PropertyValue> & a_documentStoringPropertiesSequence, UnoDocumentTailor * a_unoDocumentTailor);
				};
			}
		}
	}
#endif

