#ifndef __theBiasPlanet_unoUtilities_constantsGroups_propertyNamesSets_UnoObjectsContextPropertyNamesSet_hpp__
	#define __theBiasPlanet_unoUtilities_constantsGroups_propertyNamesSets_UnoObjectsContextPropertyNamesSet_hpp__
	
	#include <string>
	#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	
	namespace theBiasPlanet {
		namespace unoUtilities {
			namespace constantsGroups {
				namespace propertyNamesSets {
					class __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ UnoObjectsContextPropertyNamesSet {
						public:
							static string const c_identification_string;
					};
				}
			}
		}
	}
#endif

