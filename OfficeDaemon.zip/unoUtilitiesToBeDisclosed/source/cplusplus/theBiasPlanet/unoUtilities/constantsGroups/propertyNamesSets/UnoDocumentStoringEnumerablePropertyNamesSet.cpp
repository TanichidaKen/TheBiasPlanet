#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/UnoDocumentStoringEnumerablePropertyNamesSet.hpp"

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			namespace propertyNamesSets {
				UnoDocumentStoringEnumerablePropertyNamesSet::UnoDocumentStoringEnumerablePropertyNamesSet () : BaseEnumerableConstantsGroup <string> ( { {"c_filterName_String", c_filterName_String}, {"c_filterData_Object", c_filterData_Object}, {"c_isTemplate_Boolean", c_isTemplate_Boolean}, {"c_authorName_String", c_authorName_String}, {"c_title_String", c_title_String}, {"c_password_String", c_password_String}, {"c_charactersSet_String", c_charactersSet_String}, {"c_version_Short", c_version_Short}, {"c_description_String", c_description_String}, {"c_overwrites_Boolen", c_overwrites_Boolen}, {"c_documentTypeSpecificData_Object", c_documentTypeSpecificData_Object}}) {
				}
			}
		}
	}
}

