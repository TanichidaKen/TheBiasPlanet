#include "theBiasPlanet/unoUtilities/constantsGroups/propertyNamesSets/UnoDocumentOpeningEnumerablePropertyNamesSet.hpp"

namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			namespace propertyNamesSets {
				UnoDocumentOpeningEnumerablePropertyNamesSet::UnoDocumentOpeningEnumerablePropertyNamesSet () : BaseEnumerableConstantsGroup <string> ({ {"c_readOnly_Boolean", c_readOnly_Boolean}, {"c_hidden_Boolean", c_hidden_Boolean}, {"c_openNewView_Boolean", c_openNewView_Boolean}, {"c_silent_Boolean", c_silent_Boolean}})  {
				}
			}
		}
	}
}

