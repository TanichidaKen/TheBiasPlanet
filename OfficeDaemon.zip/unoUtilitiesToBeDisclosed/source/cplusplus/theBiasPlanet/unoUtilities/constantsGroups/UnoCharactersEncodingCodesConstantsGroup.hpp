#ifndef __theBiasPlanet_unoUtilities_constantsGroups_UnoCharactersEncodingCodesConstantsGroup_hpp__
	#define __theBiasPlanet_unoUtilities_constantsGroups_UnoCharactersEncodingCodesConstantsGroup_hpp__
	
	#include <string>
	#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	
	namespace theBiasPlanet {
		namespace unoUtilities {
			namespace constantsGroups {
				class __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ UnoCharactersEncodingCodesConstantsGroup {
					public:
						static int const c_utf8;
						static int const c_ucs2;
						static int const c_ucs4;
						static int const c_usAscii;
						static int const c_eucJp;
						static int const c_shiftJis;
				};
			}
		}
	}
#endif

