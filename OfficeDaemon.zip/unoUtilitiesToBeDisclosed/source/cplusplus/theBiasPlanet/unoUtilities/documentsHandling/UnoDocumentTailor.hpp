#ifndef __theBiasPlanet_unoUtilities_documentsHandling_UnoDocumentTailor_hpp__
	#define __theBiasPlanet_unoUtilities_documentsHandling_UnoDocumentTailor_hpp__
	
	#include <com/sun/star/lang/XComponent.hpp>
	#include <com/sun/star/uno/Reference.hxx>
	#include "theBiasPlanet/unoUtilities/connectionsHandling/UnoObjectsContext.hpp"
	#include "theBiasPlanet/unoUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	using namespace ::com::sun::star::frame;
	using namespace ::com::sun::star::uno;
	using namespace ::theBiasPlanet::unoUtilities::connectionsHandling;
	
	namespace theBiasPlanet {
		namespace unoUtilities {
			namespace documentsHandling {
				class __theBiasPlanet_unoUtilities_symbolExportingOrImportingForVisualCplusplus__ UnoDocumentTailor {
					protected:
						Reference <UnoObjectsContext> i_unoObjectsContext;
					public:
						UnoDocumentTailor (Reference <UnoObjectsContext> a_unoObjectsContext);
						virtual bool tailor (Reference <XComponent> a_unoDocumentInXComponent);
				};
			}
		}
	}
#endif

