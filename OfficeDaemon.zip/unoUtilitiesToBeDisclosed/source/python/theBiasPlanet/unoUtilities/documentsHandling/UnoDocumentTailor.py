from com.sun.star.frame import XModel
from com.sun.star.lang import XComponent
from theBiasPlanet.unoUtilities.pointers.UnoObjectPointer import UnoObjectPointer
from theBiasPlanet.unoUtilities.unoObjectsContexts.RemoteUnoObjectsContextInterface import RemoteUnoObjectsContextInterface

class UnoDocumentTailor:
	def __init__ (a_this: "UnoDocumentTailor", a_remoteUnoObjectsContext: "RemoteUnoObjectsContextInterface") -> None:
		a_this.i_remoteUnoObjectsContext: "RemoteUnoObjectsContextInterface"
		
		a_this.i_remoteUnoObjectsContext = a_remoteUnoObjectsContext
	
	def tailor (a_this: "UnoDocumentTailor", a_unoDocument: "UnoObjectPointer [XModel]") -> bool:
		return True

