from typing import cast
from typing import List
from typing import Optional
import threading
from threading import Condition
import time
import uno
from com.sun.star.container import ElementExistException
from com.sun.star.container import NoSuchElementException
from com.sun.star.frame import XModel
from com.sun.star.lang import DisposedException
from com.sun.star.lang import XComponent
from com.sun.star.util import XCloseable
from com.sun.star.util import CloseVetoException
from theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup import GeneralConstantsConstantsGroup
from theBiasPlanet.coreUtilities.messagingHandling.Publisher import Publisher
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.UnoObjectsContextPropertyNamesSet import UnoObjectsContextPropertyNamesSet
from theBiasPlanet.unoUtilities.displayElements.UnoDesktop import UnoDesktop
from theBiasPlanet.unoUtilities.documents.UnoDocument import UnoDocument
from theBiasPlanet.unoUtilities.inspectionsHandling.UnoComponentInspector import UnoComponentInspector
from theBiasPlanet.unoUtilities.pointers.UnoObjectPointer import UnoObjectPointer
from theBiasPlanet.unoUtilities.unoDataHandling.UnoDatumConverter import UnoDatumConverter
from theBiasPlanet.unoUtilities.unoObjectsContexts.RemoteUnoObjectsContextInterface import RemoteUnoObjectsContextInterface

class OfficeInstance:
	def __init__ (a_this: "OfficeInstance", a_remoteUnoObjectsContext: "RemoteUnoObjectsContextInterface", a_basicSourceBasePath: Optional [str]) -> None:
		a_this.i_remoteUnoObjectsContext: "RemoteUnoObjectsContextInterface"
		a_this.i_threadsCondition: Condition
		a_this.i_criticalSessionCount: int
		a_this.i_serverIsPlannedToBeTerminated: bool
		a_this.i_unoDesktop: "UnoDesktop"
		
		a_this.i_remoteUnoObjectsContext = a_remoteUnoObjectsContext
		a_this.i_threadsCondition =  Condition ()
		a_this.i_criticalSessionCount = 0;
		a_this.i_serverIsPlannedToBeTerminated = False
		a_this.i_unoDesktop = cast (UnoDesktop, a_this.i_remoteUnoObjectsContext.getLocalPropertyValue (UnoObjectsContextPropertyNamesSet.c_unoDesktopSingleton_string))
		if UnoDatumConverter.getObject (a_this.i_remoteUnoObjectsContext.getValueByName (UnoObjectsContextPropertyNamesSet.c_unoOfficeInstanceSingleton_string)) is None:
			try:
				a_this.i_remoteUnoObjectsContext.addExtraGlobalProperty (UnoObjectsContextPropertyNamesSet.c_unoOfficeInstanceSingleton_string, a_this)
			except (ElementExistException) as l_exception:
				None
	
	def __del__ (a_this: "OfficeInstance") ->None:
		None
	
	def incrementCriticalSessionCount (a_this: "OfficeInstance", a_connectionIdentification: str) -> bool:
		try:
			a_this.i_threadsCondition.acquire ()
			if a_this.i_serverIsPlannedToBeTerminated:
				return False
			else:
				a_this.i_criticalSessionCount = a_this.i_criticalSessionCount + 1
				return True
		finally:
			a_this.i_threadsCondition.release ()
	
	def decrementCriticalSessionCount (a_this: "OfficeInstance", a_connectionIdentification: str) -> None:
		try:
			a_this.i_threadsCondition.acquire ()
			a_this.i_criticalSessionCount = a_this.i_criticalSessionCount - 1
			if a_this.i_criticalSessionCount <= 0:
				a_this.i_threadsCondition.notifyAll ()
		finally:
			a_this.i_threadsCondition.release ()
	
	def getCriticalSessionCount (a_this: "OfficeInstance") -> int:
		try:
			a_this.i_threadsCondition.acquire ()
			return a_this.i_criticalSessionCount
		finally:
			a_this.i_threadsCondition.release ()
	
	def serverIsPlannedToBeTerminated (a_this: "OfficeInstance") -> bool:
		try:
			a_this.i_threadsCondition.acquire ()
			return a_this.i_serverIsPlannedToBeTerminated
		finally:
			a_this.i_threadsCondition.release ()
	
	def setServerAsPlannedToBeTerminated (a_this: "OfficeInstance") -> None:
		try:
			a_this.i_threadsCondition.acquire ()
			a_this.i_serverIsPlannedToBeTerminated = True
		finally:
			a_this.i_threadsCondition.release ()
	
	def waitUntilNoCriticalSession (a_this: "OfficeInstance", a_timeOutInMilliseconds: int) -> bool:
		try:
			a_this.i_threadsCondition.acquire ()
			if a_this.i_criticalSessionCount > 0:
				if a_timeOutInMilliseconds == GeneralConstantsConstantsGroup.c_unspecifiedInteger:
					a_this.i_threadsCondition.wait ()
					return True
				else:
					return a_this.i_threadsCondition.wait (a_timeOutInMilliseconds / 1000);
			else:
				return True
		finally:
			a_this.i_threadsCondition.release ()
	
	def terminate (a_this: "OfficeInstance", a_gracePeriodInMillisecondsBeforeForcing: int) -> bool:
		a_this.setServerAsPlannedToBeTerminated ()
		a_this.waitUntilNoCriticalSession (a_gracePeriodInMillisecondsBeforeForcing)
		l_unoObjects: List ["UnoObjectPointer [XComponent]"]  = a_this.i_unoDesktop.getChildObjects ()
		l_unoObject: "UnoObjectPointer [XComponent]" = None
		for l_unoObject in l_unoObjects:
			if l_unoObject.getAddress () is None:
				continue
			try:
				l_unoDocument: "UnoDocument" = UnoDocument (a_this.i_remoteUnoObjectsContext, UnoObjectPointer.getUnoObjectPointer (XModel, XComponent, l_unoObject))
				Publisher.logWarningInformation ("The document '{0:s}' is left opened.".format (l_unoDocument.getUrl ()))
				try:
					l_unoDocument.close ()
					Publisher.logWarningInformation ("The document '{0:s}' has been closed.".format (l_unoDocument.getUrl ()))
				except (CloseVetoException) as l_exception:
					Publisher.logWarningInformation ("The document '{0:s}' has been vetoed to be closed.".format (l_unoDocument.getUrl ()))
					l_unoObject.getAddress ().dispose ()
					Publisher.logWarningInformation ("The document '{0:s}' has been disposed.".format (l_unoDocument.getUrl ()))
				except (DisposedException) as l_exception:
					Publisher.logWarningInformation ("The document '{0:s}' has been disposed.".format (l_unoDocument.getUrl ()))
			except (Exception) as l_exception:
				Publisher.logErrorInformation ("An error has occurred: {0:s}.".format (str (l_exception)))
		try:
			a_this.i_remoteUnoObjectsContext.removeExtraGlobalProperty (UnoObjectsContextPropertyNamesSet.c_unoOfficeInstanceSingleton_string)
		except (NoSuchElementException) as l_exception:
			None
		except (Exception) as l_exception:
			None
		l_shutdownTryResult: bool = False
		# loops because the shutdown may be vetoed.
		try:
			while True:
				try:
					l_shutdownTryResult = a_this.i_unoDesktop.getUnderlyingUnoObject ().getAddress ().terminate ()
				except (DisposedException) as l_exception:
					return True
				if l_shutdownTryResult:
					return l_shutdownTryResult
				time.sleep (1000 / 1000)
		finally:
			None

