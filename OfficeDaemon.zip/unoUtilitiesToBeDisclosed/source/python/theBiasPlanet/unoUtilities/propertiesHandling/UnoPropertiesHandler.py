from typing import List
from typing import Optional
from typing import Type
from typing import TypeVar
import uno
from uno import Any
from com.sun.star.beans import PropertyValue
from theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup import GeneralConstantsConstantsGroup
from theBiasPlanet.unoUtilities.property.UnoProperty import UnoProperty
from theBiasPlanet.unoUtilities.unoDataHandling.UnoDatumConverter import UnoDatumConverter

class UnoPropertiesHandler:
	@staticmethod
	def buildProperties (a_propertyNames: List [str], a_propertyValues: List [object]) -> Optional [List [PropertyValue]]:
		if (a_propertyNames is None or a_propertyValues is None):
			return None
		else:
			l_properties: List [PropertyValue] = []
			l_propertyIndex: int = GeneralConstantsConstantsGroup.c_iterationStartingNumber
			l_propertyName: str
			l_propertyValue: object
			for l_propertyName in a_propertyNames:
				l_propertyValue = a_propertyValues [l_propertyIndex]
				l_properties.append (UnoProperty (l_propertyName, l_propertyValue))
				#l_properties.append (UnoProperty (l_propertyName, UnoDatumConverter.getAny (l_propertyValue)))
				l_propertyIndex += 1
			return l_properties

