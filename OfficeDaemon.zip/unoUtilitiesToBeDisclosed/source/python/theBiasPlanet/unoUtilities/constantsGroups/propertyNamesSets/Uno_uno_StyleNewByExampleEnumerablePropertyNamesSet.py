from theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup import BaseEnumerableConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.UnoPropertyNamesSet import UnoPropertyNamesSet

class Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet (BaseEnumerableConstantsGroup [str], UnoPropertyNamesSet):
	c_styleName_String: str = "Param"
	c_styleFamilyKey_Short: str = "Family"
	c_instance: "Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet"
	
	def __init__ (a_this: "Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet") -> None:
		BaseEnumerableConstantsGroup.__init__ (a_this, str)

Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet.c_instance = Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet ()

