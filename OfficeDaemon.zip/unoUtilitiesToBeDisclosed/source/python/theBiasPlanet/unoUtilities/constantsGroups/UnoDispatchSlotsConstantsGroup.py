from theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup import BaseEnumerableConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet import Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.Uno_uno_GoToCellEnumerablePropertyNamesSet import Uno_uno_GoToCellEnumerablePropertyNamesSet

class UnoDispatchSlotsConstantsGroup:
	# Base class for all the constants in this group
	class BaseDispatchSlot:
		def __init__ (a_this: "UnoDispatchSlotsConstantsGroup.BaseDispatchSlot", a_url: str, a_argumentPropertyNamesSet: "BaseEnumerableConstantsGroup [str]"):
			a_this.c_url: str
			a_this.c_argumentPropertyNamesSet: "BaseEnumerableConstantsGroup [str]"
			
			a_this.c_url = a_url
			a_this.c_argumentPropertyNamesSet = a_argumentPropertyNamesSet
	c__uno_StyleNewByExample: "BaseDispatchSlot" = BaseDispatchSlot (".uno:StyleNewByExample", Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet.c_instance)
	c__uno_GoToCell: "BaseDispatchSlot" = BaseDispatchSlot (".uno:GoToCell", Uno_uno_GoToCellEnumerablePropertyNamesSet.c_instance)

