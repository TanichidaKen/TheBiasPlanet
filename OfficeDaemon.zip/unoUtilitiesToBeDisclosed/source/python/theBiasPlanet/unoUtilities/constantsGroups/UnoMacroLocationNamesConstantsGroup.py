
class UnoMacroLocationNamesConstantsGroup:
	c_userInPlace: str = "user";
	c_userInExtension: str = "user:uno_packages";
	c_applicationInPlace: str = "share";
	c_applicationInExtension: str = "share:uno_packages";
	c_document: str = "document";

