import re
from typing import cast
from typing import List
from typing import Optional
import uno
from com.sun.star.beans import PropertyValue
from com.sun.star.document import XDocumentEventBroadcaster
from com.sun.star.document import XDocumentEventListener
from com.sun.star.frame import XController
from com.sun.star.frame import XFrame
from com.sun.star.frame import XModel
from com.sun.star.frame import XStorable2
from com.sun.star.script.provider import XScript
from com.sun.star.script.provider import XScriptProvider
from com.sun.star.script.provider import XScriptProviderSupplier
from com.sun.star.util import XCloseable
from theBiasPlanet.coreUtilities.collectionsHandling.ListsFactory import ListsFactory
from theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup import GeneralConstantsConstantsGroup
from theBiasPlanet.coreUtilities.constantsGroups.RegularExpressionsConstantsGroup import RegularExpressionsConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.UnoGeneralConstantsConstantsGroup import UnoGeneralConstantsConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.UnoMacroLocationNamesConstantsGroup import UnoMacroLocationNamesConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.UnoMessagesConstantsGroup import UnoMessagesConstantsGroup
from theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.UnoDocumentStoringEnumerablePropertyNamesSet import UnoDocumentStoringEnumerablePropertyNamesSet
from theBiasPlanet.unoUtilities.displayElements.UnoDesktop import UnoDesktop
from theBiasPlanet.unoUtilities.displayElements.UnoFrame import UnoFrame
from theBiasPlanet.unoUtilities.pointers.UnoObjectPointer import UnoObjectPointer
from theBiasPlanet.unoUtilities.propertiesHandling.UnoPropertiesHandler import UnoPropertiesHandler
from theBiasPlanet.unoUtilities.unoObjectsContexts.RemoteUnoObjectsContextInterface import RemoteUnoObjectsContextInterface

class UnoDocument ():
	def __init__ (a_this: "UnoDocument", a_remoteUnoObjectsContext: "RemoteUnoObjectsContextInterface", a_underlyingUnoObject: "UnoObjectPointer [XModel]") -> None:
		a_this.i_remoteUnoObjectsContext: "RemoteUnoObjectsContextInterface"
		a_this.i_underlyingUnoObject: "UnoObjectPointer [XModel]"
		a_this.i_unoController: "UnoObjectPointer [XController]"
		a_this.i_unoFrame: "UnoFrame"
		a_this.i_macrosProvider: "UnoObjectPointer [XScriptProvider]"
		
		if a_remoteUnoObjectsContext is None:
			raise Exception (UnoMessagesConstantsGroup.c_unoObjectsContextNotSpecified)
		a_this.i_remoteUnoObjectsContext = a_remoteUnoObjectsContext
		if a_underlyingUnoObject is None:
			raise Exception (UnoMessagesConstantsGroup.c_unoDocumentNotSpecified)
		a_this.i_underlyingUnoObject = a_underlyingUnoObject
		a_this.i_unoController = UnoObjectPointer (XController, a_this.i_underlyingUnoObject.getAddress ().getCurrentController ())
		a_this.i_unoFrame = UnoFrame (a_this.i_remoteUnoObjectsContext, UnoObjectPointer (XFrame, a_this.i_unoController.getAddress ().getFrame ()))
		a_this.i_macrosProvider = UnoObjectPointer (XScriptProvider, a_this.i_underlyingUnoObject.getAddress ().getScriptProvider ())
	
	def __del__ (a_this: "UnoDocument") -> None:
		None
	
	@staticmethod
	def openDocumentFile (a_unoDesktop: "UnoDesktop", a_fileUrl: str, a_password: str, a_unoDocumentIsHidden: bool) -> "UnoDocument":
		return UnoDocument (a_unoDesktop.getRemoteUnoObjectsContext (), a_unoDesktop.loadUnoDocument (a_fileUrl, a_password, a_unoDocumentIsHidden))
	
	@staticmethod
	def getCurrentDocument (a_unoDesktop: "UnoDesktop") -> "UnoDocument":
		return UnoDocument (a_unoDesktop.getRemoteUnoObjectsContext (), a_unoDesktop.getCurrentDocument ())
	
	def getRemoteUnoObjectsContext (a_this: "UnoDocument") -> "RemoteUnoObjectsContextInterface":
		return a_this.i_remoteUnoObjectsContext
	
	def getUnderlyingUnoObject (a_this: "UnoDocument") -> "UnoObjectPointer [XModel]":
		return a_this.i_underlyingUnoObject
	
	def getUnoFrame (a_this: "UnoDocument") -> "UnoFrame":
		return a_this.i_unoFrame
	
	def store (a_this: "UnoDocument") -> None:
		a_this.storeAtUrl (a_this.getUrl ())
	
	def storeAtUrl (a_this: "UnoDocument", a_fileUrl: str) -> None:
		a_this.i_underlyingUnoObject.getAddress ().storeToURL (re.sub (RegularExpressionsConstantsGroup.c_windowsDirectoryDelimiterRegularExpression, GeneralConstantsConstantsGroup.c_linuxDirectoriesDelimiter, a_fileUrl), cast (List [PropertyValue], []))
	
	# Use UnoSpreadSheetsDocumentStoringFilterNamesConstantsGroup for a_filterName.
	def storeAtUrl_1 (a_this: "UnoDocument", a_fileUrl: str, a_filterName: str, a_filterData: object) -> None:
		a_this.i_underlyingUnoObject.getAddress ().storeToURL (re.sub (RegularExpressionsConstantsGroup.c_windowsDirectoryDelimiterRegularExpression, GeneralConstantsConstantsGroup.c_linuxDirectoriesDelimiter, a_fileUrl), UnoPropertiesHandler.buildProperties (UnoDocumentStoringEnumerablePropertyNamesSet.c_instance.getValues (), ListsFactory.createList (object, a_filterName, a_filterData)))
	
	def getUrl (a_this: "UnoDocument") -> str:
		return a_this.i_underlyingUnoObject.getAddress ().getLocation ()
	
	def addEventsListener (a_this: "UnoDocument", a_eventsListener: XDocumentEventListener) -> bool:
		a_this.i_underlyingUnoObject.getAddress ().addDocumentEventListener (a_eventsListener)
		return True
	
	def  removeEventsListener (a_this: "UnoDocument", a_eventsListener: XDocumentEventListener) -> bool:
		a_this.i_underlyingUnoObject.getAddress ().removeDocumentEventListener (a_eventsListener)
		return True
	
	def close (a_this: "UnoDocument") -> None:
		a_this.i_underlyingUnoObject.getAddress ().close (False)
	
	def invokeMacro (a_this: "UnoDocument", a_macroProgrammingLanguageName: str, a_macroPathString: str, a_macroArguments: List [object], a_macroOutputArgumentIndexes: List [int], a_macroOutputArguments: List [object]) -> object:
		l_macroUrl: str = UnoGeneralConstantsConstantsGroup.c_macroUrlFormat.format (a_macroPathString, a_macroProgrammingLanguageName, UnoMacroLocationNamesConstantsGroup.c_document)
		l_macroHandler: "UnoObjectPointer [XScript]" = UnoObjectPointer (XScript, a_this.i_macrosProvider.getAddress ().getScript (l_macroUrl))
		return l_macroHandler.getAddress ().invoke (a_macroArguments, a_macroOutputArgumentIndexes, a_macroOutputArguments)

