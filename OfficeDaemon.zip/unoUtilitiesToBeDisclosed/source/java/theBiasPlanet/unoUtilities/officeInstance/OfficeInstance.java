package theBiasPlanet.unoUtilities.officeInstance;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;
import com.sun.star.container.ElementExistException;
import com.sun.star.container.NoSuchElementException;
import com.sun.star.frame.XDesktop;
import com.sun.star.frame.XModel;
import com.sun.star.lang.DisposedException;
import com.sun.star.lang.XComponent;
import com.sun.star.util.CloseVetoException;
import com.sun.star.util.XCloseable;
import theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup;
import theBiasPlanet.coreUtilities.messagingHandling.Publisher;
import theBiasPlanet.unoDatumTypes.unoUtilities.officeInstance.XOfficeInstance;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.UnoObjectsContextPropertyNamesSet;
import theBiasPlanet.unoUtilities.displayElements.UnoDesktop;
import theBiasPlanet.unoUtilities.documents.UnoDocument;
import theBiasPlanet.unoUtilities.pointers.UnoObjectPointer;
import theBiasPlanet.unoUtilities.unoComponentBases.UnoComponentBase;
import theBiasPlanet.unoUtilities.unoDataHandling.UnoDatumConverter;
import theBiasPlanet.unoUtilities.unoObjectsContexts.RemoteUnoObjectsContext;

public class OfficeInstance extends UnoComponentBase implements XOfficeInstance {
	private RemoteUnoObjectsContext i_remoteUnoObjectsContext = null;
	private ReentrantLock i_threadsLock;
	private Condition i_threadsCondition;
	private int i_criticalSessionCount;
	private boolean i_serverIsPlannedToBeTerminated;
	private UnoDesktop i_unoDesktop;
	
	private void lock () {
		i_threadsLock.lock ();
	}
	
	private void unlock () {
		i_threadsLock.unlock ();
	}
	
	public OfficeInstance (RemoteUnoObjectsContext a_remoteUnoObjectsContext) throws Exception {
		i_remoteUnoObjectsContext = a_remoteUnoObjectsContext;
		i_criticalSessionCount = 0;
		i_serverIsPlannedToBeTerminated = false;
		i_threadsLock = new ReentrantLock ();
		i_threadsCondition = i_threadsLock.newCondition ();
		i_unoDesktop = (UnoDesktop) (i_remoteUnoObjectsContext.getLocalPropertyValue (UnoObjectsContextPropertyNamesSet.c_unoDesktopSingleton_string));
		if (UnoDatumConverter.getObject (i_remoteUnoObjectsContext.getValueByName (UnoObjectsContextPropertyNamesSet.c_unoOfficeInstanceSingleton_string)) == null) {
			try {
				i_remoteUnoObjectsContext.addExtraGlobalProperty (UnoObjectsContextPropertyNamesSet.c_unoOfficeInstanceSingleton_string, this);
			}
			catch (ElementExistException l_exception) {
			}
		}
	}
	
	@Override
	protected void finalize () {
	}
	
	@Override
	public boolean incrementCriticalSessionCount (String a_connectionIdentification) {
		try {
			lock ();
			if (i_serverIsPlannedToBeTerminated) {
				return false;
			}
			else {
				i_criticalSessionCount ++;
				return true;
			}
		}
		finally {
			unlock ();
		}
	}
	
	@Override
	public void decrementCriticalSessionCount (String a_connectionIdentification) {
		try {
			lock ();
			i_criticalSessionCount --;
			if (i_criticalSessionCount <= 0) {
				i_threadsCondition.signal ();
			}
		}
		finally {
			unlock ();
		}
	}
	
	@Override
	public int getCriticalSessionCount () {
		try {
			lock ();
			return i_criticalSessionCount;
		}
		finally {
			unlock ();
		}
	}
	
	@Override
	public boolean serverIsPlannedToBeTerminated () {
		try {
			lock ();
			return i_serverIsPlannedToBeTerminated;
		}
		finally {
			unlock ();
		}
	}
	
	public void setServerAsPlannedToBeTerminated () {
		try {
			lock ();
			i_serverIsPlannedToBeTerminated = true;
		}
		finally {
			unlock ();
		}
	}
	
	public boolean waitUntilNoCriticalSession (int a_timeOutInMilliseconds) {
		try {
			lock ();
			if (i_criticalSessionCount > 0) {
				try {
					if (a_timeOutInMilliseconds == GeneralConstantsConstantsGroup.c_unspecifiedInteger) {
						i_threadsCondition.await ();
						return true;
					}
					else {
						return i_threadsCondition.await (a_timeOutInMilliseconds, TimeUnit.MILLISECONDS);
					}
				}
				catch (InterruptedException l_exception) {
					return false;
				}
			}
			else {
				return true;
			}
		}
		finally {
			unlock ();
		}
	}
	
	public boolean terminate (int a_gracePeriodInMillisecondsBeforeForcing) {
		setServerAsPlannedToBeTerminated ();
		waitUntilNoCriticalSession (a_gracePeriodInMillisecondsBeforeForcing);
		List <UnoObjectPointer <XComponent>> l_unoObjects = i_unoDesktop.getChildObjects ();
		for (UnoObjectPointer <XComponent> l_unoObject: l_unoObjects) {
			if (l_unoObject. <XCloseable>getAddress (XCloseable.class) == null) {
				continue;
			}
			try {
				UnoDocument l_unoDocument = new UnoDocument (i_remoteUnoObjectsContext, new UnoObjectPointer <XModel> (l_unoObject, XModel.class));
				Publisher.logWarningInformation (String.format ("The document '%s' is left opened.", l_unoDocument.getUrl ()));
				try {
					l_unoDocument.close ();
					Publisher.logWarningInformation (String.format ("The document '%s' has been closed.", l_unoDocument.getUrl ()));
				}
				catch (CloseVetoException l_exception) {
					Publisher.logWarningInformation (String.format ("The document '%s' has been vetoed to be closed.", l_unoDocument.getUrl ()));
					l_unoObject.getAddress ().dispose ();
					Publisher.logWarningInformation (String.format ("The document '%s' has been disposed.", l_unoDocument.getUrl ()));
				}
				catch (DisposedException l_exception) {
					Publisher.logWarningInformation (String.format ("The document '%s' has been disposed.", l_unoDocument.getUrl ()));
				}
			}
			catch (Exception l_exception) {
				Publisher.logErrorInformation (String.format ("An error has occurred: %s.", l_exception.toString ()));
			}
		}
		try {
			i_remoteUnoObjectsContext.removeExtraGlobalProperty (UnoObjectsContextPropertyNamesSet.c_unoOfficeInstanceSingleton_string);
		}
		catch (NoSuchElementException l_exception) {
		}
		catch (Exception l_exception) {
		}
		boolean l_shutdownTryResult = false;
		// loops because the shutdown may be vetoed.
		try {
			while (true) {
				try {
					l_shutdownTryResult = i_unoDesktop.getUnderlyingUnoObject (). <XDesktop>getAddress (XDesktop.class).terminate ();
				}
				catch (DisposedException l_exception) {
					return true;
				}
				if (l_shutdownTryResult) {
					return l_shutdownTryResult;
				}
				try {
					Thread.sleep (1000);
				}
				catch (InterruptedException l_exception) {
				}
			}
		}
		finally {
		}
	}
}

