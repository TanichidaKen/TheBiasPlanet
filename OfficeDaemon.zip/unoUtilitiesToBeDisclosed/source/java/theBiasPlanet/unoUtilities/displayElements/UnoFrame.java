package theBiasPlanet.unoUtilities.displayElements;

import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.List;
import com.sun.star.awt.XWindow;
import com.sun.star.beans.PropertyValue;
import com.sun.star.container.XIndexAccess;
import com.sun.star.frame.DispatchResultEvent;
import com.sun.star.frame.FeatureStateEvent;
import com.sun.star.frame.XDispatchProvider;
import com.sun.star.frame.XDispatchResultListener;
import com.sun.star.frame.XFrame;
import com.sun.star.frame.XFramesSupplier;
import com.sun.star.frame.XNotifyingDispatch;
import com.sun.star.frame.XStatusListener;
import com.sun.star.lang.EventObject;
import com.sun.star.uno.UnoRuntime;
import theBiasPlanet.coreUtilities.collectionsHandling.ListsFactory;
import theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup;
import theBiasPlanet.coreUtilities.messagingHandling.Publisher;
import theBiasPlanet.unoUtilities.constantsGroups.UnoDispatchSlotsConstantsGroup;
import theBiasPlanet.unoUtilities.constantsGroups.UnoSpecialFrameNamesConstantsGroup;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.UnoDispatchesCommonArgumentEnumerablePropertyNamesSet;
import theBiasPlanet.unoUtilities.dispatchingHandling.UnoDispatchResultAndRelatedInformation;
import theBiasPlanet.unoUtilities.pointers.UnoObjectPointer;
import theBiasPlanet.unoUtilities.propertiesHandling.UnoPropertiesHandler;
import theBiasPlanet.unoUtilities.unoComponentBases.UnoComponentBase;
import theBiasPlanet.unoUtilities.unoDataHandling.UnoDatumConverter;
import theBiasPlanet.unoUtilities.unoObjectsContexts.RemoteUnoObjectsContext;

public class UnoFrame extends UnoComponentBase implements XDispatchResultListener, XStatusListener {
	protected RemoteUnoObjectsContext i_remoteUnoObjectsContext = null;
	protected UnoObjectPointer <XFrame> i_underlyingUnoObject;
	protected UnoObjectPointer <XWindow> i_containerWindow = null;
	protected UnoDispatchResultAndRelatedInformation i_dispatchResultAndRelatedInformation = null;
	
	public UnoFrame (RemoteUnoObjectsContext a_remoteUnoObjectsContext, UnoObjectPointer <XFrame> a_underlyingUnoObject) {
		i_remoteUnoObjectsContext = a_remoteUnoObjectsContext;
		i_underlyingUnoObject = a_underlyingUnoObject;
		i_containerWindow = new UnoObjectPointer <XWindow> (i_underlyingUnoObject.getAddress ().getContainerWindow ());
	}
	
	@Override
	public void finalize () {
	}
	
	@Override
	public void dispatchFinished (DispatchResultEvent a_dispatchResultEvent) {
		i_dispatchResultAndRelatedInformation.setResult (a_dispatchResultEvent);
	}
	
	@Override
	public void statusChanged (FeatureStateEvent a_relatedInformationPieceEvent) {
		i_dispatchResultAndRelatedInformation.addRelatedInformationPiece (a_relatedInformationPieceEvent);
	}
	
	@Override
	public void disposing (EventObject a_source) {
	}
	
	public RemoteUnoObjectsContext getRemoteUnoObjectsContext () {
		return i_remoteUnoObjectsContext;
	}
	
	public UnoObjectPointer <XFrame> getUnderlyingUnoObject () {
		return i_underlyingUnoObject;
	}
	
	public Rectangle getBoundary () throws com.sun.star.uno.Exception {
		if (! (i_containerWindow.isEmpty ())) {
			com.sun.star.awt.Rectangle l_boundary = i_containerWindow.getAddress ().getPosSize ();
			return new Rectangle (l_boundary.X, l_boundary.Y, l_boundary.Width, l_boundary.Height);
		}
		return null;
	}
	
	public UnoObjectPointer <XIndexAccess> getChildFramesIterator () {
		UnoObjectPointer <XIndexAccess> l_unoFramesIterator = new UnoObjectPointer <XIndexAccess> (i_underlyingUnoObject.getAddress (XFramesSupplier.class).getFrames ());
		return l_unoFramesIterator;
	}
	
	public List <UnoFrame> getChildFrames () {
		ArrayList <UnoFrame> l_childUnoFrames = null;
		UnoObjectPointer <XIndexAccess> l_unoFramesIterator = getChildFramesIterator ();
		int l_numberOfChildUnoFrames = l_unoFramesIterator.getAddress ().getCount ();
		if (l_numberOfChildUnoFrames > 0) {
			l_childUnoFrames = new ArrayList <UnoFrame> ();
			for (int l_unoFrameIndex = 0; l_unoFrameIndex < l_numberOfChildUnoFrames; l_unoFrameIndex ++) {
				try {
					l_childUnoFrames.add (new UnoFrame (i_remoteUnoObjectsContext, new UnoObjectPointer <XFrame> ( (XFrame) UnoDatumConverter.getObject (l_unoFramesIterator.getAddress ().getByIndex (l_unoFrameIndex)))));
				}
				catch (Exception l_exception) {
					Publisher.logErrorInformation (l_exception);
				}
			}
		}
		return l_childUnoFrames;
	}
	
	public UnoObjectPointer <XNotifyingDispatch> getUnoDispatcher (com.sun.star.util.URL a_urlInURL) {
		return new UnoObjectPointer <XNotifyingDispatch> (i_underlyingUnoObject. <XDispatchProvider>getAddress (XDispatchProvider.class).queryDispatch (a_urlInURL, UnoSpecialFrameNamesConstantsGroup.c_self, GeneralConstantsConstantsGroup.c_unspecifiedInteger), XNotifyingDispatch.class);
	}
	
	public UnoDispatchResultAndRelatedInformation fulfill (UnoDispatchSlotsConstantsGroup.BaseUnoDispatchSlot a_unoDispatchSlot, List <Object> a_unoDispatchArgumentValues) throws Exception {
		synchronized (this) {
			i_dispatchResultAndRelatedInformation = new UnoDispatchResultAndRelatedInformation ();
			PropertyValue [] l_unoDispatchArgumentPropertiesArray = null;
			if (a_unoDispatchSlot.c_unoDispatchArgumentPropertyNamesSet != null) {
				if (a_unoDispatchArgumentValues != null) {
					//l_unoDispatchArgumentPropertiesArray = UnoPropertiesHandler.buildPropertiesArray (ListsFactory. <String>createArrayListExpandingItems (UnoDispatchesCommonArgumentEnumerablePropertyNamesSet.c_instance.getValues (), a_unoDispatchSlot.c_unoDispatchArgumentPropertyNamesSet.getValues ()), ListsFactory. <Object>createArrayListExpandingItems (Boolean.valueOf (true), a_unoDispatchArgumentValues));
					l_unoDispatchArgumentPropertiesArray = UnoPropertiesHandler.buildPropertiesArray (ListsFactory. <String>createArrayListExpandingItems (UnoDispatchesCommonArgumentEnumerablePropertyNamesSet.c_instance.getValues (), a_unoDispatchSlot.c_unoDispatchArgumentPropertyNamesSet.getValues ()), ListsFactory. <Object>createArrayListExpandingItems (Boolean.valueOf (false), a_unoDispatchArgumentValues));
				}
				else {
					l_unoDispatchArgumentPropertiesArray = UnoPropertiesHandler.buildPropertiesArray (UnoDispatchesCommonArgumentEnumerablePropertyNamesSet.c_instance.getValues (), ListsFactory. <Object>createArrayList (Boolean.valueOf (true)));
				}
			}
			else {
				if (a_unoDispatchArgumentValues != null) {
					l_unoDispatchArgumentPropertiesArray = UnoPropertiesHandler.buildPropertiesArray (ListsFactory. <String>createArrayListExpandingItems (UnoDispatchesCommonArgumentEnumerablePropertyNamesSet.c_instance.getValues (), a_unoDispatchSlot.c_urlInURL.Path), ListsFactory. <Object>createArrayListExpandingItems (Boolean.valueOf (true), a_unoDispatchArgumentValues.get (0)));
				}
				else {
					l_unoDispatchArgumentPropertiesArray = UnoPropertiesHandler.buildPropertiesArray (UnoDispatchesCommonArgumentEnumerablePropertyNamesSet.c_instance.getValues (), ListsFactory. <Object>createArrayList (Boolean.valueOf (true)));
				}
			}
			com.sun.star.util.URL l_urlInURL = a_unoDispatchSlot.c_urlInURL;
			UnoObjectPointer <XNotifyingDispatch> l_unoDispatcher = getUnoDispatcher (l_urlInURL);
			if (l_unoDispatcher != null) {
				l_unoDispatcher.getAddress ().addStatusListener (this, l_urlInURL);
				l_unoDispatcher.getAddress ().dispatchWithNotification (l_urlInURL, l_unoDispatchArgumentPropertiesArray, this);
				l_unoDispatcher.getAddress ().removeStatusListener (this, l_urlInURL);
			}
			else {
				i_dispatchResultAndRelatedInformation = null;
			}
			return i_dispatchResultAndRelatedInformation;
		}
	}
}

