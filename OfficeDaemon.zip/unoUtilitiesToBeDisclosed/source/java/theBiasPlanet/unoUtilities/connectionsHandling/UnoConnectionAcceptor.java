package theBiasPlanet.unoUtilities.connectionsHandling;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import com.sun.star.connection.ConnectionSetupException;
import com.sun.star.connection.XAcceptor;
import theBiasPlanet.unoUtilities.connection.UnoConnection;
import theBiasPlanet.unoUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.unoObjectsContexts.LocalUnoObjectsContext;

public class UnoConnectionAcceptor extends UnoConnectionsFactory {
	private Map <String, XAcceptor> i_portNameToUnoConnectionAcceptorMap;
	XAcceptor i_acceptingUnoConnectionAcceptor;
	
	public UnoConnectionAcceptor (LocalUnoObjectsContext a_localUnoObjectsContext) throws com.sun.star.uno.Exception {
		super (a_localUnoObjectsContext);
		i_portNameToUnoConnectionAcceptorMap = new HashMap <String, XAcceptor> ();
		initialize ();
	}
	
	public final UnoConnection accept (String a_url, List <UnoConnection.UnoConnectionEventsListener> a_eventsListeners) throws Exception {
		StringTokenizer l_urlTokenizer = new StringTokenizer(a_url, UnoGeneralConstantsConstantsGroup.c_connectionUrlDelimiter);
		String l_portName = l_urlTokenizer.nextToken();
		UnoConnection l_unoConnection = null;
		synchronized (this) {
			try {
				if (i_portNameToUnoConnectionAcceptorMap.containsKey (l_portName)) {
					i_acceptingUnoConnectionAcceptor = i_portNameToUnoConnectionAcceptorMap.get (l_portName);
				}
				else {
					i_acceptingUnoConnectionAcceptor = i_localUnoObjectsContext. <XAcceptor>getUnoServiceInstance (UnoServiceNamesConstantsGroup.c_com_sun_star_connection_Acceptor, null);
					i_portNameToUnoConnectionAcceptorMap.put (l_portName, i_acceptingUnoConnectionAcceptor);
				}
				l_unoConnection = setUpUnoConnection (i_acceptingUnoConnectionAcceptor.accept (l_portName), l_urlTokenizer, LocalDateTime.now ().toString (), a_eventsListeners);
			}
			catch (ConnectionSetupException l_exception) {
				i_portNameToUnoConnectionAcceptorMap.remove (l_portName);
				throw l_exception;
			}
			finally {
				i_acceptingUnoConnectionAcceptor = null;
			}
		}
		return l_unoConnection;
	}
	
	public final void stopAccepting () {
		if (i_acceptingUnoConnectionAcceptor != null) {
			i_acceptingUnoConnectionAcceptor.stopAccepting ();
		}
	}
}

