package theBiasPlanet.unoUtilities.processesHandling;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;
import com.sun.star.comp.helper.Bootstrap;
import theBiasPlanet.unoUtilities.constantsGroups.*;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.*;
import theBiasPlanet.unoUtilities.unoObjectsContexts.LocalUnoObjectsContext;

public class UnoProcessEnvironment {
	private LocalUnoObjectsContext i_localObjectsContext;
	
	public UnoProcessEnvironment (String a_unoConnectionIdentification, String a_globalUnoServiceInstancesFactoriesConfigurationFileUrl) throws IOException, ParserConfigurationException, SAXException, ClassNotFoundException, NoSuchMethodException, InvocationTargetException, IllegalAccessException, com.sun.star.uno.Exception {
		try {
			i_localObjectsContext = new LocalUnoObjectsContext (Bootstrap.createInitialComponentContext (null), a_unoConnectionIdentification);
		}
		catch (Exception l_exception) {
			throw new com.sun.star.uno.Exception (String.format ("%s %s", UnoMessagesConstantsGroup.c_unoObjectsContextNotCreated,  l_exception.toString ()));
		}
		if (a_globalUnoServiceInstancesFactoriesConfigurationFileUrl != null) {
			i_localObjectsContext.addGlobalUnoServices (a_globalUnoServiceInstancesFactoriesConfigurationFileUrl);
			/*
			List <XSingleComponentFactory> l_globalUnoServiceInstancesFactories = UnoServiceHandler.getGlobalUnoServiceInstancesFactories (a_servicesSettingFileUrl);
			for (XSingleComponentFactory l_globalUnoServiceInstancesFactory: l_globalUnoServiceInstancesFactories) {
				i_localObjectsContext.addGlobalUnoService (l_globalUnoServiceInstancesFactory);
			}
			*/
		}
	}
	
	public final LocalUnoObjectsContext getLocalObjectsContext () {
		return i_localObjectsContext;
	}
}

