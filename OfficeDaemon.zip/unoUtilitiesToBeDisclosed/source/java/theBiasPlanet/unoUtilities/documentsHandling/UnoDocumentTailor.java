package theBiasPlanet.unoUtilities.documentsHandling;

import com.sun.star.lang.XComponent;
import theBiasPlanet.unoUtilities.connectionsHandling.UnoObjectsContext;

public class UnoDocumentTailor {
	protected UnoObjectsContext i_unoObjectsContext;
	
	public UnoDocumentTailor (UnoObjectsContext a_unoObjectsContext) {
		i_unoObjectsContext = a_unoObjectsContext;
	}
	
	public boolean tailor (XComponent a_unoDocumentInXComponent) throws Exception {
		return true;
	}
}

