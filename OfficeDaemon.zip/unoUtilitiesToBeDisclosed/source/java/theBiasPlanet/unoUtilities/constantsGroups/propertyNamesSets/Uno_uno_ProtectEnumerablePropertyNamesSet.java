package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_ProtectEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_on_boolean = "Protect";
	public static final Uno_uno_ProtectEnumerablePropertyNamesSet c_instance = new Uno_uno_ProtectEnumerablePropertyNamesSet ();
	
	private Uno_uno_ProtectEnumerablePropertyNamesSet () {
	}
}

