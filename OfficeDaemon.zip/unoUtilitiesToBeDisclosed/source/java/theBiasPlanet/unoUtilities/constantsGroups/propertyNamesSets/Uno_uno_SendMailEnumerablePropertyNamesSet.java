package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_SendMailEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_resipient_string = "Recipient";
	public static final String c_subject_string = "Subject";
	public static final String c_message_string = "MailText";
	public static final String c_priority_short = "Priority";
	public static final Uno_uno_SendMailEnumerablePropertyNamesSet c_instance = new Uno_uno_SendMailEnumerablePropertyNamesSet ();
	
	private Uno_uno_SendMailEnumerablePropertyNamesSet () {
	}
}

