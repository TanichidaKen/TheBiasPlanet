package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_NewStyleEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_styleName_string = "Param";
	public static final String c_styleFamilyKey_short = "Family";
	//public static final String c_parentStyleName_string = "#6602";
	public static final Uno_uno_NewStyleEnumerablePropertyNamesSet c_instance = new Uno_uno_NewStyleEnumerablePropertyNamesSet ();
	
	private Uno_uno_NewStyleEnumerablePropertyNamesSet () {
	}
}

