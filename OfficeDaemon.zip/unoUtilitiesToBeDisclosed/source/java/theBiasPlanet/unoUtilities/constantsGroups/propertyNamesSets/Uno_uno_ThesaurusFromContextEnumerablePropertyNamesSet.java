package theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets;

import theBiasPlanet.coreUtilities.constantsGroups.BaseEnumerableConstantsGroup;

public class Uno_uno_ThesaurusFromContextEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoPropertyNamesSet {
	public static final String c_replacingWord_string = "WordReplace";
	public static final Uno_uno_ThesaurusFromContextEnumerablePropertyNamesSet c_instance = new Uno_uno_ThesaurusFromContextEnumerablePropertyNamesSet ();
	
	private Uno_uno_ThesaurusFromContextEnumerablePropertyNamesSet () {
	}
}

