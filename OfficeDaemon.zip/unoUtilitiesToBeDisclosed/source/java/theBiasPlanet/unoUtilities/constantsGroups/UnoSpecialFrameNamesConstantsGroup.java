package theBiasPlanet.unoUtilities.constantsGroups;

public interface UnoSpecialFrameNamesConstantsGroup {
	String c_new = "_blank";
	String c_default = "_default";
	String c_self = "_self";
	String c_parent = "_parent";
	String c_top = "_top";
	String c_specialSub = "_beamer";
}

