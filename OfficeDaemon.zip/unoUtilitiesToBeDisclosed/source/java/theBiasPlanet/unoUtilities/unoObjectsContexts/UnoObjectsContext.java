package theBiasPlanet.unoUtilities.unoObjectsContexts;

import java.util.List;
import java.util.Map;
import com.sun.star.container.ElementExistException;
import com.sun.star.container.NoSuchElementException;
import com.sun.star.lang.IllegalArgumentException;
import com.sun.star.lang.WrappedTargetException;
import com.sun.star.uno.XComponentContext;
import theBiasPlanet.coreUtilities.collections.NavigableLinkedHashMap;
import theBiasPlanet.unoUtilities.constantsGroups.propertyNamesSets.UnoObjectsContextPropertyNamesSet;
import theBiasPlanet.unoUtilities.unoComponentBases.UnoComponentBase;

public abstract class UnoObjectsContext extends UnoComponentBase implements XComponentContext {
	protected NavigableLinkedHashMap <String, Object> i_localPropertyNameToValueMap;
	
	public UnoObjectsContext (String a_unoConnectionIdentification) {
		i_localPropertyNameToValueMap =  new NavigableLinkedHashMap <String, Object> ();
		addLocalProperty (UnoObjectsContextPropertyNamesSet.c_unoConnectionIdentification_string, a_unoConnectionIdentification);
	}
	
	@Override
	protected void finalize () {
	}
	
	public abstract void addExtraGlobalProperty (String a_propertyName, Object a_propertyValue) throws IllegalArgumentException, ElementExistException, WrappedTargetException;
	
	public abstract void removeExtraGlobalProperty (String a_propertyName) throws IllegalArgumentException, NoSuchElementException, WrappedTargetException;
	
	public Object getLocalPropertyValue (String a_propertyName) {
		return i_localPropertyNameToValueMap.get (a_propertyName);
	}
	
	public void addLocalProperty (String a_propertyName, Object a_propertyValue) {
		i_localPropertyNameToValueMap.put (a_propertyName, a_propertyValue);
	}
	
	public void removeLocalProperty (String a_propertyName) {
		i_localPropertyNameToValueMap.remove (a_propertyName);
	}
	
	public boolean isFromSameOrigin (UnoObjectsContext a_comparedUnoObjectsContext) {
		if (a_comparedUnoObjectsContext ==  null) {
			return false;
		}
		String l_unoConnectionIdentification = (String) getLocalPropertyValue (UnoObjectsContextPropertyNamesSet.c_unoConnectionIdentification_string);
		if (l_unoConnectionIdentification == null) {
			return false;
		}
		if (l_unoConnectionIdentification.equals (a_comparedUnoObjectsContext.getLocalPropertyValue (UnoObjectsContextPropertyNamesSet.c_unoConnectionIdentification_string))) {
			return true;
		}
		return false;
	}
}

