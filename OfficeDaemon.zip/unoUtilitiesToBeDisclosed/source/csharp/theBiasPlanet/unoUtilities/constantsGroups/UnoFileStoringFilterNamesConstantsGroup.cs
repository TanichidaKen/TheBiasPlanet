namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			using System;
			
			public static class UnoFileStoringFilterNamesConstantsGroup {
				public const String c_openDocumentWordProcessingFilterName = "writer8";
				public const String c_openDocumentSpreadsheetsFilterName = "calc8";
				public const String c_openDocumentPresentationsFilterName = "impress8";
				public const String c_microsoftWord97FileFilterName = "MS Word 97";
				public const String c_microsoftWord2007XmlFilterName = "MS Word 2007 XML";
				public const String c_microsoftExcel97FilterName = "MS Excel 97";
				public const String c_microsoftExcel2007XmlFilterName = "Calc MS Excel 2007 XML";
				public const String c_microsoftPowerPoint97FilterName = "MS PowerPoint 97";
				public const String c_microsoftPowerPoint2007XmlFilterName = "Impress MS PowerPoint 2007 XML";
				public const String c_csvFileFilterName = "Text - txt - csv (StarCalc)";
			}
		}
	}
}

