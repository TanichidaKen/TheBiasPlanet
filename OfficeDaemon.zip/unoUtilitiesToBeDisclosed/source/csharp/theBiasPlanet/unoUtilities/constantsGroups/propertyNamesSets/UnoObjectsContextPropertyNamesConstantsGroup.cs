namespace theBiasPlanet {
	namespace unoUtilities {
		namespace constantsGroups {
			namespace propertyNamesSets {
				using System;
				
				public static class UnoObjectsContextPropertyNamesConstantsGroup {
					public const String c_identification = "identification";
				}
			}
		}
	}
}

