from abc import ABCMeta
from com.sun.star.uno import XInterface

class XExternalEvent (XInterface, metaclass=ABCMeta):
	def getEventSourceIdentification (a_this: "XExternalEvent") -> str:
		return None

class XExternalKeyEvent (XExternalEvent, metaclass=ABCMeta):
	def getKeyCode (a_this: "XExternalKeyEvent") -> int:
		return None
	
	def getModificationCode (a_this: "XExternalKeyEvent") -> int:
		return None

