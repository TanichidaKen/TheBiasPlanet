namespace theBiasPlanet {
	namespace coreUtilities {
		namespace clipboardHandling {
			using System;
			using System.IO;
			using System.Windows;
			using System.Windows.Forms;
			using theBiasPlanet.coreUtilities.constantsGroups;
			
			public class MicrosoftWindowsClipboard {
				public static Boolean clearClipboard () {
					Clipboard.Clear ();
					return true;
				}
				
				public static ClipboardFormatSpecificDataComposite  getFormatSpecificDataComposite () {
					IDataObject l_dataObject = Clipboard.GetDataObject ();
					String [] l_datumFormatNames = l_dataObject.GetFormats (false);
					ClipboardFormatSpecificDataComposite l_formatSpecificDataComposite = new ClipboardFormatSpecificDataComposite ();
					foreach (String l_datumFormatName in l_datumFormatNames) {
						Object l_copiedFormatSpecificDatum = l_dataObject.GetData (l_datumFormatName, false);
						if (typeof (MemoryStream).IsInstanceOfType (l_copiedFormatSpecificDatum)) {
							MemoryStream l_copiedFormatSpecificDatumMemoryStream = (MemoryStream) l_copiedFormatSpecificDatum;
							Int64 l_copiedFormatSpecificDatumSizeMemoryStream = l_copiedFormatSpecificDatumMemoryStream.Length;
							byte [] l_copiedFormatSpecificDatumForMemoryStream = new byte [l_copiedFormatSpecificDatumSizeMemoryStream];
							for (int l_byteIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber; l_byteIndex < l_copiedFormatSpecificDatumSizeMemoryStream; l_byteIndex ++) {
								l_copiedFormatSpecificDatumForMemoryStream [l_byteIndex] = Convert.ToByte (l_copiedFormatSpecificDatumMemoryStream.ReadByte ());
							}
							l_copiedFormatSpecificDatum = l_copiedFormatSpecificDatumForMemoryStream;
							/*
							l_copiedFormatSpecificDatum = new MemoryStream ( (Int32)l_copiedFormatSpecificDatumSizeMemoryStream);
							l_MemoryStreamcopiedFormatSpecificDatumMemoryStream.CopyTo ( (MemoryStream) l_copiedFormatSpecificDatum);
							*/
						}
						l_formatSpecificDataComposite.addFormatSpecificDatum (new ClipboardFormatSpecificDatum (l_datumFormatName, l_copiedFormatSpecificDatum));
					}
					return l_formatSpecificDataComposite;
				}
				
				public static Boolean setFormatSpecificDataComposite (ClipboardFormatSpecificDataComposite a_formatSpecificDataComposite) {
					IDataObject l_dataObject = new DataObject ();
					foreach (String l_datumFormatName  in a_formatSpecificDataComposite.getFormatNames ()) {
						ClipboardFormatSpecificDatum l_formatSpecificDatum = a_formatSpecificDataComposite.getFormatSpecificDatum (l_datumFormatName);
						Object l_copiedFormatSpecificDatum = l_formatSpecificDatum.getDatum ();
						l_dataObject.SetData (l_datumFormatName, true, l_copiedFormatSpecificDatum);
					}
					Clipboard.SetDataObject (l_dataObject, true);
					return true;
				}
			}
		}
	}
}

