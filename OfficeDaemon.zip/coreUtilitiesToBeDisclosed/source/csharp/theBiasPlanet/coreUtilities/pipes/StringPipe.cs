namespace theBiasPlanet {
	namespace coreUtilities {
		namespace pipes {
			using System;
			using System.IO;
			using System.Text;
			using theBiasPlanet.coreUtilities.constantsGroups;
			using theBiasPlanet.coreUtilities.inputsHandling;
			using theBiasPlanet.coreUtilities.timersHandling;
			
			public class StringPipe : ObjectsPipe <Char> {
				public StringPipe (Int32 a_bufferSize, Boolean a_notificationIsDelayed) : base (a_bufferSize, a_notificationIsDelayed) {
				}
				
				~StringPipe () {
				}
				
				public void writeWholeString (TextReader a_reader) {
					Int32 l_writtenCharacter;
					while (true) {
						l_writtenCharacter = a_reader.Read ();
						if (l_writtenCharacter == GeneralConstantsConstantsGroup.c_unspecifiedInteger) {
							break;
						}
						try {
							write ((Char) l_writtenCharacter);
						}
						catch (NoMoreNeedsException) {
							break;
						}
					}
				}
				
				public String readString (Int32 a_maximumLength, Int32 a_timeOutPeriodInMilliseconds = -1) {
					Char l_readCharacter;
					StringBuilder l_readStringBuilder = new StringBuilder ();
					Int32 l_readStringLength = 0;
					while (l_readStringLength < a_maximumLength) {
						try {
							if (l_readStringLength == 0) {
								l_readCharacter = read (a_timeOutPeriodInMilliseconds);
							}
							else {
								l_readCharacter = read ();
							}
						}
						/* valid only for C# 6 and after
						catch (Exception l_exception) when (l_exception is NoMoreDataException || l_exception is TimeOutException) {
							if (l_readStringLength == 0) {
								throw l_exception;
							}
							break;
						}
						*/
						catch (NoMoreDataException l_exception) {
							if (l_readStringLength == 0) {
								throw l_exception;
							}
							break;
						}
						catch (TimeOutException l_exception) {
							if (l_readStringLength == 0) {
								throw l_exception;
							}
							break;
						}
						l_readStringBuilder.Append (l_readCharacter);
						l_readStringLength ++;
					}
					return l_readStringBuilder.ToString ();
				}
				
				public String readStringLine (Int32 a_maximumLength, Int32 a_timeOutPeriodInMilliseconds) {
					StringBuilder l_readStringBuilder = new StringBuilder ();
					Int32 l_readStringLength = 0;
					while (true) {
						try {
							Char l_readCharacter = read (a_timeOutPeriodInMilliseconds);
							l_readStringBuilder.Append (l_readCharacter);
							l_readStringLength ++;
							if (l_readCharacter == GeneralConstantsConstantsGroup.c_newLineCharacter || l_readStringLength >= a_maximumLength) {
								break;
							}
						}
						/* valid only for C# 6 and after
						catch (Exception l_exception) when (l_exception is NoMoreDataException || l_exception is TimeOutException) {
							if (l_readStringLength == 0) {
								throw l_exception;
							}
							break;
						}
						*/
						catch (NoMoreDataException  l_exception) {
							if (l_readStringLength == 0) {
								throw l_exception;
							}
							break;
						}
						catch (TimeOutException l_exception) {
							if (l_readStringLength == 0) {
								throw l_exception;
							}
							break;
						}
					}
					return l_readStringBuilder.ToString ();
				}
				
				public String readWholeString () {
					Char l_readCharacter;
					StringBuilder l_readStringBuilder = new StringBuilder ();
					while (true) {
						try {
							l_readCharacter = read ();
						}
						catch (NoMoreDataException) {
							break;
						}
						l_readStringBuilder.Append (l_readCharacter);
					}
					return l_readStringBuilder.ToString ();
				}
			}
		}
	}
}

