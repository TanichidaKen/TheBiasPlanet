namespace theBiasPlanet {
	namespace coreUtilities {
		namespace jsonDataHandling {
			using System;
			
			public class UnsupportedValueException : Exception {
				public UnsupportedValueException (String a_message) : base (a_message) {
				}
			}
		}
	}
}

