package theBiasPlanet.coreUtilities.jsonDataHandling;

public class JsonParsingTerminatedException extends Exception {
	public JsonParsingTerminatedException (String a_message) {
		super (a_message);
	}
}

