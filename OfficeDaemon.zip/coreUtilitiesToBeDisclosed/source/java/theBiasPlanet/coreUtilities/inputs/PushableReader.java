package theBiasPlanet.coreUtilities.inputs;

import java.io.FilterReader;
import java.io.IOException;
import java.io.Reader;
import theBiasPlanet.coreUtilities.constantsGroups.DefaultValuesConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.InputPropertiesConstantsGroup;
import theBiasPlanet.coreUtilities.inputsHandling.BufferOverflowedException;

public class PushableReader extends FilterReader {
	private int i_bufferSize;
	private char [] i_buffer;
	private int i_characterStartIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
	private int i_characterUntilIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
	private char [] i_inMethodBuffer = new char [DefaultValuesConstantsGroup.c_smallestBufferSize];
	
	public PushableReader (Reader a_underlyingReader, int a_bufferSize) {
		super (a_underlyingReader);
		i_bufferSize = a_bufferSize;
		i_buffer = new char [i_bufferSize];
	}
	
	private int readFromBuffer (char [] a_charactersArray, int a_offset, int a_length) {
		int l_readLength = InputPropertiesConstantsGroup.c_lengthNotRead;
		int l_toReadLength = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		if (i_characterStartIndex == GeneralConstantsConstantsGroup.c_iterationStartNumber && i_characterUntilIndex == GeneralConstantsConstantsGroup.c_iterationStartNumber) {
		}
		else if (i_characterUntilIndex > i_characterStartIndex) {
			l_toReadLength = Math.min (a_length, i_characterUntilIndex - i_characterStartIndex);
			System.arraycopy (i_buffer, i_characterStartIndex, a_charactersArray, a_offset, l_toReadLength);
			l_readLength += l_toReadLength;
			i_characterStartIndex += l_toReadLength;
			if (i_characterStartIndex == i_characterUntilIndex) {
				i_characterStartIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
				i_characterUntilIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
			}
		}
		else {
			l_toReadLength = Math.min (a_length, i_bufferSize - i_characterStartIndex);
			System.arraycopy (i_buffer, i_characterStartIndex, a_charactersArray, a_offset, l_toReadLength);
			l_readLength += l_toReadLength;
			i_characterStartIndex += l_toReadLength;
			if (i_characterStartIndex == i_bufferSize) {
				i_characterStartIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
				if (l_readLength < a_length) {
					l_toReadLength = Math.min (a_length - l_readLength, i_characterUntilIndex - i_characterStartIndex);
					System.arraycopy (i_buffer, i_characterStartIndex, a_charactersArray, a_offset + l_readLength, l_toReadLength);
					l_readLength += l_toReadLength;
					i_characterStartIndex += l_toReadLength;
					if (i_characterStartIndex == i_characterUntilIndex) {
						i_characterStartIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
						i_characterUntilIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
					}
				}
			}
		}
		return l_readLength;
	}
	
	@Override
	public void close () throws IOException {
		in.close ();
		i_characterStartIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
		i_characterUntilIndex = GeneralConstantsConstantsGroup.c_iterationStartNumber;
	}
	
	@Override
	public void mark (int a_aheadReadingLimit) throws IOException{
		throw new IOException ("Marking isn't supported.");
	}
	
	@Override
	public boolean markSupported () {
		return false;
	}
	
	public int readFixedLengthData (char [] a_charactersArray, int a_offset, int a_length) throws IOException {
		int l_readLength = InputPropertiesConstantsGroup.c_lengthNotRead;
		l_readLength = readFromBuffer (a_charactersArray, a_offset, a_length);
		if (l_readLength < a_length) {
			int l_readFunctionReturn = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
			while ((l_readFunctionReturn = in.read (a_charactersArray, a_offset + l_readLength, a_length - l_readLength)) != InputPropertiesConstantsGroup.c_noMoreData) {
				l_readLength += l_readFunctionReturn;
				if (l_readLength == a_length) {
					break;
				}
			}
		}
		if (l_readLength == InputPropertiesConstantsGroup.c_lengthNotRead && a_length > InputPropertiesConstantsGroup.c_lengthNotRead) {
			l_readLength = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		}
		return l_readLength;
	}
	
	@Override
	public int read (char [] a_charactersArray, int a_offset, int a_length) throws IOException {
		int l_readLength = InputPropertiesConstantsGroup.c_lengthNotRead;
		l_readLength = readFromBuffer (a_charactersArray, a_offset, a_length);
		if (l_readLength < a_length) {
			int l_readFunctionReturn = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
			l_readFunctionReturn = in.read (a_charactersArray, a_offset + l_readLength, a_length - l_readLength);
			if (l_readFunctionReturn != InputPropertiesConstantsGroup.c_noMoreData) {
				l_readLength += l_readFunctionReturn;
			}
			else {
				if (l_readLength == InputPropertiesConstantsGroup.c_lengthNotRead) {
					l_readLength = InputPropertiesConstantsGroup.c_noMoreData;
				}
			}
		}
		return l_readLength;
	}
	
	@Override
	public int read () throws IOException {
		int l_readFunctionReturn = read (i_inMethodBuffer, GeneralConstantsConstantsGroup.c_iterationStartNumber, DefaultValuesConstantsGroup.c_smallestBufferSize);
		if (l_readFunctionReturn == InputPropertiesConstantsGroup.c_noMoreData) {
			return l_readFunctionReturn;
		}
		else {
			return i_inMethodBuffer [GeneralConstantsConstantsGroup.c_iterationStartNumber];
		}
	}
	
	@Override
	public boolean ready () throws IOException {
		if (i_characterStartIndex != GeneralConstantsConstantsGroup.c_iterationStartNumber || i_characterUntilIndex != GeneralConstantsConstantsGroup.c_iterationStartNumber) {
			return true;
		}
		else {
			return in.ready ();
		}
	}
	
	@Override
	public void reset () throws IOException {
		throw new IOException ("Resetting isn't supported.");
	}
	
	@Override
	public long skip (long a_numberOfCharactersToBeSkipped) throws IOException {
		long l_numberOfCharactersSkipped = InputPropertiesConstantsGroup.c_lengthNotRead;
		for (l_numberOfCharactersSkipped = InputPropertiesConstantsGroup.c_lengthNotRead; l_numberOfCharactersSkipped < a_numberOfCharactersToBeSkipped; l_numberOfCharactersSkipped ++) {
			if (read () == InputPropertiesConstantsGroup.c_noMoreData) {
				break;
			}
		}
		return l_numberOfCharactersSkipped;
	}
	
	public void pushData (char [] a_charactersArray, int a_offset, int a_length) throws BufferOverflowedException {
		int l_toPushLength = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		int l_pushedLength = InputPropertiesConstantsGroup.c_lengthNotRead;
		if (a_length <= InputPropertiesConstantsGroup.c_lengthNotRead) {
			return;
		}
		if (i_characterStartIndex == i_characterUntilIndex && i_characterStartIndex == GeneralConstantsConstantsGroup.c_iterationStartNumber) {
			l_toPushLength = Math.min (i_bufferSize, a_length);
			if (l_toPushLength > InputPropertiesConstantsGroup.c_lengthNotRead) {
				System.arraycopy (a_charactersArray, a_offset, i_buffer, i_characterStartIndex, l_toPushLength);
				l_pushedLength += l_toPushLength;
				i_characterUntilIndex += l_pushedLength;
			}
		}
		else if (i_characterUntilIndex > i_characterStartIndex) {
			l_toPushLength = Math.min (i_characterStartIndex, a_length);
			if (l_toPushLength > InputPropertiesConstantsGroup.c_lengthNotRead) {
				System.arraycopy (a_charactersArray, a_offset, i_buffer, i_characterStartIndex - l_toPushLength, l_toPushLength);
				l_pushedLength += l_toPushLength;
				i_characterStartIndex -= l_pushedLength;
			}
			if (l_pushedLength < a_length) {
				l_toPushLength = Math.min (i_bufferSize - i_characterUntilIndex, a_length - l_pushedLength);
				if (l_toPushLength > InputPropertiesConstantsGroup.c_lengthNotRead) {
					System.arraycopy (a_charactersArray, a_offset + l_pushedLength, i_buffer, i_bufferSize - l_toPushLength, l_toPushLength);
					l_pushedLength += l_toPushLength;
					i_characterStartIndex = i_bufferSize - l_pushedLength;
				}
			}
		}
		else {
			l_toPushLength = Math.min (i_characterStartIndex - i_characterUntilIndex, a_length);
			if (l_toPushLength > InputPropertiesConstantsGroup.c_lengthNotRead) {
				System.arraycopy (a_charactersArray, a_offset, i_buffer, i_characterStartIndex - l_toPushLength, l_toPushLength);
				l_pushedLength += l_toPushLength;
				i_characterStartIndex -= l_pushedLength;
			}
		}
		if (l_pushedLength < a_length) {
			throw new BufferOverflowedException (null);
		}
	}
	
	public void pushData (char a_character) throws BufferOverflowedException {
		i_inMethodBuffer [GeneralConstantsConstantsGroup.c_iterationStartNumber] = a_character;
		pushData (i_inMethodBuffer, GeneralConstantsConstantsGroup.c_iterationStartNumber, DefaultValuesConstantsGroup.c_smallestBufferSize);
	}
	
	// return: the number of skipped white spaces
	public int skipWhiteSpaces () throws IOException, BufferOverflowedException {
		int l_toReadLength = 1;
		int l_readLength = InputPropertiesConstantsGroup.c_lengthNotRead;
		int l_readFunctionReturn = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		while ((l_readFunctionReturn = readFixedLengthData (i_inMethodBuffer, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_toReadLength)) != InputPropertiesConstantsGroup.c_noMoreData) {
			if (i_inMethodBuffer [GeneralConstantsConstantsGroup.c_iterationStartNumber] != GeneralConstantsConstantsGroup.c_spaceCharacter && i_inMethodBuffer [GeneralConstantsConstantsGroup.c_iterationStartNumber] != GeneralConstantsConstantsGroup.c_tabCharacter && i_inMethodBuffer [GeneralConstantsConstantsGroup.c_iterationStartNumber] != GeneralConstantsConstantsGroup.c_newLineCharacter && i_inMethodBuffer [GeneralConstantsConstantsGroup.c_iterationStartNumber] != GeneralConstantsConstantsGroup.c_carriageReturnCharacter) {
				pushData (i_inMethodBuffer, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readFunctionReturn);
				break;
			}
			l_readLength += l_readFunctionReturn;
		}
		return l_readLength;
	}
	
	// return: the number of skipped characters
	public int skipThrough (String a_throughString) throws IOException {
		int l_toReadLength = 1;
		int l_readLength = InputPropertiesConstantsGroup.c_lengthNotRead;
		int l_readFunctionReturn = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		int l_throughStringLength = a_throughString.length ();
		int l_throughStringMatchedCharactersIndex = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		while ((l_readFunctionReturn = readFixedLengthData (i_inMethodBuffer, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_toReadLength)) != InputPropertiesConstantsGroup.c_noMoreData) {
			l_readLength += l_readFunctionReturn;
			if (l_readFunctionReturn < l_toReadLength) {
				return l_readLength;
			}
			if (i_inMethodBuffer [GeneralConstantsConstantsGroup.c_iterationStartNumber] == a_throughString.charAt (l_throughStringMatchedCharactersIndex + 1)) {
				l_throughStringMatchedCharactersIndex ++;
			}
			else {
				l_throughStringMatchedCharactersIndex = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
				if (i_inMethodBuffer [GeneralConstantsConstantsGroup.c_iterationStartNumber] == a_throughString.charAt (l_throughStringMatchedCharactersIndex + 1)) {
					l_throughStringMatchedCharactersIndex ++;
				}
			}
			if (l_throughStringMatchedCharactersIndex == l_throughStringLength - 1) {
				return l_readLength;
			}
		}
		return l_readLength;
	}
	
	// The from-string has to appear immediately, or the skipping will finish.
	// return: the number of skipped characters
	public int skipWhiteSpacesAndFromThroughAreas (String a_fromString, String a_throughString) throws IOException, BufferOverflowedException {
		int l_fromStringLength = a_fromString.length ();
		int l_toReadLength = l_fromStringLength;
		int l_readLength = InputPropertiesConstantsGroup.c_lengthNotRead;
		int l_readFunctionReturn = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		String l_readData = null;
		boolean l_skipFinished = false;
		char [] l_inMethodBuffer = new char [l_fromStringLength];
		while (true) {
			l_readLength += skipWhiteSpaces ();
			l_readFunctionReturn = readFixedLengthData (l_inMethodBuffer, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_toReadLength);
			if (l_readFunctionReturn == InputPropertiesConstantsGroup.c_noMoreData) {
				l_skipFinished = true;
			}
			else {
				if (l_readFunctionReturn == l_toReadLength) {
					l_readData = new String (l_inMethodBuffer, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readFunctionReturn);
					if (a_fromString.equals (l_readData)) {
						l_readLength += l_readFunctionReturn;
						l_readLength += skipThrough (a_throughString);
					}
					else {
						l_skipFinished = true;
					}
				}
				else {
					l_skipFinished = true;
				}
			}
			if (l_skipFinished) {
				if (l_readFunctionReturn > InputPropertiesConstantsGroup.c_lengthNotRead) {
					pushData (l_inMethodBuffer, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readFunctionReturn);
				}
				return l_readLength;
			}
		}
	}
}

