package theBiasPlanet.coreUtilities.collectionsHandling;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.PathMatcher;
import java.nio.file.Paths;
import theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup;

public class MapHandler {
	public static <T, U> Map.Entry <T, U> getFirstEntry (Map <T, U> a_map) {
		for (Map.Entry <T, U> l_mapEntry: a_map.entrySet ()) {
			return l_mapEntry;
		}
		return null;
	}
	
	public static <T> ArrayList <Path> getGlobMatchedKeys (Map <Path, T> a_map, List <String> a_globExpressions) {
		ArrayList <PathMatcher> l_pathMatchers = new ArrayList <PathMatcher> ();
		if (a_globExpressions != null) {
			l_pathMatchers = new ArrayList <PathMatcher> ();
			FileSystem l_fileSystem = FileSystems.getDefault ();
			for (String l_globExpression: a_globExpressions) {
				l_pathMatchers.add (l_fileSystem.getPathMatcher (String.format (GeneralConstantsConstantsGroup.c_globExpressionFormat, Paths.get (l_globExpression).normalize ())));
			}
			ArrayList <Path> l_globMatchedKeys = new ArrayList <Path> ();
			boolean l_areFound = false;
			for (Map.Entry <Path, T> l_mapEntry: a_map.entrySet ()) {
				Path l_key = l_mapEntry.getKey ();
				for (PathMatcher l_pathMatcher: l_pathMatchers) {
					if (l_pathMatcher.matches (l_key)) {
						l_globMatchedKeys.add (l_key);
						l_areFound = true;
						break;
					}
				}
			}
			if (l_areFound) {
				return l_globMatchedKeys;
			}
			else {
				return null;
			}
		}
		else {
			return null;
		}
	}
}

