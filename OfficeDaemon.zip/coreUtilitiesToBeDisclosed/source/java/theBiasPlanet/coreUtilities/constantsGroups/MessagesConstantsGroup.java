package theBiasPlanet.coreUtilities.constantsGroups;

public interface MessagesConstantsGroup {
	String c_notConnected = "Not connected.";
	String c_connected = "Connected.";
	String c_exiting = "Exiting . . .";
	String c_accepting = "Accepting . . .";
	String c_connecting = "Connecting . . .";
	String c_fromHeader = "From";
	String c_replacingConfirmation = "Do you replace this?";
	String c_invalidAxis = "Invalid Axis: %s.";
	String c_errorHasOccurred = "An error has occurred: %s.";
	String c_characterPosition = "character position: %d";
}

