package theBiasPlanet.coreUtilities.inputsHandling;

import java.io.IOException;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;
import theBiasPlanet.coreUtilities.constantsGroups.DefaultValuesConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.GeneralConstantsConstantsGroup;
import theBiasPlanet.coreUtilities.constantsGroups.InputPropertiesConstantsGroup;
import theBiasPlanet.coreUtilities.inputs.ReaderInputStream;

public class ReaderHandler {
	private static final int c_bufferSize = DefaultValuesConstantsGroup.c_smallBufferSize;
	
	public static String getWholeString (Reader a_reader) throws IOException {
		char [] l_charactersArray = new char [c_bufferSize];
		int l_readFunctionReturn = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		StringBuilder l_readDataBuilder = new StringBuilder ();
		while( (l_readFunctionReturn = a_reader.read (l_charactersArray, 0, c_bufferSize)) != InputPropertiesConstantsGroup.c_noMoreData){
			l_readDataBuilder.append (l_charactersArray, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readFunctionReturn);
		}
		return l_readDataBuilder.toString ();
	}
	
	public static void writeWholeStringToWriter (Reader a_reader, Writer a_writer) throws IOException {
		char [] l_charactersArray = new char [c_bufferSize];
		int l_readFunctionReturn = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		while( (l_readFunctionReturn = a_reader.read (l_charactersArray, 0, c_bufferSize)) != InputPropertiesConstantsGroup.c_noMoreData){
			a_writer.write (l_charactersArray, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readFunctionReturn);
			a_writer.flush ();
		}
	}
	
	public static void writeWholeStringToOutputStream (Reader a_reader, String a_charactersSet, OutputStream a_outputStream) throws IOException {
		ReaderInputStream l_readerInputStream = new ReaderInputStream (a_reader, a_charactersSet);
		byte [] l_bytesArray = new byte [c_bufferSize];
		int l_readFunctionReturn = GeneralConstantsConstantsGroup.c_unspecifiedInteger;
		while( (l_readFunctionReturn = l_readerInputStream.read (l_bytesArray, GeneralConstantsConstantsGroup.c_iterationStartNumber, c_bufferSize)) != InputPropertiesConstantsGroup.c_noMoreData) {
			a_outputStream.write (l_bytesArray, GeneralConstantsConstantsGroup.c_iterationStartNumber, l_readFunctionReturn);
			a_outputStream.flush ();
		}
	}
}

