package theBiasPlanet.coreUtilities.inputsHandling;

public class BufferOverflowedException extends Exception {
	public BufferOverflowedException (String a_message) {
		super (a_message);
	}
}

