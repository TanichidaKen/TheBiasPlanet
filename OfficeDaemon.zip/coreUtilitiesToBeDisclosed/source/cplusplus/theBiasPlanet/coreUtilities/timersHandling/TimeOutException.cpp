#include "theBiasPlanet/coreUtilities/timersHandling/TimeOutException.hpp"

namespace theBiasPlanet {
	namespace coreUtilities {
		namespace timersHandling {
			TimeOutException::TimeOutException (string a_message) : exception (), i_message (a_message) {
			}
			
			TimeOutException::~TimeOutException () {
			}
			
			char const * TimeOutException::what () const throw () {
    			return i_message.c_str ();
    		}
		}
	}
}

