#ifndef __theBiasPlanet_coreUtilities_jsonDataHandling_ExtendedJsonDatumParseEventsHandler_hpp__
	#define __theBiasPlanet_coreUtilities_jsonDataHandling_ExtendedJsonDatumParseEventsHandler_hpp__
	
	#include <chrono>
	#include <exception>
	#include "theBiasPlanet/coreUtilities/pipes/StringPipe.hpp"
	#include "theBiasPlanet/coreUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	using namespace ::std::chrono;
	using namespace ::theBiasPlanet::coreUtilities::pipes;
	
	namespace theBiasPlanet {
		namespace coreUtilities {
			namespace jsonDataHandling {
				class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ ExtendedJsonDatumParseEventsHandler {
					public:
						virtual ~ExtendedJsonDatumParseEventsHandler ();
						virtual void initialize () = 0;
						virtual bool onNullFound ();
						virtual bool onBooleanFound (bool const & a_value);
						virtual bool onIntegerFound (int const & a_value);
						virtual bool onDoubleFound (double const & a_value);
						virtual bool onLocalDateAndTimeFound (time_point <system_clock> const & a_value);
						//virtual bool onLocalDateFound (year_month_day const & a_value);
						virtual bool onLocalDateFound (time_point <system_clock> const & a_value);
						//virtual bool onLocalTimeFound (time_of_day const & a_value);
						virtual bool onLocalTimeFound (time_point <system_clock> const & a_value);
						virtual bool onBytesArrayFound (StringPipe * a_reader);
						virtual bool onStringFound (StringPipe * a_reader);
						virtual bool onArrayStarted ();
						virtual bool onArrayEnded ();
						virtual bool onDictionaryStarted ();
						virtual bool onDictionaryEnded ();
						virtual void onException (exception const & a_exception);
				};
			}
		}
	}
#endif

