#ifndef __theBiasPlanet_coreUtilities_jsonDataHandling_ExtendedJsonDatumParser_hpp__
	#define __theBiasPlanet_coreUtilities_jsonDataHandling_ExtendedJsonDatumParser_hpp__
	
	/*
	#include <chrono>
	#include <exception>
	#include "theBiasPlanet/coreUtilities/pipes/StringPipe.hpp"
	*/
	#include <string>
	#include "theBiasPlanet/coreUtilities/inputs/PushableReader.hpp"
	#include "theBiasPlanet/coreUtilities/jsonDataHandling/ExtendedJsonDatumParseEventsHandler.hpp"
	#include "theBiasPlanet/coreUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	//using namespace ::std::chrono;
	//using namespace ::theBiasPlanet::coreUtilities::pipes;
	using namespace ::theBiasPlanet::coreUtilities::inputs;
	
	namespace theBiasPlanet {
		namespace coreUtilities {
			namespace jsonDataHandling {
				class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ ExtendedJsonDatumParser {
					private:
						static int const c_bufferSize;
						static char const c_notANumberExpressionOpener;
						static char const c_positiveInfinityExpressionOpener;
						static char const c_negativeInfinityExpressionOpener;
						static char const c_nullExpressionOpener;
						static char const c_trueExpressionOpener;
						static char const c_falseExpressionOpener;
						static string const c_exceptionMessageFormattingExpression;
						PushableReader * i_extendedJsonDatumReader = nullptr;
						ExtendedJsonDatumParseEventsHandler * i_parseEventsHandler = nullptr;
						char * i_characters = nullptr;
						long i_characterPositionIndex = GeneralConstantsConstantsGroup::c_iterationStartNumber;
						virtual bool parseNextItem ();
						virtual bool parseString ();
						virtual string decodeUnicodeEscape ();
						virtual void skipWhiteSpaces ();
						virtual bool parseArray ();
						virtual bool parseDictionary ();
					public:
						ExtendedJsonDatumParser ();
						virtual ~ExtendedJsonDatumParser ();
						// return: true: An item has been found, false: No item has been found
						virtual bool parse (istream * a_extendedJsonDatumReader, ExtendedJsonDatumParseEventsHandler * a_parseEventsHandler);
						// return: true: An item has been found, false: No item has been found
				};
			}
		}
	}
#endif

