#include "theBiasPlanet/coreUtilities/jsonDataHandling/ExtendedJsonDatumParseEventsHandler.hpp"
#include "theBiasPlanet/coreUtilities/messagingHandling/Publisher.hpp"

using namespace ::theBiasPlanet::coreUtilities::messagingHandling;

namespace theBiasPlanet {
	namespace coreUtilities {
		namespace jsonDataHandling {
			ExtendedJsonDatumParseEventsHandler::~ExtendedJsonDatumParseEventsHandler () {
			}
			
			bool ExtendedJsonDatumParseEventsHandler::onNullFound () {
				return true;
			}
			
			bool ExtendedJsonDatumParseEventsHandler::onBooleanFound (bool const & a_value) {
				return true;
			}
			
			bool ExtendedJsonDatumParseEventsHandler::onIntegerFound (int const & a_value) {
				return true;
			}
			
			bool ExtendedJsonDatumParseEventsHandler::onDoubleFound (double const & a_value) {
				return true;
			}
			
			bool ExtendedJsonDatumParseEventsHandler::onLocalDateAndTimeFound (time_point <system_clock> const & a_value) {
				return true;
			}
			
			bool ExtendedJsonDatumParseEventsHandler::onLocalDateFound (time_point <system_clock> const & a_value) {
				return true;
			}
			
			bool ExtendedJsonDatumParseEventsHandler::onLocalTimeFound (time_point <system_clock> const & a_value) {
				return true;
			}
			
			bool ExtendedJsonDatumParseEventsHandler::onBytesArrayFound (StringPipe * a_reader) {
				return true;
			}
			
			bool ExtendedJsonDatumParseEventsHandler::onStringFound (StringPipe * a_reader) {
				return true;
			}
			
			bool ExtendedJsonDatumParseEventsHandler::onArrayStarted () {
				return true;
			}
			
			bool ExtendedJsonDatumParseEventsHandler::onArrayEnded () {
				return true;
			}
			
			bool ExtendedJsonDatumParseEventsHandler::onDictionaryStarted () {
				return true;
			}
			
			bool ExtendedJsonDatumParseEventsHandler::onDictionaryEnded () {
				return true;
			}
			
			void ExtendedJsonDatumParseEventsHandler::onException (exception const & a_exception) {
				Publisher::logErrorInformation (a_exception);
			}
		}
	}
}


