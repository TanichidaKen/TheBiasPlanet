#include "theBiasPlanet/coreUtilities/jsonDataHandling/TerminatedException.hpp"

namespace theBiasPlanet {
	namespace coreUtilities {
		namespace jsonDataHandling {
			TerminatedException::TerminatedException (string a_message) : exception (), i_message (a_message) {
			}
			
			TerminatedException::~TerminatedException () {
			}
			
			char const * TerminatedException::what () const throw () {
    			return i_message.c_str ();
    		}
		}
	}
}

