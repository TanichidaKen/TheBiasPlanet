#include "theBiasPlanet/coreUtilities/inputs/PushableReader.hpp"
#include <cstring>
#include "theBiasPlanet/coreUtilities/inputsHandling/BufferOverflowedException.hpp"

using namespace ::theBiasPlanet::coreUtilities::inputsHandling;

namespace theBiasPlanet {
	namespace coreUtilities {
		namespace inputs  {
			int PushableReader::readFromBuffer (char * const a_characters, int const & a_offset, int const & a_length) {
				int l_readLength = 0;
				int l_toReadLength = GeneralConstantsConstantsGroup::c_unspecifiedInteger;
				if (i_characterStartIndex == GeneralConstantsConstantsGroup::c_iterationStartNumber && i_characterUntilIndex == GeneralConstantsConstantsGroup::c_iterationStartNumber) {
				}
				else if (i_characterUntilIndex > i_characterStartIndex) {
					l_toReadLength = min (a_length, i_characterUntilIndex - i_characterStartIndex);
					strncpy (a_characters + a_offset, i_buffer + i_characterStartIndex, l_toReadLength);
					l_readLength += l_toReadLength;
					i_characterStartIndex += l_toReadLength;
					if (i_characterStartIndex == i_characterUntilIndex) {
						i_characterStartIndex = GeneralConstantsConstantsGroup::c_iterationStartNumber;
						i_characterUntilIndex = GeneralConstantsConstantsGroup::c_iterationStartNumber;
					}
				}
				else {
					l_toReadLength = min (a_length, i_bufferSize - i_characterStartIndex);
					strncpy (a_characters + a_offset, i_buffer + i_characterStartIndex, l_toReadLength);
					l_readLength += l_toReadLength;
					i_characterStartIndex += l_toReadLength;
					if (i_characterStartIndex == i_bufferSize) {
						i_characterStartIndex = GeneralConstantsConstantsGroup::c_iterationStartNumber;
						if (l_readLength < a_length) {
							l_toReadLength = min (a_length - l_readLength, i_characterUntilIndex - i_characterStartIndex);
							strncpy (a_characters + a_offset + l_readLength, i_buffer + i_characterStartIndex, l_toReadLength);
							l_readLength += l_toReadLength;
							i_characterStartIndex += l_toReadLength;
							if (i_characterStartIndex == i_characterUntilIndex) {
								i_characterStartIndex = GeneralConstantsConstantsGroup::c_iterationStartNumber;
								i_characterUntilIndex = GeneralConstantsConstantsGroup::c_iterationStartNumber;
							}
						}
					}
				}
				return l_readLength;
			}
			
			PushableReader::PushableReader (istream * const a_underlyingStream, int const & a_bufferSize) : i_underlyingStream (a_underlyingStream), i_bufferSize (a_bufferSize), i_buffer (new char [i_bufferSize]) {
			}
			
			PushableReader::~PushableReader () {
				delete [] i_buffer;
			}
			
			int PushableReader::readFixedLengthData (char * const a_characters, int const & a_offset, int const & a_length) {
				int l_readLength = 0;
				l_readLength = readFromBuffer (a_characters, a_offset, a_length);
				if (l_readLength < a_length) {
					int l_readFunctionReturn = GeneralConstantsConstantsGroup::c_unspecifiedInteger;
					i_underlyingStream->read (a_characters + a_offset + l_readLength, a_length - l_readLength);
					l_readFunctionReturn =  i_underlyingStream->gcount ();
					l_readLength += l_readFunctionReturn;
				}
				if (l_readLength == 0 && a_length > 0) {
					l_readLength = GeneralConstantsConstantsGroup::c_unspecifiedInteger;
				}
				return l_readLength;
			}
			
			int PushableReader::read () {
				int l_readFunctionReturn = readFixedLengthData (i_inMethodBuffer, GeneralConstantsConstantsGroup::c_iterationStartNumber, 1);
				if (l_readFunctionReturn == GeneralConstantsConstantsGroup::c_unspecifiedInteger) {
					return l_readFunctionReturn;
				}
				else {
					return i_inMethodBuffer [GeneralConstantsConstantsGroup::c_iterationStartNumber];
				}
			}
			
			void PushableReader::pushData (char const * const a_characters, int const & a_offset, int const & a_length) {
				int l_toPushLength = GeneralConstantsConstantsGroup::c_unspecifiedInteger;
				int l_pushedLength = 0;
				if (a_length<= 0) {
					return;
				}
				if (i_characterStartIndex == i_characterUntilIndex && i_characterStartIndex == 0) {
					l_toPushLength = min (i_bufferSize, a_length);
					if (l_toPushLength > 0) {
						strncpy (i_buffer + i_characterStartIndex, a_characters + a_offset, l_toPushLength);
						l_pushedLength += l_toPushLength;
						i_characterUntilIndex += l_pushedLength;
					}
				}
				else if (i_characterUntilIndex > i_characterStartIndex) {
					l_toPushLength = min (i_characterStartIndex, a_length);
					if (l_toPushLength > 0) {
						strncpy (i_buffer + i_characterStartIndex - l_toPushLength, a_characters + a_offset, l_toPushLength);
						l_pushedLength += l_toPushLength;
						i_characterStartIndex -= l_pushedLength;
					}
					if (l_pushedLength < a_length) {
						l_toPushLength = min (i_bufferSize - i_characterUntilIndex, a_length - l_pushedLength);
						if (l_toPushLength > 0) {
							strncpy (i_buffer + i_bufferSize - l_toPushLength, a_characters + a_offset + l_pushedLength, l_toPushLength);
							l_pushedLength += l_toPushLength;
							i_characterStartIndex = i_bufferSize - l_pushedLength;
						}
					}
				}
				else {
					l_toPushLength = min (i_characterStartIndex - i_characterUntilIndex, a_length);
					if (l_toPushLength > 0) {
						strncpy (i_buffer + i_characterStartIndex - l_toPushLength, a_characters + a_offset, l_toPushLength);
						l_pushedLength += l_toPushLength;
						i_characterStartIndex -= l_pushedLength;
					}
				}
				if (l_pushedLength < a_length) {
					throw BufferOverflowedException ("");
				}
			}
			
			void PushableReader::pushData (char const & a_character) {
				i_inMethodBuffer [GeneralConstantsConstantsGroup::c_iterationStartNumber] = a_character;
				pushData (i_inMethodBuffer, GeneralConstantsConstantsGroup::c_iterationStartNumber, 1);
			}
			
			int PushableReader::skipWhiteSpaces  () {
				int l_toReadLength = 1;
				int l_readLength = 0;
				int l_readFunctionReturn = GeneralConstantsConstantsGroup::c_unspecifiedInteger;
				while ((l_readFunctionReturn = readFixedLengthData (i_inMethodBuffer, GeneralConstantsConstantsGroup::c_iterationStartNumber, l_toReadLength)) != GeneralConstantsConstantsGroup::c_unspecifiedInteger) {
					if (i_inMethodBuffer [GeneralConstantsConstantsGroup::c_iterationStartNumber] != GeneralConstantsConstantsGroup::c_spaceCharacter && i_inMethodBuffer [GeneralConstantsConstantsGroup::c_iterationStartNumber] != GeneralConstantsConstantsGroup::c_tabCharacter && i_inMethodBuffer [GeneralConstantsConstantsGroup::c_iterationStartNumber] != GeneralConstantsConstantsGroup::c_newLineCharacter && i_inMethodBuffer [GeneralConstantsConstantsGroup::c_iterationStartNumber] != GeneralConstantsConstantsGroup::c_carriageReturnCharacter) {
						pushData (i_inMethodBuffer, GeneralConstantsConstantsGroup::c_iterationStartNumber, l_readFunctionReturn);
						break;
					}
					l_readLength += l_readFunctionReturn;
				}
				return l_readLength;
			}
			
			int PushableReader::skipThrough (string const & a_throughString) {
				int l_toReadLength = 1;
				int l_readLength = 0;
				int l_readFunctionReturn = GeneralConstantsConstantsGroup::c_unspecifiedInteger;
				int l_throughStringLength = a_throughString.length ();
				int l_throughStringMatchedCharactersIndex = GeneralConstantsConstantsGroup::c_unspecifiedInteger;
				while ((l_readFunctionReturn = readFixedLengthData (i_inMethodBuffer, GeneralConstantsConstantsGroup::c_iterationStartNumber, l_toReadLength)) != GeneralConstantsConstantsGroup::c_unspecifiedInteger) {
					l_readLength += l_readFunctionReturn;
					if (l_readFunctionReturn < l_toReadLength) {
						return l_readLength;
					}
					if (i_inMethodBuffer [GeneralConstantsConstantsGroup::c_iterationStartNumber] == a_throughString [l_throughStringMatchedCharactersIndex + 1]) {
						l_throughStringMatchedCharactersIndex ++;
					}
					else {
						l_throughStringMatchedCharactersIndex = GeneralConstantsConstantsGroup::c_unspecifiedInteger;
						if (i_inMethodBuffer [GeneralConstantsConstantsGroup::c_iterationStartNumber] == a_throughString [l_throughStringMatchedCharactersIndex + 1]) {
							l_throughStringMatchedCharactersIndex ++;
						}
					}
					if (l_throughStringMatchedCharactersIndex == l_throughStringLength - 1) {
						return l_readLength;
					}
				}
				return l_readLength;
			}
			
			int PushableReader::skipWhiteSpacesAndFromThroughAreas (string const & a_fromString, string const & a_throughString) {
				int l_fromStringLength = a_fromString.length ();
				int l_toReadLength = l_fromStringLength;
				int l_readLength = 0;
				int l_readFunctionReturn = GeneralConstantsConstantsGroup::c_unspecifiedInteger;
				string l_readData;
				bool l_skipFinished = false;
				//char l_inMethodBuffer [l_fromStringLength];
				char * l_inMethodBuffer = new char [l_fromStringLength];
				while (true) {
					l_readLength += skipWhiteSpaces ();
					l_readFunctionReturn = readFixedLengthData (l_inMethodBuffer, GeneralConstantsConstantsGroup::c_iterationStartNumber, l_toReadLength);
					if (l_readFunctionReturn == GeneralConstantsConstantsGroup::c_unspecifiedInteger) {
						l_skipFinished = true;
					}
					else {
						if (l_readFunctionReturn == l_toReadLength) {
							l_readData = string (l_inMethodBuffer, GeneralConstantsConstantsGroup::c_iterationStartNumber, l_readFunctionReturn);
							if (a_fromString == l_readData) {
								l_readLength += l_readFunctionReturn;
								l_readLength += skipThrough (a_throughString);
							}
							else {
								l_skipFinished = true;
							}
						}
						else {
							l_skipFinished = true;
						}
					}
					if (l_skipFinished) {
						if (l_readFunctionReturn > 0) {
							pushData (l_inMethodBuffer, GeneralConstantsConstantsGroup::c_iterationStartNumber, l_readFunctionReturn);
						}
						return l_readLength;
					}
				}
				delete l_inMethodBuffer;
			}
		}
	}
}

