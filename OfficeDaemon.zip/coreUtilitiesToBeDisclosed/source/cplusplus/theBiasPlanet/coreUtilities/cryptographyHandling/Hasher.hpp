#ifndef __theBiasPlanet_coreUtilities_cryptographyHandling_Hasher_hpp__
	#define __theBiasPlanet_coreUtilities_cryptographyHandling_Hasher_hpp__
	
	#include <random>
	#include <string>
	#include "theBiasPlanet/coreUtilities/visualCplusplusSpecificHeaders/VisualCplusplusSpecificDefinitions.hpp"
	
	using namespace ::std;
	
	namespace theBiasPlanet {
		namespace coreUtilities {
			namespace cryptographyHandling {
				class __theBiasPlanet_coreUtilities_symbolExportingOrImportingForVisualCplusplus__ Hasher {
					private:
						static random_device s_seedGenerator;
						static mt19937 s_randomNumberGenerator;
					public:
						static bool createSalt (unsigned char * const a_saltArray, int const & a_numberOfBytes);
						static bool hashInPbkdf2 (unsigned char * const a_hashArray, string const & a_originalDatum, unsigned char const * const a_saltArray, int const & a_saltLength, int const & a_numberOfIteration, int const & a_keyLength);
				};
			}
		}
	}
#endif

