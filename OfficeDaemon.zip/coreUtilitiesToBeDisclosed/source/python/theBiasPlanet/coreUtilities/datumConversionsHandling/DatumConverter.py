
class DatumConverter:
	@staticmethod
	def getSignedByte (a_byte: int) -> int:
		return a_byte if a_byte < 128 else a_byte - 256
	
	@staticmethod
	def getSignedShort (a_short: int) -> int:
		return a_short if a_short < 32767 else a_short - 65536
	
	@staticmethod
	def getSignedInteger (a_integer: int) -> int:
		return a_integer if a_integer < 2147483647 else a_integer - 4294967296

