from typing import List
from collections import OrderedDict
from wx import DataFormat as wx_DataFormat
import wx
from theBiasPlanet.coreUtilities.clipboardHandling.ClipboardFormatSpecificDataComposite import ClipboardFormatSpecificDataComposite
from theBiasPlanet.coreUtilities.clipboardHandling.WxPythonClipboardEventsHandler import WxPythonClipboardEventsHandler

class WxPythonClipboard:
	@staticmethod
	def setUp (a_datumFormatNameToFormatMap: "OrderedDict [str, wx_DataFormat]", a_preferedDatumFormatName: str) -> bool:
		WxPythonClipboardEventsHandler.s_possibleDatumFormatNameToFormatMap = a_datumFormatNameToFormatMap
		WxPythonClipboardEventsHandler.s_preferedDatumFormatName = a_preferedDatumFormatName
		
		WxPythonClipboardEventsHandler.s_possibleDatumFormats = []
		l_datumFormatName: str = None
		for l_datumFormatName in WxPythonClipboardEventsHandler.s_possibleDatumFormatNameToFormatMap:
			WxPythonClipboardEventsHandler.s_possibleDatumFormats.append (WxPythonClipboardEventsHandler.s_possibleDatumFormatNameToFormatMap [l_datumFormatName])
		return True
	
	@staticmethod
	def openClipboard () -> bool:
		wx.TheClipboard.Open ()
		return True
	
	@staticmethod
	def closeClipboard () -> bool:
		wx.TheClipboard.Close ()
		return True
	
	@staticmethod
	def clearClipboard () -> bool:
		wx.TheClipboard.Clear ()
		return True
	
	@staticmethod
	def getFormatSpecificDataComposite () -> "ClipboardFormatSpecificDataComposite":
		l_wxPythonClipboardEventsHandler: "WxPythonClipboardEventsHandler" = WxPythonClipboardEventsHandler (ClipboardFormatSpecificDataComposite ())
		wx.TheClipboard.GetData (l_wxPythonClipboardEventsHandler)
		return l_wxPythonClipboardEventsHandler.getFormatSpecificDataComposite ()
	
	@staticmethod
	def setFormatSpecificDataComposite (a_formatSpecificDataComposite: "ClipboardFormatSpecificDataComposite") -> bool:
		l_wxPythonClipboardEventsHandler: "WxPythonClipboardEventsHandler" = WxPythonClipboardEventsHandler (a_formatSpecificDataComposite)
		wx.TheClipboard.SetData (l_wxPythonClipboardEventsHandler)
		wx.TheClipboard.Flush ()
		return True

