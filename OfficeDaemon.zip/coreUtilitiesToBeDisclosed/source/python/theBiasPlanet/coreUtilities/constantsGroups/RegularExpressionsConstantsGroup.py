from typing import Pattern
import re

class RegularExpressionsConstantsGroup:
	c_numbersRegularExpression: Pattern = re.compile ("^(\\d*|\\d{1,3}(,\\d{3})*)(\\.\\d+)?([eE][-+]?\\d+)?$")
	c_dateAndTimesRegularExpression: Pattern = re.compile ("(\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2})(.\\d*)?")
	c_datesRegularExpression: Pattern = re.compile ("(\\d{4}-\\d{2}-\\d{2})")
	c_timesRegularExpression: Pattern = re.compile ("(\\d{2}:\\d{2}:\\d{2})")
	c_csharpPackageDelimiterRegularExpression: Pattern = re.compile ("\\.")
	c_windowsDirectoryDelimiterRegularExpression: Pattern = re.compile ("\\\\")
	c_wordRegularExpression: Pattern = re.compile ("(\\w+)")
	c_termRegularExpression: Pattern = re.compile ("(\\S+)")
	c_doubleQuotedTermRegularExpression: Pattern = re.compile ("\"(\\S+)\"")
	c_urlRegularExpression: Pattern = re.compile ("(\\b(https?|ftp|file)://)?[-A-Za-z0-9+&@#/%?=~_|!:,.;]+[-A-Za-z0-9+&@#/%=~_|]")

