## Comments that start with the mark, ##, are instructions for extending this class, where XXX is the class name of the extended class.
from abc import ABCMeta
from collections import OrderedDict
from typing import Generic
from typing import List
from typing import Type
from typing import TypeVar
from theBiasPlanet.coreUtilities.collectionsHandling.ListsFactory import ListsFactory
from theBiasPlanet.coreUtilities.collectionsHandling.MapsFactory import MapsFactory
from theBiasPlanet.coreUtilities.reflectionHandling.ReflectionHandler import ReflectionHandler

T = TypeVar ("T")

class BaseEnumerableConstantsGroup (Generic [T], metaclass=ABCMeta):
	# ## Define this.
	# ## c_instance: "XXX"
	# ## c_instance = XXX () # after the class definition
	
	def __init__ (a_this: "BaseEnumerableConstantsGroup", a_type0: Type [T]) -> None:
		a_this.i_nameToValueMap: "OrderedDict [str, T]"
		
		a_this.i_nameToValueMap = MapsFactory.createOrderedMapExpandingItems (str, a_type0, ReflectionHandler.getFieldNamesAndValues (type (a_this), None, None, ListsFactory.createList (type, type (a_this)), True))
	
	#def getNames () -> "OrderedSet [str]":
	#	return OrderedSet (a_this.i_nameToValueMap.keys ())
	def getNames (a_this: "BaseEnumerableConstantsGroup") -> "OrderedDict [str, object]":
		return  a_this.i_nameToValueMap
	
	def getValues (a_this: "BaseEnumerableConstantsGroup") -> List [T]:
		return list (a_this.i_nameToValueMap.values ())

