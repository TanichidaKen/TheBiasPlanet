
class CharactersSetNamesConstantsGroup:
	c_utf8CharactersSetName: str = "UTF-8"

