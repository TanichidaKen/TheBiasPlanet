#!/bin/bash

declare -a l_commandLineArguments=()
declare l_projectDirectoryPathSettingFlag=false
declare l_projectDirectoryPath="$(pwd)"
declare -i l_commandLineArgumentIndex=7
for l_commandLineArgument in "$@"
do
	if [ "${l_commandLineArgument}" == -p ]
	then
		l_projectDirectoryPathSettingFlag=true
	else
		if [ "${l_projectDirectoryPathSettingFlag}" == true ]
		then
			l_projectDirectoryPath="${l_commandLineArgument}"
		else
			l_commandLineArguments["${l_commandLineArgumentIndex}"]="${l_commandLineArgument}"
			l_commandLineArgumentIndex=(${l_commandLineArgumentIndex}+1)
		fi
		l_projectDirectoryPathSettingFlag=false
	fi
done
l_commandLineArguments[0]="-Duser.dir=$(pwd)"
l_commandLineArguments[1]=-p
l_commandLineArguments[2]="${l_projectDirectoryPath}"
l_commandLineArguments[3]="-Di_projectDirectoryPath=${l_projectDirectoryPath}"
l_commandLineArguments[4]="-Porg.gradle.daemon.idletimeout=1080000000"
l_commandLineArguments[5]="-Porg.gradle.vfs.watch=true"
l_commandLineArguments[6]="-Porg.gradle.jvmargs=-Xmx512M"
set -x
gradle --console plain "${l_commandLineArguments[@]}"

