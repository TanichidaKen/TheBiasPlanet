#!/bin/bash

declare -a l_commandLineArguments=()
declare l_projectDirectoryPathSettingFlag=false
declare l_projectDirectoryPath="$(pwd)"
declare -i l_commandLineArgumentIndex=4
for l_commandLineArgument in "$@"
do
	if [ "${l_commandLineArgument}" == -p ]
	then
		l_projectDirectoryPathSettingFlag=true
	else
		if [ "${l_projectDirectoryPathSettingFlag}" == true ]
		then
			l_projectDirectoryPath="${l_commandLineArgument}"
		else
			l_commandLineArguments["${l_commandLineArgumentIndex}"]="${l_commandLineArgument}"
			l_commandLineArgumentIndex=(${l_commandLineArgumentIndex}+1)
		fi
		l_projectDirectoryPathSettingFlag=false
	fi
done
l_commandLineArguments[0]="-Duser.dir=$(pwd)"
l_commandLineArguments[1]=-p
l_commandLineArguments[2]="${l_projectDirectoryPath}"
l_commandLineArguments[3]="-Dc_projectDirectoryPath=${l_projectDirectoryPath}"
set -x
gradle "${l_commandLineArguments[@]}"

