#ifndef __theBiasPlanet_officeDaemon_programs_OfficeDaemon_hpp__
	#define __theBiasPlanet_officeDaemon_programs_OfficeDaemon_hpp__
	
	#include "theBiasPlanet/unoUtilities/connectionsHandling/UnoConnection.hpp"
	#include "theBiasPlanet/unoUtilities/officeInstancesHandling/OfficeInstance.hpp"
	
	using namespace ::theBiasPlanet::unoUtilities::connectionsHandling;
	using namespace ::theBiasPlanet::unoUtilities::officeInstancesHandling;
	
	namespace theBiasPlanet {
		namespace officeDaemon {
			namespace programs {
				class OfficeDaemon {
					private:
						static list <string> c_officeProgramCommandAndArguments;
						static int c_connectTryingTimes;
						static int c_connectTryingIntervalInMilliseconds;
						Reference <UnoConnection> i_unoConnection;
						Reference <OfficeInstance> i_officeInstance;
					public:
						static int main (int const & a_argumentsNumber, char const * const a_arguments []);
						//static void signalsHandler (int a_signal);
						OfficeDaemon (string a_officeProgramDirectoryPath, string a_unoServerUrl);
						virtual ~OfficeDaemon ();
						virtual bool shutDown ();
				};
			}
		}
	}
#endif

