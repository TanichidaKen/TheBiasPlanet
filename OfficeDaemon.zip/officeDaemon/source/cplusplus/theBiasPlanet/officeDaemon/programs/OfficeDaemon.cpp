#include "theBiasPlanet/officeDaemon/programs/OfficeDaemon.hpp"
#include <chrono>
#include <ctime>
#include <iostream>
#include <exception>
#include <optional>
#include <thread>
#include <signal.h>
#include <systemd/sd-daemon.h>
#include "theBiasPlanet/coreUtilities/constantsGroups/GeneralConstantsConstantsGroup.hpp"
#include "theBiasPlanet/coreUtilities/messaging/Publisher.hpp"
#include "theBiasPlanet/coreUtilities/processesHandling/ProcessHandler.hpp"
#include "theBiasPlanet/coreUtilities/stringsHandling/StringHandler.hpp"
#include "theBiasPlanet/unoUtilities/connectionsHandling/UnoConnectionConnector.hpp"
#include "theBiasPlanet/unoUtilities/programsHandling/UnoProcessEnvironment.hpp"
#include "theBiasPlanet/unoUtilities/stringsHandling/UnoExtendedStringHandler.hpp"

//#include "theBiasPlanet/unoUtilities/documentsHandling/textDocumentsHandling/UnoTextDocument.hpp"

using namespace ::std;
using namespace ::std::chrono;
using namespace ::com::sun::star::frame;
using namespace ::theBiasPlanet::coreUtilities::constantsGroups;
using namespace ::theBiasPlanet::coreUtilities::messaging;
using namespace ::theBiasPlanet::coreUtilities::processesHandling;
using namespace ::theBiasPlanet::coreUtilities::stringsHandling;
using namespace ::theBiasPlanet::unoUtilities::connectionsHandling;
using namespace ::theBiasPlanet::unoUtilities::programsHandling;
using namespace ::theBiasPlanet::unoUtilities::stringsHandling;

//using namespace ::theBiasPlanet::unoUtilities::documentsHandling::textDocumentsHandling;

namespace theBiasPlanet {
	namespace officeDaemon {
		namespace programs {
			int l_resultStatus = 1;
			list <string> OfficeDaemon::c_officeProgramCommandAndArguments {"soffice", "--headless", "--norestore"};
			//list <string> OfficeDaemon::c_officeProgramCommandAndArguments {"soffice", "--display", ":0.0"};
			int OfficeDaemon::c_connectTryingTimes = 20;
			int OfficeDaemon::c_connectTryingIntervalInMilliseconds = 5000;
			
			int OfficeDaemon::main (int const & a_argumentsNumber, char const * const a_arguments []) {
				try {
					Publisher::setLoggingLevel (3);
					if (a_argumentsNumber != 3) {
						l_resultStatus = 2;
						throw runtime_error ("The arguments have to be these.\nThe argument 1: the office program directory path\nThe argument 2: the server url like 'socket,host=localhost,port=2002,tcpNoDelay=1;urp;StarOffice.ComponentContext'");
					}
					string l_officeProgramDirectoryPath = string (a_arguments [1]);
					string l_serverUrl = string (a_arguments [2]);
					
					/*
					struct sigaction l_signalAction;
					sigemptyset (&l_signalAction.sa_mask);
					sigemptyset.sa_flags = 0;
					sigemptyset.sa_handler = OfficeDaemon::signalsHandler;
					sigaction (SIGHUP, &l_signalAction, nullptr);
					*/
					sigset_t l_waitedSignals;
					sigemptyset (&l_waitedSignals);
					sigaddset (&l_waitedSignals, SIGTERM);
					sigprocmask (SIG_BLOCK, &l_waitedSignals, nullptr);
					OfficeDaemon l_officeDaemon (l_officeProgramDirectoryPath, l_serverUrl);
					sd_notify (0, "READY=1");
					cerr << string ("The office daemon has successfully started up.") << endl << flush;
					int l_signal;
					sigwait (&l_waitedSignals, &l_signal);
					sd_notify (0, "STOPPING=1");
					l_officeDaemon.shutDown (); 
					cerr << string ("The office daemon has been successfully shut down.") << endl << flush;
				}
				catch (Exception & l_exception) {
					sd_notifyf (0, "STATUS=Failed to start up: %s\n ERRNO=%i", UnoExtendedStringHandler::getString (l_exception.Message).c_str (), l_resultStatus);
					Publisher::logErrorInformation (StringHandler::format (string ("The office daemon has failed to start up: %s."), UnoExtendedStringHandler::getString (l_exception.Message)));
					return (l_resultStatus);
				}
				catch (exception & l_exception) {
					sd_notifyf (0, "STATUS=Failed to start up: %s\n ERRNO=%i", l_exception.what (), l_resultStatus);
					Publisher::logErrorInformation (StringHandler::format <string> (string ("The office daemon has failed to start up: %s."), l_exception.what ()));
					return (l_resultStatus);
				}
				l_resultStatus = 0;
				return (l_resultStatus);
			}
			
			/*
			void OfficeDaemon::signalsHandler (int a_signal) {
			}
			*/
			
			OfficeDaemon::OfficeDaemon (string a_officeProgramDirectoryPath, string a_unoServerUrl) {
				int l_childProcessInvokingResult = ProcessHandler::execute (a_officeProgramDirectoryPath, c_officeProgramCommandAndArguments, false);
				if (l_childProcessInvokingResult == 0) {
					UnoProcessEnvironment l_localUnoProcessEnvironment = UnoProcessEnvironment (StringHandler::getDateAndTimeString (time (nullptr)));
					UnoConnectionConnector l_unoConnectionConnector = UnoConnectionConnector (l_localUnoProcessEnvironment.getLocalObjectsContext ());
					for (int l_connectTryingIndex = GeneralConstantsConstantsGroup::c_iterationStartingNumber; l_connectTryingIndex < c_connectTryingTimes; l_connectTryingIndex ++) {
						this_thread::sleep_for (milliseconds (c_connectTryingIntervalInMilliseconds));
						try {
							i_unoConnection = l_unoConnectionConnector.connect (a_unoServerUrl, nullopt);
							break;
						}
						catch (Exception & l_exception) {
							if ((l_connectTryingIndex + 1) >= c_connectTryingTimes) {
								throw l_exception;
							}
						}
					}
					i_officeInstance = Reference <OfficeInstance> (new OfficeInstance (i_unoConnection->getRemoteObjectsContext ()));
					/*
					Reference <UnoTextDocument> l_unoTextDocument (UnoTextDocument::createTextDocument (i_unoConnection->getRemoteObjectsContext (), false));
					l_unoTextDocument->insertText ("aaaaa");
					*/
				}
				else {
					throw runtime_error ("Any office instance cannot be created.");
				}
			}
			
			OfficeDaemon::~OfficeDaemon () {
			}
			
			bool OfficeDaemon::shutDown () {
				int l_shutDownStatus =  i_officeInstance->shutDown ();
				i_unoConnection->disconnect ();
				return l_shutDownStatus;
			}
		}
	}
}

