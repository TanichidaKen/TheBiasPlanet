package test;

import test.enumerableconstantsgrouptest1.Test1Test;

final class Test {
	private Test () {
	}
	
	public static void main (String [] p_arguments) throws Exception {
		Test1Test.test ();
	}
}
