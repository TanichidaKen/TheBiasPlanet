package test.enumerableconstantsgrouptest1;

public interface Test1ExtendedConstantsGroup1 extends Test1ConstantsGroup1 {
	String c_value1 = "Value1 overridden";
	String c_value3 = "Value3";
	String c_value4 = "Value4";
}
