package test.enumerableconstantsgrouptest1;

public interface Test1ExtendedConstantsGroup12 extends Test1ConstantsGroup1, Test1ConstantsGroup2 {
	String c_value1 = "Value1 overwritten";
	String c_value4 = "Value4 overwritten";
	String c_value5 = "Value5";
	String c_value6 = "Value6";
}

