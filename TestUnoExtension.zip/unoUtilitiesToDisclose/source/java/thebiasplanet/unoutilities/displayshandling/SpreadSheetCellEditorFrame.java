package thebiasplanet.unoutilities.displayshandling;

import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.GridLayout;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.GroupLayout;
import com.sun.star.lang.WrappedTargetException;
import com.sun.star.uno.XComponentContext;
import com.sun.star.beans.PropertyVetoException;
import com.sun.star.beans.UnknownPropertyException;
import com.sun.star.util.MalformedNumberFormatException;
import thebiasplanet.coreutilities.constantsgroups.*;
import thebiasplanet.coreutilities.messaging.Publisher;
import thebiasplanet.coreutilities.displayshandling.EditorFrame;
import thebiasplanet.coreutilities.displayshandling.SwingComponentsFactory;
import thebiasplanet.coreutilities.displayshandling.SimpleFocusTraversalPolicy;
import thebiasplanet.unoutilities.constantsgroups.*;
import thebiasplanet.unoutilities.stringshandling.UnoExtendedStringsHandler;
import thebiasplanet.unoutilities.documentshandling.spreadsheetsdocumentshandling.UnoSpreadSheetCell;

public class SpreadSheetCellEditorFrame extends EditorFrame {
	private static final int c_defaultControlPanelHeight;
	private static final int c_cellUpMovementIndex;
	private static final int c_cellDownMovementIndex;
	private static final int c_cellLeftMovementIndex;
	private static final int c_cellRightMovementIndex;
	private XComponentContext i_componentContextInXComponentContext;
	private Class i_connectedSpreadSheetCellType;
	protected UnoSpreadSheetCell i_connectedSpreadSheetCell;
	protected JButton i_goUpButton;
	protected JButton i_goDownButton;
	protected JButton i_goLeftButton;
	protected JButton i_goRightButton;
	protected JCheckBox i_autoReconnectCheckBox;
	protected JButton i_reconnectButton;
	protected JButton i_setSelectedOrWholeContentsToCurrentCellButton;
	
	static {
		c_defaultControlPanelHeight = 130;
		c_cellUpMovementIndex = 0;
		c_cellDownMovementIndex = 1;
		c_cellLeftMovementIndex = 2;
		c_cellRightMovementIndex = 3;
	}
	
	public SpreadSheetCellEditorFrame (int a_frameWidth, int a_frameHeight, int a_controlPanelHeight, String a_contentsTextPaneFontName, int a_contentsTextPaneFontSize, XComponentContext a_componentContextInXComponentContext, UnoSpreadSheetCell a_spreadSheetCell, boolean a_isMainFrame) throws UnknownPropertyException, WrappedTargetException, IOException {
		super (a_frameWidth, a_frameHeight, a_controlPanelHeight == GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger ? c_defaultControlPanelHeight: a_controlPanelHeight, a_contentsTextPaneFontName,  a_contentsTextPaneFontSize, GeneralConstantsConstantsGroup.c_emptySpace, a_isMainFrame);
		i_componentContextInXComponentContext = a_componentContextInXComponentContext;
		// center control panel
		i_centerControlPanel.setLayout (new GridLayout (2,1));
		JPanel l_centerControlUpperPanel = new JPanel ();
		GroupLayout l_centerControlUpperPanelLayout = new GroupLayout (l_centerControlUpperPanel);
		l_centerControlUpperPanel.setLayout (l_centerControlUpperPanelLayout);
		JPanel l_reconnectToAnotherSpreadSheetCellPanel = null;
		if (a_spreadSheetCell != null) {
			l_reconnectToAnotherSpreadSheetCellPanel = new JPanel ();
			GroupLayout l_reconnectToAnotherSpreadSheetCellPanelLayout = new GroupLayout (l_reconnectToAnotherSpreadSheetCellPanel);
			l_reconnectToAnotherSpreadSheetCellPanel.setLayout (l_reconnectToAnotherSpreadSheetCellPanelLayout);
			i_goUpButton = SwingComponentsFactory.createButton (UserInterfaceComponentToolTipsConstantsGroup.c_goUP, KeyEvent.VK_U,
				(a_event) -> {
					goToNextCellButtonActionPerformed (a_event, c_cellUpMovementIndex);
				}
			);
			i_goDownButton = SwingComponentsFactory.createButton (UserInterfaceComponentToolTipsConstantsGroup.c_goDown, KeyEvent.VK_D,
				(a_event) -> {
					goToNextCellButtonActionPerformed (a_event, c_cellDownMovementIndex);
				}
			);
			i_goLeftButton = SwingComponentsFactory.createButton (UserInterfaceComponentToolTipsConstantsGroup.c_goLeft, KeyEvent.VK_L,
				(a_event) -> {
					goToNextCellButtonActionPerformed (a_event, c_cellLeftMovementIndex);
				}
			);
			i_goRightButton = SwingComponentsFactory.createButton (UserInterfaceComponentToolTipsConstantsGroup.c_goRight, KeyEvent.VK_R,
				(a_event) -> {
					goToNextCellButtonActionPerformed (a_event, c_cellRightMovementIndex);
				}
			);
			i_autoReconnectCheckBox = SwingComponentsFactory.createCheckBox (UserInterfaceComponentToolTipsConstantsGroup.c_autoReconnect, false);
			i_autoReconnectCheckBox.setEnabled (false);
			i_reconnectButton = SwingComponentsFactory.createButton (UserInterfaceComponentToolTipsConstantsGroup.c_reconnect, KeyEvent.VK_N,
				(a_event) -> {
					reconnectButtonActionPerformed (a_event);
				}
			);
			l_reconnectToAnotherSpreadSheetCellPanelLayout.setHorizontalGroup (l_reconnectToAnotherSpreadSheetCellPanelLayout.createSequentialGroup ().addComponent (i_goLeftButton).addGroup (l_reconnectToAnotherSpreadSheetCellPanelLayout.createParallelGroup (GroupLayout.Alignment.CENTER).addComponent (i_goUpButton).addGroup (l_reconnectToAnotherSpreadSheetCellPanelLayout.createParallelGroup (GroupLayout.Alignment.CENTER).addComponent (i_autoReconnectCheckBox).addComponent (i_reconnectButton)).addComponent (i_goDownButton)).addComponent (i_goRightButton));
			l_reconnectToAnotherSpreadSheetCellPanelLayout.setVerticalGroup (l_reconnectToAnotherSpreadSheetCellPanelLayout.createSequentialGroup ().addComponent (i_goUpButton).addGroup (l_reconnectToAnotherSpreadSheetCellPanelLayout.createParallelGroup (GroupLayout.Alignment.CENTER).addComponent (i_goLeftButton).addGroup (l_reconnectToAnotherSpreadSheetCellPanelLayout.createSequentialGroup ().addComponent (i_autoReconnectCheckBox).addComponent (i_reconnectButton)).addComponent (i_goRightButton)).addComponent (i_goDownButton));
		}
		JPanel l_modifyCurrentSpreadCellValuePanel = new JPanel ();
		i_setSelectedOrWholeContentsToCurrentCellButton = SwingComponentsFactory.createButton (UserInterfaceComponentToolTipsConstantsGroup.c_setSelectedOrWholeContents, KeyEvent.VK_T,
			(a_event) -> {
				setSelectedOrWholeContentsToCurrentCellButtonActionPerformed (a_event);
			}
		);
		l_modifyCurrentSpreadCellValuePanel.add (i_setSelectedOrWholeContentsToCurrentCellButton);
		if (a_spreadSheetCell != null) {
			l_centerControlUpperPanelLayout.setHorizontalGroup (l_centerControlUpperPanelLayout.createParallelGroup (GroupLayout.Alignment.CENTER).addComponent (l_reconnectToAnotherSpreadSheetCellPanel).addComponent (l_modifyCurrentSpreadCellValuePanel));
			l_centerControlUpperPanelLayout.setVerticalGroup (l_centerControlUpperPanelLayout.createSequentialGroup ().addComponent (l_reconnectToAnotherSpreadSheetCellPanel).addComponent (l_modifyCurrentSpreadCellValuePanel));
		}
		else {
			l_centerControlUpperPanelLayout.setHorizontalGroup (l_centerControlUpperPanelLayout.createParallelGroup (GroupLayout.Alignment.CENTER).addComponent (l_modifyCurrentSpreadCellValuePanel));
			l_centerControlUpperPanelLayout.setVerticalGroup (l_centerControlUpperPanelLayout.createSequentialGroup ().addComponent (l_modifyCurrentSpreadCellValuePanel));
		}
		i_centerControlPanel.add (l_centerControlUpperPanel);
		setSpreadSheetCell (a_spreadSheetCell);
		((SimpleFocusTraversalPolicy) getFocusTraversalPolicy ()).insertComponentsBefore (i_saveContentsButton, i_goUpButton, i_goDownButton, i_goLeftButton, i_goRightButton, i_autoReconnectCheckBox, i_reconnectButton, i_setSelectedOrWholeContentsToCurrentCellButton);
		i_saveContentsButton.setEnabled (true);
	}
	
	public SpreadSheetCellEditorFrame (XComponentContext a_componentContextInXComponentContext, UnoSpreadSheetCell a_spreadSheetCell, boolean a_isMainFrame) throws UnknownPropertyException, WrappedTargetException, IOException {
		this (GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger, GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger, GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger, null, GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger, a_componentContextInXComponentContext, a_spreadSheetCell, a_isMainFrame);
	}
	
	private UnoSpreadSheetCell getCurrentSpreadSheetCell () throws Exception {
		UnoSpreadSheetCell l_currentSpreadSheetCell = UnoSpreadSheetCell.getCurrentCell (i_componentContextInXComponentContext);
		return l_currentSpreadSheetCell;
	}
	
	public void getCellValue () throws UnknownPropertyException, WrappedTargetException, IOException {
		if (i_connectedSpreadSheetCell != null) {
			Object l_cellValue = null;
			l_cellValue = i_connectedSpreadSheetCell.getFormulaOrValue ();
			if (l_cellValue != null) {
				i_connectedSpreadSheetCellType = l_cellValue.getClass ();
			}
			else {
				i_connectedSpreadSheetCellType = String.class;
			}
			setContents (UnoExtendedStringsHandler.getString (l_cellValue));
		}
	}
	
	public void saveCellValue () throws UnknownPropertyException, PropertyVetoException, MalformedNumberFormatException, WrappedTargetException {
		if (i_connectedSpreadSheetCell != null) {
			i_connectedSpreadSheetCell.setValue (UnoExtendedStringsHandler.getObject (getContents (), i_connectedSpreadSheetCellType));
		}
	}
	
	/*
	public void saveCompressedCellValue () throws UnknownPropertyException, PropertyVetoException, MalformedNumberFormatException, WrappedTargetException, IOException {
		if (i_connectedSpreadSheetCell != null) {
			i_connectedSpreadSheetCell.setCompressedValue (UnoExtendedStringsHandler.getObject (getContents (), i_connectedSpreadSheetCellType));
		}
	}
	*/
	
	public boolean setSelectedOrWholeContentsToCurrentCell () throws Exception {
		UnoSpreadSheetCell l_currentSpreadSheetCell = getCurrentSpreadSheetCell ();
		if (l_currentSpreadSheetCell != null) {
			Object l_cellValue = l_currentSpreadSheetCell.getFormulaOrValue ();
			Class l_currentSpreadSheetCellType = null;
			if (l_cellValue != null) {
				l_currentSpreadSheetCellType = l_cellValue.getClass ();
			}
			else {
				l_currentSpreadSheetCellType = String.class;
			}
			String l_selectedText = getSelectedText ();
			int l_textLength = 0;
			if (l_selectedText != null) {
				l_textLength = l_selectedText.length ();
				if (l_textLength > 0) {
					if (l_selectedText.charAt (l_textLength - 1) == CharactersConstantsGroup.c_newLine) {
						if (l_textLength > 1) {
							if (l_selectedText.charAt (l_textLength - 2) == CharactersConstantsGroup.c_carriageReturn) {
								l_selectedText = l_selectedText.substring (GeneralConstantsConstantsGroup.c_iterationStartingNumber, l_textLength - 2);
							}
							else {
								l_selectedText = l_selectedText.substring (GeneralConstantsConstantsGroup.c_iterationStartingNumber, l_textLength - 1);
							}
						}
						else {
							l_selectedText = GeneralConstantsConstantsGroup.c_emptySpace;
						}
					}
					else if (l_selectedText.charAt (l_textLength - 1) == CharactersConstantsGroup.c_carriageReturn) {
						l_selectedText = l_selectedText.substring (GeneralConstantsConstantsGroup.c_iterationStartingNumber, l_textLength - 1);
					}
				}
			}
			else {
				l_selectedText = getContents ();
			}
			l_currentSpreadSheetCell.setValue (UnoExtendedStringsHandler.getObject (l_selectedText, l_currentSpreadSheetCellType));
			return true;
		}
		else {
			return false;
		}
	}
	
	public void setSpreadSheetCell (UnoSpreadSheetCell a_spreadSheetCell) throws UnknownPropertyException, WrappedTargetException, IOException {
		i_connectedSpreadSheetCell = a_spreadSheetCell;
		String l_title = null;
		if (i_connectedSpreadSheetCell != null) {
			l_title = String.format (UserInterfaceComponentCaptionsConstantsGroup.c_cellConnectedFormat, i_connectedSpreadSheetCell.getRowIndex (), i_connectedSpreadSheetCell.getColumnIndex ());
			if (i_connectedSpreadSheetCell.getRowIndex () > GeneralConstantsConstantsGroup.c_iterationStartingNumber) {
				i_goUpButton.setEnabled (true);
			}
			else {
				i_goUpButton.setEnabled (false);
			}
			if (i_connectedSpreadSheetCell.getColumnIndex () > GeneralConstantsConstantsGroup.c_iterationStartingNumber) {
				i_goLeftButton.setEnabled (true);
			}
			else {
				i_goLeftButton.setEnabled (false);
			}
		}
		else {
			l_title = UserInterfaceComponentCaptionsConstantsGroup.c_cellNotConnected;
		}
		setTitle (l_title);
		getCellValue ();
	}
	
	public boolean setCurrentSpreadSheetCell () throws Exception {
		UnoSpreadSheetCell l_currentSpreadSheetCell = getCurrentSpreadSheetCell ();
		if (l_currentSpreadSheetCell != null) {
			setSpreadSheetCell (l_currentSpreadSheetCell);
			return true;
		}
		else {
			return false;
		}
	}
	
	public void goToNextCell (int a_whereTo) throws com.sun.star.lang.IndexOutOfBoundsException, UnknownPropertyException, WrappedTargetException, IOException {
		if (a_whereTo == c_cellUpMovementIndex) {
			i_connectedSpreadSheetCell = i_connectedSpreadSheetCell.getUpperCell ();
		}
		else if (a_whereTo == c_cellDownMovementIndex) {
			i_connectedSpreadSheetCell = i_connectedSpreadSheetCell.getDownCell ();
		}
		else if (a_whereTo == c_cellLeftMovementIndex) {
			i_connectedSpreadSheetCell = i_connectedSpreadSheetCell.getLeftCell ();
		}
		else if (a_whereTo == c_cellRightMovementIndex) {
			i_connectedSpreadSheetCell = i_connectedSpreadSheetCell.getRightCell ();
		}
		setSpreadSheetCell (i_connectedSpreadSheetCell);
		i_connectedSpreadSheetCell.setFocus ();
	}
	
	@Override
	protected void saveContentsButtonActionPerformed (ActionEvent a_event) {
		try {
			saveCellValue ();
		}
		catch (UnknownPropertyException | PropertyVetoException | MalformedNumberFormatException | WrappedTargetException l_exception) {
			Publisher.show (l_exception.toString ());
		}
	}
	
	/*
	@Override
	protected void saveCompressedContentsButtonActionPerformed (ActionEvent a_event) {
		try {
			saveCompressedCellValue ();
		}
		catch (UnknownPropertyException | PropertyVetoException | MalformedNumberFormatException | WrappedTargetException | IOException l_exception) {
			Publisher.show (l_exception.toString ());
		}
	}
	*/
	
	private void goToNextCellButtonActionPerformed (ActionEvent a_event, int a_whereTo) {
		try {
			goToNextCell (a_whereTo);
		}
		catch (com.sun.star.lang.IndexOutOfBoundsException | UnknownPropertyException | WrappedTargetException | IOException l_exception) {
			Publisher.show (l_exception.toString ());
		}
	}
	
	private void reconnectButtonActionPerformed (ActionEvent a_event) {
		try {
			if (!setCurrentSpreadSheetCell ()) {
				Publisher.show (UnoMessagesConstantsGroup.c_noCurrentSpreadSheetCell);
			}
		}
		catch (Exception l_exception) {
			Publisher.show (l_exception.toString ());
		}
	}
	
	private void setSelectedOrWholeContentsToCurrentCellButtonActionPerformed (ActionEvent a_event) {
		try {
			if (!setSelectedOrWholeContentsToCurrentCell ()) {
				Publisher.show (UnoMessagesConstantsGroup.c_noCurrentSpreadSheetCell);
			}
		}
		catch (Exception l_exception) {
			Publisher.show (l_exception.toString ());
		}
	}
}
