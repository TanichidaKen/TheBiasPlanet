package thebiasplanet.unoutilities.displayshandling;

import java.awt.Rectangle;
import com.sun.star.uno.XComponentContext;
import com.sun.star.awt.XWindow;
import com.sun.star.frame.XDesktop;
import com.sun.star.frame.XFrame;
import thebiasplanet.unoutilities.constantsgroups.*;
import thebiasplanet.unoutilities.serviceshandling.UnoServiceHandler;

public class UnoDesktopHandler {
	public static Rectangle getUnoDesktopBoundary (XComponentContext a_componentContextInXComponentContext) throws com.sun.star.uno.Exception {
		XDesktop l_unoDesktopInXDesktop = (XDesktop) UnoServiceHandler.getServiceInstance (a_componentContextInXComponentContext, UnoServiceNamesConstantsGroup.c_com_sun_star_frame_Desktop, XDesktop.class);
		XFrame l_unoFrameInXFrame = l_unoDesktopInXDesktop.getCurrentFrame ();
		XWindow l_desktopContainerWindowInXWindow = l_unoFrameInXFrame.getContainerWindow ();
		com.sun.star.awt.Rectangle l_desktopContainerWindowBoundary = l_desktopContainerWindowInXWindow.getPosSize ();
		return new Rectangle (l_desktopContainerWindowBoundary.X, l_desktopContainerWindowBoundary.Y, l_desktopContainerWindowBoundary.Width, l_desktopContainerWindowBoundary.Height);
	}
}
