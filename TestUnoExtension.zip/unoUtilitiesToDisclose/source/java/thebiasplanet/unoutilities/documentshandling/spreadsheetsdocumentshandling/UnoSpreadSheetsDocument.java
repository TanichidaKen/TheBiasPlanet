package thebiasplanet.unoutilities.documentshandling.spreadsheetsdocumentshandling;

import java.util.List;
import java.util.Map;
import java.util.HashMap;
import com.sun.star.lang.XComponent;
import com.sun.star.lang.Locale;
import com.sun.star.lang.WrappedTargetException;
import com.sun.star.frame.XFrame;
import com.sun.star.frame.XController;
import com.sun.star.frame.XDispatchHelper;
import com.sun.star.frame.XDispatchProvider;
import com.sun.star.uno.XComponentContext;
import com.sun.star.uno.UnoRuntime;
import com.sun.star.sheet.XSpreadsheetDocument;
import com.sun.star.sheet.XSpreadsheets;
import com.sun.star.sheet.XSpreadsheet;
import com.sun.star.sheet.XSpreadsheetView;
import com.sun.star.util.XNumberFormatsSupplier;
import com.sun.star.util.XNumberFormats;
import com.sun.star.util.MalformedNumberFormatException;
import com.sun.star.beans.XPropertySet;
import com.sun.star.beans.PropertyValue;
import com.sun.star.beans.UnknownPropertyException;
import com.sun.star.container.NoSuchElementException;
import com.sun.star.document.XDocumentPropertiesSupplier;
import com.sun.star.view.XSelectionChangeListener;
import com.sun.star.view.XSelectionSupplier;
import com.sun.star.style.XStyleFamiliesSupplier;
import thebiasplanet.coreutilities.collectionshandling.ArrayFactory;
import thebiasplanet.coreutilities.constantsgroups.*;
import thebiasplanet.unoutilities.documentshandling.UnoDocument;
import thebiasplanet.unoutilities.serviceshandling.UnoServiceHandler;
import thebiasplanet.unoutilities.constantsgroups.*;
import thebiasplanet.unoutilities.constantsgroups.propertynamessets.*;
import thebiasplanet.unoutilities.propertieshandling.UnoPropertiesHandler;

public class UnoSpreadSheetsDocument extends UnoDocument {
	private XSpreadsheetDocument i_spreadSheetsDocumentInXSpreadsheetDocument;
	private XDocumentPropertiesSupplier i_spreadSheetsDocumentInXDocumentPropertiesSupplier;
	private XController i_controllerInXController;
	private XSpreadsheetView i_controllerInXSpreadsheetView;
	private XFrame i_frameInXFrame;
	private XDispatchProvider i_frameInXDispatchProvider;
	private XSelectionSupplier i_controllerInXSelectionSupplier;
	private XSpreadsheets i_spreadSheetsInXSpreadsheets;
	private XStyleFamiliesSupplier i_spreadSheetsDocumentInXStyleFamiliesSupplier;
	private XDispatchHelper i_dispatchHelperInXDispatchHelper;
	private Locale i_defaultLocale;
	private XNumberFormats i_cellValueExpressionFormatsInXNumberFormats;
	private int i_dateExpressionFormatKey;
	private int i_timeExpressionFormatKey;
	private int i_dateTimeExpressionFormatKey;
	private int i_booleanExpressionFormatKey;
	private int i_stringExpressionFormatKey;
	private int i_integerExpressionFormatKey;
	private Map <Integer, Integer> i_numberOfDecimalPlacesToDoubleExpressionFormatKeyMap;
	private Map <Integer, Integer> i_doubleExpressionFormatKeyToNumberOfDecimalPlacesMap;
	
	public UnoSpreadSheetsDocument (XComponentContext a_componentContextInXComponentContext, XComponent a_spreadSheetsDocumentInXComponent) throws Exception, MalformedNumberFormatException {
		super (a_componentContextInXComponentContext, a_spreadSheetsDocumentInXComponent);
		i_spreadSheetsDocumentInXSpreadsheetDocument = (XSpreadsheetDocument) UnoRuntime.queryInterface (XSpreadsheetDocument.class, a_spreadSheetsDocumentInXComponent);
		if (i_spreadSheetsDocumentInXSpreadsheetDocument == null) {
			throw new Exception (UnoMessagesConstantsGroup.c_isNotSpreadSheetsDocument);
		}
		i_defaultLocale = new Locale ();
		XNumberFormatsSupplier l_spreadSheetsDocumentInXNumberFormatsSupplier = UnoRuntime.queryInterface (XNumberFormatsSupplier.class, i_spreadSheetsDocumentInXSpreadsheetDocument);
		i_cellValueExpressionFormatsInXNumberFormats = l_spreadSheetsDocumentInXNumberFormatsSupplier.getNumberFormats ();
		i_dateExpressionFormatKey = getAndSetIfNecessaryCellValueExpressionFormatKey (UnoSpreadSheetCellFormatStringsConstantsGroup.c_standardDate);
		i_timeExpressionFormatKey = getAndSetIfNecessaryCellValueExpressionFormatKey (UnoSpreadSheetCellFormatStringsConstantsGroup.c_standardTime);
		i_dateTimeExpressionFormatKey = getAndSetIfNecessaryCellValueExpressionFormatKey (UnoSpreadSheetCellFormatStringsConstantsGroup.c_standardDateTime);
		i_booleanExpressionFormatKey = getAndSetIfNecessaryCellValueExpressionFormatKey (UnoSpreadSheetCellFormatStringsConstantsGroup.c_standardBoolean);
		i_stringExpressionFormatKey = getAndSetIfNecessaryCellValueExpressionFormatKey (UnoSpreadSheetCellFormatStringsConstantsGroup.c_standardString);
		i_integerExpressionFormatKey = getAndSetIfNecessaryCellValueExpressionFormatKey (UnoSpreadSheetCellFormatStringsConstantsGroup.c_standardInteger);
		i_numberOfDecimalPlacesToDoubleExpressionFormatKeyMap = new HashMap <Integer, Integer> ();
		i_doubleExpressionFormatKeyToNumberOfDecimalPlacesMap = new HashMap <Integer, Integer> ();
		int l_doubleDefaultExpressionFormatKey = GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger;
		l_doubleDefaultExpressionFormatKey = i_cellValueExpressionFormatsInXNumberFormats.queryKey (UnoSpreadSheetCellFormatStringsConstantsGroup.c_globalNumber, i_defaultLocale, false);
		if (l_doubleDefaultExpressionFormatKey == GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger) {
			l_doubleDefaultExpressionFormatKey = i_cellValueExpressionFormatsInXNumberFormats.queryKey (UnoSpreadSheetCellFormatStringsConstantsGroup.c_standardNumber, i_defaultLocale, false);
		}
		if (l_doubleDefaultExpressionFormatKey == GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger) {
			// Doesn't seem possible
		}
		else {
			Integer l_defaultNumberOfDecimalPlaces = Integer.valueOf (GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger);
			Integer l_doubleDefaultExpressionFormatKeyInInteger = Integer.valueOf (l_doubleDefaultExpressionFormatKey);
			i_numberOfDecimalPlacesToDoubleExpressionFormatKeyMap.put (l_defaultNumberOfDecimalPlaces, l_doubleDefaultExpressionFormatKeyInInteger);
			i_doubleExpressionFormatKeyToNumberOfDecimalPlacesMap.put (l_doubleDefaultExpressionFormatKeyInInteger, l_defaultNumberOfDecimalPlaces);
		}
		i_spreadSheetsDocumentInXDocumentPropertiesSupplier = (XDocumentPropertiesSupplier) UnoRuntime.queryInterface (XDocumentPropertiesSupplier.class, i_spreadSheetsDocumentInXSpreadsheetDocument);
		i_spreadSheetsDocumentInXStyleFamiliesSupplier = (XStyleFamiliesSupplier) UnoRuntime.queryInterface (XStyleFamiliesSupplier.class, i_spreadSheetsDocumentInXSpreadsheetDocument);
		i_controllerInXController = (XController) UnoRuntime.queryInterface (XController.class, i_unoDocumentInXModel.getCurrentController ());
		i_controllerInXSpreadsheetView = (XSpreadsheetView) UnoRuntime.queryInterface (XSpreadsheetView.class, i_controllerInXController);
		i_frameInXFrame = i_controllerInXController.getFrame ();
		i_frameInXDispatchProvider = (XDispatchProvider) UnoRuntime.queryInterface (XDispatchProvider.class, i_frameInXFrame);
		i_controllerInXSelectionSupplier = (XSelectionSupplier) UnoRuntime.queryInterface (XSelectionSupplier.class, i_controllerInXSpreadsheetView);
		i_spreadSheetsInXSpreadsheets = i_spreadSheetsDocumentInXSpreadsheetDocument.getSheets ();
		i_dispatchHelperInXDispatchHelper = (XDispatchHelper) UnoServiceHandler.getServiceInstance (i_componentContextInXComponentContext, UnoServiceNamesConstantsGroup.c_com_sun_star_frame_DispatchHelper, XDispatchHelper.class);
	}
	
	private int getAndSetIfNecessaryCellValueExpressionFormatKey (String a_formatString) throws MalformedNumberFormatException {
		int l_formatKey = i_cellValueExpressionFormatsInXNumberFormats.queryKey (a_formatString, i_defaultLocale, false);
		if (l_formatKey == GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger) {
			l_formatKey = i_cellValueExpressionFormatsInXNumberFormats.addNew (a_formatString, i_defaultLocale);
		}
		return l_formatKey;
	}
	
	public static UnoSpreadSheetsDocument createSpreadSheetsDocument (XComponentContext a_componentContextInXComponentContext, boolean a_hiddenly) throws Exception, com.sun.star.io.IOException {
		return new UnoSpreadSheetsDocument (a_componentContextInXComponentContext, UnoDocument.createUnoDocumentOrOpenUnoDocumentFile (a_componentContextInXComponentContext, UnoSpecialFileUrlsConstantsGroup.c_calcNewDocument, a_hiddenly));
	}
	
	public static UnoSpreadSheetsDocument openSpreadSheetsDocumentFile (XComponentContext a_componentContextInXComponentContext, String a_fileUrl, boolean a_hiddenly) throws Exception, com.sun.star.io.IOException {
		return new UnoSpreadSheetsDocument (a_componentContextInXComponentContext, UnoDocument.createUnoDocumentOrOpenUnoDocumentFile (a_componentContextInXComponentContext, a_fileUrl, a_hiddenly));
	}
	
	public static UnoSpreadSheetsDocument getCurrentSpreadSheetsDocument (XComponentContext a_componentContextInXComponentContext) throws Exception {
		return new UnoSpreadSheetsDocument (a_componentContextInXComponentContext, getCurrentUnoDocument (a_componentContextInXComponentContext));
	}
	
	public static UnoSpreadSheetsDocument getSpreadSheetsDocument (XComponentContext a_componentContextInXComponentContext, String a_fileName) throws Exception {
		return new UnoSpreadSheetsDocument (a_componentContextInXComponentContext, getUnoDocument (a_componentContextInXComponentContext, a_fileName));
	}
	
	public XSpreadsheetDocument getSpreadSheetsDocumentInXSpreadsheetDocument () {
		return i_spreadSheetsDocumentInXSpreadsheetDocument;
	}
	
	public XFrame getFrameInXFrame () {
		return i_frameInXFrame;
	}
	
	public XDispatchProvider getFrameInXDispatchProvider () {
		return i_frameInXDispatchProvider;
	}
	
	public XSpreadsheets getSpreadSheetsInXSpreadsheets () {
		return i_spreadSheetsInXSpreadsheets;
	}
	
	@Override
	public boolean equals (Object a_spreadSheetsDocumentToBeComparedWith) {
		if (a_spreadSheetsDocumentToBeComparedWith != null) {
			UnoSpreadSheetsDocument l_spreadSheetsDocumentToBeComparedWith = null;
			if (a_spreadSheetsDocumentToBeComparedWith instanceof UnoSpreadSheetsDocument) {
				l_spreadSheetsDocumentToBeComparedWith = (UnoSpreadSheetsDocument) a_spreadSheetsDocumentToBeComparedWith;
			}
			return UnoRuntime.areSame (i_spreadSheetsDocumentInXSpreadsheetDocument, l_spreadSheetsDocumentToBeComparedWith.getSpreadSheetsDocumentInXSpreadsheetDocument ());
		}
		else {
			return false;
		}
	}
	
	public void dispatch (UnoDispatchSlotsConstantsGroup.BaseDispatchSlot a_dispatchSlot, List <Object> a_argumentValues) {
		List <PropertyValue> l_dispatchArgumentProperties = null;
		if (a_dispatchSlot.c_argumentPropertyNamesSet != null) {
			l_dispatchArgumentProperties = UnoPropertiesHandler.buildPropertyNameValuePairs (a_dispatchSlot.c_argumentPropertyNamesSet.getValues (), a_argumentValues);
		}
		i_dispatchHelperInXDispatchHelper.executeDispatch (i_frameInXDispatchProvider, a_dispatchSlot.c_url, UnoGeneralConstantsConstantsGroup.c_anyUnspecifiedString, GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger, ArrayFactory. <PropertyValue>createArray (PropertyValue.class, l_dispatchArgumentProperties));
	}
	
	public int getDateExpressionFormatKey () {
		return i_dateExpressionFormatKey;
	}
	
	public int getTimeExpressionFormatKey () {
		return i_timeExpressionFormatKey;
	}
	
	public int getDateTimeExpressionFormatKey () {
		return i_dateTimeExpressionFormatKey;
	}
	
	public int getBooleanExpressionFormatKey () {
		return i_booleanExpressionFormatKey;
	}
	
	public int getStringExpressionFormatKey () {
		return i_stringExpressionFormatKey;
	}
	
	public int getIntegerExpressionFormatKey () {
		return i_integerExpressionFormatKey;
	}
	
	// a_numberOfDecimalPlaces: GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger for automatic number of decimal places
	public int getDoubleExpressionFormatKey (int a_numberOfDecimalPlaces) throws MalformedNumberFormatException {
		Integer l_numberOfDecimalPlacesInInteger = new Integer (a_numberOfDecimalPlaces);
		Integer l_doubleExpressionFormatKeyInInteger = i_numberOfDecimalPlacesToDoubleExpressionFormatKeyMap.get (l_numberOfDecimalPlacesInInteger);
		int l_doubleExpressionFormatKey = GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger;
		if (l_doubleExpressionFormatKeyInInteger == null) {
			String l_doubleExpressionFormatString = String.format (String.format (UnoSpreadSheetCellFormatStringsConstantsGroup.c_standardDoubleTemplate, a_numberOfDecimalPlaces), UnoGeneralConstantsConstantsGroup.c_numberExpressionModelNumber);
			l_doubleExpressionFormatKey = getAndSetIfNecessaryCellValueExpressionFormatKey (l_doubleExpressionFormatString);
			l_doubleExpressionFormatKeyInInteger = new Integer (l_doubleExpressionFormatKey);
			i_numberOfDecimalPlacesToDoubleExpressionFormatKeyMap.put (l_numberOfDecimalPlacesInInteger, l_doubleExpressionFormatKeyInInteger);
			i_doubleExpressionFormatKeyToNumberOfDecimalPlacesMap.put (l_doubleExpressionFormatKeyInInteger, l_numberOfDecimalPlacesInInteger);
		}
		else {
			l_doubleExpressionFormatKey = l_doubleExpressionFormatKeyInInteger.intValue ();
		}
		return l_doubleExpressionFormatKey;
	}
	
	public int getNumberOfDecimalPlaces (int a_cellValueExpressionFormatKey) throws UnknownPropertyException, WrappedTargetException {
		Integer l_cellValueExpressionFormatKeyInInteger = new Integer (a_cellValueExpressionFormatKey);
		Integer l_numberOfDecimalPlacesInInteger = i_doubleExpressionFormatKeyToNumberOfDecimalPlacesMap.get (l_cellValueExpressionFormatKeyInInteger);
		int l_numberOfDecimalPlaces = GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger;
		if (l_numberOfDecimalPlacesInInteger != null) {
			l_numberOfDecimalPlaces = l_numberOfDecimalPlacesInInteger.intValue ();
		}
		else {
			XPropertySet l_cellValueExpressionFormatPropertiesSetInXPropertySet = i_cellValueExpressionFormatsInXNumberFormats.getByKey (a_cellValueExpressionFormatKey);
			if (l_cellValueExpressionFormatPropertiesSetInXPropertySet != null) {
				String l_formatString = (String) l_cellValueExpressionFormatPropertiesSetInXPropertySet.getPropertyValue (UnoSpreadSheetCellValueExpressionFormatPropertyNamesSet.c_formatString);
				if (l_formatString.equals (UnoSpreadSheetCellFormatStringsConstantsGroup.c_globalNumber) || l_formatString.equals (UnoSpreadSheetCellFormatStringsConstantsGroup.c_standardNumber)) {
					l_numberOfDecimalPlaces = GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger;
				}
				else {
					int l_periodIndex = GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger;
					l_periodIndex = l_formatString.lastIndexOf (GeneralConstantsConstantsGroup.c_radixPointCharacter);
					if (l_periodIndex == GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger) {
						l_numberOfDecimalPlaces = GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger;
					}
					else {
						int l_formatStringLength = l_formatString.length ();
						l_numberOfDecimalPlaces = 0;
						for (int l_characterIndex = l_periodIndex + 1; l_characterIndex < l_formatStringLength; l_characterIndex ++) {
							if (l_formatString.charAt (l_characterIndex) != UnoGeneralConstantsConstantsGroup.c_digitPlaceCharacter) {
								break;
							}
							else {
								l_numberOfDecimalPlaces ++;
							}
						}
						l_numberOfDecimalPlacesInInteger = new Integer (l_numberOfDecimalPlaces);
						i_numberOfDecimalPlacesToDoubleExpressionFormatKeyMap.put (l_numberOfDecimalPlacesInInteger, l_cellValueExpressionFormatKeyInInteger);
						i_doubleExpressionFormatKeyToNumberOfDecimalPlacesMap.put (l_cellValueExpressionFormatKeyInInteger, l_numberOfDecimalPlacesInInteger);
					}
				}
			}
			else {
				l_numberOfDecimalPlaces = GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger;
			}
		}
		return l_numberOfDecimalPlaces;
	}
	
	public XSpreadsheetView getControllerInXSpreadsheetView () {
		return i_controllerInXSpreadsheetView;
	}
	
	public Object getSelection () {
		return i_controllerInXSelectionSupplier.getSelection ();
	}
	
	public void setSelection (Object a_selectedObject) {
		i_controllerInXSelectionSupplier.select (a_selectedObject);
	}
	
	public void insertSpreadSheet (String a_spreadSheetName, int a_spreadSheetIndex) {
		i_spreadSheetsInXSpreadsheets.insertNewByName (a_spreadSheetName, (short) a_spreadSheetIndex);
	}
	
	public void copySpreadSheet (String a_originalSpreadSheetName, String a_copiedSpreadSheetName, int a_copiedSpreadSheetIndex) {
		i_spreadSheetsInXSpreadsheets.copyByName (a_originalSpreadSheetName, a_copiedSpreadSheetName, (short) a_copiedSpreadSheetIndex);
	}
	
	public void removeSpreadSheet (String a_spreadSheetName) throws NoSuchElementException, WrappedTargetException {
		i_spreadSheetsInXSpreadsheets.removeByName (a_spreadSheetName);
	}
	
	public UnoSpreadSheet getSpreadSheet (String a_spreadSheetName) throws Exception, NoSuchElementException, WrappedTargetException {
		XSpreadsheet l_spreadSheetInXSpreadsheet = (XSpreadsheet) UnoRuntime.queryInterface(XSpreadsheet.class, i_spreadSheetsInXSpreadsheets.getByName (a_spreadSheetName));
		return new UnoSpreadSheet (this, l_spreadSheetInXSpreadsheet);
	}
	
	public UnoSpreadSheet getActiveSpreadSheet () throws Exception {
		return new UnoSpreadSheet (this, i_controllerInXSpreadsheetView.getActiveSheet ());
	}
	
	public void activateSpreadSheet (UnoSpreadSheet a_spreadSheet) throws NoSuchElementException {
		i_controllerInXSpreadsheetView.setActiveSheet (a_spreadSheet.getSpreadSheetInXSpreadsheet ());
	}
	
	public void addSelectionChangeListener (XSelectionChangeListener a_selectionChangeEventsListener) {
		i_controllerInXSelectionSupplier.addSelectionChangeListener (a_selectionChangeEventsListener);
	}
	
	public void removeSelectionChangeListener (XSelectionChangeListener a_selectionChangeEventsListener) {
		i_controllerInXSelectionSupplier.removeSelectionChangeListener (a_selectionChangeEventsListener);
	}
}
