package thebiasplanet.unoutilities.documentshandling.spreadsheetsdocumentshandling;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import com.sun.star.lang.WrappedTargetException;
import com.sun.star.uno.AnyConverter;
import com.sun.star.uno.UnoRuntime;
import com.sun.star.uno.XComponentContext;
import com.sun.star.uno.XInterface;
import com.sun.star.util.XModifyBroadcaster;
import com.sun.star.util.XModifyListener;
import com.sun.star.sheet.CellDeleteMode;
import com.sun.star.sheet.CellInsertMode;
import com.sun.star.sheet.XCellRangeMovement;
import com.sun.star.sheet.XSheetCellRange;
import com.sun.star.sheet.XSheetCellRangeContainer;
import com.sun.star.sheet.XSpreadsheet;
import com.sun.star.container.XNamed;
import com.sun.star.container.XIndexAccess;
import com.sun.star.table.CellRangeAddress;
import com.sun.star.table.XCellRange;
import com.sun.star.beans.XPropertySet;
import com.sun.star.beans.UnknownPropertyException;
import thebiasplanet.coreutilities.constantsgroups.*;
import thebiasplanet.unoutilities.constantsgroups.*;
import thebiasplanet.unoutilities.constantsgroups.propertynamessets.*;

public class UnoSpreadSheet {
	private UnoSpreadSheetsDocument i_spreadSheetsDocument;
	private XSpreadsheet i_spreadSheetInXSpreadsheet;
	private XNamed i_spreadSheetInXNamed;
	private XCellRangeMovement i_spreadSheetInXCellRangeMovement;
	private XPropertySet i_spreadSheetInXPropertySet;
	private XModifyBroadcaster i_spreadSheetInXModifyBroadcaster;
	
	public UnoSpreadSheet (UnoSpreadSheetsDocument a_spreadSheetsDocument, XSpreadsheet a_spreadSheetInXSpreadsheet) throws Exception {
		if (a_spreadSheetsDocument == null) {
			throw new Exception (UnoMessagesConstantsGroup.c_spreadSheetsDocumentNotSpecified);
		}
		i_spreadSheetsDocument = a_spreadSheetsDocument;
		if (a_spreadSheetInXSpreadsheet == null) {
			throw new Exception (UnoMessagesConstantsGroup.c_spreadSheetNotSpecified);
		}
		i_spreadSheetInXSpreadsheet = a_spreadSheetInXSpreadsheet;
		i_spreadSheetInXNamed = (XNamed) UnoRuntime.queryInterface (XNamed.class, i_spreadSheetInXSpreadsheet);
		i_spreadSheetInXCellRangeMovement = (XCellRangeMovement) UnoRuntime.queryInterface (XCellRangeMovement.class, i_spreadSheetInXSpreadsheet);
		i_spreadSheetInXPropertySet = (XPropertySet) UnoRuntime.queryInterface (XPropertySet.class, i_spreadSheetInXSpreadsheet);
	}
	
	public static UnoSpreadSheet getCurrentSpreadSheet (XComponentContext a_componentContextInXComponentContext) throws Exception {
		UnoSpreadSheetsDocument l_currentSpreadSheetsDocument = UnoSpreadSheetsDocument.getCurrentSpreadSheetsDocument (a_componentContextInXComponentContext);
		return new UnoSpreadSheet (l_currentSpreadSheetsDocument, l_currentSpreadSheetsDocument.getControllerInXSpreadsheetView ().getActiveSheet ());
	}
	
	public static UnoSpreadSheet getSpreadSheet (XComponentContext a_componentContextInXComponentContext, String a_fileName) throws Exception {
		UnoSpreadSheetsDocument l_spreadSheetsDocument = UnoSpreadSheetsDocument.getSpreadSheetsDocument (a_componentContextInXComponentContext, a_fileName);
		return new UnoSpreadSheet (l_spreadSheetsDocument, l_spreadSheetsDocument.getControllerInXSpreadsheetView ().getActiveSheet ());
	}
	
	public boolean isActive () {
		try {
			return equals (i_spreadSheetsDocument.getActiveSpreadSheet ());
		}
		catch (Exception l_exception) {
			return false;
		}
	}
	
	@Override
	public boolean equals (Object a_spreadSheetToBeComparedWith) {
    	if (a_spreadSheetToBeComparedWith != null) {
			UnoSpreadSheet l_spreadSheetToBeComparedWith = null;
			if (a_spreadSheetToBeComparedWith instanceof UnoSpreadSheet) {
				l_spreadSheetToBeComparedWith = (UnoSpreadSheet) a_spreadSheetToBeComparedWith;
			}
			else {
				return false;
			}
			if (i_spreadSheetsDocument.equals (l_spreadSheetToBeComparedWith.getSpreadSheetsDocument ())) {
				if (getSpreadSheetName ().equals (l_spreadSheetToBeComparedWith.getSpreadSheetName ())) {
					return true;
				}
				else {
					return false;
				}
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}
	
	public UnoSpreadSheetsDocument getSpreadSheetsDocument () {
		return i_spreadSheetsDocument;
	}
	
	public XSpreadsheet getSpreadSheetInXSpreadsheet () {
		return i_spreadSheetInXSpreadsheet;
	}
	
	public XPropertySet getSpreadSheetInXPropertySet () {
		return i_spreadSheetInXPropertySet;
	}
	
	public String getPageStyleName () throws UnknownPropertyException, WrappedTargetException {
		return (String) i_spreadSheetInXPropertySet.getPropertyValue (UnoSpreadSheetPropertyNamesSet.c_pageStyle);
	}
	
	public UnoSpreadSheetCell getSpreadSheetCell (int a_cellRowIndex, int a_cellColumnIndex) throws com.sun.star.lang.IndexOutOfBoundsException {
		return new UnoSpreadSheetCell (this, i_spreadSheetInXSpreadsheet.getCellByPosition (a_cellColumnIndex, a_cellRowIndex));
	}
	
	public UnoSpreadSheetCell getCurrentSpreadSheetCell () {
		if (!isActive ()) {
			return null;
		}
		XInterface l_currentSelectionInXInterface = (XInterface) getSpreadSheetsDocument ().getUnoDocumentinXModel ().getCurrentSelection ();
		XSheetCellRange l_currentCellsInXSheetCellRange = (XSheetCellRange) UnoRuntime.queryInterface (XSheetCellRange.class, l_currentSelectionInXInterface);
		if (l_currentCellsInXSheetCellRange == null) {
			XSheetCellRangeContainer l_currentCellsInXSheetCellRangeContainer = (XSheetCellRangeContainer) UnoRuntime.queryInterface (XSheetCellRangeContainer.class, l_currentSelectionInXInterface);
			if (l_currentCellsInXSheetCellRangeContainer != null) {
				try {
					l_currentCellsInXSheetCellRange = (XSheetCellRange) AnyConverter.toObject (XSheetCellRange.class , l_currentCellsInXSheetCellRangeContainer.getByIndex (GeneralConstantsConstantsGroup.c_iterationStartingNumber));
				}
				catch (com.sun.star.lang.IndexOutOfBoundsException | WrappedTargetException l_exception) {
					return null;
				}
			}
			else {
				return null;
			}
		}
		if (l_currentCellsInXSheetCellRange != null) {
			try {
				return new UnoSpreadSheetCell (this, l_currentCellsInXSheetCellRange.getCellByPosition (GeneralConstantsConstantsGroup.c_iterationStartingNumber, GeneralConstantsConstantsGroup.c_iterationStartingNumber));
			}
			catch (com.sun.star.lang.IndexOutOfBoundsException l_exception) {
				return null;
			}
		}
		else {
			return null;
		}
	}
	
	public ArrayList <UnoSpreadSheetCell> getCurrentSpreadSheetCells () {
		if (!isActive ()) {
			return null;
		}
		XInterface l_currentSelectionInXInterface = (XInterface) getSpreadSheetsDocument ().getUnoDocumentinXModel ().getCurrentSelection ();
		XSheetCellRangeContainer l_currentCellsInXSheetCellRangeContainer = (XSheetCellRangeContainer) UnoRuntime.queryInterface (XSheetCellRangeContainer.class, l_currentSelectionInXInterface);
		XSheetCellRange l_currentCellsInXSheetCellRange = null;
		ArrayList <UnoSpreadSheetCell> l_currentCells = new ArrayList <UnoSpreadSheetCell> ();
		for (int l_cellsRangeIndex = GeneralConstantsConstantsGroup.c_iterationStartingNumber; ; l_cellsRangeIndex ++) {
			if (l_currentCellsInXSheetCellRangeContainer == null) {
				l_currentCellsInXSheetCellRange = (XSheetCellRange) UnoRuntime.queryInterface (XSheetCellRange.class, l_currentSelectionInXInterface);
			}
			else {
				try {
					l_currentCellsInXSheetCellRange = (XSheetCellRange) AnyConverter.toObject (XSheetCellRange.class , l_currentCellsInXSheetCellRangeContainer.getByIndex (l_cellsRangeIndex));
				}
				catch (com.sun.star.lang.IndexOutOfBoundsException | WrappedTargetException l_exception) {
					break;
				}
			}
			if (l_currentCellsInXSheetCellRange != null) {
				m_rowsLoop:
				for (int l_cellRowInCellsRangeIndex = GeneralConstantsConstantsGroup.c_iterationStartingNumber; ; l_cellRowInCellsRangeIndex ++) {
					for (int l_cellColumnInCellsRangeIndex = GeneralConstantsConstantsGroup.c_iterationStartingNumber; ; l_cellColumnInCellsRangeIndex ++) {
						try {
							l_currentCells.add (new UnoSpreadSheetCell (this, l_currentCellsInXSheetCellRange.getCellByPosition (l_cellColumnInCellsRangeIndex, l_cellRowInCellsRangeIndex)));
						}
						catch (com.sun.star.lang.IndexOutOfBoundsException l_exception) {
							if (l_cellColumnInCellsRangeIndex == GeneralConstantsConstantsGroup.c_iterationStartingNumber) {
								break m_rowsLoop;
							}
							else {
								break;
							}
						}
					}
				}
			}
			else {
				break;
			}
			if (l_currentCellsInXSheetCellRangeContainer == null) {
				break;
			}
		}
		return l_currentCells;
	}
	
	public XCellRange getSpreadSheetCellsRangeInXCellRange (int a_cellTopRowIndex, int a_cellLeftColumnIndex, int a_cellBottomRowIndex, int a_cellRightColumnIndex) throws com.sun.star.lang.IndexOutOfBoundsException {
		return i_spreadSheetInXSpreadsheet.getCellRangeByPosition (a_cellLeftColumnIndex, a_cellTopRowIndex, a_cellRightColumnIndex, a_cellBottomRowIndex);
	}
	
	public String getSpreadSheetName () {
		return i_spreadSheetInXNamed.getName ();
	}
	
	public int getSpreadSheetIndex () throws com.sun.star.lang.IndexOutOfBoundsException, WrappedTargetException {
		XIndexAccess l_spreadSheetsInXIndexAccess = UnoRuntime.queryInterface (XIndexAccess.class, i_spreadSheetsDocument.getSpreadSheetsInXSpreadsheets ());
		int l_spreadSheetsCount = l_spreadSheetsInXIndexAccess.getCount ();
		String l_spreadSheetName = getSpreadSheetName ();
		XNamed l_spreadSheetInXNamed = null;
		int l_spreadSheetIndex = GeneralConstantsConstantsGroup.c_iterationStartingNumber;
		for (; l_spreadSheetIndex < l_spreadSheetsCount; l_spreadSheetIndex ++) {
			l_spreadSheetInXNamed = UnoRuntime.queryInterface (XNamed.class, l_spreadSheetsInXIndexAccess.getByIndex (l_spreadSheetIndex));
			if (l_spreadSheetName.equals (l_spreadSheetInXNamed.getName ())) {
				break;
			}
		}
		if (l_spreadSheetIndex < l_spreadSheetsCount) {
			return l_spreadSheetIndex;
		}
		else {
			return GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger;
		}
	}
	
	public void insertRows (int a_startRowIndex, int a_endRowIndex) throws com.sun.star.lang.IndexOutOfBoundsException, WrappedTargetException {
		CellRangeAddress l_cellsRangeAddress = new CellRangeAddress ();
		l_cellsRangeAddress.Sheet = (short) getSpreadSheetIndex ();
		l_cellsRangeAddress.StartRow = a_startRowIndex;
		l_cellsRangeAddress.EndRow = a_endRowIndex;
		i_spreadSheetInXCellRangeMovement.insertCells (l_cellsRangeAddress, CellInsertMode.ROWS);
	}
	
	public void insertColumns (int a_startColumnIndex, int a_endColumnIndex) throws com.sun.star.lang.IndexOutOfBoundsException, WrappedTargetException {
		CellRangeAddress l_cellsRangeAddress = new CellRangeAddress ();
		l_cellsRangeAddress.Sheet = (short) getSpreadSheetIndex ();
		l_cellsRangeAddress.StartColumn = a_startColumnIndex;
		l_cellsRangeAddress.EndColumn = a_endColumnIndex;
		i_spreadSheetInXCellRangeMovement.insertCells (l_cellsRangeAddress, CellInsertMode.COLUMNS);
	}
	
	public void removeRows (int a_startRowIndex, int a_endRowIndex) throws com.sun.star.lang.IndexOutOfBoundsException, WrappedTargetException {
		CellRangeAddress l_cellsRangeAddress = new CellRangeAddress ();
		l_cellsRangeAddress.Sheet = (short) getSpreadSheetIndex ();
		l_cellsRangeAddress.StartRow = a_startRowIndex;
		l_cellsRangeAddress.EndRow = a_endRowIndex;
		i_spreadSheetInXCellRangeMovement.removeRange (l_cellsRangeAddress, CellDeleteMode.ROWS);
	}
	
	public void removeColumns (int a_startColumnIndex, int a_endColumnIndex) throws com.sun.star.lang.IndexOutOfBoundsException, WrappedTargetException {
		CellRangeAddress l_cellsRangeAddress = new CellRangeAddress ();
		l_cellsRangeAddress.Sheet = (short) getSpreadSheetIndex ();
		l_cellsRangeAddress.StartColumn = a_startColumnIndex;
		l_cellsRangeAddress.EndColumn = a_endColumnIndex;
		i_spreadSheetInXCellRangeMovement.removeRange (l_cellsRangeAddress, CellDeleteMode.COLUMNS);
	}
	
	public void addModificationEventsListener (XModifyListener a_eventListener) {
		i_spreadSheetInXModifyBroadcaster.addModifyListener (a_eventListener);
	}
	
	public void removeModificationEventsListener (XModifyListener a_eventListener) {
		i_spreadSheetInXModifyBroadcaster.removeModifyListener (a_eventListener);
	}
	
	/*
	a_numberOfRemainingColumns: the number of remaining columns. If it's unspecified, it is determined by the number of caption columns of the above row.
	a_leafIsList: true if the leaf is a list; false if the leaf is a String
	return: the cell for the next key. Null if there is no next key.
	*/
	@SuppressWarnings("unchecked")
	public <T, U> UnoSpreadSheetCell buildCascadeMap (UnoSpreadSheetCell a_startSpreadSheetCell, LinkedHashMap <T, U> a_mapToBeBuilt, int a_numberOfRemainingColumns, boolean a_leafIsList) throws IOException {
		UnoSpreadSheetCell l_nextCell = a_startSpreadSheetCell;
		if (a_numberOfRemainingColumns == GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger) {
			UnoSpreadSheetCell l_captionCell = null;
			try {
				l_captionCell = a_startSpreadSheetCell.getUpperCell ();
			}
			catch (com.sun.star.lang.IndexOutOfBoundsException l_exception) {
				return null;
			}
			a_numberOfRemainingColumns = 0;
			while (true) {
				if (l_captionCell.getBackgroundColor () == UnoPixelValuesConstantsGroup.c_parameterCaptionBackgroundPixelValue) {
					a_numberOfRemainingColumns ++;
				}
				else {
					break;
				}
				try {
					l_captionCell = l_captionCell.getRightCell ();
				}
				catch (com.sun.star.lang.IndexOutOfBoundsException l_exception) {
					break;
				}
			}
		}
		boolean l_isFirstRow = true;
		while (true) {
			if (l_nextCell == null) {
				return null;
			}
			if (!l_isFirstRow) {
				UnoSpreadSheetCell l_leftCell = null;
				try {
					 l_leftCell = l_nextCell.getLeftCell ();
					 if (l_leftCell.getValue () != null) {
						 // The row doesn't belong to this map
						 return l_leftCell;
					 }
				}
				catch (com.sun.star.lang.IndexOutOfBoundsException l_exception) {
				}
			}
			T l_key = (T) l_nextCell.getValue ();
			if (l_key == null) {
				return null;
			}
			UnoSpreadSheetCell l_rightCell = null;
			try {
				l_rightCell = l_nextCell.getRightCell ();
			}
			catch (com.sun.star.lang.IndexOutOfBoundsException l_exception) {
				// This won't happen unless a_numberOfRemainingColumns is erroneously specified.
				break;
			}
			if (a_numberOfRemainingColumns > 2) {
				LinkedHashMap <T, Object> l_childMap = new LinkedHashMap <T, Object> ();
				l_nextCell = buildCascadeMap (l_rightCell, l_childMap, a_numberOfRemainingColumns - 1, a_leafIsList);
				a_mapToBeBuilt.put (l_key, (U) l_childMap);
			}
			else {
				ArrayList <T> l_childList = new ArrayList <T> ();
				l_nextCell  =  buildList (l_rightCell, l_childList, false, GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger);
				if (a_leafIsList) {
					a_mapToBeBuilt.put (l_key, (U) l_childList);
				}
				else {
					// There should be only one element in the list; if not, only the first element will be used.
					a_mapToBeBuilt.put (l_key, (U) l_childList.get (GeneralConstantsConstantsGroup.c_iterationStartingNumber));
				}
			}
			l_isFirstRow = false;
		}
		return null;
	}
	
	/*
	a_numberOfColumns: the number of columns (the key column and the list columns). If it's unspecified, it is determined by the number of caption columns of the above row.
	*/
	@SuppressWarnings("unchecked")
	public <T> void buildObjectToListsMap (UnoSpreadSheetCell a_startSpreadSheetCell, LinkedHashMap <T, List <List <T>>> a_mapToBeBuilt, int a_numberOfColumns) throws IOException {
		UnoSpreadSheetCell l_nextCell = a_startSpreadSheetCell;
		if (a_numberOfColumns == GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger) {
			UnoSpreadSheetCell l_captionCell = null;
			try {
				l_captionCell = a_startSpreadSheetCell.getUpperCell ();
			}
			catch (com.sun.star.lang.IndexOutOfBoundsException l_exception) {
				return;
			}
			a_numberOfColumns = 0;
			while (true) {
				if (l_captionCell.getBackgroundColor () == UnoPixelValuesConstantsGroup.c_parameterCaptionBackgroundPixelValue) {
					a_numberOfColumns ++;
				}
				else {
					break;
				}
				try {
					l_captionCell = l_captionCell.getRightCell ();
				}
				catch (com.sun.star.lang.IndexOutOfBoundsException l_exception) {
					break;
				}
			}
		}
		int l_keyColumnIndex = l_nextCell.getColumnIndex ();
		while (true) {
			if (l_nextCell == null) {
				return;
			}
			T l_key = (T) l_nextCell.getValue ();
			if (l_key == null) {
				return;
			}
			// Actually, l_listColumnCell isn't a list column cell at this point, but will be moved to the left most list column cell soon.
			UnoSpreadSheetCell l_listColumnCell = l_nextCell;
			UnoSpreadSheetCell l_nextCellCandidate = null;
			ArrayList <List <T>> l_value = new ArrayList <List <T>> ();
			l_nextCell = null;
			for (int l_numberOfRemainingColumns = a_numberOfColumns - 1; l_numberOfRemainingColumns > 0; l_numberOfRemainingColumns --) {
				try {
					l_listColumnCell = l_listColumnCell.getRightCell ();
				}
				catch (com.sun.star.lang.IndexOutOfBoundsException l_exception) {
					// This won't happen unless a_numberOfColumns is erroneously specified.
					break;
				}
				ArrayList <T> l_childList = new ArrayList <T> ();
				l_nextCellCandidate = buildList (l_listColumnCell, l_childList, false, l_keyColumnIndex);
				if (l_nextCellCandidate != null) {
					l_nextCell = l_nextCellCandidate;
				}
				l_value.add (l_childList);
			}
			a_mapToBeBuilt.put (l_key, l_value);
		}
	}
	
	/*
	a_standAlone: true if this list isn't a part of a map, but a standalone list; false otherwise
	a_keysColumnIndex: the column of keys of the map to which this list belongs. This is valid only when a_standAlone is false.
	return: the cell for the next key. Null if there is no next key.
	*/
	@SuppressWarnings("unchecked")
	public <T> UnoSpreadSheetCell buildList (UnoSpreadSheetCell a_startSpreadSheetCell, List <T> a_listToBeBuilt, boolean a_standAlone, int a_keysColumnIndex) throws IOException {
		UnoSpreadSheetCell l_nextCell = a_startSpreadSheetCell;
		boolean l_isFirstRow = true;
		while (true) {
			if (l_nextCell == null || l_nextCell.getValue () == null || l_nextCell.getBackgroundColor () == UnoPixelValuesConstantsGroup.c_parameterCaptionBackgroundPixelValue) {
				return null;
			}
			if (!a_standAlone && !l_isFirstRow) {
				UnoSpreadSheetCell l_keysColumnCell = null;
				try {
					if (a_keysColumnIndex != GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger) {
						l_keysColumnCell = l_nextCell.getSpreadSheet ().getSpreadSheetCell (l_nextCell.getRowIndex (), a_keysColumnIndex);
					}
					// If a_keysColumnIndex isn't specified, the left cell is the keys column.
					else {
						l_keysColumnCell = l_nextCell.getLeftCell ();
					}
					if (l_keysColumnCell.getValue () != null) {
						// the row doesn't belong to this map
						return l_keysColumnCell;
					}
				}
				catch (com.sun.star.lang.IndexOutOfBoundsException l_exception) {
					// There is no keys column.
				}
			}
			T l_value = (T) l_nextCell.getValue ();
			a_listToBeBuilt.add (l_value);
			try {
				 l_nextCell = l_nextCell.getDownCell ();
			}
			catch (com.sun.star.lang.IndexOutOfBoundsException l_exception) {
				l_nextCell = null;
			}
			l_isFirstRow = false;
		}
	}
}

