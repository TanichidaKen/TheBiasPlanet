package thebiasplanet.unoutilities.documentshandling;

import java.util.ArrayList;
import java.nio.file.Paths;
import com.sun.star.lang.XComponent;
import com.sun.star.lang.WrappedTargetException;
import com.sun.star.uno.XComponentContext;
import com.sun.star.uno.UnoRuntime;
import com.sun.star.frame.XModel;
import com.sun.star.frame.XStorable2;
import com.sun.star.frame.XDesktop;
import com.sun.star.frame.FrameSearchFlag;
import com.sun.star.frame.XComponentLoader;
import com.sun.star.beans.PropertyValue;
import com.sun.star.util.XCloseable;
import com.sun.star.util.CloseVetoException;
import com.sun.star.container.XEnumeration;
import com.sun.star.container.NoSuchElementException;
import thebiasplanet.coreutilities.constantsgroups.*;
import thebiasplanet.coreutilities.collectionshandling.ListFactory;
import thebiasplanet.coreutilities.collectionshandling.ArrayFactory;
import thebiasplanet.unoutilities.constantsgroups.*;
import thebiasplanet.unoutilities.constantsgroups.propertynamessets.*;
import thebiasplanet.unoutilities.serviceshandling.UnoServiceHandler;
import thebiasplanet.unoutilities.propertieshandling.UnoPropertiesHandler;

public class UnoDocument {
	protected XComponentContext i_componentContextInXComponentContext;
	protected XModel i_unoDocumentInXModel;
	protected XStorable2 i_unoDocumentInXStorable2;
	
	public UnoDocument (XComponentContext a_componentContextInXComponentContext, XComponent a_unoDocumentInXComponent) throws Exception {
		if (a_componentContextInXComponentContext == null) {
			throw new Exception (UnoMessagesConstantsGroup.c_componentContextNotSpecified);
		}
		i_componentContextInXComponentContext = a_componentContextInXComponentContext;
		if (a_unoDocumentInXComponent == null) {
			throw new Exception (UnoMessagesConstantsGroup.c_unoDocumentNotSpecified);
		}
		i_unoDocumentInXModel = (XModel) UnoRuntime.queryInterface (XModel.class, a_unoDocumentInXComponent);
		i_unoDocumentInXStorable2 = (XStorable2) UnoRuntime.queryInterface (XStorable2.class, i_unoDocumentInXModel);
	}
	
	protected static XComponent createUnoDocumentOrOpenUnoDocumentFile (XComponentContext a_componentContextInXComponentContext, String a_fileUrl, boolean a_hiddenly) throws Exception, com.sun.star.io.IOException {
		XComponentLoader l_desktopInXComponentLoader = (XComponentLoader) UnoServiceHandler.getServiceInstance (a_componentContextInXComponentContext, UnoServiceNamesConstantsGroup.c_com_sun_star_frame_Desktop, XComponentLoader.class);
		ArrayList <PropertyValue> l_loadProperties = null;
		l_loadProperties = UnoPropertiesHandler.buildPropertyNameValuePairs (UnoDocumentOpeningEnumerablePropertyNamesSet.c_instance.getValues (), ListFactory. <Object>createArrayList (Boolean.valueOf (false), Boolean.valueOf (a_hiddenly)));
		return l_desktopInXComponentLoader.loadComponentFromURL (a_fileUrl.replaceAll (RegularExpressionsConstantsGroup.c_windowsDirectoryDelimiterRegularExpression.pattern (), LiteralExpressionsConstantsGroup.c_directoryDelimiter), UnoSpecialFrameNamesConstantsGroup.c_new, FrameSearchFlag.CREATE, ArrayFactory. <PropertyValue>createArray (PropertyValue.class, l_loadProperties));
	}
	
	protected static XComponent getCurrentUnoDocument (XComponentContext a_componentContextInXComponentContext) throws Exception {
		XDesktop l_desktopInXDesktop = (XDesktop) UnoServiceHandler.getServiceInstance (a_componentContextInXComponentContext,    UnoServiceNamesConstantsGroup.c_com_sun_star_frame_Desktop, XDesktop.class);
		return l_desktopInXDesktop.getCurrentComponent ();
	}
	
	protected static XComponent getUnoDocument (XComponentContext a_componentContextInXComponentContext, String a_fileName) throws Exception {
		XDesktop l_desktopInXDesktop = (XDesktop) UnoServiceHandler.getServiceInstance (a_componentContextInXComponentContext,    UnoServiceNamesConstantsGroup.c_com_sun_star_frame_Desktop, XDesktop.class);
		XEnumeration l_unoComponentsInXEnumeration = l_desktopInXDesktop.getComponents ().createEnumeration ();
		while (l_unoComponentsInXEnumeration.hasMoreElements ()) {
			XStorable2 l_unoComponentInXStorable2 = null;
			try {
				l_unoComponentInXStorable2 = (XStorable2) UnoRuntime.queryInterface (XStorable2.class, l_unoComponentsInXEnumeration.nextElement ());
			}
			catch (NoSuchElementException | WrappedTargetException l_exception) {
				// Practically, never would happen
				break;
			}
			if (l_unoComponentInXStorable2 == null) {
				continue;
			}
			try {
				if (Paths.get (l_unoComponentInXStorable2.getLocation ()).getFileName ().toString ().equals (a_fileName)) {
					return (XComponent) UnoRuntime.queryInterface (XComponent.class, l_unoComponentInXStorable2);
				}
			}
			// The possibility is that 'getLocation' returned null.
			catch (IllegalArgumentException l_exception) {
				continue;
			}
		}
		return null;
	}
	
	public XComponentContext getComponentContextInXComponentContext () {
		return i_componentContextInXComponentContext;
	}
	
	public XModel getUnoDocumentinXModel () {
		return i_unoDocumentInXModel;
	}
	
	
	public void store () throws com.sun.star.io.IOException {
		i_unoDocumentInXStorable2.storeSelf (new PropertyValue [0]);
	}
	
	public void storeAtUrl (String a_fileUrl) throws com.sun.star.io.IOException {
		i_unoDocumentInXStorable2.storeAsURL (a_fileUrl.replaceAll (RegularExpressionsConstantsGroup.c_windowsDirectoryDelimiterRegularExpression.pattern (), LiteralExpressionsConstantsGroup.c_directoryDelimiter), new PropertyValue [0]);
	}
	
	// Use UnoSpreadSheetsDocumentStoringFilterNamesConstantsGroup for a_filterName.
	public void storeAtUrl (String a_fileUrl, String a_filterName, Object a_filterData) throws com.sun.star.io.IOException {
		ArrayList <PropertyValue> l_storingProperties = UnoPropertiesHandler.buildPropertyNameValuePairs (UnoDocumentStoringEnumerablePropertyNamesSet.c_instance.getValues (), ListFactory. <Object>createArrayList (a_filterName, a_filterData));
		i_unoDocumentInXStorable2.storeAsURL (a_fileUrl.replaceAll ("\\\\", "/"), ArrayFactory. <PropertyValue>createArray (PropertyValue.class, l_storingProperties));
	}
	
	public void close () throws CloseVetoException {
		XCloseable l_unoDocumentInXCloseable = (XCloseable) UnoRuntime.queryInterface (XCloseable.class, i_unoDocumentInXStorable2);
		l_unoDocumentInXCloseable.close (false); 
	}
}
