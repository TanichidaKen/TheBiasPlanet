package thebiasplanet.unoutilities.connectionshandling;

import java.util.StringTokenizer;
import java.util.List;
import com.sun.star.connection.XConnection;
import com.sun.star.connection.XConnector;
import com.sun.star.uno.XComponentContext;
import thebiasplanet.unoutilities.serviceshandling.UnoServiceHandler;
import thebiasplanet.unoutilities.constantsgroups.*;

public class UnoConnectionConnector extends UnoConnectionFactory {
	public UnoConnectionConnector (XComponentContext a_localComponentContextInXComponentContext) throws com.sun.star.uno.Exception {
		super (a_localComponentContextInXComponentContext);
		initialize ();
	}
	
	public final UnoConnection connect (String a_url, List <UnoConnectionEventListener> a_eventListeners) throws com.sun.star.uno.Exception {
		StringTokenizer l_urlTokenizer = new StringTokenizer (a_url, UnoLiteralExpressionsConstantsGroup.c_connectionUrlDlimiter);
		XConnector l_unoConnectionConnectorInXConnector = (XConnector) UnoServiceHandler.getServiceInstance (i_localComponentContextInXComponentContext, UnoServiceNamesConstantsGroup.c_com_sun_star_connection_Connector, XConnector.class);
		XConnection l_connectionInXConnection = l_unoConnectionConnectorInXConnector.connect (l_urlTokenizer.nextToken ());
		UnoConnection l_unoConnection = setupConnection (l_connectionInXConnection, l_urlTokenizer, a_eventListeners);
		return l_unoConnection;
	}
}
