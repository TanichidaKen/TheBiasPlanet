package thebiasplanet.unoutilities.connectionshandling;

import java.util.List;
import com.sun.star.lang.XEventListener;
import com.sun.star.lang.XComponent;
import com.sun.star.lang.EventObject;
import com.sun.star.uno.XComponentContext;

public class UnoConnection implements XEventListener {
	private XComponentContext i_remoteComponentContextInXComponentContext;
	private XComponent i_bridgeInXComponent;
	private List <UnoConnectionEventListener> i_eventListeners;
	
	UnoConnection (XComponentContext a_remoteComponentContextInXComponentContext, XComponent a_bridgeInXComponent, List <UnoConnectionEventListener> a_eventListeners) {
		i_remoteComponentContextInXComponentContext = a_remoteComponentContextInXComponentContext;
		i_bridgeInXComponent = a_bridgeInXComponent;
		i_eventListeners = a_eventListeners;
		i_bridgeInXComponent.addEventListener (this);
		EventObject l_event = new EventObject (this);
		if (i_eventListeners != null) {
			for (UnoConnectionEventListener l_eventListener: i_eventListeners){
				l_eventListener.connected (l_event);
			}
		}
	}
	
	public final XComponentContext getRemoteComponentContextInXComponentContext () {
		return i_remoteComponentContextInXComponentContext;
	}
	
	public final void disconnect () {
		if (i_bridgeInXComponent != null) {
			i_bridgeInXComponent.dispose ();
		}
	}
	
	@Override
	public final void disposing (EventObject a_event) {
		a_event.Source = this;
		if (i_eventListeners != null) {
			for (UnoConnectionEventListener l_listener: i_eventListeners) {
				l_listener.disconnected (a_event);
			}
		}
		i_remoteComponentContextInXComponentContext = null;
		i_bridgeInXComponent = null;
		i_eventListeners = null;
	}
}
