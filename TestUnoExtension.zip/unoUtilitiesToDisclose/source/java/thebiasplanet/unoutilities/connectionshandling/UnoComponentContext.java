package thebiasplanet.unoutilities.connectionshandling;

import java.util.Map;
import com.sun.star.uno.XComponentContext;
import com.sun.star.lang.XMultiComponentFactory;
import thebiasplanet.unoutilities.constantsgroups.*;

public class UnoComponentContext implements XComponentContext {
	private XComponentContext i_originalComponentContextInXComponentContext;
	private Map <String, Object> i_extraNameToValueMap;
	
	public UnoComponentContext (XComponentContext a_originalComponentContextInXComponentContext, Map <String, Object> a_extraNameToValueMap) throws com.sun.star.uno.Exception {
		if (a_originalComponentContextInXComponentContext == null) {
			throw new com.sun.star.uno.Exception (UnoMessagesConstantsGroup.c_componentContextNotSpecified);
		}
		i_originalComponentContextInXComponentContext = a_originalComponentContextInXComponentContext;
		i_extraNameToValueMap = a_extraNameToValueMap;
	}
	
	@Override
	public final Object getValueByName (String a_name) {
		if (i_extraNameToValueMap != null && i_extraNameToValueMap.containsKey (a_name)) {
			return i_extraNameToValueMap.get (a_name);
		}
		return i_originalComponentContextInXComponentContext.getValueByName (a_name);
	}
	
	@Override
	public final XMultiComponentFactory getServiceManager () {
		return i_originalComponentContextInXComponentContext.getServiceManager ();
	}
	
	public final boolean isFromSameOrigin (UnoComponentContext a_unoComponentContext) {
		if ((a_unoComponentContext ==  null) || (i_extraNameToValueMap.get (UnoComponentContextPropertyNamesConstantsGroup.c_identification) == null)) {
			return false;
		}
		if (i_extraNameToValueMap.get (UnoComponentContextPropertyNamesConstantsGroup.c_identification).equals (a_unoComponentContext.getValueByName (UnoComponentContextPropertyNamesConstantsGroup.c_identification))) {
			return true;
		}
		else {
			return false;
		}
	}
}
