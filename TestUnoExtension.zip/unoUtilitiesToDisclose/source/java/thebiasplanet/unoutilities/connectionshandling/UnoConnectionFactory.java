package thebiasplanet.unoutilities.connectionshandling;

import java.util.List;
import java.util.StringTokenizer;
import com.sun.star.uno.UnoRuntime;
import com.sun.star.uno.XComponentContext;
import com.sun.star.bridge.XBridgeFactory;
import com.sun.star.bridge.XBridge;
import com.sun.star.bridge.BridgeExistsException;
import com.sun.star.connection.XConnection;
import com.sun.star.lang.XComponent;
import thebiasplanet.unoutilities.serviceshandling.UnoServiceHandler;
import thebiasplanet.unoutilities.constantsgroups.*;
;

abstract public class UnoConnectionFactory {
	protected XComponentContext i_localComponentContextInXComponentContext;
	protected XBridgeFactory i_bridgeFactoryInXBridgeFactory;
	
	protected UnoConnectionFactory (XComponentContext a_localComponentContextInXComponentContext) {
		super ();
		i_localComponentContextInXComponentContext = a_localComponentContextInXComponentContext;
	}
	
	protected final void initialize () throws com.sun.star.uno.Exception {
		i_bridgeFactoryInXBridgeFactory = (XBridgeFactory) UnoServiceHandler.getServiceInstance (i_localComponentContextInXComponentContext, UnoServiceNamesConstantsGroup.c_com_sun_star_bridge_BridgeFactory, XBridgeFactory.class);
	}
	
	protected final UnoConnection setupConnection (XConnection a_connectionInXConnection, StringTokenizer a_urlTokenizer, List <UnoConnectionEventListener> a_eventListeners) throws com.sun.star.uno.Exception {
		XBridge l_bridgeInXBridge = null;
		try {
			l_bridgeInXBridge = i_bridgeFactoryInXBridgeFactory.createBridge ("", a_urlTokenizer.nextToken(), a_connectionInXConnection, (a_instanceName) -> {return i_localComponentContextInXComponentContext;});
		}
		catch (BridgeExistsException l_exception) {
			// This can't happen
		}
		Object l_remoteComponentContext =  l_bridgeInXBridge.getInstance (a_urlTokenizer.nextToken ());
		if (l_remoteComponentContext == null) {
				throw new com.sun.star.uno.Exception (UnoMessagesConstantsGroup.c_remoteInstanceNotProvided, null);
		}
		XComponentContext l_remoteComponentContextInXComponentContext = (XComponentContext) UnoRuntime.queryInterface (XComponentContext.class, l_remoteComponentContext);
		XComponent l_bridgeInXComponent = (XComponent) UnoRuntime.queryInterface (XComponent.class, l_bridgeInXBridge);
		UnoConnection l_unoConnection = new UnoConnection (l_remoteComponentContextInXComponentContext, l_bridgeInXComponent, a_eventListeners);
		return l_unoConnection;
	}
}
