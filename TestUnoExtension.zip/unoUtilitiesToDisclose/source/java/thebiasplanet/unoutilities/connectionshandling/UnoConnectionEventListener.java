package thebiasplanet.unoutilities.connectionshandling;

import com.sun.star.lang.EventObject;

public interface UnoConnectionEventListener {
	public void connected (EventObject a_event);
	
	public void disconnected (EventObject a_event);
}
