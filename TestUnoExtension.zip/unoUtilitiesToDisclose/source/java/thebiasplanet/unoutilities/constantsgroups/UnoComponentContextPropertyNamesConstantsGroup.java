package thebiasplanet.unoutilities.constantsgroups;

public interface UnoComponentContextPropertyNamesConstantsGroup {
	String c_identification = "identification";
}

