package thebiasplanet.unoutilities.constantsgroups;

public interface UnoLiteralExpressionsConstantsGroup {
	String c_connectionUrlDlimiter = ";";
}
