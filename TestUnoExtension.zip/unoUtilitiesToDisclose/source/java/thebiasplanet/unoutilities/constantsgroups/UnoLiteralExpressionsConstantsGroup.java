package thebiasplanet.unoutilities.constantsgroups;

public interface UnoLiteralExpressionsConstantsGroup {
	String c_connectionUrlDlimiter = ";";
	String c_moduleDlimiter = "::";
	String c_unoServiceNameFormat = "%s.%s";
	String c_unoIdlFileNameFormat = String.format ("%%s.%s", UnoFileNameSuffixesConstantsGroup.c_unoIdlFileNameSuffix);
	String c_unoModuleBeginningRelativeExpressionFormat = "module %s {";
	String c_unoModuleEndRelativeExpressionFormat = "};";
}
