package thebiasplanet.unoutilities.constantsgroups;

public interface UnoGeneralConstantsConstantsGroup {
	String c_anyUnspecifiedString = "";
	char c_digitPlaceCharacter = '0';
	double c_numberExpressionModelNumber = 0.0;
	String c_cellSpecificationExpressionTemplate = "$%s$%d";
}
