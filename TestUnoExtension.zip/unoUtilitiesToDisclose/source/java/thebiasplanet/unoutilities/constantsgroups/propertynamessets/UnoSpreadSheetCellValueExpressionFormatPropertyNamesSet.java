package thebiasplanet.unoutilities.constantsgroups.propertynamessets;

public interface UnoSpreadSheetCellValueExpressionFormatPropertyNamesSet extends UnoPropertyNamesSet {
	String c_formatString = "FormatString";
}
