package thebiasplanet.unoutilities.constantsgroups.propertynamessets;

public interface UnoDocumentStoringPropertyNamesSet extends UnoPropertyNamesSet {
	String c_filterName = "FilterName";
	String c_filterData = "FilterData";
}
