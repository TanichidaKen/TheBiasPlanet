package thebiasplanet.unoutilities.constantsgroups.propertynamessets;

public interface Uno_uno_GoToCellPropertyNamesSet extends UnoPropertyNamesSet {
	String c_destinationPoint_String = "ToPoint";
}
