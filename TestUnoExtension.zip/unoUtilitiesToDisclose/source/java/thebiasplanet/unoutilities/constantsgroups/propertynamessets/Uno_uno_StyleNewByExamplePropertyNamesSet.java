package thebiasplanet.unoutilities.constantsgroups.propertynamessets;

public interface Uno_uno_StyleNewByExamplePropertyNamesSet extends UnoPropertyNamesSet {
	String c_styleName_String = "Param";
	String c_styleFamilyKey_Short = "Family";
}
