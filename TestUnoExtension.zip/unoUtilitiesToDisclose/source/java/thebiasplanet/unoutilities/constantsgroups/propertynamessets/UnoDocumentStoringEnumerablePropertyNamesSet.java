package thebiasplanet.unoutilities.constantsgroups.propertynamessets;

import thebiasplanet.coreutilities.constantsgroups.BaseEnumerableConstantsGroup;

public class UnoDocumentStoringEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements UnoDocumentStoringPropertyNamesSet {
	public static final UnoDocumentStoringEnumerablePropertyNamesSet c_instance = new UnoDocumentStoringEnumerablePropertyNamesSet ();
	
	private UnoDocumentStoringEnumerablePropertyNamesSet () {
	}
}
