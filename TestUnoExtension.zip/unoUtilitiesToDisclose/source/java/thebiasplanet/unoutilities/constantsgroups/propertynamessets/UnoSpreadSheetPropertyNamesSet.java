package thebiasplanet.unoutilities.constantsgroups.propertynamessets;

public interface UnoSpreadSheetPropertyNamesSet extends UnoPropertyNamesSet {
	String c_pageStyle = "PageStyle";
}
