package thebiasplanet.unoutilities.constantsgroups.propertynamessets;

public interface UnoDocumentOpeningPropertyNamesSet extends UnoPropertyNamesSet {
	String c_readOnly_Boolean = "ReadOnly";
	String c_hidden_Boolean = "Hidden";
}
