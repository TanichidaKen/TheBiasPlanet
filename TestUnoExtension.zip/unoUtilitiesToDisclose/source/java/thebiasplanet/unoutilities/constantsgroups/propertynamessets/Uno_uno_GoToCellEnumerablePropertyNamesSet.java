package thebiasplanet.unoutilities.constantsgroups.propertynamessets;

import thebiasplanet.coreutilities.constantsgroups.BaseEnumerableConstantsGroup;

public class Uno_uno_GoToCellEnumerablePropertyNamesSet extends BaseEnumerableConstantsGroup <String> implements Uno_uno_GoToCellPropertyNamesSet {
	public static final Uno_uno_GoToCellEnumerablePropertyNamesSet c_instance = new Uno_uno_GoToCellEnumerablePropertyNamesSet ();
	
	private Uno_uno_GoToCellEnumerablePropertyNamesSet () {
	}
}
