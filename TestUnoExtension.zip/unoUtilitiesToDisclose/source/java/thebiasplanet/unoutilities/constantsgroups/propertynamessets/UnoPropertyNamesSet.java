package thebiasplanet.unoutilities.constantsgroups.propertynamessets;

public interface UnoPropertyNamesSet {
}
