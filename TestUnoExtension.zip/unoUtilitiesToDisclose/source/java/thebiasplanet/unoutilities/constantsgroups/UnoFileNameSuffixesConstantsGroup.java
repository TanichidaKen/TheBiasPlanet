package thebiasplanet.unoutilities.constantsgroups;

public interface UnoFileNameSuffixesConstantsGroup {
	String c_unoComponentsSettingFileNameSuffix = "components";
	String c_unoIdlFileNameSuffix = "idl";
	String c_unoDataTypesMergedRegistryFileNameSuffix = "rdb";
}
