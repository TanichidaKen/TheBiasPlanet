package thebiasplanet.unoutilities.constantsgroups;

public interface UnoServiceNamesConstantsGroup {
	String c_com_sun_star_frame_Desktop = "com.sun.star.frame.Desktop";
	String c_com_sun_star_frame_DispatchHelper = "com.sun.star.frame.DispatchHelper";
	String c_com_sun_star_xml_crypto_SecurityEnvironment = "com.sun.star.xml.crypto.SecurityEnvironment";
	String c_com_sun_star_bridge_BridgeFactory = "com.sun.star.bridge.BridgeFactory";
	String c_com_sun_star_connection_Connector = "com.sun.star.connection.Connector";
	String c_com_sun_star_connection_Acceptor = "com.sun.star.connection.Acceptor";
}
