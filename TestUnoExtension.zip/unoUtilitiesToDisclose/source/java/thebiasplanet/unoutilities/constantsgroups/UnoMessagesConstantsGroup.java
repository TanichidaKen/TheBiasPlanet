package thebiasplanet.unoutilities.constantsgroups;

public interface UnoMessagesConstantsGroup {
	String c_remoteInstanceNotProvided = "The server didn't provide the remote instance.";
	String c_cellNotString = "The cell isn't a string value cell.";
	String c_unoDocumentNotSpecified = "The UNO document isn't specified.";
	String c_isNotSpreadSheetsDocument = "The specified UNO component is not a spread sheets document.";
	String c_isNotTextDocument = "The specified UNO component is not a text document.";
	String c_spreadSheetsDocumentNotSpecified = "The spread sheets document isn't specified.";
	String c_spreadSheetNotSpecified = "The spread sheet isn't specified.";
	String c_componentContextNotCreated = "Couldn't create the component context.";
	String c_componentContextNotSpecified = "The component context isn't specified.";
}
