package thebiasplanet.unoutilities.constantsgroups;

import thebiasplanet.coreutilities.constantsgroups.BaseEnumerableConstantsGroup;
import thebiasplanet.unoutilities.constantsgroups.propertynamessets.*;

// Interface because this is not enumerable
public interface UnoDispatchSlotsConstantsGroup {
	BaseDispatchSlot c__uno_StyleNewByExample = new BaseDispatchSlot (".uno:StyleNewByExample", Uno_uno_StyleNewByExampleEnumerablePropertyNamesSet.c_instance);
	BaseDispatchSlot c__uno_GoToCell = new BaseDispatchSlot (".uno:GoToCell", Uno_uno_GoToCellEnumerablePropertyNamesSet.c_instance);
	
	// Base class for all the constants in this group
	static class BaseDispatchSlot {
		public final String c_url;
		public final BaseEnumerableConstantsGroup <String> c_argumentPropertyNamesSet;
		
		BaseDispatchSlot (String a_url, BaseEnumerableConstantsGroup <String> a_argumentPropertyNamesSet) {
			c_url = a_url;
			c_argumentPropertyNamesSet = a_argumentPropertyNamesSet;
		}
	}
}
