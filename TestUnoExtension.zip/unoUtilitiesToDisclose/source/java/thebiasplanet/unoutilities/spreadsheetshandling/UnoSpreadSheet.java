package thebiasplanet.unoutilities.spreadsheetshandling;

import com.sun.star.lang.WrappedTargetException;
import com.sun.star.uno.XComponentContext;
import com.sun.star.uno.UnoRuntime;
import com.sun.star.sheet.XSpreadsheet;
import com.sun.star.sheet.XCellRangeMovement;
import com.sun.star.sheet.CellInsertMode;
import com.sun.star.sheet.CellDeleteMode;
import com.sun.star.container.XNamed;
import com.sun.star.container.XIndexAccess;
import com.sun.star.table.CellRangeAddress;
import com.sun.star.table.XCellRange;
import com.sun.star.beans.XPropertySet;
import com.sun.star.beans.UnknownPropertyException;
import thebiasplanet.coreutilities.constantsgroups.*;
import thebiasplanet.unoutilities.constantsgroups.*;
import thebiasplanet.unoutilities.constantsgroups.propertynamessets.*;

public class UnoSpreadSheet {
	private UnoSpreadSheetsDocument i_spreadSheetsDocument;
	private XSpreadsheet i_spreadSheetInXSpreadsheet;
	private XNamed i_spreadSheetInXNamed;
	private XCellRangeMovement i_spreadSheetInXCellRangeMovement;
	private XPropertySet i_spreadSheetInXPropertySet;
	
	public UnoSpreadSheet (UnoSpreadSheetsDocument a_spreadSheetsDocument, XSpreadsheet a_spreadSheetInXSpreadsheet) throws Exception {
		if (a_spreadSheetsDocument == null) {
			throw new Exception (UnoMessagesConstantsGroup.c_spreadSheetsDocumentNotSpecified);
		}
		i_spreadSheetsDocument = a_spreadSheetsDocument;
		if (a_spreadSheetInXSpreadsheet == null) {
			throw new Exception (UnoMessagesConstantsGroup.c_spreadSheetNotSpecified);
		}
		i_spreadSheetInXSpreadsheet = a_spreadSheetInXSpreadsheet;
		i_spreadSheetInXNamed = (XNamed) UnoRuntime.queryInterface (XNamed.class, i_spreadSheetInXSpreadsheet);
		i_spreadSheetInXCellRangeMovement = (XCellRangeMovement) UnoRuntime.queryInterface (XCellRangeMovement.class, i_spreadSheetInXSpreadsheet);
		i_spreadSheetInXPropertySet = (XPropertySet) UnoRuntime.queryInterface (XPropertySet.class, i_spreadSheetInXSpreadsheet);
	}
	
	public static UnoSpreadSheet getCurrentSpreadSheet (XComponentContext a_componentContextInXComponentContext) throws Exception {
		UnoSpreadSheetsDocument l_currentSpreadSheetsDocument = UnoSpreadSheetsDocument.getCurrentSpreadSheetsDocument (a_componentContextInXComponentContext);
		return new UnoSpreadSheet (l_currentSpreadSheetsDocument, l_currentSpreadSheetsDocument.getControllerInXSpreadsheetView ().getActiveSheet ());
	}
	
	public UnoSpreadSheetsDocument getSpreadSheetsDocument () {
		return i_spreadSheetsDocument;
	}
	
	public XSpreadsheet getSpreadSheetInXSpreadsheet () {
		return i_spreadSheetInXSpreadsheet;
	}
	
	public XPropertySet getSpreadSheetInXPropertySet () {
		return i_spreadSheetInXPropertySet;
	}
	
	public String getPageStyleName () throws UnknownPropertyException, WrappedTargetException {
		return (String) i_spreadSheetInXPropertySet.getPropertyValue (UnoSpreadSheetPropertyNamesSet.c_pageStyle);
	}
	
	public UnoSpreadSheetCell getSpreadSheetCell (int a_cellRowIndex, int a_cellColumnIndex) throws com.sun.star.lang.IndexOutOfBoundsException {
		return new UnoSpreadSheetCell (this, i_spreadSheetInXSpreadsheet.getCellByPosition (a_cellColumnIndex, a_cellRowIndex));
	}
	
	public XCellRange getSpreadSheetCellsRangeInXCellRange (int a_cellTopRowIndex, int a_cellLeftColumnIndex, int a_cellBottomRowIndex, int a_cellRightColumnIndex) throws com.sun.star.lang.IndexOutOfBoundsException {
		return i_spreadSheetInXSpreadsheet.getCellRangeByPosition (a_cellLeftColumnIndex, a_cellTopRowIndex, a_cellRightColumnIndex, a_cellBottomRowIndex);
	}
	
	public String getSpreadSheetName () {
		return i_spreadSheetInXNamed.getName ();
	}
	
	public int getSpreadSheetIndex () throws com.sun.star.lang.IndexOutOfBoundsException, WrappedTargetException {
		XIndexAccess l_spreadSheetsInXIndexAccess = UnoRuntime.queryInterface (XIndexAccess.class, i_spreadSheetsDocument.getSpreadSheetsInXSpreadsheets ());
		int l_spreadSheetsCount = l_spreadSheetsInXIndexAccess.getCount ();
		String l_spreadSheetName = getSpreadSheetName ();
		XNamed l_spreadSheetInXNamed = null;
		int l_spreadSheetIndex = GeneralConstantsConstantsGroup.c_iterationStartingNumber;
		for (; l_spreadSheetIndex < l_spreadSheetsCount; l_spreadSheetIndex ++) {
			l_spreadSheetInXNamed = UnoRuntime.queryInterface (XNamed.class, l_spreadSheetsInXIndexAccess.getByIndex (l_spreadSheetIndex));
			if (l_spreadSheetName.equals (l_spreadSheetInXNamed.getName ())) {
				break;
			}
		}
		if (l_spreadSheetIndex < l_spreadSheetsCount) {
			return l_spreadSheetIndex;
		}
		else {
			return GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger;
		}
	}
	
	public void insertRows (int a_startRowIndex, int a_endRowIndex) throws com.sun.star.lang.IndexOutOfBoundsException, WrappedTargetException {
		CellRangeAddress l_cellsRangeAddress = new CellRangeAddress ();
		l_cellsRangeAddress.Sheet = (short) getSpreadSheetIndex ();
		l_cellsRangeAddress.StartRow = a_startRowIndex;
		l_cellsRangeAddress.EndRow = a_endRowIndex;
		i_spreadSheetInXCellRangeMovement.insertCells (l_cellsRangeAddress, CellInsertMode.ROWS);
	}
	
	public void insertColumns (int a_startColumnIndex, int a_endColumnIndex) throws com.sun.star.lang.IndexOutOfBoundsException, WrappedTargetException {
		CellRangeAddress l_cellsRangeAddress = new CellRangeAddress ();
		l_cellsRangeAddress.Sheet = (short) getSpreadSheetIndex ();
		l_cellsRangeAddress.StartColumn = a_startColumnIndex;
		l_cellsRangeAddress.EndColumn = a_endColumnIndex;
		i_spreadSheetInXCellRangeMovement.insertCells (l_cellsRangeAddress, CellInsertMode.COLUMNS);
	}
	
	public void removeRows (int a_startRowIndex, int a_endRowIndex) throws com.sun.star.lang.IndexOutOfBoundsException, WrappedTargetException {
		CellRangeAddress l_cellsRangeAddress = new CellRangeAddress ();
		l_cellsRangeAddress.Sheet = (short) getSpreadSheetIndex ();
		l_cellsRangeAddress.StartRow = a_startRowIndex;
		l_cellsRangeAddress.EndRow = a_endRowIndex;
		i_spreadSheetInXCellRangeMovement.removeRange (l_cellsRangeAddress, CellDeleteMode.ROWS);
	}
	
	public void removeColumns (int a_startColumnIndex, int a_endColumnIndex) throws com.sun.star.lang.IndexOutOfBoundsException, WrappedTargetException {
		CellRangeAddress l_cellsRangeAddress = new CellRangeAddress ();
		l_cellsRangeAddress.Sheet = (short) getSpreadSheetIndex ();
		l_cellsRangeAddress.StartColumn = a_startColumnIndex;
		l_cellsRangeAddress.EndColumn = a_endColumnIndex;
		i_spreadSheetInXCellRangeMovement.removeRange (l_cellsRangeAddress, CellDeleteMode.COLUMNS);
	}
}

