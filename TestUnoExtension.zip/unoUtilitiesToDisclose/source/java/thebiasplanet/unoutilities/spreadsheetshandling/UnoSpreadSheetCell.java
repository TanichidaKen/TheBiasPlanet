package thebiasplanet.unoutilities.spreadsheetshandling;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.math.BigDecimal;
import com.sun.star.uno.XComponentContext;
import com.sun.star.uno.UnoRuntime;
import com.sun.star.lang.WrappedTargetException;
import com.sun.star.awt.FontSlant;
import com.sun.star.awt.FontUnderline;
import com.sun.star.awt.FontStrikeout;
import com.sun.star.table.XCell;
import com.sun.star.table.CellContentType;
import com.sun.star.table.CellAddress;
import com.sun.star.table.XCellRange;
import com.sun.star.table.BorderLine2;
import com.sun.star.table.BorderLineStyle;
import com.sun.star.table.CellHoriJustify;
import com.sun.star.text.XText;
import com.sun.star.text.XTextCursor;
import com.sun.star.beans.XPropertySet;
import com.sun.star.beans.UnknownPropertyException;
import com.sun.star.beans.PropertyVetoException;
import com.sun.star.sheet.XCellAddressable;
import com.sun.star.util.MalformedNumberFormatException;
import thebiasplanet.coreutilities.collectionshandling.ListFactory;
import thebiasplanet.coreutilities.constantsgroups.*;
import thebiasplanet.unoutilities.constantsgroups.*;
import thebiasplanet.unoutilities.constantsgroups.propertynamessets.*;

public class UnoSpreadSheetCell {
	private UnoSpreadSheet i_spreadSheet;
	private XCell i_spreadSheetCellInXCell;
	private XCellAddressable i_spreadSheetCellInXCellAddressable;
	private XPropertySet i_spreadSheetCellInXPropertySet;
	private XText i_spreadSheetCellInXText;
	
	public UnoSpreadSheetCell (UnoSpreadSheet a_spreadSheet, XCell a_spreadSheetCellInXCell) {
		i_spreadSheet = a_spreadSheet;
		i_spreadSheetCellInXCell = a_spreadSheetCellInXCell;
		i_spreadSheetCellInXCellAddressable = (XCellAddressable) UnoRuntime.queryInterface (XCellAddressable.class, i_spreadSheetCellInXCell);
		i_spreadSheetCellInXPropertySet = (XPropertySet) UnoRuntime.queryInterface (XPropertySet.class, i_spreadSheetCellInXCell);
		i_spreadSheetCellInXText = (XText) UnoRuntime.queryInterface (XText.class, a_spreadSheetCellInXCell);
	}
	
	public static UnoSpreadSheetCell getCurrentCell (XComponentContext a_componentContextInXComponentContext) throws Exception {
		UnoSpreadSheet l_currentSpreadSheat = UnoSpreadSheet.getCurrentSpreadSheet (a_componentContextInXComponentContext);
		XCellRange l_currentCellsInXCellRange = (XCellRange) UnoRuntime.queryInterface (XCellRange.class, l_currentSpreadSheat.getSpreadSheetsDocument ().getSpreadSheetsDocumentinXModel ().getCurrentSelection ());
		if (l_currentCellsInXCellRange != null) {
			return new UnoSpreadSheetCell (l_currentSpreadSheat, l_currentCellsInXCellRange.getCellByPosition (GeneralConstantsConstantsGroup.c_iterationStartingNumber, GeneralConstantsConstantsGroup.c_iterationStartingNumber));
			
		}
		else {
			return null;
		}
	}
	
	public static String getCellPositionExpression (int a_rowIndex, int a_columnIndex) {
		int l_unprocessedColumnAlpabetsCycleIndex = GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger;
		int l_unprocessedColumnAlpabetsCycleIndexSaved = GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger;
		StringBuffer l_columnPositionExpresionInReverse = new StringBuffer ();
		l_unprocessedColumnAlpabetsCycleIndexSaved = a_columnIndex;
		while (true) {
			l_unprocessedColumnAlpabetsCycleIndex = l_unprocessedColumnAlpabetsCycleIndexSaved / GeneralConstantsConstantsGroup.c_numberOfAlphabets;
			int l_columnInsideAlpabetsCycleIndex = l_unprocessedColumnAlpabetsCycleIndexSaved - l_unprocessedColumnAlpabetsCycleIndex * GeneralConstantsConstantsGroup.c_numberOfAlphabets;
			String l_alphabet = null;
			switch (l_columnInsideAlpabetsCycleIndex) {
				case 0:
					l_alphabet = "A";
					break;
				case 1:
					l_alphabet = "B";
					break;
				case 2:
					l_alphabet = "C";
					break;
				case 3:
					l_alphabet = "D";
					break;
				case 4:
					l_alphabet = "E";
					break;
				case 5:
					l_alphabet = "F";
					break;
				case 6:
					l_alphabet = "G";
					break;
				case 7:
					l_alphabet = "H";
					break;
				case 8:
					l_alphabet = "I";
					break;
				case 9:
					l_alphabet = "J";
					break;
				case 10:
					l_alphabet = "K";
					break;
				case 11:
					l_alphabet = "L";
					break;
				case 12:
					l_alphabet = "M";
					break;
				case 13:
					l_alphabet = "N";
					break;
				case 14:
					l_alphabet = "O";
					break;
				case 15:
					l_alphabet = "P";
					break;
				case 16:
					l_alphabet = "Q";
					break;
				case 17:
					l_alphabet = "R";
					break;
				case 18:
					l_alphabet = "S";
					break;
				case 19:
					l_alphabet = "T";
					break;
				case 20:
					l_alphabet = "U";
					break;
				case 21:
					l_alphabet = "V";
					break;
				case 22:
					l_alphabet = "W";
					break;
				case 23:
					l_alphabet = "X";
					break;
				case 24:
					l_alphabet = "Y";
					break;
				case 25:
					l_alphabet = "Z";
					break;
				default:
					// impossible
					break;
			}
			l_columnPositionExpresionInReverse.append (l_alphabet);
			if (l_unprocessedColumnAlpabetsCycleIndex == GeneralConstantsConstantsGroup.c_iterationStartingNumber) {
				break;
			}
			l_unprocessedColumnAlpabetsCycleIndexSaved = l_unprocessedColumnAlpabetsCycleIndex;
		}
		l_columnPositionExpresionInReverse.reverse ();
		return String.format (UnoGeneralConstantsConstantsGroup.c_cellSpecificationExpressionTemplate, l_columnPositionExpresionInReverse.toString (), a_rowIndex + 1);
	}
	
	public UnoSpreadSheet getSpreadSheet () {
		return i_spreadSheet;
	}
	
	public XCell getSpreadSheetCellInXCell () {
		return i_spreadSheetCellInXCell;
	}
	
	public Object getValue () throws UnknownPropertyException, WrappedTargetException, IOException {
		CellContentType l_cellContentType = i_spreadSheetCellInXCell.getType ();
		if (l_cellContentType == CellContentType.EMPTY) {
			return null;
		}
		// l_cellContentType can be CellContentType.VALUE, CellContentType.TEXT, or CellContentType.FORMULA
		int l_cellValueExpressionFormatKey = ((Integer) i_spreadSheetCellInXPropertySet.getPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_numberFormat)).intValue ();
		String l_cellValueExpression = i_spreadSheetCellInXText.getString ();
		if (l_cellValueExpressionFormatKey == i_spreadSheet.getSpreadSheetsDocument ().getDateExpressionFormatKey ()) {
			LocalDate l_date = LocalDate.parse (l_cellValueExpression, DateTimeFormatter.ISO_LOCAL_DATE);
			return l_date;
		}
		else if (l_cellValueExpressionFormatKey == i_spreadSheet.getSpreadSheetsDocument ().getTimeExpressionFormatKey ()) {
			LocalTime l_time = LocalTime.parse (l_cellValueExpression, DateTimeFormatter.ISO_LOCAL_TIME);
			return l_time;
		}
		else if (l_cellValueExpressionFormatKey == i_spreadSheet.getSpreadSheetsDocument ().getDateTimeExpressionFormatKey ()) {
			LocalDateTime l_dateTime = LocalDateTime.parse (l_cellValueExpression, DateTimeFormatter.ISO_LOCAL_DATE_TIME);
			return l_dateTime;
		}
		else if (l_cellValueExpressionFormatKey == i_spreadSheet.getSpreadSheetsDocument ().getBooleanExpressionFormatKey ()) {
			Boolean l_boolean = Boolean.valueOf (l_cellValueExpression);
			return l_boolean;
		}
		else if (l_cellValueExpressionFormatKey == i_spreadSheet.getSpreadSheetsDocument ().getStringExpressionFormatKey ()) {
			{
				return l_cellValueExpression;
			}
		}
		else if (l_cellValueExpressionFormatKey == i_spreadSheet.getSpreadSheetsDocument ().getIntegerExpressionFormatKey ()) {
			Integer l_integer = Integer.valueOf (l_cellValueExpression.replaceAll (String.valueOf (GeneralConstantsConstantsGroup.c_thousandSeparator), ""));
			return l_integer;
		}
		else {
			Matcher l_matcher = RegularExpressionsConstantsGroup.c_numbersRegularExpression.matcher (l_cellValueExpression);
			if (l_matcher.find ()) {
				BigDecimal l_bigDecimal = new BigDecimal (l_cellValueExpression.replaceAll (String.valueOf (GeneralConstantsConstantsGroup.c_thousandSeparator), ""));
				return l_bigDecimal;
				/*
				Double l_double = Double.valueOf (l_cellValueExpression.replaceAll (String.valueOf (GeneralConstantsConstantsGroup.c_thousandSeparator), ""));
				return l_double;
				*/
			}
			else {
				return l_cellValueExpression;
			}
		}
	 }
	
	public Object getFormulaOrValue () throws UnknownPropertyException, WrappedTargetException, IOException {
		CellContentType l_cellContentType = i_spreadSheetCellInXCell.getType ();
		// l_cellContentType can be CellContentType.VALUE, CellContentType.TEXT, or CellContentType.FORMULA
		if (l_cellContentType == CellContentType.FORMULA) {
			return new UnoSpreadSheetFormula (i_spreadSheetCellInXCell.getFormula (), ((Integer) i_spreadSheetCellInXPropertySet.getPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_numberFormat)).intValue ());
		}
		else {
			return getValue ();
		}
	}
	
	public int getNumberOfDecimalPlaces () throws UnknownPropertyException, WrappedTargetException {
		CellContentType l_cellContentType = i_spreadSheetCellInXCell.getType ();
		if (l_cellContentType == CellContentType.EMPTY) {
			return GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger;
		}
		int l_cellValueExpressionFormatKey = ((Integer) i_spreadSheetCellInXPropertySet.getPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_numberFormat)).intValue ();
		return i_spreadSheet.getSpreadSheetsDocument ().getNumberOfDecimalPlaces (l_cellValueExpressionFormatKey);
	}
	
	public void setValue (Object a_value) throws UnknownPropertyException, PropertyVetoException, MalformedNumberFormatException, WrappedTargetException {
		if (a_value instanceof Date) {
			a_value = ((Date) a_value).toLocalDate ();
		}
		if (a_value instanceof Time) {
			a_value = ((Time) a_value).toLocalTime ();
		}
		if (a_value instanceof Timestamp) {
			a_value = ((Timestamp) a_value).toLocalDateTime ();
		}
		if (a_value == null || a_value instanceof String) {
			String l_string = UnoGeneralConstantsConstantsGroup.c_anyUnspecifiedString;
			if (a_value != null) {
				l_string = (String) a_value;
			}
			i_spreadSheetCellInXPropertySet.setPropertyValue(UnoSpreadSheetCellPropertyNamesSet.c_numberFormat, new Integer (i_spreadSheet.getSpreadSheetsDocument ().getStringExpressionFormatKey ()));
			i_spreadSheetCellInXCell.setFormula (UnoGeneralConstantsConstantsGroup.c_anyUnspecifiedString);
			XTextCursor l_textCursor = i_spreadSheetCellInXText.createTextCursor();
			i_spreadSheetCellInXText.insertString( l_textCursor, l_string, true);
		}
		else if (a_value instanceof Integer) {
			Integer l_integer = (Integer) a_value;
			i_spreadSheetCellInXPropertySet.setPropertyValue(UnoSpreadSheetCellPropertyNamesSet.c_numberFormat, new Integer (i_spreadSheet.getSpreadSheetsDocument ().getIntegerExpressionFormatKey ()));
			i_spreadSheetCellInXCell.setValue (l_integer.intValue ());
		}
		else if (a_value instanceof BigDecimal) {
			BigDecimal l_bigDeciaml = (BigDecimal) a_value;
			int l_scale = l_bigDeciaml.scale ();
			if (l_scale > 0) {
				i_spreadSheetCellInXPropertySet.setPropertyValue(UnoSpreadSheetCellPropertyNamesSet.c_numberFormat, new Integer (i_spreadSheet.getSpreadSheetsDocument ().getDoubleExpressionFormatKey (l_scale)));
				i_spreadSheetCellInXCell.setValue (l_bigDeciaml.doubleValue ());
			}
			else {
				i_spreadSheetCellInXPropertySet.setPropertyValue(UnoSpreadSheetCellPropertyNamesSet.c_numberFormat, new Integer (i_spreadSheet.getSpreadSheetsDocument ().getIntegerExpressionFormatKey ()));
				i_spreadSheetCellInXCell.setValue (l_bigDeciaml.intValue ());
			}
		}
		else if (a_value instanceof Double) {
			Double l_double = (Double) a_value;
			i_spreadSheetCellInXPropertySet.setPropertyValue(UnoSpreadSheetCellPropertyNamesSet.c_numberFormat, new Integer (i_spreadSheet.getSpreadSheetsDocument ().getDoubleExpressionFormatKey (GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger)));
			i_spreadSheetCellInXCell.setValue (l_double.doubleValue ());
		}
		else if (a_value instanceof Boolean) {
			Boolean l_boolean = (Boolean) a_value;
			i_spreadSheetCellInXPropertySet.setPropertyValue(UnoSpreadSheetCellPropertyNamesSet.c_numberFormat, new Integer (i_spreadSheet.getSpreadSheetsDocument ().getBooleanExpressionFormatKey ()));
			i_spreadSheetCellInXCell.setFormula (l_boolean.toString ());
		}
		else if (a_value instanceof LocalDate) {
			LocalDate l_date = (LocalDate) a_value;
			String l_dateString = l_date.format (DateTimeFormatter.ISO_LOCAL_DATE);
			i_spreadSheetCellInXPropertySet.setPropertyValue(UnoSpreadSheetCellPropertyNamesSet.c_numberFormat, new Integer (i_spreadSheet.getSpreadSheetsDocument ().getDateExpressionFormatKey ()));
			i_spreadSheetCellInXCell.setFormula (l_dateString);
		}
		else if (a_value instanceof LocalTime) {
			LocalTime l_time = (LocalTime) a_value;
			String l_timeString = l_time.format (DateTimeFormatter.ISO_LOCAL_TIME);
			i_spreadSheetCellInXPropertySet.setPropertyValue(UnoSpreadSheetCellPropertyNamesSet.c_numberFormat, new Integer (i_spreadSheet.getSpreadSheetsDocument ().getTimeExpressionFormatKey ()));
			i_spreadSheetCellInXCell.setFormula (l_timeString);
		}
		else if (a_value instanceof LocalDateTime) {
			LocalDateTime l_dateTime = (LocalDateTime) a_value;
			String l_dateTimeString = l_dateTime.format (DateTimeFormatter.ISO_LOCAL_DATE_TIME);
			i_spreadSheetCellInXPropertySet.setPropertyValue(UnoSpreadSheetCellPropertyNamesSet.c_numberFormat, new Integer (i_spreadSheet.getSpreadSheetsDocument ().getDateTimeExpressionFormatKey ()));
			i_spreadSheetCellInXCell.setFormula (l_dateTimeString);
		}
		else if (a_value instanceof UnoSpreadSheetFormula) {
			UnoSpreadSheetFormula l_formula = (UnoSpreadSheetFormula) a_value;
			if (l_formula.getCellValueExpressionFormatKey () != GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger) {
				i_spreadSheetCellInXPropertySet.setPropertyValue(UnoSpreadSheetCellPropertyNamesSet.c_numberFormat, new Integer (l_formula.getCellValueExpressionFormatKey ()));
			}
			i_spreadSheetCellInXCell.setFormula (l_formula.getFormulaString ());
		}
		else {
			String l_string = a_value.toString ();
			i_spreadSheetCellInXPropertySet.setPropertyValue(UnoSpreadSheetCellPropertyNamesSet.c_numberFormat, new Integer (i_spreadSheet.getSpreadSheetsDocument ().getStringExpressionFormatKey ()));
			i_spreadSheetCellInXCell.setFormula (UnoGeneralConstantsConstantsGroup.c_anyUnspecifiedString);
			XTextCursor l_textCursorInXTextCursor = i_spreadSheetCellInXText.createTextCursor();
			i_spreadSheetCellInXText.insertString( l_textCursorInXTextCursor, l_string, true);
		}
	}
	
	public void setValue (Double a_value, int a_numberOfDecimalPlaces) throws UnknownPropertyException, PropertyVetoException, MalformedNumberFormatException, WrappedTargetException {
		i_spreadSheetCellInXPropertySet.setPropertyValue(UnoSpreadSheetCellPropertyNamesSet.c_numberFormat, new Integer (i_spreadSheet.getSpreadSheetsDocument ().getDoubleExpressionFormatKey (a_numberOfDecimalPlaces)));
		i_spreadSheetCellInXCell.setValue (a_value.doubleValue ());
	}
	
	 public void insertString (String a_string, int a_characterIndex) throws Exception {
		CellContentType l_cellContentType = i_spreadSheetCellInXCell.getType ();
		// l_cellContentType can be CellContentType.VALUE, CellContentType.TEXT, or CellContentType.FORMULA
		if (l_cellContentType == CellContentType.TEXT) {
			XTextCursor l_textCursorInXTextCursor = i_spreadSheetCellInXText.createTextCursorByRange (i_spreadSheetCellInXText.getStart ());
			l_textCursorInXTextCursor.goRight ( (short) a_characterIndex, false);
			i_spreadSheetCellInXText.insertString (l_textCursorInXTextCursor, a_string, false);
			return;
		}
		else {
			throw new Exception (UnoMessagesConstantsGroup.c_cellNotString);
		}
	}
	
	 public void replaceString (String a_string, int a_startCharacterIndex, int a_endCharacterIndex) throws Exception {
		CellContentType l_cellContentType = i_spreadSheetCellInXCell.getType ();
		// l_cellContentType can be CellContentType.VALUE, CellContentType.TEXT, or CellContentType.FORMULA
		if (l_cellContentType == CellContentType.TEXT) {
			XTextCursor l_textCursorInXTextCursor = i_spreadSheetCellInXText.createTextCursorByRange (i_spreadSheetCellInXText.getStart ());
			l_textCursorInXTextCursor.goRight ( (short) a_startCharacterIndex, false);
			l_textCursorInXTextCursor.goRight ( (short) (a_endCharacterIndex + 1 - a_startCharacterIndex), true);
			i_spreadSheetCellInXText.insertString (l_textCursorInXTextCursor, a_string, true);
			return;
		}
		else {
			throw new Exception (UnoMessagesConstantsGroup.c_cellNotString);
		}
	}
	
	public int getRowIndex () {
		CellAddress l_cellAdress = i_spreadSheetCellInXCellAddressable.getCellAddress ();
		return l_cellAdress.Row;
	}
	
	public int getColumnIndex () {
		CellAddress l_cellAdress = i_spreadSheetCellInXCellAddressable.getCellAddress ();
		return l_cellAdress.Column;
	}
	
	public UnoSpreadSheetCell getUpperCell () throws com.sun.star.lang.IndexOutOfBoundsException {
		return i_spreadSheet.getSpreadSheetCell (getRowIndex () - 1, getColumnIndex ());
	}
	
	public UnoSpreadSheetCell getDownCell () throws com.sun.star.lang.IndexOutOfBoundsException {
		return i_spreadSheet.getSpreadSheetCell (getRowIndex () + 1, getColumnIndex ());
	}
	
	public UnoSpreadSheetCell getLeftCell () throws com.sun.star.lang.IndexOutOfBoundsException {
		return i_spreadSheet.getSpreadSheetCell (getRowIndex (), getColumnIndex () - 1);
	}
	
	public UnoSpreadSheetCell getRightCell () throws com.sun.star.lang.IndexOutOfBoundsException {
		return i_spreadSheet.getSpreadSheetCell (getRowIndex (), getColumnIndex () + 1);
	}
	
	public void setAsCurrentCell () {
		ArrayList <Object> l_dispatchPropertyValues = ListFactory. <Object>createArrayList (getCellPositionExpression (getRowIndex (), getColumnIndex ()));
		i_spreadSheet.getSpreadSheetsDocument ().dispatch (UnoDispatchSlotsConstantsGroup.c__uno_GoToCell, l_dispatchPropertyValues);
	}
	
	public void setFocus () {
		i_spreadSheet.getSpreadSheetsDocument ().setSelection (i_spreadSheetCellInXCell);
	}
	
	public int getBackgroundColor () throws UnknownPropertyException, WrappedTargetException {
		return ((Integer) i_spreadSheetCellInXPropertySet.getPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_backgroundColor)).intValue ();
	}
	
	public void setBackgroundColor (int a_pixelValue) throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		i_spreadSheetCellInXPropertySet.setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_backgroundColor, new Integer (a_pixelValue));
		i_spreadSheetCellInXPropertySet.setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_backgroundIsTransparent, new Boolean (false));
	}
	
	public void removeBackgroundColor () throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		i_spreadSheetCellInXPropertySet.setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_backgroundColor, new Integer (-1));
		i_spreadSheetCellInXPropertySet.setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_backgroundIsTransparent, new Boolean (true));
	}
	
	public int getForegroundColor () throws UnknownPropertyException, WrappedTargetException {
		return ((Integer) i_spreadSheetCellInXPropertySet.getPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_foregroundColor)).intValue ();
	}
	
	public void setForegroundColor (int a_pixelValue) throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		i_spreadSheetCellInXPropertySet.setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_foregroundColor, new Integer (a_pixelValue));
	}
	
	public void setForegroundColorAutomatic () throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		i_spreadSheetCellInXPropertySet.setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_foregroundColor, new Integer (-1));
	}
	
	public String getFontName () throws UnknownPropertyException, WrappedTargetException {
		return (String) i_spreadSheetCellInXPropertySet.getPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_fontName);
	}
	
	public void setFontName (String a_name) throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		i_spreadSheetCellInXPropertySet.setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_fontName, a_name);
	}
	
	public float getFontSize () throws UnknownPropertyException, WrappedTargetException {
		return ((Float) i_spreadSheetCellInXPropertySet.getPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_fontSize)).floatValue ();
	}
	
	public void setFontSize (float a_size) throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		i_spreadSheetCellInXPropertySet.setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_fontSize, new Float (a_size));
	}
	
	// com.sun.star.awt.FontSlant.(NONE, OBLIQUE, ITALIC, DONTKNOW, REVERSE_OBLIQUE, or REVERSE_ITALIC)
	public FontSlant getFontPosture () throws UnknownPropertyException, WrappedTargetException {
		return (FontSlant) i_spreadSheetCellInXPropertySet.getPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_fontPosture);
	}
	
	// com.sun.star.awt.FontSlant.(NONE, OBLIQUE, ITALIC, DONTKNOW, REVERSE_OBLIQUE, or REVERSE_ITALIC)
	public void setFontPosture (FontSlant a_style) throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		i_spreadSheetCellInXPropertySet.setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_fontPosture, a_style);
	}
	
	// com.sun.star.awt.FontWeight.(DONTKNOW, THIN, ULTRALIGHT, LIGHT, SEMILIGHT, NORMAL, SEMIBOLD, BOLD, ULTRABOLD, or BLACK)
	public float getFontWeight () throws UnknownPropertyException, WrappedTargetException {
		return ((Float) i_spreadSheetCellInXPropertySet.getPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_fontWeight)).floatValue ();
	}
	
	// com.sun.star.awt.FontWeight.(DONTKNOW, THIN, ULTRALIGHT, LIGHT, SEMILIGHT, NORMAL, SEMIBOLD, BOLD, ULTRABOLD, or BLACK)
	public void setFontWeight (float a_weight) throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		i_spreadSheetCellInXPropertySet.setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_fontWeight, new Float (a_weight));
	}
	
	// com.sun.star.awt.FontUnderline.(NONE, SINGLE, DOUBLE, DOTTED, DONTKNOW, DASH, LONGDASH, DASHDOT, DASHDOTDOT, SMALLWAVE, WAVE, DOUBLEWAVE, BOLD, BOLDDOTTED, BOLDDASH, BOLDLONGDASH, BOLDDASHDOT, BOLDDASHDOTDOT, BOLDWAVE)
	public short getUnderLineStyle () throws UnknownPropertyException, WrappedTargetException {
		return ((Short) i_spreadSheetCellInXPropertySet.getPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_underLineStyle)).shortValue ();
	}
	
	public int getUnderLineColor () throws UnknownPropertyException, WrappedTargetException {
		return ((Integer) i_spreadSheetCellInXPropertySet.getPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_underLineColor)).intValue ();
	}
	
	// For a_style, com.sun.star.awt.FontUnderline.(NONE, SINGLE, DOUBLE, DOTTED, DONTKNOW, DASH, LONGDASH, DASHDOT, DASHDOTDOT, SMALLWAVE, WAVE, DOUBLEWAVE, BOLD, BOLDDOTTED, BOLDDASH, BOLDLONGDASH, BOLDDASHDOT, BOLDDASHDOTDOT, BOLDWAVE)
	public void setUnderLine (short a_style, int a_pixelValue) throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		i_spreadSheetCellInXPropertySet.setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_underLineStyle, new Short (a_style));
		i_spreadSheetCellInXPropertySet.setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_underLineHasColor, a_pixelValue != UnoPixelValuesConstantsGroup.c_notSpecified ? Boolean.valueOf (true): new Boolean (false));
		i_spreadSheetCellInXPropertySet.setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_underLineColor, Integer.valueOf (a_pixelValue));
	}
	
	public void removeUnderLine () throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		i_spreadSheetCellInXPropertySet.setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_underLineStyle,FontUnderline.NONE);
		i_spreadSheetCellInXPropertySet.setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_underLineHasColor, Boolean.valueOf (false));
		i_spreadSheetCellInXPropertySet.setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_underLineColor, Integer.valueOf (UnoPixelValuesConstantsGroup.c_notSpecified));
	}
	
	// com.sun.star.awt.FontUnderline.(NONE, SINGLE, DOUBLE, DOTTED, DONTKNOW, DASH, LONGDASH, DASHDOT, DASHDOTDOT, SMALLWAVE, WAVE, DOUBLEWAVE, BOLD, BOLDDOTTED, BOLDDASH, BOLDLONGDASH, BOLDDASHDOT, BOLDDASHDOTDOT, BOLDWAVE)
	public short getOverLineStyle () throws UnknownPropertyException, WrappedTargetException {
		return ((Short) i_spreadSheetCellInXPropertySet.getPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_overLineStyle)).shortValue ();
	}
	
	public int getOverLineColor () throws UnknownPropertyException, WrappedTargetException {
		return ((Integer) i_spreadSheetCellInXPropertySet.getPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_overLineColor)).intValue ();
	}
	
	// For a_style, com.sun.star.awt.FontUnderline.(NONE, SINGLE, DOUBLE, DOTTED, DONTKNOW, DASH, LONGDASH, DASHDOT, DASHDOTDOT, SMALLWAVE, WAVE, DOUBLEWAVE, BOLD, BOLDDOTTED, BOLDDASH, BOLDLONGDASH, BOLDDASHDOT, BOLDDASHDOTDOT, BOLDWAVE)
	public void setOverLine (short a_style, int a_pixelValue) throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		i_spreadSheetCellInXPropertySet.setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_overLineStyle, new Short (a_style));
		i_spreadSheetCellInXPropertySet.setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_overLineHasColor, a_pixelValue != UnoPixelValuesConstantsGroup.c_notSpecified ? Boolean.valueOf (true): Boolean.valueOf (false));
		i_spreadSheetCellInXPropertySet.setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_overLineColor, Integer.valueOf (a_pixelValue));
	}
	
	public void removeOverLine () throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		i_spreadSheetCellInXPropertySet.setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_overLineStyle,FontUnderline.NONE);
		i_spreadSheetCellInXPropertySet.setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_overLineHasColor, new Boolean (false));
		i_spreadSheetCellInXPropertySet.setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_overLineColor, Integer.valueOf (UnoPixelValuesConstantsGroup.c_notSpecified));
	}
	
	// com.sun.star.awt.FontStrikeout.(NONE, SINGLE, DOUBLE, DONTKNOW, BOLD, SLASH, or X)
	public short getStrikeOutStyle () throws UnknownPropertyException, WrappedTargetException {
		return ((Short) i_spreadSheetCellInXPropertySet.getPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_strikeOutStyle)).shortValue ();
	}
	
	// com.sun.star.awt.FontStrikeout.(NONE, SINGLE, DOUBLE, DONTKNOW, BOLD, SLASH, or X)
	public void setStrikeOut (short a_style) throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		i_spreadSheetCellInXPropertySet.setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_strikeOutStyle, new Short (a_style));
	}
	
	public void removeStrikeOut () throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		i_spreadSheetCellInXPropertySet.setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_strikeOutStyle, FontStrikeout.NONE);
	}
	
	public boolean getWrappedFlag () throws UnknownPropertyException, WrappedTargetException {
		return ((Boolean) i_spreadSheetCellInXPropertySet.getPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_wrappedFlag)).booleanValue ();
	}
	
	public void setWrapped (boolean a_isWrapped) throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		i_spreadSheetCellInXPropertySet.setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_wrappedFlag, new Boolean (a_isWrapped));
	}
	
	// com.sun.star.table.CellHoriJustify.(STANDARD, LEFT, CENTER, RIGHT, BLOCK, REPEAT)
	public CellHoriJustify getHorizontalAlignmentStyle () throws UnknownPropertyException, WrappedTargetException {
		return (CellHoriJustify) i_spreadSheetCellInXPropertySet.getPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_horizontalAlignmentStyle);
	}
	
	// com.sun.star.table.CellHoriJustify.(STANDARD, LEFT, CENTER, RIGHT, BLOCK, REPEAT)
	public void setHorizontalAlignment (CellHoriJustify a_style) throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		i_spreadSheetCellInXPropertySet.setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_horizontalAlignmentStyle, a_style);
	}
	
	// com.sun.star.table.CellVertJustify2.(STANDARD, TOP, CENTER, BOTTOM, or BLOCK)
	public int getVerticalAlignmentStyle () throws UnknownPropertyException, WrappedTargetException {
		return ((Integer) i_spreadSheetCellInXPropertySet.getPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_verticalAlignmentStyle)).intValue ();
	}
	
	// com.sun.star.table.CellVertJustify2.(STANDARD, TOP, CENTER, BOTTOM, or BLOCK)
	public void setVerticalAlignment (int a_style) throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		i_spreadSheetCellInXPropertySet.setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_verticalAlignmentStyle, new Integer (a_style));
	}
	
	// com.sun.star.table.BorderLineStyle.(NONE, SOLID, DOTTED, DASHED, DOUBLE, THINTHICK_SMALLGAP, THINTHICK_MEDIUMGAP, THINTHICK_LARGEGAP, THICKTHIN_SMALLGAP, THICKTHIN_MEDIUMGAP, THICKTHIN_LARGEGAP, EMBOSSED, ENGRAVED, OUTSET, INSET, FINE_DASHED, DOUBLE_THIN, DASH_DOT, DASH_DOT_DOT, or BORDER_LINE_STYLE_MAX)
	public short getLeftBorderStyle () throws UnknownPropertyException, WrappedTargetException {
		BorderLine2 l_borderline = (BorderLine2) i_spreadSheetCellInXPropertySet.getPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_leftBorderStyle);
		return l_borderline.LineStyle;
	}
	
	public int getLeftBorderWidth () throws UnknownPropertyException, WrappedTargetException {
		BorderLine2 l_borderline = (BorderLine2) i_spreadSheetCellInXPropertySet.getPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_leftBorderStyle);
		return l_borderline.LineWidth;
	}
	
	public int getLeftBorderColor () throws UnknownPropertyException, WrappedTargetException {
		BorderLine2 l_borderline = (BorderLine2) i_spreadSheetCellInXPropertySet.getPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_leftBorderStyle);
		return l_borderline.Color;
	}
	
	// For a_style, com.sun.star.table.BorderLineStyle.(NONE, SOLID, DOTTED, DASHED, DOUBLE, THINTHICK_SMALLGAP, THINTHICK_MEDIUMGAP, THINTHICK_LARGEGAP, THICKTHIN_SMALLGAP, THICKTHIN_MEDIUMGAP, THICKTHIN_LARGEGAP, EMBOSSED, ENGRAVED, OUTSET, INSET, FINE_DASHED, DOUBLE_THIN, DASH_DOT, DASH_DOT_DOT, or BORDER_LINE_STYLE_MAX)
	public void setLeftBorder (short a_style, int a_width, int a_color) throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		BorderLine2 l_borderline = new BorderLine2 ();
		l_borderline.LineStyle = a_style;
		l_borderline.LineWidth = a_width;
		l_borderline.Color = a_color;
		i_spreadSheetCellInXPropertySet.setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_leftBorderStyle, l_borderline);
	}
	
	public void removeLeftBorder () throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		BorderLine2 l_borderline = new BorderLine2 ();
		l_borderline.LineStyle =BorderLineStyle.NONE;
		l_borderline.LineWidth = 0;
		l_borderline.Color = UnoPixelValuesConstantsGroup.c_notSpecified;
		i_spreadSheetCellInXPropertySet.setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_leftBorderStyle, l_borderline);
	}
	
	// com.sun.star.table.BorderLineStyle.(NONE, SOLID, DOTTED, DASHED, DOUBLE, THINTHICK_SMALLGAP, THINTHICK_MEDIUMGAP, THINTHICK_LARGEGAP, THICKTHIN_SMALLGAP, THICKTHIN_MEDIUMGAP, THICKTHIN_LARGEGAP, EMBOSSED, ENGRAVED, OUTSET, INSET, FINE_DASHED, DOUBLE_THIN, DASH_DOT, DASH_DOT_DOT, or BORDER_LINE_STYLE_MAX)
	public short getRightBorderStyle () throws UnknownPropertyException, WrappedTargetException {
		BorderLine2 l_borderline = (BorderLine2) i_spreadSheetCellInXPropertySet.getPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_rightBorderStyle);
		return l_borderline.LineStyle;
	}
	
	public int getRightBorderWidth () throws UnknownPropertyException, WrappedTargetException {
		BorderLine2 l_borderline = (BorderLine2) i_spreadSheetCellInXPropertySet.getPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_rightBorderStyle);
		return l_borderline.LineWidth;
	}
	
	public int getRightBorderColor () throws UnknownPropertyException, WrappedTargetException {
		BorderLine2 l_borderline = (BorderLine2) i_spreadSheetCellInXPropertySet.getPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_rightBorderStyle);
		return l_borderline.Color;
	}
	
	// For a_style, com.sun.star.table.BorderLineStyle.(NONE, SOLID, DOTTED, DASHED, DOUBLE, THINTHICK_SMALLGAP, THINTHICK_MEDIUMGAP, THINTHICK_LARGEGAP, THICKTHIN_SMALLGAP, THICKTHIN_MEDIUMGAP, THICKTHIN_LARGEGAP, EMBOSSED, ENGRAVED, OUTSET, INSET, FINE_DASHED, DOUBLE_THIN, DASH_DOT, DASH_DOT_DOT, or BORDER_LINE_STYLE_MAX)
	public void setRightBorder (short a_style, int a_width, int a_color) throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		BorderLine2 l_borderline = new BorderLine2 ();
		l_borderline.LineStyle = a_style;
		l_borderline.LineWidth = a_width;
		l_borderline.Color = a_color;
		i_spreadSheetCellInXPropertySet.setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_rightBorderStyle, l_borderline);
	}
	
	public void removeRightBorder () throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		BorderLine2 l_borderline = new BorderLine2 ();
		l_borderline.LineStyle = BorderLineStyle.NONE;
		l_borderline.LineWidth = 0;
		l_borderline.Color = UnoPixelValuesConstantsGroup.c_notSpecified;
		i_spreadSheetCellInXPropertySet.setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_rightBorderStyle, l_borderline);
	}
	
	// com.sun.star.table.BorderLineStyle.(NONE, SOLID, DOTTED, DASHED, DOUBLE, THINTHICK_SMALLGAP, THINTHICK_MEDIUMGAP, THINTHICK_LARGEGAP, THICKTHIN_SMALLGAP, THICKTHIN_MEDIUMGAP, THICKTHIN_LARGEGAP, EMBOSSED, ENGRAVED, OUTSET, INSET, FINE_DASHED, DOUBLE_THIN, DASH_DOT, DASH_DOT_DOT, or BORDER_LINE_STYLE_MAX)
	public short getTopBorderStyle () throws UnknownPropertyException, WrappedTargetException {
		BorderLine2 l_borderline = (BorderLine2) i_spreadSheetCellInXPropertySet.getPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_topBorderStyle);
		return l_borderline.LineStyle;
	}
	
	public int getTopBorderWidth () throws UnknownPropertyException, WrappedTargetException {
		BorderLine2 l_borderline = (BorderLine2) i_spreadSheetCellInXPropertySet.getPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_topBorderStyle);
		return l_borderline.LineWidth;
	}
	
	public int getTopBorderColor () throws UnknownPropertyException, WrappedTargetException {
		BorderLine2 l_borderline = (BorderLine2) i_spreadSheetCellInXPropertySet.getPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_topBorderStyle);
		return l_borderline.Color;
	}
	
	// For a_style, com.sun.star.table.BorderLineStyle.(NONE, SOLID, DOTTED, DASHED, DOUBLE, THINTHICK_SMALLGAP, THINTHICK_MEDIUMGAP, THINTHICK_LARGEGAP, THICKTHIN_SMALLGAP, THICKTHIN_MEDIUMGAP, THICKTHIN_LARGEGAP, EMBOSSED, ENGRAVED, OUTSET, INSET, FINE_DASHED, DOUBLE_THIN, DASH_DOT, DASH_DOT_DOT, or BORDER_LINE_STYLE_MAX)
	public void setTopBorder (short a_style, int a_width, int a_color) throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		BorderLine2 l_borderline = new BorderLine2 ();
		l_borderline.LineStyle = a_style;
		l_borderline.LineWidth = a_width;
		l_borderline.Color = a_color;
		i_spreadSheetCellInXPropertySet.setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_topBorderStyle, l_borderline);
	}
	
	public void removeTopBorder () throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		BorderLine2 l_borderline = new BorderLine2 ();
		l_borderline.LineStyle = BorderLineStyle.NONE;
		l_borderline.LineWidth = 0;
		l_borderline.Color = UnoPixelValuesConstantsGroup.c_notSpecified;
		i_spreadSheetCellInXPropertySet.setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_topBorderStyle, l_borderline);
	}
	
	// com.sun.star.table.BorderLineStyle.(NONE, SOLID, DOTTED, DASHED, DOUBLE, THINTHICK_SMALLGAP, THINTHICK_MEDIUMGAP, THINTHICK_LARGEGAP, THICKTHIN_SMALLGAP, THICKTHIN_MEDIUMGAP, THICKTHIN_LARGEGAP, EMBOSSED, ENGRAVED, OUTSET, INSET, FINE_DASHED, DOUBLE_THIN, DASH_DOT, DASH_DOT_DOT, or BORDER_LINE_STYLE_MAX)
	public short getBottomBorderStyle () throws UnknownPropertyException, WrappedTargetException {
		BorderLine2 l_borderline = (BorderLine2) i_spreadSheetCellInXPropertySet.getPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_bottomBorderStyle);
		return l_borderline.LineStyle;
	}
	
	public int getBottomBorderWidth () throws UnknownPropertyException, WrappedTargetException {
		BorderLine2 l_borderline = (BorderLine2) i_spreadSheetCellInXPropertySet.getPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_bottomBorderStyle);
		return l_borderline.LineWidth;
	}
	
	public int getBottomBorderColor () throws UnknownPropertyException, WrappedTargetException {
		BorderLine2 l_borderline = (BorderLine2) i_spreadSheetCellInXPropertySet.getPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_bottomBorderStyle);
		return l_borderline.Color;
	}
	
	// For a_style, com.sun.star.table.BorderLineStyle.(NONE, SOLID, DOTTED, DASHED, DOUBLE, THINTHICK_SMALLGAP, THINTHICK_MEDIUMGAP, THINTHICK_LARGEGAP, THICKTHIN_SMALLGAP, THICKTHIN_MEDIUMGAP, THICKTHIN_LARGEGAP, EMBOSSED, ENGRAVED, OUTSET, INSET, FINE_DASHED, DOUBLE_THIN, DASH_DOT, DASH_DOT_DOT, or BORDER_LINE_STYLE_MAX)
	public void setBottomBorder (short a_style, int a_width, int a_color) throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		BorderLine2 l_borderline = new BorderLine2 ();
		l_borderline.LineStyle = a_style;
		l_borderline.LineWidth = a_width;
		l_borderline.Color = a_color;
		i_spreadSheetCellInXPropertySet.setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_bottomBorderStyle, l_borderline);
	}
	
	public void removeBottomBorder () throws UnknownPropertyException, PropertyVetoException, WrappedTargetException {
		BorderLine2 l_borderline = new BorderLine2 ();
		l_borderline.LineStyle = BorderLineStyle.NONE;
		l_borderline.LineWidth = 0;
		l_borderline.Color = UnoPixelValuesConstantsGroup.c_notSpecified;
		i_spreadSheetCellInXPropertySet.setPropertyValue (UnoSpreadSheetCellPropertyNamesSet.c_bottomBorderStyle, l_borderline);
	}
}
