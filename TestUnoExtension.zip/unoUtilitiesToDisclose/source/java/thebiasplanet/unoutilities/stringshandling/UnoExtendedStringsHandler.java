package thebiasplanet.unoutilities.stringshandling;

import thebiasplanet.coreutilities.constantsgroups.*;
import thebiasplanet.coreutilities.stringshandling.StringsHandler;
import thebiasplanet.unoutilities.documentshandling.spreadsheetsdocumentshandling.UnoSpreadSheetFormula;

public class UnoExtendedStringsHandler extends StringsHandler {
	public static Object getObject (String a_string, Class a_objectClass) throws UnsupportedOperationException {
		if (a_objectClass == UnoSpreadSheetFormula.class) {
			return new UnoSpreadSheetFormula (a_string, GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger);
		}
		else {
			return StringsHandler.getObject (a_string, a_objectClass);
		}
	}
}
