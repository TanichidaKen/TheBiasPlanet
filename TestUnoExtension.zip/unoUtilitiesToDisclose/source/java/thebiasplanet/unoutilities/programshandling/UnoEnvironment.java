package thebiasplanet.unoutilities.programshandling;

import java.lang.reflect.InvocationTargetException;
import java.util.Map;
import java.util.HashMap;
import java.io.IOException;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;
import com.sun.star.uno.XComponentContext;
import com.sun.star.comp.helper.Bootstrap;
import thebiasplanet.unoutilities.connectionshandling.UnoComponentContext;
import thebiasplanet.unoutilities.constantsgroups.*;

public class UnoEnvironment {
	private UnoComponentContext i_localComponentContext;
	
	public UnoEnvironment (XComponentContext a_originalLocalComponentContext, String a_identification, String a_servicesSettingFileUrl) throws IOException, ParserConfigurationException, SAXException, ClassNotFoundException, NoSuchMethodException, InvocationTargetException, IllegalAccessException, com.sun.star.uno.Exception {
		try {
			Map <String, Object> l_extraNameToValueMap = new HashMap <String, Object> ();
			l_extraNameToValueMap.put (UnoComponentContextPropertyNamesConstantsGroup.c_identification, a_identification);
			XComponentContext l_originalLocalComponentContext = null;
			if (a_originalLocalComponentContext != null) {
				if (!(a_originalLocalComponentContext instanceof UnoComponentContext)) {
					l_originalLocalComponentContext = a_originalLocalComponentContext;
				}
			}
			else {
				l_originalLocalComponentContext = Bootstrap.createInitialComponentContext (null);
			}
			if (l_originalLocalComponentContext != null) {
				i_localComponentContext = new UnoComponentContext (l_originalLocalComponentContext, l_extraNameToValueMap);
			}
			else {
				i_localComponentContext = (UnoComponentContext) a_originalLocalComponentContext;
			}
		}
		catch (Exception l_exception) {
			throw new com.sun.star.uno.Exception (String.format ("%s %s", UnoMessagesConstantsGroup.c_componentContextNotCreated,  l_exception.toString ()));
		}
	}
	
	public final UnoComponentContext getLocalComponentContext () {
		return i_localComponentContext;
	}
}

