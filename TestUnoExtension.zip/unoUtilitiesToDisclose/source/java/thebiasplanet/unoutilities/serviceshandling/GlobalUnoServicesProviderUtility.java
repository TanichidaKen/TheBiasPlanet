package thebiasplanet.unoutilities.serviceshandling;

import java.util.Map;
import java.util.Set;
import com.sun.star.lang.XSingleComponentFactory;
import com.sun.star.registry.XRegistryKey;
import com.sun.star.lib.uno.helper.Factory;
import thebiasplanet.coreutilities.constantsgroups.*;
import thebiasplanet.coreutilities.collectionshandling.MapHandler;
import thebiasplanet.coreutilities.collectionshandling.ArrayFactory;

public class GlobalUnoServicesProviderUtility {
	public static XSingleComponentFactory getSingleComponentFactory (Map <String, Map <Class <?>, Set <String>>> a_unoComponentClassNameToUnoComponentClassToServiceNamesMapMap, String a_unoComponentClassName) {
		XSingleComponentFactory l_singleComponentFactoryInXSingleComponentFactory = null;
		Map <Class <?>, Set <String>> l_unoComponentClassToServiceNamesMap = a_unoComponentClassNameToUnoComponentClassToServiceNamesMapMap.get (a_unoComponentClassName);
		if (l_unoComponentClassToServiceNamesMap != null) {
			@SuppressWarnings (WarningNamesConstantsGroup.c_notChecked)
			Map.Entry <Class <?>, Set <String>> l_unoComponentClassToServiceNamesMapEntry = MapHandler. <Class <?>, Set <String>>getFirstEntry (l_unoComponentClassToServiceNamesMap);
			Set <String> l_serviceNames =  l_unoComponentClassToServiceNamesMapEntry.getValue ();
			l_singleComponentFactoryInXSingleComponentFactory = Factory.createComponentFactory (l_unoComponentClassToServiceNamesMapEntry.getKey (), ArrayFactory. <String>createArray (String.class, l_serviceNames));
		}
		return l_singleComponentFactoryInXSingleComponentFactory;
	}
	
	public static boolean writeServicesInformationToRegistry (Map <String, Map <Class <?>, Set <String>>> a_unoComponentClassNameToUnoComponentClassToServiceNamesMapMap, XRegistryKey a_registryKeyInXRegistryKey) {
		boolean l_returnStatus = false;
		for (Map.Entry <String,  Map <Class <?>, Set <String>>> l_unoComponentClassNameToUnoComponentClassToServiceNamesMapMapEntry: a_unoComponentClassNameToUnoComponentClassToServiceNamesMapMap.entrySet ()) {
			@SuppressWarnings (WarningNamesConstantsGroup.c_notChecked)
			Map.Entry <Class <?>, Set <String>> l_unoComponentClassToServiceNamesMapEntry = MapHandler. <Class <?>, Set <String>>getFirstEntry (l_unoComponentClassNameToUnoComponentClassToServiceNamesMapMapEntry.getValue ());
			Set <String> l_serviceNames = l_unoComponentClassToServiceNamesMapEntry.getValue ();
			l_returnStatus = Factory.writeRegistryServiceInfo (l_unoComponentClassNameToUnoComponentClassToServiceNamesMapMapEntry.getKey (), ArrayFactory. <String>createArray (String.class, l_serviceNames), a_registryKeyInXRegistryKey);
			if (!l_returnStatus) {
				break;
			}
		}
		return l_returnStatus;
	}
}
