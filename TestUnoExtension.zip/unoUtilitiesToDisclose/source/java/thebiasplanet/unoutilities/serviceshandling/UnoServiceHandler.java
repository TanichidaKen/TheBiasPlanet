package thebiasplanet.unoutilities.serviceshandling;

import java.util.List;
import com.sun.star.uno.XComponentContext;
import com.sun.star.uno.UnoRuntime;
import com.sun.star.uno.XInterface;
import com.sun.star.uno.Type;
import com.sun.star.uno.TypeClass;
import thebiasplanet.coreutilities.collectionshandling.ArrayFactory;

public final class UnoServiceHandler {
	private UnoServiceHandler () {
	}
	
	public static Object getServiceInstance (XComponentContext a_componentContextInXComponentContext, String a_serviceName, Class a_targetClass, List <Object> a_arguments) throws com.sun.star.uno.Exception {
		Object l_serviceInstance = null;
		Object l_targetProxy = null;
		if (a_arguments == null) {
			l_serviceInstance = a_componentContextInXComponentContext.getServiceManager ().createInstanceWithContext (a_serviceName, a_componentContextInXComponentContext);
		}
		else {
			l_serviceInstance = a_componentContextInXComponentContext.getServiceManager ().createInstanceWithArgumentsAndContext (a_serviceName, ArrayFactory. <Object>createArray (Object.class, a_arguments), a_componentContextInXComponentContext);
		}
		if (l_serviceInstance != null && a_targetClass != null && XInterface.class.isAssignableFrom (a_targetClass)) {
			l_targetProxy =  UnoRuntime.queryInterface (new Type (a_targetClass.getName (), TypeClass.INTERFACE), l_serviceInstance);
		}
		return l_targetProxy;
	}
	
	public static Object getServiceInstance (XComponentContext a_componentContextInXComponentContext, String a_serviceName, Class a_targetClass) throws com.sun.star.uno.Exception {
		return getServiceInstance (a_componentContextInXComponentContext, a_serviceName, a_targetClass, null);
	}
}
