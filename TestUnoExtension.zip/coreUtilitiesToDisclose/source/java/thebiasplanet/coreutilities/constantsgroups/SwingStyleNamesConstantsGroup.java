package thebiasplanet.coreutilities.constantsgroups;

public interface SwingStyleNamesConstantsGroup {
	String c_normal = "normal";
}
