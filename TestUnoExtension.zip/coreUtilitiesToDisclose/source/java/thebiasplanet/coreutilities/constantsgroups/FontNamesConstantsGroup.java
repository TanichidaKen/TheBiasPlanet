package thebiasplanet.coreutilities.constantsgroups;

public interface FontNamesConstantsGroup {
	String c_liberationMono = "Liberation Mono";
}
