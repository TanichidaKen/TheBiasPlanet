package thebiasplanet.coreutilities.constantsgroups;

public interface MimeTypesConstantsGroup {
	String c_textPlain = "text/plain";
}
