package thebiasplanet.coreutilities.constantsgroups;

public interface CharactersConstantsGroup {
	char c_newLine = '\n';
	char c_carriageReturn = '\r';
	char c_semicolon = ';';
}
