package thebiasplanet.coreutilities.constantsgroups;

public interface CharactersConstantsGroup {
	char c_newLineCharacter = '\n';
	char c_carriageReturnCharacter = '\r';
	char c_semicolonCharacter = ';';
	char c_utfBomCharacter = '\uFEFF';
	char c_lessThanCharacter = '<';
	char c_greaterThanCharacter = '>';
	char c_ampersandCharacter = '&';
	char c_doubleQuotationMarkCharacter = '\"';
	char c_apostropheCharacter = '\'';
}
