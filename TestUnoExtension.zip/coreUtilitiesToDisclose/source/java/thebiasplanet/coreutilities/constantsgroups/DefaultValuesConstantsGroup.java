package thebiasplanet.coreutilities.constantsgroups;

public interface DefaultValuesConstantsGroup {
	int c_smallBufferSize = 1024;
	int c_largeBufferSize = 102400;
	int c_smallestBufferSize = 1;
}
