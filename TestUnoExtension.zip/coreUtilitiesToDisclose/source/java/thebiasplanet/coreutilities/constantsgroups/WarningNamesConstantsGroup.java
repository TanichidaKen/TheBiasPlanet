package thebiasplanet.coreutilities.constantsgroups;

public interface WarningNamesConstantsGroup {
	String c_notChecked = "unchecked";
}
