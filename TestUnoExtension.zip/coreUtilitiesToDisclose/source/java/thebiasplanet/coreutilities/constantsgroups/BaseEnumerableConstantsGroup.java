package thebiasplanet.coreutilities.constantsgroups;

// ## Comments that start with the mark, ##, are instructions for extending this class, where XXX is the class name of the extended class.
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.LinkedHashMap;
import thebiasplanet.coreutilities.reflectionshandling.ReflectionHandler;
import thebiasplanet.coreutilities.collectionshandling.ListFactory;
import thebiasplanet.coreutilities.collectionshandling.SetFactory;
import thebiasplanet.coreutilities.collectionshandling.MapFactory;

// ## The class has to be public, extend BaseConstantsGroup, and implement some constants group interfaces of T constants
abstract public class BaseEnumerableConstantsGroup <T> {
	private LinkedHashMap <String, T> i_nameToValueMap;
	// ## Define this.
	// ## public static final XXX c_instance = new XXX ();
	
	// ## Define the private constructor.
	
	protected BaseEnumerableConstantsGroup () {
		try {
			i_nameToValueMap = MapFactory. <String, T>createLinkedHashMapExpandingItems (ReflectionHandler.getFieldNamesAndValues (this.getClass (), null, true, false, null, ListFactory. <Class <?>>createArrayList (this.getClass ()), true));
		}
		catch (IllegalAccessException l_exception) {
			throw new RuntimeException (l_exception);
		}
	}
	
	public LinkedHashSet <String> getNames () {
		return SetFactory. <String>createLinkedHashSetExpandingItems (i_nameToValueMap.keySet ());
	}
	
	public ArrayList <T> getValues () {
		return ListFactory. <T>createArrayListExpandingItems (i_nameToValueMap.values ());
	}
}
