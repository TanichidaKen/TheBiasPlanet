package thebiasplanet.coreutilities.constantsgroups;

public interface JavaPropertyNamesConstantsGroup {
	String c_userHome = "user.home";
}
