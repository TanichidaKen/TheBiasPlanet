package thebiasplanet.coreutilities.constantsgroups;

public interface LiteralExpressionsConstantsGroup {
	String c_colonDelimiter = ": ";
	String c_commaDelimiter = ", ";
	String c_directoryDelimiter = "/";
	String c_integerDefaultFormat = "%d";
	String c_doubleDefaultFormat = "%f";
	String c_booleanDefaultFormat = "%b";
}
