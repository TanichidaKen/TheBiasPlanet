package thebiasplanet.coreutilities.constantsgroups;

public interface JTextComponentPropertyNamesConstantsGroup {
	String c_font = "font";
}
