package thebiasplanet.coreutilities.xmldatahandling;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import thebiasplanet.coreutilities.constantsgroups.*;
import thebiasplanet.coreutilities.fileshandling.FilesHandler;
import thebiasplanet.coreutilities.inputs.Utf8BomIgnoringInputStreamReader;

public final class XmlDataHandler {
	private XmlDataHandler () {
	}
	
	public static String getEscapedXmlText (String a_originalText) {
		Map <Character, String> l_toEscapeCharacterEscapedStringMap = new HashMap <Character, String> ();
		l_toEscapeCharacterEscapedStringMap.put (CharactersConstantsGroup.c_lessThanCharacter, XmlExpressionsConstantsGroup.c_lessThanXmlExpression);
		l_toEscapeCharacterEscapedStringMap.put (CharactersConstantsGroup.c_greaterThanCharacter, XmlExpressionsConstantsGroup.c_greaterThanXmlExpression);
		l_toEscapeCharacterEscapedStringMap.put (CharactersConstantsGroup.c_ampersandCharacter, XmlExpressionsConstantsGroup.c_ampersandXmlExpression);
		l_toEscapeCharacterEscapedStringMap.put (CharactersConstantsGroup.c_doubleQuotationMarkCharacter, XmlExpressionsConstantsGroup.c_doubleQuotationMarkXmlExpression);
		l_toEscapeCharacterEscapedStringMap.put (CharactersConstantsGroup.c_apostropheCharacter, XmlExpressionsConstantsGroup.c_apostropheXmlExpression);
		StringReader l_stringReader = new StringReader (a_originalText);
		int l_processingData = InputPropertiesConstantsGroup.c_noMoreData;
		char l_processingCharacter;
		StringBuffer l_escapedText = new StringBuffer ();
		String l_characterEscapedString = null;
		while (true) {
			try {
				l_processingData = l_stringReader.read ();
			}
			catch (IOException l_exception) {
				throw new RuntimeException (l_exception);
			}
			if (l_processingData == InputPropertiesConstantsGroup.c_noMoreData) {
				break;
			}
			l_processingCharacter = (char) l_processingData;
			l_characterEscapedString = l_toEscapeCharacterEscapedStringMap.get (l_processingCharacter);
			if (l_characterEscapedString == null) {
				l_escapedText.append (l_processingCharacter);
			}
			else {
				l_escapedText.append (l_characterEscapedString);
			}
		}
		l_stringReader.close ();
		return l_escapedText.toString ();
	}
	
	public static void transform (Reader a_originalDataReader, Reader a_styleSheetReader, Writer a_transformedDataWriter, Map <String, Object> a_parametersMap) throws IOException, TransformerException {
		TransformerFactory l_transformerFactory = TransformerFactory.newInstance ();
		Transformer l_transformer = l_transformerFactory.newTransformer (new StreamSource (a_styleSheetReader));
		if (a_parametersMap != null) {
			for (Map.Entry <String, Object> l_parametersMapEntry: a_parametersMap.entrySet ()) {
				l_transformer.setParameter (l_parametersMapEntry.getKey (), l_parametersMapEntry.getValue ());
			}
		}
		l_transformer.transform (new StreamSource (a_originalDataReader), new StreamResult (a_transformedDataWriter));
	}
	
	public static void transform (String a_sourceFileName, String a_styleSheetFileName, String a_outputFileName, Map <String, Object> a_xsltParametersMap, boolean a_replace) throws FileNotFoundException, IOException, UnsupportedEncodingException, TransformerException, FileAlreadyExistsException {
		BufferedReader l_originalDataReader = new BufferedReader (new Utf8BomIgnoringInputStreamReader (new InputStreamReader (new FileInputStream (new File (a_sourceFileName)), EncodingNamesConstantsGroup.c_utf8EncodingName)));
		transform (l_originalDataReader, a_styleSheetFileName, a_outputFileName, a_xsltParametersMap, a_replace);
		l_originalDataReader.close ();
	}
	
	public static void transform (Reader a_originalDataReader, String a_styleSheetFileName, String a_outputFileName, Map <String, Object> a_xsltParametersMap, boolean a_replace) throws FileNotFoundException, IOException, UnsupportedEncodingException, TransformerException {
		BufferedReader l_styleSheetReader = new BufferedReader (new InputStreamReader (new FileInputStream (new File (a_styleSheetFileName)), EncodingNamesConstantsGroup.c_utf8EncodingName));
		Path l_outputFile = Paths.get (a_outputFileName);
		if (!a_replace && Files.exists (l_outputFile)) {
			throw new FileAlreadyExistsException (a_outputFileName);
		}
		FilesHandler.createDirectoryIfNecessary (l_outputFile);
		OutputStreamWriter l_outputStreamWriter = new OutputStreamWriter (new FileOutputStream (l_outputFile.toFile ()), EncodingNamesConstantsGroup.c_utf8EncodingName);
		XmlDataHandler.transform (a_originalDataReader, l_styleSheetReader, l_outputStreamWriter, a_xsltParametersMap);
		l_outputStreamWriter.close ();
		l_styleSheetReader.close ();
	}
}
