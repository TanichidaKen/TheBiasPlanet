package thebiasplanet.coreutilities.collectionshandling;

import java.util.Map;

public class MapHandler {
	public static <T, U> Map.Entry <T, U> getFirstEntry (Map <T, U> a_map) {
		for (Map.Entry <T, U> l_mapEntry: a_map.entrySet ()) {
			return l_mapEntry;
		}
		return null;
	}
}
