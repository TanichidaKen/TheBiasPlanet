package thebiasplanet.coreutilities.inputs;

import java.io.InputStreamReader;
import java.io.FilterReader;
import java.io.IOException;
import thebiasplanet.coreutilities.constantsgroups.*;

public class Utf8BomIgnoringInputStreamReader extends FilterReader {
	private boolean isUtf8 = false;
	private boolean isAtTheBeginning = true;
	private char [] inMethodBuffer = new char [DefaultValuesConstantsGroup.c_smallestBufferSize];
	
	public Utf8BomIgnoringInputStreamReader (InputStreamReader p_originalInputStreamReader) {
		super (p_originalInputStreamReader);
		if (EncodingNamesConstantsGroup.c_utf8InputStreamReaderReturningEncodingName.equals (p_originalInputStreamReader.getEncoding())) {
			isUtf8 = true;
		}
	}
	
	public int read (char [] p_characters, int p_offset, int p_length) throws IOException {
		int l_readLength = InputPropertiesConstantsGroup.c_noDataRetrieved;
		if (isUtf8 && isAtTheBeginning) {
			char [] l_characters = new char [p_length];
			l_readLength = in.read (l_characters, p_offset, p_length);
			if (l_readLength > InputPropertiesConstantsGroup.c_noDataRetrieved) {
				int l_arrayElementIndexOffset = GeneralConstantsConstantsGroup.c_iterationStartingNumber;
				if (l_characters [GeneralConstantsConstantsGroup.c_iterationStartingNumber] == CharactersConstantsGroup.c_utfBomCharacter) {
					l_arrayElementIndexOffset ++;
				}
				else {
				}
				for (int l_arrayElementIndex = GeneralConstantsConstantsGroup.c_iterationStartingNumber; l_arrayElementIndex + l_arrayElementIndexOffset < l_readLength; l_arrayElementIndex ++) {
					p_characters [l_arrayElementIndex] = l_characters [l_arrayElementIndex + l_arrayElementIndexOffset];
				}
				l_readLength -= l_arrayElementIndexOffset;
				if (l_arrayElementIndexOffset > GeneralConstantsConstantsGroup.c_iterationStartingNumber) {
					if (in.read (p_characters, l_readLength, l_arrayElementIndexOffset) == l_arrayElementIndexOffset) {
						l_readLength += l_arrayElementIndexOffset;
					}
				}
			}
			isAtTheBeginning = false;
		}
		else {
			l_readLength = in.read (p_characters, p_offset, p_length);
		}
		return l_readLength;
	}
	
	public int read () throws IOException {
		int l_readFunctionReturn = read (inMethodBuffer, GeneralConstantsConstantsGroup.c_iterationStartingNumber, DefaultValuesConstantsGroup.c_smallestBufferSize);
		if (l_readFunctionReturn == InputPropertiesConstantsGroup.c_noMoreData) {
			return l_readFunctionReturn;
		}
		else {
			return inMethodBuffer [GeneralConstantsConstantsGroup.c_iterationStartingNumber];
		}
	}
}
