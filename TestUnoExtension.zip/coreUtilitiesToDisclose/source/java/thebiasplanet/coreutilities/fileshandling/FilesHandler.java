package thebiasplanet.coreutilities.fileshandling;

import java.util.EnumSet;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.FileVisitResult;
import java.nio.file.FileVisitOption;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.BasicFileAttributes;

public class FilesHandler {
	public static void copy (String p_sourceRootDirectoryName, String p_filesGlobExpression, String p_destinationRootDirectoryName) throws IOException {
		Path l_sourceRootDirectoryPath = Paths.get (p_sourceRootDirectoryName);
		Path l_destinationRootDirectoryPath = Paths.get (p_destinationRootDirectoryName);
		Files.walkFileTree (l_sourceRootDirectoryPath, EnumSet.of (FileVisitOption.FOLLOW_LINKS), Integer.MAX_VALUE,
			new SimpleFileVisitor <Path> () {
				@Override
				public FileVisitResult preVisitDirectory (Path p_directoryPath, BasicFileAttributes p_fileAttributes)
						throws IOException {
					Path l_destinationSubDirectory = l_destinationRootDirectoryPath.resolve (l_sourceRootDirectoryPath.relativize (p_directoryPath));
					try {
						Files.copy(p_directoryPath, l_destinationSubDirectory);
					}
					catch (FileAlreadyExistsException l_exception) {
						if (!Files.isDirectory (l_destinationSubDirectory)) {
							throw l_exception;
						}
					}
					return FileVisitResult.CONTINUE;
				}
				@Override
				public FileVisitResult visitFile (Path p_filePath, BasicFileAttributes p_fileAttributes)
						throws IOException {
					Files.copy(p_filePath, l_destinationRootDirectoryPath.resolve (l_sourceRootDirectoryPath.relativize (p_filePath)), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.COPY_ATTRIBUTES);
					return FileVisitResult.CONTINUE;
				}
			}
		);
	}
	
	public static boolean copy (String a_sourceFilePath, String a_targetFilePath, boolean a_overwrite) throws IOException {
		Path l_sourceFile = Paths.get (a_sourceFilePath);
		if (!Files.exists (l_sourceFile)) {
			return false;
		}
		Path l_targetFile = Paths.get (a_targetFilePath);
		if (Files.exists (l_targetFile) && !a_overwrite) {
			return false;
		}
		createDirectoryIfNecessary (l_targetFile);
		Files.copy(l_sourceFile, l_targetFile, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.COPY_ATTRIBUTES);
		return true;
	}
	
	// return: true -> created, false -> not created
	public static boolean createDirectoryIfNecessary (String a_fileOrDirectoryName) throws IOException {
		return createDirectoryIfNecessary (Paths.get (a_fileOrDirectoryName));
	}
	
	// return: true -> created, false -> not created
	public static boolean createDirectoryIfNecessary (Path a_fileOrDirectory) throws IOException {
		Path l_targetDirectory = null;
		if (!Files.isDirectory (a_fileOrDirectory)) {
			l_targetDirectory = a_fileOrDirectory.getParent ();
		}
		else {
			l_targetDirectory = a_fileOrDirectory;
		}
		if (l_targetDirectory != null && !Files.exists (l_targetDirectory)) {
			Files.createDirectories (l_targetDirectory);
			return true;
		}
		return false;
	}
}
