package thebiasplanet.coreutilities.displayshandling;

import java.awt.Font;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JTextField;
import javax.swing.JOptionPane;
import thebiasplanet.coreutilities.constantsgroups.*;
import thebiasplanet.coreutilities.stringshandling.StringsHandler;

public class SwingComponentsFactory {
	private static Font s_font;
	private static int s_captionLength;
	
	static {
		s_font = null;
		s_captionLength = GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger;
	}
	
	private static String getCaption (String a_toolTipText) {
		if (s_captionLength == GeneralConstantsConstantsGroup.c_anyUnspecifiedInteger) {
			return a_toolTipText;
		}
		else {
			return StringsHandler.getCaptionString (a_toolTipText, s_captionLength);
		}
	}
	
	public static void setFont (Font a_font) {
		s_font = a_font;
	}
	
	public static void setCaptionLength (int a_captionLength) {
		s_captionLength = a_captionLength;
	}
	
	public static JTextField createTextField (String a_toolTipText) {
		JTextField l_createdTextField = new ExtendedJTextField ();
		l_createdTextField.setFont (s_font);
		l_createdTextField.setToolTipText (a_toolTipText);
		return l_createdTextField;
	}
	
	public static JCheckBox createCheckBox (String a_toolTipText, boolean a_defaultValue) {
		JCheckBox l_createdCheckBox = new JCheckBox (getCaption (a_toolTipText), a_defaultValue);
		if (s_font != null) {
			l_createdCheckBox.setFont (s_font);
		}
		l_createdCheckBox.setToolTipText (a_toolTipText);
		return l_createdCheckBox;
	}
	
	public static JButton createButton (String a_toolTipText, int a_shorcutKey, ActionListener a_actionListener) {
		JButton l_createdButton = new JButton (getCaption (a_toolTipText));
		if (s_font != null) {
			l_createdButton.setFont (s_font);
		}
		l_createdButton.setMnemonic (a_shorcutKey);
		l_createdButton.setToolTipText (a_toolTipText);
		l_createdButton.addActionListener (a_actionListener);
		return l_createdButton;
	}
	
	public static JButton createButtonForOptionPane (String a_toolTipText, int a_shorcutKey) {
		return createButton (a_toolTipText, a_shorcutKey,
			(a_event) -> {
				JOptionPane l_sourcePane = (JOptionPane) ((JComponent) a_event.getSource ()).getParent ().getParent ();
				l_sourcePane.setValue (a_event.getSource ());
			}
		);
	}
}
