package thebiasplanet.coreutilities.displayshandling;

import javax.swing.JTextField;
import javax.swing.text.Document;

public class ExtendedJTextField extends JTextField {
	public ExtendedJTextField () {
		super ();
		initialize ();
	}
	
	public ExtendedJTextField (Document a_document, String a_text, int a_numberOfColumns) {
		super (a_document, a_text, a_numberOfColumns);
		initialize ();
	}
	
	public ExtendedJTextField (int a_numberOfColumns) {
		super (a_numberOfColumns);
		initialize ();
	}
	
	public ExtendedJTextField (String a_text) {
		super (a_text);
		initialize ();
	}
	
	public ExtendedJTextField (String a_text, int a_numberOfColumns) {
		super ();
		initialize ();
	}
	
	private void initialize () {
		PopUpMenuInjector.injectEditorPopUpMenu (this);
	}
}
