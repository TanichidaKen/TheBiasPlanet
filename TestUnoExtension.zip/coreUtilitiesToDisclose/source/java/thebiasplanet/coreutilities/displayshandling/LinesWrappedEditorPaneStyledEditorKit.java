package thebiasplanet.coreutilities.displayshandling;

import javax.swing.text.StyledEditorKit;
import javax.swing.text.ViewFactory;

public class LinesWrappedEditorPaneStyledEditorKit extends StyledEditorKit {
	ViewFactory i_linesWrappedviewFactory;
	
	public LinesWrappedEditorPaneStyledEditorKit () {
		i_linesWrappedviewFactory = new LinesWrappedEditorPaneViewsFactory ();
	}
	
	@Override
	public ViewFactory getViewFactory () {
		return i_linesWrappedviewFactory;
	}
}
