package thebiasplanet.coreutilities.displayshandling;

import javax.swing.text.ViewFactory;
import javax.swing.text.Element;
import javax.swing.text.AbstractDocument;
import javax.swing.text.ParagraphView;
import javax.swing.text.BoxView;
import javax.swing.text.ComponentView;
import javax.swing.text.IconView;
import javax.swing.text.LabelView;
import javax.swing.text.View;
import javax.swing.text.StyleConstants;

public class LinesWrappedEditorPaneViewsFactory implements ViewFactory {
	public View create (Element a_element) {
		String l_elementKind = a_element.getName ();
		if (l_elementKind != null) {
			if (l_elementKind.equals (AbstractDocument.ContentElementName)) {
				return new LinesWrappedEditorPaneLeafView (a_element);
			} else if (l_elementKind.equals (AbstractDocument.ParagraphElementName)) {
				return new ParagraphView (a_element);
			} else if (l_elementKind.equals (AbstractDocument.SectionElementName)) {
				return new BoxView (a_element, View.Y_AXIS);
			} else if (l_elementKind.equals (StyleConstants.ComponentElementName)) {
				return new ComponentView (a_element);
			} else if (l_elementKind.equals (StyleConstants.IconElementName)) {
				return new IconView (a_element);
			}
		}
		// default to text display
		return new LabelView (a_element);
	}
}
