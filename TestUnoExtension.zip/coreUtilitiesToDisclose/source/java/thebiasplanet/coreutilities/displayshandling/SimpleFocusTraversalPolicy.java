package thebiasplanet.coreutilities.displayshandling;

import java.awt.FocusTraversalPolicy;
import java.awt.Container;
import java.awt.Component;
import java.awt.Window;
import thebiasplanet.coreutilities.constantsgroups.*;
import thebiasplanet.coreutilities.collections.NavigatableLinkedHashMap;

public class SimpleFocusTraversalPolicy extends FocusTraversalPolicy {
	private NavigatableLinkedHashMap <Component, String> i_componentToDummyMap;
	private Component i_defaultComponent;
	private Component i_initialComponent;
	
	public SimpleFocusTraversalPolicy (Component a_defaultComponent, Component a_initialComponent, Component ... a_componentsInTabOrder) {
		i_componentToDummyMap = new  NavigatableLinkedHashMap <Component, String> ();
		for (Component l_component: a_componentsInTabOrder) {
			i_componentToDummyMap.put (l_component, GeneralConstantsConstantsGroup.c_emptySpace);
		}
		i_defaultComponent = a_defaultComponent;
		i_initialComponent = a_initialComponent;
	}
	
	public void setDefaultComponent (Component a_defaultComponent) {
		i_defaultComponent = a_defaultComponent;
	}
	
	public void setInitialComponent (Component a_initialComponent) {
		i_initialComponent = a_initialComponent;
	}
	
	public void addComponents (Component ... a_componentsInTabOrder) {
		for (Component l_component: a_componentsInTabOrder) {
			i_componentToDummyMap.put (l_component, GeneralConstantsConstantsGroup.c_emptySpace);
		}
	}
	
	public void insertComponentsBefore (Component a_insertedPositionComponent, Component ... a_componentsInTabOrder) {
		for (Component l_component: a_componentsInTabOrder) {
			i_componentToDummyMap.putBefore (a_insertedPositionComponent, l_component, GeneralConstantsConstantsGroup.c_emptySpace);
		}
	}
	
	@Override
	public Component getComponentAfter (Container a_container, Component a_component) {
		for (Component l_nextComponent = i_componentToDummyMap.getNextKey (a_component); l_nextComponent != a_component; ) {
			if (l_nextComponent == null) {
				l_nextComponent = i_componentToDummyMap.getFirstKey ();
			}
			if (l_nextComponent.isEnabled ()) {
				return l_nextComponent;
			}
			l_nextComponent = i_componentToDummyMap.getNextKey (l_nextComponent);
		}
		return a_component;
	}
	
	@Override
	public Component getComponentBefore (Container a_container, Component a_component) {
		for (Component l_previousComponent = i_componentToDummyMap.getPreviousKey (a_component); l_previousComponent != a_component; ) {
			if (l_previousComponent == null) {
				l_previousComponent = i_componentToDummyMap.getLastKey ();
			}
			if (l_previousComponent.isEnabled ()) {
				return l_previousComponent;
			}
			l_previousComponent = i_componentToDummyMap.getPreviousKey (l_previousComponent);
		}
		return a_component;
	}
	
	@Override
	public Component getDefaultComponent (Container a_container) {
		return i_defaultComponent;
	}
	
	@Override
	public Component getFirstComponent (Container a_container) {
		return i_componentToDummyMap.getFirstKey ();
	}
	
	@Override
	public Component getInitialComponent (Window a_window) {
		return i_initialComponent;
	}
	
	@Override
	public Component getLastComponent (Container a_container) {
		return i_componentToDummyMap.getLastKey ();
	}
}
