package thebiasplanet.uno.testunoextension;

import java.util.Set;
import java.util.HashSet;
import java.util.Map;
import com.sun.star.lib.uno.helper.WeakBase;
import com.sun.star.lang.XServiceInfo;
import com.sun.star.lang.XInitialization;
import com.sun.star.uno.XComponentContext;
import thebiasplanet.coreutilities.collectionshandling.MapFactory;
import thebiasplanet.coreutilities.collectionshandling.ArrayFactory;
// # Add necessary classes and interfaces START
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.math.BigDecimal;
import java.awt.Rectangle;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.JOptionPane;
import com.sun.star.lang.Locale;
import com.sun.star.lang.WrappedTargetException;
import com.sun.star.uno.UnoRuntime;
import com.sun.star.util.XNumberFormatsSupplier;
import com.sun.star.util.XNumberFormats;
import com.sun.star.util.MalformedNumberFormatException;
import com.sun.star.util.XCloseable;
import com.sun.star.util.CloseVetoException;
import com.sun.star.awt.XWindow;
import com.sun.star.frame.XDesktop;
import com.sun.star.frame.XFrame;
import com.sun.star.frame.XModel;
import com.sun.star.frame.FrameSearchFlag;
import com.sun.star.frame.XComponentLoader;
import com.sun.star.frame.XStorable2;
import com.sun.star.container.NoSuchElementException;
import com.sun.star.sheet.XSpreadsheetDocument;
import com.sun.star.sheet.XSpreadsheet;
import com.sun.star.sheet.XSpreadsheets;
import com.sun.star.sheet.XSpreadsheetView;
import com.sun.star.beans.PropertyValue;
import com.sun.star.beans.XPropertySet;
import com.sun.star.beans.UnknownPropertyException;
import com.sun.star.beans.PropertyVetoException;
import com.sun.star.text.XText;
import com.sun.star.text.XTextCursor;
import com.sun.star.table.XCell;
import com.sun.star.table.XCellRange;
import com.sun.star.table.CellContentType;
import thebiasplanet.coreutilities.messaging.Publisher;
import thebiasplanet.unoutilities.constantsgroups.*;
import thebiasplanet.unoutilities.serviceshandling.UnoServiceHandler;
import thebiasplanet.unoextensiontests.controllers.TestController;
import thebiasplanet.unoextensiontests.displayshandling.TestControlPanelFrame;
// # Add necessary classes and interfaces END

public class TestUnoComponent extends WeakBase implements XServiceInfo, XInitialization, XTest {
	private static final Set <String> c_serviceNamesSet = new HashSet <String> ();
	private static final Class c_thisClass = new Object () { }.getClass ().getEnclosingClass ();
	private XComponentContext i_componentContextInXComponentContext;
	// # Add member variables START
	String i_message;
	TestControlPanelFrame i_testControlPanelFrame;
	// # Add member variables END
	
	static {
		c_serviceNamesSet.add ("thebiasplanet.uno.testunoextension.TestUnoService");
	}
	
	public TestUnoComponent (XComponentContext a_componentContextInXComponentContext)
			throws IllegalArgumentException {
		i_componentContextInXComponentContext = a_componentContextInXComponentContext;
	}
	
	static void setThisClassToServicesProvider (Map <String, Map <Class <?>, Set <String>>> a_implementationClassNameToImplementationClassToServiceNamesMapMap) {
		a_implementationClassNameToImplementationClassToServiceNamesMapMap.put (c_thisClass.getName (), MapFactory. <Class <?>, Set <String>> createLinkedHashMap (c_thisClass, c_serviceNamesSet));
	}
	
	public final void initialize (java.lang.Object [] a_arguments)
			throws com.sun.star.uno.Exception {
		// # Write the initialization START
		if (a_arguments != null && a_arguments.length == 1) {
			if (a_arguments[0] instanceof String) {
				i_message = (String) a_arguments[0];
				if (i_message == null) {
					throw new IllegalArgumentException ("The first argument can't be null.");
				}
			}
			else {
				throw new IllegalArgumentException("The first argument must be a String instance.");
			}
		}
		else {
			throw new IllegalArgumentException("The number of arguments must be 1.");
		}
		Thread.currentThread ().setContextClassLoader (ClassLoader.getSystemClassLoader ());
		try {
			UIManager.setLookAndFeel ("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
		}
		catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException l_exception) {
			throw new com.sun.star.uno.Exception (l_exception.toString ());
		}
		// # Write the initialization END
	}
	
	// # Add methods of the implemented UNO interface START
	public String test1 (String a_name) throws IllegalArgumentException {
		XDesktop l_unoDesktopInXDesktop = null;
		try {
			l_unoDesktopInXDesktop = (XDesktop) UnoRuntime.queryInterface (XDesktop.class, i_componentContextInXComponentContext.getServiceManager ().createInstanceWithContext ("com.sun.star.frame.Desktop", i_componentContextInXComponentContext));
		}
		catch (com.sun.star.uno.Exception l_exception) {
			Publisher.show (l_exception.toString ());
		}
		
		// Gets the current spread sheets document START
		XSpreadsheetDocument l_currentSpreadSheetsDocumentInXSpreadsheetDocument = (XSpreadsheetDocument) UnoRuntime.queryInterface (XSpreadsheetDocument.class, l_unoDesktopInXDesktop.getCurrentComponent ());
		if (l_currentSpreadSheetsDocumentInXSpreadsheetDocument != null) {
			Publisher.show (l_currentSpreadSheetsDocumentInXSpreadsheetDocument.toString ());
		}
		else {
			Publisher.show ("No spread sheets document is current.");
			return "No spread sheets document is current.";
		}
		// Gets the current spread sheets document END
		
		// Opens and closes a spread sheets document file START
		XStorable2 l_currentSpreadSheetsDocumentInXStorable2 = (XStorable2) UnoRuntime.queryInterface (XStorable2.class, l_currentSpreadSheetsDocumentInXSpreadsheetDocument);
		String l_currentDocumentUrl = l_currentSpreadSheetsDocumentInXStorable2.getLocation ();
		String l_openedDocumentUrl = String.format ("%s%s", l_currentDocumentUrl.substring (0, l_currentDocumentUrl.lastIndexOf ("/") + 1), "TestSpreadSheetsDocument1.ods");
		XComponentLoader l_unoDesktopInXComponentLoader = (XComponentLoader) UnoRuntime.queryInterface (XComponentLoader.class, l_unoDesktopInXDesktop);
		PropertyValue [] l_loadPropertiesArray = new PropertyValue [2];
		PropertyValue l_loadProperty = null;
		l_loadProperty = new PropertyValue ();
		l_loadProperty.Name = "ReadOnly";
		l_loadProperty.Value = Boolean.valueOf (false);
		l_loadPropertiesArray [0] = l_loadProperty;
		l_loadProperty = new PropertyValue ();
		l_loadProperty.Name = "Hidden";
		l_loadProperty.Value = Boolean.valueOf (false);
		l_loadPropertiesArray [1] = l_loadProperty;
		XSpreadsheetDocument l_openedSpreadSheetsDocumentInXSpreadsheetDocument = null;
		try {
			l_openedSpreadSheetsDocumentInXSpreadsheetDocument = UnoRuntime.queryInterface (XSpreadsheetDocument.class, l_unoDesktopInXComponentLoader.loadComponentFromURL (l_openedDocumentUrl.replaceAll ("\\\\", "/"), "_blank", FrameSearchFlag.CREATE, l_loadPropertiesArray));
			Publisher.show (l_openedSpreadSheetsDocumentInXSpreadsheetDocument.toString ());
			XCloseable l_openedSpreadSheetsDocumentInXSpreadsheetDocumentInXCloseable = (XCloseable) UnoRuntime.queryInterface(XCloseable.class, l_openedSpreadSheetsDocumentInXSpreadsheetDocument);
			l_openedSpreadSheetsDocumentInXSpreadsheetDocumentInXCloseable.close (false); 
		}
		catch (com.sun.star.io.IOException | CloseVetoException l_exception) {
			Publisher.show (l_exception.toString ());
		}
		// Opens and closes a spread sheets document file END
		
		// Gets the current spread sheet START
		XModel l_currentSpreadSheetsDocumentModelInXModel = (XModel) UnoRuntime.queryInterface (XModel.class, l_currentSpreadSheetsDocumentInXSpreadsheetDocument);
		XSpreadsheetView  l_currentSpreadSheetsDocumentViewInXSpreadsheetView = (XSpreadsheetView) UnoRuntime.queryInterface (XSpreadsheetView.class, l_currentSpreadSheetsDocumentModelInXModel.getCurrentController ());
		XSpreadsheet l_currentSpreadSheetInXSpreadsheet  = l_currentSpreadSheetsDocumentViewInXSpreadsheetView.getActiveSheet ();
		Publisher.show (l_currentSpreadSheetInXSpreadsheet.toString ());
		// Gets the current spread sheet END
		
		// Gets another spread sheet START
		XSpreadsheets l_currentSpreadSheetsInXSpreadsheets = l_currentSpreadSheetsDocumentInXSpreadsheetDocument.getSheets ();
		XSpreadsheet l_anotherSpreadSheetInXSpreadsheet = null;
		try {
			l_anotherSpreadSheetInXSpreadsheet = (XSpreadsheet) UnoRuntime.queryInterface(XSpreadsheet.class, l_currentSpreadSheetsInXSpreadsheets.getByName ("Sheet2"));
			Publisher.show (l_anotherSpreadSheetInXSpreadsheet.toString ());
		}
		catch (NoSuchElementException | WrappedTargetException l_exception) {
			Publisher.show (l_exception.toString ());
		}
		// Gets another spread sheet END
		
		// Gets a spread sheet cell START
		XCell l_spreadSheetCellInXCell = null;
		try {
			l_spreadSheetCellInXCell = l_currentSpreadSheetInXSpreadsheet.getCellByPosition (2, 0);
			Publisher.show (l_spreadSheetCellInXCell.toString ());
		}
		catch (com.sun.star.lang.IndexOutOfBoundsException l_exception) {
			Publisher.show (l_exception.toString ());
		}
		// Gets a spread sheet cell END
		
		// Gets the current spread sheet cell START
		XCellRange l_currentCellsInXCellRange = (XCellRange) UnoRuntime.queryInterface (XCellRange.class, l_currentSpreadSheetsDocumentModelInXModel.getCurrentSelection ());
		XCell l_currentSpreadSheetCellInXCell = null;
		try {
			l_currentSpreadSheetCellInXCell = l_currentCellsInXCellRange.getCellByPosition (0, 0);
			Publisher.show (l_currentSpreadSheetCellInXCell.toString ());
		}
		catch (com.sun.star.lang.IndexOutOfBoundsException l_exception) {
			Publisher.show (l_exception.toString ());
		}
		// Gets the current spread sheet cell END
		
		try {
			// Gets the value of the current spread sheet cell START
			String l_dateExpressionFormatString = "YYYY-MM-DD";
			String l_timeExpressionFormatString = "HH:MM:SS";
			String l_dateTimeExpressionFormatString = "YYYY-MM-DD\"T\"HH:MM:SS";
			String l_booleanExpressionFormatString = "BOOLEAN";
			String l_stringExpressionFormatString = "@";
			String l_integerExpressionFormatString = "0";
			String l_doubleDefaultExpressionFormatString = "Global";
			Locale l_defaultLocale = new Locale ();
			XNumberFormatsSupplier l_currentSpreadSheetsDocumentInXNumberFormatsSupplier = UnoRuntime.queryInterface (XNumberFormatsSupplier.class, l_currentSpreadSheetsDocumentInXSpreadsheetDocument);
			XNumberFormats l_cellValueExpressionFormatsInXNumberFormats = l_currentSpreadSheetsDocumentInXNumberFormatsSupplier.getNumberFormats ();
			int l_dateExpressionFormatKey = -1;
			int l_timeExpressionFormatKey = -1;
			int l_dateTimeExpressionFormatKey = -1;
			int l_booleanExpressionFormatKey = -1;
			int l_stringExpressionFormatKey = -1;
			int l_integerExpressionFormatKey = -1;
			int l_doubleDefaultExpressionFormatKey = -1;
			l_dateExpressionFormatKey = l_cellValueExpressionFormatsInXNumberFormats.queryKey (l_dateExpressionFormatString, l_defaultLocale, false);
			if (l_dateExpressionFormatKey == -1) {
				l_dateExpressionFormatKey = l_cellValueExpressionFormatsInXNumberFormats.addNew (l_dateExpressionFormatString, l_defaultLocale);
			}
			l_timeExpressionFormatKey = l_cellValueExpressionFormatsInXNumberFormats.queryKey (l_timeExpressionFormatString, l_defaultLocale, false);
			if (l_timeExpressionFormatKey == -1) {
				l_timeExpressionFormatKey = l_cellValueExpressionFormatsInXNumberFormats.addNew (l_timeExpressionFormatString, l_defaultLocale);
			}
			l_dateTimeExpressionFormatKey = l_cellValueExpressionFormatsInXNumberFormats.queryKey (l_dateTimeExpressionFormatString, l_defaultLocale, false);
			if (l_dateTimeExpressionFormatKey == -1) {
				l_dateTimeExpressionFormatKey = l_cellValueExpressionFormatsInXNumberFormats.addNew (l_dateTimeExpressionFormatString, l_defaultLocale);
			}
			l_booleanExpressionFormatKey = l_cellValueExpressionFormatsInXNumberFormats.queryKey (l_booleanExpressionFormatString, l_defaultLocale, false);
			if (l_booleanExpressionFormatKey == -1) {
				l_booleanExpressionFormatKey = l_cellValueExpressionFormatsInXNumberFormats.addNew (l_booleanExpressionFormatString, l_defaultLocale);
			}
			l_stringExpressionFormatKey = l_cellValueExpressionFormatsInXNumberFormats.queryKey (l_stringExpressionFormatString, l_defaultLocale, false);
			if (l_stringExpressionFormatKey == -1) {
				l_stringExpressionFormatKey = l_cellValueExpressionFormatsInXNumberFormats.addNew (l_stringExpressionFormatString, l_defaultLocale);
			}
			l_integerExpressionFormatKey = l_cellValueExpressionFormatsInXNumberFormats.queryKey (l_integerExpressionFormatString, l_defaultLocale, false);
			if (l_integerExpressionFormatKey == -1) {
				l_integerExpressionFormatKey = l_cellValueExpressionFormatsInXNumberFormats.addNew (l_integerExpressionFormatString, l_defaultLocale);
			}
			l_doubleDefaultExpressionFormatKey = l_cellValueExpressionFormatsInXNumberFormats.queryKey (l_doubleDefaultExpressionFormatString, l_defaultLocale, false);
			if (l_doubleDefaultExpressionFormatKey == -1) {
				l_doubleDefaultExpressionFormatString = "Standard";
				l_doubleDefaultExpressionFormatKey = l_cellValueExpressionFormatsInXNumberFormats.queryKey (l_doubleDefaultExpressionFormatString, l_defaultLocale, false);
				if (l_doubleDefaultExpressionFormatKey == -1) {
					// If your locale setting has a different default decimal fraction format string, you should use it.
				}
			}
			CellContentType l_cellContentType = l_currentSpreadSheetCellInXCell.getType ();
			XPropertySet l_currentSpreadSheetCellInXPropertySet = (XPropertySet) UnoRuntime.queryInterface (XPropertySet.class, l_currentSpreadSheetCellInXCell);
			XText l_currentSpreadSheetCellInXText = (XText) UnoRuntime.queryInterface (XText.class, l_currentSpreadSheetCellInXCell);
			if (l_cellContentType == CellContentType.EMPTY) {
			}
			else {
				if (l_cellContentType == CellContentType.FORMULA) {
					Publisher.show (String.format ("Got a formula: %s", l_currentSpreadSheetCellInXCell.getFormula ()));
				}
				int l_cellValueExpressionFormatKey = ((Integer) l_currentSpreadSheetCellInXPropertySet.getPropertyValue ("NumberFormat")).intValue ();
				String l_cellValueExpression = l_currentSpreadSheetCellInXText.getString ();
				if (l_cellValueExpressionFormatKey == l_dateExpressionFormatKey) {
					LocalDate l_date = LocalDate.parse (l_cellValueExpression, DateTimeFormatter.ISO_LOCAL_DATE);
					Publisher.show (String.format ("Got a LocalDate: %s", l_date.toString ()));
				}
				else if (l_cellValueExpressionFormatKey == l_timeExpressionFormatKey) {
					LocalTime l_time = LocalTime.parse (l_cellValueExpression, DateTimeFormatter.ISO_LOCAL_TIME);
					Publisher.show (String.format ("Got a LocalTime: %s", l_time.toString ()));
				}
				else if (l_cellValueExpressionFormatKey == l_dateTimeExpressionFormatKey) {
					LocalDateTime l_dateTime = LocalDateTime.parse (l_cellValueExpression, DateTimeFormatter.ISO_LOCAL_DATE_TIME);
					Publisher.show (String.format ("Got a LocalDateTime: %s", l_dateTime.toString ()));
				}
				else if (l_cellValueExpressionFormatKey == l_booleanExpressionFormatKey) {
					Boolean l_boolean = Boolean.valueOf (l_cellValueExpression);
					Publisher.show (String.format ("Got a Boolean: %s", l_boolean.toString ()));
				}
				else if (l_cellValueExpressionFormatKey == l_stringExpressionFormatKey) {
					Publisher.show (String.format ("Got a String: %s", l_cellValueExpression));
				}
				
				else if (l_cellValueExpressionFormatKey == l_integerExpressionFormatKey) {
					Integer l_integer = Integer.valueOf (l_cellValueExpression.replaceAll (",", ""));
					Publisher.show (String.format ("Got an Integer: %s", l_integer.toString ()));
				}
				else {
					Matcher l_matcher = Pattern.compile ("^(\\d*|\\d{1,3}(,\\d{3})*)(\\.\\d+)?([eE][-+]?\\d+)?$").matcher (l_cellValueExpression);
					if (l_matcher.find ()) {
						BigDecimal l_bigDecimal = new BigDecimal (l_cellValueExpression.replaceAll (",", ""));
						Publisher.show (String.format ("Got a BigDecimal: %s", l_bigDecimal.toString ()));
					}
					else {
						Publisher.show (String.format ("Got a String: %s", l_cellValueExpression));
					}
				}
			}
			// Gets the value of the current spread sheet cell END
			
			// Sets the inputted value to the current spread sheet cell START
			String l_specifiedValue = JOptionPane.showInputDialog (null, "Specify a value in the format, '<datum type>: <value>'");
			String l_datumType = null;
			String l_valueExpression = null;
			if (l_specifiedValue != null) {
				int l_colonDelimiterPositionIndex = l_specifiedValue.indexOf (": ");
				if (l_colonDelimiterPositionIndex >= 0) {
					l_datumType = l_specifiedValue.substring (0, l_colonDelimiterPositionIndex);
					l_valueExpression = l_specifiedValue.substring (l_colonDelimiterPositionIndex + 2);
				}
				if (l_datumType != null) {
					switch (l_datumType) {
						case "Formula":
							l_currentSpreadSheetCellInXCell.setFormula (l_valueExpression);
							break;
						case "LocalDate":
							l_currentSpreadSheetCellInXPropertySet.setPropertyValue ("NumberFormat", new Integer (l_dateExpressionFormatKey));
							l_currentSpreadSheetCellInXCell.setFormula (l_valueExpression);
							break;
						case "LocalTime":
							l_currentSpreadSheetCellInXPropertySet.setPropertyValue ("NumberFormat", new Integer (l_timeExpressionFormatKey));
							l_currentSpreadSheetCellInXCell.setFormula (l_valueExpression);
							break;
						case "LocalDateTime":
							l_currentSpreadSheetCellInXPropertySet.setPropertyValue ("NumberFormat", new Integer (l_dateTimeExpressionFormatKey));
							l_currentSpreadSheetCellInXCell.setFormula (l_valueExpression);
							break;
						case "Boolean":
							l_currentSpreadSheetCellInXPropertySet.setPropertyValue ("NumberFormat", new Integer (l_booleanExpressionFormatKey));
							l_currentSpreadSheetCellInXCell.setFormula (l_valueExpression);
							break;
						case "String":
							l_currentSpreadSheetCellInXPropertySet.setPropertyValue ("NumberFormat", new Integer (l_stringExpressionFormatKey));
							l_currentSpreadSheetCellInXCell.setFormula ("");
							XTextCursor l_textCursorInXTextCursor = l_currentSpreadSheetCellInXText.createTextCursor();
							l_currentSpreadSheetCellInXText.insertString (l_textCursorInXTextCursor, l_valueExpression, true);
							break;
						case "Integer":
							Integer l_integer = new Integer (l_valueExpression);
							l_currentSpreadSheetCellInXPropertySet.setPropertyValue ("NumberFormat", new Integer (l_integerExpressionFormatKey));
							l_currentSpreadSheetCellInXCell.setValue (l_integer.intValue ());
							break;
						case "BigDecimal":
							BigDecimal l_bigDeciaml = new BigDecimal (l_valueExpression);
							int l_scale = l_bigDeciaml.scale ();
							if (l_scale > 0) {
								// Register and set the cell value expression format of a specific precision START
								String l_doubleOfSpecificPrecisionExpressionFormatString = String.format (String.format ("%%.%df", l_scale), 0.0);
								int l_doubleOfSpecificPrecisionExpressionFormatKey = l_cellValueExpressionFormatsInXNumberFormats.queryKey (l_doubleOfSpecificPrecisionExpressionFormatString, l_defaultLocale, false);
								if (l_doubleOfSpecificPrecisionExpressionFormatKey == -1) {
									l_doubleOfSpecificPrecisionExpressionFormatKey = l_cellValueExpressionFormatsInXNumberFormats.addNew (l_doubleOfSpecificPrecisionExpressionFormatString, l_defaultLocale);
								}
								// Register and set the cell value expression format of a specific precision END
								l_currentSpreadSheetCellInXPropertySet.setPropertyValue ("NumberFormat", new Integer (l_doubleOfSpecificPrecisionExpressionFormatKey));
								l_currentSpreadSheetCellInXCell.setValue (l_bigDeciaml.doubleValue ());
							}
							else {
								l_currentSpreadSheetCellInXPropertySet.setPropertyValue ("NumberFormat", new Integer (l_integerExpressionFormatKey));
								l_currentSpreadSheetCellInXCell.setValue (l_bigDeciaml.intValue ());
							}
							break;
						case "Double":
							Double l_double = new Double (l_valueExpression);
							l_currentSpreadSheetCellInXPropertySet.setPropertyValue ("NumberFormat", new Integer (l_doubleDefaultExpressionFormatKey));
							l_currentSpreadSheetCellInXCell.setValue (l_double.doubleValue ());
							break;
						default:
							Publisher.show ("That datum type isn't recognized.");
							break;
					}
				}
				else {
					Publisher.show ("Wrong format.");
				}
			}
			// Sets the inputted value to the current spread sheet cell END
			
			// Manipulates the string of a spread sheet cell START
			// Sets the spread sheet cell, 'H1', with a string value, '0123456789', as the preparation START
			try {
				l_spreadSheetCellInXCell = l_currentSpreadSheetInXSpreadsheet.getCellByPosition (7, 0);
			}
			catch (com.sun.star.lang.IndexOutOfBoundsException l_exception) {
				Publisher.show (l_exception.toString ());
			}
			XPropertySet l_spreadSheetCellInXPropertySet = (XPropertySet) UnoRuntime.queryInterface (XPropertySet.class, l_spreadSheetCellInXCell);
			l_spreadSheetCellInXPropertySet.setPropertyValue ("NumberFormat", new Integer (l_stringExpressionFormatKey));
			l_spreadSheetCellInXCell.setFormula ("");
			XText l_spreadSheetCellInXText = (XText) UnoRuntime.queryInterface (XText.class, l_spreadSheetCellInXCell);
			XTextCursor l_textCursorInXTextCursor = l_spreadSheetCellInXText.createTextCursor ();
			l_spreadSheetCellInXText.insertString (l_textCursorInXTextCursor, "0123456789", true);
			// Sets a spread sheet cell with a string value as the preparation END
			l_textCursorInXTextCursor = l_spreadSheetCellInXText.createTextCursorByRange (l_spreadSheetCellInXText.getEnd ());
			l_textCursorInXTextCursor.gotoStart (false);
			l_spreadSheetCellInXText.insertString (l_textCursorInXTextCursor, "A", true);
			l_textCursorInXTextCursor.goRight ( (short) 1,false);
			l_spreadSheetCellInXText.insertString (l_textCursorInXTextCursor, "B", true);
			l_textCursorInXTextCursor.goRight ( (short) 1, false);
			l_textCursorInXTextCursor.goRight ( (short) 1, true);
			l_spreadSheetCellInXText.insertString (l_textCursorInXTextCursor, "C", true);
			l_spreadSheetCellInXText.insertString (l_textCursorInXTextCursor, "D", true);
			l_textCursorInXTextCursor.gotoEnd (false);
			l_spreadSheetCellInXText.insertString (l_textCursorInXTextCursor, "E", true);
			l_textCursorInXTextCursor.goLeft ( (short) 2, false);
			l_spreadSheetCellInXText.insertString (l_textCursorInXTextCursor, "F", true);
			l_textCursorInXTextCursor.goLeft ( (short) 2, false);
			l_textCursorInXTextCursor.goLeft ( (short) 1, true);
			l_spreadSheetCellInXText.insertString (l_textCursorInXTextCursor, "G", true);
			l_textCursorInXTextCursor.goLeft ( (short) 2, false);
			l_textCursorInXTextCursor.goLeft ( (short) 1, true);
			l_spreadSheetCellInXText.insertString (l_textCursorInXTextCursor, "", true);
			// Manipulates the string of a spread sheet cell END
		}
		catch (MalformedNumberFormatException | UnknownPropertyException | WrappedTargetException | PropertyVetoException | RuntimeException l_exception) {
			Publisher.show (l_exception.toString ());
		}
		return a_name;
	}
	public void showTestControlPanel () {
		if (i_testControlPanelFrame == null) {
			TestController l_testController = new TestController (i_componentContextInXComponentContext);
			i_testControlPanelFrame = new TestControlPanelFrame ("Test Control Panel", l_testController);
			i_testControlPanelFrame.addWindowListener (
				new WindowAdapter () {
					public void windowClosing (WindowEvent p_event) {
						i_testControlPanelFrame = null;
					}
				}
			);
			try {
				XDesktop l_unoDesktopInXDesktop = (XDesktop) UnoServiceHandler.getServiceInstance (i_componentContextInXComponentContext, UnoServiceNamesConstantsGroup.c_com_sun_star_frame_Desktop, XDesktop.class);
				XFrame l_unoFrameInXFrame = l_unoDesktopInXDesktop.getCurrentFrame ();
				XWindow l_desktopContainerWindowInXWindow = l_unoFrameInXFrame.getContainerWindow ();
				com.sun.star.awt.Rectangle l_desktopContainerWindowBoundary = l_desktopContainerWindowInXWindow.getPosSize ();
				Rectangle l_applicationContainerWindowBoundary = new Rectangle (l_desktopContainerWindowBoundary.X, l_desktopContainerWindowBoundary.Y, l_desktopContainerWindowBoundary.Width, l_desktopContainerWindowBoundary.Height);
				i_testControlPanelFrame.setLocation (Math.max (l_applicationContainerWindowBoundary.x - i_testControlPanelFrame.getWidth (), 0), l_applicationContainerWindowBoundary.y);
			}
			catch (Exception l_exception) {
				Publisher.show (l_exception.toString ());
			}
			i_testControlPanelFrame.setVisible (true);
		}
		i_testControlPanelFrame.toFront ();
	}
	// # Add methods of the implemented UNO interface END
	
	// # Add other member methods START
	// # Add other member methods END
	
	@Override
	public String getImplementationName () {
		return c_thisClass.getName ();
	}
	
	@Override
	public final boolean supportsService (String a_serviceName) {
		return c_serviceNamesSet.contains (a_serviceName);
	}
	
	@Override
	public final String [] getSupportedServiceNames () {
		return ArrayFactory. <String>createArray (String.class, c_serviceNamesSet);
	}
}
