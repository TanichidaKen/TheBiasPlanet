package thebiasplanet.unoextensiontests.controllers;

import java.awt.Color;
import java.net.URL;
import com.sun.star.awt.EnhancedMouseEvent;
import com.sun.star.awt.KeyEvent;
import com.sun.star.awt.XEnhancedMouseClickHandler;
import com.sun.star.awt.XKeyHandler;
import com.sun.star.awt.XUserInputInterception;
import com.sun.star.beans.XPropertySet;
import com.sun.star.lang.EventObject;
import com.sun.star.sheet.XEnhancedMouseClickBroadcaster;
import com.sun.star.sheet.XSheetCellCursor;
import com.sun.star.sheet.XSheetCellRange;
import com.sun.star.sheet.XSpreadsheet;
import com.sun.star.sheet.XSpreadsheetView;
import com.sun.star.table.XCell;
import com.sun.star.uno.UnoRuntime;
import com.sun.star.uno.XComponentContext;
import thebiasplanet.coreutilities.constantsgroups.*;
import thebiasplanet.coreutilities.messaging.Publisher;
import thebiasplanet.unoutilities.displayshandling.SpreadSheetCellEditorFrame;
import thebiasplanet.unoutilities.documentshandling.spreadsheetsdocumentshandling.UnoSpreadSheet;
import thebiasplanet.unoutilities.documentshandling.spreadsheetsdocumentshandling.UnoSpreadSheetCell;
import thebiasplanet.unoutilities.documentshandling.spreadsheetsdocumentshandling.UnoSpreadSheetsDocument;

public class TestController implements XEnhancedMouseClickHandler, XKeyHandler {
	private XComponentContext i_componentContextInXComponentContext;
	private String i_openedDocumentDirectoryPath;
	
	public TestController (XComponentContext a_componentContextInXComponentContext) {
		i_componentContextInXComponentContext = a_componentContextInXComponentContext;
	}
	
	public void showCellEditor (int a_frameWidth, int a_frameHeight, int a_leftPosition, int a_topPosition) throws Exception {
		UnoSpreadSheetCell l_currentUnoSpreadSheetCell = UnoSpreadSheetCell.getCurrentCell (i_componentContextInXComponentContext);
		SpreadSheetCellEditorFrame l_spreadSheetCellEditorFrame = new SpreadSheetCellEditorFrame (a_frameWidth, a_frameHeight, -1, "Liberation Mono", 18, i_componentContextInXComponentContext, l_currentUnoSpreadSheetCell, false);
		if (a_leftPosition != -1 && a_topPosition != -1) {
			l_spreadSheetCellEditorFrame.setLocation (a_leftPosition, a_topPosition);
		}
		l_spreadSheetCellEditorFrame.setVisible (true);
		l_spreadSheetCellEditorFrame.toFront ();
	}
	
	public void handleMergedCells () {
		try {
			UnoSpreadSheet l_currentSpreadSheet = UnoSpreadSheet.getCurrentSpreadSheet (i_componentContextInXComponentContext);
			XSpreadsheet l_currentSpreadSheetInXSpreadsheet = l_currentSpreadSheet.getSpreadSheetInXSpreadsheet ();
			XCell l_topLeftmostSpreadSheetCellInXCell = l_currentSpreadSheetInXSpreadsheet.getCellByPosition (1, 7);
			l_topLeftmostSpreadSheetCellInXCell.setValue (1);
			
			// Handling the top leftmost spread sheet cell. BEGINNING
			XPropertySet l_topLeftmostSpreadSheetCellInXPropertySet = (XPropertySet) UnoRuntime.queryInterface (XPropertySet.class, l_topLeftmostSpreadSheetCellInXCell);
			l_topLeftmostSpreadSheetCellInXPropertySet.setPropertyValue ("CellBackColor", Integer.valueOf ( (new Color (0, 255, 0)).getRGB ()));
			l_topLeftmostSpreadSheetCellInXPropertySet.setPropertyValue ("IsCellBackgroundTransparent", Boolean.valueOf (false));
			Publisher.show ("The top leftmost spread sheet cell has been handled.");
			// Handling the top leftmost spread sheet cell. END
			
			// Handling the bottom rightmost spread sheet cell. BEGINNING
			XCell l_bottomRightmostSpreadSheetCellInXCell = l_currentSpreadSheetInXSpreadsheet.getCellByPosition (2, 8);
			l_bottomRightmostSpreadSheetCellInXCell.setValue (4);
			XPropertySet l_bottomRightmostSpreadSheetCellInXPropertySet = (XPropertySet) UnoRuntime.queryInterface (XPropertySet.class, l_bottomRightmostSpreadSheetCellInXCell);
			l_bottomRightmostSpreadSheetCellInXPropertySet.setPropertyValue ("CellBackColor", Integer.valueOf ( (new Color (0, 0, 255)).getRGB ()));
			l_bottomRightmostSpreadSheetCellInXPropertySet.setPropertyValue ("IsCellBackgroundTransparent", Boolean.valueOf (false));
			Publisher.show ("The bottom rightmost spread sheet cell has been handled.");
			// Handling the bottom rightmost spread sheet cell. END
			
			// Handling merged spread sheet cells range. BEGINNING
			XSheetCellCursor l_spreadSheetCellsRangeCursor = l_currentSpreadSheetInXSpreadsheet.createCursorByRange ( (XSheetCellRange) UnoRuntime.queryInterface (XSheetCellRange.class, l_topLeftmostSpreadSheetCellInXCell));
			l_spreadSheetCellsRangeCursor.collapseToMergedArea ();
			XPropertySet l_mergedSpreadSheetCellsRangeInXPropertySet = (XPropertySet) UnoRuntime.queryInterface (XPropertySet.class, l_spreadSheetCellsRangeCursor);
			l_mergedSpreadSheetCellsRangeInXPropertySet.setPropertyValue ("CellBackColor", Integer.valueOf ( (new Color (0, 255, 0)).getRGB ()));
			l_mergedSpreadSheetCellsRangeInXPropertySet.setPropertyValue ("IsCellBackgroundTransparent", Boolean.valueOf (false));
			Publisher.show ("The merged spread sheet cells range has been handled.");
			// Handling merged spread sheet cells range. END
		}
		catch (Exception l_exception) {
			Publisher.show (l_exception.toString ());
		}
	}
	
	public void setEventsListeners () throws Exception {
		UnoSpreadSheet l_currentSpreadSheet = UnoSpreadSheet.getCurrentSpreadSheet (i_componentContextInXComponentContext);
		if (l_currentSpreadSheet != null) {
			UnoSpreadSheetsDocument l_currentSpreadSheetsDocument = l_currentSpreadSheet.getSpreadSheetsDocument ();
			XSpreadsheetView l_controllerInXSpreadsheetView = l_currentSpreadSheetsDocument.getControllerInXSpreadsheetView ();
			XEnhancedMouseClickBroadcaster l_controllerInXEnhancedMouseClickBroadcaster = (XEnhancedMouseClickBroadcaster) UnoRuntime.queryInterface (XEnhancedMouseClickBroadcaster.class, l_controllerInXSpreadsheetView);
			l_controllerInXEnhancedMouseClickBroadcaster.addEnhancedMouseClickHandler (this);
			XUserInputInterception l_controllerInXUserInputInterception = (XUserInputInterception) UnoRuntime.queryInterface (XUserInputInterception.class, l_controllerInXSpreadsheetView);
			l_controllerInXUserInputInterception.addKeyHandler (this);
			String l_openedDocumentFilePath = (new URL (l_currentSpreadSheetsDocument.getLocationUrl ())).getFile ();
			i_openedDocumentDirectoryPath = l_openedDocumentFilePath.substring (0, l_openedDocumentFilePath.lastIndexOf ("/"));
		}
	}
	
	private String getCellAbsoluteName (XCell a_cellInXCell) {
		XPropertySet l_cellInXPropertySet = (XPropertySet) UnoRuntime.queryInterface (XPropertySet.class, a_cellInXCell);
		try {
			return (String) l_cellInXPropertySet.getPropertyValue ("AbsoluteName");
		}
		catch (Exception l_exception) {
			// This will never happen.
			return null;
		}
	}
	
	@Override
	public void disposing (EventObject a_event) {
	}
	
	@Override
	public boolean mousePressed (EnhancedMouseEvent a_enhancedMouseEvent) {
		XCell l_mousePressedCellInXCell = (XCell) UnoRuntime.queryInterface (XCell.class, a_enhancedMouseEvent.Target);
		if (l_mousePressedCellInXCell != null) {
			Publisher.appendToFile ( String.format ("%s/%s", i_openedDocumentDirectoryPath, "UnoMouseEvents.txt"), String.format ("MousePressed: on %s, buttons = %d, modifiers = %d, count = %d", getCellAbsoluteName (l_mousePressedCellInXCell), a_enhancedMouseEvent.Buttons, a_enhancedMouseEvent.Modifiers, a_enhancedMouseEvent.ClickCount));
		}
		return true;
	}
	
	@Override
	public boolean  mouseReleased (EnhancedMouseEvent a_enhancedMouseEvent) {
		XCell l_mouseReleasedCellInXCell = (XCell) UnoRuntime.queryInterface (XCell.class, a_enhancedMouseEvent.Target);
		if (l_mouseReleasedCellInXCell != null) {
			Publisher.appendToFile ( String.format ("%s/%s", i_openedDocumentDirectoryPath, "UnoMouseEvents.txt"), String.format ("MouseReleased: on %s, buttons = %d, modifiers = %d, count = %d", getCellAbsoluteName (l_mouseReleasedCellInXCell), a_enhancedMouseEvent.Buttons, a_enhancedMouseEvent.Modifiers, a_enhancedMouseEvent.ClickCount));
		}
		return true;
	}
	
	@Override
	public boolean keyPressed (KeyEvent a_keyEvent) {
		Publisher.appendToFile (String.format ("%s/%s", i_openedDocumentDirectoryPath, "UnoKeyEvents.txt"), String.format ("KeyPressed: code = %d, modifiers = %d", a_keyEvent.KeyCode, a_keyEvent.Modifiers));
		return false;
	}
	
	@Override
	public boolean keyReleased (KeyEvent a_keyEvent) {
		Publisher.appendToFile (String.format ("%s/%s", i_openedDocumentDirectoryPath, "UnoKeyEvents.txt"), String.format ("KeyReleased: code = %d, modifiers = %d", a_keyEvent.KeyCode, a_keyEvent.Modifiers));
		return false;
	}
}
