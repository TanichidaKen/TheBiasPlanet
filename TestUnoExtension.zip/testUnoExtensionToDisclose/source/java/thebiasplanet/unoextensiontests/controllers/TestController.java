package thebiasplanet.unoextensiontests.controllers;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JFrame;
import com.sun.star.uno.XComponentContext;

public class TestController {
	private XComponentContext i_componentContextInXComponentContext;
	JFrame i_dummyCellEditorFrame;
	
	public TestController (XComponentContext a_componentContextInXComponentContext) {
		i_componentContextInXComponentContext = a_componentContextInXComponentContext;
	}
	
	public void showCellEditor (int a_frameWidth, int a_frameHeight, int a_leftPosition, int a_topPosition)
			throws Exception {
		// dummy code START
		if (i_dummyCellEditorFrame != null) {
		}
		else {
			i_dummyCellEditorFrame = new JFrame ("Dummy");
			i_dummyCellEditorFrame.addWindowListener (
				new WindowAdapter () {
					public void windowClosing (WindowEvent p_event) {
						i_dummyCellEditorFrame = null;
					}
				}
			);
			i_dummyCellEditorFrame.setSize (a_frameWidth, a_frameHeight);
			if (a_leftPosition != -1 && a_topPosition != -1) {
				i_dummyCellEditorFrame.setLocation (a_leftPosition, a_topPosition);
			}
			i_dummyCellEditorFrame.setVisible (true);
		}
		i_dummyCellEditorFrame.toFront ();
		// dummy code END
	}
}
