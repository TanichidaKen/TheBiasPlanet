package thebiasplanet.unoextensiontests.controllers;

import com.sun.star.uno.XComponentContext;
import thebiasplanet.unoutilities.displayshandling.SpreadSheetCellEditorFrame;
import thebiasplanet.unoutilities.documentshandling.spreadsheetsdocumentshandling.UnoSpreadSheetCell;

public class TestController {
	private XComponentContext i_componentContextInXComponentContext;
	
	public TestController (XComponentContext a_componentContextInXComponentContext) {
		i_componentContextInXComponentContext = a_componentContextInXComponentContext;
	}
	
	public void showCellEditor (int a_frameWidth, int a_frameHeight, int a_leftPosition, int a_topPosition) throws Exception {
		UnoSpreadSheetCell l_currentUnoSpreadSheetCell = UnoSpreadSheetCell.getCurrentCell (i_componentContextInXComponentContext);
		SpreadSheetCellEditorFrame l_spreadSheetCellEditorFrame = new SpreadSheetCellEditorFrame (a_frameWidth, a_frameHeight, -1, "Liberation Mono", 18, i_componentContextInXComponentContext, l_currentUnoSpreadSheetCell, false);
		if (a_leftPosition != -1 && a_topPosition != -1) {
			l_spreadSheetCellEditorFrame.setLocation (a_leftPosition, a_topPosition);
		}
		l_spreadSheetCellEditorFrame.setVisible (true);
		l_spreadSheetCellEditorFrame.toFront ();
	}
}
