package thebiasplanet.unoextensiontests.displayshandling;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Cursor;
import java.awt.Toolkit;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.GroupLayout;
import thebiasplanet.coreutilities.messaging.Publisher;
import thebiasplanet.coreutilities.displayshandling.SwingComponentsFactory;
import thebiasplanet.unoextensiontests.controllers.TestController;

public class TestControlPanelFrame extends JFrame {
	private static String c_frameFontName = "Liberation Mono";
	private static int c_frameFontSize = 12;
	private static int c_defaultFrameWidth = 105;
	private static int c_defaultFrameHeight = 130;
	private static int c_testButtonsPanelHeight = 45;
	private JPanel i_testButtonsPanel = null;
	private JLabel i_testButtonsPanelLabel = null;
	private JButton i_editCurrentCellButton = null;
	private JButton i_handleMergedCellsButton = null;
	private JButton i_setEventsListenersButton = null;
	private TestController i_testController = null;
	
	public TestControlPanelFrame (String a_frameTitle, TestController a_testController) {
		super (a_frameTitle);
		Font l_font = new Font (c_frameFontName, Font.PLAIN, c_frameFontSize);
		setFont (l_font);
		i_testController = a_testController;
		setSize (c_defaultFrameWidth, c_defaultFrameHeight);
		setResizable (false);
		// content pane
		Container l_contentPane = getContentPane ();
		GroupLayout l_contentPaneLayout = new GroupLayout (l_contentPane);
		l_contentPaneLayout.setAutoCreateGaps (true);
		l_contentPaneLayout.setAutoCreateContainerGaps (true);
		l_contentPane.setLayout (l_contentPaneLayout);
		i_testButtonsPanel = new JPanel () {
			@Override
			public Dimension getPreferredSize () {
				Dimension l_prefferedSize = super.getPreferredSize ();
				l_prefferedSize.setSize (l_prefferedSize.getWidth(), c_testButtonsPanelHeight);
				return l_prefferedSize;
			}
		};
		l_contentPaneLayout.setHorizontalGroup (l_contentPaneLayout.createParallelGroup (GroupLayout.Alignment.LEADING).addComponent (i_testButtonsPanel));
		l_contentPaneLayout.setVerticalGroup (l_contentPaneLayout.createSequentialGroup ().addComponent (i_testButtonsPanel));
		// test buttons panel
		GroupLayout l_testButtonsPanelLayout = new GroupLayout (i_testButtonsPanel);
		i_testButtonsPanel.setLayout (l_testButtonsPanelLayout);
		GroupLayout.Group l_horizontalGroup = l_testButtonsPanelLayout.createParallelGroup (GroupLayout.Alignment.CENTER);
		GroupLayout.Group l_verticalGroup = l_testButtonsPanelLayout.createSequentialGroup ();
		i_testButtonsPanelLabel = new JLabel ("Test Buttons");
		i_testButtonsPanelLabel.setFont (l_font);
		l_horizontalGroup.addComponent (i_testButtonsPanelLabel).addGap (10);
		l_verticalGroup.addComponent (i_testButtonsPanelLabel);
		SwingComponentsFactory.setFont (l_font);
		SwingComponentsFactory.setCaptionLength (9);
		i_editCurrentCellButton = createButton ("Edit the Current Cell", KeyEvent.VK_E, l_horizontalGroup, l_verticalGroup,
			(a_event) -> {
				editCurrentCellButtonActionPerformed (a_event);
			}
		);
		i_handleMergedCellsButton  = createButton ("Handle Merged Cells", KeyEvent.VK_H, l_horizontalGroup, l_verticalGroup,
			(a_event) -> {
				setHandleMergedCellsButtonActionPerformed (a_event);
			}
		);
		i_setEventsListenersButton = createButton ("Set the Events Listeners", KeyEvent.VK_S, l_horizontalGroup, l_verticalGroup,
			(a_event) -> {
				setEventsListenersButtonActionPerformed (a_event);
			}
		);
		l_testButtonsPanelLayout.setHorizontalGroup (l_horizontalGroup);
		l_testButtonsPanelLayout.setVerticalGroup (l_verticalGroup);
	}
	
	private JButton createButton (String a_toolTipText, int a_shorcutKey, GroupLayout.Group a_horizontalGroup, GroupLayout.Group a_verticalGroup, ActionListener a_actionListener) {
		JButton l_createdButton = SwingComponentsFactory.createButton (a_toolTipText, a_shorcutKey, a_actionListener);
		a_horizontalGroup.addComponent (l_createdButton);
		a_verticalGroup.addComponent (l_createdButton);
		return l_createdButton;
	}
	
	private void editCurrentCellButtonActionPerformed (ActionEvent a_event) {
		try {
			setCursor (Cursor.getPredefinedCursor (Cursor.WAIT_CURSOR));
			Rectangle l_frameBound = getBounds ();
			Dimension l_screenDimension = Toolkit.getDefaultToolkit ().getScreenSize ();
			i_testController.showCellEditor (800 , l_screenDimension.height - l_frameBound.y - 30, Math.max (l_frameBound.x - 800, 0), l_frameBound.y);
		}
		catch (Exception l_exception) {
			Publisher.show (Publisher.logErrorInformation (l_exception));
		}
		finally {
			setCursor (Cursor.getDefaultCursor ());
		}
	}
	
	private void setHandleMergedCellsButtonActionPerformed (ActionEvent a_event) {
		try {
			setCursor (Cursor.getPredefinedCursor (Cursor.WAIT_CURSOR));
			i_testController.handleMergedCells ();
		}
		catch (Exception l_exception) {
			Publisher.show (Publisher.logErrorInformation (l_exception));
		}
		finally {
			setCursor (Cursor.getDefaultCursor ());
		}
	}
	
	private void setEventsListenersButtonActionPerformed (ActionEvent a_event) {
		try {
			setCursor (Cursor.getPredefinedCursor (Cursor.WAIT_CURSOR));
			i_testController.setEventsListeners ();
		}
		catch (Exception l_exception) {
			Publisher.show (Publisher.logErrorInformation (l_exception));
		}
		finally {
			setCursor (Cursor.getDefaultCursor ());
		}
	}
}

