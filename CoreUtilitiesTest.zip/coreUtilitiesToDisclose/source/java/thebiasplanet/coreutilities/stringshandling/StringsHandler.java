package thebiasplanet.coreutilities.stringshandling;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.math.BigDecimal;
import thebiasplanet.coreutilities.constantsgroups.*;

public class StringsHandler {
	static private final int c_minimumCaptionLength;
	
	static {
		c_minimumCaptionLength = 4;
	}
	
	public static Object getObject (String a_string, Class a_objectClass) {
		try {
			if (a_objectClass == LocalDate.class) {
				LocalDate l_date = LocalDate.parse (a_string, DateTimeFormatter.ISO_LOCAL_DATE);
				return l_date;
			}
			else if (a_objectClass == LocalTime.class) {
				LocalTime l_time = LocalTime.parse (a_string, DateTimeFormatter.ISO_LOCAL_TIME);
				return l_time;
			}
			else if (a_objectClass == LocalDateTime.class) {
				LocalDateTime l_dateTime = LocalDateTime.parse (a_string, DateTimeFormatter.ISO_LOCAL_DATE_TIME);
				return l_dateTime;
			}
			else if (a_objectClass == Boolean.class) {
				Boolean l_boolean = Boolean.valueOf (a_string);
				return l_boolean;
			}
			else if (a_objectClass == Integer.class) {
				return Integer.valueOf (a_string);
			}
			else if (a_objectClass == BigDecimal.class) {
				return new BigDecimal (a_string);
			}
			else if (a_objectClass == Double.class) {
				return Double.valueOf (a_string);
			}
			else if (a_objectClass == String.class) {
				return a_string;
			}
			else {
				return a_string;
			}
		}
		catch (Exception l_exception) {
			return a_string;
		}
	}
	
	public static String getString (Object a_object) {
		String l_string = null;
		if (a_object == null || a_object instanceof String) {
			l_string = (String) a_object;
		}
		else if (a_object instanceof Integer) {
			l_string = String.format (LiteralExpressionsConstantsGroup.c_integerDefaultFormat, a_object);
		}
		else if (a_object instanceof BigDecimal) {
			l_string = ((BigDecimal) a_object).toPlainString ();
		}
		else if (a_object instanceof Double) {
			l_string = String.format (LiteralExpressionsConstantsGroup.c_doubleDefaultFormat, a_object);
		}
		else if (a_object instanceof Boolean) {
			l_string = String.format (LiteralExpressionsConstantsGroup.c_booleanDefaultFormat, a_object);
		}
		else if (a_object instanceof LocalDate) {
			LocalDate l_date = (LocalDate) a_object;
			l_string = l_date.format (DateTimeFormatter.ISO_LOCAL_DATE);
		}
		else if (a_object instanceof LocalTime) {
			LocalTime l_time = (LocalTime) a_object;
			l_string = l_time.format (DateTimeFormatter.ISO_LOCAL_TIME);
		}
		else if (a_object instanceof LocalDateTime) {
			LocalDateTime l_dateTime = (LocalDateTime) a_object;
			l_string = l_dateTime.format (DateTimeFormatter.ISO_LOCAL_DATE_TIME);
		}
		else {
			l_string = a_object.toString ();
		}
		 return l_string;
	}
	
	// a_captionLength has to be larger than or equal to c_minimumCaptionLength
	public static String getCaptionString (String a_sourceString, int a_captionLength) {
		if (a_sourceString == null) {
			return null;
		}
		else {
			if (a_captionLength < c_minimumCaptionLength) {
				a_captionLength = c_minimumCaptionLength;
			}
			int l_lackingLength = a_captionLength - a_sourceString.length ();
			if (l_lackingLength == 0) {
				return a_sourceString;
			}
			else if (l_lackingLength > 0) {
				return String.format (String.format (UserInterfaceComponentCaptionsConstantsGroup.c_generalFullFormat, l_lackingLength), a_sourceString, " ");
			}
			else {
				return String.format (UserInterfaceComponentCaptionsConstantsGroup.c_generalAbrreviatedFormat, a_sourceString.substring (GeneralConstantsConstantsGroup.c_iterationStartingNumber, a_captionLength - c_minimumCaptionLength + 1));
			}
		}
	}
}
