package thebiasplanet.coreutilities.constantsgroups;

public interface UserInterfaceComponentToolTipsConstantsGroup {
	String c_caseSensitive = "Case Sensitive";
	String c_fromTop = "From the Top";
	String c_search = "Search";
	String c_replace = "Replace";
	String c_goToTop = "Go to the Top";
	String c_goToBottom = "Go to the Bottom";
	String c_save = "Save";
	String c_saveCompressed = "Save Compressed";
	String c_close = "Close";
	String c_goUP = "Go Up";
	String c_goDown = "Go Down";
	String c_goLeft = "Go Left";
	String c_goRight = "Go Right";
	String c_autoReconnect = "Auto Reconnect";
	String c_reconnect = "Reconnect";
	String c_setSelectedOrWholeContents = "Set the Selected or the Whole Contents to the Current Cell";
	String c_searchPhrase = "Search Phrase";
	String c_replacePhrase = "Replace Phrase";
}
