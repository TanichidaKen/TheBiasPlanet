package thebiasplanet.coreutilities.constantsgroups;

public interface GeneralConstantsConstantsGroup {
	int c_numberOfAlphabets = 26;
	int c_anyUnspecifiedInteger = -1;
	int c_iterationStartingNumber = 0;
	int c_normalResult = 0;
	String c_emptySpace = "";
	char c_radixPointCharacter = '.';
	char c_thousandSeparator = ',';
}
