package thebiasplanet.coreutilities.displayshandling;

import javax.swing.JTextPane;
import javax.swing.text.StyledDocument;

public class ExtendedJTextPane extends JTextPane {
	public ExtendedJTextPane () {
		super ();
		initialize ();
	}
	
	public ExtendedJTextPane (StyledDocument a_styledDocument) {
		super (a_styledDocument);
		initialize ();
	}
	
	private void initialize () {
		setEditorKit (new LinesWrappedEditorPaneStyledEditorKit ());
		PopUpMenuInjector.injectEditorPopUpMenu (this);
	}
}
