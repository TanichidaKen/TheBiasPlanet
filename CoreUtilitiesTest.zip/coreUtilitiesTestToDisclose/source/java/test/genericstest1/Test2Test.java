package test.genericstest1;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Test2Test {
	private Test2Test () {
	}
	
	public static void main (String [] p_arguments) throws Exception {
		Test2Test.test ();
	}
	
	public static void test () {
		Map <String, Object> l_map = new HashMap <String, Object> ();
		Test2Test.buildMap (l_map, 5);
		System.out.println (l_map);
		Map <String, Map <String, Map <String, Map <String, List <String>>>>> l_mapInDesiredType = (Map <String, Map <String, Map <String, Map <String, List <String>>>>>) (Map) l_map;
		System.out.println (l_mapInDesiredType);
	}
	
	public static void buildMap (Map <String, Object> a_mapToBeBuilt, int a_remainingDepth) {
		String  l_key = String.format ("key%d", a_remainingDepth - 1);
		Object l_value = null;
		if (a_remainingDepth <= 1) {
			// The depth has to be at least 2 to build a map of this type
			return;
		}
		else {
			if (a_remainingDepth == 2) {
				List <String> l_childMap1 = new ArrayList <String> ();
				l_childMap1.add ("value1");
				l_childMap1.add ("value2");
				l_value = l_childMap1;
			}
			else {
				Map <String, Object> l_childMap2 = new HashMap <String, Object> ();
				Test2Test.buildMap (l_childMap2, a_remainingDepth - 1);
				l_value = l_childMap2;
			}
		}
		a_mapToBeBuilt.put (l_key, l_value);
	}
}
