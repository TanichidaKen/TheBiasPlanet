package test.genericstest1;

import java.util.ArrayList;
import java.util.List;

public class AGenericClass <T> {
	T i_t;
	List <T> i_listOfTs;
	List <String> i_listOfStrings;
	
	public AGenericClass () {
	}
	
	public <U> U aGenericMethod (U a_argument) {
		Object l_objectAsString = "string1";
		Object l_objectAsListOfStrings = new ArrayList <String> ();
		i_t = (T) l_objectAsString;
		i_listOfTs = (List <T>) l_objectAsListOfStrings ;
		i_listOfStrings = (List <String>) l_objectAsListOfStrings;
		
		i_t = (T) a_argument;
		
		System.out.println (i_t);
		Object l_objectAsListOfTs = new ArrayList <T> ();
		i_listOfTs = (List <T>) l_objectAsListOfTs;
		i_listOfTs.add (i_t);
		i_listOfStrings = (List <String>) l_objectAsListOfTs;
		System.out.println (i_listOfTs);
		//List <Integer> [] l_listOfIntegersArray = new List <Integer> [2];
		List <Integer> [] l_listOfIntegersArray = new List [2];
		l_listOfIntegersArray [0] = new ArrayList <Integer> ();
		//l_listOfIntegersArray [1] = new ArrayList <String> ();
		T [] l_tsArray = (T []) new Object [1];
		l_tsArray [0] = (T) "string3";
		return a_argument;
	}
}
