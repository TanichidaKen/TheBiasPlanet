package test.genericstest1;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Test3Test {
	private Test3Test () {
	}
	
	public static void main (String [] p_arguments) throws Exception {
		Test3Test.test ();
	}
	
	public static void test () {
		Map <String, Map <String, Map <String, Map <String, List <String>>>>> l_map = new HashMap <String, Map <String, Map <String, Map <String, List <String>>>>> ();
		Test3Test. <Map <String, Map <String, List <String>>>>buildMap (l_map, 5);
		System.out.println (l_map);
	}
	
	@SuppressWarnings("unchecked")
	public static <U> void buildMap (Map <String, Map <String, U>> a_mapToBeBuilt, int a_remainingDepth) {
		String  l_key = String.format ("key%d", a_remainingDepth - 1);
		Map <String, U> l_value = null;
		if (a_remainingDepth <= 2) {
			// The depth has to be at least 3 to build a map of this type
			return;
		}
		else {
			if (a_remainingDepth == 3) {
				Map <String, U> l_childMap1 = new HashMap <String, U> ();
				String l_childKey = String.format ("key%d", 1);
				List <String> l_grandchildList = new ArrayList <String> ();
				l_grandchildList.add ("value1");
				l_grandchildList.add ("value2");
				l_childMap1.put (l_childKey, (U) l_grandchildList);
				l_value = l_childMap1;
			}
			else {
				/* ??? How can I get 'U' for the next iteration?
				Map <String, Map <String, ?>> l_childMap2 = new HashMap <String, Map <String, ?>> ();
				Test3Test. <?>buildMap (l_childMap2, a_remainingDepth - 1);
				l_value = (Map <String, U>) l_childMap2;
				*/
				Map <String, Map <String, Object>> l_childMap2 = new HashMap <String, Map <String, Object>> ();
				Test3Test. <Object>buildMap (l_childMap2, a_remainingDepth - 1);
				l_value = (Map <String, U>) l_childMap2;
			}
		}
		a_mapToBeBuilt.put (l_key, l_value);
	}
}
