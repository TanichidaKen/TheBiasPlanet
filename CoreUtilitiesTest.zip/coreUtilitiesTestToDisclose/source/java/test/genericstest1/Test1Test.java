package test.genericstest1;

public class Test1Test {
	private Test1Test () {
	}
	
	public static void main (String [] p_arguments) throws Exception {
		Test1Test.test ();
	}
	
	public static void test () {
		AGenericClass <String> l_aGenericClass = new AGenericClass <String> ();
		l_aGenericClass. <String>aGenericMethod ("test string");
		l_aGenericClass. <Integer>aGenericMethod (Integer.valueOf (2));
	}
	
}
