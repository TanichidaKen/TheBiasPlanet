package test.enumerableconstantsgrouptest1;

import java.util.ArrayList;
import java.util.LinkedHashSet;

public class Test1Test {
	public static void test () {
		LinkedHashSet <String> l_names = Test1EnumerableExtendedConstantsGroup12.c_instance.getNames ();
		ArrayList <String> l_values = Test1EnumerableExtendedConstantsGroup12.c_instance.getValues ();
		for (String l_name: l_names) {
			System.out.println (l_name);
		}
		for (String l_value: l_values) {
			System.out.println (l_value);
		}
	}
}
