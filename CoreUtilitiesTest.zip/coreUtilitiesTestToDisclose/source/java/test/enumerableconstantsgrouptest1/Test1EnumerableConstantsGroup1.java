package test.enumerableconstantsgrouptest1;

import thebiasplanet.coreutilities.constantsgroups.BaseEnumerableConstantsGroup;

public final class Test1EnumerableConstantsGroup1 extends BaseEnumerableConstantsGroup <String> implements Test1ConstantsGroup1 {
	public static final Test1EnumerableConstantsGroup1 c_instance = new Test1EnumerableConstantsGroup1 ();
	
	private Test1EnumerableConstantsGroup1 () {
	}
}
