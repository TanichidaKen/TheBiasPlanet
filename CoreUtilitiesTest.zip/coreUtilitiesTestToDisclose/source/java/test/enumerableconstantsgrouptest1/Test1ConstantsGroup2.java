package test.enumerableconstantsgrouptest1;

public interface Test1ConstantsGroup2 {
	String c_value3 = "Value3";
	String c_value4 = "Value4";
}
