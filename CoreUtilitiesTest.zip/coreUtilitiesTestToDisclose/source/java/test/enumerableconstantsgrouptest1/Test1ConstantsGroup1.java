package test.enumerableconstantsgrouptest1;

public interface Test1ConstantsGroup1 {
	String c_value1 = "Value1";
	String c_value2 = "Value2";
}
