package test.navigablelinkedhashmaptest1;

import java.util.Map;
import thebiasplanet.coreutilities.collections.NavigableLinkedHashMap;

public class Test1Test {
	private Test1Test () {
	}
	
	public static void main (String [] p_arguments) throws Exception {
		int l_numberOfElements = 10000;
		int l_mode = 0;
		if (p_arguments.length > 0) {
			l_numberOfElements = Integer.valueOf (p_arguments [0]);
		}
		if (p_arguments.length > 1) {
			l_mode = Integer.valueOf (p_arguments [1]);
		}
		Test1Test.test (l_numberOfElements, l_mode);
	}
	
	// a_mode: 0 -> without dummy processing, 1 -> with dummy processing, 2 -> show some intermediate results without dummy processing
	public static void test (int a_numberOfElements, int a_mode) {
		long l_nanoTimeForInsertionStart = -1;
		long l_nanoTimeForInsertionStop = -1;
		long l_nanoTimeForInsertionAccumulation = 0;
		long l_nanoTimeForSearchStart = -1;
		long l_nanoTimeForSearchStop = -1;
		long l_nanoTimeForIterationStart = -1;
		long l_nanoTimeForIterationStop = -1;
		int l_power = -1;
		NavigableLinkedHashMap <Integer, String> l_navigableLinkedHashMap = new NavigableLinkedHashMap <Integer, String> (a_numberOfElements);
		Integer l_lastElement = null;
		Integer l_currentElement = null;
		Integer l_searchedElement = null;
		l_power = 1;
		System.out.println ("#For NavigableLinkedHashMap Beginning");
		System.out.println ("#Elements  : Insertion for (ns); Search from (ns); Iteration for (ns)");
		l_nanoTimeForInsertionStart = System.nanoTime ();
		l_nanoTimeForInsertionAccumulation = 0;
		for (int l_elementIndex = 0; l_elementIndex < a_numberOfElements; l_elementIndex ++) {
			l_currentElement = Integer.valueOf (l_elementIndex);
			if (l_lastElement != null) {
				l_navigableLinkedHashMap.putBefore (((l_elementIndex % 2) == 0) ? l_navigableLinkedHashMap.getNextKey (l_lastElement) : l_lastElement, l_currentElement, "");
			}
			else {
				l_navigableLinkedHashMap.put (l_currentElement , "");
			}
			l_lastElement = l_currentElement;
			// Dummy Processing BEGINNING
			if (a_mode == 1 && l_elementIndex == 1) {
				l_nanoTimeForInsertionStop = System.nanoTime ();
				l_nanoTimeForInsertionAccumulation += l_nanoTimeForInsertionStop - l_nanoTimeForInsertionStart;
				l_searchedElement = l_navigableLinkedHashMap.getNextKey (l_lastElement);
				for (Map.Entry <Integer, String> l_navigableLinkedHashMapEntry: l_navigableLinkedHashMap.entrySet ()) {
					Integer l_element = l_navigableLinkedHashMapEntry.getKey ();
				}
				l_nanoTimeForInsertionStart = System.nanoTime ();
			}
			// Dummy Processing END
			if (l_elementIndex + 1 == Math.pow (10, l_power)) {
				l_nanoTimeForInsertionStop = System.nanoTime ();
				l_nanoTimeForInsertionAccumulation += l_nanoTimeForInsertionStop - l_nanoTimeForInsertionStart;
				l_nanoTimeForSearchStart = System.nanoTime ();
				l_searchedElement = l_navigableLinkedHashMap.getNextKey (l_lastElement);
				if (a_mode == 2) {
					System.out.println (String.format ("#Searched Element: %d", l_searchedElement));
				}
				l_nanoTimeForSearchStop = System.nanoTime ();
				l_nanoTimeForIterationStart = System.nanoTime ();
				for (Map.Entry <Integer, String> l_navigableLinkedHashMapEntry: l_navigableLinkedHashMap.entrySet ()) {
					Integer l_element = l_navigableLinkedHashMapEntry.getKey ();
					if (a_mode == 2 && l_power == 2) {
						System.out.println (String.format ("#Iterated Element: %d", l_element));
					}
				}
				l_nanoTimeForIterationStop = System.nanoTime ();
				System.out.println (String.format ("# %,9d: %,18d; %,16d; %,18d", l_elementIndex + 1, l_nanoTimeForInsertionAccumulation, l_nanoTimeForSearchStop - l_nanoTimeForSearchStart, l_nanoTimeForIterationStop - l_nanoTimeForIterationStart));
				l_nanoTimeForInsertionStart = System.nanoTime ();
				l_power ++;
			}
		}
		System.out.println ("#For NavigableLinkedHashMap End");
	}
}
